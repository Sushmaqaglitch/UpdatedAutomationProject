The CCDT & JKS files are stored in the project for local development only.  In the cloud, these files are accessed from the pipeline secret vault.  

Eventually, we hope to be able to access the secret vault from our local development machines.  The architects are still working on a way to make this possible.

Test this process from ESB. Hit the below URL

https://devbus1a:7855/Utility/OpenshiftMQConnection
package com.healthpartners.service.imfs.common;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import javax.xml.namespace.QName;
import jakarta.xml.ws.BindingProvider;
import jakarta.xml.ws.Service;
import jakarta.xml.ws.WebEndpoint;
import jakarta.xml.ws.WebServiceClient;

import com.healthpartners.service.imfs.dto.*;

import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.logging.log4j.Logger;


public class BPMUtils {
	static SimpleDateFormat MMddyyyyFormat = new SimpleDateFormat("MM/dd/yyyy");
	static SimpleDateFormat MMddyyyyNoDelFormat = new SimpleDateFormat("MMddyyyy");
	static SimpleDateFormat CCYYmmddFormat = new SimpleDateFormat("yyyy/mm/dd");
	static SimpleDateFormat MdyyyyFormat = new SimpleDateFormat("M/d/yyyy");
	static SimpleDateFormat MMddyyyyHHmmssFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
	static SimpleDateFormat mmddyyyyFormat = new SimpleDateFormat("mm/dd/yyyy");
	
	static SimpleDateFormat CCYYmmddFormatWODel = new SimpleDateFormat("yyyyMMdd");
	

	protected final Log logger = LogFactory.getLog(getClass());
	
	
	public static String overrideDateWithYear(String dateStr, int yearOverride) {
		Date activityDate = BPMUtils.convertStringToSqlDate(dateStr, BPMConstants.HP_BPM_COMMON_DATE_FORMAT);
		
		Calendar dateCalendar = BPMUtils.dateToCalendar(activityDate);
		dateCalendar.set(Calendar.YEAR, yearOverride);
		java.sql.Date convertedDate = calendarToSqlDate(dateCalendar);
		String convertedDateStr = convertSqlDateToString(convertedDate);
		
		return convertedDateStr;
		
	}
	
	public static java.sql.Date convertStringToSqlDate(String dateStr, String dateFormat) {
		java.sql.Date sqlDate = null;
		if (dateStr != null && !dateStr.trim().equals("")) {
			try {
				SimpleDateFormat formater = new SimpleDateFormat(dateFormat);
				java.util.Date parsedDate = formater.parse(dateStr);
				sqlDate = new java.sql.Date(parsedDate.getTime());
			} catch (Exception e) {
				sqlDate = null;
			}
		}
		return sqlDate;
	}
	
public static String convertSqlDateToString(java.sql.Date sqlDate) {
		
		String dateStr;
		
		try {
			SimpleDateFormat fmt = new SimpleDateFormat(
					BPMConstants.HP_BPM_COMMON_DATE_FORMAT);
			dateStr = fmt.format(sqlDate);
			
		} catch (Exception e) {
			dateStr = null;
		}
		
		return dateStr; 
	}

	public static Calendar dateToCalendar(Date pDate) {
		if (pDate == null) {
			return null;
		}
		Calendar lCalendar = Calendar.getInstance();
		lCalendar.setTime(pDate);
		return lCalendar;
	}

	public static Date calendarToUtilDate(Calendar pCalendar) {
		return pCalendar != null ? pCalendar.getTime() : null;
	}
	
	public static java.sql.Date calendarToSqlDate(Calendar pCalendar) {
		return pCalendar != null ? new java.sql.Date(pCalendar.getTime()
				.getTime()) : null;
	}

	public static String formatDateCCYYmmdd(Calendar inputDate) {
		return CCYYmmddFormat.format(inputDate.getTime());
	}
	
	
	public static String formatDateMMddyyyy(Calendar inputDate) {
		return MMddyyyyFormat.format(inputDate.getTime());
	}
	
	public static String formatDateMMddyyyyNoDel(Calendar inputDate) {
		return MMddyyyyNoDelFormat.format(inputDate.getTime());
	}
	
	public static String formatDatemmddyyyy(Calendar inputDate) {
		return mmddyyyyFormat.format(inputDate.getTime());
	}
	
	public static String formatDateCCYYmmddFormat(java.sql.Date date) 
	{		
		return CCYYmmddFormat.format(date);
	}
	
	public static String formatDateMMddyyyy(java.sql.Date date) 
	{		
		return MMddyyyyFormat.format(date);
	}
	
	
	public static String formatDateCCYYmmddWODel(java.sql.Date date) {
		return CCYYmmddFormatWODel.format(date);
	}
	
	public static String formatDateCCYYmmddWODel(java.util.Date date) {
		return CCYYmmddFormatWODel.format(date);
	}
	
	public static java.sql.Date formatDateMMddyyyy(String dateStr) 
	{	
		java.sql.Date sqlDate = null;
		try {
			
			java.util.Date parsedUtilDate = MMddyyyyFormat.parse(dateStr);   
			sqlDate= new java.sql.Date(parsedUtilDate.getTime());  
		}
			catch(Exception e)
			{
				//return null for date.
			}
		return sqlDate;
	}
	
	public static String formatDateMdyyyy(java.sql.Date date) 
	{		
		return MdyyyyFormat.format(date);
	}
	
	public static java.sql.Date getDateFromStringMMddyyyy( String dateStr) {
		Date convertedDate = null;
		try {	    
			convertedDate = MMddyyyyFormat.parse(dateStr);  
		} catch (NullPointerException e) {     
			return null;
		} catch (ParseException e) {     
			return null;
		}
		java.sql.Date sqlDate = new java.sql.Date(convertedDate.getTime());
	    
       return sqlDate;
}
	
	public static java.sql.Date getDateFromString(String pInputDate)
	{
		java.sql.Date lSQLDate = null;
		
		try
		{
		    java.util.Date parsedUtilDate = MMddyyyyHHmmssFormat.parse(pInputDate);   
		    lSQLDate= new java.sql.Date(parsedUtilDate.getTime());
		}
		catch(Exception e)
		{
			return new java.sql.Date(System.currentTimeMillis());
		}
		return lSQLDate;
	}
	
	public static Integer getYearFromDateString(String pInputDateWithFormatInMMDDYYYY)
	{
		java.sql.Date lSQLDate = null;
		Integer year = null;
		
		
		try
		{
			
			lSQLDate = getDateFromStringMMddyyyy(pInputDateWithFormatInMMDDYYYY);
			
			Calendar cal = Calendar.getInstance();
			cal.setTime(lSQLDate);
			
			year = cal.get(Calendar.YEAR);
		}
		catch(Exception e)
		{
			return 0;
		}
		
		return year;
	}
	
	
	public static boolean isValueInteger(String fieldValue) {
		boolean result = true;
		
		try {
			Integer integerValue = new Integer(fieldValue.trim());
		} catch (NumberFormatException ne) {
			result = false;
		}
		
		return result;
	}

	/**
	 * Determines if the given Activity is one the Eligible Activities of this
	 * Program.
	 * 
	 * @param pBusinessProgramTO
	 * @param pActivityDefinition
	 * @return
	 */
	public static boolean isActivityEligible(
			BusinessProgramTO pBusinessProgramTO,
			ActivityDefinition pActivityDefinition) {
		boolean isActivityEligible = false;

		if (pBusinessProgramTO.getBusinessProgram() != null) {
			if (pBusinessProgramTO.getBusinessProgram().getEligibleActivities() != null) {
				for (int i = 0; i < pBusinessProgramTO.getBusinessProgram()
						.getEligibleActivities().length; i++) {
					EligibleActivity lEligibleActivity = (EligibleActivity) pBusinessProgramTO
							.getBusinessProgram().getEligibleActivities()[i];
					if (lEligibleActivity.getActivity().getActivityID() != null
							&& pActivityDefinition.getActivityID() != null
							&& lEligibleActivity.getActivity().getActivityID()
									.intValue() == pActivityDefinition
									.getActivityID().intValue()) {
						isActivityEligible = true;
						break;
					}
				}
			}
		}

		return isActivityEligible;
	}

	public static Calendar getMinimumDate(Calendar oneDate, Calendar twoDate) {

		setTimeToZero(oneDate);		
		setTimeToZero(twoDate);
		
		return (oneDate.compareTo(twoDate) > 0) ? twoDate : oneDate;
	}

	public static Calendar getMaximumDate(Calendar oneDate, Calendar twoDate) {

		setTimeToZero(oneDate);		
		setTimeToZero(twoDate);
		
		return (oneDate.compareTo(twoDate) > 0) ? oneDate : twoDate;
	}
	
	/*
	 * Determine if 2 sets of dates overlap.
	 */
	public static boolean isBetweenDates(java.sql.Date targetDate, java.sql.Date effDate, java.sql.Date endDate) 
	{
		boolean betweenDates = false;
		
		if (targetDate.equals(effDate)) {
			betweenDates = true;
		} else if (targetDate.equals(endDate)) {
					betweenDates = true;
		} else if (targetDate.after(effDate) && 
				targetDate.before(endDate)) {
				betweenDates = true;
		}
		
		return betweenDates;
	}

	/*
	 * Determine if a birth date is 18 and older.
	 */
	public static boolean is18Plus(java.sql.Date dateOfBirthSql)
	{

		if (getAge(dateOfBirthSql.toLocalDate()) >= 18) {
			return true;
		}


		return false;
	}

	public static int getAge(LocalDate dob) {
		LocalDate curDate = LocalDate.now();
		return Period.between(dob, curDate).getYears();
	}
	/**
	 * Calculates the number of days between two calendar days in a manner which
	 * is independent of the Calendar type used.
	 * 
	 * @param d1
	 *            The first date.
	 * @param d2
	 *            The second date.
	 * 
	 * @return The number of days between the two dates. the value returned is =
	 *         0 if d1 euals d2 the value returned is > 0 if d1 after d2 the
	 *         value returned is < 0 if d1 before d2 If Calendar types of d1 and
	 *         d2 are different, the result may not be accurate.
	 */
	public static int getDaysBetweenDates(java.util.Calendar d1,
			java.util.Calendar d2) {
		boolean isD1afterD2 = false;
		if (d1.after(d2)) { // swap dates so that d1 is start and d2 is end
			java.util.Calendar swap = d1;
			d1 = d2;
			d2 = swap;
			isD1afterD2 = true;
		}
		int days = d2.get(java.util.Calendar.DAY_OF_YEAR)
				- d1.get(java.util.Calendar.DAY_OF_YEAR);
		int y2 = d2.get(java.util.Calendar.YEAR);
		if (d1.get(java.util.Calendar.YEAR) != y2) {
			d1 = (java.util.Calendar) d1.clone();
			do {
				days += d1.getActualMaximum(java.util.Calendar.DAY_OF_YEAR);
				d1.add(java.util.Calendar.YEAR, 1);
			} while (d1.get(java.util.Calendar.YEAR) != y2);
		}

		// if d1 < d2 send negative value
		if (!isD1afterD2) {
			days = -days;
		}
		return days;
	} // getDaysBetween()

	public static String getTimeDifferenceAsString(java.util.Date startDate,
			java.util.Date endDate) {
		String msg = null;

		long seconds = ((endDate.getTime() - startDate.getTime()) / 1000L);

		if (seconds < 1) {
			msg = "< 1 second";
		} else {
			if (seconds > 3600) {
				long hours = (seconds / 3600);
				msg = hours + " hour" + (hours == 1 ? "" : "s");
				seconds -= (hours * 3600);
			}
			if (seconds > 60) {
				long minutes = (seconds / 60);
				msg = (msg == null ? "" : msg + ", ") + minutes + " minute"
						+ (minutes == 1 ? "" : "s");
				seconds -= (minutes * 60);
			}
			if (seconds > 0) {
				msg = (msg == null ? "" : msg + ", ") + seconds + " second"
						+ (seconds == 1 ? "" : "s");
			}
		}

		return msg;
	}

	public static String getStakTraceAsString(Throwable e) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		return sw.toString();
	}

	public static String getFormattedDateTime(java.util.Date date) 
	{		
		return MMddyyyyHHmmssFormat.format(date);
	}	
	
	public static java.sql.Date getDateMMDDYYYYFromString(String dateStr) throws Exception 
	{
		java.util.Date parsedUtilDate = null;
		try {
			parsedUtilDate = MMddyyyyFormat.parse(dateStr);
		} catch (Exception pe) {
			throw new Exception("BPMUtils.getDateMMDDYYYYFromString could not convert date", pe);
		}
		  
		java.sql.Date sqlDate= new java.sql.Date(parsedUtilDate.getTime());  

		return sqlDate; 
	}
	/*
	 * Retrieves system date.
	 */
	public static java.sql.Date getCurrentDate() {
		
		java.util.Date today = new java.util.Date();
		long t = today.getTime();
		java.sql.Date dt = new java.sql.Date(t);
		
		return dt;
	}

	public static java.sql.Date convertFromUtilDateToSQLDate(
			java.util.Date utilDate) {
		java.util.Calendar cal = Calendar.getInstance();
		cal.setTime(utilDate);
		java.sql.Date sqlDate = new java.sql.Date(cal.getTime().getTime());
		return sqlDate;
	}
	
	/*
	 * No parameter to pass since using Calendar date.  Based on todays date, determine
	 * if lands on a Monday.
	 */
	public static boolean isFirstDayOfWeekMonday() {
		Calendar calendar = Calendar.getInstance(); 
		
		
		int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
		boolean firstDayOfWeekMonday = false;
		
		if (dayOfWeek == Calendar.MONDAY) {
			  firstDayOfWeekMonday = true;
		}
		
		return firstDayOfWeekMonday;
	}
	
	/*
	 * No parameter to pass since using Calendar date.  Based on todays date, determine
	 * if lands on first day of month.
	 */
	public static boolean isFirstDayOfMonth() {
		Calendar calendar = Calendar.getInstance(); 
		int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH); 
		
		boolean firstDayOfMonth = false;
		
		if (dayOfMonth == 1) {
			firstDayOfMonth = true;
		} 
		
		return firstDayOfMonth;
	}
	/*
	 * No parameter to pass since using Calendar date.  Based on todays date, determine
	 * if lands on first day of quarter.
	 */
	public static boolean isFirstDayOfQuarter(boolean firstDayOfMonth) {
		boolean startOfQuarter = false;
		Calendar calendar = Calendar.getInstance(); 
		
		if (firstDayOfMonth) {
			//Determine Quarterly
			int currentMonth = calendar.get(calendar.MONTH); 
			//check end of fourth quarter
			if (currentMonth == Calendar.JANUARY) {
				startOfQuarter = true;
				//check for end of first quarter
			} else if (currentMonth == Calendar.APRIL) {
				startOfQuarter = true;
				//check for end of second quarter
			} else if (currentMonth == Calendar.JULY) {
				startOfQuarter = true;
				//check for end of third quarter
			} else if (currentMonth == Calendar.OCTOBER) {
				startOfQuarter = true;
			}
		}
	
		return startOfQuarter;
	
	}
	
	public static void setTimeToZero(Calendar pCalendar)
	{
		pCalendar.set(Calendar.HOUR_OF_DAY, 0);
		pCalendar.set(Calendar.MINUTE, 0);
		pCalendar.set(Calendar.SECOND, 0);
		pCalendar.set(Calendar.MILLISECOND, 0);
	}		
	
	
	/**
	 * Utility method that creates the Auth or Promo code based on the Business Program Qualification
	 * Start Date, and the prefix. Currently used for Smart Steps Auth Promo Codes. 
	 * Example SSHA200901, or SSPR200901
	 * 
	 * @param pBusinessProgram
	 * @param pAuthCodePrefix
	 * @return
	 */
	public static String generateProgramAuthPromoCode(BPMBusinessProgram pBusinessProgram, String pAuthCodePrefix)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat ("yyyy") ;
        String lDateFormat = dateFormat.format(new java.util.Date(pBusinessProgram.getEffectiveDate().getTime().getTime()));
		
		return pAuthCodePrefix + lDateFormat;		
	}
	
	/**
	 * Utility method that creates an End Date based on the provided effective date.
	 * 
	 * @param lProgramEffectiveDate
	 * @return
	 */
	public static Calendar generateDefaultProgramEndDate(Calendar lProgramEffectiveDate)
	{
		Calendar lProgramEndDate = (Calendar)lProgramEffectiveDate.clone();
		lProgramEndDate.add(Calendar.MONTH, BPMConstants.BPM_DEFAULT_GROUP_END_MONTH);
		lProgramEndDate.set(Calendar.DAY_OF_MONTH, lProgramEndDate.getActualMaximum(GregorianCalendar.DAY_OF_MONTH));
		return lProgramEndDate;
	}
	
	public static Calendar generateDefaultStatusCalcEndDate(Calendar lProgramEndDate, BPMBusinessProgram pBusinessProgram)
	{
		// Set the default status calculation end date to be 6 months after the end date.
		Calendar lStatusCalcEndDate = (Calendar)lProgramEndDate.clone();
		lStatusCalcEndDate.add(Calendar.MONTH, BPMConstants.BPM_DEFAULT_STATUS_CALC_END_MONTH);
		lStatusCalcEndDate.set(Calendar.DAY_OF_MONTH, lStatusCalcEndDate.getActualMaximum(GregorianCalendar.DAY_OF_MONTH));		
		return lStatusCalcEndDate;
	}
	
	/*
	 * Pass in a month span to be used to calculate from todays date in order to come up
	 * with an end date beyond or before the current date.  Pass in a negative value
	 * to get a date before the current date.
	 */
	public static java.sql.Date determineCutOffDate(String months) {
		
		Integer monthSpan = Integer.valueOf(months);
		java.sql.Date currDate = new java.sql.Date(new Date().getTime());
		Calendar calcCutOffDate = Calendar.getInstance();
		calcCutOffDate.setTime(currDate);
		calcCutOffDate.add(Calendar.MONTH, monthSpan);
		
		java.sql.Date calcCutOffSQLDate = new java.sql.Date(new Date().getTime());
		calcCutOffSQLDate = BPMUtils.calendarToSqlDate(calcCutOffDate);
		
		return calcCutOffSQLDate;
		
			
	}
	
	/*
	 * Pass in a day span to be used to calculate from the start date in order to come up
	 * with an end date beyond or before the current date.  Pass in a negative value
	 * to get a date before the start date.
	 */
	public static Calendar determineCutOffDate(Calendar startDate, Integer daySpan) {
		
		startDate.add(Calendar.DATE, daySpan);
		
		Calendar endDate = dateToCalendar(startDate.getTime());
		
		return endDate;
		
			
		
	}
	
	/*
	 * Pass in a week(s) span to be used to calculate from todays date in order to come up
	 * with an end date beyond or before the current date.  Pass in a negative value
	 * to get a date before the current date.
	 */
	public static java.sql.Date determineWeekCutOffDate(String week) {
		
		Integer weakSpan = Integer.valueOf(week);
		java.sql.Date currDate = new java.sql.Date(new Date().getTime());
		Calendar calcCutOffDate = Calendar.getInstance();
		calcCutOffDate.setTime(currDate);
		calcCutOffDate.add(Calendar.WEEK_OF_MONTH, weakSpan);
		
		java.sql.Date calcCutOffSQLDate = new java.sql.Date(new Date().getTime());
		calcCutOffSQLDate = BPMUtils.calendarToSqlDate(calcCutOffDate);
		
		return calcCutOffSQLDate;
		
			
	}
	
	/**  
	 * Get the n-th x-day of the month in which the specified date lies.    
	 * @param input the specified date  * @param weeks 1-based offset (e.g. 1 means 1st week)  
	 * @param targetWeekDay (the weekday we're looking for, e.g. Calendar.MONDAY  
	 * @return the target date 
	 */ 
	public static Date getNthXdayInMonth(final Date input, final int weeks, final int targetWeekDay){
		// strip all date fields below month     
		final Date startOfMonth = DateUtils.truncate(input, Calendar.MONTH);     
		final Calendar cal = Calendar.getInstance();     
		cal.setTime(startOfMonth);     
		final int weekDay = cal.get(Calendar.DAY_OF_WEEK);     
		final int modifier = (weeks - 1) * 7 + (targetWeekDay - weekDay);     
		return modifier > 0         
		      ? addDays(cal, modifier)         
		      : startOfMonth; 
    } 
	
	private static Date addDays(Calendar startOfMonthCal, int modifier) {
		startOfMonthCal.add(Calendar.DAY_OF_MONTH, modifier);
		
		return startOfMonthCal.getTime();
		
	}
	
	/**
	   * Right justify the contents of the string, ensuring that the string ends at the last character. If the supplied string is
	   * longer than the desired width, the leading characters are removed so that the last character in the supplied string at the
	   * last position. If the supplied string is shorter than the desired width, the padding character is inserted one or more
	   * times such that the last character in the supplied string appears as the last character in the resulting string and that
	   * the length matches that specified.
	   * 
	   * @param str the string to be right justified; if null, an empty string is used
	   * @param width the desired width of the string; must be positive
	   * @param padWithChar the character to use for padding, if needed
	   * @return the right justified string
	   */
	  public static String justifyRight( String str,
	                                     final int width,
	                                     char padWithChar ) {
	      assert width > 0;
	      // Trim the leading and trailing whitespace ...
	      str = str != null ? str.trim() : "";

	      final int length = str.length();
	      int addChars = width - length;
	      if (addChars < 0) {
	          // truncate the first characters, keep the last
	          return str.subSequence(length - width, length).toString();
	      }
	      // Prepend the whitespace ...
	      final StringBuilder sb = new StringBuilder();
	      while (addChars > 0) {
	          sb.append(padWithChar);
	          --addChars;
	      }

	      // Write the content ...
	      sb.append(str);
	      return sb.toString();
	  }
	  
	  /** 
	   * Left justify a string, and fill to a given length with the blanks.
	   * If the length of the string is greater than "maxLength" characters, return only 
	   * the first, left "maxLength" characters. 
	   */     
	  public static String justifyLeft(String s, int maxLength) { 
	    return justifyLeft(s, maxLength, ' ');
	  }                

	  /** 
	   * Left justify a string, and fill to a given length with the character <code>fill</code>.
	   * If the length of the string is greater than "maxLength" characters, return only 
	   * the first, left "maxLength" characters. 
	   */     
	  public static String justifyLeft(String s, int maxLength, char fill) {
	    if (s == null || maxLength == 0 ) { 
	      return s; 
	    }
	    // If the string has more than "maxLength" characters, 
	    // return only the first "maxLength" characters of the string. 
	    if ( s.trim().length() > maxLength ) { 
	      return s.substring( 0, maxLength ).trim(); 
	    }

	    StringBuffer sb = new StringBuffer(s.trim()); 

	    // Append as many blanks as needed to reach "maxLength". 
	    while ( sb.length() < maxLength ) {
	      sb.append(fill); 
	    }

	    return sb.toString(); 

	  }
	  
	  public static String rightPadString(String lValue, Integer lFixedLength) {
			StringBuffer lPaddedString = new StringBuffer(); 
			lPaddedString.append(lValue);
			
		    if(lValue.length() < lFixedLength)
		    {
		    	for(int i = 0; i < lFixedLength - lValue.length(); i++)
		    	{
		    		lPaddedString.append(" ");
		    	}
		    } else {
		    	//drop off extra characters if string buffer length is longer than lFixedLength
		    	StringBuffer lPaddedString2 = new StringBuffer();
		    	
		    	if (lValue.length() > lFixedLength) {
			    	for(int i = 0; i < lFixedLength; i++)
			    	{
			    		char character = lPaddedString.charAt(i);
			    		lPaddedString2.append(character);
			    	}
			    	return lPaddedString2.toString();
		    	}
		    }
		    
		    return lPaddedString.toString();
	}
	
	  /*
	   * Used for dollar representation if padding with zero's beyond implied decimal is required.
	   */
	  public static String leftPadWZerosNRightPadDecimal(String lValue, Integer lFixedLength) {
	 		StringBuffer lPaddedString = new StringBuffer();
	 	    
	 		
	 	    if(lValue.length() < lFixedLength)
	 	    {
	 	    	for(int i = 0; i < lFixedLength - lValue.length(); i++)
	 	    	{
	 	    		lPaddedString.append("0");
	 	    	}
	 	    }
	 	    lPaddedString.append(lValue);
	 	    //append decimal placeholder
	 	    for(int i = 0; i < 2; i++)
	     	{
	     		lPaddedString.append("0");
	     	}
	 	    return lPaddedString.toString();
	 }

	  public static String leftPadWZeros(String lValue, Integer lFixedLength) {
	 		StringBuffer lPaddedString = new StringBuffer();
	 	    
	 		
	 	    if(lValue.length() < lFixedLength)
	 	    {
	 	    	for(int i = 0; i < lFixedLength - lValue.length(); i++)
	 	    	{
	 	    		lPaddedString.append("0");
	 	    	}
	 	    }
	 	    lPaddedString.append(lValue);
	 	    
	 	    return lPaddedString.toString();
	 }
	  
	  public static String leftPadWZerosPadDecZeroes(String lValue, Integer lFixedLength) {
			StringBuffer lPaddedString = new StringBuffer();
		    
			
		    if(lValue.length() < lFixedLength)
		    {
		    	for(int i = 0; i < lFixedLength - lValue.length(); i++)
		    	{
		    		lPaddedString.append("0");
		    	}
		    }
		    lPaddedString.append(lValue);
		    //append decimal placeholder
		    for(int i = 0; i < 2; i++)
	    	{
	    		lPaddedString.append("0");
	    	}
		    return lPaddedString.toString();
	}
	  
	  
	  public static String formatSSNWHyphens(String ssn) {
		  String areaNo = ssn.substring(0, 3);
		  String groupNo = ssn.substring(3, 5);
		  String serialNo = ssn.substring(5, 9);
		  
		  ssn = areaNo + "-" + groupNo + "-" + serialNo;
		  
		  return ssn;
	  }	  
	  
	  public static void logException(final Log log, Exception e) {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			log.error(sw.toString());
		}
	  
	  public static java.sql.Date getSqlDateFromString(String dateString) {
			java.sql.Date sqlDate;
			try {
				SimpleDateFormat fmt = new SimpleDateFormat(
						BPMConstants.HP_BPM_COMMON_DATE_FORMAT);
				java.util.Date utilDate = fmt.parse(dateString.trim());
				sqlDate = new java.sql.Date(utilDate.getTime());
			} catch (Exception e) {
				sqlDate = null;
			}

			return sqlDate;
		}
	  
	  public static File[] readForFiles(String inpath) {
		   
		  	File Folder = new File(inpath); 
	  	  
		  	File files[];        
		  	files = Folder.listFiles();              
		  	
		  	return files;
	  }
	  
	  public static Collection<CSVTokens> readNParseCSVFile(String inPath) throws Exception{
		  ArrayList<CSVTokens> tokensSet = new ArrayList<CSVTokens>();
		  try
          {
			  	  
				//read in multiple CSV files if exists.
				File[] files = readForFiles(inPath);
				
				//create BufferedReader to read csv file
				for (int i = 0; i < files.length; i++) {
				  String fileName =	files[i].getName();
				  System.out.println("File being read " + fileName);
                  //create BufferedReader to read csv file
                  BufferedReader br = new BufferedReader( new FileReader(files[i]));
                  String strLine = "";
                  StringTokenizer st = null;
                  int lineNumber = 0, tokenNumber = 0;
                 
                  //read comma separated file line by line
                  while( (strLine = br.readLine()) != null)
                  {
                          lineNumber++;
                          //append pipe delimeter at end of string in order for the tokenizer
                          //to recognize the last value as a node.
                          strLine = strLine + " |";
                          //examine and replace pipe delimited empty string so it resolves as a node.
                          //need to pass it through twice because after the first pass may not resolve all the nodes.
                          strLine = strLine.replace("||", "| |");
                          strLine = strLine.replace("||", "| |");
                          //break pipe delimited separated line using "|"
                          st = new StringTokenizer(strLine, "|");
                          
                          CSVTokens tokens = new CSVTokens();
                         
                          while(st.hasMoreTokens())
                          {
                                  //display csv values
                                  tokenNumber++;
                                  
                                  String tokenStr = st.nextToken();
                                  tokens.getCsvTokenColumns().add(tokenStr);
                                  System.out.println("Line # " + lineNumber +
                                                  ", Token # " + tokenNumber
                                                  + ", Token : "+ tokenStr);
                                  
                          }
                          //add file name as last token
                          tokenNumber++;
                          tokens.getCsvTokenColumns().add(fileName);
                          System.out.println("Line # " + lineNumber +
                                  ", Token # " + tokenNumber
                                  + ", Token : "+ fileName);
                          
                          tokensSet.add(tokens);
                          //reset token number
                          tokenNumber = 0;
                         
                  }
                 
                  br.close(); 
			  }
          }
          catch(Exception e)
          {
                  System.out.println("Exception while reading csv file (Possible file not found): " + e); 
                  throw e;
          }
		  
		  return tokensSet;
		  
	  }
	  
	  public static Collection<CSVTokens> readNParseCommaDelimitedCSVFile(String inPath) throws Exception{
		  ArrayList<CSVTokens> tokensSet = new ArrayList<CSVTokens>();
		  try
          {
			  	  
				//read in multiple CSV files if exists.
				File[] files = readForFiles(inPath);
				
				//create BufferedReader to read csv file
				for (int i = 0; i < files.length; i++) {
				  String fileName =	files[i].getName();
				  System.out.println("File being read " + fileName);
                  //create BufferedReader to read csv file
                  BufferedReader br = new BufferedReader( new FileReader(files[i]));
                  String strLine = "";
                  StringTokenizer st = null;
                  int lineNumber = 0, tokenNumber = 0;
                 
                  //read comma separated file line by line
                  while( (strLine = br.readLine()) != null)
                  {
                          lineNumber++;
                          //append comma delimeter at end of string in order for the tokenizer
                          //to recognize the last value as a node.
                          strLine = strLine + " ,";
                          //examine and replace comma delimited empty string so it resolves as a node.
                          //need to pass it through twice because after the first pass may not resolve all the nodes.
                          strLine = strLine.replace(",,", ", ,");
                          strLine = strLine.replace(",,", ", ,");
                          //break comma delimited separated line using ","
                          st = new StringTokenizer(strLine, ",");
                          
                          CSVTokens tokens = new CSVTokens();
                         
                          while(st.hasMoreTokens())
                          {
                                  //display csv values
                                  tokenNumber++;
                                  
                                  String tokenStr = st.nextToken();
                                  tokens.getCsvTokenColumns().add(tokenStr);
                                  System.out.println("Line # " + lineNumber +
                                                  ", Token # " + tokenNumber
                                                  + ", Token : "+ tokenStr);
                                  
                          }
                          //add file name as last token
                          tokenNumber++;
                          tokens.getCsvTokenColumns().add(fileName);
                          System.out.println("Line # " + lineNumber +
                                  ", Token # " + tokenNumber
                                  + ", Token : "+ fileName);
                          
                          tokensSet.add(tokens);
                          //reset token number
                          tokenNumber = 0;
                         
                  }
                 
                  br.close(); 
			  }
          }
          catch(Exception e)
          {
                  System.out.println("Exception while reading csv file (Possible file not found): " + e); 
                  throw e;
          }
		  
		  return tokensSet;
		  
	  }
	  
	  public static <T extends Service, I extends Object> I getService(Class<T> serviceClass, Class<I> serviceInterface, String urlString, Logger log) throws MalformedURLException, RuntimeException {
			URL url = new URL(urlString);
			log.info("BPMUtils.getService called....");
			return getService(serviceClass, serviceInterface, url, log);
		}

		/**
		 * Figure out the proper targetNameSpace, and port name for any {@link Service} and return the service port
		 * @param serviceClass
		 * @param serviceInterface
		 * @param url
		 * @param log
		 * @return
		 */
		public static <T extends Service, I extends Object> I getService(Class<T> serviceClass, Class<I> serviceInterface, URL url, Logger log) throws RuntimeException {
			String targetNamespace = null;
			String serviceName = null;
			
			WebServiceClient serviceAnnotation = serviceClass.getAnnotation(WebServiceClient.class);
			if (serviceAnnotation != null) {
				targetNamespace = serviceAnnotation.targetNamespace();
				serviceName = serviceAnnotation.name();
			}
			QName serviceQName = new QName(targetNamespace, serviceName);

			Constructor<T> constructor = null;
			try {
				log.info("Log 1: Before contructor:");
				constructor = serviceClass.getConstructor(URL.class, QName.class);
				log.info("Log 2: After contructor:");
				log.info("Log 2.1: constructor name : " + constructor.getName());
				log.info("Log 2.2: constructor annotations : " + constructor.getDeclaredAnnotations().toString());
			
				T service = constructor.newInstance(url, serviceQName);
				
				log.info("Log 3: Service instantated at constructor.newInstance(url, serviceQName)");

				for (Method method : serviceClass.getMethods()) {
					WebEndpoint annotation = method.getAnnotation(WebEndpoint.class);
					if (annotation != null && method.getReturnType().equals(serviceInterface)) {
						log.info("Log 4: Annotation toString: " + annotation.toString());
						serviceName = annotation.name();
						break;
					}
				}
				QName interfaceQName = new QName(targetNamespace, serviceName);
				log.info("Log 5: Before call made to service.getPort ");
				if (serviceInterface == null) {
					log.info("serviceInterface is null");
				} else {
					log.info("serviceInterface is not null");
					log.info("serviceInterface getName " + serviceInterface.getName());
					log.info("serviceInterface toString " + serviceInterface.toString());
				}
				if (interfaceQName == null) {
					log.info("interfaceQName is null");
				} else {
					log.info("interfaceQName is not null");
					log.info("interfaceQName.getNamespaceURI " + interfaceQName.getNamespaceURI());
					log.info("interfaceQName.toString " + interfaceQName.toString());
				}
				QName lQName = null;
				if (service == null) {
					log.info("service is null");
				} else {
					log.info("service is not null");
					log.info("service.getServiceName " + service.getServiceName());
					log.info("service.getPorts " + service.getPorts());
					Iterator<QName> lQNames = service.getPorts();
					while (lQNames.hasNext()) {
				        lQName = lQNames.next();
						log.info("lQName.getLocalPart() from service = " + lQName.getLocalPart());
						log.info("lQName.getNamespaceURI() from service = " + lQName.getNamespaceURI());
						
					}
					log.info("service.getWSDLDocumentLocation " + service.getWSDLDocumentLocation());
				}
				
				log.info("BPMUtils.getService called 2 using serviceClass class SubmitFileServiceServiceagent ....");
				log.info("BPMUtils.getService called 2  using serviceInterface class SubmitFileSoap ....");
				log.info("BPMUtils.getService called 2  this is a test ....");
				
				
				I port = null;
				
				try {
					log.error("Before Call on service.getPort(lQName, serviceInterface)");
					port = service.getPort(lQName, serviceInterface);
					log.debug("Call successful on service.getPort(lQName, serviceInterface)");
				} catch (Exception e) {
					log.debug("NullPointerException caught on call to service.getPort(interfaceQName, serviceInterface) ");
					log.debug("Exception 1 is  " + e.getStackTrace());
					log.debug("Exception message  " + e.getMessage());
					log.debug("Exception string   " + e.toString());
					log.debug("Exception cause    " + e.getCause());
				}
				
				try {
					log.debug("Before Call successful on service.getPort(serviceInterface)");
					port = service.getPort(serviceInterface);
					log.debug("Call successful on service.getPort(serviceInterface)");
				} catch (Exception e) {
					log.debug("NullPointerException caught on call to service.getPort(serviceInterface) ");
					log.debug("Exception 2 is  " + e.getStackTrace());
					log.debug("Exception message  " + e.getMessage());
					log.debug("Exception string   " + e.toString());
					log.debug("Exception cause    " + e.getCause());
				} finally {
					log.debug("Continue on....");
				}
				
				try {
					log.debug("Before Call successful on service.getPort(interfaceQName, serviceInterface)");
					port = service.getPort(interfaceQName, serviceInterface);
					log.debug("Call successful on service.getPort(interfaceQName, serviceInterface)");
				} catch (Exception e) {
					log.debug("NullPointerException caught on call to service.getPort(interfaceQName, serviceInterface) ");
					log.debug("Exception 3 is  " + e.getStackTrace());
					log.debug("Exception message  " + e.getMessage());
					log.debug("Exception string   " + e.toString());
					log.debug("Exception cause    " + e.getCause());
				}
				
				log.info("Log 6: After call made to service.getPort ");
				Map<String, Object> requestContext = ((BindingProvider)port).getRequestContext();
				requestContext.put(BPMConstants.TRANSPORT_READ_TIMEOUT
						, BPMConstants.DEFAULT_READ_TIMEOUT_SECONDS * 1000);
				log.info("Log 7: return port");
				return port;
			} catch (Exception e) {
				
				log.error("Could not instantiate service");
				log.error("TargetNamespace is " + targetNamespace);
				log.error("ServiceName is     " + serviceName);
				log.error("Url is             " + url.toString());
				log.error("ServiceQName is    " + serviceQName.toString());
				log.error("constructor.newInstance(url, serviceQName) responsivle for returning the client service object.  Here's the contents: " + constructor.toString());
				log.error("Exception message  " + e.getMessage());
				log.debug("Exception string   " + e.toString());
				log.error("Exception cause    " + e.getCause());
				log.error("Exception stack trace " + e.getStackTrace());
				log.error("Exception fill in stack trace " + e.fillInStackTrace());
				log.error("Exception localized message " + e.getLocalizedMessage());
				log.error("Exception caught.  Stacktrace is " + e.getStackTrace());
				
				
				throw new RuntimeException(e);
			}
		}
		
		public static void moveFiles(String filePathFrom, String filePathTo) {
			
			InputStream inStream = null;
			OutputStream outStream = null;
		 
	    	try{
	    		
	    		File[] files = readForFiles(filePathFrom);
	    		
	    		for (int i = 0; i < files.length; i++) {
	    			String fileName = files[i].getName();
	    			if (fileName.startsWith("processed")) {
	    				break;
	    			}
	    			String filePathNFileNameFrom = filePathFrom + fileName;
	    			System.out.println("Path from " + filePathNFileNameFrom);
	    			String filePathNFileNameTo = filePathTo + fileName;
	    			System.out.println("Path to   " + filePathNFileNameTo);
	    			
		    	    File afile =new File(filePathNFileNameFrom);
		    	    File bfile =new File(filePathNFileNameTo);
		 
		    	    inStream = new FileInputStream(afile);
		    	    outStream = new FileOutputStream(bfile);
		 
		    	    byte[] buffer = new byte[1024];
		 
		    	    int length;
		    	    //copy the file content in bytes 
		    	    while ((length = inStream.read(buffer)) > 0){
		 
		    	    	outStream.write(buffer, 0, length);
		 
		    	    }
		 
		    	    inStream.close();
		    	    outStream.close();
		 
		    	    //delete the original file
		    	    afile.delete();
		 
		    	    System.out.println("File is copied successful!");
	    		}
		 
	    	}catch(IOException e){
	    	    e.printStackTrace();
	    	}
		}

		/**
		 * Determines if the package is of type HRA.
		 * 
		 * @param pPersonPackage
		 * @return
		 */
		public static boolean isTypeHRA(PersonPackage pPersonPackage)
		{
			if(BPMConstants.BPM_PRODUCT_SUBTYPE_HRA.equals(pPersonPackage.getPackageSubTypeName()))
			{
				return true;
			}
			
			return false;
		}
		
		/**
		 * Determines if the package is of type HSA.
		 * 
		 * @param pPersonPackage
		 * @return
		 */
		public static boolean isTypeHSA(PersonPackage pPersonPackage)
		{			
			if(BPMConstants.BPM_PRODUCT_SUBTYPE_HSA.equals(pPersonPackage.getPackageSubTypeName()))
			{
				return true;
			}
			
			return false;
		}
		
		public boolean validateOnlyNumerics(java.lang.String fieldValue) {
			
			if (fieldValue == null) {        
				return false;    
			}  
			
			char c;
			boolean validNumber = true;
			for (int i = 0; i < fieldValue.length() ; i++) {  
				c = fieldValue.charAt(i);  
				if (Character.isDigit(c)) {       
				       
				} else {		
						validNumber = false;
						break;
				}
			}    
			
			return validNumber;
			
		}
		
		
		/**
		 * returns true is a status is Qualified, or any of the Exempt statuses.
		 * @param pStatus
		 * @return
		 */
		public static boolean isStatusQualifiedOrExempt(String pStatus)
		{
			return (BPMConstants.CONTRACT_STATUS_QUALIFIED.equalsIgnoreCase(pStatus)
					|| BPMConstants.MEMBER_STATUS_EXEMPT.equalsIgnoreCase(pStatus)
					|| BPMConstants.MEMBER_STATUS_EXEMPT_ELIGIBLE.equalsIgnoreCase(pStatus)
					|| BPMConstants.MEMBER_STATUS_EXEMPT_HOLD.equalsIgnoreCase(pStatus)
					|| BPMConstants.MEMBER_STATUS_EXEMPT_ACTIVE.equalsIgnoreCase(pStatus)
					|| BPMConstants.MEMBER_STATUS_EXEMPT_QUALIFIED.equalsIgnoreCase(pStatus)
					|| BPMConstants.MEMBER_STATUS_EXEMPT_HA_COMPLETED.equalsIgnoreCase(pStatus)
					);
		}
		
		/*
		 * Converting Double to a formatted string will allow the 0 as the last digit
		 * past the decimal point be retained.  A decimal of type Double will drop the zero
		 * and is inaccurately displayed.
		 */
		public static String convertDoubleToDecimalFormattedString(Double value) {
			DecimalFormat valueFormat = new DecimalFormat("#,##0.00;(#)");
			String valueStr = valueFormat.format(value);
		
			return valueStr;
		}
	/*
	  Use this utility method to set timestamp to zero if using sql date in compare conditions.
	 */
	public static java.sql.Date convertSQLDateSettingTimeToZero(java.sql.Date date) {
		Calendar calendar = Calendar.getInstance();

		calendar.setTime( date );
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.HOUR, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);

		return BPMUtils.calendarToSqlDate(calendar);
	}


		public static String zipCode5Parser (String zipCode) {

			String zip5 = zipCode.substring(0, 5);

			return zip5;

		}

		public static String zipCode4ExtParser (String zipCode) {

			String zip4 = "";

			if (zipCode.length() == 10) {
				//consider dash when parsing
				zip4 = zipCode.substring(6);
			} else if (zipCode.length() == 9) {
					//consider no dash when parsing
					zip4 = zipCode.substring(5);
			}


			return zip4;
		}
}
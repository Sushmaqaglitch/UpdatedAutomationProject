package com.healthpartners.service.imfs.dao;



import java.sql.Date;
import java.sql.SQLTimeoutException;
import java.util.Collection;

import com.healthpartners.service.imfs.dto.RejectedPerson;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.QueryTimeoutException;

import com.healthpartners.service.imfs.dto.RejectedPerson;
import com.healthpartners.service.imfs.exception.BPMException;


public interface EmployerRecycleDAO 
{
	
	public Collection<RejectedPerson> getPersonEmployerRecyclePossibleMatches(String firstName, String lastName, java.sql.Date birthDate, String groupNo)
			throws DataAccessException, SQLTimeoutException, QueryTimeoutException;
	
	public void insertEmployerRecycle(RejectedPerson pRejectedPerson, String pUserID)
	throws BPMException, DataAccessException;
	
	public void insertEmployerRecycleWithContribution(RejectedPerson pRejectedPerson, String pUserID)
	throws BPMException, DataAccessException;
	
	public Collection<RejectedPerson> getEmployerRecycle(Integer activityId,
			String firstName, String lastName, Date dateOfBirth, Date activityDate, Date recycleStatusDate, Integer recycleStatusId, Integer personDemographicsID, Integer contributionAmt);
	
}

package com.healthpartners.service.imfs.exception;

public class BPMException extends Exception 
{
	private static final long serialVersionUID = 1234567899L;
	
	private String message;
	
	public BPMException() {
		super();
	}
	
	public BPMException(String message) {
		super(message);
		setMessage(message);
	}
	
	public BPMException(String message, Throwable cause) {
		super(message, cause);
	}
	
	public BPMException(Throwable cause) {
		super(cause);
		setMessage(cause.getMessage());
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}		
}

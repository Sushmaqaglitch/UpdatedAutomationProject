package com.healthpartners.service.imfs.iface;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Calendar;

import org.springframework.dao.DataRetrievalFailureException;

//import com.healthpartners.claims.x10.Coverage;
//import com.healthpartners.coverage.client.CoverageService_Impl;
import com.healthpartners.service.imfs.exception.BPMException;



public interface CacheCoverageService 
{

	
	/*
	public CoverageService_Impl getRealtimeCoverageService() 
	throws BPMException;
	
	public ArrayList<Coverage> getMemberCoverage(String memberNbr, Calendar coverageDate, String coverageType) 
	throws BPMException, DataRetrievalFailureException, RemoteException; 
	*/
	
}

package com.healthpartners.service.imfs.config;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;

import javax.sql.DataSource;

@Configuration
public class BeanConfigCache {

    @Autowired
    DataSource cacheDataSource;

    @Bean(name = "CacheDataSourceTransactionManager")
    public DataSourceTransactionManager getDataSourceTransactionManager() {
        return new DataSourceTransactionManager(cacheDataSource);
    }


}

package com.healthpartners.service.imfs.impl;

import java.util.ArrayList;
import java.util.Collection;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMEmailUtility;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dao.ControlGroupIOFileDirSetupDAO;
import com.healthpartners.service.imfs.dto.ActivityEvent;
import com.healthpartners.service.imfs.dto.BPMAuditRecord;
import com.healthpartners.service.imfs.dto.GroupActivityProgressTracker;
import com.healthpartners.service.imfs.dto.LookUpValueCode;
import com.healthpartners.service.imfs.dto.PersonContractHist;
import com.healthpartners.service.imfs.dto.RejectedPerson;
import com.healthpartners.service.imfs.exception.BPMBusinessValidationException;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.iface.ActivityEventService;
import com.healthpartners.service.imfs.iface.BusinessProgramService;
import com.healthpartners.service.imfs.iface.EmailService;
import com.healthpartners.service.imfs.iface.GroupActivityProgressTrackerService;
import com.healthpartners.service.imfs.iface.LookUpValueService;
import com.healthpartners.service.imfs.iface.MemberService;
import com.healthpartners.service.imfs.iface.ProgramStatusCalculationService;
import com.healthpartners.service.imfs.iface.ResetActivityEventsFromInprocessToPendingService;
import com.healthpartners.service.imfs.iface.UploadEmployerActivityPreprocessService;
import com.healthpartners.service.imfs.rules.StatusCalculationCommand;
@Component
@Service
public class ResetActivityEventsFromInprocessToPendingServiceImpl implements ResetActivityEventsFromInprocessToPendingService {
		

		protected final Log logger = LogFactory.getLog(getClass());

		@Autowired
		private EmailService emailService;
		@Autowired
		private ActivityEventService activityEventService;
		@Autowired
		private ProgramStatusCalculationService programStatusCalculationService;
		@Autowired
		private LookUpValueService lookUpValueService;
		
		private String hostName;
		private String userID;
		
		
	/*
	 * Batch job to scan through the activity event log table looking for activity events in a IN_PROCESS status.  Those that are encountered will
	 * be reset back to PENDING and processed again by kicking off the pending activity job.
	 */
		@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
				BPMBusinessValidationException.class, BPMException.class })
	public void processResetActivityEventsFromInprocessToPendingCommand(StatusCalculationCommand statusCalculationCommand) throws BPMException {
			
				logger.info("@Start - Reset Activity Event From INPROCESS to PENDING Command. ");
					
				int recsUpdated = 0;
				
				String failureReason = null;
				String elapsedTime = null;
				
				java.util.Date startDate = new java.util.Date();
				java.util.Date endDate = null;			
				
			
				statusCalculationCommand.setCurrentCommandText("Reset IN_PROCESS Activity Events");
				
				java.sql.Date activityEventCutoffDate = getActivityEventCutoffDate(BPMConstants.RESET_INPROCESS_ACTIVITY_EVENT_CUTOFF_DATE);
				
				boolean isTwoDaysNolder = false;
				if (statusCalculationCommand.getStartAtTwoDaysNolderFlag() != null && statusCalculationCommand.getStartAtTwoDaysNolderFlag().equals("Y")) {
					isTwoDaysNolder = true;
				}
				String sourceSystemID = statusCalculationCommand.getSourceSystemID();
				
				Collection<ActivityEvent> inprocessActivityEvents  =  
							(Collection<ActivityEvent>)activityEventService.getActivityEventLogsByProcessingStatus(BPMConstants.PROCESSING_STATUS_INPROCESS, activityEventCutoffDate, isTwoDaysNolder, sourceSystemID); 
				
				if (inprocessActivityEvents.size() > 0) {
					try {
						
						recsUpdated = activityEventService.updateActivityLogProcessingStatus(inprocessActivityEvents, BPMConstants.PROCESSING_STATUS_PENDING);
						startPendingActivities();
						
						} catch (Exception e) {
							failureReason = BPMUtils.getStakTraceAsString(e);
							logger.error(failureReason, e);
						} finally {
							endDate = new java.util.Date();
							elapsedTime = BPMUtils
									.getTimeDifferenceAsString(startDate, endDate);
							logger.info("@@@@End - Total processing time " + elapsedTime);
							logger.info("@@@@End - Number of Activity Event Processing Status set from INPROCESS to PENDING:  "
									+ recsUpdated);
							
							
							
						}
					
				} else {
					endDate = new java.util.Date();
					elapsedTime = BPMUtils
							.getTimeDifferenceAsString(startDate, endDate);	
				}		
					
				StringBuffer batchMailSubject = new StringBuffer();
				batchMailSubject.append("BPM Batch Process - INPROCESS Activity Events Reset To PENDING - Status: ");
				StringBuffer batchMailContent = new StringBuffer();
				batchMailContent
				.append("<table>");
				batchMailContent.append("<tr><td>BPM Batch Name: INPROCESS Activity Events Reset To PENDING</td></tr>");
				batchMailContent.append("<tr><td>Initiated User: "
						+ statusCalculationCommand.getUserID() + "</td></tr>");
				batchMailContent.append("<tr><td>Time Start: "
						+ BPMUtils.getFormattedDateTime(startDate) + "</td></tr>");
				batchMailContent.append("<tr><td>INPROCESS Activity Event  Cutoff Date: "
						+ BPMUtils.getFormattedDateTime(activityEventCutoffDate) + "</td></tr>");
				
				
				if (failureReason != null) {
					batchMailSubject.append("- FAILED");
					batchMailContent.append("<tr><td>Result: FAILED" + "</td></tr>");
					batchMailContent.append("<tr><td>Reason: ");
					batchMailContent.append(failureReason + "</td></tr>");
				} else {
					batchMailSubject.append("- SUCCESS");
					batchMailContent.append("<tr><td>Result: SUCCESS" + "</td></tr>");
				}
				
				
				if (isTwoDaysNolder) {
					batchMailContent
					.append("<tr><td> </td></tr>");
					batchMailContent
					.append("<tr><td>Two Days and older flag ACTIVATED</td></tr>");
				}
				batchMailContent
				.append("<tr><td> </td></tr>");
				if (sourceSystemID != null && sourceSystemID.length() > 0) {
					batchMailContent
					.append("<tr><td>Source System ID ACTIVATED: " + sourceSystemID + "</td></tr>");
				} else {
					batchMailContent
					.append("<tr><td>ALL Source Systems ACTIVATED.</td></tr>");
				}
				
				batchMailContent
				.append("<tr><td> </td></tr>");
				if (recsUpdated > 0) {
					batchMailContent
					.append("<tr><td>INPROCESS Activity Event records updated with PENDING:  " + recsUpdated + "</td></tr>");
				} else {
					batchMailContent
					.append("<tr><td> No INPROCESS Activity Event records were found.</td></tr> ");
				}
								
				
				
				batchMailContent
				.append("</table>");
				emailService.setEmailDestination(BPMConstants.BPM_EMAIL_TO_ADDR_RECONCILE_RPT);
				emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
				emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
						batchMailContent.toString());
				

				if (failureReason != null) {
					logger.info("processResetActivityEventsFromInprocessToPendingCommand Failed: " + failureReason);
					throw new BPMException(failureReason);
				}
				
				logger.info("@End - Reset Activity Event From INPROCESS to PENDING Command. ");
	 }
	
		/*
		 *  Get person contract history reconciliation date.
		 */
		private java.sql.Date getActivityEventCutoffDate(String value) throws BPMException {
			
			LookUpValueCode lookUpValueCode = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.BPM_INPROCESS_ACTIVITY_CUTOFF, value);
			String weekSpan = lookUpValueCode.getLuvDesc();
			weekSpan = "-" + weekSpan;  //Append minus sign.
			java.sql.Date activityEventInprocessCutoffDateSql = BPMUtils.determineWeekCutOffDate(weekSpan);
			
			return activityEventInprocessCutoffDateSql;
		}
		
		/*
		 * Kickoff pending activities job.
		 */
		private void startPendingActivities() throws BPMException {
			// start pending activities batch job
			StatusCalculationCommand calculationCommand = new StatusCalculationCommand();
			calculationCommand.setPendingActivityEventsCommand();
			calculationCommand.setUserID(userID);
			
			try {
				programStatusCalculationService.updateProgramStatus(calculationCommand);	
			} catch (Exception e) {
				String errorMessage = "Error trying to call programStatusCalculationService.updateProgramStatus. Attempting to kick off pending activities.";
				logger.error(errorMessage);
			
				throw new BPMException(errorMessage); 
			}
		}

		public void setEmailService(EmailService emailService) {
			this.emailService = emailService;
		}

		

		public void setActivityEventService(ActivityEventService activityEventService) {
			this.activityEventService = activityEventService;
		}

		public void setProgramStatusCalculationService(
				ProgramStatusCalculationService programStatusCalculationService) {
			this.programStatusCalculationService = programStatusCalculationService;
		}

		public void setLookUpValueService(LookUpValueService lookUpValueService) {
			this.lookUpValueService = lookUpValueService;
		}
		
		
		
}

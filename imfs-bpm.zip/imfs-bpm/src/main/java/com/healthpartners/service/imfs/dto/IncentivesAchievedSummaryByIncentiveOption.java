package com.healthpartners.service.imfs.dto;



import java.util.Date;

public class IncentivesAchievedSummaryByIncentiveOption
{	
	
	private String groupNo;
	private String groupName;
	private Date effectiveDate;
	private String incentiveOptionName;
	private String contractStatusCodeName;
	private String memberStatusCodeName;
	private int sumTotal;
	
	public String getGroupNo() {
		return groupNo;
	}
	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getIncentiveOptionName() {
		return incentiveOptionName;
	}
	public void setIncentiveOptionName(String incentiveOptionName) {
		this.incentiveOptionName = incentiveOptionName;
	}
	
	
	public String getContractStatusCodeName() {
		return contractStatusCodeName;
	}
	public void setContractStatusCodeName(String contractStatusCodeName) {
		this.contractStatusCodeName = contractStatusCodeName;
	}
	public String getMemberStatusCodeName() {
		return memberStatusCodeName;
	}
	public void setMemberStatusCodeName(String memberStatusCodeName) {
		this.memberStatusCodeName = memberStatusCodeName;
	}
	public int getSumTotal() {
		return sumTotal;
	}
	public void setSumTotal(int sumTotal) {
		this.sumTotal = sumTotal;
	}
	
	
	
	
}

package com.healthpartners.service.imfs.dto;

import java.io.Serializable;

import com.healthpartners.service.imfs.rules.StatusCalculationCommand;
import com.healthpartners.service.imfs.rules.StatusCalculationWSCommand;

public class BatchCommandRequest implements Serializable {
	static final long serialVersionUID = 0L;

	private String filteredActivityEventsCommand;

	private String pendingTaskEventsCommand;

	private String pendingActivityEventsCommand;

	private String etlMembershipUpdateCommand;

	private String memberElapsedTimeCommand;

	private String mbrShipFeedCommand;
	
	private String mbrShipPremiumBillingFeedCommand;

	private String autoProgramSetupCommand;

	private String autoProgramNewSetupCommand;

	private String employerGroupSiteSetupCommand;

	private String employerGroupBaselineSetupCommand;

	private String purgeAuditLogTableCommand;

	private String purgeProcessStatLogTableCommand;

	private String purgeGroupBaselineHistCommand;

	private String personContractHistReconciliationCommand;

	private String generateEmployerFulfillmentCSVCommand;

	private String generateEmployerFulfillmentResendCSVCommand;

	private String cdhpHraFulfillmentCommand;

	private String cdhpHsaFulfillmentCommand;

	private String rewardFulfillmentCommand;

	private String rewardFilesFromIntelispendCommand;
	
	private String populateMissingPeopleCommand;
	
	private String populatePackageBaselineCommand;
	
	private String uploadEmployerSponsoredActivityPreprocessCommand;
	
	private String uploadEmployerSponsoredActivityPostprocessCommand;
	
	private String uploadEmployerSponsoredActivityIncentedToFulfillReconCommand;

	private String memberRecalcCommand;

	private String userID;

	private Integer batchSize;

	private String processName;

	private String groupNo;

	private String snapShotEmplFulfillTrackDate;

	private String startEmplFulfillTrackDate;
	
	private String deleteTermedParticipantsCommand;
	
	private String processUnresolvedContractBenefitTypeForActivityIncentiveCommand;
	
	
	private String archivePersonContractProgramHistoryCommand;
	
	private String personContractRecycleActionNeededReportCommand;
	
	private int daySpanToCtrlFilteredOutActivity;
	
	

	public int indexCtr = 0;

	private static int commandArraySize = 11;

	private String[] commandArray;

	public String[] getCommandArray() {
		return commandArray;
	}

	public void setCommandArray(String[] commandArray) {
		this.commandArray = commandArray;
	}

	public BatchCommandRequest() {
		commandArray = new String[commandArraySize];

	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getAutoProgramSetupCommand() {
		return autoProgramSetupCommand;
	}

	public void setAutoProgramSetupCommand() {
		setParameterCommandArray(indexCtr,
				StatusCalculationWSCommand.AUTO_PROGRAM_SETUP);
		this.indexCtr++;
	}

	public String getAutoProgramNewSetupCommand() {
		return autoProgramNewSetupCommand;
	}

	public void setAutoProgramNewSetupCommand(String autoProgramNewSetupCommand) {
		setParameterCommandArray(indexCtr,
				StatusCalculationWSCommand.AUTO_PROGRAM_NEW_SETUP);
		this.indexCtr++;
	}
	
	

	public String getEmployerGroupSiteSetupCommand() {
		return employerGroupSiteSetupCommand;
	}

	public void setEmployerGroupSiteSetupCommand(
			String employerGroupSiteSetupCommand) {
		setParameterCommandArray(indexCtr,
				StatusCalculationWSCommand.EMPLOYER_GROUP_SITE_SETUP);
		this.indexCtr++;
	}

	public String getEmployerGroupBaselineSetupCommand() {
		return employerGroupBaselineSetupCommand;
	}

	public void setEmployerGroupBaselineSetupCommand(
			String employerGroupBaselineSetupCommand) {
		setParameterCommandArray(indexCtr,
				StatusCalculationWSCommand.EMPLOYER_BASELINE_SETUP);
		this.indexCtr++;
	}

	public String getFilteredActivityEventsCommand() {
		return filteredActivityEventsCommand;
	}

	public void setFilteredActivityEventsCommand() {
		setParameterCommandArray(indexCtr,
				StatusCalculationWSCommand.FILTERED_ACTIVITY_EVENTS);
		this.indexCtr++;
	}

	public String getPendingTaskEventsCommand() {
		return pendingTaskEventsCommand;
	}

	public void setPendingTaskEventsCommand() {
		setParameterCommandArray(indexCtr,
				StatusCalculationWSCommand.PENDING_TASK_EVENTS);
		this.indexCtr++;
	}

	public String getPendingActivityEventsCommand() {
		return pendingActivityEventsCommand;
	}

	public void setPendingActivityEventsCommand() {
		setParameterCommandArray(indexCtr,
				StatusCalculationWSCommand.PENDING_ACTIVITY_EVENTS);
		this.indexCtr++;
	}

	public String getEtlMembershipUpdateCommand() {
		return etlMembershipUpdateCommand;
	}

	public void setEtlMembershipUpdateCommand() {
		setParameterCommandArray(indexCtr,
				StatusCalculationWSCommand.ETL_MEMBERSHIP_UPDATE);
		this.indexCtr++;
	}

	public String getMemberElapsedTimeCommand() {
		return memberElapsedTimeCommand;
	}

	public void setMemberElapsedTimeCommand() {
		setParameterCommandArray(indexCtr,
				StatusCalculationWSCommand.MEMBER_ELAPSED_TIME);
		this.indexCtr++;
	}

	public String getMbrShipFeedCommand() {
		return mbrShipFeedCommand;
	}

	public void setMbrShipFeedCommand() {
		setParameterCommandArray(indexCtr,
				StatusCalculationWSCommand.MEMBERSHIP_FEED);
		this.indexCtr++;
	}
	
	public String getMbrShipPremiumBillingFeedCommand() {
		return mbrShipPremiumBillingFeedCommand;
	}

	public void setMbrShipPremiumBillingFeedCommand() {
		setParameterCommandArray(indexCtr,
				StatusCalculationWSCommand.MEMBERSHIP_PREMIUM_BILLING_FEED);
		this.indexCtr++;
	}

	public String getPurgeAuditLogTableCommand() {
		return purgeAuditLogTableCommand;
	}

	public void setPurgeAuditLogTableCommand() {
		setParameterCommandArray(indexCtr,
				StatusCalculationWSCommand.PURGE_AUDIT_LOG_TABLE);
		this.indexCtr++;
	}

	public String getPurgeProcessStatLogTableCommand() {
		return purgeProcessStatLogTableCommand;
	}

	public void setPurgeProcessStatLogTableCommand() {
		setParameterCommandArray(indexCtr,
				StatusCalculationWSCommand.PURGE_PROCESSLG_TABLE);
		this.indexCtr++;
	}

	public String getPurgeGroupBaselineHistCommand() {
		return purgeGroupBaselineHistCommand;
	}

	public void setPurgeGroupBaselineHistCommand() {
		setParameterCommandArray(indexCtr,
				StatusCalculationWSCommand.PURGE_GROUPBASELINEHIST_TABLE);
		this.indexCtr++;
	}

	public String getPersonContractHistReconciliationCommand() {
		return personContractHistReconciliationCommand;
	}

	public void setPersonContractHistReconciliationCommand() {
		setParameterCommandArray(indexCtr,
				StatusCalculationWSCommand.CONTRACT_RECONCILIATION);
		this.indexCtr++;
	}

	public String getMemberRecalcCommand() {
		return memberRecalcCommand;
	}

	public void setMemberRecalcCommand() {
		setParameterCommandArray(indexCtr,
				StatusCalculationWSCommand.MEMBERS_RECALCULATION);
		this.indexCtr++;
	}

	public String getCdhpHraFulfillmentCommand() {
		return cdhpHraFulfillmentCommand;
	}

	public void setCdhpHraFulfillmentCommand() {
		setParameterCommandArray(indexCtr,
				StatusCalculationWSCommand.CDHP_HRA_FULFILLMENT_REPORTING);
		this.indexCtr++;
	}

	public String getCdhpHsaFulfillmentCommand() {
		return cdhpHsaFulfillmentCommand;
	}

	public void setCdhpHsaFulfillmentCommand() {
		setParameterCommandArray(indexCtr,
				StatusCalculationWSCommand.CDHP_HSA_FULFILLMENT_REPORTING);
		this.indexCtr++;
	}

	public String getRewardFulfillmentCommand() {
		return rewardFulfillmentCommand;
	}

	public void setRewardFulfillmentCommand(String rewardFulfillmentCommand) {
		this.rewardFulfillmentCommand = rewardFulfillmentCommand;
		this.indexCtr++;
	}

	public String getRewardFilesFromIntelispendCommand() {
		return rewardFilesFromIntelispendCommand;
	}

	public void setRewardFilesFromIntelispendCommand(
			String rewardFilesFromIntelispendCommand) {
		this.rewardFilesFromIntelispendCommand = rewardFilesFromIntelispendCommand;
		this.indexCtr++;
	}
	
	public String getPopulateMissingPeopleCommand() {
		return populateMissingPeopleCommand;
	}

	public void setPopulateMissingPeopleCommand(
			String command) {
		setParameterCommandArray(indexCtr, command);
		this.indexCtr++;
	}
	
	public String getPopulatePackageBaselineCommand() {
		return populatePackageBaselineCommand;
	}

	public void setPopulatePackageBaselineCommand(
			String command) {
		setParameterCommandArray(indexCtr, command);
		this.indexCtr++;
	}
	
	public String getUploadEmployerSponsoredActivityPreprocessCommand() {
		return uploadEmployerSponsoredActivityPreprocessCommand;
	}

	public void setUploadEmployerSponsoredActivityPreprocessCommand(
			String command) {
		setParameterCommandArray(indexCtr, command);
		this.indexCtr++;
	}
	
	public String getUploadEmployerSponsoredActivityPostprocessCommand() {
		return uploadEmployerSponsoredActivityPostprocessCommand;
	}

	public void setUploadEmployerSponsoredActivityPostprocessCommand(
			String command) {
		setParameterCommandArray(indexCtr, command);
		this.indexCtr++;
	}
	
	
	public String getUploadEmployerSponsoredActivityIncentedToFulfillReconCommand() {
		return uploadEmployerSponsoredActivityIncentedToFulfillReconCommand;
	}

	public void setUploadEmployerSponsoredActivityIncentedToFulfillReconCommand(
			String command) {
		setParameterCommandArray(indexCtr, command);
		this.indexCtr++;
	}

	public String getDeleteTermedParticipantsCommand() {
		return deleteTermedParticipantsCommand;
	}

	public void setDeleteTermedParticipantsCommand(
			String command) {
		setParameterCommandArray(indexCtr, command);
		this.indexCtr++;
	}
	
	public String getProcessUnresolvedContractBenefitTypeForActivityIncentiveCommand() {
		return processUnresolvedContractBenefitTypeForActivityIncentiveCommand;
	}

	public void setProcessUnresolvedContractBenefitTypeForActivityIncentiveCommand(
			String command) {
		setParameterCommandArray(indexCtr, command);
		this.indexCtr++;
	}
	
	public String getPersonContractRecycleActionNeededReportCommand() {
		return personContractRecycleActionNeededReportCommand;
	}

	public void setArchivePersonContractProgramHistoryCommand(
			String command) {
		setParameterCommandArray(indexCtr, command);
		this.indexCtr++;
	}

	public String getArchivePersonContractProgramHistoryCommand() {
		return archivePersonContractProgramHistoryCommand;
	}

	public void setPersonContractRecycleActionNeededReportCommand(
			String command) {
		setParameterCommandArray(indexCtr, command);
		this.indexCtr++;
	}
	
	
	
	public String[] getParameterCommandArray() {
		return commandArray;
	}


	public void setParameterCommandArray(int index, String value) {
		commandArray[index] = value;
	}

	public int getIndexCtr() {
		return this.indexCtr;
	}

	public Integer getBatchSize() {
		return batchSize;
	}

	public void setBatchSize(Integer batchSize) {
		this.batchSize = batchSize;
	}

	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}

	public String getGroupNo() {
		return groupNo;
	}

	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}

	public String getSnapShotEmplFulfillTrackDate() {
		return snapShotEmplFulfillTrackDate;
	}

	public void setSnapShotEmplFulfillTrackDate(
			String snapShotEmplFulfillTrackDate) {
		this.snapShotEmplFulfillTrackDate = snapShotEmplFulfillTrackDate;
	}

	public String getStartEmplFulfillTrackDate() {
		return startEmplFulfillTrackDate;
	}

	public void setStartEmplFulfillTrackDate(String startEmplFulfillTrackDate) {
		this.startEmplFulfillTrackDate = startEmplFulfillTrackDate;
	}

	public String getGenerateEmployerFulfillmentCSVCommand() {
		return generateEmployerFulfillmentCSVCommand;
	}

	public void setGenerateEmployerFulfillmentCSVCommand() {
		setParameterCommandArray(indexCtr,
				StatusCalculationWSCommand.EMPLOYER_FULFILLMENT_REPORTING);
		this.indexCtr++;
	}

	public String getGenerateEmployerFulfillmentResendCSVCommand() {
		return generateEmployerFulfillmentResendCSVCommand;
	}

	public void setGenerateEmployerFulfillmentResendCSVCommand() {
		setParameterCommandArray(
				indexCtr,
				StatusCalculationWSCommand.EMPLOYER_FULFILLMENT_REPORTING_RESEND);
		this.indexCtr++;
	}

	public int getDaySpanToCtrlFilteredOutActivity() {
		return daySpanToCtrlFilteredOutActivity;
	}

	public void setDaySpanToCtrlFilteredOutActivity(int daySpanToCtrlFilteredOutActivity) {
		this.daySpanToCtrlFilteredOutActivity = daySpanToCtrlFilteredOutActivity;
	}
	
	
    
}

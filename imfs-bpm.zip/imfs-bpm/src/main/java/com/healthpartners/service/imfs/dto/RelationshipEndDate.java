package com.healthpartners.service.imfs.dto;


public class RelationshipEndDate 
{
	private java.sql.Date endDate;
	private Integer relationshipCodeID;
	
	public RelationshipEndDate()
	{
		super();
	}

	public java.sql.Date getEndDate() {
		return endDate;
	}

	public void setEndDate(java.sql.Date endDate) {
		this.endDate = endDate;
	}

	public Integer getRelationshipCodeID() {
		return relationshipCodeID;
	}

	public void setRelationshipCodeID(Integer relationshipCodeID) {
		this.relationshipCodeID = relationshipCodeID;
	}


	
	
}

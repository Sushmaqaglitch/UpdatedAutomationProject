package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.util.Calendar;

public class IncentiveOption implements Serializable
{	
	static final long serialVersionUID = 0L;

    public IncentiveOption()
    {
    	super();
    }

    private Integer incentiveOptionID;    
    private String incentiveOptionName;
    private String incentiveOptionDesc;
    private Integer incentiveOptionTypeCodeID;
    private String incentiveOptionTypeCode;
    private String incentiveOptionTypeDesc;
    private Integer incentiveUnitTypeCodeID;
    private String incentiveUnitTypeCode;
    private String creationDate;
    private String closeDate;
	
	public final Integer getIncentiveOptionID() {
		return incentiveOptionID;
	}
	public final void setIncentiveOptionID(Integer incentiveOptionID) {
		this.incentiveOptionID = incentiveOptionID;
	}
	public final String getIncentiveOptionName() {
		return incentiveOptionName;
	}
	public final void setIncentiveOptionName(String incentiveOptionName) {
		this.incentiveOptionName = incentiveOptionName;
	}
	public final String getIncentiveOptionTypeCode() {
		return incentiveOptionTypeCode;
	}
	public final void setIncentiveOptionTypeCode(String incentiveOptionTypeCode) {
		this.incentiveOptionTypeCode = incentiveOptionTypeCode;
	}
	public final Integer getIncentiveOptionTypeCodeID() {
		return incentiveOptionTypeCodeID;
	}
	public final void setIncentiveOptionTypeCodeID(Integer incentiveOptionTypeCodeID) {
		this.incentiveOptionTypeCodeID = incentiveOptionTypeCodeID;
	}
	public final String getIncentiveOptionTypeDesc() {
		return incentiveOptionTypeDesc;
	}
	public final void setIncentiveOptionTypeDesc(String incentiveOptionTypeDesc) {
		this.incentiveOptionTypeDesc = incentiveOptionTypeDesc;
	}
	public final String getIncentiveOptionDesc() {
		return incentiveOptionDesc;
	}
	public final void setIncentiveOptionDesc(String incentiveOptionDesc) {
		this.incentiveOptionDesc = incentiveOptionDesc;
	}
	
	public Integer getIncentiveUnitTypeCodeID() {
		return incentiveUnitTypeCodeID;
	}
	public void setIncentiveUnitTypeCodeID(Integer incentiveUnitTypeCodeID) {
		this.incentiveUnitTypeCodeID = incentiveUnitTypeCodeID;
	}
	
	public String getIncentiveUnitTypeCode() {
		return incentiveUnitTypeCode;
	}
	public void setIncentiveUnitTypeCode(String incentiveUnitTypeCode) {
		this.incentiveUnitTypeCode = incentiveUnitTypeCode;
	}
	public final String getCloseDate() {
		return closeDate;
	}
	public final void setCloseDate(String closeDate) {
		this.closeDate = closeDate;
	}
	public final String getCreationDate() {
		return creationDate;
	}
	public final void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
    
    
}

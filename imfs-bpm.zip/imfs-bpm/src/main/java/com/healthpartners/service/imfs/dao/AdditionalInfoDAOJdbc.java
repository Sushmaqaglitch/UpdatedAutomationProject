package com.healthpartners.service.imfs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.healthpartners.service.imfs.dto.AdditionalInformation;
import com.healthpartners.service.imfs.dto.NamedParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.exception.BPMException;
import org.springframework.dao.DataAccessException;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;

/**
 * 
 * @author tjquist
 *
 */
@Configuration
public class AdditionalInfoDAOJdbc extends JdbcDaoSupport implements AdditionalInfoDAO 
{
	private String selectAdditionalInfo;
	private String insertAdditionalInformation;
	
	private DataFieldMaxValueIncrementer additionalInfoIdIncrementer;

	@Autowired
	DataSource bpmDataSource;

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}

	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 60, rollbackFor = { BPMException.class})
	public  Collection<AdditionalInformation> getAdditionalInfo(Integer programID)
	{
		Object params[] = new Object[] { programID };
		int types[] = new int[] { Types.INTEGER };
		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setBizPgmId(programID);
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);
		List<AdditionalInformation> lAdditionalInfos = namedParameterJdbcTemplate.query(selectAdditionalInfo, namedParameters,
				new RowMapper() {
					@Override
					public AdditionalInformation mapRow(ResultSet rs, int i) throws SQLException {
						AdditionalInformation lAdditionalInfo = new AdditionalInformation();

						lAdditionalInfo.setBusinessProgramID(rs.getInt("biz_pgm_id"));
						lAdditionalInfo.setAdditionalInfoID(rs.getInt("addl_info_id"));
						lAdditionalInfo.setAdditionalInfoName(rs.getString("addl_info_nm"));
						lAdditionalInfo.setAdditionalInfoText(rs.getString("addl_info_txt"));
						lAdditionalInfo.setSortOrder(rs.getInt("sort_ordr"));
						lAdditionalInfo.setAdditionalInfoTypeID(rs.getInt("ADDL_INFO_TP_CD_ID"));
						return lAdditionalInfo;
					}

		});
		
		return lAdditionalInfos;
	}
	
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 60, rollbackFor = { BPMException.class})
	public void insertAdditionalInformation(AdditionalInformation pAdditionalInformation,
			String lUserID) {
		
		// Retrieve the next sequence number for the audit log entry.
		
		Integer addInfoId = additionalInfoIdIncrementer.nextIntValue();
		
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {
		addInfoId,		
		pAdditionalInformation.getBusinessProgramID(),
		pAdditionalInformation.getAdditionalInfoName(),
		pAdditionalInformation.getAdditionalInfoText(),
		pAdditionalInformation.getSortOrder(),
		pAdditionalInformation.getAdditionalInfoTypeID(), 
		lUserID };

		int types[] = new int[] { Types.INTEGER,Types.INTEGER,
				Types.VARCHAR, Types.VARCHAR,
				Types.INTEGER, Types.INTEGER, Types.VARCHAR};

		template.update(insertAdditionalInformation, params, types);
		return;
	}


	public String getSelectAdditionalInfo() {
		return selectAdditionalInfo;
	}


	public void setSelectAdditionalInfo(String selectAdditionalInfo) {
		this.selectAdditionalInfo = selectAdditionalInfo;
	}


	public DataFieldMaxValueIncrementer getAdditionalInfoIdIncrementer() {
		return additionalInfoIdIncrementer;
	}


	public void setAdditionalInfoIdIncrementer(
			DataFieldMaxValueIncrementer additionalInfoIdIncrementer) {
		this.additionalInfoIdIncrementer = additionalInfoIdIncrementer;
	}


	public String getInsertAdditionalInformation() {
		return insertAdditionalInformation;
	}


	public void setInsertAdditionalInformation(String insertAdditionalInformation) {
		this.insertAdditionalInformation = insertAdditionalInformation;
	}
	
}

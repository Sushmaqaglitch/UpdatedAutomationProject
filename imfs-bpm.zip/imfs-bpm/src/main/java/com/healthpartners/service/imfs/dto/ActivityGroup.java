package com.healthpartners.service.imfs.dto;

public class ActivityGroup extends BaseDTO
{
	static final long serialVersionUID = 0L;
    		
	private Integer ID;	
	private String name;
	private String description;
	private Boolean requiredFlag;
	private Integer minRequiredScore;
	private Integer groupScore;
	private Integer order;

	public ActivityGroup()
	{
		super();		
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getGroupScore() {
		return groupScore;
	}

	public void setGroupScore(Integer groupScore) {
		this.groupScore = groupScore;
	}

	public Integer getID() {
		return ID;
	}

	public void setID(Integer id) {
		ID = id;
	}

	public Integer getMinRequiredScore() {
		return minRequiredScore;
	}

	public void setMinRequiredScore(Integer minRequiredScore) {
		this.minRequiredScore = minRequiredScore;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getOrder() {
		return order;
	}

	public void setOrder(Integer order) {
		this.order = order;
	}

	public Boolean getRequiredFlag() {
		return requiredFlag;
	}

	public void setRequiredFlag(Boolean requiredFlag) {
		this.requiredFlag = requiredFlag;
	}
	
	
}

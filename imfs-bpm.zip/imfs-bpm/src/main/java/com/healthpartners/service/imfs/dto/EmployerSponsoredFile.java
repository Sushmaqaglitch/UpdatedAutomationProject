
package com.healthpartners.service.imfs.dto;

import java.util.Collection;



/**
 * Represents a file that stores the collection of employer sponsored activity from the optum data csv file.
 * @author tjquist
 *
 */
public class EmployerSponsoredFile {

	private String groupFileSourceName;
	
	private Collection<EmployerSponsoredActivity> employerSponsoredActivities;
	
	
	public EmployerSponsoredFile() {
		super();
	}

	
	
	public String getGroupFileSourceName() {
		return groupFileSourceName;
	}



	public void setGroupFileSourceName(String groupFileSourceName) {
		this.groupFileSourceName = groupFileSourceName;
	}



	public Collection<EmployerSponsoredActivity> getEmployerSponsoredActivities() {
		return employerSponsoredActivities;
	}



	public void setEmployerSponsoredActivities(
			Collection<EmployerSponsoredActivity> employerSponsoredActivities) {
		this.employerSponsoredActivities = employerSponsoredActivities;
	}



	
	
}

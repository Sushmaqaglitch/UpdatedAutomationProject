/* $Id$ */

package com.healthpartners.service.imfs.iface;

import java.util.Collection;

import com.healthpartners.service.imfs.dto.QualificationOverride;
import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.exception.BPMException;

/**
 * @author mxthoutam
 * 
 */
public interface QualificationOverrideService {

	/**
	 * Issues an Member exemption.
	 * 
	 * @param qualificationOverride
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public void issueMemberExemption(QualificationOverride qualificationOverride)
			throws BPMException, DataAccessException;

	/**
	 * Issues Member exemptions.
	 *
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public void issueMemberExemption(Collection<QualificationOverride> qualificationOverrides)
			throws BPMException, DataAccessException;
	
	public void deleteAutomaticMemberExemptions(
			Collection<QualificationOverride> qualificationOverrides)
			throws BPMException, DataAccessException;
	
	public Collection<QualificationOverride> getAllQualificationOverrides(
			Integer personID)
			throws DataAccessException;
	
}

package com.healthpartners.service.imfs.dao;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLTimeoutException;
import java.sql.Types;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;

import com.healthpartners.service.imfs.exception.BPMException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.QueryTimeoutException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;




import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.dto.RejectedPerson;
import com.healthpartners.service.imfs.exception.BPMException;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;


/**
 * 
 * @author tjquist
 *
 */
@Configuration
public class EmployerRecycleDAOJdbc extends JdbcDaoSupport implements EmployerRecycleDAO 
{
	
	private String selectEmployerRecyclePossibleMatches;
	private String insertEmployerRecycle;	
	private String insertEmployerRecycleWithContribution;
	private String selectEmployerRecycleWOptions;

	@Autowired
	DataSource bpmDataSource;


	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}
	
	/*
	 * SQL sequences
	 */
	@Autowired
	private DataFieldMaxValueIncrementer employerRecycleIdIncrementer;
	
	
	/**
	 * 
	 * @param 
	 * 		  firstName
	 * 		  lastName, 
	 * 		  birthDate
	 *        recycleStatusId
	 * @return
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<RejectedPerson> getPersonEmployerRecyclePossibleMatches(String firstName, String lastName, java.sql.Date birthDate, String groupNo)
			throws DataAccessException, SQLTimeoutException, QueryTimeoutException {
		
		
		firstName = firstName.toUpperCase();
		lastName = lastName.toUpperCase();
		
		final ArrayList<RejectedPerson> results = new ArrayList<RejectedPerson>();
		Object params[] = new Object[] { lastName + "%", birthDate, groupNo, firstName + "%", birthDate, groupNo, lastName + "%", firstName + "%", groupNo};
		JdbcTemplate template = getJdbcTemplate();
		int types[] = new int[] { Types.VARCHAR, Types.DATE, Types.VARCHAR, Types.VARCHAR, Types.DATE, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR  };
		
		StringBuffer query = new StringBuffer();
		query.append(selectEmployerRecyclePossibleMatches);
		

		template.query(query.toString(), params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException, SQLTimeoutException {
						RejectedPerson lRejectedPerson = new RejectedPerson();
						lRejectedPerson.setMemberNo(rs.getString("hp_mem_id"));
						lRejectedPerson.setFirstName(rs.getString("first_nm"));
						lRejectedPerson.setMiddleName(rs.getString("middle_nm"));
						lRejectedPerson.setLastName(rs.getString("last_nm"));
						lRejectedPerson.setDateOfBirth(rs.getDate("dob_dt")); 
						lRejectedPerson.setGender(rs.getString("gender_cd"));
						lRejectedPerson.setGroupNo(rs.getString("empl_grp_no"));
						lRejectedPerson.setSiteNo(rs.getString("empl_grp_site_id_no"));
						lRejectedPerson.setProgramEffDate(rs.getDate("eff_dt"));
									
						results.add(lRejectedPerson);
					}
				});
		return results;
	}
	
	
	/**
	 * 
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public void insertEmployerRecycle(RejectedPerson pRejectedPerson, String pUserID)
	throws BPMException, DataAccessException
	{
		JdbcTemplate template = getJdbcTemplate();
		
		Integer lEmployerRecycleID = new Integer(employerRecycleIdIncrementer.nextIntValue());
		pRejectedPerson.setEmployerRecycleID(lEmployerRecycleID);
		
		
		Object params[] = new Object[] 
		        {				
				pRejectedPerson.getEmployerRecycleID(),
				pRejectedPerson.getFirstName(),
				pRejectedPerson.getMiddleName(),
				pRejectedPerson.getLastName(),
				pRejectedPerson.getDateOfBirth(), 
				pRejectedPerson.getGender(), 
				pRejectedPerson.getRecycleStatusCode(),
				pRejectedPerson.getReasonDesc(), 
				pRejectedPerson.getApproverUserID(), 
				pRejectedPerson.getPersonDemographicsID(),
				pRejectedPerson.getSourceActivityID(), 
				pRejectedPerson.getActivityDate(),
				pUserID, pUserID				
				};

		int types[] = new int[] {Types.INTEGER,
				Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.DATE, Types.VARCHAR, 				
				Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER,   
				Types.VARCHAR,  Types.DATE, Types.VARCHAR, Types.VARCHAR };

		template.update(insertEmployerRecycle, params, types);
		
		return;
	}
	
	/**
	 * 
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public void insertEmployerRecycleWithContribution(RejectedPerson pRejectedPerson, String pUserID)
	throws BPMException, DataAccessException
	{
		JdbcTemplate template = getJdbcTemplate();
		
		Integer lEmployerRecycleID = new Integer(employerRecycleIdIncrementer.nextIntValue());
		pRejectedPerson.setEmployerRecycleID(lEmployerRecycleID);
		
		
		Object params[] = new Object[] 
		        {				
				pRejectedPerson.getEmployerRecycleID(),
				pRejectedPerson.getFirstName(),
				pRejectedPerson.getMiddleName(),
				pRejectedPerson.getLastName(),
				pRejectedPerson.getDateOfBirth(), 
				pRejectedPerson.getGender(), 
				pRejectedPerson.getRecycleStatusCode(),
				pRejectedPerson.getReasonDesc(), 
				pRejectedPerson.getContributionAmount(),
				pRejectedPerson.getExternalEmployerPersonId(),
				pRejectedPerson.getActivityName(),
				pRejectedPerson.getApproverUserID(), 
				pRejectedPerson.getPersonDemographicsID(),
				pRejectedPerson.getActivityID(), 
				pRejectedPerson.getActivityDate(),
				pUserID, pUserID				
				};

		int types[] = new int[] {Types.INTEGER,
				Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.DATE, Types.VARCHAR, 				
				Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.VARCHAR, Types.VARCHAR, 
				Types.VARCHAR, Types.INTEGER,   
				Types.VARCHAR,  Types.DATE, Types.VARCHAR, Types.VARCHAR };

		template.update(insertEmployerRecycleWithContribution, params, types);
		
		return;
	}
	
	
	/**
	 * 
	 * @param 
	 * 		  firstName
	 * 		  lastName, 
	 * 		  recycleStatusDate
	 *        recycleStatusId
	 * @return
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<RejectedPerson> getEmployerRecycle(Integer activityId,
			String firstName, String lastName, Date dateOfBirth, Date activityDate, Date recycleStatusDate, Integer recycleStatusId, Integer personDemographicsID, Integer contributionAmt)
			throws DataAccessException {
		final Collection<RejectedPerson> results = new ArrayList<RejectedPerson>();
		StringBuffer query = new StringBuffer();
		query.append(selectEmployerRecycleWOptions);
		
		ArrayList<Object> lParameters = new ArrayList<Object>();
		ArrayList<Integer> lTypes = new ArrayList();
		
		
		if (recycleStatusId != null && recycleStatusId != 0) {
			query.append("AND RECYC.RECYCLE_STAT_CD_ID = ? ");
			lParameters.add(recycleStatusId);
			lTypes.add(Types.INTEGER);
		}
		
		
		if (personDemographicsID != null && personDemographicsID != 0) {
			query.append("AND RECYC.prsn_dmgrphcs_id = ? ");
			lParameters.add(personDemographicsID);
			lTypes.add(Types.INTEGER);
		} 
		
		if (activityId != null && activityId != 0) {
			query.append("AND RECYC.ACTV_ID = ? ");
			lParameters.add(activityId);
			lTypes.add(Types.INTEGER);
		} 
		
		if (firstName != null && firstName.length() > 0) {
			query.append("AND RECYC.FIRST_NM = UPPER(?) ");
			lParameters.add(firstName);
			lTypes.add(Types.VARCHAR);
		} 
		
		if (lastName != null && lastName.length() > 0) {
			query.append("AND RECYC.LAST_NM = UPPER(?) ");
			lParameters.add(lastName);
			lTypes.add(Types.VARCHAR);
		} 
		
		if (dateOfBirth != null) {
			query.append("AND RECYC.DOB_DT = ? ");
			lParameters.add(dateOfBirth);
			lTypes.add(Types.DATE);
		} 
		
		if (activityDate != null) {
			query.append("AND TRUNC(RECYC.ACTV_DT) = ? ");
			lParameters.add(activityDate);
			lTypes.add(Types.DATE);
		} 
		
		if (recycleStatusDate != null) {
			query.append("AND TRUNC(RECYC.RECYCLE_STAT_DT) = ? ");
			lParameters.add(recycleStatusDate);
			lTypes.add(Types.DATE);
		} 
		
		if (contributionAmt != null) {
			query.append("AND TRUNC(RECYC.CONTRIB_AMT) = ? ");
			lParameters.add(contributionAmt);
			lTypes.add(Types.INTEGER);
		} 
		
		query.append("ORDER BY RECYC.LAST_NM, RECYC.FIRST_NM DESC");
		
		// Convert the parameter and types ArrayLists to arrays of primitive types. 
	    Object params[] = new Object[lParameters.size()];
	    lParameters.toArray(params);
		
	    int types[] = new int[lTypes.size()];
	    for(int j = 0; j < lTypes.size(); j++)
	    {
	    	types[j] = ((Integer)lTypes.get(j)).intValue();
	    }
		
		JdbcTemplate template = getJdbcTemplate();

		template.query(query.toString(), params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						RejectedPerson lRejectedPerson = new RejectedPerson();
						
						lRejectedPerson.setEmployerRecycleID(rs.getInt("EPR_ID"));
						lRejectedPerson.setFirstName(rs.getString("first_nm"));
						lRejectedPerson.setMiddleName(rs.getString("middle_nm"));
						lRejectedPerson.setLastName(rs.getString("last_nm"));
						lRejectedPerson.setDateOfBirth(rs.getDate("dob_dt")); 
						lRejectedPerson.setGender(rs.getString("gender_cd"));
						lRejectedPerson.setRecycleStatusCode(rs.getString("RECYCLE_STATUS"));
						lRejectedPerson.setRecycleStatusDate(rs.getDate("RECYCLE_STAT_DT"));
						lRejectedPerson.setReasonDesc(rs.getString("RSN_DESC"));
						lRejectedPerson.setApproverUserID(rs.getString("APRV_USR_ID")); 
						lRejectedPerson.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
						lRejectedPerson.setActivityID(rs.getInt("actv_id"));
						lRejectedPerson.setActivityDate(rs.getDate("ACTV_DT"));
						lRejectedPerson.setContributionAmount(rs.getInt("CONTRIB_AMT"));
						lRejectedPerson.setExternalEmployerPersonId(rs.getString("EXT_PRSN_ID"));
						lRejectedPerson.setActivityName(rs.getString("actv_nm"));
						
						results.add(lRejectedPerson);
					}
				});
		return results;
	}
	
	public final DataFieldMaxValueIncrementer getEmployerRecycleIdIncrementer() {
		return employerRecycleIdIncrementer;
	}

	public final void setEmployerRecycleIdIncrementer(
			DataFieldMaxValueIncrementer employerRecycleIdIncrementer) {
		this.employerRecycleIdIncrementer = employerRecycleIdIncrementer;
	}

	
	
	
	public void setSelectEmployerRecyclePossibleMatches(
			String selectEmployerRecyclePossibleMatches) {
		this.selectEmployerRecyclePossibleMatches = selectEmployerRecyclePossibleMatches;
	}


	public final String getInsertEmployerRecycle() {
		return insertEmployerRecycle;
	}

	public final void setInsertEmployerRecycle(String insertEmployerRecycle) {
		this.insertEmployerRecycle = insertEmployerRecycle;
	}



	public String getInsertEmployerRecycleWithContribution() {
		return insertEmployerRecycleWithContribution;
	}


	public void setInsertEmployerRecycleWithContribution(
			String insertEmployerRecycleWithContribution) {
		this.insertEmployerRecycleWithContribution = insertEmployerRecycleWithContribution;
	}

	public void setSelectEmployerRecycleWOptions(
			String selectEmployerRecycleWOptions) {
		this.selectEmployerRecycleWOptions = selectEmployerRecycleWOptions;
	}

	

}

package com.healthpartners.service.imfs.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMEmailUtility;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dao.ControlGroupIOFileDirSetupDAO;
import com.healthpartners.service.imfs.dto.ActivityExternalEmployerXref;
import com.healthpartners.service.imfs.dto.ControlGroupIOFileDirSetup;
import com.healthpartners.service.imfs.dto.EmployerActivityContributionsFileData;
import com.healthpartners.service.imfs.dto.EmployerSponsoredActivity;
import com.healthpartners.service.imfs.dto.EmployerSponsoredActivityTrailer;
import com.healthpartners.service.imfs.dto.EmployerSponsoredFile;
import com.healthpartners.service.imfs.dto.GroupActivityProgressTracker;
import com.healthpartners.service.imfs.dto.LookUpValueCode;
import com.healthpartners.service.imfs.dto.RejectedPerson;
import com.healthpartners.service.imfs.exception.BPMBusinessValidationException;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.helper.UploadEmployerActivityDataFileHelper;
import com.healthpartners.service.imfs.iface.BusinessProgramService;
import com.healthpartners.service.imfs.iface.GroupActivityProgressTrackerService;
import com.healthpartners.service.imfs.iface.LookUpValueService;
import com.healthpartners.service.imfs.iface.MemberService;
import com.healthpartners.service.imfs.iface.ProgramStatusCalculationService;
import com.healthpartners.service.imfs.iface.UploadEmployerActivityPreprocessService;
import com.healthpartners.service.imfs.rules.StatusCalculationCommand;
@Component
@Service
public class UploadEmployerActivityPreprocessServiceImpl implements UploadEmployerActivityPreprocessService {
	

	protected final Log logger = LogFactory.getLog(getClass());
	@Autowired
	private MemberService memberService;
	@Autowired
	private ProgramStatusCalculationService programStatusCalculationService;
	@Autowired
	private LookUpValueService lookUpValueService;
	@Autowired
	private GroupActivityProgressTrackerService groupActivityProgressTrackerService;
	@Autowired
	private BusinessProgramService businessProgramService;
	@Autowired
	private BPMEmailUtility bpmEmailUtility;
	@Autowired
	private ControlGroupIOFileDirSetupDAO controlGroupIOFileDirSetupDAO;
	
	private GroupActivityProgressTracker groupActivityProgressTracker;
	
	private Collection<RejectedPerson> employerSponsoredActivitiesOnHoldInErrorReycle;
	
	private String hostName;
	private String userID;
	
	private boolean ESPUpdateSwitchOn;
	
/*
 * Batch job to process employer sponsored files from Optum.  File format is csv.  Records are streamed in and validated.  Valid records are
 * written to the activity event log.  Errors are written to the employer recycle table.  A summary report is generted and sent out as an e-mail.
 */
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
			BPMBusinessValidationException.class, BPMException.class })
public void processUploadEmployerActivityPreprocessCommand(StatusCalculationCommand statusCalculationCommand) throws BPMException {
		
			logger.info("@Start - Processing Upload Employer Activity Preprocess Command. ");
			
			
			statusCalculationCommand.setCurrentCommandText("Upload Employer Activity Preprocess");
			
			//Find Employer Sponsored Activities that remain in the employer recycle table with an ON HOLD status.
			//If one or more exists, they will be reported on in summary report e-mail notification.
			Collection<RejectedPerson> lRejectedPersons = getEmployerSponsoredOnHoldRecycleRecs();
			setEmployerSponsoredActivitiesOnHoldInErrorReycle(lRejectedPersons);
			
			setHostName(statusCalculationCommand.getHostName());
			setUserID(statusCalculationCommand.getUserID());
			
			logger.info("@@@Host name is " + hostName);
			logger.info("@@@User ID is " + userID);
				
			LookUpValueCode uploadEmployerGroupLuv = null;
			Collection<LookUpValueCode> employerSponsoredUpdateSwitchLuv = null;
			//read from a group control table to get fileLocation by group.  Also, get group number.
			try {
				uploadEmployerGroupLuv = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.CNTRL_GRP_RT_TYPE, BPMConstants.UPL_EMPLOYER_SPONSORED);
				
				employerSponsoredUpdateSwitchLuv = lookUpValueService.getLUVCodesByGroup(BPMConstants.ESP_UPDATE_SWITCH);
				if (employerSponsoredUpdateSwitchLuv.iterator().next().getLuvVal().trim().equals(BPMConstants.ESP_UPDATE_ON)) {
					setESPUpdateSwitchOn(true);
				} else {
					setESPUpdateSwitchOn(false);
				}
			} catch (Exception e) {
				logger.error("Exception thrown after luv lookup: " + e.getMessage());
				throw new BPMException(e);
			}
			
			Integer routingTypeID = uploadEmployerGroupLuv.getLuvId();
			Collection<ControlGroupIOFileDirSetup> lControlGroupIOFileDirSetups = controlGroupIOFileDirSetupDAO.getControlGroupsIOFileDirSetup(routingTypeID);
			
			UploadEmployerActivityDataFileHelper lUploadEmployerActivityDataFileHelper = new UploadEmployerActivityDataFileHelper();
			Collection<ActivityExternalEmployerXref> lActivitiesExternalEmployerXref = memberService.getExternalEmployerActivityXrefAll();
			
			lUploadEmployerActivityDataFileHelper.setMemberService(memberService);
			lUploadEmployerActivityDataFileHelper.setBusinessProgramService(businessProgramService);
			lUploadEmployerActivityDataFileHelper.setActivitiesExternalEmployerXref(lActivitiesExternalEmployerXref);
			
			for (ControlGroupIOFileDirSetup lControlGroupIOFileDirSetup : lControlGroupIOFileDirSetups) {
				try {
					lUploadEmployerActivityDataFileHelper.setWellsFargo(false);
					lUploadEmployerActivityDataFileHelper.setTarget(false);
					lUploadEmployerActivityDataFileHelper.setDaikin(false);
					Collection<EmployerSponsoredFile> lEmployerSponsoredFiles = null;
					String groupNo = lControlGroupIOFileDirSetup.getGroupNo();
					String fileLocationPreprocess = lControlGroupIOFileDirSetup.getInputFileLocPreprocess();
					
					if (groupNo.equals(BPMConstants.BPM_TARGET)) {
						lUploadEmployerActivityDataFileHelper.setTarget(true);
					} else if (groupNo.equals(BPMConstants.BPM_DAIKIN)) {
							lUploadEmployerActivityDataFileHelper.setDaikin(true);
					} else if (groupNo.equals(BPMConstants.BPM_WELLSFARGO)) {
							lUploadEmployerActivityDataFileHelper.setWellsFargo(true);
					} else {
						BPMException lBPMException = new BPMException("Group control record does not map to group coded internally");
						prepareAndSendSummaryEmail(null, lControlGroupIOFileDirSetup, BPMConstants.RESULT_FAILURE, null, lBPMException);
						throw new BPMException(lBPMException);
					}
					
					//1) Read in one or more employer sponsored files.
					logger.info("processUploadEmployerActivityPreprocessCommand - Reading from file location: " + fileLocationPreprocess);
					
					lEmployerSponsoredFiles = lUploadEmployerActivityDataFileHelper.getEmployerSponsoredFiles(fileLocationPreprocess);
					
					//No file exists.
					if (lEmployerSponsoredFiles == null || lEmployerSponsoredFiles.isEmpty()) {
						//EV83985
						//prepareAndSendSummaryEmail(null, lControlGroupIOFileDirSetup, BPMConstants.RESULT_SUCCESS, null, null);
						//moveFilesFromPreprocessToProcessed(fileLocationPreprocess, fileLocationProcessed, groupNo);	
					} 
							
					for (EmployerSponsoredFile lEmployerSponsoredFile : lEmployerSponsoredFiles) {
					
						String groupFileSourceName = lEmployerSponsoredFile.getGroupFileSourceName();
						Collection<EmployerSponsoredActivity> lEmployerSponsoredActivities = lEmployerSponsoredFile.getEmployerSponsoredActivities();
						
						if (lEmployerSponsoredActivities != null && lEmployerSponsoredActivities.isEmpty()) {
							//EV83985
							//prepareAndSendSummaryEmail(null, lControlGroupIOFileDirSetup, BPMConstants.RESULT_SUCCESS, groupFileSourceName, null);
							lEmployerSponsoredFiles.clear();
							//moveFilesFromPreprocessToProcessed(fileLocationPreprocess, fileLocationProcessed, groupNo);
						} else {
						
							//2) validate and reconcile file against BPM support data.
							EmployerActivityContributionsFileData lEmployerActivityContributionsFileData  
											= lUploadEmployerActivityDataFileHelper.validateNFormatEmployerActivityContributions(lEmployerSponsoredActivities, groupNo);
							
							if (lEmployerActivityContributionsFileData.isRejectWholeFile()) {
								prepareAndSendSummaryEmail(lEmployerActivityContributionsFileData, lControlGroupIOFileDirSetup, BPMConstants.RESULT_FAILURE, groupFileSourceName, null);
							} else if (lEmployerActivityContributionsFileData.getEmployerSponsoredActivityTrailer().getRecordCount().equals("0")) {
										//EV83985
										//prepareAndSendSummaryEmail(null, lControlGroupIOFileDirSetup, BPMConstants.RESULT_SUCCESS, groupFileSourceName, null);
										//moveFilesFromPreprocessToProcessed(fileLocationPreprocess, fileLocationProcessed, groupNo);
								
							} else {
							
								//3) validate that file was not previously processed and then update to the employer activity progression tracker table.
								
								updateGroupActivityProgressionTrackerToPreProcessStatus(lEmployerActivityContributionsFileData);
								
								if (lEmployerActivityContributionsFileData.isRejectWholeFile()) {
									logger.error("File rejected: " + lEmployerActivityContributionsFileData.getRejectWholeFileReason());
									// prepare summary email and send
									prepareAndSendSummaryEmail(lEmployerActivityContributionsFileData, lControlGroupIOFileDirSetup, BPMConstants.RESULT_FAILURE, groupFileSourceName, null);
								} else {
									//4) write rejected activities to employer recycle table.
									if (lEmployerActivityContributionsFileData.getErrorRecycleMemberActivities() != null && lEmployerActivityContributionsFileData.getErrorRecycleMemberActivities().size() > 0) {
										Collection<EmployerSponsoredActivity> errorRecycleMemberActivities = lEmployerActivityContributionsFileData.getErrorRecycleMemberActivities();
										saveRejectedMemberActivitiesToEmployerRecyle(errorRecycleMemberActivities);
									}
									
									//5) write valid activities to activity event table, kick off pending activities, 
									//   and generate e-mail and summary report of what passed and what did not.
									saveUploadedValidEmployerActivities(lEmployerActivityContributionsFileData, lControlGroupIOFileDirSetup, groupFileSourceName);
									
									//6) set employer activity progression tracker table to INPROCESS to indicate that the next step of running the employer sponsored postprocess 
									//   can run.
									updateGroupActivityProgressionTrackerToInProcessStatus();
									
								}
								
								logger.info("Valid Member Activity count: " + lEmployerActivityContributionsFileData.getValidMemberActivities().size());
								logger.info("Error Recycle Member Activity count: " + lEmployerActivityContributionsFileData.getErrorRecycleMemberActivities().size());
								logger.info("Fatal Error Member Activity count: " + lEmployerActivityContributionsFileData.getFatalErrorMemberActivities().size());
																
								if (lControlGroupIOFileDirSetup.getGroupNo().equals(BPMConstants.BPM_WELLSFARGO))
								{
									prepareAndSendConfirmationEmail(
											lEmployerActivityContributionsFileData, lControlGroupIOFileDirSetup, groupFileSourceName);
								}
							}
						}
					}	
				} catch (Exception e) {
					prepareAndSendSummaryEmail(null, lControlGroupIOFileDirSetup, BPMConstants.RESULT_FAILURE, null, e);
					throw new BPMException(e);
				} 
			}
			
			
			
	}
	
	/**
	 * @return
	 * @throws DataAccessException
	 * @throws BPMException
	 */
	private String saveUploadedValidEmployerActivities(
			EmployerActivityContributionsFileData lEmployerActivityContributionsFileData, ControlGroupIOFileDirSetup lControlGroupIOFileDirSetup, String groupFileSourceName) throws BPMException {
		String resultPage = BPMConstants.RESULT_SUCCESS;
		ActionMessages messages = new ActionMessages();
		try {
		
			if (lEmployerActivityContributionsFileData == null) {
				
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage(
						"session.expired", "Possible file not available for processing."));
				resultPage = BPMConstants.RESULT_FAILURE;
			} else {
				Collection<Integer> totalInserts = null;
				int totalInsertsCt = 0;
				
				// insert employer administered activities
				if (isESPUpdateSwitchOn()) {
				   logger.info("Employer Sponsored Update switch is ON.");
				   totalInserts = memberService
						   .insertEmployerAdministeredActivities(lEmployerActivityContributionsFileData);
				   totalInsertsCt = totalInserts.size();
				} else {
					logger.info("Employer Sponsored Update switch is OFF.");
					totalInsertsCt = lEmployerActivityContributionsFileData.getValidMemberActivities().size();
				}
				
				if (totalInsertsCt > 0) {

					messages.add(ActionMessages.GLOBAL_MESSAGE,
							new ActionMessage("messages.batchjob.started",
									"Pending Activities"));

					// prepare summary email and send
					prepareAndSendSummaryEmail(lEmployerActivityContributionsFileData, lControlGroupIOFileDirSetup, resultPage, groupFileSourceName, null);

					// add success message to display
					messages.add(ActionMessages.GLOBAL_MESSAGE,
							new ActionMessage("messages.info",
									"Successfully added employer sponsored member activities '"
											+ totalInsertsCt + "'"));
					
					int employerRecycleRecsWrittenCt = 0;
					
					if (lEmployerActivityContributionsFileData.getErrorRecycleMemberActivities() != null) {
						employerRecycleRecsWrittenCt = lEmployerActivityContributionsFileData.getErrorRecycleMemberActivities().size();
					}
					
					messages.add(ActionMessages.GLOBAL_MESSAGE,
							new ActionMessage("messages.info",
									"Invalid and incomplete person activities written '" + employerRecycleRecsWrittenCt + 
									"' to the Employer Recycle table for further review'"));
					messages.add(ActionMessages.GLOBAL_MESSAGE,
							new ActionMessage("messages.info",
									"Go to Person Employer Activity Recycle (Review) to reconcile"));
											
				}
				resultPage = BPMConstants.RESULT_SUCCESS;
			}
			

		} catch (Exception e) {
			System.out.println("Error: Called saveUploadedValidEmployerActivities error. Exception is " + e);
			throw new BPMException(e);
		}

		return resultPage;
	}
	
	/*
	 * Validate that file is not a duplicate and then update to the group activity progression tracking table.
	 */
	private void updateGroupActivityProgressionTrackerToPreProcessStatus(EmployerActivityContributionsFileData lEmployerActivityContributionsFileData) throws Exception {
		
		try {
			if (lEmployerActivityContributionsFileData.getValidMemberActivities().size() > 0 && isESPUpdateSwitchOn()) {
				GroupActivityProgressTracker lGroupActivityProgressTracker = buildGroupActivityProgressTracker(lEmployerActivityContributionsFileData);	
				setGroupActivityProgressTracker(lGroupActivityProgressTracker);
				//Check to see if file was already processed.
				if (isFileAlreadyProcessed(lGroupActivityProgressTracker)) {
					String errorReason = "ERROR:  File determined to already be processed and flagged with a POSTPROCESS status.";
					logger.error(errorReason);
					//setting flag to object is pass by reference.
					lEmployerActivityContributionsFileData.setRejectWholeFile(true);
					lEmployerActivityContributionsFileData.setPostProcessState(true);
					lEmployerActivityContributionsFileData.setRejectWholeFileReason("File determined to already be processed.");
					
				} else if (isFileINProcessState(lGroupActivityProgressTracker)) {
						String errorReason = "ERROR:  File determined to be inprocess flagged with an INPROCESS status.";
						logger.error(errorReason);
						//setting flag to object is pass by reference.
						lEmployerActivityContributionsFileData.setRejectWholeFile(true);
						lEmployerActivityContributionsFileData.setINProcessState(true);
						lEmployerActivityContributionsFileData.setRejectWholeFileReason("File determined to already be processed.");
				} else {
				
					lGroupActivityProgressTracker.setTrackingStatusCode(BPMConstants.UPL_EMPL_PREPROCESS_STATUS);
					groupActivityProgressTrackerService.updateGroupActivityProgressionTracker(lGroupActivityProgressTracker, BPMConstants.BPM_USER_SYSTEM);
				}
				
				
			}
		} catch (Exception e) {
			throw e;
		}
	}
	
	/*
	 * update to the group activity progression tracking table with a status of INPROCESS.  This will allow the employer sponsored postprocess reporting job to run.
	 */
	private void updateGroupActivityProgressionTrackerToInProcessStatus() throws Exception {
		
		try {
			
			if (isESPUpdateSwitchOn()) {
				groupActivityProgressTracker.setTrackingStatusCode(BPMConstants.UPL_EMPL_INPROCESS_STATUS);
				groupActivityProgressTrackerService.updateGroupActivityProgressionTracker(groupActivityProgressTracker, BPMConstants.BPM_USER_SYSTEM);
			}
					
			
		} catch (Exception e) {
			throw e;
		}
	}
	
	
	
	private boolean isFileAlreadyProcessed(GroupActivityProgressTracker lGroupActivityProgressTracker) {
		boolean isFileAlreadyProcessed = false;
		
		try {
			isFileAlreadyProcessed = groupActivityProgressTrackerService.isFileAlreadyProcessed(lGroupActivityProgressTracker);
		} catch (Exception e) {
			logger.error("Error encountered after groupActivityProgressTrackerService.isFileAlreadyProcessed call");
			logger.error("Message is " + e.getMessage());
			return isFileAlreadyProcessed;
		}
		
		return isFileAlreadyProcessed;
		
	}
	
	private void saveRejectedMemberActivitiesToEmployerRecyle(Collection<EmployerSponsoredActivity> errorRecycleMemberActivities) throws DataAccessException, BPMException {
		 
		if (errorRecycleMemberActivities != null && errorRecycleMemberActivities.size() > 0) {
			Iterator<EmployerSponsoredActivity> errorRecycleMemberActivitiesIter = (Iterator<EmployerSponsoredActivity>) errorRecycleMemberActivities.iterator();
			while (errorRecycleMemberActivitiesIter.hasNext()) {
				EmployerSponsoredActivity employerActivity = (EmployerSponsoredActivity)errorRecycleMemberActivitiesIter.next();
				if (employerActivity.getReasonDesc() == null) {
					employerActivity.setReasonDesc("No member match.");
				}
				
				if (isESPUpdateSwitchOn()) {
					Collection<RejectedPerson> lRejectedPersons = null;
					try {
						//if activity previously rejected don't add another in case same input file run multiple times.
				    					    	
				    	java.sql.Date activityDate = BPMUtils.convertStringToSqlDate(employerActivity.getActivityDate(), BPMConstants.HP_BPM_COMMON_DATE_FORMAT);
				    	java.sql.Date dateOfBirth = BPMUtils.convertStringToSqlDate(employerActivity.getDateOfBirth(), BPMConstants.HP_BPM_COMMON_DATE_FORMAT);
				    	
					    lRejectedPersons = 
									businessProgramService.getEmployerRecycle(employerActivity.getActivityID(), employerActivity.getFirstName(), employerActivity.getLastName(), dateOfBirth, activityDate, null, null, null, Integer.valueOf(employerActivity.getAmountEarned()));
				    	
				    	
				   	} catch (Exception e) {
				    		throw new BPMException("buildRejectedPersonRec caught exception reading person ID - Exception follows: " + e);
				   	}
					
					if (lRejectedPersons == null || lRejectedPersons.isEmpty()) {
						RejectedPerson pRejectedPerson = buildRejectedPersonRec(employerActivity);
						businessProgramService.insertEmployerRecycleWithContribution(pRejectedPerson, BPMConstants.BPM_USER_SYSTEM);
					}
				}
			}
		}
		
		
	}
	
	
	private GroupActivityProgressTracker buildGroupActivityProgressTracker(EmployerActivityContributionsFileData lEmployerActivityContributionsFileData)  throws Exception {
		
		GroupActivityProgressTracker lGroupActivityProgressTracker = new GroupActivityProgressTracker();
		
		EmployerSponsoredActivityTrailer employerSponsoredActivityTrailer = lEmployerActivityContributionsFileData.getEmployerSponsoredActivityTrailer();
		
		java.sql.Date batchDate = BPMUtils.formatDateMMddyyyy(employerSponsoredActivityTrailer.getDateSent());
		lGroupActivityProgressTracker.setGroupNo(lEmployerActivityContributionsFileData.getGroupNo());
		lGroupActivityProgressTracker.setGroupName(lEmployerActivityContributionsFileData.getGroupName());
		lGroupActivityProgressTracker.setBatchDate(batchDate);
		lGroupActivityProgressTracker.setInputFileName(employerSponsoredActivityTrailer.getGroupFileSourceName());
		lGroupActivityProgressTracker.setPreprocessAmount(employerSponsoredActivityTrailer.getTotalAmount());
		lGroupActivityProgressTracker.setPreprocessCount(Integer.valueOf(employerSponsoredActivityTrailer.getRecordCount()));
		
		LookUpValueCode lLookupValueCode = null;
		try {
			lLookupValueCode = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.UPL_EMPL_TRACK_STAT_GROUP, BPMConstants.UPL_EMPL_PREPROCESS_STATUS);
		} catch (Exception e) {
			logger.error("Attempt made to read for the preprocess status record but failed when trying to build out a GroupActivityProgressTracker record");
			throw e;
		}
		
		lGroupActivityProgressTracker.setTrackingStatusID(lLookupValueCode.getLuvId());
		
		
		return lGroupActivityProgressTracker;
		
	}
	
	
	/**
	 * prepare and send summary email
	 * 
	 * @param employerActivities
	 */
	private void prepareAndSendSummaryEmail(
			EmployerActivityContributionsFileData employerActivities, ControlGroupIOFileDirSetup lControlGroupIOFileDirSetup, String resultPage, String groupFileSourceName, Exception exception) {
		String emailServerHost = null;
		String emailFromAddress = null;
		String dbEnvirnment = "";
		List<String> emailToAddress = new ArrayList<String>();
		StringBuffer emailContent = new StringBuffer();
		StringBuffer emailSubject = new StringBuffer();
		java.util.Date startDate = new java.util.Date();
		LookUpValueCode toAddress = null;
		
		logger.info("prepareAndSendSummaryEmail called ...");
		try {

			Collection<LookUpValueCode> serverHost = lookUpValueService
					.getLUVCodesByGroup(BPMConstants.BPM_EMAIL_HOST_SRVR);
			Collection<LookUpValueCode> fromAddress = lookUpValueService
					.getLUVCodesByGroup(BPMConstants.BPM_EMAIL_FROM_ADDR);
			
			if (lControlGroupIOFileDirSetup.getGroupNo().equals(BPMConstants.BPM_WELLSFARGO)) {
				toAddress = lookUpValueService
						.getLUVCodeByGroupNValue(BPMConstants.EMPL_SPONSORED_TO_ADDR, BPMConstants.EMPL_SPONSORED_TO_WELLSFARGO);
			} else if (lControlGroupIOFileDirSetup.getGroupNo().equals(BPMConstants.BPM_TARGET)) {
				toAddress = lookUpValueService
						.getLUVCodeByGroupNValue(BPMConstants.EMPL_SPONSORED_TO_ADDR, BPMConstants.EMPL_SPONSORED_TO_TARGET);
			} else if (lControlGroupIOFileDirSetup.getGroupNo().equals(BPMConstants.BPM_DAIKIN)) {
				toAddress = lookUpValueService
						.getLUVCodeByGroupNValue(BPMConstants.EMPL_SPONSORED_TO_ADDR, BPMConstants.EMPL_SPONSORED_TO_DAIKIN);
			} 
			
			Collection<LookUpValueCode> dbEnvirnments = lookUpValueService
					.getLUVCodesByGroup(BPMConstants.BPM_DB_ENV);

			// email server host
			Iterator<LookUpValueCode> itrHost = serverHost.iterator();
			if (itrHost.hasNext()) {
				LookUpValueCode lvalue = itrHost.next();
				emailServerHost = lvalue.getLuvDesc();
			}

			// from address
			Iterator<LookUpValueCode> itrTo = fromAddress.iterator();
			if (itrTo.hasNext()) {
				LookUpValueCode lvalue = itrTo.next();
				emailFromAddress = lvalue.getLuvDesc();
			}

			// to address
			if(toAddress != null){
				emailToAddress.add(toAddress.getLuvDesc());
			}

			Iterator<LookUpValueCode> itrEnv = dbEnvirnments.iterator();
			while (itrEnv.hasNext()) {
				LookUpValueCode lvalue = itrEnv.next();
				dbEnvirnment = lvalue.getLuvDesc();
				break;
			}

			// prepare summary email body
			if (isESPUpdateSwitchOn()) {
				emailSubject
						.append("BPM Batch - PreProcess " + lControlGroupIOFileDirSetup.getGroupName() + " Upload Employer Sponsored (ESP) Activities Update - " + resultPage); 
			} else {
				emailSubject
				.append("BPM Batch - PreProcess " + lControlGroupIOFileDirSetup.getGroupName() + " Upload Employer Sponsored (ESP) Activities Update - ATTENTION: UPDATE FLAG DISABLED FOR THIS RUN!!!"); 
			}
			
			emailContent.append("<table>");
			if (isESPUpdateSwitchOn()) {
				emailContent.append("<tr><td>Employer Sponsored Activities Update PreProcess</td></tr>");
			} else {
				emailContent.append("<tr><td>Employer Sponsored Activities Update PreProcess - UPDATE FLAG HAS BEEN DISABLED FOR THIS RUN.</td></tr>");
			}

			emailContent.append("<tr><td colspan=2>Purpose: To automate the update process for Employer Sponsored activities sent from Vendor</td></tr>");
			emailContent.append("<tr><td>Database Environment:</td>");
			emailContent.append("<td>" + dbEnvirnment + "</td></tr>");
			if (groupFileSourceName != null) {
				emailContent.append("<tr><td>CSV Input File:</td>");
				emailContent.append("<td>" + groupFileSourceName + "</td></tr>");
			} else {
				emailContent.append("<tr><td>CSV Input File:</td>");
				emailContent.append("<td>" + "Not Available" + "</td></tr>");
			}
			emailContent.append("<tr><td>Application Server:</td>");
			emailContent.append("<td>" + hostName + "</td></tr>");
			emailContent.append("<tr><td>Group Description:</td><td> "
					+ lControlGroupIOFileDirSetup.getGroupNo() + " - " + lControlGroupIOFileDirSetup.getGroupName() + "</td></tr>");
			
			
			emailContent.append("<tr><td>Initiated User:</td><td> "
					+ userID + "</td></tr>");
			emailContent.append("<tr><td>Time Start:</td><td> "
					+ BPMUtils.getFormattedDateTime(startDate)
					+ "</td></tr>");
			
			if (exception != null) {
				emailContent
				.append("<tr><td></td><td></tr>");
				emailContent
				.append("<tr><td></td><td></tr>");
				emailContent
				.append("<tr><td>ERROR DETECTED IN FILE: " + exception.toString()
						+ "</td></tr>");
				emailContent
				.append("<tr><td></td><td></tr>");
				emailContent
				.append("<tr><td></td><td></tr>");
			
			} else if (employerActivities == null) {
				emailContent
				.append("<tr><td></td><td></tr>");
				emailContent
				.append("<tr><td></td><td></tr>");
				emailContent
				.append("<tr><td>ATTENTION: No Employer Sponsored Activity Files to process today!"
						+ "</td></tr>");
				emailContent
				.append("<tr><td></td><td></tr>");
				emailContent
				.append("<tr><td></td><td></tr>");
			} else if (employerActivities.isRejectWholeFile() && employerActivities.isINProcessState()) {
				emailContent
				.append("<tr><td></td><td></tr>");
				emailContent
				.append("<tr><td></td><td></tr>");
				emailContent
				.append("<tr><td colspan=2>ATTENTION: Whole file has been rejected because input file is in a INPROCESS State."
						+ "</td></tr>");
				emailContent
				.append("<tr><td></td><td></tr>");
				emailContent
				.append("<tr><td></td><td></tr>");
			} else if (employerActivities.isRejectWholeFile() && employerActivities.isPostProcessState()) {
				emailContent
				.append("<tr><td></td><td></tr>");
				emailContent
				.append("<tr><td></td><td></tr>");
				emailContent
				.append("<tr><td colspan=2>ATTENTION: Whole file has been rejected because input file is in a POSTPROCESS State."
						+ "</td></tr>");
				emailContent
				.append("<tr><td></td><td></tr>");
				emailContent
				.append("<tr><td></td><td></tr>");
			} else if (employerActivities.isRejectWholeFile()) {
				emailContent
				.append("<tr><td></td><td></tr>");
				emailContent
				.append("<tr><td></td><td></tr>");
				emailContent
				.append("<tr><td colspan=2>ATTENTION: Whole file has been rejected.  See list of invalid member activities. "
						+ "</td></tr>");
				emailContent
				.append("<tr><td>Either fix the file or have it resent from Vendor.</td><td> "
						+ "</tr>");
				emailContent
				.append("<tr><td></td><td></tr>");
				emailContent
				.append("<tr><td></td><td></tr>");
			} 
			emailContent.append("</table>");
			
			if (employerActivities != null) {
				appendSummaryDetail(emailContent, employerActivities);
			}
			
			logger.info("bpmEmailUtility.sendEmail called ...");
			bpmEmailUtility.sendEmail(emailServerHost, emailFromAddress,
					emailToAddress, emailSubject.toString(), emailContent.toString(),
					bpmEmailUtility.EMAIL_CONTENT_TYPE_HTML, null);
		
			logger.info("bpmEmailUtility.sendEmail returned ...");

		} catch (Exception e) {
			logger.error(
					"Error occurred sending Employer Sponsored activities update status email: "
							+ e.getMessage(), e);
			logger.error("  emailToAddress=" + emailToAddress);
			logger.error("  emailFromAddress=" + emailFromAddress);
			logger.error("  emailSubject=" + emailSubject.toString());
			logger.error("  emailContent=" + emailContent.toString());
		}
	}
	
	private void appendSummaryDetail(StringBuffer emailContent, EmployerActivityContributionsFileData employerActivities) {
		emailContent.append("<table>");
		emailContent
				.append("<tr><td>Number of Member Activity Lines in data file:</td><td> "
						+ employerActivities
								.getTotalNumberOfMemberActivityLines()
						+ "</td></tr>");
		emailContent
				.append("<tr><td>Number of Valid Member Activities:</td><td> "
						+ employerActivities.getValidMemberActivityCount()
						+ "</td></tr>");
		emailContent
				.append("<tr><td>Number of Member Activities flagged with one or more errors:</td><td>"
						+ employerActivities
								.getFatalErrorMemberActivityCount()
						+ "</td></tr>");
		emailContent
				.append("<tr><td>Number of Member Activities flagged for error recycle:</td><td>"
						+ employerActivities
								.getErrorRecycleMemberActivityCount()
						+ "</td></tr>");
		
		//For future use.
		/*emailContent
		.append("<tr><td>Number of Member Activities with prior year activity dates overridden with file date:</td><td>"
				+ employerActivities
						.getPreviousYearActivitiesOverriddenMemberActivityCount()
				+ "</td></tr>"); */
		
		emailContent.append("</table>");
	
		//may or may not want to show the valid activities in the summary report.  Commented out for now.
		//buildEmailContentForValidActivites(emailContent, employerActivities);
		
		buildEmailContentForFatalErrors(emailContent, employerActivities);
		
		buildEmailContentForErrorRecycle(emailContent, employerActivities);
		
		buildEmailContentForErrorRecycleOnHold(emailContent, employerActivities);
		
	}
	
	private void buildEmailContentForValidActivites(StringBuffer emailContent, EmployerActivityContributionsFileData employerActivities) {
		
		// valid activities processed
		emailContent.append("<br><br><table>");
		emailContent
				.append("<tr><td>***************************************************************************</td></tr>");
		if (employerActivities.isRejectWholeFile()) {
			emailContent
					.append("<tr><td>Valid Member Activity(s) (No records were written to Activity Event Log due to fatal errors detected)</td></tr>");
			emailContent
					.append("<tr><td>***************************************************************************</td></tr>");
		} else {
			emailContent
					.append("<tr><td>Valid Member Activity(s) Added to Activity Event Log</td></tr>");
			emailContent
					.append("<tr><td>***************************************************************************</td></tr>");
		}
		emailContent.append("</table>");
		emailContent.append("<table>");
		
		if (employerActivities
				.getValidMemberActivities().size() > 0) {
			
			emailContent.append("<tr><td> Line</td><td>MemberID</td><td>First Name</td><td>MI</td><td>Last Name</td><td>DOB</td><td>Gender</td><td>PersonID</td><td>Activity Name</td><td>Activity Date</td><td>Amount</td></tr>");
					
			Iterator<EmployerSponsoredActivity> itrValAct = employerActivities
					.getValidMemberActivities().iterator();
			int lineNbr = 1;
			while (itrValAct.hasNext()) {
				EmployerSponsoredActivity empActivity = itrValAct.next();
				emailContent
				.append("<tr><td colspan=12>---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
				emailContent.append("<tr><td> "
						+ lineNbr + "</td><td>"
						+ empActivity.getMemberID() + "</td><td>"
						+ empActivity.getFirstName() + "</td><td>" 
						+ empActivity.getMiddleName() + "</td><td>" 
						+ empActivity.getLastName() + "</td><td>" 
						+ empActivity.getDateOfBirth() + "</td><td>" 
						+ empActivity.getGender() + "</td><td>" 
						+ empActivity.getPersonID() + "</td><td>" 
						+ empActivity.getActivityName() + "</td><td>"
						+ empActivity.getActivityDate() + "</td><td>$" 
						+ empActivity.getAmountEarned() + 	
						"</td></tr>");
				lineNbr++;
			}
		}
		emailContent.append("</table>");
	}
	
	private void buildEmailContentForFatalErrors(StringBuffer emailContent, EmployerActivityContributionsFileData employerActivities) {
		
	
		// Error Recycle activities not processed
		emailContent.append("<br><br><table>");
		
		emailContent
		.append("<tr><td>*********************************************************************************</td></tr>");
		if (employerActivities.getFatalErrorMemberActivities().size() > 0) {
			emailContent
						.append("<tr><td>Member Activity Lines flagged with fatal errors. (Whole file rejected)</td></tr>");
			emailContent
			.append("<tr><td>*********************************************************************************</td></tr>");
			emailContent.append("</table>");
			
		} 
		
		
		if (employerActivities
				.getFatalErrorMemberActivities().size() > 0) {
			emailContent.append("<table>");
			emailContent.append("<tr><td> Line</td><td>External MemberID</td><td>First Name</td><td>MI</td><td>Last Name</td><td>DOB</td><td>Gender</td><td>PersonID</td><td>Activity Name</td><td>Activity Date</td><td>Amount</td><td>Error reason</td></tr>");
			Iterator<EmployerSponsoredActivity> itrInvalAct = employerActivities
					.getFatalErrorMemberActivities().iterator();
			int lineNbr = 1;
			String externalMemberID;
			while (itrInvalAct.hasNext()) {
				EmployerSponsoredActivity empActivity = itrInvalAct.next();
				if (empActivity.getAlternateMemberID() != null) {
					externalMemberID = empActivity.getAlternateMemberID();
				} else {
					externalMemberID = "N/A";
				}
				emailContent
				.append("<tr><td colspan=13>-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
				emailContent.append("<tr><td> "
						+ lineNbr + "</td><td>"
						+ externalMemberID + "</td><td>"
						+ empActivity.getFirstName() + "</td><td>" 
						+ empActivity.getMiddleName() + "</td><td>" 
						+ empActivity.getLastName() + "</td><td>" 
						+ empActivity.getDateOfBirth() + "</td><td>" 
						+ empActivity.getGender() + "</td><td>" 
						+ empActivity.getPersonID() + "</td><td>" 
						+ empActivity.getActivityName() + "</td><td>"
						+ empActivity.getActivityDate() + "</td><td>$" 
						+ empActivity.getAmountEarned() + "</td><td>" 	
						+ empActivity.getReasonDesc() + 	
						"</td></tr>");
				lineNbr++;
			}
		} else {
			emailContent
			.append("<tr><td>No Member Activity Lines flagged with fatal errors to report.</td></tr>");
			emailContent
			.append("<tr><td>*********************************************************************************</td></tr>");
		}
		
		
		emailContent.append("</table>");
	}
	
	private void buildEmailContentForErrorRecycle(StringBuffer emailContent, EmployerActivityContributionsFileData employerActivities) {
		
		emailContent.append("<table>");
		// Error Recycle activities not processed
		emailContent.append("<br><br><table>");
		
		if (employerActivities.isRejectWholeFile()) {
			emailContent
			.append("<tr><td>****************************************************************************************************************************************</td></tr>");
			emailContent
					.append("<tr><td>Member Activity Lines flagged for error recycle (No records written to error recycle since whole file has to be reprocessed)</td></tr>");
			emailContent
			.append("<tr><td>****************************************************************************************************************************************</td></tr>");
			emailContent.append("</table>");
		} else if (employerActivities
					.getErrorRecycleMemberActivities().size() > 0) {
				emailContent.append("<table>");
				emailContent
					.append("<tr><td>****************************************************************************************************************************************</td></tr>");
				emailContent
					.append("<tr><td>Member Activity Lines flagged for error recycle (Records written to error recycle)</td></tr>");
				emailContent
					.append("<tr><td>****************************************************************************************************************************************</td></tr>");
				emailContent.append("</table>");
				emailContent.append("<table>");
				emailContent.append("<tr><td> Line</td><td>External MemberID</td><td>First Name</td><td>MI</td><td>Last Name</td><td>DOB</td><td>Gender</td><td>PersonID</td><td>Activity Name</td><td>Activity Date</td><td>Amount</td><td>Error reason</td></tr>");
				
				Iterator<EmployerSponsoredActivity> itrInvalAct = employerActivities
						.getErrorRecycleMemberActivities().iterator();
				int lineNbr = 1;
				String externalMemberID;
				while (itrInvalAct.hasNext()) {
					EmployerSponsoredActivity empActivity = itrInvalAct.next();
					if (empActivity.getAlternateMemberID() != null) {
						externalMemberID = empActivity.getAlternateMemberID();
					} else {
						externalMemberID = "N/A";
					}
					emailContent
					.append("<tr><td colspan=13>-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
					emailContent.append("<tr><td> "
							+ lineNbr + "</td><td>"
							+ externalMemberID + "</td><td>"
							+ empActivity.getFirstName() + "</td><td>" 
							+ empActivity.getMiddleName() + "</td><td>" 
							+ empActivity.getLastName() + "</td><td>" 
							+ empActivity.getDateOfBirth() + "</td><td>" 
							+ empActivity.getGender() + "</td><td>" 
							+ empActivity.getPersonID() + "</td><td>" 
							+ empActivity.getActivityName() + "</td><td>"
							+ empActivity.getActivityDate() + "</td><td>$" 
							+ empActivity.getAmountEarned() + "</td><td>" 	
							+ empActivity.getReasonDesc() + 	
							"</td></tr>");
					lineNbr++;
				}
				emailContent.append("</table>");
		} else {
			emailContent
			.append("<tr><td>****************************************************************************************************************************************</td></tr>");
				emailContent
					.append("<tr><td>No Member Activity Lines flagged for error recycle to report.</td></tr>");
				emailContent
					.append("<tr><td>****************************************************************************************************************************************</td></tr>");
		}
		
	}
	
	private void buildEmailContentForErrorRecycleOnHold(StringBuffer emailContent, EmployerActivityContributionsFileData employerActivities) {
	
	
		emailContent.append("<table>");
		emailContent
		.append("<tr><td> </td></tr>");
		emailContent
		.append("<tr><td> </td></tr>");
		emailContent.append("</table>");
		emailContent.append("<table>");
		if (employerSponsoredActivitiesOnHoldInErrorReycle != null && employerSponsoredActivitiesOnHoldInErrorReycle.size() > 0) {
			
			emailContent
			.append("<tr><td>*********************************************************************************</td></tr>");
			emailContent
			.append("<tr><td>Employer Sponsored Activities ON HOLD in recycle table:</td></tr>");
			emailContent
			.append("<tr><td>*********************************************************************************</td></tr>");
			emailContent.append("</table>");
			emailContent.append("<table>");
			emailContent.append("<tr><td> Line</td><td>MemberID</td><td>First Name</td><td>MI</td><td>Last Name</td><td>DOB</td><td>Gender</td><td>Activity Name</td><td>Activity Date</td><td>Amount</td><td>Reason Desc</td></tr>");
			
			
			Iterator<RejectedPerson> itrOnHold = employerSponsoredActivitiesOnHoldInErrorReycle.iterator();
			int lineNbr = 1;
			
			while (itrOnHold.hasNext()) {
				RejectedPerson lRejectedPerson = itrOnHold.next();
				emailContent
				.append("<tr><td colspan=12>---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
				emailContent.append("<tr><td> "
						+ lineNbr + "</td><td>"
						+ lRejectedPerson.getMemberNo() + "</td><td>"
						+ lRejectedPerson.getFirstName() + "</td><td>" 
						+ lRejectedPerson.getMiddleName() + "</td><td>" 
						+ lRejectedPerson.getLastName() + "</td><td>" 
						+ lRejectedPerson.getDateOfBirth() + "</td><td>" 
						+ lRejectedPerson.getGender() + "</td><td>" 
						+ lRejectedPerson.getActivityName() + "</td><td>"
						+ lRejectedPerson.getActivityDate() + "</td><td>$" 
						+ lRejectedPerson.getContributionAmount() + "</td><td>" 	
						+ lRejectedPerson.getReasonDesc() + 	
						"</td></tr>");
				lineNbr++;
			}
		} else {
				emailContent
				.append("<tr><td>*********************************************************************************</td></tr>");
				emailContent
				.append("<tr><td>No Employer Sponsored Activities ON HOLD in recycle table to report.</td></tr>");
				emailContent
				.append("<tr><td>*********************************************************************************</td></tr>");
			
		}
	
	emailContent.append("</table>");
	
	}
	
	private RejectedPerson buildRejectedPersonRec(EmployerSponsoredActivity employerActivity) throws BPMException {
	    RejectedPerson rejectedPerson = new RejectedPerson();
	    
	    if (employerActivity.getActivityID() != null) {
	    	rejectedPerson.setActivityID(employerActivity.getActivityID());
	    }
	    if (employerActivity.getFirstName() != null) {
	    	rejectedPerson.setFirstName(employerActivity.getFirstName());
	    }
	    if (employerActivity.getMiddleName() != null) {
	    	rejectedPerson.setMiddleName(employerActivity.getMiddleName());
	    }
	    if (employerActivity.getLastName() != null) {
	    	rejectedPerson.setLastName(employerActivity.getLastName());
	    }
	    if (employerActivity.getDateOfBirth() != null) {
	    	java.sql.Date sqlDate = BPMUtils.getSqlDateFromString(employerActivity.getDateOfBirth());
	    	rejectedPerson.setDateOfBirth(sqlDate);
	    }
	    if (employerActivity.getGender() != null) {
	    	rejectedPerson.setGender(employerActivity.getGender());
	    }
	    if (employerActivity.getMemberID() != null) {
	    	try {
	    	Integer personDemographicsID = memberService.getPersonID(employerActivity.getMemberID());
	    	rejectedPerson.setPersonDemographicsID(personDemographicsID);
	    	} catch (Exception e) {
	    		throw new BPMException("buildRejectedPersonRec caught exception reading person ID - Exception follows: " + e);
	    	}
	    }
	    
	    if (employerActivity.getSourceActivityID() != null) {
	    	rejectedPerson.setSourceActivityID(employerActivity.getSourceActivityID());
	    }
	    
	    if (employerActivity.getActivityName() != null) {
	    	rejectedPerson.setActivityName(employerActivity.getActivityName());
	    }
	   
	    if (employerActivity.getActivityDate() != null) {
	    	rejectedPerson.setActivityDate(BPMUtils.convertStringToSqlDate(employerActivity.getActivityDate(), BPMConstants.HP_BPM_COMMON_DATE_FORMAT));
	    }
	    
	    if (employerActivity.getAmountEarned() != null) {
	    	rejectedPerson.setContributionAmount(Integer.valueOf(employerActivity.getAmountEarned()));
	    }
	    
	    if (employerActivity.getReasonDesc() != null) {
	    	rejectedPerson.setReasonDesc(employerActivity.getReasonDesc());
	    }
	    
	    rejectedPerson.setRecycleStatusCode(BPMConstants.BPM_EMPL_RECYCLE_STATUS_ON_HOLD);
	    
	    return rejectedPerson;
	    
	}
	
	/*private void moveFilesFromPreprocessToProcessed(String fileLocationPreprocess, String fileLocationProcessed, String groupNo) throws BPMException {
		
		logger.info("Move file for group " + groupNo + fileLocationPreprocess + " to " + fileLocationProcessed);
		BPMUtils.moveFiles(fileLocationPreprocess, fileLocationProcessed);
			
	}*/
	
	private  Collection<RejectedPerson> getEmployerSponsoredOnHoldRecycleRecs() throws BPMException {
			LookUpValueCode employerRecycleGroupLuv = null;
			Collection<LookUpValueCode> employerSponsoredUpdateSwitchLuv = null;
			//read from a group control table to get fileLocation by group.  Also, get group number.
			try {
				employerRecycleGroupLuv = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.BPM_EMPL_RECYCLE_STATUS, BPMConstants.BPM_EMPL_RECYCLE_STATUS_ON_HOLD);
			} catch (Exception e) {
				logger.error("Exception thrown after luv lookup: " + e.getMessage());
				throw new BPMException(e);
			}
			
			Integer recycleStatusID = employerRecycleGroupLuv.getLuvId();
			Collection<RejectedPerson> lRejectedPersons = 
					businessProgramService.getEmployerRecycle(null, null, null, null, null, null, recycleStatusID, null, null);
			
			return lRejectedPersons;
	}
	
	private boolean isFileINProcessState(GroupActivityProgressTracker lGroupActivityProgressTracker) {
		boolean isFileINProcess = false;
		
		
		try {
			isFileINProcess = groupActivityProgressTrackerService.isFileINProcess(groupActivityProgressTracker);
		} catch (Exception e) {
			logger.error("Error encountered after groupActivityProgressTrackerService.isFileINProcess call");
			logger.error("Message is " + e);
			return isFileINProcess;
		}
		
		return isFileINProcess;
		
	}
	
	
	private void prepareAndSendConfirmationEmail(
			EmployerActivityContributionsFileData employerActivities, ControlGroupIOFileDirSetup lControlGroupIOFileDirSetup, String groupFileSourceName) {
		String emailServerHost = null;
		String emailFromAddress = null;		
		List<String> emailToAddress = new ArrayList<String>();
		StringBuffer emailContent = new StringBuffer();
		StringBuffer emailSubject = new StringBuffer();
		java.util.Date startDate = new java.util.Date();
		LookUpValueCode toAddress = null;
		
		logger.info("prepareAndSendConfirmationEmail called ...");
		try {

			Collection<LookUpValueCode> serverHost = lookUpValueService
					.getLUVCodesByGroup(BPMConstants.BPM_EMAIL_HOST_SRVR);
			Collection<LookUpValueCode> fromAddress = lookUpValueService
					.getLUVCodesByGroup(BPMConstants.BPM_EMAIL_FROM_ADDR);
			
			emailSubject.append(lControlGroupIOFileDirSetup.getGroupName());
			
			if (lControlGroupIOFileDirSetup.getGroupNo().equals(BPMConstants.BPM_WELLSFARGO)) {
				toAddress = lookUpValueService
						.getLUVCodeByGroupNValue(BPMConstants.EMPL_SPNSRED_CONFRM, BPMConstants.EMPL_SPNSRED_WELLSFARGO);
			
				emailSubject.append(" Wells Fargo Optum Incentive File Confirmation ");
				
			} 
			else if (lControlGroupIOFileDirSetup.getGroupNo().equals(BPMConstants.BPM_TARGET)) {
				toAddress = lookUpValueService
						.getLUVCodeByGroupNValue(BPMConstants.EMPL_SPONSORED_TO_ADDR, BPMConstants.EMPL_SPONSORED_TO_TARGET);
			} else if (lControlGroupIOFileDirSetup.getGroupNo().equals(BPMConstants.BPM_DAIKIN)) {
				toAddress = lookUpValueService
						.getLUVCodeByGroupNValue(BPMConstants.EMPL_SPONSORED_TO_ADDR, BPMConstants.EMPL_SPONSORED_TO_DAIKIN);
			}
						

			// email server host
			Iterator<LookUpValueCode> itrHost = serverHost.iterator();
			if (itrHost.hasNext()) {
				LookUpValueCode lvalue = itrHost.next();
				emailServerHost = lvalue.getLuvDesc();
			}

			// from address
			Iterator<LookUpValueCode> itrTo = fromAddress.iterator();
			if (itrTo.hasNext()) {
				LookUpValueCode lvalue = itrTo.next();
				emailFromAddress = lvalue.getLuvDesc();
			}

			// to address
			if(toAddress != null){
				emailToAddress.add(toAddress.getLuvDesc());
			}

			// prepare summary email body						 		
			
			emailContent.append("<table>");			
			emailContent.append("<tr><td>");
			
			emailContent.append("</td></tr>");						
			
			if (groupFileSourceName != null) {
				emailContent.append("<tr><td>Input File:</td>");
				emailContent.append("<td>" + groupFileSourceName + "</td></tr>");
			} else {
				emailContent.append("<tr><td>Input File:</td>");
				emailContent.append("<td>" + "Not Available" + "</td></tr>");
			}
			
			emailContent.append("<tr><td>Time:</td><td> "
					+ BPMUtils.getFormattedDateTime(startDate)
					+ "</td></tr>");												
			
			emailContent.append("<tr><td>Total Number of Records:</td><td> "
					+ employerActivities.getValidMemberActivityCount()
					+ "</td></tr>");
						
			emailContent.append("<tr><td>Total Amount Processed:</td><td> $"
					+ employerActivities.getValidTotalAmounts()
					+ "</td></tr>");
			
			emailContent.append("</table>");
			
			logger.info("bpmEmailUtility.sendEmail called ...");
			for(String lToAddress : emailToAddress)
			{
				logger.info("--- Recipient: " + lToAddress);
			}
			bpmEmailUtility.sendEmail(emailServerHost, emailFromAddress,
					emailToAddress, emailSubject.toString(), emailContent.toString(),
					bpmEmailUtility.EMAIL_CONTENT_TYPE_HTML, null);
		
			logger.info("bpmEmailUtility.sendEmail returned ...");

		} catch (Exception e) {
			logger.error(
					"Error occurred sending Employer Sponsored activities update status email: "
							+ e.getMessage(), e);
			logger.error("  emailToAddress=" + emailToAddress);
			logger.error("  emailFromAddress=" + emailFromAddress);
			logger.error("  emailSubject=" + emailSubject.toString());
			logger.error("  emailContent=" + emailContent.toString());
		}
	}
	
	
	
	public void setLookUpValueService(LookUpValueService lookUpValueService) {
		this.lookUpValueService = lookUpValueService;
	}


	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}
	
	

	public void setProgramStatusCalculationService(
			ProgramStatusCalculationService programStatusCalculationService) {
		this.programStatusCalculationService = programStatusCalculationService;
	}

	public void setGroupActivityProgressTrackerService(
			GroupActivityProgressTrackerService groupActivityProgressTrackerService) {
		this.groupActivityProgressTrackerService = groupActivityProgressTrackerService;
	}

	public void setBusinessProgramService(
			BusinessProgramService businessProgramService) {
		this.businessProgramService = businessProgramService;
	}
	
	

	public void setControlGroupIOFileDirSetupDAO(
			ControlGroupIOFileDirSetupDAO controlGroupIOFileDirSetupDAO) {
		this.controlGroupIOFileDirSetupDAO = controlGroupIOFileDirSetupDAO;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public void setBpmEmailUtility(BPMEmailUtility bpmEmailUtility) {
		this.bpmEmailUtility = bpmEmailUtility;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public void setGroupActivityProgressTracker(
			GroupActivityProgressTracker groupActivityProgressTracker) {
		this.groupActivityProgressTracker = groupActivityProgressTracker;
	}
	
	

	public void setEmployerSponsoredActivitiesOnHoldInErrorReycle(
			Collection<RejectedPerson> employerSponsoredActivitiesOnHoldInErrorReycle) {
		this.employerSponsoredActivitiesOnHoldInErrorReycle = employerSponsoredActivitiesOnHoldInErrorReycle;
	}

	public boolean isESPUpdateSwitchOn() {
		return ESPUpdateSwitchOn;
	}

	public void setESPUpdateSwitchOn(boolean eSPUpdateSwitchOn) {
		ESPUpdateSwitchOn = eSPUpdateSwitchOn;
	}

	
	
	
	
}

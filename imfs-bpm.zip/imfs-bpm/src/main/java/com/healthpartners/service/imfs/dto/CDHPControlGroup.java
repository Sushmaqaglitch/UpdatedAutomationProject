package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.util.Collection;

public class CDHPControlGroup implements Serializable
{	
	static final long serialVersionUID = 0L;

	private Integer controlGroupID;
	private String  groupNo;
	private String  groupName;
	private String runFrequency;
	private String outputFilePath;
	private String processedOutputFilePath;
	private String outputExternalFileServerDirectoryPath;
	private String fileNamePrefix;
	private String fileLayoutType;
	private String packageSubType;
	private String securityType;
	private boolean groupProcessedToday;
	private int cdhpFulfillmentReportHistCountToProcess;
	private int insertCDHPFulfillmentCount;
	private int cdhpFulfillmentCountToSendToHPDIT;
	private int cdhpFulfillmentCountToBeRetrievedFromEmployerPortal;
	private int contributionsAfterCombineCount;
	
        
    public CDHPControlGroup()
    {
    	super();
    }



	public Integer getControlGroupID() {
		return controlGroupID;
	}



	public void setControlGroupID(Integer controlGroupID) {
		this.controlGroupID = controlGroupID;
	}



	public String getGroupNo() {
		return groupNo;
	}



	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}

	

	public String getGroupName() {
		return groupName;
	}



	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}



	public String getRunFrequency() {
		return runFrequency;
	}



	public void setRunFrequency(String runFrequency) {
		this.runFrequency = runFrequency;
	}

	

	public String getOutputFilePath() {
		return outputFilePath;
	}



	public void setOutputFilePath(String outputFilePath) {
		this.outputFilePath = outputFilePath;
	}



	public String getProcessedOutputFilePath() {
		return processedOutputFilePath;
	}



	public void setProcessedOutputFilePath(String processedOutputFilePath) {
		this.processedOutputFilePath = processedOutputFilePath;
	}



	public String getOutputExternalFileServerDirectoryPath() {
		return outputExternalFileServerDirectoryPath;
	}



	public void setOutputExternalFileServerDirectoryPath(
			String outputExternalFileServerDirectoryPath) {
		this.outputExternalFileServerDirectoryPath = outputExternalFileServerDirectoryPath;
	}




	public String getFileNamePrefix() {
		return fileNamePrefix;
	}



	public void setFileNamePrefix(String fileNamePrefix) {
		this.fileNamePrefix = fileNamePrefix;
	}



	public String getFileLayoutType() {
		return fileLayoutType;
	}



	public void setFileLayoutType(String fileLayoutType) {
		this.fileLayoutType = fileLayoutType;
	}

	

	public String getPackageSubType() {
		return packageSubType;
	}



	public void setPackageSubType(String packageSubType) {
		this.packageSubType = packageSubType;
	}



	public String getSecurityType() {
		return securityType;
	}



	public void setSecurityType(String securityType) {
		this.securityType = securityType;
	}



	public boolean isGroupProcessedToday() {
		return groupProcessedToday;
	}



	public void setGroupProcessedToday() {
		this.groupProcessedToday = true;
	}



	public int getCdhpFulfillmentReportHistCountToProcess() {
		return cdhpFulfillmentReportHistCountToProcess;
	}



	public void setCdhpFulfillmentReportHistCountToProcess(
			int cdhpFulfillmentReportHistCountToProcess) {
		this.cdhpFulfillmentReportHistCountToProcess = cdhpFulfillmentReportHistCountToProcess;
	}



	public int getInsertCDHPFulfillmentCount() {
		return insertCDHPFulfillmentCount;
	}



	public void setInsertCDHPFulfillmentCount(int insertCDHPFulfillmentCount) {
		this.insertCDHPFulfillmentCount = insertCDHPFulfillmentCount;
	}

	

	public int getCdhpFulfillmentCountToSendToHPDIT() {
		return cdhpFulfillmentCountToSendToHPDIT;
	}



	public void setCdhpFulfillmentCountToSendToHPDIT(
			int cdhpFulfillmentCountToSendToHPDIT) {
		this.cdhpFulfillmentCountToSendToHPDIT = cdhpFulfillmentCountToSendToHPDIT;
	}



	public int getContributionsAfterCombineCount() {
		return contributionsAfterCombineCount;
	}



	public void setContributionsAfterCombineCount(int contributionsAfterCombineCount) {
		this.contributionsAfterCombineCount = contributionsAfterCombineCount;
	}



	public int getCdhpFulfillmentCountToBeRetrievedFromEmployerPortal() {
		return cdhpFulfillmentCountToBeRetrievedFromEmployerPortal;
	}



	public void setCdhpFulfillmentCountToBeRetrievedFromEmployerPortal(
			int cdhpFulfillmentCountToBeRetrievedFromEmployerPortal) {
		this.cdhpFulfillmentCountToBeRetrievedFromEmployerPortal = cdhpFulfillmentCountToBeRetrievedFromEmployerPortal;
	}
    
	
    
	
}

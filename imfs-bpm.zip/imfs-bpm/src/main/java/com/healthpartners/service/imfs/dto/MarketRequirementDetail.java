package com.healthpartners.service.imfs.dto;

public class MarketRequirementDetail extends BaseDTO
{
    static final long serialVersionUID = 0L;
        
    private Integer marketIndicatorID;
    private Integer marketIndicatorReqID;
    private Integer marketIndicatorDefinitionCodeID;
    private String groupBaselineColumnName;
    private String marketIndicatorCodeValue;
    private Integer logicalOperatorCodeID;
    private String logicalOperator;
    
    public MarketRequirementDetail()
    {
    	super();
    }

	public Integer getMarketIndicatorID() {
		return marketIndicatorID;
	}

	public void setMarketIndicatorID(Integer marketIndicatorID) {
		this.marketIndicatorID = marketIndicatorID;
	}

	public Integer getMarketIndicatorReqID() {
		return marketIndicatorReqID;
	}

	public void setMarketIndicatorReqID(Integer marketIndicatorReqID) {
		this.marketIndicatorReqID = marketIndicatorReqID;
	}

	public Integer getMarketIndicatorDefinitionCodeID() {
		return marketIndicatorDefinitionCodeID;
	}

	public void setMarketIndicatorDefinitionCodeID(
			Integer marketIndicatorDefinitionCodeID) {
		this.marketIndicatorDefinitionCodeID = marketIndicatorDefinitionCodeID;
	}

	public String getMarketIndicatorCodeValue() {
		return marketIndicatorCodeValue;
	}

	public void setMarketIndicatorCodeValue(String marketIndicatorCodeValue) {
		this.marketIndicatorCodeValue = marketIndicatorCodeValue;
	}

	public String getGroupBaselineColumnName() {
		return groupBaselineColumnName;
	}

	public void setGroupBaselineColumnName(String groupBaselineColumnName) {
		this.groupBaselineColumnName = groupBaselineColumnName;
	}

	public String getLogicalOperator() {
		return logicalOperator;
	}

	public void setLogicalOperator(String logicalOperator) {
		this.logicalOperator = logicalOperator;
	}

	public Integer getLogicalOperatorCodeID() {
		return logicalOperatorCodeID;
	}

	public void setLogicalOperatorCodeID(Integer logicalOperatorCodeID) {
		this.logicalOperatorCodeID = logicalOperatorCodeID;
	}

	    
    
}

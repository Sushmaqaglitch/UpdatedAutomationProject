package com.healthpartners.service.imfs.dto;

import java.sql.Date;

public class MemberUpdate extends BaseDTO
{
	static final long serialVersionUID = 0L;
	
	private Integer businessProgramID;
	private Integer personID;
	private Integer contractNumber;
	private String memberID;
	private Integer relationshipID;
	private String relationship;
	private java.sql.Date dateOfBirth;
	private Integer programIncentiveOptionID;
	
	
	public MemberUpdate()
	{
		super();
	}
	
	public Integer getBusinessProgramID() {
		return businessProgramID;
	}
	public void setBusinessProgramID(Integer businessProgramID) {
		this.businessProgramID = businessProgramID;
	}
	public Integer getContractNumber() {
		return contractNumber;
	}
	public void setContractNumber(Integer contractNumber) {
		this.contractNumber = contractNumber;
	}
	public String getMemberID() {
		return memberID;
	}
	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}
	public Integer getPersonID() {
		return personID;
	}
	public void setPersonID(Integer personID) {
		this.personID = personID;
	}
	
	public Integer getRelationshipID() {
		return relationshipID;
	}

	public void setRelationshipID(Integer relationshipID) {
		this.relationshipID = relationshipID;
	}

	public String getRelationship() {
		return relationship;
	}
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public java.sql.Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(java.sql.Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Integer getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}

	public void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}

	
	
}

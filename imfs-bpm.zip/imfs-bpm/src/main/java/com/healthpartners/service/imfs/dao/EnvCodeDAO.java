/* $Id: LookUpValueDAO.java 227262 2013-02-22 20:50:26Z tjquist $ */

package com.healthpartners.service.imfs.dao;

import java.util.Collection;

import com.healthpartners.service.imfs.dto.EnvCode;
import org.springframework.dao.DataAccessException;


/**
 * Retrieves instances of <code>EnvCode</code> from the
 * <code>ENV</code> table.
 * 
 * @author tjquist
 */
public interface EnvCodeDAO {

		
	public Collection<EnvCode> getAllENVCodes()
			throws DataAccessException;
			
		public EnvCode getENVCodeByID(Integer envCodeValID)
			throws DataAccessException;
			
		public Collection<EnvCode> getENVCodesByDesc(String envDesc)
			throws DataAccessException;
		
		public EnvCode getENVCodeByCode(String code)
			throws DataAccessException;


}

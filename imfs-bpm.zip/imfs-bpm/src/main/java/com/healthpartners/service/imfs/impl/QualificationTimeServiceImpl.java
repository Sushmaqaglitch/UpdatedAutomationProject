/**
 * 
 */
package com.healthpartners.service.imfs.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import com.healthpartners.service.imfs.dao.LookUpValueDAO;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.iface.QualificationTimeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.exception.BPMException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;


/**
 * @author tjquist
 *
 */
@Component
@Service
public class QualificationTimeServiceImpl implements QualificationTimeService {
	@Autowired
	LookUpValueDAO lookUpValueDAO;
	
	/**
	 * 
	 */
	public QualificationTimeServiceImpl() {
		super();
	}

	/* 
	 * @see com.healthpartners.service.bpm.iface.QualificationTimeService#getCurrentDate()
	 */
	public Calendar getCurrentDate() throws BPMException {
		 
		SimpleDateFormat dateFormat = new SimpleDateFormat ("MM/dd/yyyy HH:mm:ss") ;
        Calendar lCurrentDateTime = Calendar.getInstance();		    	    
	            
		return lCurrentDateTime;		        
	}

	/* 
	 * @see com.healthpartners.service.bpm.iface.QualificationTimeService#getTargetBenifitYear()
	 */
	public int getTargetBenefitYear() throws BPMException, DataAccessException {						
		return getTargetQualificationYear() + 1;
	}

	public int getTargetQualificationYear() throws BPMException, DataAccessException 
	{
		int lTargetQualificationYear = 0;			    	    
	    
		/*
	    ArrayList<LookUpValueCode> results = (ArrayList<LookUpValueCode>) 
	        lookUpValueDAO.getLUVCodesByGroup(BPMConstants.BPM_TARGET_QUAL_YEAR_LUV);
	    	    
	    if(results != null && results.size() > 0) {
	    	LookUpValueCode lLookUpValueCode = (LookUpValueCode) 
	    	    results.get(0);
	    	lTargetQualificationYear = Integer.valueOf(lLookUpValueCode.getLuvVal().trim()).intValue();	    	
	    } 
	    
	    */
	    if(lTargetQualificationYear <= 0){
	    	Calendar lCurrentDateTime = Calendar.getInstance();
	    	lTargetQualificationYear = lCurrentDateTime.get(Calendar.YEAR);
	    }
	    
		return lTargetQualificationYear;
	}

	public LookUpValueDAO getLookUpValueDAO() {
		return lookUpValueDAO;
	}

	public void setLookUpValueDAO(LookUpValueDAO lookUpValueDAO) {
		this.lookUpValueDAO = lookUpValueDAO;
	}
	
	
}

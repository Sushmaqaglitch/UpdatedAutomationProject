package com.healthpartners.service.imfs.dto;



public class DetailEmployerSponsoredContractSummary
{	

    public DetailEmployerSponsoredContractSummary()
    {
    	super();
    }


    private String groupNo;    
    private String siteNo;
    private String contractNo;
    private Integer memberCount;
    private Integer sumOfContributionAmount;

	public String getGroupNo() {
		return groupNo;
	}
	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}
	public String getSiteNo() {
		return siteNo;
	}
	public void setSiteNo(String siteNo) {
		this.siteNo = siteNo;
	}
	public String getContractNo() {
		return contractNo;
	}
	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}
	
	
	public Integer getMemberCount() {
		return memberCount;
	}
	public void setMemberCount(Integer memberCount) {
		this.memberCount = memberCount;
	}
	public Integer getSumOfContributionAmount() {
		return sumOfContributionAmount;
	}
	public void setSumOfContributionAmount(Integer sumOfContributionAmount) {
		this.sumOfContributionAmount = sumOfContributionAmount;
	}
	
   
}

package com.healthpartners.service.imfs.dto;

import java.io.Serializable;

public class ActivityDefinition implements Serializable
{	
	static final long serialVersionUID = 0L;

	private Integer precursorID;
	private String sourceActivityID; //external system sends/recognises
		
	private String activityTypeValue;
	private String activityTypeDesc;
	private Integer activityTypeCodeID;
    private String name;
    private String precursorName;
    private String description;
    private String source;
    private Integer duration;
    private Double cost;
    private String webLink;

    private String userId;
   
    private java.sql.Date effectiveDate;
	private java.sql.Date endDate;


	 // Database table ID.
	private Integer activityID;
        
    public ActivityDefinition()
    {
    	super();
    }

	public Integer getPrecursorID() {
		return precursorID;
	}

	public void setPrecursorID(Integer precursorId) {
		this.precursorID = precursorId;
	}

	public Double getCost() {
		return cost;
	}

	public void setCost(Double cost) {
		this.cost = cost;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	

	public Integer getActivityTypeCodeID() {
		return activityTypeCodeID;
	}

	public void setActivityTypeCodeID(Integer activityTypeCodeID) {
		this.activityTypeCodeID = activityTypeCodeID;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}	

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getWebLink() {
		return webLink;
	}

	public void setWebLink(String webLink) {
		this.webLink = webLink;
	}

	public String getPrecursorName() {
		return precursorName;
	}

	public void setPrecursorName(String precursorName) {
		this.precursorName = precursorName;
	}

	/**
	 * @return the sourceActivityID
	 */
	public String getSourceActivityID() {
		return sourceActivityID;
	}

	/**
	 * @param sourceActivityID the sourceActivityID to set
	 */
	public void setSourceActivityID(String sourceActivityID) {
		this.sourceActivityID = sourceActivityID;
	}

	public String getActivityTypeDesc() {
		return activityTypeDesc;
	}

	public void setActivityTypeDesc(String activityTypeDesc) {
		this.activityTypeDesc = activityTypeDesc;
	}

	public String getActivityTypeValue() {
		return activityTypeValue;
	}

	public void setActivityTypeValue(String activityTypeValue) {
		this.activityTypeValue = activityTypeValue;
	}


	public Integer getActivityID() {
		return activityID;
	}
	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public java.sql.Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(java.sql.Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public java.sql.Date getEndDate() {
		return endDate;
	}

	public void setEndDate(java.sql.Date endDate) {
		this.endDate = endDate;
	}
	
	
}

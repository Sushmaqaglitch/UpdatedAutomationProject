package com.healthpartners.service.imfs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;

import com.healthpartners.service.imfs.dto.CDHPControlGroup;
import com.healthpartners.service.imfs.dto.CDHPControlGroupProcessTracker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.exception.BPMException;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;

/**
 * 
 * @author jxbourbour
 *
 */
@Configuration
public class CDHPControlGroupDAOJdbc extends JdbcDaoSupport implements CDHPControlGroupDAO 
{
	private String selectCDHPControlGroups;
	private String insertCDHPControlGroupProcessTracker;
	private String selectCDHPControlGroupProcessTracker;

	@Autowired
	DataSource bpmDataSource;


	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}
	
	/**
	 * 
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public Collection<CDHPControlGroup> getCDHPControlGroups()
	{
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { };
		int types[] = new int[] { };
		final ArrayList<CDHPControlGroup> lCDHPControlGroups = new ArrayList<CDHPControlGroup>();
		
		template.query(selectCDHPControlGroups, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						CDHPControlGroup lCDHPControlGroup = new CDHPControlGroup();
						
						lCDHPControlGroup.setControlGroupID(rs.getInt("CNTRL_GRP_ID"));
						lCDHPControlGroup.setGroupNo(rs.getString("GRP_NO"));
						lCDHPControlGroup.setRunFrequency(rs.getString("RUN_FREQ_TP"));
						lCDHPControlGroup.setProcessedOutputFilePath(rs.getObject("PROCESSED_OUTPUT_FILE_LOC") == null ? "" : rs.getString("PROCESSED_OUTPUT_FILE_LOC"));
						lCDHPControlGroup.setOutputFilePath(rs.getObject("OUTPUT_FILE_LOC") == null ? "" : rs.getString("OUTPUT_FILE_LOC"));
						lCDHPControlGroup.setOutputExternalFileServerDirectoryPath(rs.getObject("EXTERNAL_FILE_LOC") == null ? "" : rs.getString("EXTERNAL_FILE_LOC"));
						lCDHPControlGroup.setFileNamePrefix(rs.getString("FILE_NAME_PREFIX"));
						lCDHPControlGroup.setFileLayoutType(rs.getString("FILE_LAYOUT_TP"));
						lCDHPControlGroup.setPackageSubType(rs.getString("PURCH_SUB_TP_NM"));
						lCDHPControlGroup.setSecurityType(rs.getString("SECURITY_TP"));
						lCDHPControlGroup.setGroupName(rs.getString("EMPL_GRP_RPT_NM"));
						
						
						
						lCDHPControlGroups.add(lCDHPControlGroup);
					}
		});
		
		return lCDHPControlGroups;
	}
	
	/**
	 * 
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public CDHPControlGroupProcessTracker getCDHPControlGroupProcessTracker(Integer controlGroupID)
	{
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {controlGroupID, controlGroupID };
		int types[] = new int[] {Types.INTEGER, Types.INTEGER };
		final ArrayList<CDHPControlGroupProcessTracker> lCDHPControlGroupProcessTrackers = new ArrayList<CDHPControlGroupProcessTracker>();
		
		template.query(selectCDHPControlGroupProcessTracker, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						CDHPControlGroupProcessTracker lCDHPControlGroupProcessTracker = new CDHPControlGroupProcessTracker();
						
						lCDHPControlGroupProcessTracker.setControlGroupID(rs.getInt("cntrl_grp_id"));
						lCDHPControlGroupProcessTracker.setDateLastProcessed(rs.getDate("dt_last_processed"));
						lCDHPControlGroupProcessTracker.setProcessStatus(rs.getString("process_status"));
						lCDHPControlGroupProcessTracker.setProcessStatusID(rs.getInt("prcs_status_tp_id"));
						lCDHPControlGroupProcessTracker.setRecordsSent(rs.getInt("records_sent"));
						
						lCDHPControlGroupProcessTrackers.add(lCDHPControlGroupProcessTracker);
					}
		});
		
		CDHPControlGroupProcessTracker dto = null;
		if (lCDHPControlGroupProcessTrackers.size() > 0) {
			dto = (CDHPControlGroupProcessTracker) lCDHPControlGroupProcessTrackers.get(0);
		}
		return dto;
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public int insertCDHPControlGroupProcessTracker(Integer controlGroupID, String processStatus, Integer recordsSent)
	throws DataAccessException {
		
	
		JdbcTemplate template = getJdbcTemplate();
		
	
		Object params[] = new Object[] { controlGroupID, processStatus, recordsSent };
		int types[] = new int[] { Types.INTEGER, Types.VARCHAR, Types.INTEGER};
	
		int rowInserted = template.update(insertCDHPControlGroupProcessTracker, params,
				types);
	
		
		return rowInserted;
	}

	public void setSelectCDHPControlGroups(String selectCDHPControlGroups) {
		this.selectCDHPControlGroups = selectCDHPControlGroups;
	}

	public void setInsertCDHPControlGroupProcessTracker(
			String insertCDHPControlGroupProcessTracker) {
		this.insertCDHPControlGroupProcessTracker = insertCDHPControlGroupProcessTracker;
	}

	public void setSelectCDHPControlGroupProcessTracker(
			String selectCDHPControlGroupProcessTracker) {
		this.selectCDHPControlGroupProcessTracker = selectCDHPControlGroupProcessTracker;
	}

	
	
	
}

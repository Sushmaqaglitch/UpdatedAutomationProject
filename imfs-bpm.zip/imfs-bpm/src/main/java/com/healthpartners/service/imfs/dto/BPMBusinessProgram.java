package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.util.Calendar;

/**
 * This business program class is used internally in BPM, for ex. in status calculation.
 * It has only fields that are required in status calculation. 
 * Also, the BusinessProgram class is sent back in the web service. 
 * So changes in that class would affect the WSDL and the calling systems.
 *  
 * @author jxbourbour
 *
 */
public class BPMBusinessProgram implements Serializable
{	
	static final long serialVersionUID = 0L;
	
	private int programID;
	private int groupID;
	private int subgroupID;
	
	private String groupNumber;
	private String siteNumber;
	
	private String familyParticipationValue;
	private int familyParticipationCodeID;
	private Calendar effectiveDate;
	private Calendar endDate;
	private Calendar releaseDate;
	private Integer contractNumber; 

	private Calendar qualificationWindowStartDate;	
    private Calendar qualificationWindowEndDate;
    
    private Calendar siteEffectiveDate;
    private Calendar siteEndDate;
    
    private Calendar contractEffDate;
    private Calendar contractEndDate;
    
    private Calendar newHireDate;
    
    private String programTypeCodeID;
    
    private int programStatusCodeID;
    private String programStatusCodeValue;
    private String smallGroupType;
    
    private Calendar statusCalcEndDate;
    private int qualificationCheckmarkID;
    private int eligiblePackageID;
    
    private boolean evaluateTermedContract;
    
    private String groupName;
    private String siteName;
       
    
    public BPMBusinessProgram()
    {
    	super();
    }
    
	public final Integer getContractNumber() {
		return contractNumber;
	}
	public final void setContractNumber(Integer contractNumber) {
		this.contractNumber = contractNumber;
	}
	public final Calendar getEffectiveDate() {
		return effectiveDate;
	}
	public final void setEffectiveDate(Calendar effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public final Calendar getEndDate() {
		return endDate;
	}
	public final void setEndDate(Calendar endDate) {
		this.endDate = endDate;
	}
	public final String getFamilyParticipationValue() {
		return familyParticipationValue;
	}
	public final void setFamilyParticipationValue(String familyParticipationValue) {
		this.familyParticipationValue = familyParticipationValue;
	}
	public final int getGroupID() {
		return groupID;
	}
	public final void setGroupID(int groupID) {
		this.groupID = groupID;
	}
	public final int getProgramID() {
		return programID;
	}
	public final void setProgramID(int programID) {
		this.programID = programID;
	}
	public final Calendar getQualificationWindowEndDate() {
		return qualificationWindowEndDate;
	}
	public final void setQualificationWindowEndDate(
			Calendar qualificationWindowEndDate) {
		this.qualificationWindowEndDate = qualificationWindowEndDate;
	}
	public final Calendar getQualificationWindowStartDate() {
		return qualificationWindowStartDate;
	}
	public final void setQualificationWindowStartDate(
			Calendar qualificationWindowStartDate) {
		this.qualificationWindowStartDate = qualificationWindowStartDate;
	}
	
	
	
	
	public Calendar getSiteEffectiveDate() {
		return siteEffectiveDate;
	}

	public void setSiteEffectiveDate(Calendar siteEffectiveDate) {
		this.siteEffectiveDate = siteEffectiveDate;
	}

	public Calendar getSiteEndDate() {
		return siteEndDate;
	}

	public void setSiteEndDate(Calendar siteEndDate) {
		this.siteEndDate = siteEndDate;
	}

	public Calendar getContractEffDate() {
		return contractEffDate;
	}

	public void setContractEffDate(Calendar contractEffDate) {
		this.contractEffDate = contractEffDate;
	}

	public Calendar getContractEndDate() {
		return contractEndDate;
	}

	public void setContractEndDate(Calendar contractEndDate) {
		this.contractEndDate = contractEndDate;
	}

	public final int getSubgroupID() {
		return subgroupID;
	}
	public final void setSubgroupID(int subgroupID) {
		this.subgroupID = subgroupID;
	}
	public final String getProgramTypeCodeID() {
		return programTypeCodeID;
	}
	public final void setProgramTypeCodeID(String programTypeCodeID) {
		this.programTypeCodeID = programTypeCodeID;
	}
	public final Calendar getNewHireDate() {
		return newHireDate;
	}
	public final void setNewHireDate(Calendar newHireDate) {
		this.newHireDate = newHireDate;
	}

	public Calendar getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(Calendar releaseDate) {
		this.releaseDate = releaseDate;
	}

	public int getProgramStatusCodeID() {
		return programStatusCodeID;
	}

	public void setProgramStatusCodeID(int programStatusCodeID) {
		this.programStatusCodeID = programStatusCodeID;
	}

	public int getFamilyParticipationCodeID() {
		return familyParticipationCodeID;
	}

	public void setFamilyParticipationCodeID(int familyParticipationCodeID) {
		this.familyParticipationCodeID = familyParticipationCodeID;
	}

	public String getProgramStatusCodeValue() {
		return programStatusCodeValue;
	}

	public void setProgramStatusCodeValue(String programStatusCodeValue) {
		this.programStatusCodeValue = programStatusCodeValue;
	}

	public final int getEligiblePackageID() {
		return eligiblePackageID;
	}

	public final void setEligiblePackageID(int eligiblePackageID) {
		this.eligiblePackageID = eligiblePackageID;
	}

	public final int getQualificationCheckmarkID() {
		return qualificationCheckmarkID;
	}

	public final void setQualificationCheckmarkID(int qualificationCheckmarkID) {
		this.qualificationCheckmarkID = qualificationCheckmarkID;
	}

	public final Calendar getStatusCalcEndDate() {
		return statusCalcEndDate;
	}

	public final void setStatusCalcEndDate(Calendar statusCalcEndDate) {
		this.statusCalcEndDate = statusCalcEndDate;
	}

	public String getGroupNumber() {
		return groupNumber;
	}

	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}
	
	

	public String getSiteNumber() {
		return siteNumber;
	}

	public void setSiteNumber(String siteNumber) {
		this.siteNumber = siteNumber;
	}

	public boolean isEvaluateTermedContract() {
		return evaluateTermedContract;
	}

	public void setEvaluateTermedContract(boolean evaluateTermedContract) {
		this.evaluateTermedContract = evaluateTermedContract;
	}

	public String getSmallGroupType() {
		return smallGroupType;
	}

	public void setSmallGroupType(String smallGroupType) {
		this.smallGroupType = smallGroupType;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	
	
	    
    
}

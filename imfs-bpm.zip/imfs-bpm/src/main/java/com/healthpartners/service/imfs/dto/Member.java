/* $Id$ */

package com.healthpartners.service.imfs.dto;

import java.io.Serializable;

/**
 * Represents the member attributes of a person.
 * 
 * @author pbhenninger
 */
public class Member implements Serializable {

	static final long serialVersionUID = 0L;

	private String memberID;
	private String firstName;
	private String middleName;
	private String lastName;

	private String relationshipToContractHolder;

	private MemberStatus memberStatus;
	
	private Contract memberContract;

	// private EligibleActivity[] eligibleActivities;
	
	private MemberActivity[] memberActivities;
	private EligibleActivity[] eligibleActivities;

	public Member() {
		super();
	}

	public String getMemberID() {
		return memberID;
	}

	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}

	public String getRelationshipToContractHolder() {
		return relationshipToContractHolder;
	}

	public void setRelationshipToContractHolder(
			String relationshipToContractHolder) {
		this.relationshipToContractHolder = relationshipToContractHolder;
	}

	public MemberStatus getMemberStatus() {
		return memberStatus;
	}

	public void setMemberStatus(MemberStatus memberStatus) {
		this.memberStatus = memberStatus;
	}

	public MemberActivity[] getMemberActivities() {
		return memberActivities;
	}

	public void setMemberActivities(MemberActivity[] memberActivities) {
		this.memberActivities = memberActivities;
	}

	public Contract getMemberContract() {
		return memberContract;
	}

	public void setMemberContract(Contract memberContract) {
		this.memberContract = memberContract;
	}

	public EligibleActivity[] getEligibleActivities() {
		return eligibleActivities;
	}

	public void setEligibleActivities(EligibleActivity[] eligibleActivities) {
		this.eligibleActivities = eligibleActivities;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	
}

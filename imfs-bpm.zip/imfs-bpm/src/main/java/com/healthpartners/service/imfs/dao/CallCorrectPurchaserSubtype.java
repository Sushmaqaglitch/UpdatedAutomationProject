package com.healthpartners.service.imfs.dao;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.healthpartners.service.imfs.dto.StoredProcedureResults;
@Configuration
public class CallCorrectPurchaserSubtype  extends StoredProcedure 
{

    protected final Log logger = LogFactory.getLog(getClass());

    @Autowired
    DataSource bpmDataSource;


    @PostConstruct
    private void initialize() {

        setDataSource(bpmDataSource);
    }

    private static final String STORED_PROC_NAME = "pkg_bpm_utils.correctPurchaserSubType";
    
    public CallCorrectPurchaserSubtype(DataSource bpmDataSource)
    {
        super(bpmDataSource, STORED_PROC_NAME);
        
        // Input Parameter
        // None.
        
        // Output Parameters   
        declareParameter(new SqlOutParameter("out_CountSelect", Types.INTEGER));        
        declareParameter(new SqlOutParameter("out_CountUpdate", Types.INTEGER));
        
        compile();
    }
    
    public StoredProcedureResults execute()    
    {    	    	
        Map<String, Object> lInputParams = new HashMap<String, Object>(0);
              
        // Input        
        
        Map<String, Object> lOutputParams = execute(lInputParams);
        
        StoredProcedureResults lStoredProcedureResults = new StoredProcedureResults();
        
        // Output
        if(lOutputParams.size() > 0) 
        {
        	lStoredProcedureResults.setCountBefore((Integer)lOutputParams.get("out_CountSelect"));        	
        	lStoredProcedureResults.setCountUpdate((Integer)lOutputParams.get("out_CountUpdate"));
        }                
        
        return lStoredProcedureResults;
    }

}

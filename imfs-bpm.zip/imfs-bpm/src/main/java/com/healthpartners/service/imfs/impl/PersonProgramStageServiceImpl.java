/* $Id$ */

package com.healthpartners.service.imfs.impl;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import com.healthpartners.service.imfs.dao.PersonProgramStageDAO;
import com.healthpartners.service.imfs.dao.RuleGroupDAO;
import com.healthpartners.service.imfs.dto.BusinessProgramTO;
import com.healthpartners.service.imfs.dto.PersonProgramStage;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.iface.PersonProgramStageService;
import com.healthpartners.service.imfs.rules.RuleAdapter;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/**
 * @author tjquist
 * 
 */
@Component
@Service
public class PersonProgramStageServiceImpl implements PersonProgramStageService {
	@Autowired
	private PersonProgramStageDAO personProgramStageDAO;



	public int getPersonProgramCount()
			throws BPMException, DataAccessException {
		return personProgramStageDAO.getPersonProgramCount();
	}

	/*
	 * @see com.healthpartners.service.bpm.iface.PersonProgramStageService#insertPersonPrograms()
	 */
	public int insertPersonPrograms(Collection<PersonProgramStage> personPrograms)
		throws BPMException, DataAccessException {
		return personProgramStageDAO.insertPersonPrograms(personPrograms);
	}

	/*
	 * @see com.healthpartners.service.bpm.iface.PersonProgramStageService#deletePersonPrograms()
	 */
	public int deletePersonPrograms(Collection<PersonProgramStage> personPrograms) 
		throws BPMException, DataAccessException {
		
		return personProgramStageDAO.deletePersonPrograms(personPrograms);
	}
	
	/*
	 * @see com.healthpartners.service.bpm.iface.PersonProgramStageService#getPersonProgram()
	 */
	public PersonProgramStage getPersonProgram(int personNumber)
		throws BPMException, DataAccessException {
		
		return personProgramStageDAO.getPersonProgram(personNumber);
	}
	
	/*
	 * @see com.healthpartners.service.bpm.iface.PersonProgramStageService#getPersonPrograms()
	 */
	public Collection<PersonProgramStage> getPersonPrograms()
		throws BPMException, DataAccessException {
		
		return personProgramStageDAO.getPersonPrograms();
	}

	public PersonProgramStageDAO getPersonProgramStageDAO() {
		return personProgramStageDAO;
	}

	public void setPersonProgramStageDAO(PersonProgramStageDAO personProgramStageDAO) {
		this.personProgramStageDAO = personProgramStageDAO;
	}

}

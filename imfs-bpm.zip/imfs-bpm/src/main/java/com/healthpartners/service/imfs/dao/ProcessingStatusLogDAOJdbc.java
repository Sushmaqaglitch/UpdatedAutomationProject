package com.healthpartners.service.imfs.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.exception.BPMException;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;

/**
 * @author tjquist
 * 
 */
@Configuration
public class ProcessingStatusLogDAOJdbc extends JdbcDaoSupport implements
		ProcessingStatusLogDAO {

	private String updatePersonProcessingStatusLog;

	private String insertPersonProcessingStatusLog;

	private String selectPendingPersonsTobeProcessed;

	private String selectNumberOfPendingPersonsTobeProcessed;
	
	private String selectProcessingStatusLogCount;
	
	private String purgeProcessingStatusLogByDate;

	@Autowired
	private DataFieldMaxValueIncrementer processingStatusLogIdIncrementer;

	@Autowired
	DataSource bpmDataSource;


	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}


	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<Integer> getPendingPersonsTobeProcessed(int batchSize,
			int pProcessID) throws DataAccessException {
		final ArrayList<Integer> results = new ArrayList<Integer>();
		JdbcTemplate template = getJdbcTemplate();

		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectPendingPersonsTobeProcessed);

		if (pProcessID > 0) {
			lQuery.append(" AND PRCS_ID = " + pProcessID + "");
		}

		if (batchSize > 0) {
			lQuery.append(" AND ROWNUM <= " + batchSize + "");
		}

		template.query(lQuery.toString(), new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				if (rs.getObject(1) != null) {
					results.add(new Integer(rs.getInt(1)));
				}
			}
		});

		return results;
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int getNumberOfPendingPersonsTobeProcessed(int pProcessID)
			throws DataAccessException {
		final ArrayList<Integer> results = new ArrayList<Integer>();
		JdbcTemplate template = getJdbcTemplate();
		StringBuffer lQuery = new StringBuffer();

		lQuery.append(selectNumberOfPendingPersonsTobeProcessed);

		if (pProcessID > 0) {
			lQuery.append(" AND PRCS_ID = " + pProcessID + "");
		}

		template.query(lQuery.toString(), new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				results.add(new Integer(rs.getInt(1)));
			}
		});

		int numberOfPendingPersons = 0;
		if (results.size() > 0) {
			numberOfPendingPersons = results.get(0).intValue();
		}

		return numberOfPendingPersons;
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int updatePersonProcessingStatusLog(Integer pPersonID,
			Integer processId, String processingStatusValue, String userId)
			throws DataAccessException {
		Calendar completionDate = null;
		if (BPMConstants.PROCESSING_STATUS_COMPLETED
				.equals(processingStatusValue)) {
			completionDate = Calendar.getInstance();
		} else {
			completionDate = null;
		}
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { completionDate, processingStatusValue,
				userId, pPersonID, processId };
		int types[] = new int[] { Types.TIMESTAMP, Types.VARCHAR,
				Types.VARCHAR, Types.INTEGER, Types.INTEGER };
		return template.update(updatePersonProcessingStatusLog, params, types);
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int[] updatePersonProcessingStatus(
			Collection<Integer> personIds, final Integer processId,
			final String processingStatusValue, final String userId)
			throws DataAccessException {
		int[] numberOfRowsUpdated;

		Calendar localCompletionDate = null;
		if (BPMConstants.PROCESSING_STATUS_COMPLETED
				.equals(processingStatusValue)) {
			localCompletionDate = Calendar.getInstance();
		} else {
			localCompletionDate = null;
		}

		final Calendar completionDate = localCompletionDate;

		final Object objs[] = personIds.toArray();
		JdbcTemplate template = getJdbcTemplate();
		BatchPreparedStatementSetter setter = null;
		setter = new BatchPreparedStatementSetter() {
			public int getBatchSize() {
				return objs.length;
			}

			public void setValues(PreparedStatement ps, int index)
					throws SQLException {
				Integer personId = (Integer) objs[index];
				ps.setDate(1, BPMUtils.calendarToSqlDate(completionDate));
				ps.setString(2, processingStatusValue);
				ps.setString(3, userId);
				ps.setInt(4, personId);
				ps.setInt(5, processId);
			}
		};
		numberOfRowsUpdated = template.batchUpdate(
				updatePersonProcessingStatusLog, setter);
		return numberOfRowsUpdated;
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public long insertPersonProcessingStatusLog(Integer personId,
			Integer processId, String processingStatusValue, String userId)
			throws DataAccessException {
		// Retrieve the next sequence number .
		Long logId = new Long(processingStatusLogIdIncrementer.nextLongValue());

		// Persist
		JdbcTemplate template = getJdbcTemplate();

		Object params[] = new Object[] { logId, processId, personId,
				processingStatusValue, userId };

		int types[] = new int[] { Types.BIGINT, Types.INTEGER, Types.INTEGER,
				Types.VARCHAR, Types.VARCHAR };

		template.update(insertPersonProcessingStatusLog, params, types);

		return logId.longValue();
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int[] insertPersonProcessingStatusLog(Collection<Integer> personIds,
			final Integer processId, final String processingStatusValue,
			final String userId) throws DataAccessException {

		int[] numberOfRowsInserted;

		final Object objs[] = personIds.toArray();

		JdbcTemplate template = getJdbcTemplate();

		BatchPreparedStatementSetter setter = null;
		setter = new BatchPreparedStatementSetter() {
			public int getBatchSize() {
				return objs.length;
			}

			public void setValues(PreparedStatement ps, int index)
					throws SQLException {
				Long logId = new Long(processingStatusLogIdIncrementer
						.nextLongValue());
				Integer personId = (Integer) objs[index];
				ps.setLong(1, logId);
				ps.setInt(2, processId);
				ps.setInt(3, personId);
				ps.setString(4, processingStatusValue);
				ps.setString(5, userId);
			}
		};
		numberOfRowsInserted = template.batchUpdate(
				insertPersonProcessingStatusLog, setter);

		return numberOfRowsInserted;
	}
	
	/**
	 * Date used comes from LUV table
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Integer purgeProcessStatLogByDate(java.sql.Date purgeDate)
			throws DataAccessException {
		

		// Persist the audit log entry.
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {			
				purgeDate // comes from LUV table
				};
		int types[] = new int[] { 
				Types.TIMESTAMP};
		int deleteCount = template.update(purgeProcessingStatusLogByDate, params, types);

		return deleteCount;
	}
	
	
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Integer getProcessStatLogCount() throws DataAccessException {
		final ArrayList<Integer> results = new ArrayList<Integer>();
		JdbcTemplate template = getJdbcTemplate();
		template.query(selectProcessingStatusLogCount,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						results.add(new Integer(rs.getInt(1)));
					}
				});

		Integer numberOfAuditLogRecords = 0;
		if (results.size() > 0) {
			numberOfAuditLogRecords = results.get(0).intValue();
		}

		return numberOfAuditLogRecords;

	}


	public String getInsertPersonProcessingStatusLog() {
		return insertPersonProcessingStatusLog;
	}

	public void setInsertPersonProcessingStatusLog(
			String insertPersonProcessingStatusLog) {
		this.insertPersonProcessingStatusLog = insertPersonProcessingStatusLog;
	}

	public DataFieldMaxValueIncrementer getProcessingStatusLogIdIncrementer() {
		return processingStatusLogIdIncrementer;
	}

	public void setProcessingStatusLogIdIncrementer(
			DataFieldMaxValueIncrementer processingStatusIdIncrementer) {
		this.processingStatusLogIdIncrementer = processingStatusIdIncrementer;
	}

	public String getSelectPendingPersonsTobeProcessed() {
		return selectPendingPersonsTobeProcessed;
	}

	public void setSelectPendingPersonsTobeProcessed(
			String selectPendingPersonsTobeProcessed) {
		this.selectPendingPersonsTobeProcessed = selectPendingPersonsTobeProcessed;
	}

	public String getSelectNumberOfPendingPersonsTobeProcessed() {
		return selectNumberOfPendingPersonsTobeProcessed;
	}

	public void setSelectNumberOfPendingPersonsTobeProcessed(
			String selectNumberOfPendingPersonsTobeProcessed) {
		this.selectNumberOfPendingPersonsTobeProcessed = selectNumberOfPendingPersonsTobeProcessed;
	}

	public String getUpdatePersonProcessingStatusLog() {
		return updatePersonProcessingStatusLog;
	}

	public void setUpdatePersonProcessingStatusLog(
			String updatePersonProcessingStatusLog) {
		this.updatePersonProcessingStatusLog = updatePersonProcessingStatusLog;
	}


	public String getSelectProcessingStatusLogCount() {
		return selectProcessingStatusLogCount;
	}

	public void setSelectProcessingStatusLogCount(
			String selectProcessingStatusLogCount) {
		this.selectProcessingStatusLogCount = selectProcessingStatusLogCount;
	}

	public String getPurgeProcessingStatusLogByDate() {
		return purgeProcessingStatusLogByDate;
	}

	public void setPurgeProcessingStatusLogByDate(
			String purgeProcessingStatusLogByDate) {
		this.purgeProcessingStatusLogByDate = purgeProcessingStatusLogByDate;
	}

	
}

/* $Id$ */

package com.healthpartners.service.imfs.impl;


import java.util.Collection;

import com.healthpartners.service.imfs.exception.BPMBusinessValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;


import com.healthpartners.service.imfs.dao.GroupSiteYearStageDAO;

import com.healthpartners.service.imfs.dto.GroupSiteYearStage;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.iface.GroupSiteYearStageService;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


/**
 * @author tjquist
 * 
 */
@Component
@Service
public class GroupSiteYearStageServiceImpl implements GroupSiteYearStageService {
	@Autowired
	private GroupSiteYearStageDAO groupSiteYearStageDAO;


	/*
	 * @see com.healthpartners.service.bpm.iface.GroupSiteYearStageService#getGroupSiteYearCount()
	 */
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public int getGroupSiteYearCount()
			throws BPMException, DataAccessException {
		return groupSiteYearStageDAO.getGroupSiteYearCount();
	}

	/*
	 * @see com.healthpartners.service.bpm.iface.GroupSiteYearStageService#insertGroupSiteYears()
	 */
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public int insertGroupSiteYears(Collection<GroupSiteYearStage> groupSiteYears)
		throws BPMException, DataAccessException {
		return groupSiteYearStageDAO.insertGroupSiteYears(groupSiteYears);
	}

	/*
	 * @see com.healthpartners.service.bpm.iface.GroupSiteYearStageService#deleteGroupSiteYears()
	 */
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public int deleteGroupSiteYears(Collection<GroupSiteYearStage> groupSiteYears) 
		throws BPMException, DataAccessException {
		
		return groupSiteYearStageDAO.deleteGroupSiteYears(groupSiteYears);
	}
	
	/*
	 * @see com.healthpartners.service.bpm.iface.GroupSiteYearStageService#getGroupSiteYear()
	 */
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public GroupSiteYearStage getGroupSiteYear(int groupNumber, int siteNumber, java.sql.Date qualStartDate)
		throws BPMException, DataAccessException {
		
		return groupSiteYearStageDAO.getGroupSiteYear(groupNumber, siteNumber, qualStartDate);
	}
	
	/*
	 * @see com.healthpartners.service.bpm.iface.GroupSiteYearStageService#getGroupSiteYears()
	 */
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public Collection<GroupSiteYearStage> getGroupSiteYears()
		throws BPMException, DataAccessException {
		
		return groupSiteYearStageDAO.getGroupSiteYears();
	}
	
	

	public GroupSiteYearStageDAO getGroupSiteYearStageDAO() {
		return groupSiteYearStageDAO;
	}

	public void setGroupSiteYearStageDAO(GroupSiteYearStageDAO groupSiteYearStageDAO) {
		this.groupSiteYearStageDAO = groupSiteYearStageDAO;
	}

	


}

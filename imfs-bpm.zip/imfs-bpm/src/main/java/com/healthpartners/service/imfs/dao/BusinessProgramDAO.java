package com.healthpartners.service.imfs.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;

import com.healthpartners.service.imfs.dto.*;
import org.springframework.dao.DataAccessException;


public interface BusinessProgramDAO 
{
	public Collection<EmployerGroup> getGroups(String pGroupNumber);
	
	public Collection<BusinessProgramTO> getBusinessProgramTO(Integer personId,
															  String programCode,
															  Integer targetQualificationYear,
															  String groupNo,
															  Integer pProgramID);
	
	public Collection<BusinessProgramTO> getBusinessProgramTO(Integer pPersonID, 			
			Integer pTargetQualificationYear);
	
	public Collection<BusinessProgramTO> getGroupBusinessProgramTO(String programCode, 
			Integer targetQualificationYear,
			String groupNo,
			String siteNo);
	
	/**
	 * This method returns a list of BusinessProgramTOs for the target benefit year.
	 * Target Benefit Year is required.
	 * The other paratmers are optional. When not provided, they should be set to 0. 
	 */
	public Collection<BusinessProgramTO> getBusinessProgramTOs(String pProgramCode, 
			Integer pTargetQualificationYear,
			String pGroupNo,
			String pSiteNo);
	/*
	 * Returns a BusinessProgramTO object representing the Business Program specified by the
	 * program ID, the person ID, and the target benefit year for the person participating 
	 * in that program.  Only looking to return the business program involved
	 * in the site transfer (termed sites only).
	 */
	
	public Collection<BusinessProgramTO> getBusinessProgramTOFromMemberTermedSite(Integer pPersonID, 
			Integer pTargetQualificationYear,
			String pGroupNo);
	
	/**
	 * This method returns a list of Business Programs based on group, site, year which is
	 * part of the feed to the membership cache system.
	 *  
	 */
	public Collection<GroupSiteYearStage> getBPMGroupSiteYear();
		
	public Collection<Integer> getQualificationYears(String pProgramCode);
	public Collection<Integer> getAllQualificationYears();
	
	public Collection<BusinessProgramTO> getParticipatingBusinessProgramTO(Integer pPersonID, 			
			Integer pTargetQualificationYear);
	
	public Collection<BPMBusinessProgram> getBPMBusinessPrograms(Integer pPersonID,
																 Integer pTargetQualificationYear, boolean limitForStatusCalculation);
	
	public Collection<BPMBusinessProgram> getBPMBusinessProgramsWTermedContract(Integer pPersonID, 			
			Integer pTargetQualificationYear, boolean limitForStatusCalculation);
	
	public Collection<BusinessProgramTO> getBusinessProgramsForMembership(boolean pReadyForMembership);
	
	public long updateMembershipStatusFlag()
	throws DataAccessException;
	
	Collection<Integer> getHAAvailable(Integer pProgramID,
			String pTargetQualificationYear, Calendar pCurrentDate) throws DataAccessException;
	
	public int insertBusinessProgram(BPMBusinessProgram pBusinessProgramTO, String lUserID)
	throws DataAccessException;
	
	public Collection<BPMBusinessProgram> selectProgramTemplate(String pProgramType)
	throws DataAccessException;
	
	public int[] insertBusinessPrograms(final ArrayList<BPMBusinessProgram> pBusinessPrograms)
	throws DataAccessException;
	
	public Collection<BusinessProgramTO> getAllBusinessPrograms(Integer pPersonID, boolean pCalledFromWebPortal)
	throws DataAccessException;
	
	public BPMBusinessProgram getBusinessProgramDetail(Integer programId) throws DataAccessException;
	
	public Collection<BusinessProgramType> getSmallGroupTypeIDs()
	throws DataAccessException;
	
	public Collection<MarketRequirement> gMarketIndicatorRequirements(Integer pMarketIndicatorID)
	throws DataAccessException;
	
	public Collection<MarketRequirementDetail> getMarketRequirementDetails(Integer pMarketIndicatorID, Integer lMarketIndicatorReqID)
	throws DataAccessException;
	
	public Collection<GroupBaseline> getNewSmartStepsGroupBaseline(Collection<MarketRequirement> pMarketRequirements, Integer batchCount)
	throws DataAccessException;
	
	public Collection<AuthCode> getNewSmartStepsProgramAuthPromoCode(Integer pProgramID)
	throws DataAccessException;

	
	public Collection<GroupBaseline> getAutoPopulateOverlaps(Collection<MarketRequirement> pMarketRequirements)
	throws DataAccessException;
	
	public Integer getTemplateBusinessProgramID(String pProgramTypeCode)
	throws DataAccessException;
		
	public Integer getTemplateActivitiesCount(Integer pProgramID)
	throws DataAccessException;
	
	public Integer getTemplateAuthCodesCount(Integer pProgramID)
	throws DataAccessException;
	
	public Integer getTemplateIncentivesCount(Integer pProgramID)
	throws DataAccessException;
	
	public Integer getTemplateCheckmarkCount(Integer pProgramID)
	throws DataAccessException;
	
	
	
	}

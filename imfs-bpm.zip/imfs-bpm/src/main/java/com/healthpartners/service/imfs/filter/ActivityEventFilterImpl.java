/**
 * 
 */
package com.healthpartners.service.imfs.filter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;



import com.healthpartners.service.imfs.dto.ActivityEvent;
import com.healthpartners.service.imfs.exception.BPMException;
import org.apache.log4j.Logger;

/**
 * @author mxthoutam
 *
 */
public class ActivityEventFilterImpl implements ActivityEventFilter {

	protected final Logger log = Logger.getLogger(this.getClass());
	
	Collection<ActivityEventFilter> filters = new ArrayList<ActivityEventFilter>();
	
	/**
	 * 
	 */
	public ActivityEventFilterImpl() {
		super();
	}

	/* 
	 * @see com.healthpartners.service.bpm.iface.FilterService#doFilter(com.healthpartners.service.bpm.dto.ActivityEvent)
	 */
	public String doFilter(ActivityEvent activityEvent) throws BPMException {
		String result = "0"; // By default filterd set to "0".
		//logger.info("@@ called Filter for ActivityEvent--");
		Iterator<ActivityEventFilter> itr  = filters.iterator();
		while(itr.hasNext()){
			ActivityEventFilter filter = itr.next();
			result = filter.doFilter(activityEvent);
			if(!result.equals("0")){
				//false - is filterd out
				// send result - no need of further calling filters
				break;
			}
		}
		//logger.info("@@ ActivityEvent Filter result--"+result);
		return result;
	}

	public Collection<ActivityEventFilter> getFilters() {
		return filters;
	}

	public void setFilters(Collection<ActivityEventFilter> filters) {
		this.filters = filters;
	}

}

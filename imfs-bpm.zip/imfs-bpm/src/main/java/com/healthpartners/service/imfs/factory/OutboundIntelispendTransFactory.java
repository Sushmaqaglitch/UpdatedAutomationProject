/* $Id: OutboundVendorTransFactory.java 153848 2008-11-12 20:55:34Z tjquist $ */

package com.healthpartners.service.imfs.factory;

import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.common.XMLIntelispendTags;
import com.healthpartners.service.imfs.dto.RewardCardClientData;
import com.healthpartners.service.imfs.dto.RewardFulfillmentTrackingReportHist;
import org.springframework.stereotype.Component;


/*
 * Build out xml transactions to send to vendor hosting webservice.
 */
@Component
public class OutboundIntelispendTransFactory {
	

	
	 public static String formatXMLOrderMapper(RewardFulfillmentTrackingReportHist lRewardFulfillmentTrackingReportHist) {
			
			
			StringBuffer formattedXML = new StringBuffer();
			
			// KYC
			
			
			

	        formattedXML.append(getOrderBeginTag());
			
			if (lRewardFulfillmentTrackingReportHist.getRewardTransHistID() != null) {
				formattedXML.append(formatXMLCardHolderPIDNumber(lRewardFulfillmentTrackingReportHist.getRewardTransHistID()));
			}
			if (lRewardFulfillmentTrackingReportHist.getFirstName() != null) {
				formattedXML.append(formatXMLFirstName(lRewardFulfillmentTrackingReportHist.getFirstName()));
			}
			if (lRewardFulfillmentTrackingReportHist.getMiddleInit() != null) {
				formattedXML.append(formatXMLMiddleName(lRewardFulfillmentTrackingReportHist.getMiddleInit()));
			}
			if (lRewardFulfillmentTrackingReportHist.getLastName() != null) {
				formattedXML.append(formatXMLLastName(lRewardFulfillmentTrackingReportHist.getLastName()));
			}
			//Currently not being used.
			/*if (lRewardFulfillmentTrackingReportHist.getEmbossName() != null) {
				formattedXML.append(formatXMLEmbossName(lRewardFulfillmentTrackingReportHist.getEmbossName()));
			}*/
			if (lRewardFulfillmentTrackingReportHist.getEmbossDesc() != null) {
				formattedXML.append(formatXMLFourthLineEmboss(lRewardFulfillmentTrackingReportHist.getEmbossDesc()));
			}
			if (lRewardFulfillmentTrackingReportHist.getAddressLine1() != null) {
				formattedXML.append(formatXMLAddressLine1(lRewardFulfillmentTrackingReportHist.getAddressLine1()));
			}
			if (lRewardFulfillmentTrackingReportHist.getAddressLine2() != null) {
				formattedXML.append(formatXMLAddressLine2(lRewardFulfillmentTrackingReportHist.getAddressLine2()));
			}
			if (lRewardFulfillmentTrackingReportHist.getCity() != null) {
				formattedXML.append(formatXMLCity(lRewardFulfillmentTrackingReportHist.getCity()));
			}
			if (lRewardFulfillmentTrackingReportHist.getState() != null) {
				formattedXML.append(formatXMLState(lRewardFulfillmentTrackingReportHist.getState()));
			}
			if (lRewardFulfillmentTrackingReportHist.getZip() != null) {
				formattedXML.append(formatXMLZip(lRewardFulfillmentTrackingReportHist.getZip()));
			}
			if (lRewardFulfillmentTrackingReportHist.getExtendedZip() != null) {
				formattedXML.append(formatXMLExtZip(lRewardFulfillmentTrackingReportHist.getExtendedZip()));
			}
			if (lRewardFulfillmentTrackingReportHist.getContributionAmount() != null) {
				formattedXML.append(formatXMLFundingAmt(Integer.toString(lRewardFulfillmentTrackingReportHist.getContributionAmount())));
			}
			if (lRewardFulfillmentTrackingReportHist.getTransactionMessageDesc() != null) {
				formattedXML.append(formatXMLTransactionDesc(lRewardFulfillmentTrackingReportHist.getTransactionMessageDesc()));
			}
			if (lRewardFulfillmentTrackingReportHist.getCarrierMessageDesc() != null && lRewardFulfillmentTrackingReportHist.getCarrierMessageDesc2() != null) {
				int maxLength = 40;
				String carrierMessageDesc = BPMUtils.rightPadString(lRewardFulfillmentTrackingReportHist.getCarrierMessageDesc(), maxLength);
				formattedXML.append(formatXMLCardCarrierMessage(carrierMessageDesc + lRewardFulfillmentTrackingReportHist.getCarrierMessageDesc2()));
			} else if (lRewardFulfillmentTrackingReportHist.getCarrierMessageDesc() != null) {
				formattedXML.append(formatXMLCardCarrierMessage(lRewardFulfillmentTrackingReportHist.getCarrierMessageDesc()));
			} 
			if (lRewardFulfillmentTrackingReportHist.getProgramParticipationStatus() != null) {
				formattedXML.append(formatXMLProgramParticipationStatus(lRewardFulfillmentTrackingReportHist.getProgramParticipationStatus()));
			}
			if (lRewardFulfillmentTrackingReportHist.getGroupNo() != null) {
				formattedXML.append(formatXMLGroupNo(lRewardFulfillmentTrackingReportHist.getGroupNo()));
			}
			if (lRewardFulfillmentTrackingReportHist.getGroupName() != null) {
				formattedXML.append(formatXMLGroupName(lRewardFulfillmentTrackingReportHist.getGroupName()));
			}
			if (lRewardFulfillmentTrackingReportHist.getPersonDemographicsID() != null) {
				formattedXML.append(formatXMLCachePersonID(lRewardFulfillmentTrackingReportHist.getPersonID()));
			}
			if (lRewardFulfillmentTrackingReportHist.getRewardTransHistID() != null) {
				formattedXML.append(formatXMLRewardTransHistID(lRewardFulfillmentTrackingReportHist.getRewardTransHistID()));
			}
			formattedXML.append(getOrderEndTag());
		

		return formattedXML.toString();
		
	}
	
	public static String createKnowYourClientSegment(RewardCardClientData pKnowYourClientData)
	{
		StringBuffer lKYCString = new StringBuffer();
		
		lKYCString.append(getKYCBeginTag());							
		
		lKYCString.append(formatKYCCompanyName(pKnowYourClientData.getCompanyName()));
		lKYCString.append(formatKYCContactName(pKnowYourClientData.getContactName()));
		lKYCString.append(formatKYCAddressLine1(pKnowYourClientData.getAddressLine1()));
		lKYCString.append(formatKYCAddressLine2(pKnowYourClientData.getAddressLine2()));
		lKYCString.append(formatKYCCity(pKnowYourClientData.getCity()));
		lKYCString.append(formatKYCState(pKnowYourClientData.getState()));
		lKYCString.append(formatKYCZip(pKnowYourClientData.getZip()));
		lKYCString.append(formatKYCTaxID(pKnowYourClientData.getTaxID()));
		
		lKYCString.append(getKYCEndTag());
		
		return lKYCString.toString();
	}
	 
	 
	private static String formatXMLFundingAmt(String fundingAmt) {
		String xmlFundingAmt = XMLIntelispendTags.START_FUNDING_AMT + fundingAmt + XMLIntelispendTags.END_FUNDING_AMT;
		return xmlFundingAmt;
	}
	
	private static String formatXMLFirstName(String firstName) {
		firstName = XMLIntelispendTags.START_FIRST_NAME + firstName + XMLIntelispendTags.END_FIRST_NAME;
		return firstName;
	}
	
	private static String formatXMLMiddleName(String middleInit) {
		middleInit = XMLIntelispendTags.START_MIDDLE_INIT + middleInit + XMLIntelispendTags.END_MIDDLE_INIT;
		return middleInit;
	}
	
	private static String formatXMLLastName(String lastName) {
		lastName = XMLIntelispendTags.START_LAST_NAME + lastName + XMLIntelispendTags.END_LAST_NAME;
		return lastName;
	}
	
	private static String formatXMLEmbossName(String embossName) {
		embossName = XMLIntelispendTags.START_CARD_EMBOSS_NAME + embossName + XMLIntelispendTags.END_CARD_EMBOSS_NAME;
		return embossName;
	}
	
	private static String formatXMLFourthLineEmboss(String fourthLineEmboss) {
		fourthLineEmboss = XMLIntelispendTags.START_FOURTH_LINE_EMBOSS + fourthLineEmboss + XMLIntelispendTags.END_FOURTH_LINE_EMBOSS;
		return fourthLineEmboss;
	}
	
	private static String formatXMLAddressLine1(String addressLine1) {
		addressLine1 = XMLIntelispendTags.START_ADDRESS_ELEMENT_1 + addressLine1 + XMLIntelispendTags.END_ADDRESS_ELEMENT_1;
		return addressLine1;
	}
	
	private static String formatXMLAddressLine2(String addressLine2) {
		addressLine2 = XMLIntelispendTags.START_ADDRESS_ELEMENT_2 + addressLine2 + XMLIntelispendTags.END_ADDRESS_ELEMENT_2;
		return addressLine2;
	}
	
	private static String formatXMLCity(String city) {
		city = XMLIntelispendTags.START_CITY + city + XMLIntelispendTags.END_CITY;
		return city;
	}
	

	private static String formatXMLState(String state) {
		state = XMLIntelispendTags.START_STATE + state + XMLIntelispendTags.END_STATE;
		return state;
	}
	
	private static String formatXMLZip(String zip) {
		zip = XMLIntelispendTags.START_ZIP_CODE + zip + XMLIntelispendTags.END_ZIP_CODE;
		return zip;
	}
	
	private static String formatXMLExtZip(String extZip) {
		extZip = XMLIntelispendTags.START_EXT_ZIP_CODE + extZip + XMLIntelispendTags.END_EXT_ZIP_CODE;
		return extZip;
	}
	
	
	
	private static String formatXMLTransactionDesc(String transactionDesc) {
        transactionDesc = XMLIntelispendTags.START_TRANS_DESC + transactionDesc + XMLIntelispendTags.END_TRANS_DESC;
		return transactionDesc;
	}
	
	private static String formatXMLCardCarrierMessage(String cardCarrierMessage) {
		cardCarrierMessage = XMLIntelispendTags.START_CARD_CARRIER_MESSAGE + cardCarrierMessage + XMLIntelispendTags.END_CARD_CARRIER_MESSAGE;
		return cardCarrierMessage;
	}
	
	
	private static String formatXMLProgramParticipationStatus(String programParticipationStatus) {
		programParticipationStatus = XMLIntelispendTags.START_PROGRAM_PARTICIPATION_STATUS + programParticipationStatus + XMLIntelispendTags.END_PROGRAM_PARTICIPATION_STATUS;
		return programParticipationStatus;
	}
	
	private static String formatXMLGroupNo(String groupNo) {
		groupNo = XMLIntelispendTags.START_GROUP_NUMBER + groupNo + XMLIntelispendTags.END_GROUP_NUMBER;
		return groupNo;
	}
	
	private static String formatXMLGroupName(String groupName) {
		//Group name going passed 17 characters.  Need to cut it off at 17 or Intelispend will reject the field attribute for being too long.
		//This is also true for Indicative Data 1, 2, and 4.  Group name is passed to indicative data 3.
		if (groupName.length() > 17) {
			groupName = groupName.substring(0, 17);
		} 
		
		groupName = XMLIntelispendTags.START_GROUP_NAME + groupName + XMLIntelispendTags.END_GROUP_NAME;
		return groupName;
	}
	
	private static String formatXMLCachePersonID(Integer cachePersonID) {
		String cachePersonIDStr = String.valueOf(cachePersonID);
		cachePersonIDStr = XMLIntelispendTags.START_PARTICIPANT_ID + cachePersonIDStr + XMLIntelispendTags.END_PARTICIPANT_ID;
		return cachePersonIDStr;
	}
	
	private static String formatXMLCardHolderPIDNumber(Integer rewardTransHistID) {
		
		String pidStr = String.valueOf(rewardTransHistID);
		pidStr = XMLIntelispendTags.START_CARDHOLDER_PID_NO + pidStr + XMLIntelispendTags.END_CARDHOLDER_PID_NO;
		return pidStr;
	}
	
	private static String formatXMLRewardTransHistID(Integer rewardTransHistID) {
		
		String trackingIDStr = String.valueOf(rewardTransHistID);
		
		if (trackingIDStr != null) {
			trackingIDStr = XMLIntelispendTags.START_FULFILLMENT_TRK_ID + trackingIDStr + XMLIntelispendTags.END_FULFILLMENT_TRK_ID;
		}
		return trackingIDStr;
	}
	
	public static String getOrderBeginTag() {
		return XMLIntelispendTags.START_ORDER_ITEM;
	}
	
	public static String getOrderEndTag() {
		return XMLIntelispendTags.END_ORDER_ITEM;
	}
	
	public static String getProductBeginTag() {
		return XMLIntelispendTags.START_PRODUCT;
	}
	
	public static String getProductEndTag() {
		return XMLIntelispendTags.END_PRODUCT;
	}
	
	
	public static String getKYCBeginTag() {
		return XMLIntelispendTags.KYC_ADDRESS_INFO;
	}
	
	public static String getKYCEndTag() {
		return XMLIntelispendTags.KYC_END_ADDRESS_INFO;
	}
	
	private static String formatKYCCompanyName(String companyName) 
	{
		StringBuffer lCompanyName = new StringBuffer();
		lCompanyName.append(XMLIntelispendTags.KYC_COMPANY_NAME);
		lCompanyName.append(companyName);
		lCompanyName.append(XMLIntelispendTags.KYC_END_COMPANY_NAME);				
		return lCompanyName.toString();
	}
	
	private static String formatKYCContactName(String contactName) 
	{
		StringBuffer lContactName = new StringBuffer();
		lContactName.append(XMLIntelispendTags.KYC_CONTACT_NAME);
		lContactName.append(contactName);
		lContactName.append(XMLIntelispendTags.KYC_END_CONTACT_NAME);				
		return lContactName.toString();
	}
	
	private static String formatKYCAddressLine1(String addressLine1) 
	{
		StringBuffer lAddressLine1 = new StringBuffer();
		lAddressLine1.append(XMLIntelispendTags.KYC_ADDRESS_LINE_1);
		lAddressLine1.append(addressLine1);
		lAddressLine1.append(XMLIntelispendTags.KYC_END_ADDRESS_LINE_1);				
		return lAddressLine1.toString();
	}
	
	private static String formatKYCAddressLine2(String addressLine2) 
	{
		StringBuffer lAddressLine2 = new StringBuffer();
		lAddressLine2.append(XMLIntelispendTags.KYC_ADDRESS_LINE_2);
		lAddressLine2.append(addressLine2);
		lAddressLine2.append(XMLIntelispendTags.KYC_END_ADDRESS_LINE_2);				
		return lAddressLine2.toString();
	}
	
	private static String formatKYCCity(String city) 
	{
		StringBuffer lCity = new StringBuffer();
		lCity.append(XMLIntelispendTags.KYC_CITY);
		lCity.append(city);
		lCity.append(XMLIntelispendTags.KYC_END_CITY);				
		return lCity.toString();
	}
	
	private static String formatKYCState(String state) 
	{
		StringBuffer lState = new StringBuffer();
		lState.append(XMLIntelispendTags.KYC_STATE);
		lState.append(state);
		lState.append(XMLIntelispendTags.KYC_END_STATE);				
		return lState.toString();
	}
	
	private static String formatKYCZip(String zip) 
	{
		StringBuffer lZip = new StringBuffer();
		lZip.append(XMLIntelispendTags.KYC_ZIP);
		lZip.append(zip);
		lZip.append(XMLIntelispendTags.KYC_END_ZIP);				
		return lZip.toString();
	}
	
	private static String formatKYCTaxID(String taxID) 
	{
		StringBuffer lTaxID = new StringBuffer();
		lTaxID.append(XMLIntelispendTags.KYC_TAX_ID);
		lTaxID.append(taxID);
		lTaxID.append(XMLIntelispendTags.KYC_END_TAX_ID);				
		return lTaxID.toString();
	}
}

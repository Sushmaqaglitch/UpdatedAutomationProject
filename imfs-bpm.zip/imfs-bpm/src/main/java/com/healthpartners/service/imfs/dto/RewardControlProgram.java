package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.sql.Date;
import java.util.Collection;

public class RewardControlProgram implements Serializable
{	
	static final long serialVersionUID = 0L;

	private Integer controlProgramID;
	private Integer programID;
	private String  groupNo;
	private String  siteNo;
	private String  groupName;
	private String  siteName;
	private Integer incentiveOptionID;
	private Integer totalRewardCardsOrdered;
	private Integer totalRewardCardsRejected;
	private String runFrequency;
	private String quoteNo;
	private boolean programProcessedToday;
	private int insertRewardFulfillmentCount;
	private int rewardFulfillmentCountToSendToVendor;
	private Date programIncentiveOptionEffectiveDate;
	private Date programIncentiveOptionEndDate;
	
	
        
    public RewardControlProgram()
    {
    	super();
    }



	
	

	public Integer getControlProgramID() {
		return controlProgramID;
	}


	public void setControlProgramID(Integer controlProgramID) {
		this.controlProgramID = controlProgramID;
	}






	public Integer getProgramID() {
		return programID;
	}



	public void setProgramID(Integer programID) {
		this.programID = programID;
	}

   
	
   


	public String getGroupNo() {
		return groupNo;
	}






	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}






	public String getSiteNo() {
		return siteNo;
	}



	


	public void setSiteNo(String siteNo) {
		this.siteNo = siteNo;
	}



	


	public String getGroupName() {
		return groupName;
	}






	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}






	public String getSiteName() {
		return siteName;
	}






	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}


	



	public Integer getIncentiveOptionID() {
		return incentiveOptionID;
	}






	public void setIncentiveOptionID(Integer incentiveOptionID) {
		this.incentiveOptionID = incentiveOptionID;
	}






	public Integer getTotalRewardCardsOrdered() {
		return totalRewardCardsOrdered;
	}






	public void setTotalRewardCardsOrdered(Integer totalRewardCardsOrdered) {
		this.totalRewardCardsOrdered = totalRewardCardsOrdered;
	}






	public Integer getTotalRewardCardsRejected() {
		return totalRewardCardsRejected;
	}






	public void setTotalRewardCardsRejected(Integer totalRewardCardsRejected) {
		this.totalRewardCardsRejected = totalRewardCardsRejected;
	}






	public String getRunFrequency() {
		return runFrequency;
	}






	public void setRunFrequency(String runFrequency) {
		this.runFrequency = runFrequency;
	}






	public String getQuoteNo() {
		return quoteNo;
	}






	public void setQuoteNo(String quoteNo) {
		this.quoteNo = quoteNo;
	}






	public boolean isProgramProcessedToday() {
		return programProcessedToday;
	}






	public void setProgramProcessedToday() {
		this.programProcessedToday = true;
	}


	public int getInsertRewardFulfillmentCount() {
		return insertRewardFulfillmentCount;
	}



	public void setInsertRewardFulfillmentCount(int insertRewardFulfillmentCount) {
		this.insertRewardFulfillmentCount = insertRewardFulfillmentCount;
	}



	public int getRewardFulfillmentCountToSendToVendor() {
		return rewardFulfillmentCountToSendToVendor;
	}



	public void setRewardFulfillmentCountToSendToVendor(
			int rewardFulfillmentCountToSendToVendor) {
		this.rewardFulfillmentCountToSendToVendor = rewardFulfillmentCountToSendToVendor;
	}



	public void setProgramProcessedToday(boolean programProcessedToday) {
		this.programProcessedToday = programProcessedToday;
	}






	public Date getProgramIncentiveOptionEffectiveDate() {
		return programIncentiveOptionEffectiveDate;
	}






	public void setProgramIncentiveOptionEffectiveDate(
			Date programIncentiveOptionEffectiveDate) {
		this.programIncentiveOptionEffectiveDate = programIncentiveOptionEffectiveDate;
	}






	public Date getProgramIncentiveOptionEndDate() {
		return programIncentiveOptionEndDate;
	}






	public void setProgramIncentiveOptionEndDate(Date programIncentiveOptionEndDate) {
		this.programIncentiveOptionEndDate = programIncentiveOptionEndDate;
	}

	

	
	
    
	
}

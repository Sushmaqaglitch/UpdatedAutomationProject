package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.sql.Date;
import java.util.Calendar;

public class MemberActivity implements Serializable
{	
	static final long serialVersionUID = 0L;

	
	private ActivityDefinition activityDefinition;
	
	private Integer activityEventLogID;
	
	// activityTypeCodeID really belongs in the ActivityDefinition. Added here because ActivityDefinition
	// is used in the web service and changing it would require changes in Web Portal and HCSS.
	private Integer activityTypeCodeID;
	
//	 ActivityDefinition that has been completed or in progress attributes.
	private String registrationID;
	private Calendar registrationDate;
	private Calendar completionDate;
	private String qualificationStatus;
	private Calendar qualificationDate;
	
	private Integer businessProgramID;
	
	private Integer groupID;
	
	private Integer contractNumber;
	
	private Integer incentiveOptionID;
	
	private Integer businessProgramIncentiveOptionID;
	
	private Integer benefitPackageID;
	
	private String memberID;
	
	private Integer personID;
	
	private Integer personDemographicsID;
	
	private Integer collectionID;
	
	private Calendar coverageEffectiveDate;
	
	private GenericStatusType activityStatus;	
	
	private String authPromoCode;
	
	private Integer contributionAmt;
	
	private GenericStatusType[] statusHistory;
	
	private boolean ableToComplete;
	
	private Boolean activityCompletedWithinTimePeriod;
	
	private Integer personProgramActivityStatusID;
	
	private String groupNo;
	
	private String siteNo;
	
	private String groupName;
	
	private String siteName;
	
	private String reasonDesc;
	
	private String statusOutcome;
	
	private String sourceSystemID;
	
	private Integer qualificationCheckmarkID;
	
	
		
	public MemberActivity()
	{
		super();
	}
	
	

	public Integer getActivityEventLogID() {
		return activityEventLogID;
	}



	public void setActivityEventLogID(Integer activityEventLogID) {
		this.activityEventLogID = activityEventLogID;
	}



	public ActivityDefinition getActivity() {
		return activityDefinition;
	}

	public void setActivity(ActivityDefinition activityDefinition) {
		this.activityDefinition = activityDefinition;
	}

	public GenericStatusType getActivityStatus() {
		return activityStatus;
	}


	public void setActivityStatus(GenericStatusType activityStatus) {
		this.activityStatus = activityStatus;
	}


	public Calendar getCompletionDate() {
		return completionDate;
	}


	public void setCompletionDate(Calendar completionDate) {
		this.completionDate = completionDate;
	}


	public Calendar getQualificationDate() {
		return qualificationDate;
	}


	public void setQualificationDate(Calendar qualificationDate) {
		this.qualificationDate = qualificationDate;
	}


	public String getQualificationStatus() {
		return qualificationStatus;
	}


	public void setQualificationStatus(String qualificationStatus) {
		this.qualificationStatus = qualificationStatus;
	}


	public Calendar getRegistrationDate() {
		return registrationDate;
	}


	public void setRegistrationDate(Calendar registrationDate) {
		this.registrationDate = registrationDate;
	}


	public String getRegistrationID() {
		return registrationID;
	}


	public void setRegistrationID(String registrationID) {
		this.registrationID = registrationID;
	}	

	public GenericStatusType[] getStatusHistory() {
		return statusHistory;
	}

	public void setStatusHistory(GenericStatusType[] statusHistory) {
		this.statusHistory = statusHistory;
	}

	public String getAuthPromoCode() {
		return authPromoCode;
	}

	public void setAuthPromoCode(String authPromoCode) {
		this.authPromoCode = authPromoCode;
	}	
	
	

	public Integer getContributionAmt() {
		return contributionAmt;
	}

	public void setContributionAmt(Integer contributionAmt) {
		this.contributionAmt = contributionAmt;
	}

	public Integer getBusinessProgramID() {
		return businessProgramID;
	}

	public void setBusinessProgramID(Integer businessProgramID) {
		this.businessProgramID = businessProgramID;
	}
	
	

	public Integer getGroupID() {
		return groupID;
	}

	public void setGroupID(Integer groupID) {
		this.groupID = groupID;
	}

	public ActivityDefinition getActivityDefinition() {
		return activityDefinition;
	}

	public void setActivityDefinition(ActivityDefinition activityDefinition) {
		this.activityDefinition = activityDefinition;
	}

	public Integer getContractNumber() {
		return contractNumber;
	}

	public void setContractNumber(Integer contractNumber) {
		this.contractNumber = contractNumber;
	}

	
	
	public Integer getIncentiveOptionID() {
		return incentiveOptionID;
	}

	public void setIncentiveOptionID(Integer incentiveOptionID) {
		this.incentiveOptionID = incentiveOptionID;
	}

	public Integer getBusinessProgramIncentiveOptionID() {
		return businessProgramIncentiveOptionID;
	}

	public void setBusinessProgramIncentiveOptionID(
			Integer businessProgramIncentiveOptionID) {
		this.businessProgramIncentiveOptionID = businessProgramIncentiveOptionID;
	}
	
	public Integer getBenefitPackageID() {
		return benefitPackageID;
	}

	public void setBenefitPackageID(Integer benefitPackageID) {
		this.benefitPackageID = benefitPackageID;
	}
	
	
	

	public String getMemberID() {
		return memberID;
	}

	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}

	public Integer getPersonID() {
		return personID;
	}

	public void setPersonID(Integer personID) {
		this.personID = personID;
	}

	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}

	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}

	public Integer getCollectionID() {
		return collectionID;
	}

	public void setCollectionID(Integer collectionID) {
		this.collectionID = collectionID;
	}

	

	public Calendar getCoverageEffectiveDate() {
		return coverageEffectiveDate;
	}

	public void setCoverageEffectiveDate(Calendar coverageEffectiveDate) {
		this.coverageEffectiveDate = coverageEffectiveDate;
	}

	public final boolean isAbleToComplete() {
		return ableToComplete;
	}

	public final void setAbleToComplete(boolean ableToComplete) {
		this.ableToComplete = ableToComplete;
	}

	public final Integer getActivityTypeCodeID() {
		return activityTypeCodeID;
	}

	public final void setActivityTypeCodeID(Integer activityTypeCodeID) {
		this.activityTypeCodeID = activityTypeCodeID;
	}

	public Boolean getActivityCompletedWithinTimePeriod() {
		return activityCompletedWithinTimePeriod;
	}

	public void setActivityCompletedWithinTimePeriod(
			Boolean activityCompletedWithinTimePeriod) {
		this.activityCompletedWithinTimePeriod = activityCompletedWithinTimePeriod;
	}

	public Integer getPersonProgramActivityStatusID() {
		return personProgramActivityStatusID;
	}

	public void setPersonProgramActivityStatusID(
			Integer personProgramActivityStatusID) {
		this.personProgramActivityStatusID = personProgramActivityStatusID;
	}

	public String getGroupNo() {
		return groupNo;
	}

	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}

	public String getSiteNo() {
		return siteNo;
	}

	public void setSiteNo(String siteNo) {
		this.siteNo = siteNo;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getReasonDesc() {
		return reasonDesc;
	}

	public void setReasonDesc(String reasonDesc) {
		this.reasonDesc = reasonDesc;
	}

	public String getStatusOutcome() {
		return statusOutcome;
	}

	public void setStatusOutcome(String statusOutcome) {
		this.statusOutcome = statusOutcome;
	}

	public String getSourceSystemID() {
		return sourceSystemID;
	}

	public void setSourceSystemID(String sourceSystemID) {
		this.sourceSystemID = sourceSystemID;
	}

	public Integer getQualificationCheckmarkID() {
		return qualificationCheckmarkID;
	}

	public void setQualificationCheckmarkID(Integer qualificationCheckmarkID) {
		this.qualificationCheckmarkID = qualificationCheckmarkID;
	}


	
}

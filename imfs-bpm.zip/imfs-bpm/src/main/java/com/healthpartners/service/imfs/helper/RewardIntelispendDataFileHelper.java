package com.healthpartners.service.imfs.helper;
	
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dao.PersonDAO;
import com.healthpartners.service.imfs.dto.CSVTokens;
import com.healthpartners.service.imfs.dto.RewardCardError;
import com.healthpartners.service.imfs.dto.RewardIntelispendOrdered;
import com.healthpartners.service.imfs.dto.RewardIntelispendShipped;

/**
 * This class parsses data file(text) for employer activities
 * 
 * @author mxthoutam
 * 
 */
public class RewardIntelispendDataFileHelper {
		ArrayList<RewardCardError> rewardCardShippedDetailErrors = new ArrayList<RewardCardError>();
		ArrayList<RewardCardError> rewardCardOrderDetailErrors = new ArrayList<RewardCardError>();
		PersonDAO personDAO;
	
	/**
	 * read and format csv shipped data file
	 *
	 * @throws IOException
	 */
	public Collection<RewardIntelispendShipped> readNFormatCSVShippedFile(String inPath, Integer shippedStatusID) throws IOException, Exception {
		
	    
        Collection<CSVTokens> csvTokenRecs = BPMUtils.readNParseCSVFile(inPath);
        
        Collection<RewardIntelispendShipped> lRewardIntelispendShipped = shippedTokenMapper(csvTokenRecs, shippedStatusID);
		
		return lRewardIntelispendShipped;
	}
	
	/**
	 * read and format csv shipped data file
	 *
	 * @throws IOException
	 */
	public Collection<RewardIntelispendOrdered> readNFormatCSVOrderedFile(String inPath, Integer shippedStatusID) throws IOException, Exception {
		
        Collection<CSVTokens> csvTokenRecs = BPMUtils.readNParseCSVFile(inPath);
        
        Collection<RewardIntelispendOrdered> lRewardIntelispendOrdered = orderedTokenMapper(csvTokenRecs, shippedStatusID);
        
		
		return lRewardIntelispendOrdered;
	}
	
	private Collection<RewardIntelispendShipped> shippedTokenMapper( Collection<CSVTokens> csvTokenRecs, Integer shippedStatusID) throws Exception {
		
		ArrayList<RewardIntelispendShipped> lRewardIntelispendShippedArray = new ArrayList<RewardIntelispendShipped>();
		
		Iterator<CSVTokens> iter = csvTokenRecs.iterator();
		
		//iterate through block of raw shipped data.
		while (iter.hasNext()) {
			CSVTokens csvTokenColumns =  iter.next();
			
			Collection<String> columns = csvTokenColumns.getCsvTokenColumns();
			
			RewardIntelispendShipped lRewardIntelispendShipped = new RewardIntelispendShipped();
			
			boolean tooManyColumns = false;
			int columNo = 0;
			String column = null;
			Iterator<String> iter2 = columns.iterator();
			//iterate through the columns (tokens) while mapping to the IntelispendShipped DTO
			while (iter2.hasNext()) {
				
				column = iter2.next();
				
				switch (columNo) {
					case 0: lRewardIntelispendShipped.setQuoteID(column);
							break;
					case 1: lRewardIntelispendShipped.setOrderDate(column);
					 		break;
					case 2: lRewardIntelispendShipped.setOrderNumber(column);
					 		break;
					case 3: lRewardIntelispendShipped.setCardNumberMasked(column);
					 		break;
					case 4: lRewardIntelispendShipped.setProxyCardNumber(column);
			 				break;
					case 5: lRewardIntelispendShipped.setAmount(column);
					 		break;
					case 6: lRewardIntelispendShipped.setPidNumber(column);
			 				break;
					case 7: lRewardIntelispendShipped.setShipDate(column);
					 		break;
					case 8: lRewardIntelispendShipped.setShippedVia(column);
			 				break;
					case 9: lRewardIntelispendShipped.setShipTrackingNumber(column);
	 						break;
					case 10: lRewardIntelispendShipped.setLastName(column);
					 		break;
					case 11: lRewardIntelispendShipped.setFirstName(column);
					 		break;
					case 12: lRewardIntelispendShipped.setGroupNumberIndicativeData1(column);
			 				break; 
					case 13: lRewardIntelispendShipped.setGroupNameIndicativeData2(column);
	 						break; 
					case 14: lRewardIntelispendShipped.setPersonIDIndicativeData3(column);
							break; 
					case 15: lRewardIntelispendShipped.setRewardFulfillHistIDIndicativeData4(column);
							break; 
					case 16: lRewardIntelispendShipped.setIndicativeData5(column);
							break; 
					 		
					case 17: lRewardIntelispendShipped.setAddressLine1(column);
					 		break;
					case 18: lRewardIntelispendShipped.setAddressLine2(column);
					 		break;
					case 19: lRewardIntelispendShipped.setCity(column);
					 		break;
					case 20: lRewardIntelispendShipped.setState(column);
					 		break;
					case 21: lRewardIntelispendShipped.setPostalCode(column);
					 		break;
					case 22: lRewardIntelispendShipped.setRewardCardType(column);
						break;
					case 23: lRewardIntelispendShipped.setShipReportFileName(column);
			 				break;
					
					
					
					default: tooManyColumns = true;
                    		break;
				}
				
				columNo++;
			}
			
			if (tooManyColumns) {
				throw new Exception("RewardIntelispendDataFileHelper.shippedTokenMapper: too many columns(nodes) being sent by Intelispend.  File will not be processed.");
			}
			
			lRewardIntelispendShipped.setProcessStatusCode(shippedStatusID);
			
			if (lRewardIntelispendShipped.getQuoteID() == null || lRewardIntelispendShipped.getQuoteID().equals("QuoteID")) {
				//bypass headers from shipped file
			} else {
				editRewardCardShippedDetail(lRewardIntelispendShipped);
				lRewardIntelispendShippedArray.add(lRewardIntelispendShipped);
			}
		}
		
		return lRewardIntelispendShippedArray;
	}
	
	private Collection<RewardIntelispendOrdered> orderedTokenMapper( Collection<CSVTokens> csvTokenRecs, Integer shippedStatusID) throws Exception{
		
		ArrayList<RewardIntelispendOrdered> lRewardIntelispendOrderedArray = new ArrayList<RewardIntelispendOrdered>();
		
		Iterator<CSVTokens> iter = csvTokenRecs.iterator();
		
		//iterate through block of raw shipped data.
		while (iter.hasNext()) {
			CSVTokens csvTokenColumns =  iter.next();
			
			Collection<String> columns = csvTokenColumns.getCsvTokenColumns();
			
			RewardIntelispendOrdered lRewardIntelispendOrdered = new RewardIntelispendOrdered();
			
			boolean tooManyColumns = false;
			int columNo = 0;
			String column = null;
			Iterator<String> iter2 = columns.iterator();
			//iterate through the columns (tokens) while mapping to the IntelispendShipped DTO
			while (iter2.hasNext()) {
				
				column = iter2.next();
				
				switch (columNo) {
				case 0: lRewardIntelispendOrdered.setQuoteID(column);
				 		break;
				case 1: lRewardIntelispendOrdered.setCartName(column);
				 		break;
				case 2: lRewardIntelispendOrdered.setOrderDate(column);
		 				break;
				case 3: lRewardIntelispendOrdered.setOrderNumber(column);
 						break;
				case 4: lRewardIntelispendOrdered.setAmount(column);
				 		break;
				case 5: lRewardIntelispendOrdered.setPidNumber(column);
				 		break;
				case 6: lRewardIntelispendOrdered.setShipDate(column);
				 		break;
				case 7: lRewardIntelispendOrdered.setLastName(column);
				 		break;
				case 8: lRewardIntelispendOrdered.setFirstName(column);
				 		break;
				case 9: lRewardIntelispendOrdered.setCardNumberMasked(column);
		 				break;
				case 10: lRewardIntelispendOrdered.setProxyCardNumber(column);
 						break;
				case 11: lRewardIntelispendOrdered.setAddressLine1(column);
				 		break;
				case 12: lRewardIntelispendOrdered.setAddressLine2(column);
				 		break;
				case 13: lRewardIntelispendOrdered.setCity(column);
				 		break;
				case 14: lRewardIntelispendOrdered.setState(column);
				 		break;
				case 15: lRewardIntelispendOrdered.setPostalCode(column);
				 		break;
				case 16: lRewardIntelispendOrdered.setGroupNumberIndicativeData1(column);
		 				break;
				case 17: lRewardIntelispendOrdered.setGroupNameIndicativeData2(column);
 						break;
				case 18: lRewardIntelispendOrdered.setPersonIDIndicativeData3(column);
						break;
				case 19: lRewardIntelispendOrdered.setRewardFulfillHistIDIndicativeData4(column);
						break;
				case 20: lRewardIntelispendOrdered.setIndicativeData5(column);
						break;
				case 21: lRewardIntelispendOrdered.setOrderReportFileName(column);
 						break;
				
				
				default: tooManyColumns = true;
                		break;
			}
				columNo++;
			}
			
			if (tooManyColumns) {
				throw new Exception("RewardIntelispendDataFileHelper.orderedTokenMapper: too many columns(nodes) being sent by Intelispend.  File will not be processed.");
			}
			
			lRewardIntelispendOrdered.setProcessStatusCode(shippedStatusID);
			
			if (lRewardIntelispendOrdered.getQuoteID() == null || lRewardIntelispendOrdered.getQuoteID().equals("quote_number")) {
				//bypass headers from shipped file
			} else {
				editRewardCardOrderedDetail(lRewardIntelispendOrdered);
				lRewardIntelispendOrderedArray.add(lRewardIntelispendOrdered);
			}
			
		}
		
		return lRewardIntelispendOrderedArray;
	}
	
	private void editRewardCardOrderedDetail(RewardIntelispendOrdered lRewardIntelispendOrdered) {
		RewardCardError lRewardCardError = new RewardCardError();
		
		//person id must be numeric.  Occasionaly business user will enter a request into an online 
	    //website requesting a reward card to be ordered.  If they forget to enter the Cache person id or its not numeric,
	    //it needs to be handled gracefully by showing it in a detail report and then failing the job since
	    //the record cannot be loaded into BPM.
		if (lRewardIntelispendOrdered.getPersonIDIndicativeData3() == null || lRewardIntelispendOrdered.getPersonIDIndicativeData3().isEmpty()) {
			String dataElement = "PersonIDIndicativeData3";
			String errorReason = "value is missing.";
			lRewardCardError.setDataElement(dataElement);
			lRewardCardError.setErrorReason(errorReason);
			lRewardCardError.setRewardIntelispendOrdered(lRewardIntelispendOrdered);
			this.rewardCardOrderDetailErrors.add(lRewardCardError);   
		} else if (!BPMUtils.isValueInteger(lRewardIntelispendOrdered.getPersonIDIndicativeData3())) {
					String dataElement = "PersonIDIndicativeData3";
					String errorReason = "value is not numeric.";
					lRewardCardError.setDataElement(dataElement);
					lRewardCardError.setErrorReason(errorReason);
					lRewardCardError.setRewardIntelispendOrdered(lRewardIntelispendOrdered);
					this.rewardCardOrderDetailErrors.add(lRewardCardError);
		}
		
		Integer personDemographicsID = convertCachePersonIdToPersonDemographicsID(lRewardIntelispendOrdered.getPersonIDIndicativeData3());
		if (personDemographicsID == null) {
			String dataElement = "PersonIDIndicativeData3";
			String errorReason = "Cache Person ID is invalid.  Not found in person demographics table.";
			lRewardCardError.setDataElement(dataElement);
			lRewardCardError.setErrorReason(errorReason);
			lRewardCardError.setRewardIntelispendOrdered(lRewardIntelispendOrdered);
			this.rewardCardOrderDetailErrors.add(lRewardCardError);
		}
		
	}
	
	private void editRewardCardShippedDetail(RewardIntelispendShipped lRewardIntelispendShipped) {
		RewardCardError lRewardCardError = new RewardCardError();
		
		//person id must be numeric.  Occasionaly business user will enter a request into an online 
	    //website requesting a reward card to be ordered.  If they forget to enter the Cache person id or its not numeric,
	    //it needs to be handled gracefully by showing it in a detail report and then failing the job since
	    //the record cannot be loaded into BPM.
		if (lRewardIntelispendShipped.getPersonIDIndicativeData3() == null || lRewardIntelispendShipped.getPersonIDIndicativeData3().isEmpty()) {
			String dataElement = "PersonIDIndicativeData3";
			String errorReason = "value is missing.";
			lRewardCardError.setDataElement(dataElement);
			lRewardCardError.setErrorReason(errorReason);
			lRewardCardError.setRewardIntelispendShipped(lRewardIntelispendShipped);
			this.rewardCardShippedDetailErrors.add(lRewardCardError);   
		} else if (!BPMUtils.isValueInteger(lRewardIntelispendShipped.getPersonIDIndicativeData3())) {
					String dataElement = "PersonIDIndicativeData3";
					String errorReason = "value is not numeric.";
					lRewardCardError.setDataElement(dataElement);
					lRewardCardError.setErrorReason(errorReason);
					lRewardCardError.setRewardIntelispendShipped(lRewardIntelispendShipped);
					this.rewardCardShippedDetailErrors.add(lRewardCardError);
		}
		
		Integer personDemographicsID = convertCachePersonIdToPersonDemographicsID(lRewardIntelispendShipped.getPersonIDIndicativeData3());
		if (personDemographicsID != null) {
			lRewardIntelispendShipped.setPersonDemographicsID(personDemographicsID);	
		} else {
			String dataElement = "PersonIDIndicativeData3";
			String errorReason = "Cache Person ID is invalid.  Not found in person demographics table.";
			lRewardCardError.setDataElement(dataElement);
			lRewardCardError.setErrorReason(errorReason);
			lRewardCardError.setRewardIntelispendShipped(lRewardIntelispendShipped);
			this.rewardCardShippedDetailErrors.add(lRewardCardError);
		}
	}
	/*
	 * This method translates the CachePersonId or Member Id to the person demographics id.  Person demographics id is required
	 * when writing back to the reward fulfillment table.  Here's a little background: Some of the reward card
	 * is entered manually through a web based application called Portico hosted by the vendor Blackhawk/Intelispend.  If the person id or member id
	 * number is entered incorrectly, the lookup against the person demographics table will return a null value.  This will kick out the transaction
	 * in error with a reason of bad person id entered by end user.  This will fail all the transactions from the file.
	 */
	private Integer convertCachePersonIdToPersonDemographicsID(String personIDIndicativeData3) {
		
    	Integer personDemographicsID = personDAO.getPersonDemographicsIDFromPersonID(personIDIndicativeData3);
    	
    	if (personDemographicsID == null) {
    		String memberId = personIDIndicativeData3;
    		personDemographicsID = personDAO.getPersonID(memberId);
    	}
    	
    	return personDemographicsID;
	}
	

	public ArrayList<RewardCardError> getRewardCardShippedDetailErrors() {
		return rewardCardShippedDetailErrors;
	}

	public ArrayList<RewardCardError> getRewardCardOrderDetailErrors() {
		return rewardCardOrderDetailErrors;
	}
	
	public void setPersonDAO(PersonDAO personDAO) {
		this.personDAO = personDAO;
	}

	
	
}
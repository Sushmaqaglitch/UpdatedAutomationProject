package com.healthpartners.service.imfs.dto;

import com.healthpartners.service.imfs.common.BPMConstants;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;


/**
 * @author tjquist
 * 
 */
public class MemberTO extends BaseDTO {

	static final long serialVersionUID = 0L;

	private Integer programID;
	
	private String memberID;

	private Integer personID;

	private Integer PHpersonID;

	private java.sql.Date dateOfBirth;


	private Collection<MemberContractProgramTO> memberContractPrograms;
	
	private Collection<MemberContractProgramTO> memberTermedContractPrograms;
	
	private Collection<PersonProgramActivityIncentiveStatus> activityBasedIncentivesForTermedSite;
	
	private Collection<PersonProgramActivityIncentiveStatus> memberBasedIncentivesForTermedSite;
	
	private Collection<PersonProgramActivityIncentiveStatus> contractBasedIncentivesForTermedSite;
	
	private Collection<QualificationOverride> memberExemptions;
	
	

	/**
	 * 
	 */
	public MemberTO() {
		super();
	}

	/**
	 * @return the memberContractPrograms
	 */
	public Collection<MemberContractProgramTO> getMemberContractPrograms() {
		return memberContractPrograms;
	}

	/**
	 * @param memberContractPrograms
	 *            the memberContractPrograms to set
	 */
	public void setMemberContractPrograms(
			Collection<MemberContractProgramTO> memberContractPrograms) {
		this.memberContractPrograms = memberContractPrograms;
	}

	/**
	 * @return the programID
	 */
	public Integer getProgramID() {
		return programID;
	}
	
	/**
	 * @param programID
	 *            the programID to set
	 */
	public void setProgramID(Integer programID) {
		this.programID = programID;
	}

	/**
	 * @return the memberID
	 */
	public String getMemberID() {
		return memberID;
	}

	/**
	 * @param memberID
	 *            the memberID to set
	 */
	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}

	/**
	 * @return the personID
	 */
	public Integer getPersonID() {
		return personID;
	}

	/**
	 * @param personID
	 *            the personID to set
	 */
	public void setPersonID(Integer personID) {
		this.personID = personID;
	}

	public Integer getPHpersonID() {
		return PHpersonID;
	}

	public void setPHpersonID(Integer PHpersonID) {
		this.PHpersonID = PHpersonID;
	}

	public java.sql.Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(java.sql.Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	// Utility Methods
	/**
	 * @param businessProgramID
	 */
	public MemberContractProgramTO getMemberContractProgramTO(
			Integer businessProgramID) {

		MemberContractProgramTO memberContractProgram = null;

		if (memberContractPrograms != null && businessProgramID != null) {
			Iterator<MemberContractProgramTO> itr = memberContractPrograms
					.iterator();
			while (itr.hasNext()) {
				memberContractProgram = itr.next();
				if (memberContractProgram != null
						&& memberContractProgram.getBusinessProgramID() != null
						&& businessProgramID.intValue() == memberContractProgram
								.getBusinessProgramID().intValue()) {
					break;
				}
				else
				{
					// memberContractProgram is still pointing to the current value of the
					// iterator. Set it to null before going through the loop again. 
					memberContractProgram = null;
				}
			}
		}
		
		if(memberContractProgram == null)
		{
			memberContractProgram = getMemberTermedContractProgramTO(businessProgramID);
		}
				
		return memberContractProgram;
	}
	
	// Utility Methods
		/**
		 * This method used when only persons with termed contracts exist.  Addresses retro activity incentives.
		 * See EV46192.
		 * @param businessProgramID
		 */
		public MemberContractProgramTO getMemberTermedContractProgramTO(
				Integer businessProgramID) {

			MemberContractProgramTO memberTermedContractProgram = null;

			if (memberTermedContractPrograms != null && businessProgramID != null) {
				Iterator<MemberContractProgramTO> itr = this.memberTermedContractPrograms
						.iterator();
				while (itr.hasNext()) {
					memberTermedContractProgram = itr.next();
					if (memberTermedContractProgram != null
							&& memberTermedContractProgram.getBusinessProgramID() != null
							&& businessProgramID.intValue() == memberTermedContractProgram
									.getBusinessProgramID().intValue()) {
						break;
					}
					else
					{
						// memberTermedContractProgram is still pointing to the current value of the
						// iterator. Set it to null before going through the loop again. 
						memberTermedContractProgram = null;
					}
				}
			}

			return memberTermedContractProgram;
		}

	/**
	 * @return the memberStatusCodeValue
	 */
	public String getMemberStatusCodeValue(Integer businessProgramID) {
		String memberStatusCodeValue = null;

		GenericStatusType memberStatus = getMemberStatus(businessProgramID);
		if (memberStatus != null) {
			memberStatusCodeValue = memberStatus.getStatusCodeValue();
		}

		return memberStatusCodeValue;
	}

	/**
	 * @return the memberStatusCodevalue
	 */
	public GenericStatusType getMemberStatus(Integer businessProgramID) {
		GenericStatusType memberStatus = null;

		MemberContractProgramTO programTo = getMemberContractProgramTO(businessProgramID);
		if (programTo != null) {
			memberStatus = programTo.getMemberStatus();
		}

		return memberStatus;
	}

	/**
	 * @return the contractStatusCodeValue
	 */
	public String getContractStatusCodeValue(Integer businessProgramID) {

		String contractStatusCodeValue = null;

		GenericStatusType contractStatus = getContractStatus(businessProgramID);
		if (contractStatus != null) {
			contractStatusCodeValue = contractStatus.getStatusCodeValue();
		}

		return contractStatusCodeValue;
	}
	
	/**
	 * 
	 * @param businessProgramID
	 * @return
	 */
	public String getContractIncentiveStatusCodeValue(Integer businessProgramID) 
	{
		String contractStatusCodeValue = null;

		GenericStatusType contractStatus = getContractStatus(businessProgramID);
		if (contractStatus != null) {
			contractStatusCodeValue = contractStatus.getStatusCodeValue();
		}

		return contractStatusCodeValue;
	}

	/**
	 * @return the contractStatus
	 */
	public GenericStatusType getContractStatus(Integer businessProgramID) {
		GenericStatusType contractStatus = null;

		MemberContractProgramTO programTo = getMemberContractProgramTO(businessProgramID);
		if (programTo != null && programTo.getMemberContract() != null
				&& programTo.getMemberContract().getContract() != null) {
			contractStatus = programTo.getMemberContract().getContract()
					.getContractStatus();
		}

		return contractStatus;
	}

	/**
	 * 
	 * @param businessProgramID
	 * @return
	 */
	public ContractTO getMemberContract(Integer businessProgramID) {
		ContractTO memberContract = null;		
		
		MemberContractProgramTO programTo = getMemberContractProgramTO(businessProgramID);
		if (programTo != null) {
			memberContract = programTo.getMemberContract();
		}
		
		return memberContract;
	}

	/**
	 * 
	 * @param businessProgramID
	 * @return
	 */
	public String getRelationshipToContractHolder(Integer businessProgramID) {
		String relationshipToContractHolder = null;

		MemberContractProgramTO programTo = getMemberContractProgramTO(businessProgramID);
		if (programTo != null && programTo.getMemberContract() != null) {
			relationshipToContractHolder = programTo.getMemberContract()
					.getRelationshipToPolicyHolder();
		}

		return relationshipToContractHolder;
	}
	
	/**
	 * Return the relationship code. Currently 1 = Policy Holder, 2 = Spouse, etc...
	 * For the JourneyWell expansion project, relationship code will also include non-member.
	 * 
	 * @param businessProgramID
	 * @return
	 */
	public Integer getRelationshipCode(Integer businessProgramID)
	{
		MemberContractProgramTO programTo = getMemberContractProgramTO(businessProgramID);
		if (programTo != null && programTo.getMemberContract() != null) {
			return programTo.getMemberContract().getRelationshipCode();
		}
		
		return -1;
	}

	public Calendar getContractDateOfPolicyHolder(Integer businessProgramID) {
		Calendar contractDateOfPolicyHolder = null;

		MemberContractProgramTO programTo = getMemberContractProgramTO(businessProgramID);
		if (programTo != null && programTo.getMemberContract() != null) {
			contractDateOfPolicyHolder = programTo.getMemberContract()
					.getContractDateOfPolicyHolder();
		}

		return contractDateOfPolicyHolder;
	}

	public Calendar getContractDateOfMember(Integer businessProgramID) {
		Calendar contractDateOfMember = null;

		MemberContractProgramTO programTo = getMemberContractProgramTO(businessProgramID);
		if (programTo != null && programTo.getMemberContract() != null
				&& programTo.getMemberContract().getContract() != null) {
			contractDateOfMember = programTo.getMemberContract().getContract()
					.getContractEffectiveDate();
		}

		return contractDateOfMember;
	}

	public Calendar getContractEndDateOfMember(Integer businessProgramID) {
		Calendar contractDateOfMember = null;

		MemberContractProgramTO programTo = getMemberContractProgramTO(businessProgramID);
		if (programTo != null && programTo.getMemberContract() != null
				&& programTo.getMemberContract().getContract() != null) {
			contractDateOfMember = programTo.getMemberContract().getContract()
					.getContractEndDate();
		}

		return contractDateOfMember;
	}
	
	

	public Collection<QualificationOverride> getMemberExemptions() {
		
		if(memberExemptions == null)
		{
			memberExemptions = new ArrayList<QualificationOverride>();
		}
		return memberExemptions;
	}

	public void setMemberExemptions(
			Collection<QualificationOverride> memberExemptions) {
		this.memberExemptions = memberExemptions;
	}

	/**
	 * 
	 * @param memberContractProgram
	 */
	public void addMemberContractProgram(
			MemberContractProgramTO memberContractProgram) {
		if (memberContractPrograms == null) {
			memberContractPrograms = new ArrayList<MemberContractProgramTO>();
		}
		if (memberContractProgram != null) {
			memberContractPrograms.add(memberContractProgram);
		}
	}


	public Collection<TaskEvent> getMemberTasksForGroupId(Integer businessProgramID,
			String taskGroupID) {

		Collection<TaskEvent> memberTasksForGroup = new ArrayList<TaskEvent>();
		Collection<TaskEvent> memberProgramTasks = new ArrayList<TaskEvent>();

		if (businessProgramID != null && taskGroupID != null) {
			memberProgramTasks = getMemberTasks(businessProgramID);
			Iterator<TaskEvent> itr = memberProgramTasks.iterator();
			while (itr.hasNext()) {
				TaskEvent taskEvent = itr.next();
				if (taskEvent != null && taskGroupID.equals(taskEvent.getTaskID())) {
					memberTasksForGroup.add(taskEvent);
				}
			}
		}
		return memberTasksForGroup;
	}

	/**
	 * Returns member tasks for program
	 * 
	 * @return the memberProgramTasks
	 */
	public Collection<TaskEvent> getMemberTasks(Integer businessProgramID) {
		Collection<TaskEvent> memberProgramTasks = new ArrayList<TaskEvent>();
		if (businessProgramID != null) {
			MemberContractProgramTO memberContractProgram = getMemberContractProgramTO(businessProgramID);
			if (memberContractProgram != null && memberContractProgram.getMemberTasks() != null) {
				memberProgramTasks = memberContractProgram.getMemberTasks();
			}
		}
		return memberProgramTasks;
	}

	/**
	 * Returns member activities for program.
	 * EV46129 - EvaluateTermedContract is only set when there exists termed contracts for participants.
	 * 
	 * @return the memberActivities
	 */
	public Collection<MemberActivity> getMemberActivities(
			Integer businessProgramID, boolean isEvaluateTermedContract) {
		Collection<MemberActivity> memberProgramActivities = new ArrayList<MemberActivity>();
		MemberContractProgramTO programTo = null;
		
		if (isEvaluateTermedContract) {
			programTo = getMemberTermedContractProgramTO(businessProgramID);
			if (programTo != null && programTo.getMemberActivities() != null) {
				memberProgramActivities = programTo.getMemberActivities();
			}
		} else {
			programTo = getMemberContractProgramTO(businessProgramID);
			if (programTo != null && programTo.getMemberActivities() != null) {
				memberProgramActivities = programTo.getMemberActivities();
			}
		}

		return memberProgramActivities;
	}
	
	

	/**
	 * Returns member's Disease management activities for program
	 * 
	 * @return the memberActivities
	 */
	public Collection<MemberActivity> getDiseaseManagementMemberActivities(
			Integer businessProgramID, boolean isEvaluateTermedContract) {
		Collection<MemberActivity> diseaseActivities = new ArrayList<MemberActivity>();
		Collection<MemberActivity> memberProgramActivities = getMemberActivities(businessProgramID, isEvaluateTermedContract);
		Iterator<MemberActivity> itr = memberProgramActivities.iterator();
		while (itr.hasNext()) {
			MemberActivity activity = itr.next();
			if (isDiseaseManagementActivity(activity)) {
				diseaseActivities.add(activity);
			}
		}
		return diseaseActivities;
	}

	private boolean isDiseaseManagementActivity(MemberActivity activity) {
		boolean result = false;
		String activityType = activity.getActivity().getActivityTypeValue();
		if (BPMConstants.ACTIVITY_TYPE_DISEASE_MGMT
				.equalsIgnoreCase(activityType)) {
			result = true;
		}
		return result;
	}

	/**
	 * Returns member's Health assessment activities for program
	 * 
	 * @return the memberActivities
	 */
	public Collection<MemberActivity> getHealthAssesmentMemberActivities(
			Integer businessProgramID, boolean isEvaluateTermedContract) {
		Collection<MemberActivity> haActivities = new ArrayList<MemberActivity>();
		Collection<MemberActivity> memberProgramActivities = getMemberActivities(businessProgramID, isEvaluateTermedContract);
		Iterator<MemberActivity> itr = memberProgramActivities.iterator();
		while (itr.hasNext()) {
			MemberActivity activity = itr.next();
			if (isHealthAssesmentActivity(activity)) {
				haActivities.add(activity);
			}
		}
		return haActivities;
	}

	private boolean isHealthAssesmentActivity(MemberActivity activity) {
		boolean result = false;
		if (BPMConstants.ACTIVITY_HEALTHY_BENEFITS_HA.equals(activity
				.getActivity().getName())) {
			result = true;
		}
		return result;
	}
	
	

	public Collection<MemberActivity> getNonDMNonHAMemberActivities(
			Integer businessProgramID, boolean isEvaluateTermedContract) {
		Collection<MemberActivity> otherActivities = new ArrayList<MemberActivity>();
		Collection<MemberActivity> memberProgramActivities = getMemberActivities(businessProgramID, isEvaluateTermedContract);
		Iterator<MemberActivity> itr = memberProgramActivities.iterator();
		while (itr.hasNext()) {
			MemberActivity activity = itr.next();
			if (!isHealthAssesmentActivity(activity)
					&& !isDiseaseManagementActivity(activity)) {
				otherActivities.add(activity);
			}
		}
		return otherActivities;
	}

	public Collection<MemberContractProgramTO> getMemberTermedContractPrograms() {
		return memberTermedContractPrograms;
	}

	public void setMemberTermedContractPrograms(
			Collection<MemberContractProgramTO> memberTermedContractPrograms) {
		this.memberTermedContractPrograms = memberTermedContractPrograms;
	}

	public Collection<PersonProgramActivityIncentiveStatus> getActivityBasedIncentivesForTermedSite() {
		return activityBasedIncentivesForTermedSite;
	}

	public void setActivityBasedIncentivesForTermedSite(
			Collection<PersonProgramActivityIncentiveStatus> activityBasedIncentivesForTermedSite) {
		this.activityBasedIncentivesForTermedSite = activityBasedIncentivesForTermedSite;
	}

	public Collection<PersonProgramActivityIncentiveStatus> getMemberBasedIncentivesForTermedSite() {
		return memberBasedIncentivesForTermedSite;
	}

	public void setMemberBasedIncentivesForTermedSite(
			Collection<PersonProgramActivityIncentiveStatus> memberBasedIncentivesForTermedSite) {
		this.memberBasedIncentivesForTermedSite = memberBasedIncentivesForTermedSite;
	}

	public Collection<PersonProgramActivityIncentiveStatus> getContractBasedIncentivesForTermedSite() {
		return contractBasedIncentivesForTermedSite;
	}

	public void setContractBasedIncentivesForTermedSite(
			Collection<PersonProgramActivityIncentiveStatus> contractBasedIncentivesForTermedSite) {
		this.contractBasedIncentivesForTermedSite = contractBasedIncentivesForTermedSite;
	}
}

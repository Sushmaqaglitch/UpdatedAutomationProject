/**
 * 
 */
package com.healthpartners.service.imfs.iface;

import java.util.ArrayList;
import java.util.Collection;

import com.healthpartners.service.imfs.dto.*;
import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.exception.BPMException;


/**
 * Provides a common interface for reward card data.
 * 
 * @author tjquist
 */
public interface RewardCardService 
{
	
	public Collection<RewardCardQuote> getQuotesFromBusProgramsWithRewardCards() throws BPMException;
	
	public Collection<RewardControlProgram> getRewardControlPrograms(String quoteID) throws BPMException;
	
	public Collection<RewardFulfillmentTrackingReportHist> assignAddressWhereToSendRewardCard(Collection<RewardFulfillmentTrackingReportHist> lRewardFulfillmentHistoryTrackingRpts,
																							  RewardCardQuoteByProgramSummary lRewardCardQuoteByProgramSummary, RewardControlProgram lRewardControlProgram)
			throws BPMException;

	public Collection<RewardFulfillmentTrackingReportHist> assignAddressUsingMODSWhereToSendRewardCard(Collection<RewardFulfillmentTrackingReportHist> lRewardFulfillmentHistoryTrackingRpts,
																									 RewardCardQuoteByProgramSummary lRewardCardQuoteByProgramSummary, RewardControlProgram lRewardControlProgram)
			throws BPMException;


	public boolean isRewardFulfillOnHoldOrDenied(Integer rewardTransHistID) throws BPMException;
	
	public boolean isRewardFulfillApproved(Integer rewardTransHistID) throws BPMException;
	
	
	public RewardControlProgramProcessTracker getRewardControlProgramProcessTracker(Integer rewardTransHistID) throws DataAccessException, BPMException;
	
	public int updateRewardFulfillRecycleStatus(RewardFulfillmentTrackingRecycle lRewardFulfillmentTrackingRecycle) throws DataAccessException, BPMException;
	
	public int updateRewardFulfillmentHistWithTodaysDate(Integer rewardTransHistID) throws DataAccessException, BPMException;
	
	public int updateRewardFulfillmentHistWOrderNumber(Integer rewardTransHistID, String orderNumber) throws DataAccessException, BPMException;
	
	public Collection<RewardCardRecycleDetail> getRewardRecycleByProgramOnHold(Integer programID, java.sql.Date selectionDate)
			throws DataAccessException;
	
	public boolean doesErrorExistInRewardRecycle(Integer rewardTransHistID, String itemNo) throws BPMException;
	
	public boolean doesErrorExistInRewardRecycle(Integer rewardTransHistID) throws BPMException;
	
	public int insertRewardFulfillmentRecycle(RewardFulfillmentTrackingRecycle newRewardFulfillmentTrackingRecycle, String systemUser)
			throws DataAccessException, BPMException;
	
	public int updateRewardFulfillRptTrackHist(
			Collection<RewardIntelispendShipped> lRewardIntelispendShippedRecs)
			throws DataAccessException, BPMException;
	
	public int insertRewardFulfillmentStatus(
			RewardFulfillmentTrackingReportHist lRewardFulfillmentTrackingReportHist, String systemID)
			throws DataAccessException, BPMException;
	
	public int insertRewardOrderDetailReport(Collection<RewardIntelispendOrdered> lRewardIntelispendOrderedRecs)
			throws DataAccessException, BPMException;
	
	public int updateRewardShipDetailReport(Collection<RewardIntelispendShipped> lRewardIntelispendShippedRecs)
			throws DataAccessException, BPMException;
	
	public int insertTransmissionAuditLog(
			Integer transactionID, Integer sendReceiveCodeID, Integer transmissionStatusID)
			throws DataAccessException;
	
	public int insertTransmissionAuditLogs(
			Collection<RewardFulfillmentTrackingReportHist> lRewardFulfillmentTrackingReportHists, Integer sendReceiveCodeID, Integer transmissionStatusID)
			throws DataAccessException;
	
	public int insertRewardControlProgramProcessTracker(Integer controlProgramID, String processStatus, Integer recordsSent)
			throws DataAccessException;
	
	public Collection<RewardFulfillmentTrackingRecycle> getRewardFulfillRecycle(int rewardTransHistID)
			throws DataAccessException;
	
	public Integer getProgramByRewardFulfillTransHistID(Integer fulfillTransHistID);
	
	public String findLatestRewardFulfillStatus(Integer rewardTransHistID, Integer rewardStatusID) throws DataAccessException;
	
	public boolean isStatusAlreadyExist(Integer rewardTransHistID, String rewardStatusDesc) throws BPMException;
	
	public ArrayList<RewardIntelispendShipped>  findNRemoveDuplicateRewardShipped(Collection<RewardIntelispendShipped> lRewardIntelispendShippedRecs) throws DataAccessException;
	
	public ArrayList<RewardIntelispendOrdered>  findNRemoveDuplicateRewardOrdered(Collection<RewardIntelispendOrdered> lRewardIntelispendOrderedRecs) throws DataAccessException;
	
	public Integer getProgramID(Integer transHistID) throws DataAccessException;
	
	public RewardCardClientData getRewardCardClientData(Integer pProgramID, Integer pIncentiveOptionID) throws DataAccessException;
		
}

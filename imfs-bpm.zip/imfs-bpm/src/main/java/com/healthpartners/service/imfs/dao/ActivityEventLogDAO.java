/**
 * 
 */
package com.healthpartners.service.imfs.dao;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;

import com.healthpartners.service.imfs.dto.ActivityEvent;
import com.healthpartners.service.imfs.dto.EmployerSponsoredActivity;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;


/**
 * @author tjquist
 * 
 */
public interface ActivityEventLogDAO {

	/**
	 * inserts ActivityEvent
	 * 
	 * @param activityEvent
	 * @return Long activityEventLogID
	 * @throws DataAccessException
	 */
	public Long insertActivityEventLog(ActivityEvent activityEvent)
			throws DataAccessException;
	
	public int insertEmployerAdministeredActivity(
			final EmployerSponsoredActivity lEmployerSponsoredActivity, String userID)
			throws DataAccessException;
	

	/**
	 * updates ActivityEvent Log for processing status
	 * 
	 * @param activityEvent
	 * @return number of rows updated
	 * @throws DataAccessException
	 */
	public int updateActivityLogProcessingStatus(ActivityEvent activityEvent)
			throws DataAccessException;

	/**
	 * deletes ActivityEvent log
	 * 
	 * @param activityEventLogID
	 * @return number of rows deleted
	 * @throws DataAccessException
	 */
	public int deleteActivityEventLog(Long activityEventLogID)
			throws DataAccessException;

	/**
	 * getActivityEventLog
	 * 
	 * @param activityEventLogID
	 * @return
	 * @throws DataAccessException
	 */
	public ActivityEvent getActivityEventLog(Long activityEventLogID)
			throws DataAccessException;

	/**
	 * gets all pending activity event IDs- not processed
	 * 
	 * @return Collection<Long> ID
	 * @throws DataAccessException
	 */
	public Collection<Long> getPendingActivityEventLogIDs(int batchSize)
			throws DataAccessException;

	

	
	public int getNumberOfPendingActivityEvents()
			throws DataAccessException;
	
	public int getNumberOfFilteredActivityEvents(String reasonCode, int daySpan)
	throws DataAccessException;
	
	public int updateQualifyingFilteredOutActivityEventsToPending(String reasonCode, int daySpan) throws DataAccessException;
	
	
	/**
	 * find complete and active or cancel activity events sent in at same time and then adjust
	 * insert timestamp of complete activity event by adding a minute.  This will force
	 * complete activity event to be processed last so member status calculates correctly. 
	 * 
	 * @return int
	 * @throws DataAccessException
	 */
	
	public  int processCompleteActivityEventsSentInAtSameTimeAsActiveOrCancel() throws DataAccessException;
	
	public Collection<ActivityEvent> 
		getMemberActivityEventLogActivity(String pMemberID, String pSourceActivityID, Date pActivityDate)
				throws DataAccessException;
	
	public Collection<ActivityEvent> 
	getMemberActivityEventLogActivity(String pMemberID, String pSourceActivityID, String registrationID)
			throws DataAccessException;
	
	public Collection<ActivityEvent> getActivityEventLogsByProcessingStatus(String processingStatus, java.sql.Date lActivityEventCutoffDate, boolean twoDaysNolderFlag, String sourceSystemID) 
			throws DataAccessException;
	
	public Collection<ActivityEvent> getActivityEventLogsByGroup(String groupNo, String siteNo, String memberNo, java.sql.Date lActivityEventCutoffDate, String sourceSystemID) 
			throws DataAccessException;
	
	public int insertMemberActivityBasedOnPreconditionByGroup(String groupNo, String siteNo, Integer programIncentiveOptionID, String sourceActivityID) throws DataAccessException;
}

/**
 * 
 */
package com.healthpartners.service.imfs.dao;

import java.util.Collection;

import com.healthpartners.service.imfs.dto.QualificationOverride;
import org.springframework.dao.DataAccessException;


/**
 * @author tjquist
 * 
 */
public interface QualificationOverrideDAO {

	/**
	 * inserts QualificationOverride
	 * 
	 * @param qualificationOverride
	 * @return long activityEventLogID
	 * @throws DataAccessException
	 */
	public long insertQualificationOverride(
			QualificationOverride qualificationOverride)
			throws DataAccessException;

	/**
	 * inserts QualificationOverride in batch mode
	 * 
	 * @param qualOverrides
	 *            Collection<QualificationOverride>
	 * @return long activityEventLogID
	 * @throws DataAccessException
	 */
	public int[] insertQualificationOverride(
			Collection<QualificationOverride> qualOverrides)
			throws DataAccessException;

	/**
	 * get all QualificationOverrides
	 * 
	 * @param personID
	 * @return Collection<QualificationOverride>
	 * @throws DataAccessException
	 */
	public Collection<QualificationOverride> getAllQualificationOverrides(
			Integer personID)
			throws DataAccessException;

	/**
	 * get QualificationOverride
	 * 
	 * @param overrideID
	 * @return QualificationOverride
	 * @throws DataAccessException
	 */
	public QualificationOverride getQualificationOverride(long overrideID)
			throws DataAccessException;

	/**
	 * deletes QualificationOverride
	 *
	 * @return number of rows deleted
	 * @throws DataAccessException
	 */
	public int deleteQualificationOverride(long overrideID)
			throws DataAccessException;

	public int deleteAutomaticMemberExemptions(Integer personID,
			Integer programID, Integer contractNo) throws DataAccessException;

	public int[] deleteAutomaticMemberExemptions(
			Collection<QualificationOverride> qualOverrides)
			throws DataAccessException;
	
	public Collection<QualificationOverride> getGroupTransferManualExemptions(
			Integer personID, Integer businessProgramID, Integer contractNo, Integer pProgramIncentiveOptionID)
			throws DataAccessException;

}

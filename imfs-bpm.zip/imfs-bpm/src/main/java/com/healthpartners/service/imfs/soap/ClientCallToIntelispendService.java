/**
 *
 *//*

package com.healthpartners.service.imfs.soap;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.iface.EnvCodeService;
import com.healthpartners.service.imfs.iface.LookUpValueService;

*/
/**
 * Responsible for getting a connection over the internet and returning the stub for making
 * webservice method calls to the host.  In this case Intelispend over SSL.
 *
 * @author tjquist
 *//*

@Component
public class ClientCallToIntelispendService
{

	protected final Log logger = LogFactory.getLog(getClass());

*/
/*	@Autowired
	private SubmitFileSoap intelispendService;*//*


	@Autowired
	public EnvCodeService envCodeService;

	@Autowired
	public LookUpValueService lookUpValueService;

*/
/*

	*//*

*/
/*
	 * Generate formatted xml for requesting gift card orders from Intelispend vendor participants achieving a reward
	 * based on activities completed.
	 *//*
*/
/*

	public DXML submitXMLTransToIntelispend(String xmlData, String quoteID) throws BPMException{

		SubmitFileRequest lSubmitFileRequest = getParametersForRequest(xmlData, quoteID);
		DXML lDXML = intelispendService.submitFile(lSubmitFileRequest);

		return lDXML;
	}
*//*


	private SubmitFileRequest getParametersForRequest(String xmlData, String quoteID) throws BPMException {

		SubmitFileRequest lSubmitFileRequest = new SubmitFileRequest();

		String userName = null;
		String password = null;
		String fileFormat = null;
		String fileType = null;

		try {
			userName = envCodeService.getENVCodeByCode(BPMConstants.REWARDCARD_USER_NM).getEnvCodeValue();
			password = envCodeService.getENVCodeByCode(BPMConstants.REWARDCARD_PASSWORD).getEnvCodeValue();
			fileFormat = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.INTELISPEND_PARM, BPMConstants.FILE_FORMAT).getLuvDesc();
			fileType = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.INTELISPEND_PARM, BPMConstants.FILE_TYPE).getLuvDesc();
		} catch (BPMException e) {
			logger.error("BPMException caught in ClientCallToIntelispendService.getParametersForRequest");
			logger.error("Stacktrace follows: " + e.getStackTrace());
			throw new BPMException(e);
		}

		lSubmitFileRequest.setUserName(userName);
		lSubmitFileRequest.setPassword(password);
		lSubmitFileRequest.setQuoteID(quoteID);
		lSubmitFileRequest.setFileFormat(fileFormat);
		lSubmitFileRequest.setFileType(fileType);
		lSubmitFileRequest.setData(xmlData);


		logger.info("In ClientCallToIntelispendService.getParametersForRequest.....");
		logger.info("User Name    " + lSubmitFileRequest.getUserName());
		logger.info("Password     " + lSubmitFileRequest.getPassword());
		logger.info("Quote ID     " + lSubmitFileRequest.getQuoteID());
		logger.info("File Format  " + lSubmitFileRequest.getFileFormat());
		logger.info("File Type    " + lSubmitFileRequest.getFileType());



		return lSubmitFileRequest;

	}




	public void setEnvCodeService(EnvCodeService envCodeService) {
		this.envCodeService = envCodeService;
	}


	public void setLookUpValueService(LookUpValueService lookUpValueService) {
		this.lookUpValueService = lookUpValueService;
	}



}
*/

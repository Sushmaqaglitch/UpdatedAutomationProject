package com.healthpartners.service.imfs.impl;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMEmailUtility;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dao.BusinessProgramDAO;
import com.healthpartners.service.imfs.dao.ControlGroupIOFileDirSetupDAO;
import com.healthpartners.service.imfs.dao.EmployerRecycleDAO;
import com.healthpartners.service.imfs.dao.PersonDAO;
import com.healthpartners.service.imfs.dto.ActivityDefinition;
import com.healthpartners.service.imfs.dto.ActivityEvent;
import com.healthpartners.service.imfs.dto.ActivityExternalEmployerXref;
import com.healthpartners.service.imfs.dto.BPMBusinessProgram;
import com.healthpartners.service.imfs.dto.ControlGroupIOFileDirSetup;
import com.healthpartners.service.imfs.dto.EmployerActivityContributionsFileData;
import com.healthpartners.service.imfs.dto.EmployerSponsoredActivity;
import com.healthpartners.service.imfs.dto.EmployerSponsoredActivityTrailer;
import com.healthpartners.service.imfs.dto.EmployerSponsoredFile;
import com.healthpartners.service.imfs.dto.GroupActivityProgressTracker;
import com.healthpartners.service.imfs.dto.LookUpValueCode;
import com.healthpartners.service.imfs.dto.MemberActivity;
import com.healthpartners.service.imfs.dto.PersonContractRecycleList;
import com.healthpartners.service.imfs.dto.PersonPackage;
import com.healthpartners.service.imfs.dto.PersonProgramActivityIncentiveStatus;
import com.healthpartners.service.imfs.dto.RejectedPerson;
import com.healthpartners.service.imfs.exception.BPMBusinessValidationException;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.helper.UploadEmployerActivityDataFileHelper;
import com.healthpartners.service.imfs.iface.ActivityEventService;
import com.healthpartners.service.imfs.iface.BusinessProgramService;
import com.healthpartners.service.imfs.iface.EmailService;
import com.healthpartners.service.imfs.iface.GroupActivityProgressTrackerService;
import com.healthpartners.service.imfs.iface.LookUpValueService;
import com.healthpartners.service.imfs.iface.MemberService;
import com.healthpartners.service.imfs.iface.PersonContractRecycleReportService;
import com.healthpartners.service.imfs.iface.UploadEmployerActivityPostprocessService;
import com.healthpartners.service.imfs.outbound.OutboundFileProcessing;
import com.healthpartners.service.imfs.rules.StatusCalculationCommand;
@Component
@Service
public class PersonContractRecycleReportServiceImpl implements PersonContractRecycleReportService {
	

	protected final Log logger = LogFactory.getLog(getClass());
	@Autowired
	private PersonDAO personDAO;
	@Autowired
	private LookUpValueService lookUpValueService;
	@Autowired
	private EmailService emailService;
	
	
	
	/*
	 * Produce a list of member contracts with ACTION NEEDED statuses from the person contract recycle table.  Send in an e-mail
	 * to a distribution list of business users responsible for monitoring member contracts with ACTION NEEDED statuses.  This will be a check and balance
	 * between BUSG Team members and the business users waiting for statues with ACTION_NEEDED to be addressed within the BPM system.
	 */
		@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
				BPMBusinessValidationException.class, BPMException.class })
	public void createPersonContractRecycleReportOnActionNeededStatusesCommand(StatusCalculationCommand statusCalculationCommand) throws BPMException
		{
			logger.info("@Start - Create Person Contract Action Needed Report. ");
			String emailServerHost = null;
			String emailFromAddress = null;
			String dbEnvirnment = "";
			StringBuffer emailSubject = new StringBuffer();
			StringBuffer batchMailContent = new StringBuffer();
			StringBuffer batchMailSubject = new StringBuffer();
			Collection<LookUpValueCode> toAddress = null;
			
			String hostName = statusCalculationCommand.getHostName();
			String userID = statusCalculationCommand.getUserID();
			
			try {

				Collection<LookUpValueCode> serverHost = lookUpValueService
						.getLUVCodesByGroup(BPMConstants.BPM_EMAIL_HOST_SRVR);
				Collection<LookUpValueCode> fromAddress = lookUpValueService
						.getLUVCodesByGroup(BPMConstants.BPM_EMAIL_FROM_ADDR);
				
				Collection<LookUpValueCode> dbEnvirnments = lookUpValueService
						.getLUVCodesByGroup(BPMConstants.BPM_DB_ENV);
				
				
				// email server host
				Iterator<LookUpValueCode> itrHost = serverHost.iterator();
				if (itrHost.hasNext()) {
					LookUpValueCode lvalue = itrHost.next();
					emailServerHost = lvalue.getLuvDesc();
				}

				// from address
				Iterator<LookUpValueCode> itrTo = fromAddress.iterator();
				if (itrTo.hasNext()) {
					LookUpValueCode lvalue = itrTo.next();
					emailFromAddress = lvalue.getLuvDesc();
				}

				Iterator<LookUpValueCode> itrEnv = dbEnvirnments.iterator();
				while (itrEnv.hasNext()) {
					LookUpValueCode lvalue = itrEnv.next();
					dbEnvirnment = lvalue.getLuvDesc();
					break;
				}
		
			
				batchMailSubject
				.append("BPM Batch Name: Member Contract Recycle ACTION NEEDED Report - SUCCESS");
				batchMailContent
						.append("<table>");
				batchMailContent.append("<tr><td>Initiated User: "
						+ statusCalculationCommand.getUserID() + "</td></tr>");


				batchMailContent.append("<tr></td>Result: SUCCESS</td></tr>");

				batchMailContent.append("<table>");
				batchMailContent
				.append("<tr><th align=center>MEMBER CONTRACT RECYCLE ACTION NEEDED DETAIL REPORT</th></tr>");
				batchMailContent.append("</table>");
				
				batchMailContent
				.append("<table width=\"800\" border=\"5\">");
				
				batchMailContent
				.append("<tr><td>Row</td><td>Member No</td><td>Contract No</td><td>Last Name</td><td>First Name</td><td>Status</td><td>Status Date</td></tr>");
				
				Collection<PersonContractRecycleList> lPersonContractsRecycleList = personDAO.getPersonContractRecycleByRecycleStatus(BPMConstants.PERSON_CONTRACT_RECYCLE_STATUS_ACTION_NEEDED);
				if (lPersonContractsRecycleList.size() > 0) {
					// column headers
					
					
					Iterator<PersonContractRecycleList> iter  = (Iterator<PersonContractRecycleList>) lPersonContractsRecycleList.iterator();
					int rowCt = 1;
			    	while (iter.hasNext()) {
			    		PersonContractRecycleList lPersonContractRecycleList = (PersonContractRecycleList)iter.next();
			    		batchMailContent
						.append("<tr>");
			    		batchMailContent
						.append("<td>" + rowCt + "." + "</td>");
						batchMailContent
						.append("<td>" + lPersonContractRecycleList.getMemberNo() + "</td>");
						batchMailContent
						.append("<td>" + lPersonContractRecycleList.getContractNo() + "</td>");
						batchMailContent
						.append("<td>" + lPersonContractRecycleList.getLastName() + ", " + "</td>");
						batchMailContent
						.append("<td>" + lPersonContractRecycleList.getFirstName() + "</td>");
						batchMailContent
						.append("<td>" + lPersonContractRecycleList.getRecycleStatus() + "</td>");
						String recycleStatusDate = BPMUtils.formatDateMMddyyyy(lPersonContractRecycleList.getRecycleStatusDate());
						batchMailContent
						.append("<td>" + recycleStatusDate + "</td>");
						batchMailContent
						.append("</tr>");
					
						rowCt++;
			    	} 
			    	
				} else {
					batchMailContent
					.append("<tr><td colspan=7>** No ACTION_NEEDED Member Contract Reycle records to report.</td></tr>");
					batchMailContent
					.append("</table>");
				}
			} catch (Exception e) {
				logger.error(
						"Error occurred prior to sending Employer Activity Reconciliation email: "
								+ e.getMessage(), e);
				logger.error("  emailFromAddress=" + emailFromAddress);
				logger.error("  emailSubject=" + emailSubject.toString());
			}
			batchMailContent
			.append("</table>");
	    	emailService.setEmailDestination(BPMConstants.BPM_EMAIL_TO_ADDR_MEMBERSHIP_ONHOLD_RPT);
	    	emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
	    	emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
	    			batchMailContent.toString());
	    	
		}

		

		public PersonDAO getPersonDAO() {
			return personDAO;
		}



		public void setPersonDAO(PersonDAO personDAO) {
			this.personDAO = personDAO;
		}


		public LookUpValueService getLookUpValueService() {
			return lookUpValueService;
		}



		public void setLookUpValueService(LookUpValueService lookUpValueService) {
			this.lookUpValueService = lookUpValueService;
		}



		public EmailService getEmailService() {
			return emailService;
		}



		public void setEmailService(EmailService emailService) {
			this.emailService = emailService;
		}

		
	
}

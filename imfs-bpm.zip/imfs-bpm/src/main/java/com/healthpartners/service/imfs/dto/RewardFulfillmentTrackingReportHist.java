package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.sql.Date;
import java.util.Calendar;

/**
 * @author tjquist
 *
 */
public class RewardFulfillmentTrackingReportHist implements Serializable
{	
	static final long serialVersionUID = 0L;
	
	private Integer rewardTransHistID;
	private Integer programID;
	private String   groupNo;
	private String   groupName;
	private Calendar qualificationStartDate;
	private Integer personID;
	private Integer personDemographicsID;
	private Integer groupID;
	private Integer packageID;
	private String  memberNo;
	private Integer contractNo;
	private String  firstName;
	private String  suffix;
	private String  lastName;
	private String  middleInit;
	private String  embossName;
	private String  embossDesc;
	private String  fourthLineEmboss;
	private String  addressLine1;
	private String  addressLine2;
	private String  city;
	private String  state;
	private String  zip;
	private String  extendedZip;
	private String countryCode;
	private String postalCodeExt;
	private String  programParticipationStatus;
	//funding amount.  Using contributionAmount because ties back to tiering contribuion model for assigning dollars.
	private Integer contributionAmount;
	private String  contributionTypeCode;
	private Integer  contributionTypeCodeId;
	private Integer feeAmount;
	private Date rewardStartDate;
	private Date rewardEndDate;
	private Integer memberCount;
	private Integer activityID;
	private Date    fileSentDate;
	private Date    rewardDate;
	private String sourceActivityID;
	private Integer  incentiveOptionID;
	private String reasonCodeID;
	private String reasonDesc;
	private String carrierMessageName;
	private String carrierMessageDesc;
	private String carrierMessageDesc2;
	private String transactionMessageName;
	private String transactionMessageDesc;
	private String orderNumber;
	private Date rewardCardStatusDate;
	
	
	
	
	public Integer getRewardTransHistID() {
		return rewardTransHistID;
	}
	public void setRewardTransHistID(Integer rewardTransHistID) {
		this.rewardTransHistID = rewardTransHistID;
	}
	public Integer getProgramID() {
		return programID;
	}
	public void setProgramID(Integer programID) {
		this.programID = programID;
	}
	public String getGroupNo() {
		return groupNo;
	}
	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}
	
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public Calendar getQualificationStartDate() {
		return qualificationStartDate;
	}
	public void setQualificationStartDate(Calendar qualificationStartDate) {
		this.qualificationStartDate = qualificationStartDate;
	}
	public Integer getPersonID() {
		return personID;
	}
	public void setPersonID(Integer personID) {
		this.personID = personID;
	}
	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}
	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}
	public Integer getGroupID() {
		return groupID;
	}
	public void setGroupID(Integer groupID) {
		this.groupID = groupID;
	}
	public Integer getPackageID() {
		return packageID;
	}
	public void setPackageID(Integer packageID) {
		this.packageID = packageID;
	}
	public String getMemberNo() {
		return memberNo;
	}
	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}
	public Integer getContractNo() {
		return contractNo;
	}
	public void setContractNo(Integer contractNo) {
		this.contractNo = contractNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getSuffix() {
		return suffix;
	}
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	
	public String getMiddleInit() {
		return middleInit;
	}
	public void setMiddleInit(String middleInit) {
		this.middleInit = middleInit;
	}
	public String getEmbossName() {
		return embossName;
	}
	public void setEmbossName(String embossName) {
		this.embossName = embossName;
	}
	
	public String getEmbossDesc() {
		return embossDesc;
	}
	public void setEmbossDesc(String embossDesc) {
		this.embossDesc = embossDesc;
	}
	public String getFourthLineEmboss() {
		return fourthLineEmboss;
	}
	public void setFourthLineEmboss(String fourthLineEmboss) {
		this.fourthLineEmboss = fourthLineEmboss;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getExtendedZip() {
		return extendedZip;
	}
	public void setExtendedZip(String extendedZip) {
		this.extendedZip = extendedZip;
	}
	
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	
	public String getPostalCodeExt() {
		return postalCodeExt;
	}
	public void setPostalCodeExt(String postalCodeExt) {
		this.postalCodeExt = postalCodeExt;
	}

	public String getProgramParticipationStatus() {
		return programParticipationStatus;
	}
	public void setProgramParticipationStatus(String programParticipationStatus) {
		this.programParticipationStatus = programParticipationStatus;
	}
	
	public Integer getContributionAmount() {
		return contributionAmount;
	}
	public void setContributionAmount(Integer contributionAmount) {
		this.contributionAmount = contributionAmount;
	}
	public Integer getFeeAmount() {
		return feeAmount;
	}
	public void setFeeAmount(Integer feeAmount) {
		this.feeAmount = feeAmount;
	}
	public String getContributionTypeCode() {
		return contributionTypeCode;
	}
	public void setContributionTypeCode(String contributionTypeCode) {
		this.contributionTypeCode = contributionTypeCode;
	}
	public Integer getContributionTypeCodeId() {
		return contributionTypeCodeId;
	}
	public void setContributionTypeCodeId(Integer contributionTypeCodeId) {
		this.contributionTypeCodeId = contributionTypeCodeId;
	}
	public Date getRewardStartDate() {
		return rewardStartDate;
	}
	public void setRewardStartDate(Date rewardStartDate) {
		this.rewardStartDate = rewardStartDate;
	}
	public Date getRewardEndDate() {
		return rewardEndDate;
	}
	public void setRewardEndDate(Date rewardEndDate) {
		this.rewardEndDate = rewardEndDate;
	}
	
	
	public Integer getMemberCount() {
		return memberCount;
	}
	public void setMemberCount(Integer memberCount) {
		this.memberCount = memberCount;
	}
	public Integer getActivityID() {
		return activityID;
	}
	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}
	
	public Date getFileSentDate() {
		return fileSentDate;
	}
	public void setFileSentDate(Date fileSentDate) {
		this.fileSentDate = fileSentDate;
	}
	public Date getRewardDate() {
		return rewardDate;
	}
	public void setRewardDate(Date rewardDate) {
		this.rewardDate = rewardDate;
	}
	public String getSourceActivityID() {
		return sourceActivityID;
	}
	public void setSourceActivityID(String sourceActivityID) {
		this.sourceActivityID = sourceActivityID;
	}
	
	public Integer getIncentiveOptionID() {
		return incentiveOptionID;
	}
	public void setIncentiveOptionID(Integer incentiveOptionID) {
		this.incentiveOptionID = incentiveOptionID;
	}
	
	public String getReasonCodeID() {
		return reasonCodeID;
	}
	public void setReasonCodeID(String reasonCodeID) {
		this.reasonCodeID = reasonCodeID;
	}
	public String getReasonDesc() {
		return reasonDesc;
	}
	public void setReasonDesc(String reasonDesc) {
		this.reasonDesc = reasonDesc;
	}
	public String getCarrierMessageName() {
		return carrierMessageName;
	}
	public void setCarrierMessageName(String carrierMessageName) {
		this.carrierMessageName = carrierMessageName;
	}
	public String getCarrierMessageDesc() {
		return carrierMessageDesc;
	}
	public void setCarrierMessageDesc(String carrierMessageDesc) {
		this.carrierMessageDesc = carrierMessageDesc;
	}
	
	public String getCarrierMessageDesc2() {
		return carrierMessageDesc2;
	}
	public void setCarrierMessageDesc2(String carrierMessageDesc2) {
		this.carrierMessageDesc2 = carrierMessageDesc2;
	}
	public String getTransactionMessageName() {
		return transactionMessageName;
	}
	public void setTransactionMessageName(String transactionMessageName) {
		this.transactionMessageName = transactionMessageName;
	}
	public String getTransactionMessageDesc() {
		return transactionMessageDesc;
	}
	public void setTransactionMessageDesc(String transactionMessageDesc) {
		this.transactionMessageDesc = transactionMessageDesc;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public Date getRewardCardStatusDate() {
		return rewardCardStatusDate;
	}
	public void setRewardCardStatusDate(Date rewardCardStatusDate) {
		this.rewardCardStatusDate = rewardCardStatusDate;
	}
	
	
	
	
}

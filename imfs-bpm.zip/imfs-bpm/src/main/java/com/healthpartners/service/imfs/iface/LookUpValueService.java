/* $Id$ */

package com.healthpartners.service.imfs.iface;

import java.util.Collection;

import com.healthpartners.service.imfs.dto.LookUpValueCode;
import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.exception.BPMException;

/**
 * Provides LookUpValueCode services.
 * 
 * @author tjquist
 */
public interface LookUpValueService {

	

	/**
	 * Retrieves code of the specified group and value.
	 * 
	 * @param group
	 *            the LUV group
	 * @return a <code>LookUpValueCode</code> 
	 *         object
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public LookUpValueCode getLUVCodeByGroupNValue(String group, String value)
			throws BPMException, DataAccessException;
	
	public LookUpValueCode getLUVCodeByID(Integer luvID)
			throws BPMException, DataAccessException;
	
	/**
	 * Retrieves codes of the specified group.
	 * 
	 * @param group
	 *            the LUV group
	 *
	 * @return a <code>LookUpValueCode</code> 
	 *         object
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public Collection<LookUpValueCode> getLUVCodesByGroup(String group)
		throws BPMException, DataAccessException;
}

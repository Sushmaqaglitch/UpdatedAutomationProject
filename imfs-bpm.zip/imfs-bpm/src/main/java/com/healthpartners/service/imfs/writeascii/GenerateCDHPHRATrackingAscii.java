

package com.healthpartners.service.imfs.writeascii;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.StringTokenizer;

import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.DetailHRA;
import com.healthpartners.service.imfs.dto.HeaderHRA;
import com.healthpartners.service.imfs.dto.TrailerHRA;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.DetailHRA;
import com.healthpartners.service.imfs.dto.HeaderHRA;
import com.healthpartners.service.imfs.dto.TrailerHRA;
 
public class GenerateCDHPHRATrackingAscii
{

	protected final Log logger = LogFactory.getLog(getClass());
   
   private FileWriter writer;
   
   private int recsWritten = 0;
 
   public void GenerateCDHPHRATrackingAscii() {
	   
   }
   //Method commented out in case needed in the future.  Header, detail, and trailer dto's do not need to be saved off into an array list
   //since there will only be one header and one trailer record each time the batch program is run.
   /*
   public void generateAsciiFile(ArrayList cdhpHRATransByGroup, String pFilePath) throws Exception {
	   
	   	
		Iterator iter = cdhpHRATransByGroup.iterator();
		
		try {
			while (iter.hasNext()) {
				Object transObject = iter.next();
				if (transObject instanceof HeaderHRA) {
					HeaderHRA headerHRA = (HeaderHRA) transObject;
					writer = buildHRAHeader(headerHRA);
					
				} else if (transObject instanceof DetailHRA) {
							DetailHRA detailHRA = (DetailHRA) transObject;
							writer = buildHRADetail(detailHRA);
					
				} else if (transObject instanceof TrailerHRA) {
							TrailerHRA trailerHRA = (TrailerHRA) transObject;
							writer = buildHRATrailer(trailerHRA);
				} else {
					throw new Exception("OutboundFileServiceImpl.generateCDHPHRAFile: transObject instanceof NOT FOUND.  Class is " + transObject.getClass().getName());
				}
			}
	   } catch(IOException e)
		{
		     e.printStackTrace();
		} 
		
	}*/
 
 
   public void generateAsciiFile(HeaderHRA lHeaderHRA, Collection<DetailHRA> lDetailHRAs, TrailerHRA lTrailerHRA, String pFilePath) throws Exception {
	   
	   	
		Iterator iter = lDetailHRAs.iterator();
		
		try {
			writeHRAHeader(lHeaderHRA);
			while (iter.hasNext()) {
				Object transObject = iter.next();
				
				DetailHRA detailHRA = (DetailHRA) transObject;
				writeHRADetail(detailHRA);
			}
			writeHRATrailer(lTrailerHRA);
	   } catch(IOException e)
		{
		     e.printStackTrace();
		} 
		
	}
   
 private void writeHRAHeader(HeaderHRA headerHRA) throws IOException {
	 String filler = "";
	 writer.append(headerHRA.getRecordType());
	 
	 String fileDate = BPMUtils.rightPadString(headerHRA.getFileDate(), 8);
	 writer.append(fileDate);
	
	 writer.append(headerHRA.getFileClassification());
	
	 String carrierID = BPMUtils.rightPadString(headerHRA.getCarrierID(), 20);
	 writer.append(carrierID);
	
	 String employerGroupID = BPMUtils.rightPadString(filler, 20);
	 writer.append(headerHRA.getEmployerGroupID());
	 
	 String lFiller = BPMUtils.rightPadString(filler, 50);
	 writer.append(lFiller);
	 writer.append('\n');
	 
	 recsWritten++;
   }
 
 private void writeHRADetail(DetailHRA detailHRA) throws IOException {
	   
	 writer.append(detailHRA.getRecordType());
	 String recordID = "";
	 if (detailHRA.getRecordID() != null) {
		 recordID = BPMUtils.rightPadString(detailHRA.getRecordID(), 10);
	 } else {
		 recordID = BPMUtils.rightPadString(recordID, 10);
	 }
	 
	 writer.append(recordID);
	 String fileDate = "";
	 if (detailHRA.getFileDate() != null) {
		 fileDate = BPMUtils.rightPadString(detailHRA.getFileDate(), 8);
	 } else {
		 fileDate = BPMUtils.rightPadString(fileDate, 8);
	 }
	 writer.append(fileDate);
	 //writer.append(' ');
	 String employerTaxID = "";
	 if (detailHRA.getEmployerTaxID() != null) {
	     employerTaxID = BPMUtils.rightPadString(detailHRA.getEmployerTaxID(), 9);
	 } else {
		 employerTaxID = BPMUtils.rightPadString(employerTaxID, 9);
	 }
	 writer.append(employerTaxID);
	 //writer.append(' ');
	 String groupID = "";
	 if (detailHRA.getHpGroupID() != null) {
		 groupID = BPMUtils.rightPadString(detailHRA.getHpGroupID(), 8);
	 } else {
		 groupID = BPMUtils.rightPadString(groupID, 8);
	 }
	 writer.append(groupID);
	 //writer.append(' ');
	 String ssn = "";
	 if (detailHRA.getPolicyHolderSocialSecurityNumber() != null) {
		 ssn = BPMUtils.rightPadString(detailHRA.getPolicyHolderSocialSecurityNumber(), 9);
	 } else {
		 ssn = BPMUtils.rightPadString(ssn, 9);
	 }
	 writer.append(ssn);
	 //writer.append(' ');
	 String contractNo = "";
	 if (detailHRA.getPolicyHolderHPContractID() != null) {
		 contractNo = BPMUtils.rightPadString(detailHRA.getPolicyHolderHPContractID(), 10);
	 } else {
		 contractNo = BPMUtils.rightPadString(contractNo, 10);
	 }
	 writer.append(contractNo);
	 //writer.append(' ');
	 String memberNo = "";
	 if (detailHRA.getPolicyHolderHPMemberID() != null) {
		 memberNo = BPMUtils.rightPadString(detailHRA.getPolicyHolderHPMemberID(), 9);
	 } else {
		 memberNo = BPMUtils.rightPadString(memberNo, 9);
	 }
	 writer.append(memberNo);
	 //writer.append(' ');
	 String lastName = "";
	 if (detailHRA.getPolicyHolderLastName() != null) {
		 lastName = BPMUtils.rightPadString(detailHRA.getPolicyHolderLastName(), 20);
	 } else {
		 lastName = BPMUtils.rightPadString(lastName, 20);
	 }
	 writer.append(lastName);
	 //writer.append(' ');
	 String firstName = "";
	 if (detailHRA.getPolicyHolderFirstName() != null) {
	     firstName = BPMUtils.rightPadString(detailHRA.getPolicyHolderFirstName(), 20);
	 } else {
		 firstName = BPMUtils.rightPadString(firstName, 20);
	 }
	 writer.append(firstName);
	 //writer.append(' ');
	 String middleInit = "";
	 if (detailHRA.getPolicyHolderMiddleInit() != null) {
		 middleInit = BPMUtils.rightPadString(detailHRA.getPolicyHolderMiddleInit(), 1);
	 } else {
		 middleInit = BPMUtils.rightPadString(middleInit, 1);
	 }
	 writer.append(middleInit);
	 //writer.append(' ');
	 String activityType = "";
	 if (detailHRA.getActivityType() != null) {
		 activityType = BPMUtils.rightPadString(detailHRA.getActivityType(), 20);
	 } else {
		 activityType = BPMUtils.rightPadString(activityType, 20);
	 }
	 writer.append(activityType);
	 //writer.append(' ');
	 String contributionDate = "";
	 if (detailHRA.getContributionDate() != null) {
	       contributionDate = BPMUtils.rightPadString(detailHRA.getContributionDate(), 8);
	 } else {
		 contributionDate = BPMUtils.rightPadString(contributionDate, 8);
	 }
	 writer.append(contributionDate);
	 //writer.append(' ');
	 String contributionAmount = "";
	 if (detailHRA.getContributionAmount() != null) {
		 contributionAmount = BPMUtils.leftPadWZerosPadDecZeroes(Integer.toString(detailHRA.getContributionAmount().intValue()), 9);
	 } else {
		 contributionAmount = BPMUtils.leftPadWZerosPadDecZeroes(contributionAmount, 9);
	 }
	 writer.append(contributionAmount);
	 
	 String filler = "";
	 filler = BPMUtils.rightPadString(filler, 50);
	 
	 writer.append(filler);
	 writer.append('\n');
	 
	 recsWritten++;
	 
   }
 
 
 
 private void writeHRATrailer(TrailerHRA trailerHRA) throws IOException {
	   
	 writer.append(trailerHRA.getRecordType());
	 
	 String totalRecords = BPMUtils.rightPadString(trailerHRA.getTotalRecords(), 10);
	 writer.append(totalRecords);
	 
	 writer.append('\n');
	 
	 recsWritten++;
	 
   }
 
 
 
 public void openFileWriter(String pFilePath) {
	
	 Calendar calDate = Calendar.getInstance();

     String calDateStr = BPMUtils.formatDateMMddyyyy(calDate);
     StringTokenizer strDate = new StringTokenizer(calDateStr, "/");
     String month = strDate.nextToken();
     String day = strDate.nextToken();
     String year = strDate.nextToken();
     
     String topLevelDir = "output_bpm_hra/";
     File topLevelDirFile = new File(topLevelDir);
     if((topLevelDirFile.mkdirs())) {
         logger.info("Created directory: " + topLevelDirFile.getPath());
     }
     String filePathWithFileName =  pFilePath + year + month + day + calDate.get(Calendar.HOUR_OF_DAY) + calDate.get(Calendar.MINUTE) + calDate.get(Calendar.SECOND) + ".dat";
     logger.info("GenerateHRAFileAscii: File path is " + filePathWithFileName);
     int recsWritten = 0;
     
     try{
    	 FileWriter writer = new FileWriter(filePathWithFileName); 
    	 setWriter(writer);
	 } catch(IOException e)
		{
		     e.printStackTrace();
		} 
     
 	}

	public void closeFileWriter() {
		try {
		 writer.flush();
		 writer.close();
		} catch(IOException e)
		{
		     e.printStackTrace();
		} 
	}
	public void setWriter(FileWriter writer) {
		this.writer = writer;
	}

	public int getRecsWritten() {
		return recsWritten;
	}

	public void setRecsWritten(int recsWritten) {
		this.recsWritten = recsWritten;
	}
	  
  
}
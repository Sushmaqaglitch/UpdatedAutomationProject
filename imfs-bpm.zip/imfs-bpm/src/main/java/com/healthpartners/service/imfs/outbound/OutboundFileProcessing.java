/**
 * 
 */
package com.healthpartners.service.imfs.outbound;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.CDHPControlGroup;
import com.healthpartners.service.imfs.dto.CDHPFulfillmentTrackingReport;
import com.healthpartners.service.imfs.dto.ControlGroupIOFileDirSetup;
import com.healthpartners.service.imfs.dto.DetailEmployerSponsoredActivity;
import com.healthpartners.service.imfs.dto.DetailEmployerSponsoredContractSummary;
import com.healthpartners.service.imfs.dto.DetailHRA;
import com.healthpartners.service.imfs.dto.DetailHSA;
import com.healthpartners.service.imfs.dto.HeaderHRA;
import com.healthpartners.service.imfs.dto.HeaderHSA;
import com.healthpartners.service.imfs.dto.RewardCardClientData;
import com.healthpartners.service.imfs.dto.PersonProgramActivityIncentiveStatus;
import com.healthpartners.service.imfs.dto.RewardFulfillmentTrackingReportHist;
import com.healthpartners.service.imfs.dto.TrailerEmployerSponsoredActivity;
import com.healthpartners.service.imfs.dto.TrailerEmployerSponsoredContractSummary;
import com.healthpartners.service.imfs.dto.TrailerHRA;
import com.healthpartners.service.imfs.dto.TrailerHSA;
import com.healthpartners.service.imfs.factory.OutboundCDHPTransFactory;
import com.healthpartners.service.imfs.factory.OutboundEmployerSponsoredReportFactory;
import com.healthpartners.service.imfs.factory.OutboundIntelispendTransFactory;
import com.healthpartners.service.imfs.writeascii.GenerateCDHPHRATrackingAscii;
import com.healthpartners.service.imfs.writeascii.GenerateCDHPHSATrackingAscii;
import com.healthpartners.service.imfs.writeascii.GenerateEmployerSponsoredAscii;


/**
 * Responsible for generating outbound csv files.
 * 
 * @author tjquist
 */
public class OutboundFileProcessing
{

	protected final Log logger = LogFactory.getLog(getClass());
	
	/**
	 * Handles 
	 */
	public OutboundFileProcessing() {
		super();
	}
	
	
	public int generateCDHPHRAFile(Collection<CDHPFulfillmentTrackingReport> lCDHPFulfillmentTrackingReports, String pFilePath, String lCDHPEnvIdentifier) throws Exception 
	{
		ArrayList<DetailHRA> lDetailHRAs = new ArrayList<DetailHRA>();
		
		java.sql.Date todaysDate = BPMUtils.calendarToSqlDate(Calendar.getInstance());
		
		String fileCreateDate = BPMUtils.formatDateCCYYmmddWODel(todaysDate);
		//Sending only one header for all employer groups.
		String employerGroupID = "";
		
		
		if (lCDHPFulfillmentTrackingReports.size() > 0) {
			Iterator<CDHPFulfillmentTrackingReport> iter = (Iterator<CDHPFulfillmentTrackingReport>) lCDHPFulfillmentTrackingReports.iterator();
			
			DetailHRA lDetailHRA = null;
			while (iter.hasNext()) {
				CDHPFulfillmentTrackingReport lCDHPHRAFulfillmentTrackingReport = (CDHPFulfillmentTrackingReport) iter.next();
				lDetailHRA = OutboundCDHPTransFactory.detailHRAMapper(lCDHPHRAFulfillmentTrackingReport, fileCreateDate);	
				lDetailHRAs.add(lDetailHRA);			
			}		
		} 
		
		GenerateCDHPHRATrackingAscii lGenerateCDHPHRATrackingAscii = new GenerateCDHPHRATrackingAscii();
		try {
			
			HeaderHRA lHeaderHRA = OutboundCDHPTransFactory.headerHRAMapper(fileCreateDate, employerGroupID, lCDHPEnvIdentifier);
			TrailerHRA lTrailerHRA = OutboundCDHPTransFactory.trailerHRAMapper(lDetailHRAs.size());
			lGenerateCDHPHRATrackingAscii.openFileWriter(pFilePath);
			lGenerateCDHPHRATrackingAscii.generateAsciiFile(lHeaderHRA, lDetailHRAs, lTrailerHRA, pFilePath);
			lGenerateCDHPHRATrackingAscii.closeFileWriter();
		} catch (Exception e) {
			logger.error("Issue attempting to generate CDHP HRA Ascii File.  Message is " + e.getMessage());
			throw e;
		}
		
		
		
		return lDetailHRAs.size();
			
	}
	 																																	
	public int generateCDHPHSAFile(Collection<CDHPFulfillmentTrackingReport> lCDHPFulfillmentTrackingReports, CDHPControlGroup lCDHPControlGroup, String lCDHPEnvIdentifier) throws Exception 
	{
		ArrayList<DetailHSA> lDetailHSAs = new ArrayList<DetailHSA>();
		
		java.sql.Date todaysDate = BPMUtils.calendarToSqlDate(Calendar.getInstance());
		
		String fileCreateDate = BPMUtils.formatDateCCYYmmddWODel(todaysDate);
		
		String outputFilePathNFileName = lCDHPControlGroup.getOutputFilePath() + lCDHPControlGroup.getFileNamePrefix();
		String fileLayoutType = lCDHPControlGroup.getFileLayoutType();
		String employerGroupID = lCDHPControlGroup.getGroupNo();
		
		if (lCDHPFulfillmentTrackingReports.size() > 0) {
			Iterator<CDHPFulfillmentTrackingReport> iter = (Iterator<CDHPFulfillmentTrackingReport>) lCDHPFulfillmentTrackingReports.iterator();
			
			DetailHSA lDetailHSA = null;
			while (iter.hasNext()) {
				CDHPFulfillmentTrackingReport lCDHPHRAFulfillmentTrackingReport = (CDHPFulfillmentTrackingReport) iter.next();
				lDetailHSA = OutboundCDHPTransFactory.detailHSAMapper(lCDHPHRAFulfillmentTrackingReport, fileCreateDate);	
				lDetailHSAs.add(lDetailHSA);			
			}		
		} 
		
		GenerateCDHPHSATrackingAscii lGenerateCDHPHSATrackingAscii = new GenerateCDHPHSATrackingAscii();
		try {
			
			HeaderHSA lHeaderHSA = OutboundCDHPTransFactory.headerHSAMapper(fileCreateDate, employerGroupID, lCDHPEnvIdentifier);
			TrailerHSA lTrailerHSA = OutboundCDHPTransFactory.trailerHSAMapper(lDetailHSAs.size());
			lGenerateCDHPHSATrackingAscii.openFileWriter(lCDHPControlGroup.getOutputFilePath(), lCDHPControlGroup.getProcessedOutputFilePath(), outputFilePathNFileName);
			lGenerateCDHPHSATrackingAscii.generateAsciiFile(lHeaderHSA, lDetailHSAs, lTrailerHSA, fileLayoutType);
			lGenerateCDHPHSATrackingAscii.closeFileWriter();
		} catch (Exception e) {
			logger.error("Issue attempting to generate CDHP HSA Ascii File.  Message is " + e.getMessage());
			throw e;
		}
		
		
		
		return lDetailHSAs.size();
			
	}
	
	public int generateEmployerSponsoredActivityFile(Collection<PersonProgramActivityIncentiveStatus> personProgramActivityIncentiveStatuses, ControlGroupIOFileDirSetup lControlGroupIOFileDirSetup) throws Exception 
	{
		ArrayList<DetailEmployerSponsoredActivity> lDetailEmployerSponsoredActivitys = new ArrayList<DetailEmployerSponsoredActivity>();
		
		java.sql.Date todaysDate = BPMUtils.calendarToSqlDate(Calendar.getInstance());
		
		String fileCreateDate = BPMUtils.formatDateCCYYmmddWODel(todaysDate);
		
		if (personProgramActivityIncentiveStatuses.size() > 0) {
			Iterator<PersonProgramActivityIncentiveStatus> iter = (Iterator<PersonProgramActivityIncentiveStatus>) personProgramActivityIncentiveStatuses.iterator();
			
			DetailEmployerSponsoredActivity lDetailEmployerSponsoredActivity = null;
			while (iter.hasNext()) {
				PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus = (PersonProgramActivityIncentiveStatus) iter.next();
				lDetailEmployerSponsoredActivity = OutboundEmployerSponsoredReportFactory.detailActivityMapper(lPersonProgramActivityIncentiveStatus, fileCreateDate);	
				lDetailEmployerSponsoredActivitys.add(lDetailEmployerSponsoredActivity);			
			}		
		} 
		
		GenerateEmployerSponsoredAscii lGenerateEmployerSponsoredAscii = new GenerateEmployerSponsoredAscii();
		try {
			Integer totalContributionAmount = totalEmployerSponsoredActivityAmounts(lDetailEmployerSponsoredActivitys);
			TrailerEmployerSponsoredActivity lTrailerEmployerSponsoredActivity = OutboundEmployerSponsoredReportFactory.trailerActivityMapper(lDetailEmployerSponsoredActivitys.size(), totalContributionAmount);
			String outputFilePath = lControlGroupIOFileDirSetup.getProcessedOutputFilePathLoc1();
			String detailFileName = lGenerateEmployerSponsoredAscii.openFileWriter(outputFilePath, lControlGroupIOFileDirSetup.getFileNamePrefix1());
			lControlGroupIOFileDirSetup.setGeneratedDetailPathNFileName(detailFileName);
			lGenerateEmployerSponsoredAscii.generateActivityAsciiFile(lDetailEmployerSponsoredActivitys, lTrailerEmployerSponsoredActivity);
			
			lGenerateEmployerSponsoredAscii.closeFileWriter();
		} catch (Exception e) {
			logger.error("Issue attempting to generate Employer Sponsored Activity Detail Ascii Report.  Message is " + e.getMessage());
			throw e;
		}
		
		
		
		return lDetailEmployerSponsoredActivitys.size();
			
	}
	
	public int generateEmployerSponsoredContractSummaryFile(Collection<PersonProgramActivityIncentiveStatus> personProgramActivityIncentiveStatuses, ControlGroupIOFileDirSetup lControlGroupIOFileDirSetup) throws Exception 
	{
		ArrayList<DetailEmployerSponsoredActivity> lDetailEmployerSponsoredActivitys = new ArrayList<DetailEmployerSponsoredActivity>();
		
		OutboundEmployerSponsoredReportFactory lOutboundEmployerSponsoredReportFactory = new OutboundEmployerSponsoredReportFactory();
		
		TrailerEmployerSponsoredContractSummary lTrailerEmployerSponsoredContractSummary = null;
		
		Collection<DetailEmployerSponsoredContractSummary> lDetailEmployerSponsoredContractSummarys = lOutboundEmployerSponsoredReportFactory.detailContractSummaryMapperForRollingUpToContract(personProgramActivityIncentiveStatuses);
		
		GenerateEmployerSponsoredAscii lGenerateEmployerSponsoredAscii = new GenerateEmployerSponsoredAscii();
		try {
			Integer totalContributionAmount = totalEmployerSponsoredContractSummaryAmounts(lDetailEmployerSponsoredContractSummarys);
			lTrailerEmployerSponsoredContractSummary = OutboundEmployerSponsoredReportFactory.trailerContractSummaryMapper(lDetailEmployerSponsoredContractSummarys.size(), totalContributionAmount);
			String outputFilePath = lControlGroupIOFileDirSetup.getProcessedOutputFilePathLoc2();
			String contractFileName = lGenerateEmployerSponsoredAscii.openFileWriter(outputFilePath, lControlGroupIOFileDirSetup.getFileNamePrefix2());
			lControlGroupIOFileDirSetup.setGeneratedContractPathNFileName(contractFileName);
			lGenerateEmployerSponsoredAscii.generateContractSummaryAsciiFile(lDetailEmployerSponsoredContractSummarys, lTrailerEmployerSponsoredContractSummary);
			
			lGenerateEmployerSponsoredAscii.closeFileWriter();
		} catch (Exception e) {
			logger.error("Issue attempting to generate Employer Sponsored Ascii File.  Message is " + e.getMessage());
			throw e;
		}
		
		Integer totalRecords = new Integer(0);
		
		if (lTrailerEmployerSponsoredContractSummary != null) {
			totalRecords = Integer.valueOf(lTrailerEmployerSponsoredContractSummary.getTotalRecords());
		}
		
		return totalRecords;
			
	}
	
	/*
	 * Generate formatted xml for requesting gift card orders from Intelispend vendor participants achieving a reward
	 * based on activities completed.
	 */
	public String generateIntelispendXMLRewardFileGiftCardOrders(Collection<RewardFulfillmentTrackingReportHist> lRewardFulfillmentTrackingReportHists
			, RewardCardClientData pKnowYourClientData)
	{
		
		StringBuffer xmlOrders = new StringBuffer();
		int orderCt = 0;
		if (lRewardFulfillmentTrackingReportHists.size() > 0) {
			xmlOrders.append(OutboundIntelispendTransFactory.getProductBeginTag());
			
			// KYC 
			xmlOrders.append(OutboundIntelispendTransFactory.createKnowYourClientSegment(pKnowYourClientData));
			
			for (RewardFulfillmentTrackingReportHist lRewardFulfillmentTrackingReportHist : lRewardFulfillmentTrackingReportHists) {
				orderCt++;
				String xmlOrder = OutboundIntelispendTransFactory.formatXMLOrderMapper(lRewardFulfillmentTrackingReportHist);	
				logger.info("Order " + orderCt + " = " + xmlOrder);
				xmlOrders.append(xmlOrder);		
			}	
			xmlOrders.append(OutboundIntelispendTransFactory.getProductEndTag());
		} 
		
		return xmlOrders.toString();
			
	}
	
	private Integer totalEmployerSponsoredActivityAmounts(Collection<DetailEmployerSponsoredActivity> detailEmployerSponsoredActivitys) {
		Integer totalAmount = 0;
		
		for (DetailEmployerSponsoredActivity lDetailEmployerSponsoredActivity : detailEmployerSponsoredActivitys) {
			totalAmount= totalAmount + Integer.valueOf(lDetailEmployerSponsoredActivity.getContributionAmt());
		}
		
		return totalAmount;
	}
	
	private Integer totalEmployerSponsoredContractSummaryAmounts(Collection<DetailEmployerSponsoredContractSummary> detailEmployerSponsoredContractsSummary) {
		Integer totalAmount = 0;
		
		for (DetailEmployerSponsoredContractSummary lDetailEmployerSponsoredContractSummary : detailEmployerSponsoredContractsSummary) {
			totalAmount= totalAmount + Integer.valueOf(lDetailEmployerSponsoredContractSummary.getSumOfContributionAmount());
		}
		
		return totalAmount;
	}


	
	
}

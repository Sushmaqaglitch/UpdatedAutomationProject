/**
 * 
 */
package com.healthpartners.service.imfs.dto;

import java.util.HashMap;

/**
 * @author tjquist
 * 
 */
public class RewardCardRecycleDetail extends BaseAuditableDTO {

	static final long serialVersionUID = 0L;

	private String firstName;
	private String middleName;
	private String lastName;
	private String memberNo;
	private Integer personID;
	private String fieldColumn;
	private String itemNo;
	private String reasonDesc;
	private String recycleStatus;

	
	
	/**
	 * 
	 */
	public RewardCardRecycleDetail() {
		super();
	}



	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getMiddleName() {
		return middleName;
	}



	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public String getMemberNo() {
		return memberNo;
	}



	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}



	public Integer getPersonID() {
		return personID;
	}



	public void setPersonID(Integer personID) {
		this.personID = personID;
	}



	public String getFieldColumn() {
		return fieldColumn;
	}



	public void setFieldColumn(String fieldColumn) {
		this.fieldColumn = fieldColumn;
	}



	public String getItemNo() {
		return itemNo;
	}



	public void setItemNo(String itemNo) {
		this.itemNo = itemNo;
	}



	public String getReasonDesc() {
		return reasonDesc;
	}



	public void setReasonDesc(String reasonDesc) {
		this.reasonDesc = reasonDesc;
	}



	public String getRecycleStatus() {
		return recycleStatus;
	}



	public void setRecycleStatus(String recycleStatus) {
		this.recycleStatus = recycleStatus;
	}




	

}

package com.healthpartners.service.imfs.dto;

public class Site extends BaseDTO
{
	static final long serialVersionUID = 0L;
	
	private Integer ID;
    private String siteName;
 
    public Site()
    {
    	super();
    }
    
	public Integer getID() {
		return ID;
	}
	public void setId(Integer id) {
		this.ID = id;
	}
	public String getSiteName() {
		return siteName;
	}
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}        
}

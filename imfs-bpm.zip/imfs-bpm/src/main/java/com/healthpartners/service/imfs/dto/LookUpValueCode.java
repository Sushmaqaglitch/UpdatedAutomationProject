/* $Id$ */

package com.healthpartners.service.imfs.dto;

/**
 * Represents a generic code from <code>cde_sets</code> table.
 * 
 * @author axpagey
 */
public class LookUpValueCode extends BaseDTO {
	
	static final long serialVersionUID = 0L;
	
	/**
	 * The unique identifier.
	 */
	private Integer luvId;
	
	/**
	 * The grouping code for the values.
	 */
	private String luvGroup;

	/**
	 * The value associated to the description.  Can be represented as an abreviated description.
	 */
	private String luvVal;

	/**
	 * A description of the value.
	 */
	private String luvDesc;

	/**
	 * Indicates whether or not this code is active. Inactive codes will be
	 * ignored.
	 */
	private String luvStatus;
	
	/**
	 * User responsible for creating the record.
	 */
	private String luvCreateUser;
	
	/**
	 * User responsible for updating the record.
	 */
	private String luvUpdateUser;
	
	/**
	 * A number assignment.
	 */
	private Integer luvNum;
	
	/**
	 * Controls sorting order.
	 */
	private Integer luvSortOrder;
	
	/**
	 * An attribute name.
	 */
	private String luvText;

	public String getLuvUpdateUser() {
		return luvUpdateUser;
	}

	public void setLuvUpdateUser(String luvUpdateUser) {
		this.luvUpdateUser = luvUpdateUser;
	}

	public LookUpValueCode() {
		super();
	}

	public LookUpValueCode(String luvGroup, String luvVal, String luvDesc,
			String luvStatus) {
		super();
		this.luvGroup = luvGroup;
		this.luvVal = luvVal;
		this.luvDesc = luvDesc;
		this.luvStatus = luvStatus;
	}

	public Integer getLuvId() {
		return luvId;
	}

	public void setLuvId(Integer luvId) {
		this.luvId = luvId;
	}

	public String getLuvCreateUser() {
		return luvCreateUser;
	}

	public void setLuvCreateUser(String luvCreateUser) {
		this.luvCreateUser = luvCreateUser;
	}

	public String getLuvDesc() {
		return luvDesc;
	}

	public void setLuvDesc(String luvDesc) {
		this.luvDesc = luvDesc;
	}

	public String getLuvGroup() {
		return luvGroup;
	}

	public void setLuvGroup(String luvGroup) {
		this.luvGroup = luvGroup;
	}

	public String getLuvStatus() {
		return luvStatus;
	}

	public void setLuvStatus(String luvStatus) {
		this.luvStatus = luvStatus;
	}

	public String getLuvVal() {
		return luvVal;
	}

	public void setLuvVal(String luvVal) {
		this.luvVal = luvVal;
	}

	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (obj == null || !(obj instanceof LookUpValueCode)) {
			return false;
		}

		LookUpValueCode otherObj = (LookUpValueCode) obj;

		boolean result = ((this.getLuvGroup() == null ? otherObj.getLuvGroup() == null
				: this.getLuvGroup().equals(otherObj.getLuvGroup()))
				&& (this.getLuvDesc() == null ? otherObj.getLuvDesc() == null
						: this.getLuvDesc().equals(otherObj.getLuvDesc()))
				&& (this.getLuvStatus() == null ? otherObj.getLuvStatus() == null
						: this.getLuvStatus().equals(
								otherObj.getLuvStatus())) && (this
				.getLuvVal() == null ? otherObj.getLuvVal() == null
				: this.getLuvVal().equals(otherObj.getLuvVal())));

		return result;
	}

	public int hashCode() {
		int hash = 1;
		hash = hash * 31 + (luvGroup == null ? 0 : luvGroup.hashCode());
		hash = hash * 31 + (luvDesc == null ? 0 : luvDesc.hashCode());
		return hash;
	}

	public int compareTo(Object otherObj) throws ClassCastException {
		if (!(otherObj instanceof LookUpValueCode))
			throw new ClassCastException("A GenericCode object expected.");
		return (this.equals(otherObj) ? 0 : -1);
	}

	public Integer getLuvNum() {
		return luvNum;
	}

	public void setLuvNum(Integer luvNum) {
		this.luvNum = luvNum;
	}

	public Integer getLuvSortOrder() {
		return luvSortOrder;
	}

	public void setLuvSortOrder(Integer luvSortOrder) {
		this.luvSortOrder = luvSortOrder;
	}

	public String getLuvText() {
		return luvText;
	}

	public void setLuvText(String luvText) {
		this.luvText = luvText;
	}

	
}

/**
 * 
 */
package com.healthpartners.service.imfs.dto;

import java.sql.Date;
import java.util.Calendar;

/**
 * @author tjquist
 *
 */
public class MemberProgramUpdateTO extends BaseAuditableDTO {

	static final long serialVersionUID = 0L;
	
	private Integer personID;

	private Integer programID;

	private Integer contractNumber; // for only contract sts
	
	private String statusCodeValue;
	
	private Date statusCodeDate;
	
	private String statusReasonCodeValue;

	private Calendar issueDate;
	
	private Calendar participationEndDate;
	
	private String externalPersonID;

	private Long id; // database id
	
	private String healthPlanCode;
	
	private Integer qualificationCheckmarkID;

	private Integer relationshipCodeID;
	
	private Calendar coverageEffectiveDate;
	
	private Integer programIncentiveOptionID;
	
	private String statusCodeValue2;
	
	private Date statusCodeDate2;;
	
	private Calendar issueDate2;
	
	//contract status stored in statusCodeValue
	//member status stored in statusCodeValue2
	private boolean contractStatusWithMemberStatus;
	
	//member status stored in statusCodeValue
	//contract status stored in statusCodeValue2
	private boolean memberStatusWithContractStatus;
	
	private String activationStatusCode;
	
	/**
	 * 
	 */
	public MemberProgramUpdateTO() {
		super();
	}


	public Integer getContractNumber() {
		return contractNumber;
	}


	public void setContractNumber(Integer contractNumber) {
		this.contractNumber = contractNumber;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public Calendar getIssueDate() {
		return issueDate;
	}


	public void setIssueDate(Calendar issueDate) {
		this.issueDate = issueDate;
	}


	public Integer getPersonID() {
		return personID;
	}


	public void setPersonID(Integer personID) {
		this.personID = personID;
	}


	public Integer getProgramID() {
		return programID;
	}


	public void setProgramID(Integer programID) {
		this.programID = programID;
	}


	public String getStatusCodeValue() {
		return statusCodeValue;
	}


	public void setStatusCodeValue(String statusCodeValue) {
		this.statusCodeValue = statusCodeValue;
	}
	
	


	public Date getStatusCodeDate() {
		return statusCodeDate;
	}


	public void setStatusCodeDate(Date statusCodeDate) {
		this.statusCodeDate = statusCodeDate;
	}


	public String getStatusReasonCodeValue() {
		return statusReasonCodeValue;
	}


	public void setStatusReasonCodeValue(String statusReasonCode) {
		this.statusReasonCodeValue = statusReasonCode;
	}


	public Calendar getParticipationEndDate() {
		return participationEndDate;
	}


	public void setParticipationEndDate(Calendar participationEndDate) {
		this.participationEndDate = participationEndDate;
	}


	public String getExternalPersonID() {
		return externalPersonID;
	}


	public void setExternalPersonID(String externalPersonID) {
		this.externalPersonID = externalPersonID;
	}


	public String getHealthPlanCode() {
		return healthPlanCode;
	}


	public void setHealthPlanCode(String healthPlanCode) {
		this.healthPlanCode = healthPlanCode;
	}


	public Integer getQualificationCheckmarkID() {
		return qualificationCheckmarkID;
	}


	public void setQualificationCheckmarkID(Integer qualificationCheckmarkID) {
		this.qualificationCheckmarkID = qualificationCheckmarkID;
	}


	public Integer getRelationshipCodeID() {
		return relationshipCodeID;
	}


	public void setRelationshipCodeID(Integer relationshipCodeID) {
		this.relationshipCodeID = relationshipCodeID;
	}


	public Calendar getCoverageEffectiveDate() {
		return coverageEffectiveDate;
	}


	public void setCoverageEffectiveDate(Calendar coverageEffectiveDate) {
		this.coverageEffectiveDate = coverageEffectiveDate;
	}


	public Integer getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}


	public void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}


	public String getStatusCodeValue2() {
		return statusCodeValue2;
	}


	public void setStatusCodeValue2(String statusCodeValue2) {
		this.statusCodeValue2 = statusCodeValue2;
	}
	
	


	public Date getStatusCodeDate2() {
		return statusCodeDate2;
	}


	public void setStatusCodeDate2(Date statusCodeDate2) {
		this.statusCodeDate2 = statusCodeDate2;
	}


	public Calendar getIssueDate2() {
		return issueDate2;
	}


	public void setIssueDate2(Calendar issueDate2) {
		this.issueDate2 = issueDate2;
	}


	public boolean isContractStatusWithMemberStatus() {
		return contractStatusWithMemberStatus;
	}


	public void setContractStatusWithMemberStatus(boolean contractStatusWithMemberStatus) {
		this.contractStatusWithMemberStatus = contractStatusWithMemberStatus;
	}


	public boolean isMemberStatusWithContractStatus() {
		return memberStatusWithContractStatus;
	}


	public void setMemberStatusWithContractStatus(boolean memberStatusWithContractStatus) {
		this.memberStatusWithContractStatus = memberStatusWithContractStatus;
	}


	public final String getActivationStatusCode() {
		return activationStatusCode;
	}


	public final void setActivationStatusCode(String activationStatusCode) {
		this.activationStatusCode = activationStatusCode;
	}


	

}

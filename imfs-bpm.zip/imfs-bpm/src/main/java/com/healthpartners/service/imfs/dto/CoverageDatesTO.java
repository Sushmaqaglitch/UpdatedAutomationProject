/**
 * 
 */
package com.healthpartners.service.imfs.dto;

import java.util.Calendar;

/**
 * @author tjquist
 * 
 */
public class CoverageDatesTO  {

	

	private Calendar packageDate = null;
	private Calendar subgroupDate = null;
	
	public Calendar getPackageDate() {
		return packageDate;
	}
	public void setPackageDate(Calendar packageDate) {
		this.packageDate = packageDate;
	}
	public Calendar getSubgroupDate() {
		return subgroupDate;
	}
	public void setSubgroupDate(Calendar subgroupDate) {
		this.subgroupDate = subgroupDate;
	}	
	
	

	
}

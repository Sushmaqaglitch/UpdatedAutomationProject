package com.healthpartners.service.imfs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;

import com.healthpartners.service.imfs.dto.GroupActivityProgressTracker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.dto.GroupActivityProgressTracker;
import com.healthpartners.service.imfs.exception.BPMException;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;


/**
 * 
 * @author jxbourbour
 *
 */
@Configuration
public class GroupActivityProgressTrackerDAOJdbc extends JdbcDaoSupport implements GroupActivityProgressTrackerDAO 
{
	private String selectGroupActivityProgressionTracker;
	
	private String insertGroupActivityProgressionTracker;
	private String updateGroupActivityProgressionTracker;


	@Autowired
	DataSource bpmDataSource;


	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}
	
	/**
	 * 
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public GroupActivityProgressTracker getGroupActivityProgressionTracker(String pInputFileName, java.sql.Date pBatchDate, Integer trackingStatusId)
	{
		
		JdbcTemplate template = getJdbcTemplate();
		StringBuffer lQuery = new StringBuffer();
		ArrayList<Object> lParameters = new ArrayList<Object>();
	    ArrayList<Integer> lTypes = new ArrayList<Integer>();
		
		lQuery.append(selectGroupActivityProgressionTracker);
		

		lParameters.add(pInputFileName);
		lTypes.add(new Integer(Types.VARCHAR));		
		
		if(pBatchDate != null)
	    {	    	
	    	lParameters.add(pBatchDate);
		    lTypes.add(new Integer(Types.DATE));
		    lQuery.append(" AND batch_dt = ? ");
	    }
		
		if(trackingStatusId != null)
	    {	    	
	    	lParameters.add(trackingStatusId);
		    lTypes.add(new Integer(Types.INTEGER));
		    lQuery.append(" AND tracking_status_id = ? ");
	    }
		
		
		// Convert the parameter arraylists to arrays.
		Object params[] = new Object[lParameters.size()];
	    lParameters.toArray(params);

	    int types[] = new int[lTypes.size()];
	    for(int j = 0; j < lTypes.size(); j++)
	    {
	    	types[j] = ((Integer)lTypes.get(j)).intValue();
	    }				
	    
	    Collection<GroupActivityProgressTracker> lGroupActivityProgressTrackers = (Collection<GroupActivityProgressTracker>) template.query(
	    		lQuery.toString(), params, types, new groupActivityProgressionTrackerMapper());
	    
	
	    GroupActivityProgressTracker lGroupActivityProgressTracker = null;
		if (lGroupActivityProgressTrackers != null && lGroupActivityProgressTrackers.size() > 0) {
			lGroupActivityProgressTracker = lGroupActivityProgressTrackers.iterator().next();
		}
		
		return lGroupActivityProgressTracker;
	}
	
	
	
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int updateGroupActivityProgressionTracker(GroupActivityProgressTracker pGroupActivityProgressTracker, String userID)
			throws DataAccessException {
		
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { pGroupActivityProgressTracker.getProgramID(),
										 pGroupActivityProgressTracker.getGroupNo(),
										 pGroupActivityProgressTracker.getGroupName(),
										 pGroupActivityProgressTracker.getPreprocessCount(),
										 pGroupActivityProgressTracker.getPreprocessAmount(), 
										 pGroupActivityProgressTracker.getPostprocessCount(),
										 pGroupActivityProgressTracker.getPostprocessAmount(),
										
										 pGroupActivityProgressTracker.getTrackingStatusCode(),
										
										 userID,
										 pGroupActivityProgressTracker.getBatchDate(),
										 pGroupActivityProgressTracker.getInputFileName()};
		
		int types[] = new int[] { Types.INTEGER, 
								  Types.VARCHAR,
								  Types.VARCHAR,
								  Types.INTEGER, 
								  Types.INTEGER, 
								  Types.INTEGER,
								  Types.INTEGER,
								  Types.VARCHAR,
								  Types.VARCHAR,
								  Types.DATE,
								  Types.VARCHAR};
		
		return template.update(updateGroupActivityProgressionTracker, params,
				types);
	}
	
	
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int insertGroupActivityProgressionTracker(GroupActivityProgressTracker pGroupActivityProgressTracker, String userID)
	throws DataAccessException {
		
	
		JdbcTemplate template = getJdbcTemplate();
		
	
		Object params[] = new Object[] { pGroupActivityProgressTracker.getProgramID(),
										 pGroupActivityProgressTracker.getGroupNo(),
										 pGroupActivityProgressTracker.getGroupName(),
										 pGroupActivityProgressTracker.getBatchDate(),
										 pGroupActivityProgressTracker.getPreprocessCount(),
										 pGroupActivityProgressTracker.getPreprocessAmount(),
										 pGroupActivityProgressTracker.getPostprocessCount(),
										 pGroupActivityProgressTracker.getPostprocessAmount(),
										 pGroupActivityProgressTracker.getTrackingStatusID(),
										 pGroupActivityProgressTracker.getInputFileName(),
										 pGroupActivityProgressTracker.getTrackingReason(),
										 userID };
										
		int types[] = new int[] { Types.INTEGER, 
				 				  Types.VARCHAR,
				 				  Types.VARCHAR,
								  Types.DATE,
								  Types.VARCHAR,
								  Types.INTEGER,
								  Types.INTEGER,
								  Types.INTEGER,
								  Types.VARCHAR,
								  Types.VARCHAR,
								  Types.VARCHAR,
								  Types.VARCHAR};
	
		int rowInserted = template.update(insertGroupActivityProgressionTracker, params,
				types);
	
		
		return rowInserted;
	}
	
	private static final class groupActivityProgressionTrackerMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			GroupActivityProgressTracker lGroupActivityProgressTracker = new GroupActivityProgressTracker();
			
			lGroupActivityProgressTracker.setProgramID(rs.getInt("biz_pgm_id"));
			lGroupActivityProgressTracker.setGroupNo(rs.getString("grp_no"));
			lGroupActivityProgressTracker.setGroupName(rs.getString("grp_name"));
			lGroupActivityProgressTracker.setBatchDate(rs.getDate("batch_dt"));
			lGroupActivityProgressTracker.setPreprocessCount(rs.getInt("preprocess_ct"));
			lGroupActivityProgressTracker.setPostprocessCount(rs.getInt("postprocess_ct"));
			lGroupActivityProgressTracker.setPreprocessAmount(rs.getInt("preprocess_amt"));
			lGroupActivityProgressTracker.setPostprocessAmount(rs.getInt("postprocess_amt"));
			lGroupActivityProgressTracker.setTrackingStatusCode(rs.getString("tracking_status_code"));
			lGroupActivityProgressTracker.setTrackingStatusID(rs.getInt("tracking_status_id"));
			lGroupActivityProgressTracker.setInputFileName(rs.getString("input_file_name"));
			lGroupActivityProgressTracker.setTrackingReason(rs.getString("tracking_reason"));
			
			

			return lGroupActivityProgressTracker;
		}
	}

	public String getSelectGroupActivityProgressionTracker() {
		return selectGroupActivityProgressionTracker;
	}


	public void setSelectGroupActivityProgressionTracker(
			String selectGroupActivityProgressionTracker) {
		this.selectGroupActivityProgressionTracker = selectGroupActivityProgressionTracker;
	}
	
	

	

	public String getInsertGroupActivityProgressionTracker() {
		return insertGroupActivityProgressionTracker;
	}


	public void setInsertGroupActivityProgressionTracker(
			String insertGroupActivityProgressionTracker) {
		this.insertGroupActivityProgressionTracker = insertGroupActivityProgressionTracker;
	}


	public String getUpdateGroupActivityProgressionTracker() {
		return updateGroupActivityProgressionTracker;
	}


	public void setUpdateGroupActivityProgressionTracker(
			String updateGroupActivityProgressionTracker) {
		this.updateGroupActivityProgressionTracker = updateGroupActivityProgressionTracker;
	}


	
	
	
}

/**
 * 
 */
package com.healthpartners.service.imfs.dto;

import java.util.ArrayList;

/**
 * This DTO is a one dimensional arraylist storing data elements (nodes) resolved from a csv file.
 * When class is instantiated as an arraylist, it will become 2 dimensional.
 * @author tjquist
 * 
 */
public class CSVTokens {
	private ArrayList<String> csvTokenColumns = new ArrayList<String>();
	
	/**
	 * Keep track of tokens in arraylist.  Each token represents a data element read in from 
	 * a csv file.  This dto is a holding area where tokens will later be moved to a more specifically defined dto. 
	 */
	public CSVTokens() {
		super();
		
	}

	public ArrayList<String> getCsvTokenColumns() {
		return csvTokenColumns;
	}

	public void setCsvTokenColumns(ArrayList<String> csvTokenColumns) {
		this.csvTokenColumns = csvTokenColumns;
	}

	
}

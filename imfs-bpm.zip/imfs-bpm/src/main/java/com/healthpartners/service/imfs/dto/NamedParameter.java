package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.sql.Date;
import java.util.Calendar;

public class NamedParameter implements Serializable {

    private String emplGrpNo;
    private String pSiteNo;
    private Integer personId;
    private Integer actvId;
    private Integer bizPgmId;
    private String luGrpNo;
    private String luValNo;
    private String memberId;
    private Integer relationId;
    private Integer contractId;
    private Integer incentiveId;
    private String activityNum;
    private Calendar pCurrentDate;
    private Integer incentiveReqGroupId;
    private Integer qualificationCheckId;
    private Integer reqQualCheckId;
    private Date startDate;
    private String programCode;
    private Date businessPrgmStartDate;
    private String groupNo;
    private java.util.Date pActivityDate;
    private String authCode;
    private String purchSubTpNm;
    private String registrationId;
    private Integer contribAmt;
    private Date lastSuccessRunDate;
    private String firstName;
    private String middleInitial;
    private String lastName;
    private String gender;
    private String sourceSystemId;
    private Integer rewardTxnHistId;
    private Integer benPkgId;
    private Integer rewardStatusId;
    private Integer luId;
    private Integer subGrpId;
    private Integer collectionId;
    private String luGrp;
    private String luGrp2;
    private String luVal;
    private String luVal2;
    private String val1;
    private String val2;
    private Calendar statusEffectiveDate;
    private String sourceActivityID;
    private String insertUserId;
    private String modifyUserId;
    private String authPromoCode;
    private String activityOutCome;
    private String activityStatus;
    private Calendar businessPgmEffDate;
    private Calendar businessPgmEndDate;
    private String exclusionOptionFlag;
    private Integer activityID;

    public Integer getCollectionId() {
        return collectionId;
    }

    public void setCollectionId(Integer collectionId) {
        this.collectionId = collectionId;
    }

    public Integer getSubGrpId() {
        return subGrpId;
    }

    public void setSubGrpId(Integer subGrpId) {
        this.subGrpId = subGrpId;
    }

    public Integer getLuId() {
        return luId;
    }

    public void setLuId(Integer luId) {
        this.luId = luId;
    }

    public Integer getRewardStatusId() {
        return rewardStatusId;
    }

    public void setRewardStatusId(Integer rewardStatusId) {
        this.rewardStatusId = rewardStatusId;
    }

    public Integer getBenPkgId() {
        return benPkgId;
    }

    public void setBenPkgId(Integer benPkgId) {
        this.benPkgId = benPkgId;
    }

    public Integer getRewardTxnHistId() {
        return rewardTxnHistId;
    }

    public void setRewardTxnHistId(Integer rewardTxnHistId) {
        this.rewardTxnHistId = rewardTxnHistId;
    }

    public String getEmplGrpNo() {
        return emplGrpNo;
    }

    public void setEmplGrpNo(String emplGrpNo) {
        this.emplGrpNo = emplGrpNo;
    }

    public String getpSiteNo() {
        return pSiteNo;
    }

    public void setpSiteNo(String pSiteNo) {
        this.pSiteNo = pSiteNo;
    }

    public Integer getPersonId() {
        return personId;
    }

    public void setPersonId(Integer personId) {
        this.personId = personId;
    }

    public Integer getActvId() {
        return actvId;
    }

    public void setActvId(Integer actvId) {
        this.actvId = actvId;
    }


    public Integer getBizPgmId() {
        return bizPgmId;
    }

    public void setBizPgmId(Integer bizPgmId) {
        this.bizPgmId = bizPgmId;
    }

    public String getLuGrpNo() {
        return luGrpNo;
    }

    public void setLuGrpNo(String luGrpNo) {
        this.luGrpNo = luGrpNo;
    }

    public String getLuValNo() {
        return luValNo;
    }

    public void setLuValNo(String luValNo) {
        this.luValNo = luValNo;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public Integer getRelationId() {
        return relationId;
    }

    public void setRelationId(Integer relationId) {
        this.relationId = relationId;
    }

    public Integer getContractId() {
        return contractId;
    }

    public void setContractId(Integer contractId) {
        this.contractId = contractId;
    }

    public Integer getIncentiveId() {
        return incentiveId;
    }

    public void setIncentiveId(Integer incentiveId) {
        this.incentiveId = incentiveId;
    }

    public String getActivityNum() {
        return activityNum;
    }

    public void setActivityNum(String activityNum) {
        this.activityNum = activityNum;
    }


    public Calendar getpCurrentDate() {
        return pCurrentDate;
    }

    public void setpCurrentDate(Calendar pCurrentDate) {
        this.pCurrentDate = pCurrentDate;
    }

    public Integer getIncentiveReqGroupId() {
        return incentiveReqGroupId;
    }

    public void setIncentiveReqGroupId(Integer incentiveReqGroupId) {
        this.incentiveReqGroupId = incentiveReqGroupId;
    }

    public Integer getQualificationCheckId() {
        return qualificationCheckId;
    }

    public void setQualificationCheckId(Integer qualificationCheckId) {
        this.qualificationCheckId = qualificationCheckId;
    }

    public Integer getReqQualCheckId() {
        return reqQualCheckId;
    }

    public void setReqQualCheckId(Integer reqQualCheckId) {
        this.reqQualCheckId = reqQualCheckId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public String getProgramCode() {
        return programCode;
    }

    public void setProgramCode(String programCode) {
        this.programCode = programCode;
    }

    public Date getBusinessPrgmStartDate() {
        return businessPrgmStartDate;
    }

    public void setBusinessPrgmStartDate(Date businessPrgmStartDate) {
        this.businessPrgmStartDate = businessPrgmStartDate;
    }

    public String getGroupNo() {
        return groupNo;
    }

    public void setGroupNo(String groupNo) {
        this.groupNo = groupNo;
    }

    public java.util.Date getpActivityDate() {
        return pActivityDate;
    }

    public void setpActivityDate(java.util.Date pActivityDate) {
        this.pActivityDate = pActivityDate;
    }

    public String getAuthCode() {
        return authCode;
    }

    public void setAuthCode(String authCode) {
        this.authCode = authCode;
    }

    public String getPurchSubTpNm() {
        return purchSubTpNm;
    }

    public void setPurchSubTpNm(String purchSubTpNm) {
        this.purchSubTpNm = purchSubTpNm;

    }

    public String getRegistrationId() {
        return registrationId;
    }

    public void setRegistrationId(String registrationId) {
        this.registrationId = registrationId;
    }

    public Integer getContribAmt() {
        return contribAmt;
    }

    public void setContribAmt(Integer contribAmt) {
        this.contribAmt = contribAmt;
    }

    public Date getLastSuccessRunDate() {
        return lastSuccessRunDate;
    }

    public void setLastSuccessRunDate(Date lastSuccessRunDate) {
        this.lastSuccessRunDate = lastSuccessRunDate;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleInitial() {
        return middleInitial;
    }

    public void setMiddleInitial(String middleInitial) {
        this.middleInitial = middleInitial;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getSourceSystemId() {
        return sourceSystemId;
    }

    public void setSourceSystemId(String sourceSystemId) {
        this.sourceSystemId = sourceSystemId;
    }

    public String getLuGrp() {
        return luGrp;
    }

    public void setLuGrp(String luGrp) {
        this.luGrp = luGrp;
    }

    public String getLuGrp2() {
        return luGrp2;
    }

    public void setLuGrp2(String luGrp2) {
        this.luGrp2 = luGrp2;
    }

    public String getLuVal() {
        return luVal;
    }

    public void setLuVal(String luVal) {
        this.luVal = luVal;
    }

    public String getLuVal2() {
        return luVal2;
    }

    public void setLuVal2(String luVal2) {
        this.luVal2 = luVal2;
    }

    public String getVal1() {
        return val1;
    }

    public void setVal1(String val1) {
        this.val1 = val1;
    }

    public String getVal2() {
        return val2;
    }

    public void setVal2(String val2) {
        this.val2 = val2;
    }

    public Calendar getStatusEffectiveDate() {
        return statusEffectiveDate;
    }

    public void setStatusEffectiveDate(Calendar statusEffectiveDate) {
        this.statusEffectiveDate = statusEffectiveDate;
    }

    public String getSourceActivityID() {
        return sourceActivityID;
    }

    public void setSourceActivityID(String sourceActivityID) {
        this.sourceActivityID = sourceActivityID;
    }

    public String getInsertUserId() {
        return insertUserId;
    }

    public void setInsertUserId(String insertUserId) {
        this.insertUserId = insertUserId;
    }

    public String getAuthPromoCode() {
        return authPromoCode;
    }

    public void setAuthPromoCode(String authPromoCode) {
        this.authPromoCode = authPromoCode;
    }

    public String getActivityOutCome() {
        return activityOutCome;
    }

    public void setActivityOutCome(String activityOutCome) {
        this.activityOutCome = activityOutCome;
    }

    public String getModifyUserId() {
        return modifyUserId;
    }

    public void setModifyUserId(String modifyUserId) {
        this.modifyUserId = modifyUserId;
    }

    public String getActivityStatus() {
        return activityStatus;
    }

    public void setActivityStatus(String activityStatus) {
        this.activityStatus = activityStatus;
    }

    public Calendar getBusinessPgmEffDate() {
        return businessPgmEffDate;
    }

    public void setBusinessPgmEffDate(Calendar businessPgmEffDate) {
        this.businessPgmEffDate = businessPgmEffDate;
    }

    public Calendar getBusinessPgmEndDate() {
        return businessPgmEndDate;
    }

    public void setBusinessPgmEndDate(Calendar businessPgmEndDate) {
        this.businessPgmEndDate = businessPgmEndDate;
    }

    public String getExclusionOptionFlag() {
        return exclusionOptionFlag;
    }

    public void setExclusionOptionFlag(String exclusionOptionFlag) {
        this.exclusionOptionFlag = exclusionOptionFlag;
    }

    public Integer getActivityID() {
        return activityID;
    }

    public void setActivityID(Integer activityID) {
        this.activityID = activityID;
    }
}



package com.healthpartners.service.imfs.dto;


public class RewardCardError {

	private String dataElement;
	
	private String errorReason;
	
	private RewardIntelispendShipped rewardIntelispendShipped;
	
	private RewardIntelispendOrdered rewardIntelispendOrdered;
	
	
	public RewardCardError() {
		super();
	}

	public String getDataElement() {
		return dataElement;
	}

	public void setDataElement(String dataElement) {
		this.dataElement = dataElement;
	}

	public String getErrorReason() {
		return errorReason;
	}

	public void setErrorReason(String errorReason) {
		this.errorReason = errorReason;
	}

	public RewardIntelispendShipped getRewardIntelispendShipped() {
		return rewardIntelispendShipped;
	}

	public void setRewardIntelispendShipped(RewardIntelispendShipped rewardIntelispendShipped) {
		this.rewardIntelispendShipped = rewardIntelispendShipped;
	}

	public RewardIntelispendOrdered getRewardIntelispendOrdered() {
		return rewardIntelispendOrdered;
	}

	public void setRewardIntelispendOrdered(RewardIntelispendOrdered rewardIntelispendOrdered) {
		this.rewardIntelispendOrdered = rewardIntelispendOrdered;
	}

}

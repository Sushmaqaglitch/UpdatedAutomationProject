package com.healthpartners.service.imfs.iface;

import com.healthpartners.service.imfs.rules.StatusCalculationCommand;
import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.exception.BPMException;


public interface PersonContractRecycleReportService {
	
	public void createPersonContractRecycleReportOnActionNeededStatusesCommand(
			StatusCalculationCommand statusCalculationCommand)
			throws BPMException, DataAccessException;

}

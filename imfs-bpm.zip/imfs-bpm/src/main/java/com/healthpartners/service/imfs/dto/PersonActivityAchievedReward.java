package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.sql.Date;

public class PersonActivityAchievedReward implements Serializable
{	
	static final long serialVersionUID = 0L;
		
	private Integer personID;
	private Integer personDemographicsID;
	private Integer  contractNo;
	private String  memberNo;
	private String firstName;
	private String lastName;
	private String middleName;
	private Integer groupID;
	private Integer subgroupID;
	private String  groupNo;
	private String  siteNo;
	private Date    activityStatDate;
	private Date    contributionDate;
	private String  activityIncentiveStatus;
	private String  programType;
	private Integer programID;
	private Integer programIncentiveOptionID;
	private Integer businessProgramTypeCode;
	private Integer incentedStatusTypeCodeID;
	private Integer participantCap;
	private Integer familyCap;
	private Integer contributionAmt;
	private Integer contribTypeCodeID;
	private Integer contribGridID;
	private Integer activityID;
	private String  sourceActivityID;
	private String  benefitContractType;
	private Integer participantCount;
	private Integer incentiveOptionID;
	private String externalTransactionID;
	private String orderID;
	private String rewardCardNoMask; 
	private Integer vendorFee;
	private Integer packageID;
	private String systemID;
	private Integer incentiveStatusActivityDetailID;
	private Integer contractIncentiveStatID;
	private Integer memberIncentiveStatID;
	
	
	
	public Integer getPersonID() {
		return personID;
	}
	public void setPersonID(Integer personID) {
		this.personID = personID;
	}
	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}
	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}
	
	public Integer getContractNo() {
		return contractNo;
	}
	public void setContractNo(Integer contractNo) {
		this.contractNo = contractNo;
	}
	public String getMemberNo() {
		return memberNo;
	}
	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public Integer getGroupID() {
		return groupID;
	}
	public void setGroupID(Integer groupID) {
		this.groupID = groupID;
	}
	public Integer getSubgroupID() {
		return subgroupID;
	}
	public void setSubgroupID(Integer subgroupID) {
		this.subgroupID = subgroupID;
	}
	public String getGroupNo() {
		return groupNo;
	}
	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}
	
	public String getSiteNo() {
		return siteNo;
	}
	public void setSiteNo(String siteNo) {
		this.siteNo = siteNo;
	}
	public Date getActivityStatDate() {
		return activityStatDate;
	}
	public void setActivityStatDate(Date activityStatDate) {
		this.activityStatDate = activityStatDate;
	}
	
	
	public Date getContributionDate() {
		return contributionDate;
	}
	public void setContributionDate(Date contributionDate) {
		this.contributionDate = contributionDate;
	}
	public String getActivityIncentiveStatus() {
		return activityIncentiveStatus;
	}
	public void setActivityIncentiveStatus(String activityIncentiveStatus) {
		this.activityIncentiveStatus = activityIncentiveStatus;
	}
	public String getProgramType() {
		return programType;
	}
	public void setProgramType(String programType) {
		this.programType = programType;
	}
	
	public Integer getProgramID() {
		return programID;
	}
	public void setProgramID(Integer programID) {
		this.programID = programID;
	}
	
	
	
	public Integer getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}
	public void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}
	public Integer getBusinessProgramTypeCode() {
		return businessProgramTypeCode;
	}
	public void setBusinessProgramTypeCode(Integer businessProgramTypeCode) {
		this.businessProgramTypeCode = businessProgramTypeCode;
	}
	
	
	
	public Integer getIncentedStatusTypeCodeID() {
		return incentedStatusTypeCodeID;
	}
	public void setIncentedStatusTypeCodeID(Integer incentedStatusTypeCodeID) {
		this.incentedStatusTypeCodeID = incentedStatusTypeCodeID;
	}
	public Integer getParticipantCap() {
		return participantCap;
	}
	public void setParticipantCap(Integer participantCap) {
		this.participantCap = participantCap;
	}
	
	
	public Integer getFamilyCap() {
		return familyCap;
	}
	public void setFamilyCap(Integer familyCap) {
		this.familyCap = familyCap;
	}
	public Integer getContributionAmt() {
		return contributionAmt;
	}
	public void setContributionAmt(Integer contributionAmt) {
		this.contributionAmt = contributionAmt;
	}
	

	public Integer getContribTypeCodeID() {
		return contribTypeCodeID;
	}
	public void setContribTypeCodeID(Integer contribTypeCodeID) {
		this.contribTypeCodeID = contribTypeCodeID;
	}
	
	
	
	public Integer getContribGridID() {
		return contribGridID;
	}
	public void setContribGridID(Integer contribGridID) {
		this.contribGridID = contribGridID;
	}
	public Integer getActivityID() {
		return activityID;
	}
	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}
	
	public String getSourceActivityID() {
		return sourceActivityID;
	}
	public void setSourceActivityID(String sourceActivityID) {
		this.sourceActivityID = sourceActivityID;
	}
	
	public String getBenefitContractType() {
		return benefitContractType;
	}
	public void setBenefitContractType(String benefitContractType) {
		this.benefitContractType = benefitContractType;
	}
	public Integer getParticipantCount() {
		return participantCount;
	}
	public void setParticipantCount(Integer participantCount) {
		this.participantCount = participantCount;
	}
	public Integer getIncentiveOptionID() {
		return incentiveOptionID;
	}
	public void setIncentiveOptionID(Integer incentiveOptionID) {
		this.incentiveOptionID = incentiveOptionID;
	}
	
	public String getExternalTransactionID() {
		return externalTransactionID;
	}
	public void setExternalTransactionID(String externalTransactionID) {
		this.externalTransactionID = externalTransactionID;
	}
	public String getOrderID() {
		return orderID;
	}
	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}
	public String getRewardCardNoMask() {
		return rewardCardNoMask;
	}
	public void setRewardCardNoMask(String rewardCardNoMask) {
		this.rewardCardNoMask = rewardCardNoMask;
	}
	public Integer getVendorFee() {
		return vendorFee;
	}
	public void setVendorFee(Integer vendorFee) {
		this.vendorFee = vendorFee;
	}
	public Integer getPackageID() {
		return packageID;
	}
	public void setPackageID(Integer packageID) {
		this.packageID = packageID;
	}
	public String getSystemID() {
		return systemID;
	}
	public void setSystemID(String systemID) {
		this.systemID = systemID;
	}
	public Integer getIncentiveStatusActivityDetailID() {
		return incentiveStatusActivityDetailID;
	}
	public void setIncentiveStatusActivityDetailID(
			Integer incentiveStatusActivityDetailID) {
		this.incentiveStatusActivityDetailID = incentiveStatusActivityDetailID;
	}
	public Integer getContractIncentiveStatID() {
		return contractIncentiveStatID;
	}
	public void setContractIncentiveStatID(Integer contractIncentiveStatID) {
		this.contractIncentiveStatID = contractIncentiveStatID;
	}
	public Integer getMemberIncentiveStatID() {
		return memberIncentiveStatID;
	}
	public void setMemberIncentiveStatID(Integer memberIncentiveStatID) {
		this.memberIncentiveStatID = memberIncentiveStatID;
	}
	
			
}

/**
 * 
 */
package com.healthpartners.service.imfs.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import com.healthpartners.service.imfs.common.BPMEmailUtility;
import com.healthpartners.service.imfs.dao.LookUpValueDAO;
import com.healthpartners.service.imfs.iface.EmailService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMEmailUtility;
import com.healthpartners.service.imfs.dao.LookUpValueDAO;
import com.healthpartners.service.imfs.dto.LookUpValueCode;
import com.healthpartners.service.imfs.iface.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/**
 * Provides a common interface to send project emails.
 * 
 * @author jxbourbour
 */
@Component
@Service
public class EmailServiceImpl implements EmailService
{
	@Autowired
	private LookUpValueDAO lookUpValueDAO;
	@Autowired
	private BPMEmailUtility bpmEmailUtility;

	private String emailContentType;

	@Autowired
    private String hostName;

	protected final Log logger = LogFactory.getLog(getClass());
	
	protected String emailDestination;
	
	
	

	/**
	 * 
	 */
	public EmailServiceImpl() {
		super();
	}

	
	public void prepareAndSendBatchStatusEmail(String emailSubject, String emailContent)
	{
		this.prepareAndSendBatchStatusEmail(emailSubject, emailContent, null);
	}
	
	
	public void prepareAndSendBatchStatusEmail(String emailSubject, String emailContent, Collection<String> attachmentLocations) 
	{
		String emailServerHost = null;
		String emailFromAddress = null;
		String dbEnvirnment = "";
		List<String> emailToAddress = new ArrayList<String>();
		StringBuffer appendEmailContent = new StringBuffer();
		try {

			Collection<LookUpValueCode> serverHost = lookUpValueDAO
					.getLUVCodesByGroup(BPMConstants.BPM_EMAIL_HOST_SRVR);
			Collection<LookUpValueCode> fromAddress = lookUpValueDAO
					.getLUVCodesByGroup(BPMConstants.BPM_EMAIL_FROM_ADDR);
			
			Collection<LookUpValueCode> toAddress;
			if (emailDestination != null && emailDestination.equals(BPMConstants.EMAIL_DESTINATION_MEMBERSHIP)) {
				toAddress = lookUpValueDAO.getLUVCodesByGroup(BPMConstants.BPM_EMAIL_TO_ADDR);
				//Add larger group distribution lists for membership feed.
				Collection<LookUpValueCode> toEmailAddrForMembershipFeed = lookUpValueDAO
						.getLUVCodesByGroup(BPMConstants.BPM_EMAIL_TO_ADDR_MEMBERSHIP);
				if (toEmailAddrForMembershipFeed.size() > 0) {
					toAddress.addAll(toEmailAddrForMembershipFeed);
				}
			} else if (emailDestination != null && emailDestination.equals(BPMConstants.EMAIL_DESTINATION_MEMBERSHIP_ONHOLD_RPT)) {
					//Add larger group distribution lists for membership feed ON HOLD report.
					toAddress = lookUpValueDAO
							.getLUVCodesByGroup(BPMConstants.BPM_EMAIL_TO_ADDR_MEMBERSHIP_ONHOLD_RPT);
			} else if (emailDestination != null && emailDestination.equals(BPMConstants.EMAIL_DESTINATION_EMPLOYER_FULFILLMENT_RPT)) {
				//Add larger group distribution lists for membership feed ON HOLD report.
				toAddress = lookUpValueDAO
						.getLUVCodesByGroup(BPMConstants.BPM_EMAIL_TO_ADDR_EMPL_FULFILL_RPT);		
			} else if (emailDestination != null && emailDestination.equals(BPMConstants.BPM_EMAIL_TO_ADDR_RECONCILE_RPT)) {
				//Add larger group distribution lists for membership feed ON HOLD report.
				toAddress = lookUpValueDAO
						.getLUVCodesByGroup(BPMConstants.BPM_EMAIL_TO_ADDR_RECONCILE_RPT);
			} else if (emailDestination != null && emailDestination.equals(BPMConstants.EMAIL_DESTINATION_CDHP_HRA)) {
				toAddress = lookUpValueDAO
						.getLUVCodesByGroup(BPMConstants.BPM_EMAIL_TO_ADDR_HRA);
			} else if (emailDestination != null && emailDestination.equals(BPMConstants.EMAIL_DESTINATION_CDHP_HSA)) {
				toAddress = lookUpValueDAO
						.getLUVCodesByGroup(BPMConstants.BPM_EMAIL_TO_ADDR_HSA);
			} else if (emailDestination != null && emailDestination.equals(BPMConstants.BPM_EMAIL_TO_ADDR_MEMBERSHIP_ONHOLD_RPT)) {
				toAddress = lookUpValueDAO
						.getLUVCodesByGroup(BPMConstants.BPM_EMAIL_TO_ADDR_MEMBERSHIP_ONHOLD_RPT);
			} else {
				toAddress = lookUpValueDAO
				.getLUVCodesByGroup(BPMConstants.BPM_EMAIL_TO_ADDR);
			}

			Collection<LookUpValueCode> dbEnvirnments = lookUpValueDAO
					.getLUVCodesByGroup(BPMConstants.BPM_DB_ENV);

			// email server host
			Iterator<LookUpValueCode> itrHost = serverHost.iterator();
			if (itrHost.hasNext()) {
				LookUpValueCode lvalue = itrHost.next();
				emailServerHost = lvalue.getLuvDesc();
			}

			// from address
			Iterator<LookUpValueCode> itrTo = fromAddress.iterator();
			if (itrTo.hasNext()) {
				LookUpValueCode lvalue = itrTo.next();
				emailFromAddress = lvalue.getLuvDesc();
			}

			// to address
			Iterator<LookUpValueCode> itr = toAddress.iterator();
			while (itr.hasNext()) {
				LookUpValueCode lvalue = itr.next();
				emailToAddress.add(lvalue.getLuvDesc());
			}

			Iterator<LookUpValueCode> itrEnv = dbEnvirnments.iterator();
			while (itrEnv.hasNext()) {
				LookUpValueCode lvalue = itrEnv.next();
				dbEnvirnment = lvalue.getLuvDesc();
				break;
			}

			appendEmailContent.append("<table>");
			appendEmailContent.append("<tr><td>Database Environment: ");
			appendEmailContent.append(dbEnvirnment + "</td></tr>");
			appendEmailContent.append("<tr><td>Application Server: ");
			appendEmailContent.append(hostName + "</td></tr>");
			emailContent = appendEmailContent.toString() + "<tr><td>" + emailContent + "</table>";
			
			emailSubject = emailSubject + " - " + dbEnvirnment;


			String contentType;
			//email content type should default to html when html tags are always being used.
			contentType = bpmEmailUtility.EMAIL_CONTENT_TYPE_HTML;
//			if (emailContentType != null && emailContentType.equals(bpmEmailUtility.EMAIL_CONTENT_TYPE_HTML)) {
//				contentType = bpmEmailUtility.EMAIL_CONTENT_TYPE_HTML;
//			} else {
//				contentType = bpmEmailUtility.EMAIL_CONTENT_TYPE_TEXT;
//			}
			
			bpmEmailUtility.sendEmail(emailServerHost, emailFromAddress,
				emailToAddress, emailSubject, emailContent,
				contentType, attachmentLocations);
			
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			logger.error("  emailToAddress=" + emailToAddress);
			logger.error("  emailFromAddress=" + emailFromAddress);
			logger.error("  emailSubject=" + emailSubject);
			logger.error("  emailContent=" + emailContent);
		}
	}


	public BPMEmailUtility getBpmEmailUtility() {
		return bpmEmailUtility;
	}


	public void setBpmEmailUtility(BPMEmailUtility bpmEmailUtility) {
		this.bpmEmailUtility = bpmEmailUtility;
	}


	public String getHostName() {
		return hostName;
	}


	public void setHostName(String hostName) {
		this.hostName = hostName;
	}


	public LookUpValueDAO getLookUpValueDAO() {
		return lookUpValueDAO;
	}


	public void setLookUpValueDAO(LookUpValueDAO lookUpValueDAO) {
		this.lookUpValueDAO = lookUpValueDAO;
	}
	
	public String getEmailDestination() {
		return emailDestination;
	}


	public void setEmailDestination(String emailDestination) {
		this.emailDestination = emailDestination;
	}


	public void setEmailContentType(String emailContentType) {
		this.emailContentType = emailContentType;
	}

	
	
}

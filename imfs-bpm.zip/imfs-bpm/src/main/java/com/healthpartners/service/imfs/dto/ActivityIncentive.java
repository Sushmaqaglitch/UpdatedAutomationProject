package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * 
 * @author jxbourbour
 *
 */
public class ActivityIncentive implements Serializable
{	
	static final long serialVersionUID = 0L;

	private Integer activityIncentiveID;
	private Integer activityIncentiveGroupID;
	private Integer activityIncentiveGroupReqID;
	private Integer incentiveOptionID;
	private Integer businessProgramID;
	private Integer activityID;
	private Integer activityTypeID;
	private Integer activityIncentiveTypeID;
	private Integer incentedStatusTypeID;
	private String incentedStatusTypeCode;
	private Integer incentiveQuantity;
	private Integer participantCap;
	private Integer familyCap;
	private java.sql.Date enrollByDeadlineDate;
	private java.sql.Date completeByDeadlineDate;
	private String incentiveRuleTypeCode;
	private String incentedStatusTypeCodeDesc;
	private java.sql.Date effectiveDate;
	private java.sql.Date endDate;
	
	private ActivityCollection activityCollection;

	private ArrayList<IncentiveParticipant> incentiveParticipants;
			       
    public ActivityIncentive()
    {
    	super();
    }

	public Integer getActivityIncentiveID() {
		return activityIncentiveID;
	}

	public void setActivityIncentiveID(Integer activityIncentiveID) {
		this.activityIncentiveID = activityIncentiveID;
	}

	public Integer getActivityIncentiveGroupID() {
		return activityIncentiveGroupID;
	}

	public void setActivityIncentiveGroupID(Integer activityIncentiveGroupID) {
		this.activityIncentiveGroupID = activityIncentiveGroupID;
	}

	public Integer getActivityIncentiveGroupReqID() {
		return activityIncentiveGroupReqID;
	}

	public void setActivityIncentiveGroupReqID(Integer activityIncentiveGroupReqID) {
		this.activityIncentiveGroupReqID = activityIncentiveGroupReqID;
	}

	public Integer getIncentiveOptionID() {
		return incentiveOptionID;
	}

	public void setIncentiveOptionID(Integer incentiveOptionID) {
		this.incentiveOptionID = incentiveOptionID;
	}

	public Integer getBusinessProgramID() {
		return businessProgramID;
	}

	public void setBusinessProgramID(Integer businessProgramID) {
		this.businessProgramID = businessProgramID;
	}

	public Integer getActivityID() {
		return activityID;
	}

	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}

	public Integer getActivityTypeID() {
		return activityTypeID;
	}

	public void setActivityTypeID(Integer activityTypeID) {
		this.activityTypeID = activityTypeID;
	}

	public Integer getActivityIncentiveTypeID() {
		return activityIncentiveTypeID;
	}

	public void setActivityIncentiveTypeID(Integer activityIncentiveTypeID) {
		this.activityIncentiveTypeID = activityIncentiveTypeID;
	}

	public Integer getIncentedStatusTypeID() {
		return incentedStatusTypeID;
	}

	public void setIncentedStatusTypeID(Integer incentedStatusTypeID) {
		this.incentedStatusTypeID = incentedStatusTypeID;
	}

	public Integer getIncentiveQuantity() {
		return incentiveQuantity;
	}

	public void setIncentiveQuantity(Integer incentiveQuantity) {
		this.incentiveQuantity = incentiveQuantity;
	}

	public ArrayList<IncentiveParticipant> getIncentiveParticipants() {
		return incentiveParticipants;
	}

	public void setIncentiveParticipants(
			ArrayList<IncentiveParticipant> incentiveParticipants) {
		this.incentiveParticipants = incentiveParticipants;
	}

	public String getIncentedStatusTypeCode() {
		return incentedStatusTypeCode;
	}

	public void setIncentedStatusTypeCode(String incentedStatusTypeCode) {
		this.incentedStatusTypeCode = incentedStatusTypeCode;
	}

	public Integer getParticipantCap() {
		return participantCap;
	}

	public void setParticipantCap(Integer participantCap) {
		this.participantCap = participantCap;
	}

	public Integer getFamilyCap() {
		return familyCap;
	}

	public void setFamilyCap(Integer familyCap) {
		this.familyCap = familyCap;
	}

	public java.sql.Date getEnrollByDeadlineDate() {
		return enrollByDeadlineDate;
	}

	public void setEnrollByDeadlineDate(java.sql.Date enrollByDeadlineDate) {
		this.enrollByDeadlineDate = enrollByDeadlineDate;
	}

	public java.sql.Date getCompleteByDeadlineDate() {
		return completeByDeadlineDate;
	}

	public void setCompleteByDeadlineDate(java.sql.Date completeByDeadlineDate) {
		this.completeByDeadlineDate = completeByDeadlineDate;
	}

	public String getIncentiveRuleTypeCode() {
		return incentiveRuleTypeCode;
	}

	public void setIncentiveRuleTypeCode(String incentiveRuleTypeCode) {
		this.incentiveRuleTypeCode = incentiveRuleTypeCode;
	}

	public String getIncentedStatusTypeCodeDesc() {
		return incentedStatusTypeCodeDesc;
	}

	public void setIncentedStatusTypeCodeDesc(String incentedStatusTypeCodeDesc) {
		this.incentedStatusTypeCodeDesc = incentedStatusTypeCodeDesc;
	}

	public final ActivityCollection getActivityCollection() {
		return activityCollection;
	}

	public final void setActivityCollection(ActivityCollection activityCollection) {
		this.activityCollection = activityCollection;
	}

	public java.sql.Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(java.sql.Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public java.sql.Date getEndDate() {
		return endDate;
	}

	public void setEndDate(java.sql.Date endDate) {
		this.endDate = endDate;
	}

		
	
}

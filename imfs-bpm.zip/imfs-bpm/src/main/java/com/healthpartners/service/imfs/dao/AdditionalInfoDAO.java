package com.healthpartners.service.imfs.dao;


import java.util.Collection;

import com.healthpartners.service.imfs.dto.AdditionalInformation;
import org.springframework.dao.DataAccessException;

public interface AdditionalInfoDAO 
{
	public Collection<AdditionalInformation> getAdditionalInfo(Integer programID)
	throws DataAccessException;
	
	public void insertAdditionalInformation(AdditionalInformation pAdditionalInformation, String lUserID)
	throws DataAccessException;
}

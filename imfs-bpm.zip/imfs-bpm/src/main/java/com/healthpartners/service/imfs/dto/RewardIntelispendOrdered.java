
package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.util.StringTokenizer;


import com.healthpartners.service.imfs.common.BPMUtils;

/**
 * Represents line item from the ordered data csv file sent from Intelispend
 * @author tjquist
 *
 */
public class RewardIntelispendOrdered {

	private String quoteID;
	
	private String cartName;
	
	private String orderDate;
	
	private String orderNumber;
	
	private String amount;
	
	private String pidNumber;
	
	private String shipDate;
	
	private String lastName;
	
	private String firstName;
	
	private String cardNumberMasked;
	
	private String proxyCardNumber;
	
	private String addressLine1;
	
	private String addressLine2;
	
	private String city;
	
	private String state;
	
	private String postalCode;
	
	private String groupNumberIndicativeData1;
	
	private String groupNameIndicativeData2;
	
	private String personIDIndicativeData3;
	
	private String rewardFulfillHistIDIndicativeData4;
	
	private String indicativeData5;
	
	private Integer processStatusCode;
	
	private String orderReportFileName;
	

	
	public RewardIntelispendOrdered() {
		super();
	}

	

	public String getQuoteID() {
		return quoteID;
	}


	public void setQuoteID(String quoteID) {
		this.quoteID = quoteID;
	}


	public String getCartName() {
		return cartName;
	}


	public void setCartName(String cartName) {
		this.cartName = cartName;
	}


	public String getOrderDate() {
		return orderDate;
	}


	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}


	public String getOrderNumber() {
		return orderNumber;
	}


	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}


	public String getAmount() {
		return amount;
	}


	public void setAmount(String amount) {
		this.amount = amount;
	}


	public String getPidNumber() {
		return pidNumber;
	}


	public void setPidNumber(String pidNumber) {
		this.pidNumber = pidNumber;
	}


	public String getShipDate() {
		return shipDate;
	}

	public void setShipDate(String shipDate) {
		this.shipDate = shipDate;
	}


	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getCardNumberMasked() {
		return cardNumberMasked;
	}

	public void setCardNumberMasked(String cardNumberMasked) {
		this.cardNumberMasked = cardNumberMasked;
	}

	public String getProxyCardNumber() {
		return proxyCardNumber;
	}

	public void setProxyCardNumber(String proxyCardNumber) {
		this.proxyCardNumber = proxyCardNumber;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPostalCode() {
		return postalCode;
	}


	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}


	public String getGroupNumberIndicativeData1() {
		return groupNumberIndicativeData1;
	}

	public void setGroupNumberIndicativeData1(String groupNumberIndicativeData1) {
		this.groupNumberIndicativeData1 = groupNumberIndicativeData1;
	}


	public String getGroupNameIndicativeData2() {
		return groupNameIndicativeData2;
	}


	public void setGroupNameIndicativeData2(String groupNameIndicativeData2) {
		this.groupNameIndicativeData2 = groupNameIndicativeData2;
	}


	public String getPersonIDIndicativeData3() {
		return personIDIndicativeData3;
	}


	public void setPersonIDIndicativeData3(String personIDIndicativeData3) {
		this.personIDIndicativeData3 = personIDIndicativeData3;
	}


	

	public String getRewardFulfillHistIDIndicativeData4() {
		return rewardFulfillHistIDIndicativeData4;
	}



	public void setRewardFulfillHistIDIndicativeData4(
			String rewardFulfillHistIDIndicativeData4) {
		this.rewardFulfillHistIDIndicativeData4 = rewardFulfillHistIDIndicativeData4;
	}



	public String getIndicativeData5() {
		return indicativeData5;
	}


	public void setIndicativeData5(String indicativeData5) {
		this.indicativeData5 = indicativeData5;
	}


	public Integer getProcessStatusCode() {
		return processStatusCode;
	}


	public void setProcessStatusCode(Integer processStatusCode) {
		this.processStatusCode = processStatusCode;
	}



	public String getOrderReportFileName() {
		return orderReportFileName;
	}



	public void setOrderReportFileName(String orderReportFileName) {
		this.orderReportFileName = orderReportFileName;
	}




}

/**
 * 
 */
package com.healthpartners.service.imfs.iface;

import java.util.Calendar;

import com.healthpartners.service.imfs.dto.BPMRequiredParticipantResponse;
import com.healthpartners.service.imfs.dto.WebServiceRequest;



/**
 * @author jxbourbour
 * 
 */
public interface DemoSiteService 
{

	public BPMRequiredParticipantResponse isRequiredParticipant(WebServiceRequest pWebServiceRequest);
	
}

package com.healthpartners.service.imfs.dao;

import java.util.Collection;

import com.healthpartners.service.imfs.dto.ACTVBatchLog;
import com.healthpartners.service.imfs.dto.CDHPBatchLog;
import com.healthpartners.service.imfs.dto.RewardBatchLog;

public interface BatchLogDAO 
{

	public Collection<CDHPBatchLog> getCDHPBatchLog(java.sql.Date fileSentDate);
	public int insertCDHPBatchLog(CDHPBatchLog pCDHPBatchLog);
	
	public Collection<RewardBatchLog> getRewardBatchLog(java.sql.Date fileSentDate);
	public int insertRewardBatchLog(RewardBatchLog pRewardBatchLog);
	
	public Collection<ACTVBatchLog> getActivityBatchLog(java.sql.Date fileSentDate);
	public int insertActivityBatchLog(ACTVBatchLog pACTVBatchLog);
	
}

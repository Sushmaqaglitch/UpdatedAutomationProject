package com.healthpartners.service.imfs.dto;

import java.util.Calendar;

/**
 * This class represents the internal BPM package Data Transfer Object.
 * It is not exposed to web services for example.
 * 
 * @author jxbourbour
 */
public class ContractTO extends BaseDTO
{
	static final long serialVersionUID = 0L;
	
//	 Database table ID.
	private Integer ID;
	
	Contract contract;
	
	private Calendar contractDateOfPolicyHolder;
	
	private String relationshipToPolicyHolder;
	private Integer relationshipCode;
	
	private String productTypeCode;                           
	private String JWOfferCode;                           
	private String JWReportingUnit;                          
	private String divisionCode;                                
	private String employeeFlag;                               
	private java.sql.Date eligibleHireDate;
	private String healthPlanCode;
	private String benefitContractType;
		
	public ContractTO()
	{
		super();
	}
	
	public Integer getID() {
		return ID;
	}

	public void setID(Integer id) {
		this.ID = id;
	}

	public Contract getContract() {
		return contract;
	}

	public void setContract(Contract contract) {
		this.contract = contract;
	}

	public Calendar getContractDateOfPolicyHolder() {
		return contractDateOfPolicyHolder;
	}

	public void setContractDateOfPolicyHolder(Calendar contractDateOfPolicyHolder) {
		this.contractDateOfPolicyHolder = contractDateOfPolicyHolder;
	}

	public String getRelationshipToPolicyHolder() {
		return relationshipToPolicyHolder;
	}

	public void setRelationshipToPolicyHolder(String relationshipToPolicyHolder) {
		this.relationshipToPolicyHolder = relationshipToPolicyHolder;
	}

	public Integer getRelationshipCode() {
		return relationshipCode;
	}

	public void setRelationshipCode(Integer relationshipCode) {
		this.relationshipCode = relationshipCode;
	}

	public String getProductTypeCode() {
		return productTypeCode;
	}

	public void setProductTypeCode(String productTypeCode) {
		this.productTypeCode = productTypeCode;
	}

	public String getJWOfferCode() {
		return JWOfferCode;
	}

	public void setJWOfferCode(String jWOfferCode) {
		JWOfferCode = jWOfferCode;
	}

	public String getJWReportingUnit() {
		return JWReportingUnit;
	}

	public void setJWReportingUnit(String jWReportingUnit) {
		JWReportingUnit = jWReportingUnit;
	}

	public String getDivisionCode() {
		return divisionCode;
	}

	public void setDivisionCode(String divisionCode) {
		this.divisionCode = divisionCode;
	}

	public String getEmployeeFlag() {
		return employeeFlag;
	}

	public void setEmployeeFlag(String employeeFlag) {
		this.employeeFlag = employeeFlag;
	}

	public java.sql.Date getEligibleHireDate() {
		return eligibleHireDate;
	}

	public void setEligibleHireDate(java.sql.Date eligibleHireDate) {
		this.eligibleHireDate = eligibleHireDate;
	}

	public String getHealthPlanCode() {
		return healthPlanCode;
	}

	public void setHealthPlanCode(String healthPlanCode) {
		this.healthPlanCode = healthPlanCode;
	}

	public String getBenefitContractType() {
		return benefitContractType;
	}

	public void setBenefitContractType(String benefitContractType) {
		this.benefitContractType = benefitContractType;
	}

		
	
}

package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.util.Calendar;

public class RewardBatchLog implements Serializable
{	
	static final long serialVersionUID = 0L;

    public RewardBatchLog()
    {
    	super();
    }

    private Integer logID; 
    //HSA or HRA
    private String batchType;
    private Integer recordCount;
    private java.sql.Date fileSent;

	public Integer getLogID() {
		return logID;
	}
	public void setLogID(Integer logID) {
		this.logID = logID;
	}
	
	
	public String getBatchType() {
		return batchType;
	}
	public void setBatchType(String batchType) {
		this.batchType = batchType;
	}
	public Integer getRecordCount() {
		return recordCount;
	}
	public void setRecordCount(Integer recordCount) {
		this.recordCount = recordCount;
	}
	public java.sql.Date getFileSent() {
		return fileSent;
	}
	public void setFileSent(java.sql.Date fileSent) {
		this.fileSent = fileSent;
	}
    
    
   

	
   
}

package com.healthpartners.service.imfs.dao;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.healthpartners.service.imfs.dto.StoredProcedureResults;

/**
 * Called from service ArchivePersonContractProgramHistoryService.
 * 
 * @author tjquist
 *
 */
@Configuration
public class CallArchivePersonContractPgmHistory extends StoredProcedure 
{

    protected final Log logger = LogFactory.getLog(getClass());

    @Autowired
    DataSource bpmDataSource;


    @PostConstruct
    private void initialize() {

        setDataSource(bpmDataSource);
    }

    private static final String STORED_PROC_NAME = "proc_archive_prsn_pgm_hist";

    public CallArchivePersonContractPgmHistory(DataSource bpmDataSource)
    {
        super(bpmDataSource, STORED_PROC_NAME);
        
        // Input Parameter
        declareParameter(new SqlParameter("iv_date", Types.DATE));
        
        
        compile();
    }

    /**
     * 
     * 
     * @param currentDate
     * @return
     */
    public void execute(java.sql.Date currentDate)    
    {    	    	
        Map<String, Object> lInputParams = new HashMap<String, Object>(0);
              
        // Input        
        lInputParams.put("iv_date", currentDate);
        
        execute(lInputParams);
         
    }

}

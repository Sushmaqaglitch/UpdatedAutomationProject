/**
 * 
 */
package com.healthpartners.service.imfs.impl;

import java.util.ArrayList;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.dao.LookUpValueDAO;
import com.healthpartners.service.imfs.dto.BPMRequiredParticipantResponse;
import com.healthpartners.service.imfs.dto.LookUpValueCode;
import com.healthpartners.service.imfs.dto.RequiredParticipant;
import com.healthpartners.service.imfs.dto.WebServiceRequest;
import com.healthpartners.service.imfs.iface.DemoSiteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/**
 * This class is set up to emulate the BPM Web Services for the Demo web site.
 * 
 * @author jxbourbour
 *
 */
@Component
@Service
public class DemoSiteServiceImpl implements DemoSiteService {
	@Autowired
	LookUpValueDAO lookUpValueDAO;
	
	/**
	 * 
	 */
	public DemoSiteServiceImpl() 
	{
		super();
	}
	
	/**
	 * 
	 * Emulates the isRequiredParticipant Web Service. Looks up pre-set lookup values in the bpm_luv table.
	 * If the member requested in the web service is one of the pre-set ones, it returns true.
	 * Otherwise returns false.
	 * 
	 */
	public BPMRequiredParticipantResponse isRequiredParticipant(WebServiceRequest pWebServiceRequest)
	{
		BPMRequiredParticipantResponse lBPMRequiredParticpantResponse = new BPMRequiredParticipantResponse();
		ArrayList<RequiredParticipant> lRequiredParticipantsResponse = new ArrayList<RequiredParticipant>();
		lBPMRequiredParticpantResponse.setRequiredParticipants(lRequiredParticipantsResponse);
		
		// Get the List of Demo Healthy Benefits Members. 
		ArrayList<LookUpValueCode> lDemoHBMembers = (ArrayList<LookUpValueCode>)
		    lookUpValueDAO.getLUVCodesByGroup(BPMConstants.BPM_HB_DEMO_MEM_ID_LUV);
		
		for(int i = 0; i < lDemoHBMembers.size(); i++)
		{
		    if(lDemoHBMembers.get(i).getLuvVal().equals(pWebServiceRequest.getMemberID()))
		    {
			    RequiredParticipant lRequiredParticipant = new RequiredParticipant();
			    lRequiredParticipant.setParticipant(true);
			    lRequiredParticipant.setHaAvailable(true);
			    lRequiredParticipant.setProgramTypeCode(BPMConstants.PROGRAM_TYPE_CODE_HEALTY_BENEFITS);
			    lRequiredParticipantsResponse.add(lRequiredParticipant);
		    }
		}
		
        // Get the List of Demo Smart Steps Members. 
		ArrayList<LookUpValueCode> lDemoSSMembers = (ArrayList<LookUpValueCode>)
		    lookUpValueDAO.getLUVCodesByGroup(BPMConstants.BPM_SS_DEMO_MEM_ID_LUV);
		
		for(int i = 0; i < lDemoSSMembers.size(); i++)
		{
			if(lDemoSSMembers.get(i).getLuvVal().equals(pWebServiceRequest.getMemberID()))
		    {
			    RequiredParticipant lRequiredParticipant = new RequiredParticipant();
			    lRequiredParticipant.setParticipant(true);
			    lRequiredParticipant.setHaAvailable(true);
			    lRequiredParticipant.setProgramTypeCode(BPMConstants.PROGRAM_TYPE_CODE_SMART_STEPS);
			    lRequiredParticipantsResponse.add(lRequiredParticipant);
		    }
		}
				
		return lBPMRequiredParticpantResponse;
	}

	public LookUpValueDAO getLookUpValueDAO() {
		return lookUpValueDAO;
	}

	public void setLookUpValueDAO(LookUpValueDAO lookUpValueDAO) {
		this.lookUpValueDAO = lookUpValueDAO;
	}		
}

package com.healthpartners.service.imfs.dao;

import java.util.Collection;

import org.springframework.dao.DataAccessException;
import java.sql.Date;

import com.healthpartners.service.imfs.dto.GroupSiteYearStage;

public interface GroupSiteYearStageDAO 
{

	public int getGroupSiteYearCount() throws DataAccessException;;
	public int insertGroupSiteYears(Collection<GroupSiteYearStage> GroupSiteYears) throws DataAccessException;;
	public int deleteGroupSiteYears(Collection<GroupSiteYearStage> GroupSiteYears) throws DataAccessException;;
	public GroupSiteYearStage getGroupSiteYear(int groupNumber, int siteNumber, Date qualStartDate) throws DataAccessException;;
	public Collection<GroupSiteYearStage> getGroupSiteYears() throws DataAccessException;;
}

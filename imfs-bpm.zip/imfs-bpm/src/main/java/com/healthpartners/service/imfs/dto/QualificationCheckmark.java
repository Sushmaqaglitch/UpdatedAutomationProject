package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;

public class QualificationCheckmark implements Serializable
{	
	static final long serialVersionUID = 0L;
		
	private Integer qualificationCheckmarkID;
	private String qualificationCheckmarkName; 
	private String qualificationCheckmarkInfo;
	private String qualificationCheckmarkDesc;
	private Date insertDate;
	private Date modifyDate;
	private String insertUser;
	private String modifyUser;	
	private Date effectiveDate;
	private Date endDate;
	private Integer used;

	private String effectiveDateString;
	private String endDateString;
		
	private Integer participationGroupID;
	private String participationGroupName;
	
	private ArrayList<CheckmarkRequirement> checkmarkRequirements;
	
	private ParticipationGroup participationGroup;
	
	private Integer programIncentiveOptionID;
	private Integer incentedStatusTypeCodeID;
	private String incentedStatusTypeCode;
	
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getEffectiveDateString() {
		return effectiveDateString;
	}
	public void setEffectiveDateString(String effectiveDateString) {
		this.effectiveDateString = effectiveDateString;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getEndDateString() {
		return endDateString;
	}
	public void setEndDateString(String endDateString) {
		this.endDateString = endDateString;
	}
	public Date getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}
	public String getInsertUser() {
		return insertUser;
	}
	public void setInsertUser(String insertUser) {
		this.insertUser = insertUser;
	}
	public Date getModifyDate() {
		return modifyDate;
	}
	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}
	public String getModifyUser() {
		return modifyUser;
	}
	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}
	public String getQualificationCheckmarkDesc() {
		return qualificationCheckmarkDesc;
	}
	public void setQualificationCheckmarkDesc(String qualificationCheckmarkDesc) {
		this.qualificationCheckmarkDesc = qualificationCheckmarkDesc;
	}
	public Integer getQualificationCheckmarkID() {
		return qualificationCheckmarkID;
	}
	public void setQualificationCheckmarkID(Integer qualificationCheckmarkID) {
		this.qualificationCheckmarkID = qualificationCheckmarkID;
	}
	public String getQualificationCheckmarkInfo() {
		return qualificationCheckmarkInfo;
	}
	public void setQualificationCheckmarkInfo(String qualificationCheckmarkInfo) {
		this.qualificationCheckmarkInfo = qualificationCheckmarkInfo;
	}
	public String getQualificationCheckmarkName() {
		return qualificationCheckmarkName;
	}
	public void setQualificationCheckmarkName(String qualificationCheckmarkName) {
		this.qualificationCheckmarkName = qualificationCheckmarkName;
	}
	public Integer getUsed() {
		return used;
	}
	public void setUsed(Integer used) {
		this.used = used;
	}
	public ArrayList<CheckmarkRequirement> getCheckmarkRequirements() {
		return checkmarkRequirements;
	}
	public void setCheckmarkRequirements(
			ArrayList<CheckmarkRequirement> checkmarkRequirements) {
		this.checkmarkRequirements = checkmarkRequirements;
	}
	public final Integer getParticipationGroupID() {
		return participationGroupID;
	}
	public final void setParticipationGroupID(Integer participationGroupID) {
		this.participationGroupID = participationGroupID;
	}
	public final String getParticipationGroupName() {
		return participationGroupName;
	}
	public final void setParticipationGroupName(String participationGroupName) {
		this.participationGroupName = participationGroupName;
	}
	public ParticipationGroup getParticipationGroup() {
		return participationGroup;
	}
	public void setParticipationGroup(ParticipationGroup participationGroup) {
		this.participationGroup = participationGroup;
	}
	public Integer getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}
	public void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}
	public Integer getIncentedStatusTypeCodeID() {
		return incentedStatusTypeCodeID;
	}
	public void setIncentedStatusTypeCodeID(Integer incentedStatusTypeCodeID) {
		this.incentedStatusTypeCodeID = incentedStatusTypeCodeID;
	}
	public String getIncentedStatusTypeCode() {
		return incentedStatusTypeCode;
	}
	public void setIncentedStatusTypeCode(String incentedStatusTypeCode) {
		this.incentedStatusTypeCode = incentedStatusTypeCode;
	}

	
	
}

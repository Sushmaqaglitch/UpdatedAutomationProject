/* $Id: LookUpValueServiceImpl.java 296322 2015-02-06 19:21:39Z tjquist $ */

package com.healthpartners.service.imfs.impl;

import java.util.Collection;

import com.healthpartners.service.imfs.dao.EnvCodeDAO;
import com.healthpartners.service.imfs.dto.EnvCode;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.iface.EnvCodeService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.dao.EnvCodeDAO;
import com.healthpartners.service.imfs.dto.EnvCode;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.iface.EnvCodeService;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/**
 * 
 * @author tjquist
 */
@Component
@Service
public class EnvCodeServiceImpl implements EnvCodeService
{


	protected final Log logger = LogFactory.getLog(getClass());

	@Autowired
	private EnvCodeDAO envCodeDAO;

	public EnvCodeServiceImpl() {
	}

	
	/**
	 * @see EnvCodeService#getENVCodesByDesc(String)
	 */
	public Collection<EnvCode> getENVCodesByDesc(String envDesc)
			throws BPMException, DataAccessException
	{
		Collection<EnvCode> envCodes = null;
		try {
			envCodes = envCodeDAO.getENVCodesByDesc(envDesc);
			
		} catch (Exception e) {			
			throw new BPMException(e.getMessage(), e);
		}

		return envCodes;
	}
	
	/**
	 * @see EnvCodeService#getENVCodeByID(Integer)
	 */
	public EnvCode getENVCodeByID(Integer envValCodeID)
			throws BPMException, DataAccessException 
	{
		EnvCode lEnvCode = null;
		try {
			lEnvCode = envCodeDAO.getENVCodeByID(envValCodeID);
			
		} catch (Exception e) {			
			throw new BPMException(e.getMessage(), e);
		}

		return lEnvCode;
	}
	
	/**
	 * @see EnvCodeService#getENVCodeByCode(Integer)
	 */
	public EnvCode getENVCodeByCode(String code)
			throws BPMException, DataAccessException 
	{
		EnvCode lEnvCode = null;
		try {
			lEnvCode = envCodeDAO.getENVCodeByCode(code);
			
		} catch (Exception e) {			
			throw new BPMException(e.getMessage(), e);
		}

		return lEnvCode;
	}



	public void setEnvCodeDAO(EnvCodeDAO envCodeDAO) {
		this.envCodeDAO = envCodeDAO;
	}
	
	
	
	
}

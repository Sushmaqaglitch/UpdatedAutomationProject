package com.healthpartners.service.imfs.dto;

import java.util.Calendar;

/**
 * This class stores quote id and description for communicating to vendor
 * the type of card need to be produced.
 * 
 * @author tjquist
 */
public class RewardCardQuote extends BaseDTO
{
	String quoteID;
	String quoteDescription;
	
	public RewardCardQuote()
	{
		super();
	}

	
	public String getQuoteID() {
		return quoteID;
	}


	public void setQuoteID(String quoteID) {
		this.quoteID = quoteID;
	}


	public String getQuoteDescription() {
		return quoteDescription;
	}

	public void setQuoteDescription(String quoteDescription) {
		this.quoteDescription = quoteDescription;
	}
	
	
		
	
}

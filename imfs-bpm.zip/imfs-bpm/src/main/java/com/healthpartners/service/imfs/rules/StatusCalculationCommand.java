/* $Id$ */

package com.healthpartners.service.imfs.rules;

import java.util.HashMap;
import java.util.Map;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.dto.ActivityEvent;
import com.healthpartners.service.imfs.dto.BaseDTO;
import com.healthpartners.service.imfs.dto.TaskEvent;
import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.dto.ActivityEvent;
import com.healthpartners.service.imfs.dto.BaseDTO;
import com.healthpartners.service.imfs.dto.TaskEvent;

/**
 * Class represents a command object to send throgh JMS message for status
 * calculation job.
 * 
 * Refer com.healthpartners.service.bpm.impl.ProgramStatusCalculationServiceImpl
 * class and its mehod updateProgramStatus(StatusCalculationCommand
 * statusCalculationCommand) for furher details.
 * 
 * This class stores type of command to perform in the Map<String, Object>
 * parametersMap.
 * 
 * @author mxthoutam
 * 
 */
public class StatusCalculationCommand extends BaseDTO {

	static final long serialVersionUID = 0L;

	public static final String ACTIVITY_EVENT = "ACTIVITY_EVENT";

	public static final String TASK_EVENT = "TASK_EVENT";
														  
	public static final String PENDING_ACTIVITY_EVENTS = "PENDING_ACTIVITY_EVENTS";
	
	public static final String FILTERED_ACTIVITY_EVENTS = "FILTERED_ACTIVITY_EVENTS";

	public static final String PENDING_TASK_EVENTS = "PENDING_TASK_EVENTS";

	public static final String ETL_MEMBERSHIP_UPDATE = "ETL_MEMBERSHIP_UPDATE";
	public static final String TOPIC_ETL_MEMBERSHIP_UPDATE = "TOPIC_ETL_MEMBERSHIP_UPDATE";
	public static final String ETL_MEMBERSHIP_UPDATE_ONLY = "ETL_MEMBERSHIP_ONLY";

	public static final String MEMBER_ELAPSED_TIME = "MEMBER_ELAPSED_TIME";
	
	public static final String PURGE_AUDIT_LOG_TABLE = "PURGE_AUDITLOG_TABLE";
	
	public static final String PURGE_PROCESSLG_TABLE = "PURGE_PROCSTATLOG_TABLE";

	public static final String PURGE_GROUPBASELINEHIST_TABLE = "PURGE_GROUPBASELINEHIST_TABLE";

	
	public static final String ARCHIVE_PERSONCONTRACTHIST_TABLE = "ARCHIVE_PERSONCONTRACTHIST_TABLE";
	
	public static final String MEMBERCONTRACTRECYCLE_ACTIONNEEDED_RPT = "MEMBERCONTRACTRECYCLE_ACTIONNEEDED_RPT";


	public static final String PARAM_BATCH_SIZE = "PARAM_BATCH_SIZE";

	public static final String ONE_PERSON = "ONE_PERSON";

	public static final String MEMBERS_RECALCULATION = "MEMBERS_RECALCULATION";

	public static final String MEMBERSHIP_FEED = "MEMBERSHIP_FEED";
	
	public static final String MEMBERSHIP_PREMIUM_BILLING_FEED = "MEMBERSHIP_PREMIUM_BILLING_FEED";
	
	public static final String AUTO_PROGRAM_SETUP = "AUTO_PROGRAM_SETUP";
	public static final String AUTO_PROGRAM_NEW_SETUP = "AUTO_PROGRAM_NEW_SMARTSTEPS";
	
	public static final String EMPLOYER_GROUP_SITE_SETUP = "EMPLOYER_GROUP_SITE_SETUP";
	public static final String EMPLOYER_BASELINE_SETUP = "EMPLOYER_BASELINE_SETUP";
	public static final String POPULATE_MISSING_PEOPLE = "POPULATE_MISSING_PEOPLE";
	public static final String POPULATE_MISSING_ACTIVITIES = "POPULATE_MISSING_ACTIVITIES";
	public static final String RECALC_DUALCOVERED_PARTICIPANTS = "RECALC_DUALCOVERED_PARTICIPANTS";
	public static final String DELETE_TERMED_PARTICIPANTS = "DELETE_TERMED_PARTICIPANTS";
	public static final String DELETE_TERMED_PARTICIPANTS_BY_GRP = "DELETE_TERMED_BY_GRP";
	
	
	public static final String CONTRACT_RECONCILIATION = "CONTRACT_RECONCILIATION";
	
	
	public static final String EMPLOYER_FULFILLMENT_REPORTING = "EMPLOYER_FULFILLMENT";
	public static final String EMPLOYER_FULFILLMENT_REPORTING_RESEND = "EMPLOYER_FULFILLMENT_RESEND";
	
	public static final String CDHP_HRA_FULFILLMENT_REPORTING = "CDHP_HRA_FULFILLMENT";
	public static final String CDHP_HSA_FULFILLMENT_REPORTING = "CDHP_HSA_FULFILLMENT";
	
	public static final String REWARD_FULFILLMENT_SEND = "REWARD_FULFILLMENT";
																	  
	public static final String UPLOAD_EMPLOYER_ACTIVITY_PREPROCESS = "UPLOAD_EMPLOYER_ACTIVITY_PREPROCESS";
	public static final String UPLOAD_EMPLOYER_ACTIVITY_POSTPROCESS = "UPLOAD_EMPLOYER_ACTIVITY_POSTPROCESS";
	public static final String OPTUM_INCENTED_TO_FULFILL_RECON = "OPTUM_INCENTED_TO_FULFILL_RECON";
																
	
	public static final String REWARD_INTELISPEND_REPORTING = "INTELISPEND_REPORTS";
	
	public static final String POPULATE_PACKAGE_BASELINE = "POPULATE_PACKAGE_BASELINE";
	public static final String FILTERED_OUT_ACTIVITY_REPORT = "FILTERED_OUT_ACTIVITY_REPORT";
	
	public static final String AUTO_POPULATE_AUDIT_REPORT = "AUTO_POPULATE_AUDIT_REPORT";
	
	public static final String RESET_ACTIVITY_EVENT_TO_PENDING = "RESET_ACTIVITY_EVENT_TO_PENDING";
	
	public static final String REPROCESS_INCENTED_ACTIVITY_W_UNRESOLVED = "REPROCESS_INCENTED_ACTIVITY_W_UNRESOLVED";
	
	public static final String ACTIVITY_TO_CONTRIBGRID_RECON = "ACTIVITY_TO_CONTRIBGRID_RECON";	
	
	public static final String EMPLOYER_ACTIVITY_END_TO_END_RECON = "EMPLOYER_ACTIVITY_END_TO_END_RECON";
	
	public static final String CORRECT_PURCHASER_SUBTYPE = "CORRECT_PURCHASER_SUBTYPE";
	
	public static final String ACTIVITY_CREATION_BASED_ON_PRECONDITION = "ACTIVITY_CREATION_BASED_ON_PRECONDITION";
	

	// public static final String ALL_BUSINESS_PROGRAMS =
	// "ALL_BUSINESS_PROGRAMS";

	// public static final String ONE_BUSINESS_PROGRAM = "ONE_BUSINESS_PROGRAM";

	// map to store type of command
	private Map<String, Object> parametersMap = new HashMap<String, Object>();

	private String userID;

	private String processName;

	// type of process - ex memberhip update etl job - 1, re-calculation-2,
	// admin membership update-10, admin re calc-11
	private Map<String, Integer> processIDsMap = new HashMap<String, Integer>();
	
	//used at the time of processing
	private String currentProcessingCommand;
	
	private String currentCommandText;
	
	private int daySpanToCtrlFilteredOutActivity;
	
	private String snapShotEmplFulfillTrackDate;
	
	private String snapShotActivityActivityFulfillTrackDate;
	
	private String startEmplFulfillTrackDate;
	
	private String startDate;
	
	private String snapShotCDHPHRAFulfillTrackDate;
	
	private String groupNo;
	
	private String siteNo;
	
	private String memberNo;
	
	private String employerFulfillActivityCatReport;
	
	private String hostName;
	
	private String sourceSystemID;
	
	private String startAtTwoDaysNolderFlag;
	
	

	

	public StatusCalculationCommand() { 
		super();
	}

	// / getParametersMap(), setParametersMap() are used in spring configuration
	// for Batch processing
	public Map<String, Object> getParametersMap() {
		return parametersMap;
	}

	public void setParametersMap(Map<String, Object> parametersMap) {
		this.parametersMap = parametersMap;
	}

	public Map<String, Integer> getProcessIDsMap() {
		return processIDsMap;
	}

	public void setProcessIDsMap(Map<String, Integer> processIDsMap) {
		this.processIDsMap = processIDsMap;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}
	

	// ////Use public utility methods to set or get in all programs///////////
	private Object getParameter(String paramName) {
		return parametersMap.get(paramName);
	}

	private void setParameter(String paramName, Object value) {
		parametersMap.put(paramName, value);
	}

	private void setProcessID(String paramName, Integer processID) {
		processIDsMap.put(paramName, processID);
	}

	private Integer getProcessID(String paramName) {
		//default to zero
		Integer lProcessID = new Integer(0);
		if (processIDsMap.get(paramName) != null) {
			lProcessID = processIDsMap.get(paramName);
		}
		return lProcessID;
	}
	
	// /////////ALL Utility Methods///////////
	// 1. activity event
	public boolean isActivityEventCommand() {
		boolean result = parametersMap.containsKey(ACTIVITY_EVENT);
		return result;
	}

	public ActivityEvent getActivityEvent() {
		ActivityEvent activityEvent = null;
		if (isActivityEventCommand()) {
			activityEvent = (ActivityEvent) getParameter(StatusCalculationCommand.ACTIVITY_EVENT);
		}
		return activityEvent;
	}

	public void setActivityEventCommand(ActivityEvent activityEvent) {
		setParameter(ACTIVITY_EVENT, activityEvent);
	}


	public void setActivityEventCommand() {
		setParameter(ACTIVITY_EVENT,
				ACTIVITY_EVENT);
	}
	// 2. task event
	public boolean isTaskEventCommand() {
		boolean result = parametersMap.containsKey(TASK_EVENT);
		return result;
	}

	public TaskEvent getTaskEvent() {
		TaskEvent taskEvent = null;
		if (isTaskEventCommand()) {
			taskEvent = (TaskEvent) getParameter(StatusCalculationCommand.TASK_EVENT);
		}
		return taskEvent;
	}

	public void setTaskEventCommand(TaskEvent taskEvent) {
		setParameter(TASK_EVENT, taskEvent);
	}

	// 3 pending activity events
	public boolean isPendingActivityEventsCommand() {
		boolean result = parametersMap.containsKey(PENDING_ACTIVITY_EVENTS);
		return result;
	}

	public void setPendingActivityEventsCommand() {
		setParameter(PENDING_ACTIVITY_EVENTS, PENDING_ACTIVITY_EVENTS);
	}
	
	// 4 filtered activity events
	public boolean isFilteredActivityEventsCommand() {
		boolean result = parametersMap.containsKey(FILTERED_ACTIVITY_EVENTS);
		return result;
	}

	public void setFilteredActivityEventsCommand() {
		setParameter(FILTERED_ACTIVITY_EVENTS, FILTERED_ACTIVITY_EVENTS);
	}
	
	// 5 pending task events
	public boolean isPendingTaskEventsCommand() {
		boolean result = parametersMap.containsKey(PENDING_TASK_EVENTS);
		return result;
	}

	public void setPendingTaskEventsCommand() {
		setParameter(PENDING_TASK_EVENTS, PENDING_TASK_EVENTS);
	}

	// etl membership update
	public boolean isEtlMembershipUpdateCommand() {
		boolean result = parametersMap.containsKey(ETL_MEMBERSHIP_UPDATE);
		return result;
	}

	// topic etl membership update
	public boolean isTopicEtlMembershipUpdateCommand() {
		boolean result = parametersMap.containsKey(TOPIC_ETL_MEMBERSHIP_UPDATE);
		return result;
	}
	
	// membership update only 
	public boolean isEtlMembershipUpdateOnlyCommand() {
		boolean result = parametersMap.containsKey(ETL_MEMBERSHIP_UPDATE_ONLY);
		return result;
	}

	public boolean isCurrentProcessingEtlMembershipUpdateCommand() {
		boolean result = false;
		if(ETL_MEMBERSHIP_UPDATE.equalsIgnoreCase(currentProcessingCommand)){
			result = true;
		}
		return result;
	}
	
	public void setEtlMembershipUpdateCommand() {
		setParameter(ETL_MEMBERSHIP_UPDATE, ETL_MEMBERSHIP_UPDATE);
	}

	public void setTopicEtlMembershipUpdateCommand() {
		setParameter(TOPIC_ETL_MEMBERSHIP_UPDATE, TOPIC_ETL_MEMBERSHIP_UPDATE);
	}

	public void setProcessIDForEtlMembershipUpdateCommand(Integer pProcessID) {
		setProcessID(ETL_MEMBERSHIP_UPDATE, pProcessID);
	}
	
	// membership update only	
	public void setEtlMembershipUpdateOnlyCommand() {
		setParameter(ETL_MEMBERSHIP_UPDATE_ONLY, ETL_MEMBERSHIP_UPDATE_ONLY);
	}

	public void setProcessIDForEtlMembershipUpdateOnlyCommand(Integer pProcessID) {
		setProcessID(ETL_MEMBERSHIP_UPDATE_ONLY, pProcessID);
	}
	

	// 7. elapsed time
	public boolean isMemberElapsedTimeCommand() {
		boolean result = parametersMap.containsKey(MEMBER_ELAPSED_TIME);
		return result;
	}

	public void setMemberElapsedTimeCommand() {
		setParameter(MEMBER_ELAPSED_TIME,
				BPMConstants.MEMBER_ELAPSED_TIME_FILE_XML);
	}

	public void setProcessIDForMemberElapsedTimeCommand(Integer pProcessID) {
		setProcessID(MEMBER_ELAPSED_TIME, pProcessID);
	}

	
	// 8. one member
	public boolean isOnePersonCommand() {
		boolean result = parametersMap.containsKey(ONE_PERSON);
		return result;
	}

	public Integer getOnePersonID() {
		Integer personID = null;
		if (isOnePersonCommand()) {
			personID = (Integer) getParameter(StatusCalculationCommand.ONE_PERSON);
		}
		return personID;
	}

	public void setOnePersonCommand(Integer onePersonID) {
		setParameter(ONE_PERSON, onePersonID);
	}

	
	// 9. batch size
	public boolean isBatchSizeCommandSet() {
		boolean result = parametersMap.containsKey(PARAM_BATCH_SIZE);
		return result;
	}

	public Integer getBatchSize() {
		Integer batchSize = null;
		if (isBatchSizeCommandSet()) {
			batchSize = (Integer) getParameter(StatusCalculationCommand.PARAM_BATCH_SIZE);
		}
		return batchSize;
	}

	public void setBatchSizeCommand(Integer batchSize) {
		setParameter(PARAM_BATCH_SIZE, batchSize);
	}

	// 10 members recalculation commad \
	public boolean isMembersReCalculationCommand() {
		boolean result = parametersMap.containsKey(MEMBERS_RECALCULATION);
		return result;
	}

	public void setMembersReCalculationCommand() {
		setParameter(MEMBERS_RECALCULATION, MEMBERS_RECALCULATION);
	}

	public void setProcessIDForMembersReCalculationCommand(Integer pProcessID) {
		setProcessID(MEMBERS_RECALCULATION, pProcessID);
	}
	

	// 11 membership feed
	public boolean isMbrShipFeedCommand() {
		boolean result = parametersMap.containsKey(MEMBERSHIP_FEED);
		return result;
	}

	public void setMbrShipFeedCommand() {
		setParameter(MEMBERSHIP_FEED, MEMBERSHIP_FEED);
	}
	
	
	public boolean isMbrShipPremiumBillingFeedCommand() {
		boolean result = parametersMap.containsKey(MEMBERSHIP_PREMIUM_BILLING_FEED);
		return result;
	}

	public void setMbrShipPremiumBillingFeedCommand() {
		setParameter(MEMBERSHIP_PREMIUM_BILLING_FEED, MEMBERSHIP_PREMIUM_BILLING_FEED);
	}
	
	public boolean isAutoProgramSetup()
	{
		boolean result = parametersMap.containsKey(AUTO_PROGRAM_SETUP);
		return result;
	}
	
	public boolean isAutoProgramSetupNewSmartSteps()
	{
		boolean result = parametersMap.containsKey(AUTO_PROGRAM_NEW_SETUP);
		return result;		
	}
	
	
	public boolean isEmployerGroupSiteSetup()
	{
		boolean result = parametersMap.containsKey(EMPLOYER_GROUP_SITE_SETUP);
		return result;		
	}
	
	public boolean isCallPopulatePackageBaseline()
	{
		boolean result = parametersMap.containsKey(POPULATE_PACKAGE_BASELINE);
		return result;		
	}
	
	public boolean isFilteredOutActivityReport()
	{
		boolean result = parametersMap.containsKey(FILTERED_OUT_ACTIVITY_REPORT);
		return result;
	}
	
	public boolean isAutoPopulateAuditReport()
	{
		boolean result = parametersMap.containsKey(AUTO_POPULATE_AUDIT_REPORT);
		return result;
	}
	
	public boolean isCorrectPurchaserSubType()
	{
		boolean result = parametersMap.containsKey(CORRECT_PURCHASER_SUBTYPE);
		return result;
	}
	
	public boolean isActivityToContribGridReconReport()
	{
		boolean result = parametersMap.containsKey(ACTIVITY_TO_CONTRIBGRID_RECON);
		return result;
	}
	
	
	public boolean isEmployerGroupBaselineSetup()
	{
		boolean result = parametersMap.containsKey(EMPLOYER_BASELINE_SETUP);
		return result;		
	}
	
	public boolean isPopulateMissingPeople()
	{
		boolean result = parametersMap.containsKey(POPULATE_MISSING_PEOPLE);
		return result;
	}

	public boolean isPopulateMissingPersonProgramActivities()
	{
		boolean result = parametersMap.containsKey(POPULATE_MISSING_ACTIVITIES);
		return result;
	}

	public boolean isRecalcDualCoveredPersons()
	{
		boolean result = parametersMap.containsKey(RECALC_DUALCOVERED_PARTICIPANTS);
		return result;
	}

	public void setRecalcDualCoveredPersons() {
		setParameter(RECALC_DUALCOVERED_PARTICIPANTS, RECALC_DUALCOVERED_PARTICIPANTS);
	}


	public void setDeleteTermedParticipantsCommand() {
		setParameter(DELETE_TERMED_PARTICIPANTS, DELETE_TERMED_PARTICIPANTS);
	}
	
	public boolean isDeleteTermedParticipants()
	{
		boolean result = parametersMap.containsKey(DELETE_TERMED_PARTICIPANTS);
		return result;
	}
	
	public void setDeleteTermedByGroupCommand() {
		setParameter(DELETE_TERMED_PARTICIPANTS_BY_GRP, DELETE_TERMED_PARTICIPANTS_BY_GRP);
	}
	
	public boolean isDeleteTermedByGroup()
	{
		boolean result = parametersMap.containsKey(DELETE_TERMED_PARTICIPANTS_BY_GRP);
		return result;
	}
	
	public void setAutoGroupSetup()
	{
		setParameter(AUTO_PROGRAM_SETUP, AUTO_PROGRAM_SETUP);
	}
	
	public void setEmployerGroupSiteSetup()
	{
		setParameter(EMPLOYER_GROUP_SITE_SETUP, EMPLOYER_GROUP_SITE_SETUP);
	}
	
	public void setEmployerBaselineSetup()
	{
		setParameter(EMPLOYER_BASELINE_SETUP, EMPLOYER_BASELINE_SETUP);
	}
	
	public void setPopulatePackageBaseline()
	{
		setParameter(POPULATE_PACKAGE_BASELINE, POPULATE_PACKAGE_BASELINE);
	}
	
	public void setFilteredOutActivityReport()
	{
		setParameter(FILTERED_OUT_ACTIVITY_REPORT, FILTERED_OUT_ACTIVITY_REPORT);
	}
	
	public void setAutoPopulateAuditReport()
	{
		setParameter(AUTO_POPULATE_AUDIT_REPORT, AUTO_POPULATE_AUDIT_REPORT);
	}
	
	public void setActivityToContribGridReconReport()
	{
		setParameter(ACTIVITY_TO_CONTRIBGRID_RECON, ACTIVITY_TO_CONTRIBGRID_RECON);
	}
	
	public void setCorrectPurchaserSubtype()
	{
		setParameter(CORRECT_PURCHASER_SUBTYPE, CORRECT_PURCHASER_SUBTYPE);
	}
	
	
	
	public void setAutoProgramNewSmartStepsSetup()
	{
		setParameter(AUTO_PROGRAM_NEW_SETUP, AUTO_PROGRAM_NEW_SETUP);
	}
	
	public void setPopulateMissingPeopleSetup()
	{
		setParameter(POPULATE_MISSING_PEOPLE, POPULATE_MISSING_PEOPLE);
	}

	public void setPopulateMissingActivities()
	{
		setParameter(POPULATE_MISSING_ACTIVITIES, POPULATE_MISSING_ACTIVITIES);
	}

	// 12 purge audit log table by date commad 
	
	public boolean isPurgeAuditLogTableCommand()
	{
		
		boolean result = parametersMap.containsKey(PURGE_AUDIT_LOG_TABLE);
		return result;
	}
	
	public void setPurgeAuditLogTableCommand() {
		setParameter(PURGE_AUDIT_LOG_TABLE,
				PURGE_AUDIT_LOG_TABLE);
	}
	
// 12 purge audit log table by date commad 
	
	public boolean isPurgeProcessStatLogTableCommand()
	{		
		
		boolean result = parametersMap.containsKey(PURGE_PROCESSLG_TABLE);

		return result;
	}
	
	public void setPurgeProcessStatLogTableCommand() {
		setParameter(PURGE_PROCESSLG_TABLE,
				PURGE_PROCESSLG_TABLE);
	}

	// 12 purge audit log table by date commad

	public boolean isPurgeGroupBaselineHistTableCommand()
	{

		boolean result = parametersMap.containsKey(PURGE_GROUPBASELINEHIST_TABLE);

		return result;
	}

	public void setPurgeGroupBaselineHistTableCommand() {
		setParameter(PURGE_GROUPBASELINEHIST_TABLE,
				PURGE_GROUPBASELINEHIST_TABLE);
	}
	
// 13 person contract history reconciliation command 
	
	public boolean isPersonContractHistReconciliationCommand()
	{		
		
		boolean result = parametersMap.containsKey(CONTRACT_RECONCILIATION);

		return result;
	}
	
	public void setPersonContractHistReconciliationCommandCommand() {
		setParameter(CONTRACT_RECONCILIATION,
				CONTRACT_RECONCILIATION);
	}
	
// 14 employer reporting fulfillment command 
	
	public boolean isEmployerReportingFulfillmentCommand()
	{		
		
		boolean result = parametersMap.containsKey(EMPLOYER_FULFILLMENT_REPORTING);

		return result;
	}
	
	public void setEmployerReportingFulfillmentCommand() {
		setParameter(EMPLOYER_FULFILLMENT_REPORTING,
				EMPLOYER_FULFILLMENT_REPORTING);
	}
	
// 15 resend employer reporting fulfillment command 
	
	public boolean isResendEmployerReportingFulfillmentCommand()
	{		
		
		boolean result = parametersMap.containsKey(EMPLOYER_FULFILLMENT_REPORTING_RESEND);

		return result;
	}
	
	
// 16 process HRA Contributions command 
	
	public void setProcessCDHPHRAFulfillmentCommand() {
		setParameter(CDHP_HRA_FULFILLMENT_REPORTING,
				CDHP_HRA_FULFILLMENT_REPORTING);
	}
	
	public boolean isProcessCDHPHRAFulfillment()
	{		
		
		boolean result = parametersMap.containsKey(CDHP_HRA_FULFILLMENT_REPORTING);

		return result;
	}
	
// 17 process HRA Contributions command 
	
	public void setProcessCDHPHSAFulfillmentCommand() {
		setParameter(CDHP_HSA_FULFILLMENT_REPORTING,
				CDHP_HSA_FULFILLMENT_REPORTING);
	}
	
	public boolean isProcessCDHPHSAFulfillment()
	{		
		
		boolean result = parametersMap.containsKey(CDHP_HSA_FULFILLMENT_REPORTING);

		return result;
	}
	

	
	
	public void setProcessRewardFilesFromIntelispendFulfillmentCommand() {
		setParameter(REWARD_INTELISPEND_REPORTING,
				REWARD_INTELISPEND_REPORTING);
	}
	
	public boolean isProcessRewardFilesFromIntelispendFulfillment()
	{		
		
		boolean result = parametersMap.containsKey(REWARD_INTELISPEND_REPORTING);

		return result;
	}
	
	
	public void setProcessRewardFulfillmentCommand() {
		setParameter(REWARD_FULFILLMENT_SEND,
				REWARD_FULFILLMENT_SEND);
	}
	
	public boolean isProcessRewardFulfillment()
	{		
		
		boolean result = parametersMap.containsKey(REWARD_FULFILLMENT_SEND);

		return result;
	}
	
	public void setProcessBatchEmployerActivitiesPreprocessCommand() {
		setParameter(UPLOAD_EMPLOYER_ACTIVITY_PREPROCESS,
				UPLOAD_EMPLOYER_ACTIVITY_PREPROCESS);
	}
	
	public boolean isProcessBatchEmployerActivitiesPreprocessCommand()
	{		
		
		boolean result = parametersMap.containsKey(UPLOAD_EMPLOYER_ACTIVITY_PREPROCESS);

		return result;
	}
	
	public void setProcessBatchEmployerActivitiesPostprocessCommand() {
		setParameter(UPLOAD_EMPLOYER_ACTIVITY_POSTPROCESS,
				UPLOAD_EMPLOYER_ACTIVITY_POSTPROCESS);
	}
	
	public boolean isProcessBatchEmployerActivitiesPostprocessCommand()
	{		
		
		boolean result = parametersMap.containsKey(UPLOAD_EMPLOYER_ACTIVITY_POSTPROCESS);

		return result;
	}
	
	public void setProcessBatchOptumMemberActivitiesIncentedToFulfillReconCommand() {
		setParameter(OPTUM_INCENTED_TO_FULFILL_RECON,
				OPTUM_INCENTED_TO_FULFILL_RECON);
	}
	
	public boolean isProcessBatchOptumMemberActivitiesIncentedToFulfillReconCommand()
	{		
		boolean result = parametersMap.containsKey(OPTUM_INCENTED_TO_FULFILL_RECON);
		return result;
	}
	
	public boolean isProcessResetActivityEventsFromInprocessToPendingCommand()
	{		
		
		boolean result = parametersMap.containsKey(RESET_ACTIVITY_EVENT_TO_PENDING);

		return result;
	}
	
	public void setProcessResetActivityEventsFromInprocessToPendingCommand() {
		setParameter(RESET_ACTIVITY_EVENT_TO_PENDING,
				RESET_ACTIVITY_EVENT_TO_PENDING);
	}
	
	public boolean isProcessUnresolvedContractBenefitTypeForActivityIncentiveCommand()
	{		
		
		boolean result = parametersMap.containsKey(REPROCESS_INCENTED_ACTIVITY_W_UNRESOLVED);

		return result;
	}
	
	
	public void setProcessUnresolvedContractBenefitTypeForActivityIncentiveCommand() {
		setParameter(REPROCESS_INCENTED_ACTIVITY_W_UNRESOLVED,
				REPROCESS_INCENTED_ACTIVITY_W_UNRESOLVED);
	}
	
	public boolean isProcessPersonContractActivityToContribGridReconCommand()
	{		
		
		boolean result = parametersMap.containsKey(ACTIVITY_TO_CONTRIBGRID_RECON);

		return result;
	}
	
	public void setProcessPersonContractActivityToContribGridReconCommand() {
		setParameter(ACTIVITY_TO_CONTRIBGRID_RECON,
				ACTIVITY_TO_CONTRIBGRID_RECON);
	}
	
	public boolean isEmployerActivityEndToEndReconCommand()
	{		
		
		boolean result = parametersMap.containsKey(EMPLOYER_ACTIVITY_END_TO_END_RECON);

		return result;
	}

	public void setArchivePersonContractProgramHistoryCommand() {
		setParameter(ARCHIVE_PERSONCONTRACTHIST_TABLE,
				ARCHIVE_PERSONCONTRACTHIST_TABLE);
	}
	
	public boolean isArchivePersonContractProgramHistoryCommand()
	{		
		
		boolean result = parametersMap.containsKey(ARCHIVE_PERSONCONTRACTHIST_TABLE);

		return result;
	}
	
	public void setPersonContractRecycleActionNeededReportCommand() {
		setParameter(MEMBERCONTRACTRECYCLE_ACTIONNEEDED_RPT,
				MEMBERCONTRACTRECYCLE_ACTIONNEEDED_RPT);
	}
	
	public boolean isPersonContractRecycleActionNeededReportCommand()
	{		
		
		boolean result = parametersMap.containsKey(MEMBERCONTRACTRECYCLE_ACTIONNEEDED_RPT);

		return result;
	}
	
	public void setActivityEventCreationBasedOnPreconditionCommand() {
		setParameter(ACTIVITY_CREATION_BASED_ON_PRECONDITION,
				ACTIVITY_CREATION_BASED_ON_PRECONDITION);
	}
	
	public boolean isActivityEventCreationBasedOnPreconditionCommand()
	{		
		
		boolean result = parametersMap.containsKey(ACTIVITY_CREATION_BASED_ON_PRECONDITION);

		return result;
	}
	
	
	
	public void setEmployerActivityEndToEndReconCommand() {
		setParameter(EMPLOYER_ACTIVITY_END_TO_END_RECON,
				EMPLOYER_ACTIVITY_END_TO_END_RECON);
	}
	
	
	public void setResendEmployerReportingFulfillmentCommand() {
		setParameter(EMPLOYER_FULFILLMENT_REPORTING_RESEND,
				EMPLOYER_FULFILLMENT_REPORTING_RESEND);
	}
	
	public String getSnapShotEmplFulfillTrackDate() {
		return snapShotEmplFulfillTrackDate;
	}
	
	public void setSnapShotEmplFulfillTrackDate(String snapshotEmplFulfillTrackDate) {
		this.snapShotEmplFulfillTrackDate = snapshotEmplFulfillTrackDate;
	}
	
	
	
	
	public String getSnapShotActivityActivityFulfillTrackDate() {
		return snapShotActivityActivityFulfillTrackDate;
	}

	public void setSnapShotActivityActivityFulfillTrackDate(
			String snapShotActivityActivityFulfillTrackDate) {
		this.snapShotActivityActivityFulfillTrackDate = snapShotActivityActivityFulfillTrackDate;
	}

	public String getStartEmplFulfillTrackDate() {
		return startEmplFulfillTrackDate;
	}

	public void setStartEmplFulfillTrackDate(String startEmplFulfillTrackDate) {
		this.startEmplFulfillTrackDate = startEmplFulfillTrackDate;
	}
	
	

	public String getSnapShotCDHPHRAFulfillTrackDate() {
		return snapShotCDHPHRAFulfillTrackDate;
	}

	public void setSnapShotCDHPHRAFulfillTrackDate(
			String snapShotCDHPHRAFulfillTrackDate) {
		this.snapShotCDHPHRAFulfillTrackDate = snapShotCDHPHRAFulfillTrackDate;
	}

	public String getGroupNo() {
		return groupNo;
	}

	
	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}
	
	
	
	public String getSiteNo() {
		return siteNo;
	}

	public void setSiteNo(String siteNo) {
		this.siteNo = siteNo;
	}

	public String getMemberNo() {
		return memberNo;
	}

	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}

	/**
	 * is it not batch commad?
	 * 
	 * @return boolean
	 */
	public boolean isNotABatchCommand() {
		// add any more types
		return (isActivityEventCommand() || isTaskEventCommand() || isOnePersonCommand());
	}

	/**
	 * is it batch commad?
	 * 
	 * @return boolean
	 */
	public boolean isBatchCommand() {
		// || isAllMembersCommand()
		// || isOneBusinessProgramCommand() || isAllBusinessProgramsCommand());
		return (isEtlMembershipUpdateCommand() 
				|| isEtlMembershipUpdateOnlyCommand()
				|| isMemberElapsedTimeCommand()
				|| isPendingActivityEventsCommand()
				|| isPendingTaskEventsCommand()
				|| isMembersReCalculationCommand() 
				|| isMbrShipFeedCommand()
				|| isMbrShipPremiumBillingFeedCommand()
				|| isEmployerReportingFulfillmentCommand()
				|| isResendEmployerReportingFulfillmentCommand()
				|| isProcessCDHPHRAFulfillment()
				|| isProcessCDHPHSAFulfillment()
				|| isPopulateMissingPeople()
				|| isProcessUnresolvedContractBenefitTypeForActivityIncentiveCommand()
				|| isEmployerActivityEndToEndReconCommand()
				|| isArchivePersonContractProgramHistoryCommand());
	}


	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}

	public String getCurrentProcessingCommand() {
		return currentProcessingCommand;
	}

	public void setCurrentProcessingCommand(String currentProcessingCommand) {
		this.currentProcessingCommand = currentProcessingCommand;
	}
	
	public void resetCurrentProcessingCommand() {
		this.currentProcessingCommand = null;
	}
	
	

	public String getEmployerFulfillActivityCatReport() {
		return employerFulfillActivityCatReport;
	}

	public void setEmployerFulfillActivityCatReport(
			String employerFulfillActivityCatReport) {
		this.employerFulfillActivityCatReport = employerFulfillActivityCatReport;
	}

	public Integer getProcessIDForCurrentProcessingCommand(){
		//default to zero
		Integer lProcessID = new Integer(0);
		if (currentProcessingCommand != null && processIDsMap.get(currentProcessingCommand) != null) {
			lProcessID = getProcessID(currentProcessingCommand);
		}
		return lProcessID;
	}
	
	public String getCurrentCommandText() {
		return currentCommandText;
	}

	public void setCurrentCommandText(String currentCommandText) {
		this.currentCommandText = currentCommandText;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public String getSourceSystemID() {
		return sourceSystemID;
	}

	public void setSourceSystemID(String sourceSystemID) {
		this.sourceSystemID = sourceSystemID;
	}

	public String getStartAtTwoDaysNolderFlag() {
		return startAtTwoDaysNolderFlag;
	}

	public void setStartAtTwoDaysNolderFlag(String startAtTwoDaysNolderFlag) {
		this.startAtTwoDaysNolderFlag = startAtTwoDaysNolderFlag;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public int getDaySpanToCtrlFilteredOutActivity() {
		return daySpanToCtrlFilteredOutActivity;
	}

	public void setDaySpanToCtrlFilteredOutActivity(
			int daySpanToCtrlFilteredOutActivity) {
		this.daySpanToCtrlFilteredOutActivity = daySpanToCtrlFilteredOutActivity;
	}
	
	/*
	 * // 5. all programs commad public boolean isAllBusinessProgramsCommand() {
	 * boolean result = parametersMap.containsKey(ALL_BUSINESS_PROGRAMS); return
	 * result; } public void setAllBusinessProgramsCommand() {
	 * setParameter(ALL_BUSINESS_PROGRAMS, ALL_BUSINESS_PROGRAMS); } // 7. one
	 * program public boolean isOneBusinessProgramCommand() { boolean result =
	 * parametersMap.containsKey(ONE_BUSINESS_PROGRAM); return result; }
	 * 
	 * public Integer getOneBusinessProgramID() { Integer programID = null; if
	 * (isOneBusinessProgramCommand()) { programID = (Integer)
	 * getParameter(StatusCalculationCommand.ONE_BUSINESS_PROGRAM); } return
	 * programID; }
	 * 
	 * public void setOneBusinessProgramCommand(Integer oneProgramID) {
	 * setParameter(ONE_BUSINESS_PROGRAM, oneProgramID); }
	 */
}

package com.healthpartners.service.imfs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.healthpartners.service.imfs.dto.NamedParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.RewardCardAddress;
import com.healthpartners.service.imfs.dto.RewardCardClientData;
import com.healthpartners.service.imfs.dto.RewardCardFulfilled;
import com.healthpartners.service.imfs.dto.RewardCardQuote;
import com.healthpartners.service.imfs.dto.RewardCardRecycleDetail;
import com.healthpartners.service.imfs.dto.RewardFulfillmentTrackingRecycle;
import com.healthpartners.service.imfs.dto.RewardFulfillmentTrackingReportHist;
import com.healthpartners.service.imfs.dto.RewardIntelispendOrdered;
import com.healthpartners.service.imfs.dto.RewardIntelispendShipped;
import com.healthpartners.service.imfs.exception.BPMException;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;
import org.owasp.esapi.ESAPI;



/**
 * 
 * @author tjquist
 *
 */
@Configuration
public class RewardCardDAOJdbc extends JdbcDaoSupport implements RewardCardDAO 
{
	private String selectQuotesFromBusProgramsWithRewardCards;

	private String insertRewardFulfillRecycle;
	
	private String insertRewardOrderDetailReport;
	
	private String insertRewardShipDetailReport;
	
	private String updateRewardFulfillRecycleStatus;
	
	private String updateRewardCardAddressWMissingFulfillTransHistID;
	
	private String selectRewardCardAddress;

	private String selectPersonAddressUsingMODS;
	
	private String selectRewardFulfillRecycle;
	
	private String selectRewardFulfillRecycleByItemNo;
	
	private String selectRewardRecycleByProgram;
	
	private String selectRewardProgramID;
	
	private String selectRewardsCardFulfilled;
	
	private String insertTransmissionAuditLog;
	
	private String findDuplicateRewardShipped;
	
	
	private String findDuplicateRewardOrdered;
	
	private String countRewardShippedDetailReportRow;
	
	private String updateRewardShipDetailReport;
	
	private String selectRewardCardClientData;
	
	private String updateRewardCardAddressWithProgramID;
	
	@Autowired
	private DataFieldMaxValueIncrementer rewardRecycleIdIncrementer;
	@Autowired
	private DataFieldMaxValueIncrementer rewardOrderDetailIncrementer;
	@Autowired
	private DataFieldMaxValueIncrementer rewardShipDetailIncrementer;
	@Autowired
	private DataFieldMaxValueIncrementer transmAuditLogIdIncrementer;

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;


	private static String groupByRewardCardAddress = 
			
			" group by " +
			"t.reward_card_address_id, " +
			"t.reward_txn_hist_id, " + 
            "t.first_nm, " +
            "t.middle_initial, " +
            "t.last_nm, " +
            "t.addr_line_1, " +
            "t.addr_line_2, " +
            "t.city, " +
            "t.state_cd, " +
            "t.postal_code, " +
            "t.postal_code_ext, " +
            "t.country_cd, " +
            "t.address_sts_tp_id, " +
            "t.address_sts_dt," +
            "t.biz_pgm_id," +
            "t.prsn_dmgrphcs_id," +
            "t.incntv_optn_id";

	@Autowired
	DataSource bpmDataSource;


	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}
	
	/**
	 * Retrieve Intelispend quote IDs that control what kind of card is produced by the vendor Intelispend.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<RewardCardQuote> getQuotesFromBusProgramsWithRewardCards() throws DataAccessException, BPMException
	{
		
		
		
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { };
		int types[] = new int[] {};
		final ArrayList<RewardCardQuote> lRewardCardQuotes = new ArrayList<RewardCardQuote>();
		
		template.query(selectQuotesFromBusProgramsWithRewardCards, params, types,
				new RowCallbackHandler() { 
					public void processRow(ResultSet rs) throws SQLException {
						RewardCardQuote lRewardCardQuote = new RewardCardQuote();	
						lRewardCardQuote.setQuoteID(rs.getString("QUOTE_NO"));
						lRewardCardQuote.setQuoteDescription(rs.getString("QUOTE_DESC"));
						lRewardCardQuotes.add(lRewardCardQuote);
					}
		});
		
		return lRewardCardQuotes;
	}
	
	/**
	 * Retrieve address information required by vendor Intelispend.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public RewardCardAddress getRewarCardAddress(Integer rewardTransHistID, Integer programID, Integer personDemographicsID, Integer incentiveOptionID) throws DataAccessException, BPMException
	{
		
		RewardCardAddress lRewardCardAddress = new RewardCardAddress();
		
		StringBuffer lQuery = new StringBuffer();
		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setRewardTxnHistId(rewardTransHistID);
		lQuery.append(selectRewardCardAddress);
		lQuery.append("where t.reward_txn_hist_id = :rewardTxnHistId");
		lQuery.append(groupByRewardCardAddress);
		
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { rewardTransHistID};
		int types[] = new int[] { Types.INTEGER};
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<RewardCardAddress> lRewardCardAddresses = namedParameterJdbcTemplate.query(lQuery.toString(),
					namedParameters, new RewardCardAddressRowMapper());

		
		//if no address returned based on using the trans hist id in the lookup,
		 // try using program ID person demographic id and incentive option
		if (lRewardCardAddresses.isEmpty()) {
			lRewardCardAddress = getRewarCardAddress(programID, personDemographicsID, incentiveOptionID);
		} else {
			lRewardCardAddress = lRewardCardAddresses.get(0);
		}
		
		return lRewardCardAddress;
	}

	/**
	 * Retrieve address information required by vendor Intelispend.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public RewardCardAddress getPersonAddressUsingMODS(Integer personDemographicsID) throws DataAccessException, BPMException
	{


		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectPersonAddressUsingMODS);

		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setPersonId(personDemographicsID);
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<RewardCardAddress> lRewardCardAddresses = namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
				new RowMapper() {
					@Override
					public RewardCardAddress mapRow(ResultSet rs, int i) throws SQLException {
						RewardCardAddress lRewardCardAddress = new RewardCardAddress();
						lRewardCardAddress.setFirstName(rs.getString("first_nm"));
						lRewardCardAddress.setMiddleInit(rs.getString("middle_nm"));
						lRewardCardAddress.setLastName(rs.getString("last_nm"));
						lRewardCardAddress.setAddressLine1(rs.getString("addr_line_txt1"));
						lRewardCardAddress.setAddressLine2(rs.getString("addr_line_txt2"));
						lRewardCardAddress.setCity(rs.getString("city_nm"));
						lRewardCardAddress.setStatCode(rs.getString("state_cd"));
						String postalCode = rs.getString("zipcode_cd");
						lRewardCardAddress.setPostalCode(BPMUtils.zipCode5Parser(postalCode));
						lRewardCardAddress.setPostalCodeExt(BPMUtils.zipCode4ExtParser(postalCode));
						return lRewardCardAddress;
					}

				});
		RewardCardAddress lRewardCardAddress = lRewardCardAddresses.get(0);

		return lRewardCardAddress;
	}
	
	/**
	 * Retrieve address information required by vendor Intelispend using programID, personDemographicsID, and incentiveOptionID.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public RewardCardAddress getRewarCardAddress(Integer programID, Integer personDemographicsID, Integer incentiveOptionID) throws DataAccessException, BPMException
	{
		RewardCardAddress lRewardCardAddress = new RewardCardAddress();
		
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectRewardCardAddress);
		lQuery.append(" where t.biz_pgm_id = :bizPgmId");
		lQuery.append(" AND t.prsn_dmgrphcs_id = :personId");
		lQuery.append(" AND t.incntv_optn_id = :incentiveId ");
		
		lQuery.append(groupByRewardCardAddress); 
		
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { programID, personDemographicsID, incentiveOptionID};
		int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.INTEGER};
		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setBizPgmId(programID);
		namedParameter.setPersonId(personDemographicsID);
		namedParameter.setIncentiveId(incentiveOptionID);
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		 List<RewardCardAddress> lRewardCardAddresses = namedParameterJdbcTemplate.query(lQuery.toString(),
					namedParameters, new RewardCardAddressRowMapper());
		 
		 if (lRewardCardAddresses.size() > 0) {
			 lRewardCardAddress = lRewardCardAddresses.get(0);
		 }
		
		 return lRewardCardAddress;
	}
	
	
	
	/**
	 * Retrieve program id from reward fulfillment history table using trans hist id.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Integer getProgramID(Integer rewardTransHistID) throws DataAccessException
	{
		
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {rewardTransHistID };
		int types[] = new int[] {Types.INTEGER};
		final ArrayList<Integer> programIDs = new ArrayList<Integer>();
		
		
		template.query(selectRewardProgramID, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						Integer programID = rs.getInt("biz_pgm_id");	
						programIDs.add(programID);
					}
		});
		
		Integer programID = programIDs.get(0);
		
		return programID;
	}
	
	/**
	 * Select reward cards fulfilled given parameters provided.
	 * 
	 * @return RewardCardsFulfilled collection object.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<RewardCardFulfilled> getRewardCardsFulfilled(String groupNo, String siteNo, java.sql.Date startDate)
			throws DataAccessException {
		final ArrayList<RewardCardFulfilled> lRewardCardsFulfilled = new ArrayList<RewardCardFulfilled>();
		StringBuffer query = new StringBuffer();
		query.append(selectRewardsCardFulfilled);
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = null;
		int types[] = null;
		
		
		if ((groupNo != null && groupNo.length() > 0) && (siteNo == null || siteNo.length() == 0)) {
			params = new Object[] { startDate, groupNo};
			query.append("AND egs.empl_grp_no = ?");
			types = new int[] { Types.DATE, Types.VARCHAR};
		} else if ((groupNo != null && groupNo.length() > 0) && (siteNo != null && siteNo.length() > 0)) {
			params = new Object[] {startDate, groupNo, siteNo };
			query.append("AND egs.empl_grp_no = ?");
			query.append("AND egs.empl_grp_site_id_no = ?");
			types = new int[] {Types.DATE, Types.VARCHAR, Types.VARCHAR};
		} else {
			params = new Object[] { startDate};
			types = new int[] { Types.DATE};
		}
		
		
		template.query(query.toString(), params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						RewardCardFulfilled lRewardCardFulfilled = new RewardCardFulfilled();
						lRewardCardFulfilled.setGroupNo(rs
								.getString("EMPL_GRP_NO"));
						lRewardCardFulfilled.setSiteNo(rs
								.getString("EMPL_GRP_SITE_ID_NO"));
						lRewardCardFulfilled.setRewardTransHistID(rs
								.getInt("reward_txn_hist_id"));
						lRewardCardFulfilled.setProgramIncentiveOptionID(rs
								.getInt("biz_pgm_incntv_optn_id"));
						lRewardCardFulfilled.setProgramID(rs
								.getInt("biz_pgm_id"));
						lRewardCardFulfilled.setMemberNo(rs
								.getString("hp_mem_id"));
						lRewardCardFulfilled.setPersonDemographicsID(rs
								.getInt("prsn_dmgrphcs_id"));
						lRewardCardFulfilled.setActivityID(rs
								.getInt("actv_id"));
						lRewardCardFulfilled.setActivityName(rs
								.getString("activity_name"));
						lRewardCardFulfilled.setInsertDate(rs
								.getDate("insert_ts"));
						lRewardCardFulfilled.setOrderId(rs
								.getString("order_id"));
						lRewardCardFulfilled.setRewardCardNoMasked(rs
								.getString("reward_card_no_mskd"));
						lRewardCardFulfilled.setFamilyCap(rs
								.getInt("family_cap"));
						lRewardCardFulfilled.setParticipantCap(rs
								.getInt("particip_cap"));
						lRewardCardsFulfilled
								.add(lRewardCardFulfilled);
					}
				});

		return lRewardCardsFulfilled;
	}
	
	
	/**
	 * Select a Reward Recycle record given reward fulfillment unique id.  Can return more than one record.  Reason is
	 * Intelispend returns errors by field columns sent.  This information is captured back to the recycle table.  So if x number
	 * of field columns sent, there can be as many as x number of errors returned.
	 * 
	 * @return RewardFulfillmentTrackingRecycle object.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<RewardFulfillmentTrackingRecycle> getRewardFulfillRecycle(int rewardTransHistID)
			throws DataAccessException {
		StringBuffer query = new StringBuffer();
		query.append(selectRewardFulfillRecycle);
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { rewardTransHistID};
		int types[] = new int[] { Types.INTEGER};

		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setRewardTxnHistId(rewardTransHistID);

		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);
		List<RewardFulfillmentTrackingRecycle> lRewardFulfillmentTrackingRecycles = namedParameterJdbcTemplate.query(query.toString(), namedParameters,
				new RowMapper() {
					@Override
					public RewardFulfillmentTrackingRecycle mapRow(ResultSet rs, int i) throws SQLException {
						RewardFulfillmentTrackingRecycle lRewardFulfillmentTrackingRecycle = new RewardFulfillmentTrackingRecycle();
						lRewardFulfillmentTrackingRecycle.setRewardRecycleId(rs
								.getInt("REWARD_RECYCLE_ID"));
						lRewardFulfillmentTrackingRecycle.setRewardTransHistID(rs
								.getInt("REWARD_TXN_HIST_ID"));
						lRewardFulfillmentTrackingRecycle.setRecycleStatusId(rs
								.getInt("RECYCLE_STS_ID"));
						lRewardFulfillmentTrackingRecycle.setRecycleStatus(rs
								.getString("RECYCLE_STATUS"));
						lRewardFulfillmentTrackingRecycle.setItemNo(rs
								.getString("RSN_ITEM_NO"));
						lRewardFulfillmentTrackingRecycle.setFieldColumn(rs
								.getString("RSN_COLUMN"));
						lRewardFulfillmentTrackingRecycle.setReasonDesc(rs
								.getString("RSN_DESC"));
						lRewardFulfillmentTrackingRecycle.setReasonCodeID(rs
								.getString("RSN_CD_ID"));
						return lRewardFulfillmentTrackingRecycle;
					}

				});

		return lRewardFulfillmentTrackingRecycles;
	}
	
	/**
	 * Select a Reward Recycle record given reward fulfillment unique id.  Can return more than one record.  Reason is
	 * Intelispend returns errors by field columns sent.  This information is captured back to the recycle table.  So if x number
	 * of field columns sent, there can be as many as x number of errors returned.
	 * 
	 * @return RewardFulfillmentTrackingRecycle object.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public boolean doesErrorExistInRewardRecycle(Integer rewardTransHistID, String itemNo)
			throws DataAccessException {
		
		boolean isAlreadyOnHold = false;
		final ArrayList<RewardFulfillmentTrackingRecycle> lRewardFulfillmentTrackingRecycles = new ArrayList<RewardFulfillmentTrackingRecycle>();
		StringBuffer query = new StringBuffer();
		query.append(selectRewardFulfillRecycleByItemNo);
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { rewardTransHistID, itemNo};
		int types[] = new int[] { Types.INTEGER, Types.VARCHAR};

		template.query(query.toString(), params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						RewardFulfillmentTrackingRecycle lRewardFulfillmentTrackingRecycle = new RewardFulfillmentTrackingRecycle();
						lRewardFulfillmentTrackingRecycle.setRewardRecycleId(rs
								.getInt("REWARD_RECYCLE_ID"));
						lRewardFulfillmentTrackingRecycle.setRewardTransHistID(rs
								.getInt("REWARD_TXN_HIST_ID"));
						lRewardFulfillmentTrackingRecycle.setRecycleStatusId(rs
								.getInt("RECYCLE_STS_ID"));
						lRewardFulfillmentTrackingRecycle.setRecycleStatus(rs
								.getString("RECYCLE_STATUS"));
						lRewardFulfillmentTrackingRecycle.setItemNo(rs
								.getString("RSN_ITEM_NO"));
						lRewardFulfillmentTrackingRecycle.setFieldColumn(rs
								.getString("RSN_COLUMN"));
						lRewardFulfillmentTrackingRecycle.setReasonDesc(rs
								.getString("RSN_DESC"));
						lRewardFulfillmentTrackingRecycle.setReasonCodeID(rs
								.getString("RSN_CD_ID"));
						
						lRewardFulfillmentTrackingRecycles
								.add(lRewardFulfillmentTrackingRecycle);
					}
				});
		
		if (lRewardFulfillmentTrackingRecycles.size() > 0) {
			isAlreadyOnHold = true;
		}
		
		return isAlreadyOnHold;
	}
	
	
	/**
	 * Select a Reward Recycle records by program ID and date.
	 * 
	 * @return RewardFulfillmentTrackingRecycle object.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<RewardCardRecycleDetail> getRewardRecycleByProgramOnHold(Integer programID, java.sql.Date selectionDate)
			throws DataAccessException {
		final ArrayList<RewardCardRecycleDetail> lRewardCardRecycleDetails = new ArrayList<RewardCardRecycleDetail>();
		StringBuffer query = new StringBuffer();
		query.append(selectRewardRecycleByProgram);
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {programID, selectionDate};
		int types[] = new int[] {Types.INTEGER, Types.DATE  };

		template.query(query.toString(), params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						RewardCardRecycleDetail lRewardCardRecycleDetail = new RewardCardRecycleDetail();
						lRewardCardRecycleDetail.setFirstName(rs
								.getString("FIRST_NM"));
						lRewardCardRecycleDetail.setMiddleName(rs
								.getString("MIDDLE_NM"));
						lRewardCardRecycleDetail.setLastName(rs
								.getString("LAST_NM"));
						lRewardCardRecycleDetail.setMemberNo(rs
								.getString("HP_MEM_ID"));
						lRewardCardRecycleDetail.setPersonID(rs
								.getInt("PRSN_ID"));
						lRewardCardRecycleDetail.setRecycleStatus(rs
								.getString("RECYCLE_STATUS"));
						lRewardCardRecycleDetail.setItemNo(rs
								.getString("RSN_ITEM_NO"));
						lRewardCardRecycleDetail.setFieldColumn(rs
								.getString("RSN_COLUMN"));
						lRewardCardRecycleDetail.setReasonDesc(rs
								.getString("RSN_DESC"));
						
						lRewardCardRecycleDetails
								.add(lRewardCardRecycleDetail);
					}
				});

		return lRewardCardRecycleDetails;
	}
	
	
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int updateRewardFulfillRecycleStatus(RewardFulfillmentTrackingRecycle lRewardFulfillmentTrackingRecycle) throws DataAccessException, BPMException {
		
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {
				lRewardFulfillmentTrackingRecycle.getRecycleStatusId(), 
				BPMConstants.BPM_USER_SYSTEM, 
				lRewardFulfillmentTrackingRecycle.getRewardRecycleId()
				 };
		int types[] = new int[] {  Types.INTEGER, Types.VARCHAR, Types.INTEGER };
				
		return template.update(updateRewardFulfillRecycleStatus, params, types);
		
	}
	

	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int insertRewardFulfillmentRecycle(RewardFulfillmentTrackingRecycle newRewardFulfillmentTrackingRecycle, String systemUser)
			throws DataAccessException, BPMException {
		
		Integer rewardRecycleId = rewardRecycleIdIncrementer
				.nextIntValue();
		
		Integer rewardTransHistID = (newRewardFulfillmentTrackingRecycle.getRewardTransHistID() != null) ? newRewardFulfillmentTrackingRecycle.getRewardTransHistID() : null;	
		
		String reasonCodeID = (newRewardFulfillmentTrackingRecycle.getReasonCodeID() != null) ? newRewardFulfillmentTrackingRecycle.getReasonCodeID() : null;
		String reasonColumn = (newRewardFulfillmentTrackingRecycle.getFieldColumn() != null) ? newRewardFulfillmentTrackingRecycle.getFieldColumn() : null;
		String reasonItemNo = (newRewardFulfillmentTrackingRecycle.getItemNo() != null) ? newRewardFulfillmentTrackingRecycle.getItemNo() : null;
		String reasonDesc = (newRewardFulfillmentTrackingRecycle.getReasonDesc() != null) ? newRewardFulfillmentTrackingRecycle.getReasonDesc() : null;
		Integer recycleStatusId = (newRewardFulfillmentTrackingRecycle.getRecycleStatusId() != null) ? newRewardFulfillmentTrackingRecycle.getRecycleStatusId() : null;	
		
		
		
		
		// Persist.
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { rewardRecycleId, rewardTransHistID, reasonCodeID, reasonColumn, reasonItemNo, reasonDesc,
				recycleStatusId, systemUser 
				 };

		int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
				Types.INTEGER, Types.VARCHAR};
		int rowInserted = 0;
		try {
			 rowInserted = template.update(insertRewardFulfillRecycle, params, types);
		} catch (Exception ex) {
			System.out.print("Error method rewardRecycleIdIncrementer possible attempt to insert duplicates: " + ex);
			logger.error("Error method rewardRecycleIdIncrementer possible attempt to insert duplicates: " + ex);
			logger.error("");
			logger.error("rewardTransHistID: " + rewardTransHistID); 
			
			throw new BPMException("Failed to insert RewardFulfillRecycle record.", ex);
			
		}
	
		return rowInserted;
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int insertRewardOrderDetailReport(RewardIntelispendOrdered lRewardIntelispendOrdered)
			throws DataAccessException, BPMException {
		
		java.sql.Date orderDate = null;
		Integer orderNumber;
		java.sql.Date shipDate;
		
		
		Integer rewardOrderDetailId = rewardOrderDetailIncrementer
				.nextIntValue();
		
		String quoteID = (lRewardIntelispendOrdered.getQuoteID() != null) ? lRewardIntelispendOrdered.getQuoteID() : null;
		
		String cartName = (lRewardIntelispendOrdered.getCartName() != null) ? lRewardIntelispendOrdered.getCartName() : null;
		
		String orderDateStr = (lRewardIntelispendOrdered.getOrderDate() != null) ? lRewardIntelispendOrdered.getOrderDate() : null;	
		if (orderDateStr != null) {
			orderDate = BPMUtils.formatDateMMddyyyy(orderDateStr);
		}
		
		String orderNumberStr = (lRewardIntelispendOrdered.getOrderNumber() != null) ? lRewardIntelispendOrdered.getOrderNumber() : null;
		if (orderNumberStr != null) {
			orderNumber = Integer.parseInt(orderNumberStr);
		} else{
			orderNumber = null;
		}
		
		String amountStr = (lRewardIntelispendOrdered.getAmount() != null) ? lRewardIntelispendOrdered.getAmount() : null;
		Double amountDoubleTO = 00.00;
		
		if (amountStr != null) {
			amountDoubleTO = Double.parseDouble(amountStr);
		}
		
		String cachePersonID = (lRewardIntelispendOrdered.getPersonIDIndicativeData3() != null) ? lRewardIntelispendOrdered.getPersonIDIndicativeData3() : null;
		
		String fulfillHistID = (lRewardIntelispendOrdered.getPidNumber() != null) ? lRewardIntelispendOrdered.getPidNumber() : null;
		
		
		String shipDateStr = (lRewardIntelispendOrdered.getShipDate() != null) ? lRewardIntelispendOrdered.getShipDate() : null;	
		if (shipDateStr != null) {
			shipDate = BPMUtils.formatDateMMddyyyy(shipDateStr);
		} else{
			shipDate = null;
		}
		
		String lastName = (lRewardIntelispendOrdered.getLastName() != null) ? lRewardIntelispendOrdered.getLastName() : null;
		String firstName = (lRewardIntelispendOrdered.getFirstName() != null) ? lRewardIntelispendOrdered.getFirstName() : null;
		String addressLine1 = (lRewardIntelispendOrdered.getAddressLine1() != null) ? lRewardIntelispendOrdered.getAddressLine1() : null;
		String addressLine2 = (lRewardIntelispendOrdered.getAddressLine2() != null) ? lRewardIntelispendOrdered.getAddressLine2() : null;
		String city = (lRewardIntelispendOrdered.getCity() != null) ? lRewardIntelispendOrdered.getCity() : null;
		String state = (lRewardIntelispendOrdered.getState() != null) ? lRewardIntelispendOrdered.getState() : null;
		String postalCode = (lRewardIntelispendOrdered.getPostalCode() != null) ? lRewardIntelispendOrdered.getPostalCode() : null;
		String groupNumber = (lRewardIntelispendOrdered.getGroupNumberIndicativeData1() != null) ? lRewardIntelispendOrdered.getGroupNumberIndicativeData1() : null;
		String groupName = (lRewardIntelispendOrdered.getGroupNameIndicativeData2() != null) ? lRewardIntelispendOrdered.getGroupNameIndicativeData2() : null;
		
		//Not doing anything with Indicative Data 4 since fulfillHistID is already stored as the PIDNumber returned from Intelispend.
		//String transactionID = (lRewardIntelispendOrdered.getIndicativeData4FulfillHistID() != null) ? lRewardIntelispendOrdered.getIndicativeData4FulfillHistID() : null;
		
		
		
		String reportFileName = (lRewardIntelispendOrdered.getOrderReportFileName() != null) ? lRewardIntelispendOrdered.getOrderReportFileName() : null;	
		
		Integer processStatusCode = (lRewardIntelispendOrdered.getProcessStatusCode() != null) ? lRewardIntelispendOrdered.getProcessStatusCode() : null;
		
		
		String proxyCardNumber = (lRewardIntelispendOrdered.getProxyCardNumber() != null) ? lRewardIntelispendOrdered.getProxyCardNumber() : null;
		
		String cardNumberMasked = (lRewardIntelispendOrdered.getCardNumberMasked() != null) ? lRewardIntelispendOrdered.getCardNumberMasked() : null;
		
		
		logger.info(" ");
		logger.info("rewardOrderDetailId  " +rewardOrderDetailId);
		logger.info("orderDate          " + orderDate);
		logger.info("orderNumber        " + orderNumber);
		logger.info("cardNumberMasked   " + cardNumberMasked);
		logger.info("amountDoubleTO.intValue()   " + amountDoubleTO.intValue());
		logger.info("cachePersonID      " + cachePersonID);
		logger.info("shipDate           " + shipDate);
		logger.info("lastName           " + lastName);
		logger.info("firstName   		" + firstName);
		logger.info("addressLine1  		" + addressLine1);
		logger.info("addressLine2   	" + addressLine2);
		logger.info("city   			" + city);
		logger.info("state   			" + state);
		logger.info("postalCode   		" + postalCode);
		logger.info("groupNumber   		" + groupNumber);
		logger.info("groupName   		" + groupName);
		logger.info("fulfillHistID   	" + fulfillHistID);
		logger.info("quoteID   			" + quoteID);
		logger.info("processStatusCode  " + processStatusCode);
		
		logger.info("BPMConstants.BPM_USER_SYSTEM   " + BPMConstants.BPM_USER_SYSTEM);
		logger.info("proxyCardNumber   	" + proxyCardNumber);
		logger.info("cartName   		" + cartName);
		logger.info("reportFileName " + reportFileName);
		
		
		// Persist.
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { rewardOrderDetailId,
										 orderDate,
										 orderNumber,
										 amountDoubleTO.intValue(),
										 Integer.valueOf(cachePersonID),
										 shipDate,
										 lastName,
										 firstName,
										 addressLine1,
										 addressLine2,
										 city,
										 state,
										 postalCode,
										 groupNumber,
										 groupName,
										 fulfillHistID,
										 quoteID,
										 reportFileName,
										 processStatusCode,
										 BPMConstants.BPM_USER_SYSTEM,
										 cartName,
										 proxyCardNumber,
										 cardNumberMasked
		};

		int types[] = new int[] { Types.INTEGER,  Types.DATE, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.DATE,
				                  Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
				                  Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
				                  Types.VARCHAR, Types.INTEGER, Types.VARCHAR, Types.VARCHAR,  Types.VARCHAR, Types.VARCHAR};
		int rowInserted = 0;
		try {
			 rowInserted = template.update(insertRewardOrderDetailReport, params, types);
		} catch (Exception ex) {
			System.out.print("Error method rewardOrderDetailIncrementer possible attempt to insert duplicates: " + ex);
			logger.error("Error method rewardOrderDetailIncrementer possible attempt to insert duplicates: " + ex);
			logger.error("");
			logger.error("transaction ID (fulfillHistID) is: " + fulfillHistID); 
			
			throw new BPMException("Failed to insert RewardIntelispendOrdered record.", ex);
			
		}
	
		return rowInserted;
	}
	
	/**
	 * EV89209 - added update method to handle replacement cards sent from vendor.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int updateRewardShipDetailReport(
			RewardIntelispendShipped lRewardIntelispendShipped)
			throws DataAccessException, BPMException {
		
		int rowUpdated = 0;
		String pidNumber = lRewardIntelispendShipped.getPidNumber();
		if (!hasRewardShippedDetailReportRow(pidNumber)) {
			rowUpdated = insertRewardShipDetailReport(lRewardIntelispendShipped);
			return rowUpdated;
		} else {
			
			JdbcTemplate template = getJdbcTemplate();
			Object params[] = new Object[] {
					BPMUtils.formatDateMMddyyyy(lRewardIntelispendShipped.getOrderDate()),
					lRewardIntelispendShipped.getOrderNumber(),
					lRewardIntelispendShipped.getCardNumberMasked(),
					lRewardIntelispendShipped.getProxyCardNumber(),
					BPMUtils.formatDateMMddyyyy(lRewardIntelispendShipped.getShipDate()),
					lRewardIntelispendShipped.getShippedVia(),
					lRewardIntelispendShipped.getShipTrackingNumber(),
					lRewardIntelispendShipped.getRewardCardType(),
					pidNumber
					};
			int types[] = new int[] { Types.DATE, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
					Types.DATE, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR}; 
					
			rowUpdated = template.update(updateRewardShipDetailReport, params, types);
		
			return rowUpdated;
		}
	}

	private int insertRewardShipDetailReport(RewardIntelispendShipped lRewardIntelispendShipped)
			throws DataAccessException, BPMException {
		
		java.sql.Date orderDate;
		Integer orderNumber = null;
		
		java.sql.Date shipDate;
	
		
		Integer rewardShipDetailId = rewardShipDetailIncrementer
				.nextIntValue();
		
		String orderDateStr = (lRewardIntelispendShipped.getOrderDate() != null) ? lRewardIntelispendShipped.getOrderDate() : null;	
		if (orderDateStr != null) {
			orderDate = BPMUtils.formatDateMMddyyyy(orderDateStr);
		} else{
			orderDate = null;
		}
		
		String orderNumberStr = (lRewardIntelispendShipped.getOrderNumber() != null) ? lRewardIntelispendShipped.getOrderNumber() : null;
		if (orderNumberStr != null) {
			orderNumber = Integer.parseInt(orderNumberStr);
		}

		String cardNumber = lRewardIntelispendShipped.getCardNumberMasked();
		String cardNumberMasked = (cardNumber != null) ? cardNumber : null;
		
		String amountStr = (lRewardIntelispendShipped.getAmount() != null) ? lRewardIntelispendShipped.getAmount() : null;
		Double amountDouble = 00.00;
		
		if (amountStr != null) {
			amountDouble = Double.parseDouble(amountStr);
		}
		
		Integer cachePersonID =  Integer.valueOf(lRewardIntelispendShipped.getPersonIDIndicativeData3());
		
		String fulfillHistID = (lRewardIntelispendShipped.getPidNumber() != null) ? lRewardIntelispendShipped.getPidNumber() : null;
		
		String shipDateStr = (lRewardIntelispendShipped.getShipDate() != null) ? lRewardIntelispendShipped.getShipDate() : null;	
		if (shipDateStr != null) {
			shipDate = BPMUtils.formatDateMMddyyyy(shipDateStr);
		}else {
			shipDate = null;
		}
		
		String lastName = (lRewardIntelispendShipped.getLastName() != null) ? lRewardIntelispendShipped.getLastName() : null;
		String firstName = (lRewardIntelispendShipped.getFirstName() != null) ? lRewardIntelispendShipped.getFirstName() : null;
		String addressLine1 = (lRewardIntelispendShipped.getAddressLine1() != null) ? lRewardIntelispendShipped.getAddressLine1() : null;
		String addressLine2 = (lRewardIntelispendShipped.getAddressLine2() != null) ? lRewardIntelispendShipped.getAddressLine2() : null;
		String city = (lRewardIntelispendShipped.getCity() != null) ? lRewardIntelispendShipped.getCity() : null;
		String state = (lRewardIntelispendShipped.getState() != null) ? lRewardIntelispendShipped.getState() : null;
		String postalCode = (lRewardIntelispendShipped.getPostalCode() != null) ? lRewardIntelispendShipped.getPostalCode() : null;
		String groupNumber = (lRewardIntelispendShipped.getGroupNumberIndicativeData1() != null) ? lRewardIntelispendShipped.getGroupNumberIndicativeData1() : null;
		String groupName = (lRewardIntelispendShipped.getGroupNameIndicativeData2() != null) ? lRewardIntelispendShipped.getGroupNameIndicativeData2() : null;
		
		
		String quoteID = (lRewardIntelispendShipped.getQuoteID() != null) ? lRewardIntelispendShipped.getQuoteID() : null;
		String reportFileName = (lRewardIntelispendShipped.getShipReportFileName() != null) ? lRewardIntelispendShipped.getShipReportFileName() : null;	

		Integer processStatusCode = (lRewardIntelispendShipped.getProcessStatusCode() != null) ? lRewardIntelispendShipped.getProcessStatusCode() : null;
		
		
		String proxyCardNumber = (lRewardIntelispendShipped.getProxyCardNumber() != null) ? lRewardIntelispendShipped.getProxyCardNumber() : null;
		String shippedVia = (lRewardIntelispendShipped.getShippedVia() != null) ? lRewardIntelispendShipped.getShippedVia() : null;
		String shipTrackingNumber = (lRewardIntelispendShipped.getShipTrackingNumber() != null) ? lRewardIntelispendShipped.getShipTrackingNumber() : null;
		String rewardCardType = (lRewardIntelispendShipped.getRewardCardType() != null) ? lRewardIntelispendShipped.getRewardCardType() : null;
		
		logger.info(" ");
		logger.info("rewardShipDetailId " + rewardShipDetailId);
		logger.info("orderDate          " + orderDate);
		logger.info("orderNumber        " + orderNumber);
		logger.info("cardNumberMasked   " + cardNumberMasked);
		logger.info("amountDouble.intValue()   " + amountDouble.intValue());
		logger.info("cachePersonID      " + cachePersonID);
		logger.info("shipDate           " + shipDate);
		logger.info("lastName           " + lastName);
		logger.info("firstName   		" + firstName);
		logger.info("addressLine1  		" + addressLine1);
		logger.info("addressLine2   	" + addressLine2);
		logger.info("city   			" + city);
		logger.info("state   			" + state);
		logger.info("postalCode   		" + postalCode);
		logger.info("groupNumber   		" + groupNumber);
		logger.info("groupName   		" + groupName);
		logger.info("fulfillHistID   	" + fulfillHistID);
		logger.info("quoteID   			" + quoteID);
		logger.info("reportFileName   	" + reportFileName);
		logger.info("processStatusCode  " + processStatusCode);
		
		logger.info("BPMConstants.BPM_USER_SYSTEM   " + BPMConstants.BPM_USER_SYSTEM);
		logger.info("proxyCardNumber   	" + proxyCardNumber);
		logger.info("shippedVia   		" + shippedVia);
		logger.info("shipTrackingNumber " + shipTrackingNumber);
		logger.info("reportFileName " + reportFileName);
		logger.info("rewardCardType " + rewardCardType);
		
		// Persist.
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { rewardShipDetailId, 
										 orderDate,
										 orderNumber,
										 cardNumberMasked,
										 amountDouble.intValue(),
										 cachePersonID,
										 shipDate,
										 lastName,
										 firstName,
										 addressLine1,
										 addressLine2,
										 city,
										 state,
										 postalCode,
										 groupNumber,
										 groupName,
										 fulfillHistID,
										 quoteID,
										 reportFileName,
										 processStatusCode,
										 BPMConstants.BPM_USER_SYSTEM,
										 proxyCardNumber,
										 shippedVia,
										 shipTrackingNumber,
										 rewardCardType
										 
										 
		};
		
		int types[] = new int[] { Types.INTEGER, Types.DATE, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER,  Types.DATE,
				                  Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
				                  Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, 
				                  Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };
		int rowInserted = 0;
		try {
			 rowInserted = template.update(insertRewardShipDetailReport, params, types);
		} catch (Exception ex) {
			System.out.print("Error method rewardShipDetailIncrementer possible attempt to insert duplicates: " + ex);
			logger.error("Error method rewardShipDetailIncrementer possible attempt to insert duplicates: " + ex);
			logger.error("");
			logger.error("transaction history ID is: " + fulfillHistID); 
			
			throw new BPMException("Failed to insert RewardIntelispendShipped record.", ex);
			
		}
	
		return rowInserted;
	}
	/*
	 * EV89209 - this method checks to see if row already exists.  If yes, then vendor sent in a replacement card transaction.
	 */

	private boolean hasRewardShippedDetailReportRow(String pRewardTransactionHistID) throws DataAccessException {
		final ArrayList<Boolean> results = new ArrayList<Boolean>();
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { pRewardTransactionHistID};
		int types[] = new int[] { Types.VARCHAR };
		template.query(countRewardShippedDetailReportRow, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {

						if (rs.getInt(1) > 0) {
							results.add(Boolean.valueOf(true));
						}
					}
				});

		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
		
		return (results.size() > 0 && results.get(0).booleanValue() == true);
	}
	

	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Integer insertTransmissionAuditLog(Integer transactionID, Integer sendReceiveCodeID, Integer transmissionStatusID)
			throws DataAccessException {
		// Retrieve the next sequence number for the audit log entry.
		Integer auditLogId = new Integer(transmAuditLogIdIncrementer.nextIntValue());

		// Persist the audit log entry.
		JdbcTemplate template = getJdbcTemplate();
		Date logDate = new Date();
		Object params[] = new Object[] {
				auditLogId,
				transactionID,
				sendReceiveCodeID,
				transmissionStatusID
				 };
		int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER};
		template.update(insertTransmissionAuditLog, params, types);

		return auditLogId;
	}
	
	/**
	 * Determine if Intelispend sent duplicate shipped transactions
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Integer findDuplicateRewardShipped(RewardIntelispendShipped lRewardIntelispendShipped) throws DataAccessException
	{
		
		String rewardCardTransID = lRewardIntelispendShipped.getPidNumber();
		
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {rewardCardTransID };
		int types[] = new int[] {Types.VARCHAR};
		final ArrayList<Integer> recFoundCt = new ArrayList<Integer>();
		
		template.query(findDuplicateRewardShipped, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						Integer foundCt = Integer.valueOf(rs.getString("COUNT"));
						recFoundCt.add(foundCt);
					}
		});
		
		Integer shippedRecFoundCt = recFoundCt.get(0);
		
		return shippedRecFoundCt;
	}	
	
	/**
	 * Determine if Inelispend send duplicate ordered transactions
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Integer findDuplicateRewardOrdered(RewardIntelispendOrdered lRewardIntelispendOrdered) throws DataAccessException
	{
		
		
		String transHistID = lRewardIntelispendOrdered.getPidNumber();
		
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {transHistID };
		int types[] = new int[] {Types.VARCHAR};
		final ArrayList<Integer> recFoundCt = new ArrayList<Integer>();
		
		template.query(findDuplicateRewardOrdered, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						Integer foundCt = Integer.valueOf(rs.getString("COUNT"));
						recFoundCt.add(foundCt);
					}
		});
		
		Integer orderedRecFoundCt = recFoundCt.get(0);
		
		return orderedRecFoundCt;
	}
	
	/*
	 * This method exists because once an address is found while using programID, personDemographicsID and incentiveOptionID
	 * as the matching criteria from the fulfillment record, apply the fulfillment history ID back to the address
	 */
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int updateRewardCardAddressWMissingTransHistID(RewardCardAddress lRewardCardAddress)
			throws DataAccessException, BPMException {
		    
		    Integer fulfillTransHistID = lRewardCardAddress.getRewardTransHistID();
		    Integer programID = lRewardCardAddress.getProgramID();
		    Integer personDemographicsID = lRewardCardAddress.getPersonDemographicsID();
		    Integer incentiveOptionID = lRewardCardAddress.getIncentiveOptionID();
		    
					
			JdbcTemplate template = getJdbcTemplate();
			Object params[] = new Object[] { 
					fulfillTransHistID,
					programID,
					personDemographicsID,
					incentiveOptionID};
			int types[] = new int[] { Types.INTEGER, Types.INTEGER,
					Types.INTEGER, Types.INTEGER};									
			return template.update(updateRewardCardAddressWMissingFulfillTransHistID, params, types);
		
	}
	
	/*
	 * This method exists to address cases where a site transfer occurred with member and
	 * member achieved a reward card under the old site.  Under the new site, they enter an
	 * the address where they want the reward to be sent to through the web.  As a result, the reward card address
	 * record contains the program id of the business program enrolled in.  The reward card address
	 * record needs to change to use the program id the member achieved the incentive under.
	 */
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int updateRewardCardAddressWithProgramID(Integer rewardCardAddressID, Integer programID)
			throws DataAccessException, BPMException {
		    
			JdbcTemplate template = getJdbcTemplate();
			Object params[] = new Object[] { 
					programID,
					rewardCardAddressID
			};
			int types[] = new int[] { Types.INTEGER, Types.INTEGER};									
			return template.update(updateRewardCardAddressWithProgramID, params, types);
		
	}
	
	
	
	private static final class RewardCardAddressRowMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			
			RewardCardAddress lRewardCardAddress = new RewardCardAddress();
			
			lRewardCardAddress.setRewardCardAddressID(rs.getInt("reward_card_address_id"));
			lRewardCardAddress.setRewardTransHistID(rs.getInt("reward_txn_hist_id"));
			lRewardCardAddress.setFirstName(rs.getString("first_nm"));
			lRewardCardAddress.setMiddleInit(rs.getString("middle_initial"));
			lRewardCardAddress.setLastName(rs.getString("last_nm"));
			lRewardCardAddress.setAddressLine1(rs.getString("addr_line_1"));
			lRewardCardAddress.setAddressLine2(rs.getString("addr_line_2"));
			lRewardCardAddress.setCity(rs.getString("city"));
			lRewardCardAddress.setStatCode(rs.getString("state_cd"));
			lRewardCardAddress.setPostalCode(rs.getString("postal_code"));
			lRewardCardAddress.setPostalCodeExt(rs.getString("postal_code_ext"));
			lRewardCardAddress.setCountryCode(rs.getString("country_cd"));
			lRewardCardAddress.setAddressStatusTypeId(rs.getInt("address_sts_tp_id"));
			lRewardCardAddress.setAddressStatusDate(rs.getDate("address_sts_dt"));
			lRewardCardAddress.setProgramID(rs.getInt("biz_pgm_id"));
			lRewardCardAddress.setPersonDemographicsID(rs.getInt("prsn_dmgrphcs_id"));
			lRewardCardAddress.setIncentiveOptionID(rs.getInt("incntv_optn_id"));

			return lRewardCardAddress;
		}
	}
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public RewardCardClientData getRewardCardClientData(Integer pProgramID, Integer pIncentiveOptionID)
	throws DataAccessException
	{		
		final ArrayList<RewardCardClientData> lRewardCardClientDataList = new ArrayList<RewardCardClientData>();				
				
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {pProgramID, pIncentiveOptionID};
		int types[] = new int[] {Types.INTEGER, Types.INTEGER  };				

		template.query(selectRewardCardClientData, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						RewardCardClientData lRewardCardClientData = new RewardCardClientData();
							
						lRewardCardClientData.setRewardCardClientContactID(rs.getInt("REWARD_CARD_CLIENT_CNTCT_ID"));
						
						lRewardCardClientData.setCompanyName(rs.getString("CLIENT_CMPNY_NM"));
						lRewardCardClientData.setContactName(rs.getString("CLIENT_CNTCT_NM"));
						
						lRewardCardClientData.setAddressLine1(rs.getString("CLIENT_ADDR_LINE_1"));
						lRewardCardClientData.setAddressLine2(rs.getString("CLIENT_ADDR_LINE_2"));
						lRewardCardClientData.setCity(rs.getString("CLIENT_CITY"));
						lRewardCardClientData.setState(rs.getString("CLIENT_STATE_CD"));						
												
						StringBuffer lZipPlusExt = new StringBuffer();
						lZipPlusExt.append(rs.getString("CLIENT_POSTAL_CODE"));	
						if(rs.getString("CLIENT_POSTAL_CD_EXT") != null)
						{
						   lZipPlusExt.append(rs.getString("CLIENT_POSTAL_CD_EXT"));
						}
						
						lRewardCardClientData.setZip(lZipPlusExt.toString());
						lRewardCardClientData.setTaxID(rs.getString("CLIENT_TAX_ID"));
						
						lRewardCardClientDataList.add(lRewardCardClientData);
					}
				});				
				
		return lRewardCardClientDataList.get(0);
	}
	

	public String getSelectQuotesFromBusProgramsWithRewardCards() {
		return selectQuotesFromBusProgramsWithRewardCards;
	}

	public void setSelectQuotesFromBusProgramsWithRewardCards(
			String selectQuotesFromBusProgramsWithRewardCards) {
		this.selectQuotesFromBusProgramsWithRewardCards = selectQuotesFromBusProgramsWithRewardCards;
	}
	
	public void setUpdateRewardFulfillRecycleStatus(
			String updateRewardFulfillRecycleStatus) {
		this.updateRewardFulfillRecycleStatus = updateRewardFulfillRecycleStatus;
	}
	
	

	

	public void setUpdateRewardCardAddressWMissingFulfillTransHistID(
			String updateRewardCardAddressWMissingFulfillTransHistID) {
		this.updateRewardCardAddressWMissingFulfillTransHistID = updateRewardCardAddressWMissingFulfillTransHistID;
	}

	public void setSelectRewardCardAddress(String selectRewardCardAddress) {
		this.selectRewardCardAddress = selectRewardCardAddress;
	}

	public void setSelectPersonAddressUsingMODS(String selectPersonAddressUsingMODS) {
		this.selectPersonAddressUsingMODS = selectPersonAddressUsingMODS;
	}

	public void setInsertRewardFulfillRecycle(String insertRewardFulfillRecycle) {
		this.insertRewardFulfillRecycle = insertRewardFulfillRecycle;
	}


	public void setInsertRewardShipDetailReport(String insertRewardShipDetailReport) {
		this.insertRewardShipDetailReport = insertRewardShipDetailReport;
	}

	public void setInsertRewardOrderDetailReport(
			String insertRewardOrderDetailReport) {
		this.insertRewardOrderDetailReport = insertRewardOrderDetailReport;
	}

	public void setSelectRewardFulfillRecycle(String selectRewardFulfillRecycle) {
		this.selectRewardFulfillRecycle = selectRewardFulfillRecycle;
	}
	
	
	

	public void setSelectRewardFulfillRecycleByItemNo(
			String selectRewardFulfillRecycleByItemNo) {
		this.selectRewardFulfillRecycleByItemNo = selectRewardFulfillRecycleByItemNo;
	}

	public void setSelectRewardRecycleByProgram(String selectRewardRecycleByProgram) {
		this.selectRewardRecycleByProgram = selectRewardRecycleByProgram;
	}

	public void setInsertTransmissionAuditLog(String insertTransmissionAuditLog) {
		this.insertTransmissionAuditLog = insertTransmissionAuditLog;
	}
	

	public void setRewardRecycleIdIncrementer(
			DataFieldMaxValueIncrementer rewardRecycleIdIncrementer) {
		this.rewardRecycleIdIncrementer = rewardRecycleIdIncrementer;
	}

	public void setRewardOrderDetailIncrementer(
			DataFieldMaxValueIncrementer rewardOrderDetailIncrementer) {
		this.rewardOrderDetailIncrementer = rewardOrderDetailIncrementer;
	}

	public void setRewardShipDetailIncrementer(
			DataFieldMaxValueIncrementer rewardShipDetailIncrementer) {
		this.rewardShipDetailIncrementer = rewardShipDetailIncrementer;
	}

	public void setTransmAuditLogIdIncrementer(
			DataFieldMaxValueIncrementer transmAuditLogIdIncrementer) {
		this.transmAuditLogIdIncrementer = transmAuditLogIdIncrementer;
	}

	public void setFindDuplicateRewardShipped(String findDuplicateRewardShipped) {
		this.findDuplicateRewardShipped = findDuplicateRewardShipped;
	}
	

	public void setFindDuplicateRewardOrdered(String findDuplicateRewardOrdered) {
		this.findDuplicateRewardOrdered = findDuplicateRewardOrdered;
	}

	public void setSelectRewardProgramID(String selectRewardProgramID) {
		this.selectRewardProgramID = selectRewardProgramID;
	}
	
	
	
	public void setSelectRewardsCardFulfilled(String selectRewardsCardFulfilled) {
		this.selectRewardsCardFulfilled = selectRewardsCardFulfilled;
	}

	public void setCountRewardShippedDetailReportRow(
			String countRewardShippedDetailReportRow) {
		this.countRewardShippedDetailReportRow = countRewardShippedDetailReportRow;
	}

	public void setUpdateRewardShipDetailReport(String updateRewardShipDetailReport) {
		this.updateRewardShipDetailReport = updateRewardShipDetailReport;
	}

	public final String getSelectRewardCardClientData() {
		return selectRewardCardClientData;
	}

	public final void setSelectRewardCardClientData(String selectRewardCardClientData) {
		this.selectRewardCardClientData = selectRewardCardClientData;
	}

	public void setUpdateRewardCardAddressWithProgramID(String updateRewardCardAddressWithProgramID) {
		this.updateRewardCardAddressWithProgramID = updateRewardCardAddressWithProgramID;
	}

	public String encode(String message) {
		message = message.replace( '\n' ,  '_' ).replace( '\r' , '_' )
				.replace( '\t' , '_' );
		message = ESAPI.encoder().encodeForHTML( message );
		return message;
	}
	
	
	
}

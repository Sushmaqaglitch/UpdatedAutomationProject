/**
 * 
 */
package com.healthpartners.service.imfs.filter;

import java.util.Calendar;


import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.ActivityEvent;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.iface.MemberService;
import com.healthpartners.service.imfs.iface.QualificationTimeService;
import com.healthpartners.service.imfs.filter.ActivityEventFilter;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;



/**
 * @author mxthoutam
 * 
 */
public class RequiredParticipantFilter implements ActivityEventFilter {


	protected final Log logger = LogFactory.getLog(getClass());

	private MemberService memberService;
	
	private QualificationTimeService qualificationTimeService;

	/*
	 * @see com.healthpartners.service.bpm.filter.ActivityEventFilter#doFilter(com.healthpartners.service.bpm.dto.ActivityEvent)
	 */
	public String doFilter(ActivityEvent activityEvent) throws BPMException {
		String result = BPMConstants.BPM_FILTERD_OUT_RSN_CD0_OK; // filter IN
		//logger.info("@@ called RequiredParticipantFilter--");
		try {
			
			if(activityEvent.getMemberActivity().getActivityStatus().getStatusEffectiveDate() == null)
			{
				activityEvent.setReasonDescription(BPMConstants.BPM_FILTERD_OUT_RSN_CD14_ACTIVITY_DATE_MISSING);
				Calendar lPlaceHolderDate = Calendar.getInstance();
				lPlaceHolderDate.set(Calendar.DAY_OF_MONTH, 1);
				lPlaceHolderDate.set(Calendar.MONTH, 0);
				lPlaceHolderDate.set(Calendar.YEAR, 9999);
				
				activityEvent.getMemberActivity().getActivityStatus().setStatusEffectiveDate(lPlaceHolderDate);
				return BPMConstants.BPM_FILTERD_OUT_RSN_CD14_ACTIVITY_DATE_MISSING;
			}
			
			int targetQualificationYear = BPMUtils.getYearFromDateString(BPMUtils.formatDatemmddyyyy(activityEvent.getMemberActivity().getActivityStatus().getStatusEffectiveDate()));
						
			boolean requiredParticipant = memberService.isRequiredParticipant(activityEvent
					.getMemberID(), targetQualificationYear, activityEvent.getMemberActivity().getActivityStatus().getStatusEffectiveDate());
			
						
	        if (!requiredParticipant) {
	        	// This method call addresses an issue where member experiences a package change at the beginning or middle of a program year.  See EV109752.
	        	//commented out until fully tested
	        	//requiredParticipant = memberService.isRequiredParticipantRetroactive(activityEvent
				//		.getMemberID(), targetQualificationYear, activityEvent.getMemberActivity().getActivityStatus().getStatusEffectiveDate());
	        	if (!requiredParticipant) {
	        		result = BPMConstants.BPM_FILTERD_OUT_RSN_CD7_NON_PART_MEMBER;
	        	}
	        }
			

		} catch (Exception e) {
			e.printStackTrace();
			logger.info("@@ exception in RequiredParticipantFilter="
					+ e.getMessage());
			throw new BPMException(e);
		}

		//logger.info("@@ RequiredParticipantFilter-- result=" + result);

		return result;
	}

	public MemberService getMemberService() {
		return memberService;
	}

	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}

	public QualificationTimeService getQualificationTimeService() {
		return qualificationTimeService;
	}

	public void setQualificationTimeService(
			QualificationTimeService qualificationTimeService) {
		this.qualificationTimeService = qualificationTimeService;
	}

}

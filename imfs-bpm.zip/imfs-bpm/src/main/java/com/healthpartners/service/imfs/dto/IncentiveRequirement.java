package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * 
 * @author jxbourbour
 *
 */
public class IncentiveRequirement implements Serializable
{	
	static final long serialVersionUID = 0L;
	
	private Integer programID;
	private Integer incentiveOptionID;
	private Integer activityIncentiveGroupID;
	private Integer activityIncentiveGroupReqID;	
	private Integer requiredQuantity;
	
	private ArrayList<ActivityIncentive> activityIncentives;
			       
    public IncentiveRequirement()
    {
    	super();
    }

	public Integer getActivityIncentiveGroupID() {
		return activityIncentiveGroupID;
	}

	public void setActivityIncentiveGroupID(Integer activityIncentiveGroupID) {
		this.activityIncentiveGroupID = activityIncentiveGroupID;
	}

	public Integer getActivityIncentiveGroupReqID() {
		return activityIncentiveGroupReqID;
	}

	public void setActivityIncentiveGroupReqID(Integer activityIncentiveGroupReqID) {
		this.activityIncentiveGroupReqID = activityIncentiveGroupReqID;
	}

	public Integer getRequiredQuantity() {
		return requiredQuantity;
	}

	public void setRequiredQuantity(Integer requiredQuantity) {
		this.requiredQuantity = requiredQuantity;
	}

	public ArrayList<ActivityIncentive> getActivityIncentives() {
		return activityIncentives;
	}

	public void setActivityIncentives(
			ArrayList<ActivityIncentive> activityIncentives) {
		this.activityIncentives = activityIncentives;
	}

	public Integer getProgramID() {
		return programID;
	}

	public void setProgramID(Integer programID) {
		this.programID = programID;
	}

	public Integer getIncentiveOptionID() {
		return incentiveOptionID;
	}

	public void setIncentiveOptionID(Integer incentiveOptionID) {
		this.incentiveOptionID = incentiveOptionID;
	}
	    
}

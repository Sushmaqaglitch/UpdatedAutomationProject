package com.healthpartners.service.imfs.factory;


import com.healthpartners.service.imfs.iface.EnvCodeService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;



public class BPMLUVWsProxyFactory {
    @Autowired
	private EnvCodeService envCodeService;

	protected final Log logger = LogFactory.getLog(getClass());
	
	/*
	@Override
	public void afterPropertiesSet() {
		try {
			String url = envCodeService.getENVCodeByCode(BPMConstants.REWARDCARD_URL).getEnvCodeValue();
			logger.info("BPMLUVWsProxyFactory.afterPropertiesSet URL is " + url);
			setEndpointAddress(url);
		} catch (Exception e) {
			throw(new RuntimeException(e));
		}
		super.afterPropertiesSet();
	}
	*/

	public void setEnvCodeService(EnvCodeService envCodeService) {
		this.envCodeService = envCodeService;
	}


	
}

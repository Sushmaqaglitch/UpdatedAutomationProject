package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.sql.Date;

public class PersonActivityIncentive implements Serializable
{	
	static final long serialVersionUID = 0L;
		
	private Integer businessProgramID;
	private Integer contractNo;
	private Integer incentiveOptionID;
	private Integer incentiveOptionGroupID;
	private Integer incentiveOptionRequirementID;
	private Integer personDemographicsID;
	private Integer activityID;
	private Integer activityTypeCodeID;
	private Integer activityIncentiveID;
	private Integer activityStatusCodeID;
	private String activityStatusCode;
	private String registrationID;
	private Date incentiveStatusDate;
	private Integer incentiveQuantity;
	private Integer relationshipCode;
	private String benefitContractType;
	private Integer collectionID;
	private Integer programIncentiveOptionID;
	private String activationStatusCode;
	
	private Integer participantCap;
	private Integer familyCap;
	
	public PersonActivityIncentive() {}

	public Integer getBusinessProgramID() {
		return businessProgramID;
	}

	public void setBusinessProgramID(Integer businessProgramID) {
		this.businessProgramID = businessProgramID;
	}


	public Integer getContractNo() {
		return contractNo;
	}

	public void setContractNo(Integer contractNo) {
		this.contractNo = contractNo;
	}

	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}

	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}

	public Integer getActivityID() {
		return activityID;
	}

	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}

	public Integer getActivityTypeCodeID() {
		return activityTypeCodeID;
	}

	public void setActivityTypeCodeID(Integer activityTypeCodeID) {
		this.activityTypeCodeID = activityTypeCodeID;
	}

	public Integer getActivityIncentiveID() {
		return activityIncentiveID;
	}

	public void setActivityIncentiveID(Integer activityIncentiveID) {
		this.activityIncentiveID = activityIncentiveID;
	}

	public Integer getActivityStatusCodeID() {
		return activityStatusCodeID;
	}

	public void setActivityStatusCodeID(Integer activityStatusCodeID) {
		this.activityStatusCodeID = activityStatusCodeID;
	}	

	public String getActivityStatusCode() {
		return activityStatusCode;
	}

	public void setActivityStatusCode(String activityStatusCode) {
		this.activityStatusCode = activityStatusCode;
	}

	public String getRegistrationID() {
		return registrationID;
	}

	public void setRegistrationID(String registrationID) {
		this.registrationID = registrationID;
	}

	public Integer getIncentiveQuantity() {
		return incentiveQuantity;
	}

	public void setIncentiveQuantity(Integer incentiveQuantity) {
		this.incentiveQuantity = incentiveQuantity;
	}

	public Date getIncentiveStatusDate() {
		return incentiveStatusDate;
	}

	public void setIncentiveStatusDate(Date incentiveStatusDate) {
		this.incentiveStatusDate = incentiveStatusDate;
	}

	public Integer getRelationshipCode() {
		return relationshipCode;
	}

	public void setRelationshipCode(Integer relationshipCode) {
		this.relationshipCode = relationshipCode;
	}

	public Integer getIncentiveOptionID() {
		return incentiveOptionID;
	}

	public void setIncentiveOptionID(Integer incentiveOptionID) {
		this.incentiveOptionID = incentiveOptionID;
	}

	public Integer getIncentiveOptionGroupID() {
		return incentiveOptionGroupID;
	}

	public void setIncentiveOptionGroupID(Integer incentiveOptionGroupID) {
		this.incentiveOptionGroupID = incentiveOptionGroupID;
	}

	public Integer getIncentiveOptionRequirementID() {
		return incentiveOptionRequirementID;
	}

	public void setIncentiveOptionRequirementID(Integer incentiveOptionRequirementID) {
		this.incentiveOptionRequirementID = incentiveOptionRequirementID;
	}

	public String getBenefitContractType() {
		return benefitContractType;
	}

	public void setBenefitContractType(String benefitContractType) {
		this.benefitContractType = benefitContractType;
	}

	public final Integer getCollectionID() {
		return collectionID;
	}

	public final void setCollectionID(Integer collectionID) {
		this.collectionID = collectionID;
	}

	public Integer getParticipantCap() {
		return participantCap;
	}

	public void setParticipantCap(Integer participantCap) {
		this.participantCap = participantCap;
	}

	public Integer getFamilyCap() {
		return familyCap;
	}

	public void setFamilyCap(Integer familyCap) {
		this.familyCap = familyCap;
	}

	public final Integer getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}

	public final void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}

	public final String getActivationStatusCode() {
		return activationStatusCode;
	}

	public final void setActivationStatusCode(String activationStatusCode) {
		this.activationStatusCode = activationStatusCode;
	}
	
	
	
}

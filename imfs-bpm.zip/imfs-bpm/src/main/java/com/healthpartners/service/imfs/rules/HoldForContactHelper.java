package com.healthpartners.service.imfs.rules;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import com.healthpartners.service.imfs.dto.MemberTO;


import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.GenericStatusType;
import com.healthpartners.service.imfs.dto.LookUpValueCode;
import com.healthpartners.service.imfs.dto.MemberActivity;
import com.healthpartners.service.imfs.dto.MemberTO;
import com.healthpartners.service.imfs.dto.Risk;
import com.healthpartners.service.imfs.dto.TaskEvent;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * Helper class to return hold for contact status on member is true or false
 * 
 * 1. false - if any program activity started/completed
 * 
 * 2. true - if health assesment(HA) not completed and hold from any task group
 * (ie task started, not completed, active days < 35 time out period)
 * 
 * 3. false - if health assesment not completed and not hold from any task group
 * 
 * if HA completed with Risk groups HBG,BHIO...(generic RISK can now be
 * ignored), for each group - 1. false - if group task completed 2. false - if
 * group task period timed out ( active, not completed in 35 days) 3. true - if
 * group task not started and HA risk(Health assesment date) not timed out(today <
 * 7 days from HA date) 4. true - if group task started and task period not
 * timed out(active date + 35 < today)
 * 
 * if HA completed with Generic RISK, and group risk type is not recieved 1.
 * true - if hold from any one of the task groups 2. false - if not hold from
 * any one of task, atlest 1 task started 3. true - if not hold from any one of
 * task, atlest 1 task not started, HA not timed out(today < 7 days from HA
 * date)
 * 
 * @author mxthoutam
 * 
 */
public class HoldForContactHelper {

	private MemberTO member;

	private Calendar currentDateTime;

	protected final Log logger = LogFactory.getLog(getClass());

	SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");

	// add up more task/risk groups here
	// private String[] riskGroupIds = { BPMConstants.TASK_ID_HA_FOLLOWUP_HBG,
	// BPMConstants.TASK_ID_HA_FOLLOWUP_BHIO };

	// risk groups - all from LUV
	private ArrayList<LookUpValueCode> riskGroupCodes;

	//risk groups - all from LUV exclude - UNKNOWN
	private ArrayList<LookUpValueCode> knownRiskGroupCodes;

	//Risk types
	ArrayList<Risk> risks;

	/**
	 * Constructor to populate properties
	 * @param member
	 * @param currentDateTime
	 * @param pRiskGroupCodes
	 * @param pRisks
	 */
	public HoldForContactHelper(MemberTO member, Calendar currentDateTime,
			ArrayList<LookUpValueCode> pRiskGroupCodes, ArrayList<Risk> pRisks) {
		super();
		this.member = member;
		this.currentDateTime = currentDateTime;
		this.riskGroupCodes = pRiskGroupCodes;
		this.knownRiskGroupCodes = getKnownRiskGroupCodes(riskGroupCodes);
		this.risks = pRisks;
	}

	/**
	 * decide, wether the memmber status is Hold for contact?
	 * refer class level documentation for further calculation details
	 * @param program
	 * @param programActivityStarted
	 * @param programActivityCompleted
	 * @param healthAssesmentCompleted
	 * @return boolean
	 */
	public boolean isHoldForContact(BusinessProgramAdapter program,
			boolean programActivityStarted, boolean programActivityCompleted,
			boolean healthAssesmentCompleted
			, boolean programQualificationPeriodEnded) {
		boolean result = false;

		if (programActivityStarted || programActivityCompleted || programQualificationPeriodEnded) {
			// BR 8.1.2
			//Rule: do not hold, if program Activity Started or completed, or past the qualification period
			result = false;
		} else {
			//Calculate hold status from task history and Health Assessment
			result = caluculateHoldFromHAandTasks(program,
					healthAssesmentCompleted);
		}

		//logger.info("@isHoldForContact = " + result + " for programID "
		//		+ program.getBusinessProgramId());
		return result;
	}

	/**
	 * get all risk groups excluding UNKNOWN riskGroup
	 * @param riskGroupCodes
	 * @return
	 */
	private ArrayList<LookUpValueCode> getKnownRiskGroupCodes(
			ArrayList<LookUpValueCode> riskGroupCodes) {
		ArrayList<LookUpValueCode> knownRiskGroupcodes = new ArrayList<LookUpValueCode>();

		if (riskGroupCodes != null && riskGroupCodes.size() > 0) {

			Iterator<LookUpValueCode> itr = riskGroupCodes.iterator();
			while (itr.hasNext()) {
				LookUpValueCode code = itr.next();
				if (!BPMConstants.RISK_GROUP_UNKNOWN.equals(code.getLuvVal())) {
					knownRiskGroupcodes.add(code);
				}
			}
		}

		return knownRiskGroupcodes;
	}

	/**
	 * Calculate hold status from task history and Health Assessment
	 * @param program
	 * @param healthAssesmentCompleted
	 * @return
	 */
	private boolean caluculateHoldFromHAandTasks(
			BusinessProgramAdapter program, boolean healthAssesmentCompleted) {
		boolean result = false;

		TaskRiskTO taskRiskTO = generateTaskRiskTO(program);

		if (isHoldFromTasks(taskRiskTO)) {
			//Rule: hold if tasks say
			result = true;
			//Fix for #99 - removed checking !healthAssesmentCompleted
			//always from task is priority  to hold
		} else if(healthAssesmentCompleted){
			//health assessment completed and tasks don't hold
			HARiskTO haRiskTO = generateHARiskTO(program);
			if (isHoldFromHAOutcomeType(haRiskTO, taskRiskTO)) {
				//hold if, HA is not timed out and no tasks for that group
				result = true;
			}
		}
		
		return result;
	}

	/**
	 * calculate hold status from task history 
	 * @param taskRiskTO
	 * @return boolean
	 */
	private boolean isHoldFromTasks(TaskRiskTO taskRiskTO) {
		boolean result = false;
		if (taskRiskTO != null && taskRiskTO.getTaskPairs() != null) {
			//loop throgh each known risk group
			for (int i = 0; i < knownRiskGroupCodes.size(); i++) {
				LookUpValueCode lLookUpValueCode = (LookUpValueCode) knownRiskGroupCodes
						.get(i);
				//fetch TaskPair (s) for this risk group
				List<TaskPair> taskPairsForGroup = taskRiskTO
						.getTaskPairsForGroup(lLookUpValueCode.getLuvVal());
				//decide hold status for this risk group from tasks
				result = isHoldFromTasksForGroup(taskPairsForGroup,
						lLookUpValueCode.getLuvVal());
				if (result) {
					// if hold from 1 task, no further check
					break;
				}
			}
		}

		return result;
	}

	/**
	 * decide hold status for the risk group from tasks
	 * @param taskPairsForGroup
	 * @param taskGroupId
	 * @return
	 */
	private boolean isHoldFromTasksForGroup(List<TaskPair> taskPairsForGroup,
			String taskGroupId) {
		boolean result = false;

		int activeTaskTimeOutDays = 0;

		/*
		 * if (BPMConstants.TASK_ID_HA_FOLLOWUP_HBG.equals(taskGroupId)) {
		 * activeTaskTimeOutDays = BPMConstants.TASK_TIME_OUT_DAYS_HBG; } else
		 * if (BPMConstants.TASK_ID_HA_FOLLOWUP_BHIO.equals(taskGroupId)) {
		 * activeTaskTimeOutDays = BPMConstants.TASK_TIME_OUT_DAYS_BHIO; }
		 */

		//find task time out days for this risk group 
		for (int i = 0; i < risks.size(); i++) {
			Risk lRisk = (Risk) risks.get(i);
			if (taskGroupId.equalsIgnoreCase(lRisk.getRiskGroupCodeVal())) {
				activeTaskTimeOutDays = lRisk.getRiskHoldDuration();
				break;
			}
		}

		if (taskPairsForGroup == null || taskPairsForGroup.size() < 1) {
			// No tasks, no hold
			result = false;
		} else {
			Iterator<TaskPair> itrPairs = taskPairsForGroup.iterator();
			while (itrPairs.hasNext()) {
				TaskPair pair = itrPairs.next();
				if (pair.getCompletionDate() != null) {
					// completed
					result = false;
					// once complete, no more holds from this group
					break;
				} else if (pair.getActiveDays() > activeTaskTimeOutDays) {
					// timed out = completed
					result = false;
					// once timed out - no more holds from this group
					break;
				} else if (pair.getActiveDays() <= activeTaskTimeOutDays) {
					// not timed out - hold
					result = true;
				}
			}
		}

		// logger.info("@isHoldFromTasksForGroup() for " + taskGroupId + " ="+
		// result);
		return result;
	}

	/**
	 * Calculate hold from HA outcome type
	 * @param haRiskTO
	 * @param taskRiskTO
	 * @return
	 */
	private boolean isHoldFromHAOutcomeType(HARiskTO haRiskTO,
			TaskRiskTO taskRiskTO) {
		boolean result = false;
		// logger.info("@called isHoldFromHAActivity() ");

		//loop throgh each known risk group
		for (int i = 0; i < knownRiskGroupCodes.size(); i++) {
			LookUpValueCode lLookUpValueCode = (LookUpValueCode) knownRiskGroupCodes
					.get(i);
			// calculate for hold on this risk group
			result = isHoldFromHARiskGroup(haRiskTO, taskRiskTO,
					lLookUpValueCode.getLuvVal());
			if (result) {
				// if hold from 1 risk, no further check
				break;
			}
		}

		if (!result && hasHARiskGroupUnknown(haRiskTO)) {
			// general risk received , no risk type came
			result = isHoldFromHARiskGroupUnknown(haRiskTO, taskRiskTO);
		}

		logger.info("@ isHoldFromHAActivity() =" + result);
		return result;
	}

	/**
	 * calculate for hold status on the given risk group from HA outcome type.
	 * @param haRiskTO
	 * @param taskRiskTO
	 * @param riskGroupId
	 * @return
	 */
	private boolean isHoldFromHARiskGroup(HARiskTO haRiskTO,
			TaskRiskTO taskRiskTO, String riskGroupId) {
		boolean result = false;
		//wether member has the HA risk, for the given group
		if (!hasHARiskForGroup(haRiskTO, riskGroupId)) {
			//No risk for this group
			result = false;
		} else {
		//member has HA rsik for this group, so calculate further
			
			// find any task completed, for this risk group 
			boolean taskCompleted = isTaskCompleted(taskRiskTO, riskGroupId);
			
			// find any started task has timed out, for this risk group 
			boolean taskPeriodTimedOut = isStartedTaskPeriodTimedOut(
					taskRiskTO, riskGroupId);
			
			// find any task started, for this risk group 
			boolean taskStarted = isTaskStarted(taskRiskTO, riskGroupId);
			
			// find any HA timed out with no tasks, for this risk group 
			boolean haRiskWithoutTasksTimedOut = isHARiskWithoutTasksTimedOut(
					haRiskTO, riskGroupId);

			if (taskCompleted) {
				//Rule: task completed - do not hold
				result = false;
			} else if (taskPeriodTimedOut) {
				//Rule: task timed out - do not hold
				result = false;
			} else if (!taskStarted && !haRiskWithoutTasksTimedOut) {
				//Rule: no tasks for this group and HA not timed out - hold
				result = true;
			} else if (taskStarted && !taskPeriodTimedOut) {
				//Rule: task started but not completed for this group and task period  not timed out - hold
				result = true;
			}
		}

		return result;
	}

	/**
	 * calculate hold status for general risk received, no risk type arrived
	 * @param haRiskTO
	 * @param taskRiskTO
	 * @return
	 */
	private boolean isHoldFromHARiskGroupUnknown(HARiskTO haRiskTO,
			TaskRiskTO taskRiskTO) {
		boolean result = false;
		boolean taskStarted = false;
		boolean haRiskWithoutTasksTimedOut = false;
		if (isHoldFromTasks(taskRiskTO)) {
			result = true;
		} else {
			// check to see if atleast 1 known task started
			for (int i = 0; i < knownRiskGroupCodes.size(); i++) {
				LookUpValueCode lLookUpValueCode = (LookUpValueCode) knownRiskGroupCodes
						.get(i);
				taskStarted = isTaskStarted(taskRiskTO, lLookUpValueCode
						.getLuvVal());
				if (taskStarted) {
					// atleast 1 started , safe - might have completed/timed out
					break;
				}
			}
			haRiskWithoutTasksTimedOut = isHARiskWithoutTasksTimedOut(haRiskTO,
					BPMConstants.RISK_GROUP_UNKNOWN);
			if (!taskStarted && !haRiskWithoutTasksTimedOut) {
				// no task, and ha not timed out
				result = true;
			}
		}

		return result;
	}

	/**
	 * find any task completed, for given risk group 
	 * @param taskRiskTO
	 * @param taskGroupId
	 * @return boolean
	 */
	private boolean isTaskCompleted(TaskRiskTO taskRiskTO, String taskGroupId) {
		boolean result = false;

		List<TaskPair> taskPairs = taskRiskTO.getTaskPairsForGroup(taskGroupId);

		if (taskPairs == null || taskPairs.size() < 1) {
			// No task start/end
			result = false;
		} else {
			Iterator<TaskPair> itrPairs = taskPairs.iterator();
			while (itrPairs.hasNext()) {
				TaskPair pair = itrPairs.next();
				Calendar taskCompletionDate = pair.getCompletionDate();
				if (taskCompletionDate != null) {
					// task completed
					result = true;
				}
			}
		}

		// logger.info("@isTaskCompleted() for " + taskGroupId + " = " +
		// result);
		return result;
	}

	/**
	 * find any task started, for this risk group 
	 * @param taskRiskTO
	 * @param taskGroupId
	 * @return
	 */
	private boolean isTaskStarted(TaskRiskTO taskRiskTO, String taskGroupId) {
		boolean result = false;

		List<TaskPair> taskPairs = taskRiskTO.getTaskPairsForGroup(taskGroupId);

		if (taskPairs == null || taskPairs.size() < 1) {
			// No task start
			result = false;
		} else {
			Iterator<TaskPair> itrPairs = taskPairs.iterator();
			while (itrPairs.hasNext()) {
				TaskPair pair = itrPairs.next();
				Calendar taskStartDate = pair.getStartDate();
				Calendar taskCompletionDate = pair.getCompletionDate();
				if (taskStartDate != null || taskCompletionDate != null) {
					// task strated
					result = true;
				}
			}
		}

		// logger.info("@isTaskStarted() for " + taskGroupId + " = " + result);
		return result;
	}

	/**
	 * find any started task has timed out, for given risk group 
	 * @param taskRiskTO
	 * @param taskGroupId
	 * @return
	 */
	private boolean isStartedTaskPeriodTimedOut(TaskRiskTO taskRiskTO,
			String taskGroupId) {
		boolean result = false;

		List<TaskPair> taskPairs = taskRiskTO.getTaskPairsForGroup(taskGroupId);

		int activeTaskTimeOutDays = 0;

		/*
		 * if (BPMConstants.TASK_ID_HA_FOLLOWUP_HBG.endsWith(taskGroupId)) {
		 * activeTaskTimeOutDays = BPMConstants.TASK_TIME_OUT_DAYS_HBG; } else
		 * if (BPMConstants.TASK_ID_HA_FOLLOWUP_BHIO.endsWith(taskGroupId)) {
		 * activeTaskTimeOutDays = BPMConstants.TASK_TIME_OUT_DAYS_BHIO; }
		 */

		//fetch time out days for this risk group
		for (int i = 0; i < risks.size(); i++) {
			Risk lRisk = (Risk) risks.get(i);
			if (taskGroupId.equalsIgnoreCase(lRisk.getRiskGroupCodeVal())) {
				activeTaskTimeOutDays = lRisk.getRiskHoldDuration();
				break;
			}
		}

		if (taskPairs == null || taskPairs.size() < 1) {
			// No task start/end
			result = false;
		} else {
			Iterator<TaskPair> itrPairs = taskPairs.iterator();
			while (itrPairs.hasNext()) {
				TaskPair pair = itrPairs.next();
				int gapDays = pair.getActiveDays();
				if (gapDays > activeTaskTimeOutDays) {
					//timed out
					result = true;
				}
			}
		}

		// logger.info("@isTaskTimedOut() for " + taskGroupId + " = " + result);
		return result;
	}

	/**
	 * find any HA timed out with no tasks, for this risk group 
	 * @param haRiskTO
	 * @param riskGroupId
	 * @return
	 */
	public boolean isHARiskWithoutTasksTimedOut(HARiskTO haRiskTO,
			String riskGroupId) {
		boolean result = false;
		Calendar today = getCurrentDateTime();
		int riskTimeOutDaysWithoutTasks = 0;

		//fing time out days for this risk group
		for (int i = 0; i < risks.size(); i++) {
			Risk lRisk = (Risk) risks.get(i);
			if (BPMConstants.RISK_GROUP_UNKNOWN.equalsIgnoreCase(lRisk
					.getRiskGroupCodeVal())) {
				riskTimeOutDaysWithoutTasks = lRisk.getRiskHoldDuration();
				break;
			}
		}

		//fetch HA outcome group
		HARiskOutcomeGroup riskOutcomeGroup = haRiskTO
				.getHARiskOutcomeGroup(riskGroupId);

		int daysPassed = BPMUtils.getDaysBetweenDates(today, riskOutcomeGroup
				.getActivityDate());
		logger.info("@riskTimeOutDaysWithoutTasks for " + riskGroupId
				+ " HA Active days=" + daysPassed + ", timeOutDays="
				+ riskTimeOutDaysWithoutTasks);
		if (daysPassed > riskTimeOutDaysWithoutTasks) {
			//timed out
			result = true;
		}
		return result;
	}

	/**
	 * wether member has unknown HA risk type
	 * @param haRiskTO
	 * @return boolean
	 */
	public boolean hasHARiskGroupUnknown(HARiskTO haRiskTO) {
		boolean result = false;

		// if has generic risk date
		if (hasHARiskForGroup(haRiskTO, BPMConstants.RISK_GROUP_UNKNOWN)) {
			result = true;
			if (hasHARiskForAnyKnownRiskGroup(haRiskTO)) {
				// if it has any risk group - false for generic risk
				result = false;
			}
		}

		return result;
	}

	/**
	 * wether member has the HA risk, for the given group
	 * @param haRiskTO
	 * @param riskGroupId
	 * @return boolean
	 */
	public boolean hasHARiskForGroup(HARiskTO haRiskTO, String riskGroupId) {
		return (haRiskTO.getHARiskOutcomeGroup(riskGroupId) != null);
	}

	/**
	 * wether member has any known HA risk type
	 * @param haRiskTO
	 * @return boolean
	 */
	public boolean hasHARiskForAnyKnownRiskGroup(HARiskTO haRiskTO) {
		boolean result = false;
		for (int i = 0; i < knownRiskGroupCodes.size(); i++) {
			LookUpValueCode lLookUpValueCode = (LookUpValueCode) knownRiskGroupCodes
					.get(i);
			if (hasHARiskForGroup(haRiskTO, lLookUpValueCode.getLuvVal())) {
				result = true;
				break;
			}
		}
		return result;
	}

	/**
	 * generate HARiskTO for the member and the program
	 * @param program
	 * @return
	 */
	private HARiskTO generateHARiskTO(BusinessProgramAdapter program) {
		// Calendar hARiskHBGDate = null;
		// Calendar hARiskBHIODate = null;
		// Calendar hARiskGeneralDate = null;
		HARiskTO hARiskTO = new HARiskTO();

		ArrayList<HARiskOutcomeGroup> haRiskOutComeGroups = new ArrayList<HARiskOutcomeGroup>();

		// Health assesment Activity out come high risk
		//fetch all Health assesment Activities
		Collection<MemberActivity> haActivities = member
				.getHealthAssesmentMemberActivities(program
						.getBusinessProgramId(), program.getBusinessProgram().isEvaluateTermedContract());
		
		if (haActivities != null && haActivities.size() > 0) {
			Iterator<MemberActivity> iter = haActivities.iterator();
			//loop through each HA activity
			while (iter.hasNext()) {
				MemberActivity activity = iter.next();
				String activityName = activity.getActivity().getName();
				
				//fetch this HA activity history
				GenericStatusType[] statusHistory = activity.getStatusHistory();
				// NOTE: history assumed to be within qual year and ordered in
				// sql query
				if (statusHistory != null) {
					//loop through HA activity history
					for (int i = 0; i < statusHistory.length; i++) {
						String statusValue = statusHistory[i]
								.getStatusCodeValue();
						//if activity status is completed/panding
						if (isActivityCompleted(activityName, statusValue)) {
							String outComeValue = statusHistory[i].getOutCome();
							Calendar activityDate = statusHistory[i]
									.getStatusEffectiveDate();
							// check for outcome type wrt to risks
							//loop throgh all risks
							for (int j = 0; j < risks.size(); j++) {
								Risk lRisk = (Risk) risks.get(j);
								if (outComeValue != null
										&& outComeValue.equalsIgnoreCase(lRisk
												.getRiskName())) {
									//HA outcome type is of this risk type
									HARiskOutcomeGroup riskOutcomeGroup = new HARiskOutcomeGroup();
									riskOutcomeGroup
											.setActivityDate(activityDate);
									riskOutcomeGroup.setRiskGroup(lRisk
											.getRiskGroupCodeVal());
									//add the HA risk group 
									haRiskOutComeGroups.add(riskOutcomeGroup);
									break;
								}
							}

							/*
							 * if (outComeValue != null &&
							 * BPMConstants.ACTIVITY_STATUS_OUTCOME_GENERIC_RISK
							 * .equals(outComeValue)) { hARiskGeneralDate =
							 * activityDate; } else if (outComeValue != null &&
							 * BPMConstants.ACTIVITY_STATUS_OUTCOME_HIGH_RISK_CAD
							 * .equals(outComeValue) ||
							 * BPMConstants.ACTIVITY_STATUS_OUTCOME_HIGH_RISK_DIABETES
							 * .equals(outComeValue)) { hARiskHBGDate =
							 * activityDate; } else if (outComeValue != null &&
							 * BPMConstants.ACTIVITY_STATUS_OUTCOME_HIGH_RISK_DEPRESS
							 * .equals(outComeValue) ||
							 * BPMConstants.ACTIVITY_STATUS_OUTCOME_HIGH_RISK_ALCOHOL
							 * .equals(outComeValue)) { hARiskBHIODate =
							 * activityDate; }
							 */
						}
					}
				} // status history
			} // if any HA activities
		}

		// prepare HARiskTO
		/*
		 * if (hARiskGeneralDate != null) {
		 * hARiskTO.setHARiskGeneralDate(hARiskGeneralDate); }
		 * 
		 * if (hARiskHBGDate != null) { HARiskOutcomeGroup riskOutcomeGroup =
		 * new HARiskOutcomeGroup();
		 * riskOutcomeGroup.setActivityDate(hARiskHBGDate);
		 * riskOutcomeGroup.setRiskGroup(BPMConstants.TASK_ID_HA_FOLLOWUP_HBG);
		 * haRiskOutComeGroups.add(riskOutcomeGroup); }
		 * 
		 * if (hARiskBHIODate != null) { HARiskOutcomeGroup riskOutcomeGroup =
		 * new HARiskOutcomeGroup();
		 * riskOutcomeGroup.setActivityDate(hARiskBHIODate); riskOutcomeGroup
		 * .setRiskGroup(BPMConstants.TASK_ID_HA_FOLLOWUP_BHIO);
		 * haRiskOutComeGroups.add(riskOutcomeGroup); }
		 */

		//set all HA risk groups
		hARiskTO.setHaRiskOutcomeGroups(haRiskOutComeGroups);

		return hARiskTO;
	}

	/**
	 * generates TaskRiskTO for the member and program
	 * @param program
	 * @return
	 */
	private TaskRiskTO generateTaskRiskTO(BusinessProgramAdapter program) {

		List<TaskPair> allTaskPairs = new ArrayList<TaskPair>();

		TaskRiskTO taskRiskTO = new TaskRiskTO();

		Integer businessProgramID = program.getBusinessProgramId();

		//loop through all risk groups
		for (int i = 0; i < knownRiskGroupCodes.size(); i++) {
			LookUpValueCode lLookUpValueCode = (LookUpValueCode) knownRiskGroupCodes
					.get(i);
			//generate List<TaskPair> for this risk group
			List<TaskPair> taskPairs = generateTaskPairsForSingleGroup(
					businessProgramID, lLookUpValueCode.getLuvVal());
			//add
			allTaskPairs.addAll(taskPairs);
		}

		taskRiskTO.setTaskPairs(allTaskPairs);

		return taskRiskTO;
	}

	/**
	 * generates List<TaskPair> from the task history for the member
	 */
	private List<TaskPair> generateTaskPairsForSingleGroup(
			Integer businessProgramID, String taskGroupId) {
		Collection<TaskEvent> tasks = null;
		List<TaskPair> taskPairs = new ArrayList<TaskPair>();

		//fetch member tasks
		tasks = member.getMemberTasksForGroupId(businessProgramID, taskGroupId);

		if (tasks != null && tasks.size() > 0) {
			boolean taskStarted = false;
			boolean taskCompleted = false;
			Calendar startDate = null;
			Calendar endDate = null;
			Iterator<TaskEvent> iter = tasks.iterator();
			//llop throgh each task
			while (iter.hasNext()) {
				TaskEvent task = iter.next();
				String taskStatus = task.getTaskStatus().getStatusCodeValue();
				Calendar taskDate = task.getTaskStatus()
						.getStatusEffectiveDate();
				if (BPMConstants.TASK_STATUS_ACTIVE.equals(taskStatus)) {
					// started
					if (!taskStarted) {
						startDate = taskDate;
						taskStarted = true;
					}
				} else if (BPMConstants.TASK_STATUS_COMPLETE.equals(taskStatus)
						|| BPMConstants.TASK_STATUS_INACTIVE.equals(taskStatus)
						|| BPMConstants.TASK_STATUS_CANCELED.equals(taskStatus)
						|| BPMConstants.TASK_STATUS_WAIVE.equals(taskStatus)
						) {
					// YES completed, DELETE is not considered for contacted
					if (!taskCompleted) {
						endDate = taskDate;
						taskCompleted = true;
					}
				} else if (BPMConstants.TASK_STATUS_DELETE.equals(taskStatus)) {
					// delete ie don't consider previous history
					taskStarted = false;
					taskCompleted = false;
					startDate = null;
					endDate = null;
				}

				// create one pair - if any completed
				if (taskCompleted) {
					TaskPair taskPair = new TaskPair();
					taskPair.setRiskGroup(taskGroupId);
					if (!taskStarted) {
						// may be started - assume it same as completion
						// date
						// force startDate as QualificationWindowStartDate
						startDate = endDate;
						taskStarted = true;
					}
					taskPair.setStartDate(startDate);
					taskPair.setCompletionDate(endDate);
					// ADD one pair
					taskPairs.add(taskPair);
					// make room for another pair
					taskStarted = false;
					taskCompleted = false;
					startDate = null;
					endDate = null;
				}
			} // end while loop

			// create one pair - if NO completions
			if (taskStarted && !taskCompleted) {
				TaskPair taskPair = new TaskPair();
				taskPair.setRiskGroup(taskGroupId);
				taskPair.setStartDate(startDate);

				// No end Date
				// ADD one pair
				taskPairs.add(taskPair);
			}
		}// end if any tasks

		return taskPairs;
	}

	/**
	 * decide on activity completed
	 * @param activityName
	 * @param activityStatus
	 * @return
	 */
	private boolean isActivityCompleted(String activityName,
			String activityStatus) {
		boolean result = false;

		// Is the activity status "Complete"?
		if (BPMConstants.ACTIVITY_STATUS_COMPLETE.equals(activityStatus)) {
			result = true;
		} else if (BPMConstants.ACTIVITY_HEALTHY_BENEFITS_HA
				.equals(activityName)
				&& BPMConstants.ACTIVITY_STATUS_PENDING.equals(activityStatus)) {
			result = true;
		}
		// logger.info("@isActivityCompleted=" + result);
		return result;
	}

	public Calendar getCurrentDateTime() {
		return currentDateTime;
	}

	public void setCurrentDateTime(Calendar currentDateTime) {
		this.currentDateTime = currentDateTime;
	}

	public MemberTO getMember() {
		return member;
	}

	public void setMember(MemberTO member) {
		this.member = member;
	}

	/**
	 * 
	 * Inner class to hold HA Risks(riskTimeoutDays, List<HARiskOutcomeGroup>)
	 * 
	 * @author mxthoutam
	 *
	 */
	private class HARiskTO {

		// private Calendar hARiskGeneralDate = null;
		private int riskTimeoutDays = 0;

		private List<HARiskOutcomeGroup> haRiskOutcomeGroups = null;

		public List<HARiskOutcomeGroup> getHaRiskOutcomeGroups() {
			return haRiskOutcomeGroups;
		}

		public void setHaRiskOutcomeGroups(
				List<HARiskOutcomeGroup> haRiskOutcomeGroups) {
			this.haRiskOutcomeGroups = haRiskOutcomeGroups;
		}

		public HARiskOutcomeGroup getHARiskOutcomeGroup(String riskGroupId) {
			HARiskOutcomeGroup hARiskOutcomeGroup = null;
			if (riskGroupId != null && haRiskOutcomeGroups != null
					&& haRiskOutcomeGroups.size() > 0) {
				Iterator<HARiskOutcomeGroup> itr = haRiskOutcomeGroups
						.iterator();
				while (itr.hasNext()) {
					HARiskOutcomeGroup riskOutcomeGroup = itr.next();
					if (riskGroupId.equals(riskOutcomeGroup.getRiskGroup())) {
						hARiskOutcomeGroup = riskOutcomeGroup;
					}
				}
			}
			return hARiskOutcomeGroup;
		}

		public void setRiskTimeoutDays(int pRiskTimeoutDays) {
			riskTimeoutDays = pRiskTimeoutDays;
		}

		public int getRiskTimeoutDays() {
			return riskTimeoutDays;
		}
	}

	/**
	 * Inner class to hold HA Risk Outcome Group (riskGroup, activityDate)
	 * 
	 * @author mxthoutam
	 *
	 */
	private class HARiskOutcomeGroup {

		private String riskGroup;

		private Calendar activityDate;

		public Calendar getActivityDate() {
			return activityDate;
		}

		public void setActivityDate(Calendar activityDate) {
			this.activityDate = activityDate;
		}

		public String getRiskGroup() {
			return riskGroup;
		}

		public void setRiskGroup(String riskGroup) {
			this.riskGroup = riskGroup;
		}
	}

	private class TaskRiskTO {
		List<TaskPair> taskPairs = null;

		public List<TaskPair> getTaskPairs() {
			return taskPairs;
		}

		public void setTaskPairs(List<TaskPair> taskPairs) {
			this.taskPairs = taskPairs;
		}

		/**
		 * fetch TaskPair (s) for the passed risk group
		 */
		public List<TaskPair> getTaskPairsForGroup(String taskGroupId) {
			List<TaskPair> taskPairsForGroup = new ArrayList<TaskPair>();
			if (taskGroupId != null && taskPairs != null
					&& taskPairs.size() > 0) {
				Iterator<TaskPair> itr = taskPairs.iterator();
				while (itr.hasNext()) {
					TaskPair taskPair = itr.next();
					if (taskGroupId.equals(taskPair.getRiskGroup())) {
						taskPairsForGroup.add(taskPair);
					}
				}
			}
			return taskPairsForGroup;
		}
	}

	/**
	 * Inner class to hold TaskPair (riskGroup, startDate, completionDate)
	 * comparable by startDate
	 * @author mxthoutam
	 *
	 */
	private class TaskPair implements Comparable<TaskPair> {

		private String riskGroup;

		private Calendar startDate;

		private Calendar completionDate;

		// default to some higher number than
		// BPMConstants.TASK_TIME_OUT_DAYS_HBG,BPMConstants.TASK_TIME_OUT_DAYS_BHIO
		private int activeDays = 999999999;

		public Calendar getCompletionDate() {
			return completionDate;
		}

		public void setCompletionDate(Calendar completionDate) {
			this.completionDate = completionDate;
		}

		public Calendar getStartDate() {
			return startDate;
		}

		public void setStartDate(Calendar startDate) {
			this.startDate = startDate;
		}

		public int getActiveDays() {
			// add gap days from now
			if (completionDate == null && startDate != null) {
				Calendar today = getCurrentDateTime();
				activeDays = BPMUtils.getDaysBetweenDates(today, startDate);
			}
			return activeDays;
		}

		public void setActiveDays(int activeDays) {
			this.activeDays = activeDays;
		}

		public String getRiskGroup() {
			return riskGroup;
		}

		public void setRiskGroup(String riskGroup) {
			this.riskGroup = riskGroup;
		}

		public int compareTo(TaskPair o) {
			
            // Set the times to 0, so that only the dates are compared.
			BPMUtils.setTimeToZero(getStartDate());			
			BPMUtils.setTimeToZero(o.getStartDate());						
			
			// sort by start date
			if (startDate == null || o.getStartDate() == null) {
				return 0;
			} else {
				return startDate.compareTo(o.getStartDate());
			}
		}
	}

	public ArrayList<LookUpValueCode> getRiskGroupCodes() {
		return riskGroupCodes;
	}

	public void setRiskGroupCodes(ArrayList<LookUpValueCode> riskGroupCodes) {
		this.riskGroupCodes = riskGroupCodes;
	}

	public ArrayList<LookUpValueCode> getKnownRiskGroupCodes() {
		return knownRiskGroupCodes;
	}

	public void setKnownRiskGroupCodes(
			ArrayList<LookUpValueCode> knownRiskGroupCodes) {
		this.knownRiskGroupCodes = knownRiskGroupCodes;
	}

}

package com.healthpartners.service.imfs.dto;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * This class represents the internal BPM package Data Transfer Object.
 * It is not exposed to web services for example.
 * 
 * Represents a record in the pgm_mem_incntv_status table. 
 * 
 * @author jxbourbour
 */
public class MemberProgramIncentiveTO extends BaseDTO
{
	static final long serialVersionUID = 0L;
	
	private Integer memberProgramIncentiveID;
	private Integer businessProgramID;
	private Integer incentiveOptionID;
	private Integer contractNo;
	private Integer personDemographicsID;
	private Integer qualificationCheckmarkID;
	private String  memberIncentiveStatusCode;
	private Date    memberIncentiveStatusDate; 
	private Integer benefitPackageID;
	private Date    coverageEffectiveDate;
	private Integer programIncentiveOptionID;
	private String  activationStatusCode;
	private String  activationStatusCodeID;
	private List<IncentiveStatusActivityDetail> incentiveStatusActivityDetails = new ArrayList<IncentiveStatusActivityDetail>();
	
	
	
	public MemberProgramIncentiveTO()
	{
		super();
	}

	
	


	public final Integer getMemberProgramIncentiveID() {
		return memberProgramIncentiveID;
	}





	public final void setMemberProgramIncentiveID(Integer memberProgramIncentiveID) {
		this.memberProgramIncentiveID = memberProgramIncentiveID;
	}





	public Integer getBusinessProgramID() {
		return businessProgramID;
	}

	public void setBusinessProgramID(Integer businessProgramID) {
		this.businessProgramID = businessProgramID;
	}

	public Integer getIncentiveOptionID() {
		return incentiveOptionID;
	}

	public void setIncentiveOptionID(Integer incentiveOptionID) {
		this.incentiveOptionID = incentiveOptionID;
	}

	public Integer getContractNo() {
		return contractNo;
	}

	public void setContractNo(Integer contractNo) {
		this.contractNo = contractNo;
	}

	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}

	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}

	public String getMemberIncentiveStatusCode() {
		return memberIncentiveStatusCode;
	}

	public void setMemberIncentiveStatusCode(String memberIncentiveStatusCode) {
		this.memberIncentiveStatusCode = memberIncentiveStatusCode;
	}

	
	public Date getMemberIncentiveStatusDate() {
		return memberIncentiveStatusDate;
	}

	public void setMemberIncentiveStatusDate(Date memberIncentiveStatusDate) {
		this.memberIncentiveStatusDate = memberIncentiveStatusDate;
	}

	public Integer getQualificationCheckmarkID() {
		return qualificationCheckmarkID;
	}

	public void setQualificationCheckmarkID(Integer qualificationCheckmarkID) {
		this.qualificationCheckmarkID = qualificationCheckmarkID;
	}

	public Integer getBenefitPackageID() {
		return benefitPackageID;
	}

	public void setBenefitPackageID(Integer benefitPackageID) {
		this.benefitPackageID = benefitPackageID;
	}

	public Date getCoverageEffectiveDate() {
		return coverageEffectiveDate;
	}

	public void setCoverageEffectiveDate(Date coverageEffectiveDate) {
		this.coverageEffectiveDate = coverageEffectiveDate;
	}

	public Integer getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}

	public void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}


	public List<IncentiveStatusActivityDetail> getIncentiveStatusActivityDetails() {
		return incentiveStatusActivityDetails;
	}


	public void setIncentiveStatusActivityDetails(
			List<IncentiveStatusActivityDetail> incentiveStatusActivityDetails) {
		this.incentiveStatusActivityDetails = incentiveStatusActivityDetails;
	}


	public final String getActivationStatusCode() {
		return activationStatusCode;
	}


	public final void setActivationStatusCode(String activationStatusCode) {
		this.activationStatusCode = activationStatusCode;
	}


	public final String getActivationStatusCodeID() {
		return activationStatusCodeID;
	}


	public final void setActivationStatusCodeID(String activationStatusCodeID) {
		this.activationStatusCodeID = activationStatusCodeID;
	}


		
	
		
}

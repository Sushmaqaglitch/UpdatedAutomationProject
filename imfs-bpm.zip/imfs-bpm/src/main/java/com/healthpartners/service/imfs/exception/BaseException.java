/* $Id$ */

package com.healthpartners.service.imfs.exception;

/**
 * A base checked exception for the PES application.
 * 
 * @author pbhenninger
 */
public class BaseException extends java.lang.Exception {

	private static final long serialVersionUID = 0L;

	public BaseException() {
		super();
	}
	
	public BaseException(String message) {
		super(message);
	}

	public BaseException(String message, Throwable cause) {
		super(message, cause);
	}
	
	public BaseException(Throwable cause) {
		super(cause);
	}
}
package com.healthpartners.service.imfs.exception;

/**
 * @author tjquist
 * 
 */
public class BPMParserException extends Exception {

	private static final long serialVersionUID = 1234567899L;

	private String message;

	public BPMParserException() {
		super();
	}

	public BPMParserException(String message) {
		super(message);
	}

	public BPMParserException(String message, Throwable cause) {
		super(message, cause);
	}

	public BPMParserException(Throwable cause) {
		super(cause);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}

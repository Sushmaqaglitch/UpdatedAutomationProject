package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class IncentiveStatusActivityDetail implements Serializable
{	
	static final long serialVersionUID = 0L;
	
	private Integer incentiveStatusActivityDetailID;
	//uid to contract incented table.
	private Integer contractProgramIncentiveStatusID;
	//uid to member incented table.
	private Integer programMemberIncentiveStatusID;
	private Integer  personDemographicsID;
	private Date    activityStatusIncentiveDate;
	//uid to person program activity status table.
	private Integer personProgramActivityStatusID;
	
	private Integer programIncentiveOptionID;
	
	private List<IncentiveStatusActivityDetailContribution> incentiveStatusActivityDetailContributions = new ArrayList<IncentiveStatusActivityDetailContribution>();
	
	PersonProgramActivityStatus personProgramActivityStatus;
	
	public IncentiveStatusActivityDetail()
	{
		super();
	}


	public Integer getIncentiveStatusActivityDetailID() {
		return incentiveStatusActivityDetailID;
	}

	public void setIncentiveStatusActivityDetailID(
			Integer incentiveStatusActivityDetailID) {
		this.incentiveStatusActivityDetailID = incentiveStatusActivityDetailID;
	}

	public Integer getContractProgramIncentiveStatusID() {
		return contractProgramIncentiveStatusID;
	}

	public void setContractProgramIncentiveStatusID(
			Integer contractProgramIncentiveStatusID) {
		this.contractProgramIncentiveStatusID = contractProgramIncentiveStatusID;
	}

	public Integer getProgramMemberIncentiveStatusID() {
		return programMemberIncentiveStatusID;
	}

	public void setProgramMemberIncentiveStatusID(
			Integer programMemberIncentiveStatusID) {
		this.programMemberIncentiveStatusID = programMemberIncentiveStatusID;
	}

	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}

	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}
	
	

	public Date getActivityStatusIncentiveDate() {
		return activityStatusIncentiveDate;
	}

	public void setActivityStatusIncentiveDate(Date activityStatusIncentiveDate) {
		this.activityStatusIncentiveDate = activityStatusIncentiveDate;
	}

	public Integer getPersonProgramActivityStatusID() {
		return personProgramActivityStatusID;
	}

	public void setPersonProgramActivityStatusID(
			Integer personProgramActivityStatusID) {
		this.personProgramActivityStatusID = personProgramActivityStatusID;
	}

	public List<IncentiveStatusActivityDetailContribution> getIncentiveStatusActivityDetailContributions() {
		return incentiveStatusActivityDetailContributions;
	}

	public void setIncentiveStatusActivityDetailContributions(List<IncentiveStatusActivityDetailContribution> incentiveStatusActivityDetailContributions) {
		this.incentiveStatusActivityDetailContributions = incentiveStatusActivityDetailContributions;
	}

	public PersonProgramActivityStatus getPersonProgramActivityStatus() {
		return personProgramActivityStatus;
	}

	public void setPersonProgramActivityStatus(
			PersonProgramActivityStatus personProgramActivityStatus) {
		this.personProgramActivityStatus = personProgramActivityStatus;
	}


	public final Integer getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}


	public final void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}

	
	
	
}

package com.healthpartners.service.imfs.iface;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.TreeSet;

import com.healthpartners.service.imfs.dto.*;
import org.springframework.dao.DataAccessException;



public interface MemberService {
	public Collection<MemberProgramStatus> getMemberProgramStatus(
			WebServiceRequest pWebServiceRequest);

	public BPMRequiredParticipantResponse isRequiredParticipant(WebServiceRequest pWebServiceRequest);

	public boolean isRequiredParticipant(String memberID,
			int targetQualificationYear, Calendar pCurrentDate);
	
	public boolean isRequiredParticipantRetroactive(String memberID,
			int targetQualificationYear, Calendar activityStatusDate);
	

	public BPMRequiredParticipantResponse isHAAvailable(WebServiceRequest pWebServiceRequest);

	/**
	 * gets BusinessProgramTOs for Person ID and current TargetQualificationYear
	 * 
	 * @param pPersonID
	 * @return Collection<BusinessProgramTO>
	 * @throws DataAccessException
	 */
	public Collection<BusinessProgramTO> getBusinessPrograms(Integer pPersonID)
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;

	/**
	 * gets BusinessProgramTOs for member ID and current TargetQualificationYear
	 * 
	 * @param pMemberID
	 * @return Collection<BusinessProgramTO>
	 * @throws DataAccessException
	 */
	public Collection<BusinessProgramTO> getBusinessPrograms(String pMemberID)
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;

	Collection<Member> getMembers(String pMemberID,
			BusinessProgramTO pBusinessProgramTO);

	public Collection<Member> getMembers(Integer pPersonID,
			BusinessProgramTO pBusinessProgramTO, boolean pCalledFromWebPortal);
	
	public String getMemberNoUsingMODS(String lExternalPersonID) throws Exception, DataAccessException;

	/**
	 * gets Collection<<MemberTO>> for status calculation -based on memberID
	 *
	 * @throws DataAccessException
	 */
	public Collection<MemberTO> getMembersForStatusCalculation(String memberID, BPMBusinessProgram pBusinessProgram)
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;

	/**
	 * gets Collection<<MemberTO>> for status calculation -based on personID
	 * 
	 * @param personID
	 * @return Collection<MemberTO>
	 * @throws DataAccessException
	 */
	public Collection<MemberTO> getMembersForStatusCalculation(Integer personID, BPMBusinessProgram pBusinessProgram)
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;

	/**
	 * gets MemberTO for status calculation -based on personID
	 *
	 * @return MemberTO
	 * @throws DataAccessException
	 */
	public MemberTO getMemberDetails(PersonRelationship personRelationship, BPMBusinessProgram pBusinessProgram) throws com.healthpartners.service.imfs.exception.BPMException,
			DataAccessException;
	
	public Collection<ActivityFulfillmentTrackingReportHist> getActivityFulfillmentTrackingReportHist(String fulfillmentRoutingType, java.sql.Date transactionDate)
			throws DataAccessException;

	/**
	 * Updates member program status.
	 * 
	 * @param memberProgramUpdate
	 * @return number of rows updated
	 * @throws DataAccessException
	 */
	public int updateMemberProgramStatus(
			MemberProgramUpdateTO memberProgramUpdate) throws com.healthpartners.service.imfs.exception.BPMException,
			DataAccessException;

	/**
	 * Updates member program status in batch.
	 * 
	 * @param memberProgramUpdates
	 * @return number of rows updated
	 * @throws DataAccessException
	 */
	public int[] updateMemberProgramStatus(
			Collection<MemberProgramUpdateTO> memberProgramUpdates)
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;

	/**
	 * Updates member contract status in batch.
	 * 
	 * @param memberProgramUpdates
	 * @return number of rows updated
	 * @throws DataAccessException
	 */
	public int[] updateMemberContractStatus(
			Collection<MemberProgramUpdateTO> memberProgramUpdates)
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;

	/**
	 * Updates member contract status.
	 * 
	 * @param memberProgramUpdate
	 * @return number of rows updated
	 * @throws DataAccessException
	 */
	public int updateMemberContractStatus(
			MemberProgramUpdateTO memberProgramUpdate) throws com.healthpartners.service.imfs.exception.BPMException,
			DataAccessException;
	
//	public void updateMemberContractRecyclePerTollgateRules(
//			Collection<MemberProgramUpdateTO> generatedMemberProgramStatuses,
//				Collection<MemberProgramUpdateTO> generatedMemberContractStatuses) throws BPMException;

	/**
	 * gets Person
	 * 
	 * @param memberID
	 * @return Person
	 * @throws DataAccessException
	 */
	public Person getPersonByMemberId(String memberID) throws com.healthpartners.service.imfs.exception.BPMException,
			DataAccessException;

	public TreeSet<Integer> updateMembershipData(Integer lPersonID)
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;

	public Integer getPersonID(String hpMemberID) throws com.healthpartners.service.imfs.exception.BPMException,
			DataAccessException;

	/**
	 * gets person ids still eligible after qualification period to be used
	 * for elapsed time calculation.
	 * 
	 * @return
	 * @throws DataAccessException
	 */
	public Collection<Integer> getPersonsEligibleBeyondQualificationPeriod()
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;

	/**
	 * inserts row PROCESSING_STATUS_LOG with completion time set NULL
	 *
	 * @param processId
	 * @param userId
	 * @return number of rows updated
	 * @throws DataAccessException
	 */
	public int[] insertPersonProcessingStatus(Collection<Integer> personIds,
			Integer processId, String processingStatusValue, String userId)
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;

	/**
	 * sets Member Processing Status PROCESSING_STATUS_LOG
	 * 
	 * @param personIds
	 * @param userId
	 * @param processingStatusValue
	 * @throws DataAccessException
	 */
	public int[] updatePersonProcessingStatus(Collection<Integer> personIds,
			Integer processId, String processingStatusValue, String userId)
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;

	/**
	 * inserts row PROCESSING_STATUS_LOG with completion time set NULL
	 * 
	 * @param personId
	 * @param processId
	 * @param userId
	 * @param processingStatusValue
	 * @return id
	 * @throws DataAccessException
	 */
	public Long insertPersonProcessingStatus(Integer personId,
			Integer processId, String processingStatusValue, String userId)
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
	
	/**
	 * Insert person contract history records into the person contract history table.
	 * @param pPersonContractHist
	 * @throws DataAccessException
	 */
	public void insertPersonContractHist(
			Collection<PersonContractHist> pPersonContractHist) throws com.healthpartners.service.imfs.exception.BPMException,
			DataAccessException;

	
	/**
	 * sets Member Processing Status PROCESSING_STATUS_LOG
	 *
	 */
	public int updatePersonProcessingStatusLog(Integer personId,
			Integer processId, String processingStatusValue, String userId)
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;

	public int getNumberOfPendingPersonsTobeProcessed(int pProcessID)
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;

	public Collection<Integer> getPendingPersonsTobeProcessed(int batchSize,
			int pProcessID) throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
	
	public Collection<BPMBusinessProgram> getParticipatingBusinessPrograms(Integer pPersonID)
	throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
	
	public Collection<BPMBusinessProgram> getParticipatingBusinessProgramsWTermedContract(Integer pPersonID)
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
	
	public Collection<PersonRelationship> getPersonRelationships(Integer pPersonDemographicsID)
	throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
	
	public Collection<PersonContractHist> getPersonContractHistoryReconciled(java.sql.Date pCutoffDateToReconcile)
	throws DataAccessException;
	
	public Collection<PersonActivityIncentToFulfillReconcile> getAllPersonActivityIncentToFulfillReconciled(String sourceSystemCode, String purchaseSubType)
			throws DataAccessException;
	
	
	public int insertCDHPFulfillments(Collection<PersonActivityAchievedContribution> hraParticipantCompletions) 
	throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
	
	public int insertCDHPFulfillmentHistory(Collection<PersonActivityAchievedContribution> hraParticipantCompletions) 
	throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
	
	public int insertRewardFulfillmentHistory(Collection<PersonActivityAchievedReward> participantRewards) 
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
	
	public int insertPersonActivityFulfillmentHistory(
			Collection<MemberActivity> pMemberActivities) throws com.healthpartners.service.imfs.exception.BPMException,
			DataAccessException;
	
	public Collection<String> getMemberIDFromPersonDetails(String firstName,
			String middleInitial, String lastName, String gender,
			java.sql.Date dateOfBirth) throws DataAccessException, com.healthpartners.service.imfs.exception.BPMException;
	
	
	
	public Collection<Integer> insertEmployerAdministeredActivities(
			EmployerActivityContributionsFileData lEmployerActivityContributionsFileData)
			throws DataAccessException, com.healthpartners.service.imfs.exception.BPMException;
		
	
	public Activity getActivityFromExternalActivity(String groupNo, String externalActivityName) throws Exception, DataAccessException;
	
	public boolean validateParticipatingMember(String memberID);
	
	public String getGroupName(String groupNo) throws com.healthpartners.service.imfs.exception.BPMException,
			DataAccessException;
	
	public Collection<Activity> getEmployerAdminsterdActivities()
			throws DataAccessException, com.healthpartners.service.imfs.exception.BPMException;
	
	public Collection<ActivityExternalEmployerXref> getExternalEmployerActivityXrefAll()
			throws DataAccessException, com.healthpartners.service.imfs.exception.BPMException;
	
	public ArrayList<MemberProgramIncentiveTO> getRelatedMemberProgramIncentives(Integer programID, Integer contractNo, Integer personDemographicsID);
	
	public PersonProgramActivityIncentiveStatus getMemberPgmActivityIncentiveStatusNDetail (Integer programID, Integer personDemographicsID, Integer incentiveOptionID, Integer activityID) throws DataAccessException;
	
	
	public Collection<CDHPFulfillmentTrackingReportHist> getCDHPFulfillmentTrackingReportHist(String productType, Integer programID, Integer personDemographicsID, Integer activityID)
			throws DataAccessException;
	
	public Collection<PersonProgramActivityIncentiveStatus> getCDHPPersonActivityIncentToFulfillReconciled(Collection<PersonProgramActivityIncentiveStatus> personProgramActivityIncentiveStatusForHraHsaAL) 
			throws DataAccessException;
	
	public Collection<PersonProgramActivityIncentiveStatus> getRewardPersonActivityIncentToFulfillReconciled(Collection<PersonProgramActivityIncentiveStatus> personProgramActivityIncentiveStatusForRewardAL) 
			throws DataAccessException;
	
	public void createPersonContractProgramHistory(
			Collection<MemberProgramUpdateTO> memberProgramUpdates, Collection<MemberProgramUpdateTO> memberProgramContractUpdates, Collection<MemberTO> members)
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
	
}
	
package com.healthpartners.service.imfs.dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.fasterxml.jackson.databind.util.Named;
import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.healthpartners.service.imfs.exception.BPMException;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;

@Configuration
public class ContractDAOJdbc extends JdbcDaoSupport implements ContractDAO {

	/*
	 * SQL statements
	 */
	private String insertMemberContractStatus;

	private String updateMemberContractStatus;

	private String getMemberContractStatus;
	
	private String selectContractStatus;

	private String deleteMemberContractStatus;

	private String deleteMemberContractByPersonID;

	private String countMemberContractStatusRows;

	private String selectMemberContractProgramStatus;
	
	private String selectMemberTermedContractProgramStatus;

	private String selectBPMMemberContract;
	
	private String selectBPMMembersForProgramContract;
	
	private String selectBPMMembersForProgramContractV2;
	
	private String selectContractHistory;
	private String selectContractHistoryForDependent;
	private String selectSubgroupHistory;
	private String selectPackageHistory;
	private String selectPackageHistoryForDependent;
	
	private String selectIsParticipating;
	private String selectContractOfPH;
	
	private String selectContractStatusCount;
	
	private String selectBadMemberContracts;
	
	private String selectNameOfPHByContract;
	
	private String selectCDHPFulfillmentTrackingReport;
	
	private String selectPersonContributions;
	private String selectContractContributions;
	

	/*
	 * SQL sequences
	 */
	@Autowired
	private DataFieldMaxValueIncrementer contractStatusIdIncrementer;

	/*
	 * DAO reference
	 */
	private QualificationOverrideDAO qualificationOverrideDAO;

	public ContractDAOJdbc() {
		super();
	}
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Autowired
	DataSource bpmDataSource;


	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}

	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public long insertMemberContractStatus(
			MemberProgramUpdateTO memberProgramUpdate)
			throws DataAccessException {

		Long contractStatusId = new Long(contractStatusIdIncrementer
				.nextLongValue());		
		
		// Persist
		JdbcTemplate template = getJdbcTemplate();

		Object params[] = new Object[] {
				contractStatusId,
				memberProgramUpdate.getProgramID(),
				BPMConstants.BPM_TYPE_CONTRACT_STATUS,
				memberProgramUpdate.getStatusCodeValue(),
				memberProgramUpdate.getIssueDate(),
				// memberProgramUpdate.getStatusReasonCodeValue(), STAT_RSN_CD
				// none in
				// current requiremnt				
				memberProgramUpdate.getContractNumber(),
				memberProgramUpdate.getProgramIncentiveOptionID(),
				memberProgramUpdate.getInsertUserId(),
				memberProgramUpdate.getContractNumber(),
				memberProgramUpdate.getContractNumber()};

		int types[] = new int[] { Types.BIGINT, Types.INTEGER, Types.VARCHAR,
				Types.VARCHAR, Types.TIMESTAMP, Types.INTEGER, 
				Types.INTEGER,
				Types.VARCHAR, Types.INTEGER, Types.INTEGER };

		template.update(insertMemberContractStatus, params, types);

		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
		
		return contractStatusId.longValue();
	}


	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public int updateMemberContractStatus(
			MemberProgramUpdateTO memberProgramUpdate)
			throws DataAccessException {

		if (hasMemberContractStatusRow(memberProgramUpdate) == false) {
			insertMemberContractStatus(memberProgramUpdate);
			return 1;
		} else {			
			
			JdbcTemplate template = getJdbcTemplate();
			Object params[] = new Object[] {
					BPMConstants.BPM_TYPE_CONTRACT_STATUS,
					memberProgramUpdate.getStatusCodeValue(),
					memberProgramUpdate.getIssueDate(),
					memberProgramUpdate.getModifyUserId(),
					memberProgramUpdate.getContractNumber(),
					// memberProgramUpdate.getPersonID(), //update all persons
					// on this contract// policy holder id
					memberProgramUpdate.getProgramID() };
			int types[] = new int[] { Types.VARCHAR, Types.VARCHAR,
					Types.TIMESTAMP, Types.VARCHAR, Types.INTEGER,
					Types.INTEGER };
			return template.update(updateMemberContractStatus, params, types);
		}
	}

	/**
	 * 
	 * @param pProgramIncentiveOptionID
	 * @param pProgramID
	 * @param pContractNumber
	 * @param pContractStatus
	 * @param pUserID
	 * @return
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public long updateMemberContractStatus(Integer pProgramIncentiveOptionID,
			Integer pProgramID, Integer pContractNumber,
			String pContractStatus, String pUserID) throws DataAccessException {				
		
		if (hasMemberContractStatusRow(pContractNumber, pProgramIncentiveOptionID, pProgramID) == false) 
		{			
			return insertMemberContractStatus(pProgramIncentiveOptionID, pProgramID,
					pContractNumber, pContractStatus, pUserID);
		} else {
			JdbcTemplate template = getJdbcTemplate();
			Object params[] = new Object[] {
					BPMConstants.BPM_TYPE_CONTRACT_STATUS, pContractStatus,
					Calendar.getInstance()					
					, pUserID, pContractNumber,
					pProgramID, pProgramIncentiveOptionID };
			int types[] = new int[] { Types.VARCHAR, Types.VARCHAR
					, Types.TIMESTAMP					
					, Types.VARCHAR, Types.INTEGER
					, Types.INTEGER, Types.INTEGER };
			return template.update(updateMemberContractStatus, params, types);
		}
	}

	/**
	 * 
	 * @param pProgramIncentiveOptionID
	 * @param pProgramID
	 * @param pContractNumber
	 * @param pContractStatus
	 * @param pUserID
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public long insertMemberContractStatus(Integer pProgramIncentiveOptionID,
			Integer pProgramID, Integer pContractNumber,
			String pContractStatus, String pUserID) throws DataAccessException {
		Long contractStatusId = new Long(contractStatusIdIncrementer
				.nextLongValue());
		
		// Persist
		JdbcTemplate template = getJdbcTemplate();
			
		Object params[] = new Object[] { contractStatusId, pProgramID,
				BPMConstants.BPM_TYPE_CONTRACT_STATUS, pContractStatus,
				Calendar.getInstance(), pContractNumber, pProgramIncentiveOptionID, pUserID, pContractNumber, pContractNumber };

		int types[] = new int[] { Types.BIGINT, Types.INTEGER, Types.VARCHAR,
				Types.VARCHAR, Types.TIMESTAMP, Types.INTEGER, Types.INTEGER, 
				Types.VARCHAR,
				Types.INTEGER, Types.INTEGER };

		template.update(insertMemberContractStatus, params, types);

		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
		
		return contractStatusId.longValue();
	}

	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public int[] updateMemberContractStatus(Collection<MemberProgramUpdateTO> memberProgramUpdates)
	throws DataAccessException 
	{
		int[] numberOfRowsUpdated = new int[1];
		Iterator<MemberProgramUpdateTO> itrStats = memberProgramUpdates.iterator();
		while (itrStats.hasNext()) {
			MemberProgramUpdateTO memberProgramUpdate = (MemberProgramUpdateTO) itrStats
					.next();
			if (hasMemberContractStatusRow(memberProgramUpdate) == false) 
			{			
				numberOfRowsUpdated[0] += insertMemberContractStatus(memberProgramUpdate);
			}
			else
			{
				numberOfRowsUpdated[0] += updateMemberContractStatus(memberProgramUpdate.getProgramIncentiveOptionID()
						, memberProgramUpdate.getProgramID(), memberProgramUpdate.getContractNumber(), memberProgramUpdate.getStatusCodeValue(), memberProgramUpdate.getInsertUserId());
			}
		}
				
		return numberOfRowsUpdated;
	}


	public MemberProgramUpdateTO getMemberContractStatus(
			Integer contractNumber, Integer policyHolderID,
			Integer bisinessProgramID) throws DataAccessException {

		StringBuffer lQuery = new StringBuffer();
		lQuery.append(getMemberContractStatus);
		
		ArrayList<Object> lParameters = new ArrayList<Object>();
	    ArrayList<Integer> lTypes = new ArrayList<Integer>();	
		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setPersonId(policyHolderID);
		namedParameter.setBizPgmId(bisinessProgramID);
		lParameters.add(policyHolderID);
        lTypes.add(new Integer(Types.INTEGER));
        
        lParameters.add(bisinessProgramID);
        lTypes.add(new Integer(Types.INTEGER));
        
       
        if(contractNumber != null && contractNumber > 0)
	    {
	        lParameters.add(contractNumber);
	        namedParameter.setContractId(contractNumber);
	        lTypes.add(new Integer(Types.INTEGER));
	        lQuery.append(" AND cntrstat.CONTRACT_NO = :contractId ");
	    }
		
		// Convert the parameter arraylists to arrays.
		Object params[] = new Object[lParameters.size()];
	    lParameters.toArray(params);

	    int types[] = new int[lTypes.size()];
	    for(int j = 0; j < lTypes.size(); j++)
	    {
	    	types[j] = ((Integer)lTypes.get(j)).intValue();
	    }

		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<MemberProgramUpdateTO> results =	namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
				new RowMapper() {
					@Override
					public MemberProgramUpdateTO mapRow(ResultSet rs, int i) throws SQLException {
						MemberProgramUpdateTO memberProgramUpdate = new MemberProgramUpdateTO();
						memberProgramUpdate
								.setId(rs.getObject(1) != null ? Long
										.valueOf(rs.getLong(1)) : null);
						memberProgramUpdate
								.setProgramID(rs.getObject(2) != null ? Integer
										.valueOf(rs.getInt(2)) : null);
						memberProgramUpdate.setStatusCodeValue(rs.getString(3));
						memberProgramUpdate
								.setIssueDate(rs.getObject(4) != null ? BPMUtils
										.dateToCalendar(rs.getDate(4))
										: null);
						memberProgramUpdate
								.setContractNumber(rs.getObject(5) != null ? Integer
										.valueOf(rs.getInt(5))
										: null);
						memberProgramUpdate
								.setPersonID(rs.getObject(6) != null ? Integer
										.valueOf(rs.getInt(6)) : null);
						memberProgramUpdate.setInsertUserId(rs.getString(7));
						memberProgramUpdate.setModifyUserId(rs.getString(8));
						return memberProgramUpdate;
					}

				});

		MemberProgramUpdateTO dto = null;
		if (results.size() > 0) {
			dto = (MemberProgramUpdateTO) results.get(0);
		}
		
		return dto;
	}
	
	/*
	 * @see com.healthpartners.service.bpm.dao.ContractDAO#getContractStatus(java.lang.Integer,
	 *      java.lang.Integer, java.lang.Integer)
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	
	public ContractProgramStatusTO getContractStatus(Integer programID, Integer programIncentiveOptionID, Integer contractNumber) throws DataAccessException {
		final ArrayList<ContractProgramStatusTO> results = new ArrayList<ContractProgramStatusTO>();
		JdbcTemplate template = getJdbcTemplate();
		
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectContractStatus);
		
		ArrayList<Object> lParameters = new ArrayList<Object>();
	    ArrayList<Integer> lTypes = new ArrayList<Integer>();	
		
        lParameters.add(programID);
        lTypes.add(new Integer(Types.INTEGER));
        
        lParameters.add(programIncentiveOptionID);
        lTypes.add(new Integer(Types.INTEGER));
        
        lParameters.add(contractNumber);
        lTypes.add(new Integer(Types.INTEGER));
        
       
		// Convert the parameter arraylists to arrays.
		Object params[] = new Object[lParameters.size()];
	    lParameters.toArray(params);

	    int types[] = new int[lTypes.size()];
	    for(int j = 0; j < lTypes.size(); j++)
	    {
	    	types[j] = ((Integer)lTypes.get(j)).intValue();
	    }				
		
		
		template.query(lQuery.toString(), params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						ContractProgramStatusTO lContractProgramStatusTO = new ContractProgramStatusTO();
						lContractProgramStatusTO.setProgramID(rs.getInt("BIZ_PGM_ID"));
						lContractProgramStatusTO.setProgramIncentiveOptionID(rs.getInt("biz_pgm_incntv_optn_id"));
						lContractProgramStatusTO.setContractNo(rs.getInt("CONTRACT_NO"));
						lContractProgramStatusTO.setContractStatus(rs.getString("CNTR_STAT_VALUE"));
						lContractProgramStatusTO.setQualificationStartDate(rs.getDate("qualification_year_start_dt"));
						lContractProgramStatusTO.setParticipationEndDate(rs.getDate("participation_end_dt"));
						results.add(lContractProgramStatusTO);
					}
				});

		ContractProgramStatusTO dto = null;
		if (results.size() > 0) {
			dto = (ContractProgramStatusTO) results.get(0);
		}
		
	
		
		return dto;
	}
	
	/**
	 * Find the Policy Holder contract info given the contract no.
	 * @param pContractNo
	 * @return
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	
	public Contract getContractOfPH(Integer pContractNo)
	throws DataAccessException 
	{
		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setContractId(pContractNo);
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<Contract> results = namedParameterJdbcTemplate.query(selectContractOfPH, namedParameters,
				new RowMapper() {
					@Override
					public Contract mapRow(ResultSet rs, int i) throws SQLException {
						Contract lContract = new Contract();
						lContract.setContractNumber(rs.getInt("contract_no"));
						lContract.setPolicyHolderNumber(rs.getInt("PERSON_NO"));
						lContract.setContractEffectiveDate(BPMUtils.dateToCalendar(rs.getDate("CONTRACT_EFF_DT")));
						lContract.setContractEndDate(BPMUtils.dateToCalendar(rs.getDate("CONTRACT_END_DT")));
						return lContract;
					}

				});

		Contract lContract = null;
		if (results.size() > 0) {
			lContract = (Contract) results.get(0);
		}

		
		return lContract;
	}
	
	/**
	 * Find the Policy Holder contract info given the contract no.
	 * @param pContractNo
	 * @return
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	
	public ContractPolicyHolderInfo getNameOfPHByContract(Integer pContractNo)
	throws DataAccessException 
	{
		final ArrayList<ContractPolicyHolderInfo> results = new ArrayList<ContractPolicyHolderInfo>();
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { pContractNo, pContractNo };
		int types[] = new int[] { Types.INTEGER, Types.INTEGER};
		template.query(selectNameOfPHByContract, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						
						ContractPolicyHolderInfo lContactPHInfo = new ContractPolicyHolderInfo();
						lContactPHInfo.setFirstName(rs.getString("first_nm"));
						lContactPHInfo.setLastName(rs.getString("last_nm"));
						lContactPHInfo.setMiddleName(rs.getString("middle_nm"));
						lContactPHInfo.setMemberNo(rs.getString("hp_mem_id"));
						lContactPHInfo.setPersonID(rs.getInt("prsn_id"));
						lContactPHInfo.setPersonDemographicsID(rs.getInt("prsn_dmgrphcs_id"));
						
						results.add(lContactPHInfo);
					}
				});

		ContractPolicyHolderInfo lContractPHInfo = null;
		if (results.size() > 0) {
			lContractPHInfo = (ContractPolicyHolderInfo) results.get(0);
		}
		
		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
		
		return lContractPHInfo;
	}

	/*
	 * @see com.healthpartners.service.bpm.dao.ContractDAO#deleteMemberContractStatus(java.lang.Integer)
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public int deleteMemberContractStatus(long contractProgramStatusID)
			throws DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { Long.valueOf(contractProgramStatusID) };
		int types[] = new int[] { Types.BIGINT };
		return template.update(deleteMemberContractStatus, params, types);
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	
	public int deleteMemberContractStatusByPersonID(Integer personID,
			Integer contractNumber, Integer pProgramID) throws DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {contractNumber, personID, pProgramID };
		int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.INTEGER };
		return template.update(deleteMemberContractByPersonID, params, types);
	}
	
	private boolean hasMemberContractStatusRow(
			MemberProgramUpdateTO memberProgramUpdate)
			throws DataAccessException {
		Object params[] = new Object[] {
				memberProgramUpdate.getContractNumber(),				
				memberProgramUpdate.getProgramID(),
				memberProgramUpdate.getProgramIncentiveOptionID()
				};

		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setContractId(memberProgramUpdate.getContractNumber());
		namedParameter.setBizPgmId(memberProgramUpdate.getProgramID());
		namedParameter.setIncentiveId(memberProgramUpdate.getProgramIncentiveOptionID());


		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<Integer> results = namedParameterJdbcTemplate.query(countMemberContractStatusRows, namedParameters,
				new RowMapper() {
					@Override
					public Integer mapRow(ResultSet rs, int i) throws SQLException {
						return rs.getInt("number_of_contracts");
					}

				});

		
		if(results.size() > 0 && results.get(0).intValue() > 0)
		{
			return true;
		}
		
		return false;
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	
	public boolean hasMemberContractStatusRow(Integer pContractNumber,
			Integer pProgramIncentiveOptionID, Integer pProgramID) throws DataAccessException {
		Object params[] = new Object[] { pContractNumber, pProgramID, pProgramIncentiveOptionID };
		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setContractId(pContractNumber);
		namedParameter.setBizPgmId(pProgramID);
		namedParameter.setIncentiveId(pProgramIncentiveOptionID);
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);


		List<Integer> results = namedParameterJdbcTemplate.query(countMemberContractStatusRows, namedParameters,
				new RowMapper() {
					@Override
					public Integer mapRow(ResultSet rs, int i) throws SQLException {
						return rs.getInt("number_of_contracts");
					}

				});

		if(results.size() > 0 && results.get(0).intValue() > 0)
		{
			return true;
		}
		
		return false;
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	
	public Collection<MemberContractProgramTO> getMemberContractProgramStatus(
			Integer pPersonID, Integer relationshipCode, Integer pTargetQualificationYear)
			throws DataAccessException {
		
		final Integer personId = pPersonID;
		
		JdbcTemplate template = getJdbcTemplate();
		StringBuffer lQuery = new StringBuffer();
		ArrayList<Object> lParameters = new ArrayList<Object>();
	    ArrayList<Integer> lTypes = new ArrayList<Integer>();
		
		lQuery.append(selectMemberContractProgramStatus);				
				
		// Person ID is used twice in the query.
		lParameters.add(pPersonID);
		lTypes.add(new Integer(Types.INTEGER));		
		lParameters.add(pPersonID);
		lTypes.add(new Integer(Types.INTEGER));
		lParameters.add(pPersonID);
		lTypes.add(new Integer(Types.INTEGER));
		//BPM 45 - relationship needed for dual covered scenerios.
		lParameters.add(relationshipCode);
		lTypes.add(new Integer(Types.INTEGER));
					
		if(pTargetQualificationYear != null && pTargetQualificationYear.intValue() > 0)
	    {			
	    	lParameters.add(pTargetQualificationYear);
		    lTypes.add(new Integer(Types.INTEGER));
		    lQuery.append(" AND EXTRACT(YEAR FROM biz.eff_dt) = ? ");
	    }
		//BPM-45 - ensures most recent contract in dual coverage scenerio.
		lQuery.append("  order by contract_eff_dt desc");

		// Convert the parameter arraylists to arrays.
		Object params[] = new Object[lParameters.size()];
	    lParameters.toArray(params);

	    int types[] = new int[lTypes.size()];
	    for(int j = 0; j < lTypes.size(); j++)
	    {
	    	types[j] = ((Integer)lTypes.get(j)).intValue();
	    }				
	    
	    ArrayList<MemberContractProgramTO> lMemberContractProgramTOs = (ArrayList<MemberContractProgramTO>) template.query(
	    		lQuery.toString(), params, types, new memberContractProgramStatusMapper());	    	    			    

		// Find the effective contract date of the policy holder. 
		// The person being queried may be the Spouse or Domestic Partner who may have
		// joined the contract at a later date.
		// Object lMemberContractProgramTOs gets updated via pass by reference.
		assignEffectiveContractDateOfPHAndHealthPlanCode(lMemberContractProgramTOs);
		
		
		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;				
		
		return lMemberContractProgramTOs;
	}
	/*
	 * Method is called only when termed contracts exist and need to evaluate against term contracts.
	 * (non-Javadoc)
	 * @see com.healthpartners.service.bpm.dao.ContractDAO#getMemberContractProgramStatusTermed(java.lang.Integer, java.lang.Integer)
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	
	public Collection<MemberContractProgramTO> getMemberContractProgramStatusTermed(
			Integer pPersonID, Integer relationshipCode, Integer pTargetQualificationYear)
			throws DataAccessException {
		
		
		JdbcTemplate template = getJdbcTemplate();
		StringBuffer lQuery = new StringBuffer();
		ArrayList<Object> lParameters = new ArrayList<Object>();
	    ArrayList<Integer> lTypes = new ArrayList<Integer>();
		
		lQuery.append(selectMemberTermedContractProgramStatus);
		lQuery.append("AND person_con.CONTRACT_END_DT != to_date('99990101', 'YYYYMMDD')");
		
		
		// Person ID is used twice in the query.
		lParameters.add(pPersonID);
		lTypes.add(new Integer(Types.INTEGER));		
		lParameters.add(pPersonID);
		lTypes.add(new Integer(Types.INTEGER));
		lParameters.add(pPersonID);
		lTypes.add(new Integer(Types.INTEGER));
		//BPM 45 - relationship needed for dual covered scenerios.
		lParameters.add(relationshipCode);
		lTypes.add(new Integer(Types.INTEGER));
						 		
		if(pTargetQualificationYear != null && pTargetQualificationYear.intValue() > 0)
	    {	    	
	    	lParameters.add(pTargetQualificationYear);
		    lTypes.add(new Integer(Types.INTEGER));
		    lQuery.append("AND EXTRACT(YEAR FROM biz.eff_dt) = ? ");
	    }
		//BPM-45 - ensures most recent contract in dual coverage scenerio.
		lQuery.append("  order by contract_eff_dt desc");

		// Convert the parameter arraylists to arrays.
		Object params[] = new Object[lParameters.size()];
	    lParameters.toArray(params);

	    int types[] = new int[lTypes.size()];
	    for(int j = 0; j < lTypes.size(); j++)
	    {
	    	types[j] = ((Integer)lTypes.get(j)).intValue();
	    }				

	    
	    ArrayList<MemberContractProgramTO> lMemberContractProgramTOs = (ArrayList<MemberContractProgramTO>) template.query(
	    		lQuery.toString(), params, types, new memberContractProgramStatusMapper());
	    			   

		// Find the effective contract date of the policy holder. 
		// The person being queried may be the Spouse or Domestic Partner who may have
		// joined the contract at a later date.
		// Object lMemberContractProgramTOs gets updated via pass by reference.
		assignEffectiveContractDateOfPHAndHealthPlanCode(lMemberContractProgramTOs);
		
		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
		
		return lMemberContractProgramTOs;
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	
	public Collection<MemberUpdate> getBPMMemberContracts(Integer pPersonID) 
	throws DataAccessException 
	{
		final ArrayList<MemberUpdate> lMemberUpdates = new ArrayList<MemberUpdate>();
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { pPersonID};
		int types[] = new int[] { Types.INTEGER};

		template.query(selectBPMMemberContract, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						MemberUpdate lMemberUpdate = new MemberUpdate();

						lMemberUpdate.setBusinessProgramID(rs
								.getInt("biz_pgm_id"));
						lMemberUpdate.setContractNumber(rs
								.getInt("contract_no"));
						lMemberUpdate.setPersonID(rs.getInt("PRSN_DMGRPHCS_ID"));
						lMemberUpdate.setRelationshipID(rs.getInt("rel_cd"));
						lMemberUpdate.setDateOfBirth(rs.getDate("DOB_DT"));
						lMemberUpdate.setProgramIncentiveOptionID(rs.getInt("biz_pgm_incntv_optn_ID"));

						lMemberUpdates.add(lMemberUpdate);

					}
				});

		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
		
		return lMemberUpdates;
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	
	public Collection<MemberUpdate> getBPMMembersForProgramContract(Integer pContractNumber,
			Integer programID) throws DataAccessException {
		final ArrayList<MemberUpdate> lMemberUpdates = new ArrayList<MemberUpdate>();
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { pContractNumber, programID };
		int types[] = new int[] { Types.INTEGER, Types.INTEGER };

		template.query(selectBPMMembersForProgramContract, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						MemberUpdate lMemberUpdate = new MemberUpdate();

						lMemberUpdate.setBusinessProgramID(rs
								.getInt("biz_pgm_id"));
						lMemberUpdate.setContractNumber(rs
								.getInt("contract_no"));
						lMemberUpdate.setPersonID(rs.getInt("PRSN_DMGRPHCS_ID"));
						lMemberUpdate.setRelationshipID(rs.getInt("REL_CD"));
						

						lMemberUpdates.add(lMemberUpdate);

					}
				});

		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
		
		return lMemberUpdates;
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	
	public Collection<MemberUpdate> getBPMMembersForProgramContractV2(Integer pContractNumber,
			Integer programID) throws DataAccessException {

		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setContractId(pContractNumber);
		namedParameter.setBizPgmId(programID);
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<MemberUpdate> lMemberUpdates = namedParameterJdbcTemplate.query(selectBPMMembersForProgramContractV2, namedParameters,
				new RowMapper() {
					@Override
					public MemberUpdate mapRow(ResultSet rs, int i) throws SQLException {
						MemberUpdate lMemberUpdate = new MemberUpdate();

						lMemberUpdate.setBusinessProgramID(rs
								.getInt("biz_pgm_id"));
						lMemberUpdate.setContractNumber(rs
								.getInt("contract_no"));
						lMemberUpdate.setPersonID(rs.getInt("PRSN_DMGRPHCS_ID"));
						lMemberUpdate.setRelationshipID(rs.getInt("REL_CD"));
						lMemberUpdate.setRelationship(rs.getString("RLSHP_TXT"));
						return lMemberUpdate;
					}

				});

		
		return lMemberUpdates;
	}
	
	/**
	 * select bad member contracts 
	 *
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	
	public  Collection<BadContract> getBadMemberContracts(
			String pBadContractStartDate) throws DataAccessException {
		final ArrayList<BadContract> lBadContracts = new ArrayList<BadContract>();
		
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { pBadContractStartDate};
		int types[] = new int[] { Types.VARCHAR};
		
		template.query(selectBadMemberContracts, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException 
					{
						BadContract badContract = new BadContract();
						badContract.setContractPgmStatId(rs.getInt("contractPgmStatId"));
						badContract.setBizProgramId(rs.getInt("bizProgramId"));
						badContract.setPersonId(rs.getInt("personId"));
									
						lBadContracts.add(badContract);
					}
				});
		
		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
		
		return lBadContracts;
	}
	
	
	//Produces warnings during compile time to quickly identify typos or API changes
	
	public Collection<ContractHistory> getContractHistory(Integer pPersonID) 
	throws DataAccessException 
	{
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { pPersonID};
		int types[] = new int[] { Types.INTEGER};
		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setPersonId(pPersonID);
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<ContractHistory> lContractHistories = namedParameterJdbcTemplate.query(selectContractHistory, namedParameters,
				new RowMapper() {
					@Override
					public ContractHistory mapRow(ResultSet rs, int i) throws SQLException {
						ContractHistory lContractHistory = new ContractHistory();

						lContractHistory.setID(rs.getInt("contract_no"));
						lContractHistory.setEffectiveDate(rs.getDate("eff_dt"));
						lContractHistory.setEndDate(rs.getDate("end_dt"));
						lContractHistory.setGroupID(rs.getInt("grp_id"));
						lContractHistory.setSubgroupID(rs.getInt("subgrp_id"));
						lContractHistory.setRelationshipCode(rs.getInt("rel_cd"));
						if(rs.getString("current_contract").equals("Y"))
						{
							lContractHistory.setCurrent(true);
						}
						else
						{
							lContractHistory.setCurrent(false);
						}
						return lContractHistory;
					}


				});

		
		return lContractHistories;
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	
	public Collection<ContractHistory> getContractHistoryForDependent(Integer pPersonID) 
			throws DataAccessException 
	{
		Object params[] = new Object[] { pPersonID};
		int types[] = new int[] { Types.INTEGER};
		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setPersonId(pPersonID);
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);


		List<ContractHistory> lContractHistories = namedParameterJdbcTemplate.query(selectContractHistoryForDependent, namedParameters,
				new RowMapper() {
					@Override
					public ContractHistory mapRow(ResultSet rs, int i) throws SQLException {
						ContractHistory lContractHistory = new ContractHistory();

						lContractHistory.setID(rs.getInt("contract_no"));
						lContractHistory.setEffectiveDate(rs.getDate("eff_dt"));
						lContractHistory.setEndDate(rs.getDate("end_dt"));
						lContractHistory.setGroupID(rs.getInt("grp_id"));
						lContractHistory.setSubgroupID(rs.getInt("subgrp_id"));
						lContractHistory.setRelationshipCode(rs.getInt("rel_cd"));
						if(rs.getString("current_contract").equals("Y"))
						{
							lContractHistory.setCurrent(true);
						}
						else
						{
							lContractHistory.setCurrent(false);
						}
						return lContractHistory;
					}

				});

		
		return lContractHistories;
	}
	
	//Produces warnings during compile time to quickly identify typos or API changes
	
	public Collection<PackageHistory> getPackageHistory(Integer pPersonID, Integer pContractNo) 
	throws DataAccessException 
	{
		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setPersonId(pPersonID);
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<PackageHistory> lPackageHistories = namedParameterJdbcTemplate.query(selectPackageHistory, namedParameters,
				new RowMapper() {
					@Override
					public PackageHistory mapRow(ResultSet rs, int i) throws SQLException {
						PackageHistory lPackageHistory = new PackageHistory();

						lPackageHistory.setID(rs.getInt("ben_pkg_id"));
						lPackageHistory.setEffectiveDate(rs.getDate("eff_dt"));
						lPackageHistory.setEndDate(rs.getDate("end_dt"));
						lPackageHistory.setContractNumber(rs.getInt("contract_no"));
						lPackageHistory.setGroupID(rs.getInt("grp_id"));
						lPackageHistory.setSubgroupID(rs.getInt("subgrp_id"));
						if(rs.getString("current_pkg").equals("Y"))
						{
							lPackageHistory.setCurrent(true);
						}
						else
						{
							lPackageHistory.setCurrent(false);
						}
						return lPackageHistory;
					}


				});

		
		return lPackageHistories;
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	
	public Collection<PackageHistory> getPackageHistoryForDependent(Integer pPersonID, Integer pContractNo) 
			throws DataAccessException {

		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setPersonId(pPersonID);
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<PackageHistory> lPackageHistories =  namedParameterJdbcTemplate.query(selectPackageHistoryForDependent, namedParameters,
				new RowMapper() {
					@Override
					public PackageHistory mapRow(ResultSet rs, int i) throws SQLException {
						PackageHistory lPackageHistory = new PackageHistory();

						lPackageHistory.setID(rs.getInt("ben_pkg_id"));
						lPackageHistory.setEffectiveDate(rs.getDate("eff_dt"));
						lPackageHistory.setEndDate(rs.getDate("end_dt"));
						lPackageHistory.setContractNumber(rs.getInt("contract_no"));
						lPackageHistory.setGroupID(rs.getInt("grp_id"));
						lPackageHistory.setSubgroupID(rs.getInt("subgrp_id"));
						if(rs.getString("current_pkg").equals("Y"))
						{
							lPackageHistory.setCurrent(true);
						}
						else
						{
							lPackageHistory.setCurrent(false);
						}
						return lPackageHistory;
					}

				});
		
		return lPackageHistories;
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	
	public Collection<SubgroupHistory> getSubgroupHistory(Integer pPersonID, Integer pContractNo) 
	throws DataAccessException 
	{

		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setPersonId(pPersonID);
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<SubgroupHistory> lSubgroupHistories =	namedParameterJdbcTemplate.query(selectSubgroupHistory, namedParameters,
				new RowMapper() {
					@Override
					public SubgroupHistory mapRow(ResultSet rs, int i) throws SQLException {
						SubgroupHistory lSubgroupHistory = new SubgroupHistory();

						lSubgroupHistory.setID(rs.getInt("subgrp_id"));
						lSubgroupHistory.setEffectiveDate(rs.getDate("subgrp_eff_dt"));
						lSubgroupHistory.setEndDate(rs.getDate("subgrp_end_dt"));
						lSubgroupHistory.setContractNumber(rs.getInt("contract_no"));
						lSubgroupHistory.setGroupID(rs.getInt("grp_id"));
						lSubgroupHistory.setSubgroupID(rs.getInt("subgrp_id"));
						if(rs.getString("current_subgrp").equals("Y"))
						{
							lSubgroupHistory.setCurrent(true);
						}
						else
						{
							lSubgroupHistory.setCurrent(false);
						}
						return lSubgroupHistory;
					}

				});

		
		return lSubgroupHistories;
	}
	
	//Produces warnings during compile time to quickly identify typos or API changes
	
	public Collection<CDHPFulfillmentTrackingReport> getCDHPFulfillmentTrackingReport(String groupNo, String productType, java.sql.Date transactionDate)
	throws DataAccessException { 
		
		final ArrayList<CDHPFulfillmentTrackingReport> lCDHPFulfillmentTrackingReports = new ArrayList<CDHPFulfillmentTrackingReport>();
		ArrayList<Object> lParameters = new ArrayList<Object>();
	    ArrayList<Integer> lTypes = new ArrayList<Integer>();
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectCDHPFulfillmentTrackingReport);
		JdbcTemplate template = getJdbcTemplate();
		
		lParameters.add(productType);
		lTypes.add(new Integer(Types.VARCHAR));
		
		lParameters.add(transactionDate);
		lTypes.add(new Integer(Types.DATE));
		
		if (groupNo == null) {
			lQuery.append(" AND trunc(t.file_sent_dt) = trunc(?) ");
		} else {
			lQuery.append(" AND trunc(t.file_sent_dt) >= trunc(?) ");
			lQuery.append(" AND egs.empl_grp_no = ? ");
			lParameters.add(groupNo);
			lTypes.add(new Integer(Types.VARCHAR));		
		}
		
		
		// Convert the parameter arraylists to arrays.
		Object params[] = new Object[lParameters.size()];
	    lParameters.toArray(params);

	    int types[] = new int[lTypes.size()];
	    for(int j = 0; j < lTypes.size(); j++)
	    {
	    	types[j] = ((Integer)lTypes.get(j)).intValue();
	    }				

		template.query(lQuery.toString(), params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException 
					{
						CDHPFulfillmentTrackingReport lCDHPFulfillmentTrackingReport = new CDHPFulfillmentTrackingReport();
						lCDHPFulfillmentTrackingReport.setCDHPTransID(rs.getInt("cdhp_txn_id"));
						lCDHPFulfillmentTrackingReport.setProgramID(rs.getInt("biz_pgm_id"));
						lCDHPFulfillmentTrackingReport.setGroupID(rs.getInt("grp_id"));
						lCDHPFulfillmentTrackingReport.setGroupNo(rs.getString("empl_grp_no"));
						lCDHPFulfillmentTrackingReport.setEmployerGroupName(rs.getString("empl_grp_rpt_nm"));
						lCDHPFulfillmentTrackingReport.setContractNo(rs.getInt("contract_no"));	
						lCDHPFulfillmentTrackingReport.setContributionStartDate(rs.getDate("contribution_start_dt"));
						lCDHPFulfillmentTrackingReport.setContributionEndDate(rs.getDate("contribution_end_dt"));
						lCDHPFulfillmentTrackingReport.setContributionAmount(rs.getInt("contrib_amt"));
						lCDHPFulfillmentTrackingReport.setContributionTypeCodeId(rs.getInt("tier_contrib_id"));
						lCDHPFulfillmentTrackingReport.setContributionType(rs.getString("contributionType"));
						lCDHPFulfillmentTrackingReport.setContributionDate(rs.getDate("contrib_dt"));
						lCDHPFulfillmentTrackingReport.setMemberCount(rs.getInt("mem_count"));
						lCDHPFulfillmentTrackingReport.setFileSentDate(rs.getDate("file_sent_dt"));
						lCDHPFulfillmentTrackingReport.setIncentiveReportName(rs.getString("incntv_rpt_name"));
						lCDHPFulfillmentTrackingReport.setFulfillmentRoutingType(rs.getString("fulfillment_rtng_tp"));
						
						lCDHPFulfillmentTrackingReports.add(lCDHPFulfillmentTrackingReport);

					}
				});

		
		return lCDHPFulfillmentTrackingReports;
	}
	
	
	
	//Produces warnings during compile time to quickly identify typos or API changes
	
	public Collection<CDHPFulfillmentTrackingReport> getContractContributions(Integer programID, Integer contractNo, Integer incentiveOptionID) 
		throws DataAccessException { 

			final ArrayList<CDHPFulfillmentTrackingReport> lCDHPFulfillmentTrackingReports = new ArrayList<CDHPFulfillmentTrackingReport>();
			JdbcTemplate template = getJdbcTemplate();
			Object params[] = new Object[] { programID, contractNo, incentiveOptionID };
			int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.INTEGER };

			template.query(selectContractContributions, params, types,
					new RowCallbackHandler() {
						public void processRow(ResultSet rs) throws SQLException 
						{
							CDHPFulfillmentTrackingReport lCDHPFulfillmentTrackingReport = new CDHPFulfillmentTrackingReport();
							lCDHPFulfillmentTrackingReport.setProgramID(rs.getInt("biz_pgm_id"));
							lCDHPFulfillmentTrackingReport.setContractNo(rs.getInt("contract_no"));						
							lCDHPFulfillmentTrackingReport.setContributionAmount(rs.getInt("contrib_amt"));
							
							lCDHPFulfillmentTrackingReports.add(lCDHPFulfillmentTrackingReport);

						}
					});

			
			return lCDHPFulfillmentTrackingReports;
		}
	//Produces warnings during compile time to quickly identify typos or API changes
	
	public Collection<MemberUpdate> getIsParticipating(Integer personID, Integer pID, String pWhichColumn)
	throws DataAccessException 
	{
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectIsParticipating);
		Object params[] = null;
		int types[] = null;

		params = new Object[] { personID };
		types = new int[] { Types.INTEGER };
		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setPersonId(personID);
		
		if(pWhichColumn.equals(BPMConstants.BPM_HISTORY_CONTRACT))
		{
			namedParameter.setContractId(pID);
			lQuery.append(" AND todays_baseline.contract_no = :contractId");
		}
		else if(pWhichColumn.equals(BPMConstants.BPM_HISTORY_PACKAGE))
		{
			namedParameter.setBenPkgId(pID);
			lQuery.append(" AND todays_baseline.ben_pkg_id = :benPkgId");
		}
		else if(pWhichColumn.equals(BPMConstants.BPM_HISTORY_SUBGROUP))
		{
			namedParameter.setSubGrpId(pID);
			lQuery.append(" AND todays_baseline.subgrp_id = :subGrpId");
		}

		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<MemberUpdate> lMembers = namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
				new RowMapper() {
					@Override
					public MemberUpdate mapRow(ResultSet rs, int i) throws SQLException {
						MemberUpdate lMemberUpdate = new MemberUpdate();
						lMemberUpdate.setPersonID(rs.getInt("person_no"));
						lMemberUpdate.setContractNumber(rs
								.getInt("contract_no"));
						lMemberUpdate.setBusinessProgramID(rs
								.getInt("biz_pgm_id"));
						lMemberUpdate.setMemberID(rs.getString("HP_MEM_ID"));
						lMemberUpdate
								.setRelationship(rs.getString("rlshp_txt"));
						return lMemberUpdate;
					}

				});
		
		return lMembers;
	}
	
	/**
	 * Get the count for the given contract status, and the given biz pgm ID.
	 * 
	 * @param pContractStatus
	 * @return
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	
	public Integer getContractStatusCount(String pContractStatus, Integer pBusinessProgramID) 
	throws DataAccessException 
	{
		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setBizPgmId(pBusinessProgramID);
		namedParameter.setLuVal(pContractStatus);
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<Integer> results = namedParameterJdbcTemplate.query(selectContractStatusCount, namedParameters,
				new RowMapper() {
					@Override
					public Integer mapRow(ResultSet rs, int i) throws SQLException {
						return rs.getInt("status_count");
					}
				});

		
		return results.get(0);
	}
	
	private static final class memberContractProgramStatusMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			MemberContractProgramTO lMemberContractProgramTO = new MemberContractProgramTO();
			ContractTO lContractTO = new ContractTO();
			Contract lContract = new Contract();
			GenericStatusType lContractStatus = new GenericStatusType();
			GenericStatusType lMemberStatus = new GenericStatusType();

			lMemberContractProgramTO.setBusinessProgramID(rs
					.getInt("biz_pgm_id"));

			lMemberContractProgramTO
					.setBusinessProgramTypeCodeID(rs
							.getString("biz_pgm_tp_cd"));

			lContract.setContractEffectiveDate(BPMUtils.dateToCalendar(rs.getDate("contract_eff_dt")));
									
			lContract.setContractEndDate(BPMUtils.dateToCalendar(rs.getDate("contract_end_dt")));						
			lContract.setContractNumber(rs.getInt("contract_no"));

			lContractStatus.setStatusCodeID(rs.getInt("cntr_stat_cd_id"));
			lContractStatus.setStatusCodeValue(rs.getString("cntr_stat_val"));
			lContractStatus.setStatusCodeDesc(rs.getString("cntr_stat_desc"));
			lContractStatus.setStatusEffectiveDate(BPMUtils.dateToCalendar(rs.getDate("cntr_stat_dt")));
			lContract.setContractStatus(lContractStatus);

			lContractTO.setRelationshipToPolicyHolder(rs.getString("rlshp_txt"));
			lContractTO.setRelationshipCode(rs.getInt("rlshp_cd"));

			lContractTO.setContract(lContract);
			lContractTO.setContractDateOfPolicyHolder(BPMUtils.dateToCalendar(rs.getDate("contract_eff_dt")));

			lMemberContractProgramTO.setMemberContract(lContractTO);

			lMemberStatus.setStatusCodeDesc(rs.getString("stat_desc"));
			lMemberStatus.setStatusCodeID(rs.getInt("stat_cd_id"));
			lMemberStatus.setStatusCodeValue(rs.getString("stat_val"));
			lMemberStatus.setStatusEffectiveDate(BPMUtils.dateToCalendar(rs.getDate("stat_dt")));	
			
			
			lContractTO.setProductTypeCode(rs.getString("PROD_TP_CD"));                           
			lContractTO.setJWOfferCode(rs.getString("JW_OFFER_CD"));                           
			lContractTO.setJWReportingUnit(rs.getString("JW_REPORTING_UNIT"));                         
			lContractTO.setDivisionCode(rs.getString("DIVISION_CD"));                               
			lContractTO.setEmployeeFlag(rs.getString("EMPLOYEE_FLG"));                             
			lContractTO.setEligibleHireDate(rs.getDate("ELIG_HIRE_DT"));
			lContractTO.setHealthPlanCode(rs.getString("HLTH_PLAN_CD"));
			lMemberContractProgramTO.setProgramIncentiveOptionID(rs.getInt("biz_pgm_incntv_optn_ID"));

			lMemberContractProgramTO.setMemberStatus(lMemberStatus);

			return lMemberContractProgramTO;
		}
	}

	/*
	 * Update MemberContractProgramTO collection with member exemptions.  Uupdate done using "pass by reference".
	 */
	private Collection<QualificationOverride> assignAllQualificationOverrides(Integer pPersonDemographicsID, Integer pProgramID, Integer pProgramIncentiveOptionID) 
	{
		Collection<QualificationOverride> lExemptions = 
		    qualificationOverrideDAO.getAllQualificationOverrides(pPersonDemographicsID);
			
		return 	lExemptions;
	}
	
	/* 
	* Find the effective contract date of the policy holder. 
	* The person being queried may be the Spouse or Domestic Partner who may have
	* joined the contract at a later date.
	* 
	* EV 66025 - When a contract-group-site-package has both an M, and a J, two rows are returned for the same
	* business-program.
	* For each MemberContractProgram, if there is a medical-health-plan, find the other business-program in the
	* return list, and set the health plan code to medical.
	*/ 
	private void assignEffectiveContractDateOfPHAndHealthPlanCode(ArrayList<MemberContractProgramTO> lMemberContractProgramTOs) {
		
	
		for (MemberContractProgramTO lMemberContractProgramTO : lMemberContractProgramTOs)
		{
			Contract lContract = getContractOfPH(lMemberContractProgramTO.getMemberContract().getContract().getContractNumber());
			
			if(lContract != null)
			{
			    lMemberContractProgramTO.getMemberContract().setContractDateOfPolicyHolder(lContract.getContractEffectiveDate());
			}
			
			
			// EV 66025 - When a contract-group-site-package has both an M, and a J, two rows are returned for the same
			// business-program.
			// For each MemberContractProgram, if there is a medical-health-plan, find the other business-program in the
			// return list, and set the health plan code to medical.
			HashMap<Integer, String> lBizProgramHealthPlan = new HashMap<Integer, String>();
			
			if(BPMConstants.BPM_MEMBER_WITH_MEDICAL_PLAN.equals(lMemberContractProgramTO.getMemberContract().getHealthPlanCode()))
			{
			    lBizProgramHealthPlan.put(lMemberContractProgramTO.getBusinessProgramID(), lMemberContractProgramTO.getMemberContract().getHealthPlanCode());
			}
			
			for(MemberContractProgramTO lSearchMemberContractProgramTO : lMemberContractProgramTOs)
			{
				String lHealthPlanCode = lBizProgramHealthPlan.get(lSearchMemberContractProgramTO.getBusinessProgramID());
				
				if(BPMConstants.BPM_MEMBER_WITH_MEDICAL_PLAN.equals(lHealthPlanCode))
				{
					lSearchMemberContractProgramTO.getMemberContract().setHealthPlanCode(BPMConstants.BPM_MEMBER_WITH_MEDICAL_PLAN);
					lSearchMemberContractProgramTO.getMemberContract().setProductTypeCode(BPMConstants.BPM_MEMBER_WITH_MEDICAL_PLAN);
				}
			}
		
		}
		
	}

	/**
	 * Sets the insertMemberContractStatus SQL statement. Should only be called
	 * by Spring.
	 *
	 */
	public void setInsertMemberContractStatus(String sql) {
		this.insertMemberContractStatus = sql;
	}

	/**
	 * Sets the getMemberContractStatus SQL statement. Should only be called by
	 * Spring.
	 *
	 */
	public void setGetMemberContractStatus(String sql) {
		this.getMemberContractStatus = sql;
	}
	
	

	public void setSelectContractStatus(String selectContractStatus) {
		this.selectContractStatus = selectContractStatus;
	}

	/**
	 * Sets the updateMemberContractStatus SQL statement. Should only be called
	 * by Spring.
	 *
	 */
	public void setUpdateMemberContractStatus(String sql) {
		this.updateMemberContractStatus = sql;
	}

	/**
	 * Sets the deleteMemberContractStatus SQL statement. Should only be called
	 * by Spring.
	 *
	 */
	public void setDeleteMemberContractStatus(String sql) {
		this.deleteMemberContractStatus = sql;
	}

	/**
	 * Sets the updateMemberContractStatus SQL statement. Should only be called
	 * by Spring.
	 *
	 */
	public void setCountMemberContractStatusRows(String sql) {
		this.countMemberContractStatusRows = sql;
	}

	/**
	 * Sets the Incrementer. Should only be called by Spring.
	 * 
	 * @param incrementer
	 */
	public void setContractStatusIdIncrementer(
			DataFieldMaxValueIncrementer incrementer) {
		this.contractStatusIdIncrementer = incrementer;
	}

	public String getSelectMemberContractProgramStatus() {
		return selectMemberContractProgramStatus;
	}

	public void setSelectMemberContractProgramStatus(
			String selectMemberContractProgramStatus) {
		this.selectMemberContractProgramStatus = selectMemberContractProgramStatus;
	}
	
	

	public void setSelectMemberTermedContractProgramStatus(
			String selectMemberTermedContractProgramStatus) {
		this.selectMemberTermedContractProgramStatus = selectMemberTermedContractProgramStatus;
	}

	public QualificationOverrideDAO getQualificationOverrideDAO() {
		return qualificationOverrideDAO;
	}

	public void setQualificationOverrideDAO(
			QualificationOverrideDAO qualificationOverrideDAO) {
		this.qualificationOverrideDAO = qualificationOverrideDAO;
	}

	public String getDeleteMemberContractByPersonID() {
		return deleteMemberContractByPersonID;
	}

	public void setDeleteMemberContractByPersonID(
			String deleteMemberContractByPersonID) {
		this.deleteMemberContractByPersonID = deleteMemberContractByPersonID;
	}

	public void setSelectBPMMemberContract(String selectBPMMemberContract) {
		this.selectBPMMemberContract = selectBPMMemberContract;
	}

	public String getSelectBPMMembersForProgramContract() {
		return selectBPMMembersForProgramContract;
	}

	public void setSelectBPMMembersForProgramContract(
			String selectBPMMembersForProgramContract) {
		this.selectBPMMembersForProgramContract = selectBPMMembersForProgramContract;
	}
	
	

	

	public void setSelectBPMMembersForProgramContractV2(
			String selectBPMMembersForProgramContractV2) {
		this.selectBPMMembersForProgramContractV2 = selectBPMMembersForProgramContractV2;
	}

	public String getSelectPackageHistory() {
		return selectPackageHistory;
	}

	public void setSelectPackageHistory(String selectPackageHistory) {
		this.selectPackageHistory = selectPackageHistory;
	}
	
	

	public void setSelectPackageHistoryForDependent(
			String selectPackageHistoryForDependent) {
		this.selectPackageHistoryForDependent = selectPackageHistoryForDependent;
	}

	public String getSelectSubgroupHistory() {
		return selectSubgroupHistory;
	}

	public void setSelectSubgroupHistory(String selectSubgroupHistory) {
		this.selectSubgroupHistory = selectSubgroupHistory;
	}

	public String getUpdateMemberContractStatus() {
		return updateMemberContractStatus;
	}

	public final String getSelectContractHistory() {
		return selectContractHistory;
	}

	public final void setSelectContractHistory(String selectContractHistory) {
		this.selectContractHistory = selectContractHistory;
	}

	
	
	public void setSelectContractHistoryForDependent(
			String selectContractHistoryForDependent) {
		this.selectContractHistoryForDependent = selectContractHistoryForDependent;
	}

	public final String getSelectIsParticipating() {
		return selectIsParticipating;
	}

	public final void setSelectIsParticipating(String selectIsParticipating) {
		this.selectIsParticipating = selectIsParticipating;
	}

	public final String getSelectContractOfPH() {
		return selectContractOfPH;
	}

	public final void setSelectContractOfPH(String selectContractOfPH) {
		this.selectContractOfPH = selectContractOfPH;
	}

	public final String getSelectContractStatusCount() {
		return selectContractStatusCount;
	}

	public final void setSelectContractStatusCount(String selectContractStatusCount) {
		this.selectContractStatusCount = selectContractStatusCount;
	}

	public String getSelectBadMemberContracts() {
		return selectBadMemberContracts;
	}

	public void setSelectBadMemberContracts(String selectBadMemberContracts) {
		this.selectBadMemberContracts = selectBadMemberContracts;
	}



	public void setSelectCDHPFulfillmentTrackingReport(
			String selectCDHPFulfillmentTrackingReport) {
		this.selectCDHPFulfillmentTrackingReport = selectCDHPFulfillmentTrackingReport;
	}

	public void setSelectNameOfPHByContract(String selectNameOfPHByContract) {
		this.selectNameOfPHByContract = selectNameOfPHByContract;
	}

	public void setSelectPersonContributions(String selectPersonContributions) {
		this.selectPersonContributions = selectPersonContributions;
	}

	public void setSelectContractContributions(String selectContractContributions) {
		this.selectContractContributions = selectContractContributions;
	}

	public void setNamedParameterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
	}

	public void setBpmDataSource(DataSource bpmDataSource) {
		this.bpmDataSource = bpmDataSource;
	}
}
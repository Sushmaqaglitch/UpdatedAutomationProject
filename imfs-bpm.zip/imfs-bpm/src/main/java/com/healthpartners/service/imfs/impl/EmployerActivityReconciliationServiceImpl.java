package com.healthpartners.service.imfs.impl;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMEmailUtility;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dao.BusinessProgramDAO;
import com.healthpartners.service.imfs.dao.ContractDAO;
import com.healthpartners.service.imfs.dao.PersonDAO;
import com.healthpartners.service.imfs.dto.*;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.iface.*;
import com.healthpartners.service.imfs.rules.StatusCalculationCommand;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Component
@Service
public class EmployerActivityReconciliationServiceImpl implements EmployerActivityReconciliationService {

    protected final Log logger = LogFactory.getLog(getClass());
	@Autowired
	private MemberService memberService;
	@Autowired
	private BusinessProgramService businessProgramService;
	@Autowired
	private LookUpValueService lookUpValueService;
	@Autowired
	private ActivityEventService activityEventService;
	@Autowired
	private PersonDAO personDAO;
	@Autowired
	private BusinessProgramDAO businessProgramDAO;
	@Autowired
	private ContractDAO contractDAO;
	@Autowired
	private BPMEmailUtility bpmEmailUtility;
	@Autowired
	private EmailService emailService;
	
	
	private String hostName;
	private String userID;
	
	private ArrayList<PersonProgramActivityIncentiveStatus> personProgramActivityIncentiveStatusForHraAL = null;
	private ArrayList<PersonProgramActivityIncentiveStatus> personProgramActivityIncentiveStatusForHsaAL = null;
	private ArrayList<PersonProgramActivityIncentiveStatus> personProgramActivityIncentiveStatusForIntelispendAL = null;
	private ArrayList<PersonProgramActivityIncentiveStatus> memberProgramActivityIncentiveStatusForHraAL = null;
	private ArrayList<PersonProgramActivityIncentiveStatus> memberProgramActivityIncentiveStatusForHsaAL = null;
	private ArrayList<PersonProgramActivityIncentiveStatus> memberProgramActivityIncentiveStatusForIntelispendAL = null;
	private ArrayList<ContractProgramIncentive> contractProgramIncentiveStatusAL = null;
	private ArrayList<ActivityEvent> activityEventsAL = null;
	private ArrayList<ActivityEvent> activityEventDuplicatesAL = null;
	private ArrayList<ActivityEvent> activityEventFilteredOutDuplicatesAL = null;
	private ArrayList<ActivityEvent> activityEventPendingAL = null;
	private ArrayList<ActivityEvent> activityEventInProcessAL = null;
	private ArrayList<ActivityEvent> activityEventFilteredOutAL = null;
	private ArrayList<ActivityEvent> activityEventUnresolvedMemberIDAL = null;
	private ArrayList<ActivityEvent> activityNotIncentedForActivityBasedRequirementsAL = null;
	private ArrayList<ActivityEvent> activityNotIncentedForContractBasedAL = null;
	private ArrayList<ActivityEvent> activityNotIncentedForMemberBasedAL = null;
	private ArrayList<ActivityEvent> activityIncentedForContractBasedAL = null;
	private ArrayList<ActivityEvent> activityIncentedForMemberBasedAL = null;
	
	private ArrayList<ActivityEvent> activityEventNotEligibleAL = null;
	
	
	private ArrayList<ActivityEvent> activityNonRewardedAL = null;
	private ArrayList<ActivityEvent> activityNotIncentedForCheckmarkAL = null;
	private ArrayList<ActivityEvent> activityNoMatchToActivityRequirementAL = null;
	private ArrayList<ActivityEvent> activityNotProgramEligibleAL = null;
	private ArrayList<ActivityEvent> activityHABypassedAlongWithProgramAL = null;
	private ArrayList<ActivityEvent> activityWithNoHATakenForMultiActivityAL = null;
	private ArrayList<ActivityEvent> activityNotLeadToRewardAL = null;
	
	
	
	HashMap<String, ActivityEvent> haExistsForParticipantCheckmarkReqHM = null;
	HashMap<String, ActivityEvent> haExistsForParticipantActivityReqHM = null;
	
	
	
	private Integer inputRecordCount;
	
	private boolean isHraExist =false;
	private boolean isHsaExist = false;
	private boolean isIntelispendExist = false;
	private boolean isMultiActivityBased = false;
	
	private Integer activityEventsToProcessCount;
	
	
/*
 * Batch job to produce reconciliation employer sponsored summary report within the e-mail notification and
 * create a Detail File from the Person Program Activity Incentive Status table if reconciled successfully back to 
 * the file sent from Vendor.
 * 
*/
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
			com.healthpartners.service.imfs.exception.BPMBusinessValidationException.class, com.healthpartners.service.imfs.exception.BPMException.class })
public void processEmployerActivityReconciliationCommand(StatusCalculationCommand statusCalculationCommand) throws com.healthpartners.service.imfs.exception.BPMException {
		
			logger.info("@Start - Process Employer Activity Reconciliation Command. ");
			
			statusCalculationCommand.setCurrentCommandText("Employer Activity Reconciliation");
			
			
			setHostName(statusCalculationCommand.getHostName());
			setUserID(statusCalculationCommand.getUserID());
			
			logger.info("@@@Host name is " + hostName);
			logger.info("@@@User ID is " + userID);
			
			
			instantiateObjects();
		
			
			
			try {	
				
				String groupNo = statusCalculationCommand.getGroupNo();
				String siteNo = statusCalculationCommand.getSiteNo();
				String memberNo = statusCalculationCommand.getMemberNo();
				String startDate =  statusCalculationCommand.getStartDate();
				String sourceSystemID = statusCalculationCommand.getSourceSystemID();
				
				Collection<ActivityEvent> lActivityEvents = (ArrayList<ActivityEvent>) activityEventService.getActivityEventLogsByGroup(groupNo, siteNo, memberNo, startDate, sourceSystemID);
				
				setInputRecordCount(lActivityEvents.size());
				
				//Note: filtered out activity events will also be removed from lActivityEvents in removeDuplicateFilteredOuts.
				Collection<ActivityEvent> activityEventFilteredOut = removeDuplicateFilteredOuts(lActivityEvents);
				this.activityEventFilteredOutAL.addAll(activityEventFilteredOut);
				
				lActivityEvents = (Collection<ActivityEvent>) removeDuplicates(lActivityEvents);
				
				
				this.activityEventsAL.addAll(lActivityEvents);
				
				findPendingActivities(this.activityEventsAL);
				findInProcessActivities(this.activityEventsAL);
				
				setActivityEventsToProcessCount(lActivityEvents.size());
				
				reconcileActivitiesToIncentedTables(lActivityEvents);
				
				String groupName = memberService.getGroupName(groupNo);
			 
				reconcileActivitiesIncentedToFulfillmentTables(statusCalculationCommand, groupName, groupNo);
			
			 	prepareAndSendSummaryEmail(groupNo, groupName, startDate);			
				
			 	clearActivityALs();	
				
			} catch (Exception e) {
				System.out.println("Exception is " + e.toString());
				throw new BPMException(e);
			}
			
	}
	
	private Collection<ActivityEvent> removeDuplicates(Collection<ActivityEvent>  lActivityEvents) {
		
		//LinkHashMap will retain same order that is coming in from the Collection.  See javadoc.
		//This is important because HA always needs to come first followed by program.
		Map<String, ActivityEvent> activityEventHM = new LinkedHashMap<String, ActivityEvent>();
		ArrayList<ActivityEvent> activityEventFilteredOutRemoveAL = new ArrayList<ActivityEvent>();
		
		for (ActivityEvent lActivityEvent : lActivityEvents) {
			String keyHMP = lActivityEvent.getMemberActivity().getMemberID() + lActivityEvent.getMemberActivity().getActivity().getSourceActivityID() + lActivityEvent.getPurchaserSubtypeName();
			if (!activityEventHM.containsKey(keyHMP)) {
				activityEventHM.put(keyHMP, lActivityEvent);
			} else {
				activityEventDuplicatesAL.add(lActivityEvent);
			}
			//determine if filtered out activity event is also found in the non filtered out activity event.
			//if true, it needs to be removed from the filtered out array list to avoid being reported on.
			//just means that the same activity was sent in with corrected info that passed the filtered out edits.
			for (ActivityEvent activityEventFilteredOut : this.activityEventFilteredOutAL) {
				if (activityEventFilteredOut.getMemberActivity().getBusinessProgramID().equals(lActivityEvent.getMemberActivity().getBusinessProgramID()) &&
						activityEventFilteredOut.getMemberActivity().getMemberID().equals(lActivityEvent.getMemberActivity().getMemberID()) &&
							activityEventFilteredOut.getMemberActivity().getActivity().getActivityID().equals(lActivityEvent.getMemberActivity().getActivity().getActivityID())) {
					activityEventFilteredOutRemoveAL.add(activityEventFilteredOut);
					break;
				}

			}
		}
		
		for (ActivityEvent activityEventFilteredOutRemove : activityEventFilteredOutRemoveAL) {
			this.activityEventFilteredOutAL.remove(activityEventFilteredOutRemove);
		}
		
		
		return activityEventHM.values();
		
	}
	
	/*
	 * Capture filtered out activity events ignoring the duplicates into a hashmap and return.  Remove all filtered out activities
	 * from it's source lActivityEvents.  Filtered out activities will be reported on out of their own collection object.
	 */
	private Collection<ActivityEvent> removeDuplicateFilteredOuts(Collection<ActivityEvent>  lActivityEvents) throws Exception {
		
		HashMap<String, ActivityEvent> activityEventFilteredOutHM = new HashMap<String, ActivityEvent> ();
		
		for (ActivityEvent lActivityEvent : lActivityEvents) {
			if (lActivityEvent.getProcessingStatusValue().equals(BPMConstants.PROCESSING_STATUS_FILTERD_OUT)) {
				String keyHMP = lActivityEvent.getMemberActivity().getMemberID() + lActivityEvent.getMemberActivity().getActivity().getSourceActivityID();
				if (!activityEventFilteredOutHM.containsKey(keyHMP)) {
					String reasonDescID = lActivityEvent.getMemberActivity().getReasonDesc();
					if (reasonDescID != null && !reasonDescID.isEmpty()) {
						if (BPMUtils.isValueInteger(reasonDescID)) {
							LookUpValueCode lLookUpValueCode = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.BPM_FILTERD_OUT_RSN, reasonDescID.trim());
							lActivityEvent.setReasonDescription(lLookUpValueCode.getLuvDesc());
						} else {
							lActivityEvent.setReasonDescription("Filtered out reason not available.");
						}
					}
					activityEventFilteredOutHM.put(keyHMP, lActivityEvent);
					activityEventFilteredOutDuplicatesAL.add(lActivityEvent);
				} else { 
					activityEventFilteredOutDuplicatesAL.add(lActivityEvent);
				}
			}
		}
		
		for (ActivityEvent lActivityEventFilteredOut : activityEventFilteredOutDuplicatesAL) {
			lActivityEvents.remove(lActivityEventFilteredOut);
		}
		
		return activityEventFilteredOutHM.values();
		
	}
	
	
	
	private ArrayList<ActivityEvent> findPendingActivities(ArrayList<ActivityEvent> lActivityEvents) {
		
		for (ActivityEvent lActivityEvent : lActivityEvents) {
			
			if (lActivityEvent.getProcessingStatusValue().equals(BPMConstants.PROCESSING_STATUS_PENDING)) {
				activityEventPendingAL.add(lActivityEvent);
			}
		}
		
		for (ActivityEvent activityEventPending : activityEventPendingAL) {
			lActivityEvents.remove(activityEventPending);
		}
		
		return activityEventPendingAL;
	}
	
	private ArrayList<ActivityEvent> findInProcessActivities(ArrayList<ActivityEvent> lActivityEvents) {
		
		for (ActivityEvent lActivityEvent : lActivityEvents) {
			
			if (lActivityEvent.getProcessingStatusValue().equals(BPMConstants.PROCESSING_STATUS_INPROCESS)) {
				activityEventInProcessAL.add(lActivityEvent);
			}
		}
		
		for (ActivityEvent activityEventInProcess : activityEventInProcessAL) {
			lActivityEvents.remove(activityEventInProcess);
		}
		
		return activityEventInProcessAL;
	}
	
	
	
	private void reconcileActivitiesToIncentedTables(Collection<ActivityEvent> lActivityEvents) throws Exception {
		Collection<ProgramIncentiveOption> lProgramIncentiveOptions = null;
		Collection<QualificationCheckmark> lQualificationCheckmarks = null;
		Collection<EligibleProgramActivity> lEligibleProgramActivities = null;
		Map<Integer, Collection<ProgramIncentiveOption>> programIncentiveOptionsMAP = new HashMap<Integer, Collection<ProgramIncentiveOption>>();
		Map<Integer, Collection<QualificationCheckmark>> qualificationCheckmarksMAP = new HashMap<Integer, Collection<QualificationCheckmark>>();
		Map<Integer, Collection<EligibleProgramActivity>> eligibleProgramActivitiesMAP = new HashMap<Integer, Collection<EligibleProgramActivity>>();
			
		for (ActivityEvent lActivityEvent : lActivityEvents) {
			
			ProgramIncentiveOption lProgramIncentiveOption;
			Integer programID = lActivityEvent.getMemberActivity().getBusinessProgramID();
			Integer personID =  lActivityEvent.getMemberActivity().getPersonID();
			boolean incentiveOptionLeadToReward = false;
			//go out and get contract number from person baseline through a lookup method.
			
			MemberProgramUpdateTO memberContract = 
					contractDAO.getMemberContractStatus(null, personID, programID);	
			//if null returned for memberContract, indicates that no eligibility is available
			//under the business program so bypass.
			if (memberContract != null) {
				
				Integer contractNo = memberContract.getContractNumber();
				
				//check for first time through and break in programID.
				if (!programIncentiveOptionsMAP.containsKey(programID)) {
					lProgramIncentiveOptions = businessProgramService.getProgramIncentiveOptions(programID);
					lProgramIncentiveOptions = getProgramIncentiveOptionIncentiveRequirements(programID, lProgramIncentiveOptions);
					lQualificationCheckmarks = businessProgramService.getQualificationCheckmarks(programID);
					lQualificationCheckmarks = getCheckmarkRequirements(lQualificationCheckmarks);
					lProgramIncentiveOptions = searchNRemoveProgramIncentiveOptionHealthyMessageNCheckmark(lProgramIncentiveOptions, lQualificationCheckmarks);
					lEligibleProgramActivities = businessProgramService.getEligibleProgramActivities(programID);
					programIncentiveOptionsMAP.put(programID, lProgramIncentiveOptions);
					qualificationCheckmarksMAP.put(programID, lQualificationCheckmarks);
					eligibleProgramActivitiesMAP.put(programID, lEligibleProgramActivities);
					
				} else {
					lProgramIncentiveOptions = programIncentiveOptionsMAP.get(programID);
					lQualificationCheckmarks = qualificationCheckmarksMAP.get(programID);
					lEligibleProgramActivities = eligibleProgramActivitiesMAP.get(programID);
				}
				Boolean activityIncented = null;
				if (isActivityEligible(lActivityEvent, lEligibleProgramActivities)) {
					lProgramIncentiveOption = findProgramIncentiveOptionMatchingToActivityRequirements(lActivityEvent, lQualificationCheckmarks, lProgramIncentiveOptions);
					if (lProgramIncentiveOption != null) {
						incentiveOptionLeadToReward = isIncentiveOptionLeadToReward(lProgramIncentiveOption.getIncentiveOption().getIncentiveOptionName());
					} else {
						incentiveOptionLeadToReward = false;
					}
					if (lProgramIncentiveOption != null && incentiveOptionLeadToReward) {
						
						lProgramIncentiveOption.setProgramContributionGrids(businessProgramService.getProgramContributionGrids(lProgramIncentiveOption.getProgramIncentiveOptionID()));
					
						Integer incentiveOptionID = lProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID();
						Integer programIncentiveOptionID = lProgramIncentiveOption.getProgramIncentiveOptionID();
						String incentedStatusTypeCode = lProgramIncentiveOption.getIncentedStatusTypeCode();
						String incentiveOptionTypeCode = lProgramIncentiveOption.getIncentiveOption().getIncentiveOptionTypeCode();
						boolean contributionGridExists = false;
						if (lProgramIncentiveOption.getProgramContributionGrids() != null && 
								lProgramIncentiveOption.getProgramContributionGrids().size() > 0) {
							contributionGridExists = true;
						} else {
							//if contribution grid does not exist, then activity will not lead to an incentive reward.
							incentiveOptionLeadToReward = false;
						}
						//if incentive requirements exist, then program incentive option is activity based.
						if (lProgramIncentiveOption.getIncentiveRequirements() != null && 
								lProgramIncentiveOption.getIncentiveRequirements().size() > 0) {
							ArrayList<IncentiveRequirement> lIncentiveRequirements = lProgramIncentiveOption.getIncentiveRequirements();
							activityIncented = processActivityAgainstActivityRequirement(lIncentiveRequirements, programID, incentiveOptionID, programIncentiveOptionID, incentedStatusTypeCode, incentiveOptionTypeCode,  lActivityEvent, contractNo);
							 
								//Check for qualification checkmarks to indicate program incentive option is contract or member based incentive. 
						} else if (lQualificationCheckmarks.size() > 0) {
									//when a contribution grid exists, activity configured to be incented at the contract and member based level
									if (contributionGridExists) { 
										activityIncented = processActivityAgainstCheckmarkRequirements(lQualificationCheckmarks, programID, incentiveOptionID, programIncentiveOptionID,  incentedStatusTypeCode, incentiveOptionTypeCode, lActivityEvent, contractNo);
										//if not activity incented
										if (!activityIncented) {
											//if not found in ...
											if (!activityNotIncentedForCheckmarkAL.contains(lActivityEvent)) {
												if (isMemberProgramActivityNotAlreadyIncentedFromDuplicate(lActivityEvent)) {
													activityNotIncentedForCheckmarkAL.add(lActivityEvent);
												}
											}
										}
									}
								
						} //end else
					}//end if 
					
				//end if begin else	
				} else {
					activityNotProgramEligibleAL.add(lActivityEvent);
				}
				
				if (incentiveOptionLeadToReward || (activityIncented != null && activityIncented)) {
					if (!activityNotProgramEligibleAL.contains(lActivityEvent)) {
						if (activityIncented != null && activityIncented.FALSE) {
							activityNonRewardedAL.add(lActivityEvent);
							//0001 is HA
						} else if (isHA(lActivityEvent.getMemberActivity().getActivityDefinition().getSourceActivityID()) && activityIncented.FALSE) {		
									//indicates that HA is present along with program's taken.
									//this will happen when an incented status type of multi activity, contract_based, or member_based
									// is present along with a qualification checkmark that requires an HA along with a program.
									activityHABypassedAlongWithProgramAL.add(lActivityEvent);
						}
					}
				} else {
					
					activityNotLeadToRewardAL.add(lActivityEvent);
					
				}
			} //end if (bypass activity event if no member contract found.
		}//end for loop
		
		
		removeActivityNotInCheckmarkIfIncentedByActivityTypes();
		
	}
	
	
	private boolean isMemberProgramActivityNotAlreadyIncentedFromDuplicate(ActivityEvent lActivityEvent) {
		boolean memberProgramActivityNotIncented = true;
		for (PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus : this.memberProgramActivityIncentiveStatusForHraAL) {
			if (lPersonProgramActivityIncentiveStatus.getMemberNo().equals(lActivityEvent.getMemberActivity().getMemberID()) &&
					lPersonProgramActivityIncentiveStatus.getProgramID().equals(lActivityEvent.getMemberActivity().getBusinessProgramID()) &&
						lPersonProgramActivityIncentiveStatus.getActivityID().equals(lActivityEvent.getMemberActivity().getActivity().getActivityID())) {
				memberProgramActivityNotIncented = false;
				break;
			}
		}
		
		for (PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus : this.memberProgramActivityIncentiveStatusForHsaAL) {
			if (lPersonProgramActivityIncentiveStatus.getMemberNo().equals(lActivityEvent.getMemberActivity().getMemberID()) &&
					lPersonProgramActivityIncentiveStatus.getProgramID().equals(lActivityEvent.getMemberActivity().getBusinessProgramID()) &&
						lPersonProgramActivityIncentiveStatus.getActivityID().equals(lActivityEvent.getMemberActivity().getActivity().getActivityID())) {
				memberProgramActivityNotIncented = false;
				break;
			}
		}
		
		if (this.activityNotIncentedForMemberBasedAL.contains(lActivityEvent)) {
			this.activityNotIncentedForMemberBasedAL.remove(lActivityEvent);
		}
		
		return memberProgramActivityNotIncented;
	}
	
	private void reconcileActivitiesIncentedToFulfillmentTables(StatusCalculationCommand statusCalculationCommand, String groupName, String groupNo) throws Exception {
		 
		 ArrayList<PersonProgramActivityIncentiveStatus> personProgramActivityIncentiveStatusForHraHsaALL = new ArrayList<PersonProgramActivityIncentiveStatus> ();
		 ArrayList<PersonProgramActivityIncentiveStatus> personProgramActivityIncentiveStatusForIntelispendALL = new ArrayList<PersonProgramActivityIncentiveStatus> ();
		 
		 if (this.personProgramActivityIncentiveStatusForHraAL.size() > 0) {
			 personProgramActivityIncentiveStatusForHraHsaALL.addAll(this.personProgramActivityIncentiveStatusForHraAL);
		 }
		 if (this.personProgramActivityIncentiveStatusForHsaAL.size() > 0) {
			 personProgramActivityIncentiveStatusForHraHsaALL.addAll(this.personProgramActivityIncentiveStatusForHsaAL);
		 }
		 if (this.memberProgramActivityIncentiveStatusForHraAL.size() > 0) {
			 personProgramActivityIncentiveStatusForHraHsaALL.addAll(this.memberProgramActivityIncentiveStatusForHraAL);
		 }
		 if (this.memberProgramActivityIncentiveStatusForHsaAL.size() > 0) {
			 personProgramActivityIncentiveStatusForHraHsaALL.addAll(this.memberProgramActivityIncentiveStatusForHsaAL);
		 }
		 if (this.personProgramActivityIncentiveStatusForIntelispendAL.size() > 0) {
			 personProgramActivityIncentiveStatusForIntelispendALL.addAll(this.personProgramActivityIncentiveStatusForIntelispendAL);
		 }
		 if (this.memberProgramActivityIncentiveStatusForIntelispendAL.size() > 0) {
			 personProgramActivityIncentiveStatusForIntelispendALL.addAll(this.memberProgramActivityIncentiveStatusForIntelispendAL);
		 }
		 
		 if (personProgramActivityIncentiveStatusForHraHsaALL.size() > 0) {
			 reconcileActivitiesIncentedToHraHsaFulfillmentTable(statusCalculationCommand, personProgramActivityIncentiveStatusForHraHsaALL, groupName, groupNo);
		 }
		 
		 if (personProgramActivityIncentiveStatusForIntelispendALL.size() > 0) {
			 reconcileActivitiesIncentedToRewardFulfillmentTable(statusCalculationCommand, personProgramActivityIncentiveStatusForIntelispendALL, groupName, groupNo);
		 }
		
	}
	
	
	/*
	 * Search for and remove the healthy message program incentive option and corresponding qualification checkmark.
	 */
	private Collection<ProgramIncentiveOption>  searchNRemoveProgramIncentiveOptionHealthyMessageNCheckmark(Collection<ProgramIncentiveOption> lProgramIncentiveOptions, Collection<QualificationCheckmark> lQualificationCheckmarks) {
		ArrayList<ProgramIncentiveOption> lProgramIncentiveOptionsHealthyMessage = new ArrayList<ProgramIncentiveOption>();
		
		for (ProgramIncentiveOption lProgramIncentiveOption : lProgramIncentiveOptions) {
			if (lProgramIncentiveOption.getIncentiveOption().getIncentiveOptionName().equals("healthyMessage")) {
				lProgramIncentiveOptionsHealthyMessage.add(lProgramIncentiveOption);
			}
		}
		
		//now remove checkmark that corresponds to the healthy message incentive option..
		if (lProgramIncentiveOptionsHealthyMessage.size() > 0) {
			for (ProgramIncentiveOption lProgramIncentiveOptionHealthyMessage : lProgramIncentiveOptionsHealthyMessage) {
				lProgramIncentiveOptions.remove(lProgramIncentiveOptionHealthyMessage);
				searchNRemoveQualificationCheckmarkHealthyMessage(lProgramIncentiveOptionHealthyMessage.getProgramIncentiveOptionID(), lQualificationCheckmarks);
			}
		}
		
		return lProgramIncentiveOptions;
	}
	
	/*
	 * Search for and remove the healthy message qualification checkmark.
	 */
	private Collection<QualificationCheckmark> searchNRemoveQualificationCheckmarkHealthyMessage(Integer programIncentiveOption, Collection<QualificationCheckmark> lQualificationCheckmarks) {
		ArrayList<QualificationCheckmark> lQualificationCheckmarksHealthyMessage = new ArrayList<QualificationCheckmark>();
		
		for (QualificationCheckmark lQualificationCheckmark : lQualificationCheckmarks) {
			if (lQualificationCheckmark.getProgramIncentiveOptionID().equals(programIncentiveOption)) {
				lQualificationCheckmarksHealthyMessage.add(lQualificationCheckmark);
			}
		}
		
		if (lQualificationCheckmarksHealthyMessage.size() > 0) {
			for (QualificationCheckmark lQualificationCheckmarkHealthyMessage : lQualificationCheckmarksHealthyMessage) {
				lQualificationCheckmarks.remove(lQualificationCheckmarkHealthyMessage);
			}
		}
		
		return lQualificationCheckmarks;
	}
	
	private void removeActivityNotInCheckmarkIfIncentedByActivityTypes() {
		
		removeNonIncentedActivitiesIfIncented(this.activityNoMatchToActivityRequirementAL, this.personProgramActivityIncentiveStatusForHraAL);
		removeNonIncentedActivitiesIfIncented(this.activityNoMatchToActivityRequirementAL, this.personProgramActivityIncentiveStatusForHsaAL);
		removeNonIncentedActivitiesIfIncented(this.activityNoMatchToActivityRequirementAL, this.personProgramActivityIncentiveStatusForIntelispendAL);
	}
	
	private void removeNonIncentedActivitiesIfIncented(Collection<ActivityEvent> activityNotIncentedForActivityBasedRequirementsAL, Collection<PersonProgramActivityIncentiveStatus>  personProgramActivityIncentiveStatusAL) {
		
		ArrayList<ActivityEvent> lActivityEventsNotIncentedToRemoveAL = new ArrayList<ActivityEvent>();
		if (personProgramActivityIncentiveStatusAL != null &&
				personProgramActivityIncentiveStatusAL.size() > 0) {
				for (ActivityEvent lActivityEvent : activityNotIncentedForActivityBasedRequirementsAL) {
					for (PersonProgramActivityIncentiveStatus personProgramActivityIncentiveStatus : personProgramActivityIncentiveStatusAL) {
						if (lActivityEvent.getMemberActivity().getBusinessProgramID().equals(personProgramActivityIncentiveStatus.getProgramID()) &&
								lActivityEvent.getPersonDemographicsID().equals(personProgramActivityIncentiveStatus.getPersonDemographicsID()) &&
									lActivityEvent.getMemberActivity().getActivity().getActivityID().equals(personProgramActivityIncentiveStatus.getActivityID())) {
							lActivityEventsNotIncentedToRemoveAL.add(lActivityEvent);
						}
					}
				}
		}
		
		if (lActivityEventsNotIncentedToRemoveAL.size() > 0) {
			for (ActivityEvent lActivityEvent : lActivityEventsNotIncentedToRemoveAL) {
				activityNotIncentedForActivityBasedRequirementsAL.remove(lActivityEvent);
			}
		}
	}
	
	private ProgramIncentiveOption findProgramIncentiveOptionMatchingToActivityRequirements(ActivityEvent lActivityEvent, Collection<QualificationCheckmark> lQualificationCheckmarks, Collection<ProgramIncentiveOption> lProgramIncentiveOptions) {
		
		ProgramIncentiveOption lProgramIncentiveOptionResult = null;
		
		boolean isActivityBasedConfiguration = false;
		
		//if activity requirements are configured to the program incentive option, indicates an activity based configuration.
		for (ProgramIncentiveOption lProgramIncentiveOption : lProgramIncentiveOptions) {
			Collection<IncentiveRequirement> lIncentiveRequirements = lProgramIncentiveOption.getIncentiveRequirements();
			if (lIncentiveRequirements != null && lIncentiveRequirements.size() > 0) {
				isActivityBasedConfiguration = true;
				if (isActivityPartOfIncentiveRequirement(lActivityEvent, lIncentiveRequirements)) {
					lProgramIncentiveOptionResult = lProgramIncentiveOption;
					break;
				}
				
			}
		}
		
		if (lProgramIncentiveOptionResult == null && lQualificationCheckmarks != null) {
			for (ProgramIncentiveOption lProgramIncentiveOption : lProgramIncentiveOptions) {
				QualificationCheckmark lQualificationCheckmark = getActivityPartOfQualificationCheckmark(lActivityEvent, lQualificationCheckmarks, lProgramIncentiveOption);
				if (lQualificationCheckmark == null) {
					if (isActivityBasedConfiguration) {
						activityNoMatchToActivityRequirementAL.add(lActivityEvent);
					} 
				} else {
						lProgramIncentiveOptionResult = lProgramIncentiveOption;
						break;	
				}
				
			}
			
			//if activity based configuration and not part of any incentive requirement across program incentive options
		} else if (isActivityBasedConfiguration && lProgramIncentiveOptionResult == null) {
					if (isNotDuplicateOfActivityEvent(lActivityEvent, this.activityNoMatchToActivityRequirementAL)) {
						activityNoMatchToActivityRequirementAL.add(lActivityEvent);
					}
		}
		
		return lProgramIncentiveOptionResult;
	}
	
	private boolean processActivityAgainstCheckmarkRequirements(Collection<QualificationCheckmark> lQualificationCheckmarks, Integer programID, Integer incentiveOptionID, Integer programIncentiveOptionID,
				 String incentedStatusTypeCode, String incentiveOptionTypeCode, ActivityEvent lActivityEvent, Integer contractNo) throws Exception  {
		boolean activityIncented = false;
		
		for (QualificationCheckmark lQualificationCheckmark : lQualificationCheckmarks) {
			if (lQualificationCheckmark.getProgramIncentiveOptionID().equals(programIncentiveOptionID)) {
				ArrayList<CheckmarkRequirement> lCheckmarkRequirements = lQualificationCheckmark.getCheckmarkRequirements();
				//1. Indicates a straight one to one activity event to incentive table reconciliation.
				 if (isActivityPartOfCheckmarkRequirement(lActivityEvent, lCheckmarkRequirements)) {
					if (lCheckmarkRequirements.size() == 1) {
						activityIncented = determineActivityIncentedForOneCheckmarkRequirement(lActivityEvent, incentedStatusTypeCode, incentiveOptionTypeCode, programID, incentiveOptionID, contractNo);
					} else if (lCheckmarkRequirements.size() > 1) {
								activityIncented =  determineActivityIncentedForMultipleCheckmarkRequirementsWithHA(lActivityEvent, incentedStatusTypeCode, incentiveOptionTypeCode, programID, incentiveOptionID, contractNo);
					}
				 }
				 if (activityIncented) {
					 break;
				 }
		   }
		}
		
		return activityIncented;
	}
	
	
	private Boolean processActivityAgainstActivityRequirement(ArrayList<IncentiveRequirement> lIncentiveRequirements, Integer programID, Integer incentiveOptionID,
			Integer programIncentiveOptionID, String incentedStatusTypeCode, String incentiveOptionTypeCode, ActivityEvent lActivityEvent, Integer contractNo) throws Exception  {
	Boolean activityIncented = false;
	
	if (isActivityPartOfIncentiveRequirement(lActivityEvent, lIncentiveRequirements)) {
		//1. Indicates a straight one to one activity event to incentive table reconciliation.
		if (lIncentiveRequirements.size() == 1) {
			activityIncented = determineActivityIncentedForOneActivityRequirement(lActivityEvent, incentedStatusTypeCode, incentiveOptionTypeCode, programID, incentiveOptionID, contractNo);
		} else if (lIncentiveRequirements.size() > 1) {
				activityIncented = determineActivityIncentedForMultipleActivityRequirementsWithHA(lActivityEvent, incentedStatusTypeCode, incentiveOptionTypeCode, programID, incentiveOptionID, contractNo);
		}
	}
	return activityIncented;
}
	
	private boolean determineActivityIncentedForOneCheckmarkRequirement(ActivityEvent lActivityEvent, String incentedStatusTypeCode, String incentiveOptionTypeCode, Integer programID, Integer incentiveOptionID, Integer contractNo) throws Exception {
		boolean activityIncented = false;
		
		
		if(BPMConstants.BPM_INCENTED_STATUS_TYPE_MEMBER_BASED.equals((incentedStatusTypeCode)))
		{
			Integer personDemographicsID = lActivityEvent.getPersonDemographicsID();
			Integer activityID = lActivityEvent.getMemberActivity().getActivity().getActivityID();
			
			boolean activityIncentiveDetailIncented = false;
			
			PersonProgramActivityIncentiveStatus lMemberProgramActivityIncentiveStatus = memberService.getMemberPgmActivityIncentiveStatusNDetail(programID, personDemographicsID, incentiveOptionID, activityID);
			if (lMemberProgramActivityIncentiveStatus != null) {
				lMemberProgramActivityIncentiveStatus.setPurchaserSubtypeName(lActivityEvent.getPurchaserSubtypeName());
				activityIncentiveDetailIncented = determineActivityIncented(lMemberProgramActivityIncentiveStatus.getIncentiveStatusActivityDetails());
			} else {
				this.activityNotIncentedForMemberBasedAL.add(lActivityEvent);
				return activityIncented;
			}
			LookUpValueCode lLookUpValueCode = lookUpValueService.getLUVCodeByID(lMemberProgramActivityIncentiveStatus.getActivityStatusCodeID());
			String luvValue = lLookUpValueCode.getLuvVal();
			if (luvValue.equals(BPMConstants.ACTIVITY_STATUS_INCENTIVE_NOT_ACHIEVED)) {
				//ignore if not achieved since no activity incentive would be included.
			} else if (isCDHPHRA(incentiveOptionTypeCode, null)) {
				if (activityIncentiveDetailIncented) {
					memberProgramActivityIncentiveStatusForHraAL.add(lMemberProgramActivityIncentiveStatus);
					removeHRAHSAActivityIfMarkedForNotIncented(lActivityEvent);
					activityIncented = true;	
				}  else {
					this.activityNotIncentedForMemberBasedAL.add(lActivityEvent);
				}
			} else if (isCDHPHSA(incentiveOptionTypeCode, null)) {
						if (activityIncentiveDetailIncented) {						
							memberProgramActivityIncentiveStatusForHsaAL.add(lMemberProgramActivityIncentiveStatus);
							removeHRAHSAActivityIfMarkedForNotIncented(lActivityEvent);
							activityIncented = true;
						} else {
							this.activityNotIncentedForMemberBasedAL.add(lActivityEvent);
						}
			} else if (isIntelispend(incentiveOptionTypeCode)) {
						if (activityIncentiveDetailIncented) {
							memberProgramActivityIncentiveStatusForIntelispendAL.add(lMemberProgramActivityIncentiveStatus);
							activityIncented = true;
						}else {
							this.activityNotIncentedForMemberBasedAL.add(lActivityEvent);
						}
			} 
			
		} else if(BPMConstants.BPM_INCENTED_STATUS_TYPE_CONTRACT_BASED.equals((incentedStatusTypeCode))) {
					Collection<ContractProgramIncentiveTO> lContractProgramIncentiveTOs = businessProgramService.getContractProgramIncentive(programID, incentiveOptionID, contractNo);
					if (lContractProgramIncentiveTOs != null && lContractProgramIncentiveTOs.size() > 0) {
						ContractProgramIncentiveTO lContractProgramIncentiveTO = lContractProgramIncentiveTOs.iterator().next();
						//If no activity incentive detail, then check
						if (lContractProgramIncentiveTO.getIncentiveStatusActivityDetails().size() == 0) {
							this.activityNotIncentedForContractBasedAL.add(lActivityEvent);
						} else {
							//if not in arraylist, then add
							if (!this.activityIncentedForContractBasedAL.contains(lActivityEvent)) {
								this.activityIncentedForContractBasedAL.add(lActivityEvent);
								activityIncented = true;
							}
						}
				}
		}
		
		return activityIncented;
	}
	
	/*
	 * This method exists so that if the same activity event is assigned to both HSA and HRA forming duplicates,
	 * one of these activities will be flagged as not being incented and will need to be removed from the 
	 * activityNotIncentedForCheckmarkAL array so it doesn't show up in the report.
	 */
	private void removeHRAHSAActivityIfMarkedForNotIncented(ActivityEvent lActivityEvent) {
		ActivityEvent activityEventToRemove = null;
		for (ActivityEvent activityEventNotIncented: activityNotIncentedForCheckmarkAL) {
			if (activityEventNotIncented.getMemberActivity().getMemberID().equals(lActivityEvent.getMemberActivity().getMemberID()) &&
					activityEventNotIncented.getMemberActivity().getActivity().getActivityID().equals(lActivityEvent.getMemberActivity().getActivity().getActivityID()) &&
						activityEventNotIncented.getMemberActivity().getBusinessProgramID().equals(lActivityEvent.getMemberActivity().getBusinessProgramID())) {
				activityEventToRemove = activityEventNotIncented;
				break;
			}	
		}
		
		if (activityNotIncentedForCheckmarkAL.contains(activityEventToRemove)) {
			activityNotIncentedForCheckmarkAL.remove(activityEventToRemove);
		}
	}
	
	/*
	 * If incented detail exists, then activity was incented.
	 */
	private boolean determineActivityIncented(Collection<IncentiveStatusActivityDetail> incentiveStatusActivityDetails) {
		boolean activityIncentiveDetailIncented = false;
		
		if (incentiveStatusActivityDetails != null && incentiveStatusActivityDetails.size() > 0) {
			
			activityIncentiveDetailIncented = true;
			
		}
		
		return activityIncentiveDetailIncented;
	}
	
	private boolean determineActivityIncentedForOneActivityRequirement(ActivityEvent lActivityEvent, String incentedStatusTypeCode, String incentiveOptionTypeCode, Integer programID, Integer incentiveOptionID, Integer contractNo) throws Exception {
		boolean activityIncented = false;
		final String UNKNOWN = "UNKNOWN";
		if(isActivityBased(incentedStatusTypeCode)) {
			Integer personDemographicsID = lActivityEvent.getPersonDemographicsID();
			Integer activityID = lActivityEvent.getMemberActivity().getActivity().getActivityID();
			Date activityStatusDate = BPMUtils.calendarToSqlDate(lActivityEvent.getMemberActivity().getCompletionDate());
			Integer contributionAmt = lActivityEvent.getMemberActivity().getContributionAmt();
			PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus = personDAO.getPersonPgmActivityIncentiveStatusEnhanced(programID, personDemographicsID, activityID, activityStatusDate, contributionAmt);
			if (lPersonProgramActivityIncentiveStatus == null) {
				//it's possible that activity status date does not match.
				//see if match without passing activity status date.
				lPersonProgramActivityIncentiveStatus = personDAO.getPersonPgmActivityIncentiveStatusEnhanced(programID, personDemographicsID, activityID, null, contributionAmt);
			}
			String purchaserSubtypeName = lActivityEvent.getPurchaserSubtypeName();
			
			if (lPersonProgramActivityIncentiveStatus != null && !isIntelispend(incentiveOptionTypeCode)) {
				
				lPersonProgramActivityIncentiveStatus.setPurchaserSubtypeName(purchaserSubtypeName);
				//if package is null and 
				//current date is outside the package coverage effective dates, look to
				//see if activity was previously fulfilled and use the purchaser sub type from that.
				if (purchaserSubtypeName == null) {
					Collection<CDHPFulfillmentTrackingReportHist> lCDHPFulfillmentTrackingReportHistCL = memberService.getCDHPFulfillmentTrackingReportHist(null, programID, personDemographicsID, activityID);
					if (lCDHPFulfillmentTrackingReportHistCL != null && lCDHPFulfillmentTrackingReportHistCL.size() > 0) {
						CDHPFulfillmentTrackingReportHist lCDHPFulfillmentTrackingReportHist = lCDHPFulfillmentTrackingReportHistCL.iterator().next();
						purchaserSubtypeName = lCDHPFulfillmentTrackingReportHist.getPackageSubTypeName();
					} 
				}
			}
			
			//if incented record not found.
			if (lPersonProgramActivityIncentiveStatus == null || purchaserSubtypeName.equals(UNKNOWN)) {	
				this.activityNotIncentedForActivityBasedRequirementsAL.add(lActivityEvent);		
			//if incented record found
			} else if (isCDHPHRA(null,purchaserSubtypeName)) {
						if (this.personProgramActivityIncentiveStatusForHraAL.isEmpty()) {
							this.personProgramActivityIncentiveStatusForHraAL.add(lPersonProgramActivityIncentiveStatus);
							activityIncented = true;
						} else {
							
							if (isNotDuplicateOfPersonProgramActivityIncentiveStatus(lPersonProgramActivityIncentiveStatus, personProgramActivityIncentiveStatusForHraAL)) {
								this.personProgramActivityIncentiveStatusForHraAL.add(lPersonProgramActivityIncentiveStatus);
								activityIncented = true;
							}
						}

			} else if (isCDHPHSA(null,purchaserSubtypeName)) {
						if (this.personProgramActivityIncentiveStatusForHsaAL.isEmpty()) {
							this.personProgramActivityIncentiveStatusForHsaAL.add(lPersonProgramActivityIncentiveStatus);
							activityIncented = true;
						} else {
							if (isNotDuplicateOfPersonProgramActivityIncentiveStatus(lPersonProgramActivityIncentiveStatus, personProgramActivityIncentiveStatusForHsaAL)) {
								this.personProgramActivityIncentiveStatusForHsaAL.add(lPersonProgramActivityIncentiveStatus);
								activityIncented = true;
							}
						}
					
			} else {
					if (this.personProgramActivityIncentiveStatusForIntelispendAL.isEmpty()) {
						this.personProgramActivityIncentiveStatusForIntelispendAL.add(lPersonProgramActivityIncentiveStatus);
						activityIncented = true;
					} else {
						if (isNotDuplicateOfPersonProgramActivityIncentiveStatus(lPersonProgramActivityIncentiveStatus, personProgramActivityIncentiveStatusForIntelispendAL)) {
							this.personProgramActivityIncentiveStatusForIntelispendAL.add(lPersonProgramActivityIncentiveStatus);
							activityIncented = true;
						}
					}
			}
		}
		
		return activityIncented;
	}
	
	/*
	 * Find the first medical packages from the list of packages for the member.
	 */
	private PersonPackage findMedicalPackage(Collection<PersonPackage> lPersonPackages) {
		
		PersonPackage lPersonPackageResult = null;
		
		for (PersonPackage lPersonPackage : lPersonPackages) {
			if (lPersonPackage.getPackageType().equals("MEDICAL")) {
				lPersonPackageResult = lPersonPackage;
				break;
			}
		}
		
		return lPersonPackageResult;
		
	}
	
	private Boolean determineActivityIncentedForMultipleCheckmarkRequirementsWithHA(ActivityEvent lActivityEvent, String incentedStatusTypeCode, String incentiveOptionTypeCode, Integer programID, Integer incentiveOptionID, Integer contractNo) throws Exception 
	{
		Boolean activityIncented = false;
		StringBuffer formKey = new StringBuffer(); 
		formKey.append(String.valueOf(lActivityEvent.getMemberActivity().getBusinessProgramID())); 
		formKey.append(String.valueOf(lActivityEvent.getMemberActivity().getPersonDemographicsID()));
		
		if (lActivityEvent.getMemberActivity().getActivity().getActivityID() != null &&
				isHA(lActivityEvent.getMemberActivity().getActivityDefinition().getSourceActivityID())) {
				if (!haExistsForParticipantCheckmarkReqHM.containsKey(formKey.toString())) {
					haExistsForParticipantCheckmarkReqHM.put(formKey.toString(), lActivityEvent);
				}
				activityIncented = null;
				return activityIncented;
		}
		
		
		
		//check to see if HA taken for program being processed.
		if (haExistsForParticipantCheckmarkReqHM.containsKey(formKey.toString())) {
			Integer personDemographicsID = lActivityEvent.getPersonDemographicsID();
			Integer activityID = lActivityEvent.getMemberActivity().getActivity().getActivityID();
			boolean activityIncentiveDetailIncented = false;
			
			PersonProgramActivityIncentiveStatus lMemberProgramActivityIncentiveStatus = memberService.getMemberPgmActivityIncentiveStatusNDetail(programID, personDemographicsID, incentiveOptionID, activityID);
			
			if (lMemberProgramActivityIncentiveStatus != null) {
				lMemberProgramActivityIncentiveStatus.setPurchaserSubtypeName(lActivityEvent.getPurchaserSubtypeName());
				activityIncentiveDetailIncented = determineActivityIncented(lMemberProgramActivityIncentiveStatus.getIncentiveStatusActivityDetails());
			} else {
				this.activityNotIncentedForMemberBasedAL.add(lActivityEvent);
				return activityIncented;
			}
			
			
			LookUpValueCode lLookUpValueCode = lookUpValueService.getLUVCodeByID(lMemberProgramActivityIncentiveStatus.getActivityStatusCodeID());
			String luvValue = lLookUpValueCode.getLuvVal();
			if (luvValue.equals(BPMConstants.ACTIVITY_STATUS_INCENTIVE_NOT_ACHIEVED)) {
				//ignore if not achieved since no activity incentive would be included.
			
			} else if(BPMConstants.BPM_INCENTED_STATUS_TYPE_MEMBER_BASED.equals((incentedStatusTypeCode)))
			{
				if (isCDHPHRA(incentiveOptionTypeCode, null)) {
					if (activityIncentiveDetailIncented) {
						memberProgramActivityIncentiveStatusForHraAL.add(lMemberProgramActivityIncentiveStatus);
						activityIncented = true;
					}
				} else if (isCDHPHSA(incentiveOptionTypeCode, null)) {
							if (activityIncentiveDetailIncented) {
								memberProgramActivityIncentiveStatusForHsaAL.add(lMemberProgramActivityIncentiveStatus);
								activityIncented = true;
							}
				} else if (isIntelispend(incentiveOptionTypeCode)) {
							if (activityIncentiveDetailIncented) {
								memberProgramActivityIncentiveStatusForIntelispendAL.add(lMemberProgramActivityIncentiveStatus);
								activityIncented = true;
							}
				} else {
						this.activityNotIncentedForMemberBasedAL.add(lActivityEvent);
				}
			} else if(BPMConstants.BPM_INCENTED_STATUS_TYPE_CONTRACT_BASED.equals((incentedStatusTypeCode))) {
					Collection<ContractProgramIncentiveTO> lContractProgramIncentiveTOs = businessProgramService.getContractProgramIncentive(programID, incentiveOptionID, contractNo);
					if (lContractProgramIncentiveTOs != null && lContractProgramIncentiveTOs.size() > 0) {
						ContractProgramIncentiveTO lContractProgramIncentiveTO = lContractProgramIncentiveTOs.iterator().next();
						if (lContractProgramIncentiveTO.getIncentiveStatusActivityDetails().size() == 0) {
							this.activityNotIncentedForContractBasedAL.add(lActivityEvent);
						} else {
							if (!activityIncentedForContractBasedAL.contains(lActivityEvent)) {
								activityIncentedForContractBasedAL.add(lActivityEvent);
							}
						}
					}		
			} 
		} else {
			if(BPMConstants.BPM_INCENTED_STATUS_TYPE_MULTI_ACTIVITY.equals((incentedStatusTypeCode))) {
				activityWithNoHATakenForMultiActivityAL.add(lActivityEvent);
			}
		}
		
		return activityIncented;
	}
	
private Boolean determineActivityIncentedForMultipleActivityRequirementsWithHA(ActivityEvent lActivityEvent, String incentedStatusTypeCode, String incentiveOptionTypeCode, Integer programID, Integer incentiveOptionID, Integer contractNo) throws Exception {
	    Boolean activityIncented = false; 
	    StringBuffer formKey = new StringBuffer(); 
		formKey.append(String.valueOf(lActivityEvent.getMemberActivity().getBusinessProgramID())); 
		formKey.append(String.valueOf(lActivityEvent.getMemberActivity().getPersonDemographicsID()));
				
		if (lActivityEvent.getMemberActivity().getActivity().getActivityID() != null &&
				lActivityEvent.getMemberActivity().getActivity().getActivityID().intValue() == 37) { //check for HA
					if (!haExistsForParticipantCheckmarkReqHM.containsKey(formKey.toString())) {
						haExistsForParticipantCheckmarkReqHM.put(formKey.toString(), lActivityEvent);
					}
					activityIncented = null;
					return activityIncented;
		}
		
		//check to see if HA taken for program being processed.
		if (haExistsForParticipantCheckmarkReqHM.containsKey(formKey.toString())) {
					
			if(isActivityBased(incentedStatusTypeCode)) {
				Integer personDemographicsID = lActivityEvent.getPersonDemographicsID();
				Integer activityID = lActivityEvent.getMemberActivity().getActivity().getActivityID();
				Date activityStatusDate = BPMUtils.calendarToSqlDate(lActivityEvent.getMemberActivity().getCompletionDate());
				Integer contributionAmt = lActivityEvent.getMemberActivity().getContributionAmt();
				PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus = personDAO.getPersonPgmActivityIncentiveStatusEnhanced(programID, personDemographicsID, activityID, activityStatusDate, contributionAmt);
				lPersonProgramActivityIncentiveStatus.setPurchaserSubtypeName(lActivityEvent.getPurchaserSubtypeName());
				if (isCDHPHRA(incentiveOptionTypeCode, null)) {
					if (lPersonProgramActivityIncentiveStatus != null) {
						personProgramActivityIncentiveStatusForHraAL.add(lPersonProgramActivityIncentiveStatus);
						activityIncented = true;
					}
				} else if (isCDHPHSA(incentiveOptionTypeCode, null)) {
							if (lPersonProgramActivityIncentiveStatus != null) {
								personProgramActivityIncentiveStatusForHsaAL.add(lPersonProgramActivityIncentiveStatus);
								activityIncented = true;
							}
				} else if (isIntelispend(incentiveOptionTypeCode)) {
					if (lPersonProgramActivityIncentiveStatus != null) {
						personProgramActivityIncentiveStatusForIntelispendAL.add(lPersonProgramActivityIncentiveStatus);
						activityIncented = true;
					}
				}
			}
		}
		
		return activityIncented;
	}
	
	
	private boolean isActivityPartOfCheckmarkRequirement(ActivityEvent lActivityEvent, Collection<CheckmarkRequirement> lCheckmarkRequirements) {
		boolean activityFound = false;
		
		if (lCheckmarkRequirements == null) {
			return activityFound;
		}
		
		for (CheckmarkRequirement lCheckmarkRequirement : lCheckmarkRequirements) {
			Collection<CheckmarkDetail> lCheckmarkDetails = lCheckmarkRequirement.getCheckmarkDetails();
			for (CheckmarkDetail lCheckmarkDetail : lCheckmarkDetails) {
				if (lCheckmarkDetail.getActivityID() != null && lActivityEvent.getMemberActivity().getActivityDefinition().getActivityID() != null &&
							lCheckmarkDetail.getActivityID().equals(lActivityEvent.getMemberActivity().getActivityDefinition().getActivityID())) {
					activityFound = true;
					break;
				} else if (lCheckmarkDetail.getActivityTypeCodeID() != null && lActivityEvent.getMemberActivity().getActivityDefinition().getActivityTypeCodeID() != null &&
								lCheckmarkDetail.getActivityTypeCodeID().equals(lActivityEvent.getMemberActivity().getActivityDefinition().getActivityTypeCodeID())) {
							activityFound = true;
							break;	
				}
			}
			if (activityFound) {
				break;
			}
		}
		
		return activityFound;
	}
	
	private boolean isActivityPartOfIncentiveRequirement(ActivityEvent lActivityEvent, Collection<IncentiveRequirement> lIncentiveRequirements) {
		boolean activityFound = false;
		
		for (IncentiveRequirement lIncentiveRequirement : lIncentiveRequirements) {
			Collection<ActivityIncentive> lActivityIncentives = lIncentiveRequirement.getActivityIncentives();
			for (ActivityIncentive lActivityIncentive : lActivityIncentives) {
				if (lActivityIncentive.getActivityID() != null && lActivityIncentive.getActivityID() != null &&
						lActivityIncentive.getActivityID().equals(lActivityEvent.getMemberActivity().getActivity().getActivityID())) {
					activityFound = true;
					break;
				} else if (lActivityIncentive.getActivityTypeID() != null && lActivityEvent.getMemberActivity().getActivity().getActivityTypeCodeID() != null &&
						lActivityIncentive.getActivityTypeID().equals(lActivityEvent.getMemberActivity().getActivity().getActivityTypeCodeID())) {
							activityFound = true;
							break;	
				}
			}
			if (activityFound) {
				break;
			}
		}
		
		
		return activityFound;
	}
	
	/*
	 * Determine if incentive option will lead to an award based on incentive option configuration.
	 */
	private boolean isIncentiveOptionLeadToReward(String incentiveOptionName) {
		boolean incentiveOptionLeadToReward = true;
		
		if (incentiveOptionName.equals(BPMConstants.INCENTIVE_OPTION_TYPE_NAME_DESC_PREFERRED_BENEFIT) ||
				incentiveOptionName.startsWith(BPMConstants.INCENTIVE_OPTION_TYPE_NAME_DESC_NAME_PREMIUM_DISCOUNT) ||
					incentiveOptionName.equals(BPMConstants.INCENTIVE_OPTION_TYPE_NAME_DESC_TOBACCO)) {
			incentiveOptionLeadToReward = false;
		}
		
		return incentiveOptionLeadToReward;
	}
	
	private QualificationCheckmark getActivityPartOfQualificationCheckmark(ActivityEvent lActivityEvent, Collection<QualificationCheckmark> lQualificationCheckmarks, ProgramIncentiveOption lProgramIncentiveOption) {
		QualificationCheckmark lQualificationCheckmarkResult = null;
		
		for (QualificationCheckmark lQualificationCheckmark : lQualificationCheckmarks) {
			if (lProgramIncentiveOption.getProgramIncentiveOptionID().equals(lQualificationCheckmark.getProgramIncentiveOptionID())) {
				//must match on incentive option types between activity event and program incentive option.
				if (isCDHPHSA(null, lActivityEvent.getPurchaserSubtypeName()) || isCDHPHRA(null, lActivityEvent.getPurchaserSubtypeName())) {
					if (isCDHPHSA(lProgramIncentiveOption.getIncentiveOption().getIncentiveOptionTypeCode(), null) && isCDHPHSA(null, lActivityEvent.getPurchaserSubtypeName()) ||
							isCDHPHRA(lProgramIncentiveOption.getIncentiveOption().getIncentiveOptionTypeCode(), null) && isCDHPHRA(null, lActivityEvent.getPurchaserSubtypeName())) {
						if (isActivityPartOfCheckmarkRequirement(lActivityEvent, lQualificationCheckmark.getCheckmarkRequirements())) {
							lQualificationCheckmarkResult = lQualificationCheckmark;
							break;
						}
					}
				} else {
					//Other incentive option type exists besides HRA and HSA.  This would typicall be for reward cards.
					if (isActivityPartOfCheckmarkRequirement(lActivityEvent, lQualificationCheckmark.getCheckmarkRequirements())) {
						lQualificationCheckmarkResult = lQualificationCheckmark;
						break;
					}
				}
			}
		}
		
		
		return lQualificationCheckmarkResult;
	}
	
	
	/*
	 * Method compares by program id, person demographics id and activity id to determine if a duplicate exists.
	 */
	private boolean isNotDuplicateOfPersonProgramActivityIncentiveStatus(PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus, Collection<PersonProgramActivityIncentiveStatus> personProgramActivityIncentiveStatusAL) {
		boolean isNotDuplicate = true;
		
		
		for (PersonProgramActivityIncentiveStatus personProgramActivityIncentiveStatusCompare : personProgramActivityIncentiveStatusAL) {
			if (personProgramActivityIncentiveStatusCompare.getProgramID().equals(lPersonProgramActivityIncentiveStatus.getProgramID()) &&
					personProgramActivityIncentiveStatusCompare.getPersonDemographicsID().equals(lPersonProgramActivityIncentiveStatus.getPersonDemographicsID()) &&
							personProgramActivityIncentiveStatusCompare.getActivityID().equals(lPersonProgramActivityIncentiveStatus.getActivityID())) {
				isNotDuplicate = false;
				break;
			}
		}
		
		
		return isNotDuplicate;
	}
	
	/*
	 * Method compares by program id, person demographics id and activity id to determine if a duplicate exists.
	 */
	private boolean isNotDuplicateOfActivityEvent(ActivityEvent lActivityEvent, Collection<ActivityEvent> lActivityEventAL) {
		boolean isNotDuplicate = true;
		
		
		for (ActivityEvent lActivityEventCompare : lActivityEventAL) {
			if (lActivityEventCompare.getMemberActivity().getBusinessProgramID().equals(lActivityEvent.getMemberActivity().getBusinessProgramID()) &&
					lActivityEventCompare.getPersonDemographicsID().equals(lActivityEvent.getPersonDemographicsID()) &&
					lActivityEventCompare.getMemberActivity().getActivity().getActivityID().equals(lActivityEvent.getMemberActivity().getActivity().getActivityID())) {
				isNotDuplicate = false;
				break;
			}
		}
		
		
		return isNotDuplicate;
	}
	
	private boolean isHA(String sourceActivityID) { 
	   boolean isHA = false;
	   if (sourceActivityID.equals(BPMConstants.ACTIVITY_HEALTHY_BENEFITS_HA_ID)) {
		   isHA = true;
	   }
	   
	   return isHA;
	}
	
	
	private Collection<ProgramIncentiveOption> getProgramIncentiveOptionIncentiveRequirements(Integer programID, Collection<ProgramIncentiveOption> lProgramIncentiveOptions) throws com.healthpartners.service.imfs.exception.BPMException {
	
		for (ProgramIncentiveOption lProgramIncentiveOption : lProgramIncentiveOptions) {
			lProgramIncentiveOption.setIncentiveRequirements((ArrayList<IncentiveRequirement>)
			    businessProgramService.getIncentiveRequirements(programID,
			    		  lProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID()));
		}
		
		return lProgramIncentiveOptions;
	}
	
	private Collection<QualificationCheckmark> getCheckmarkRequirements(Collection<QualificationCheckmark> lQualificationCheckmarks) throws Exception {
	
		for (QualificationCheckmark lQualificationCheckmark: lQualificationCheckmarks) {
			Integer qualificationCheckmarkID = lQualificationCheckmark.getQualificationCheckmarkID();
			ArrayList<CheckmarkRequirement> lCheckmarkRequirements = (ArrayList<CheckmarkRequirement>)businessProgramService.getCheckmarkRequirements(qualificationCheckmarkID);
			lQualificationCheckmark.setCheckmarkRequirements(lCheckmarkRequirements);	
		}
		
		return lQualificationCheckmarks;
	}
	
	
	private boolean isActivityEligible(ActivityEvent lActivityEvent, Collection<EligibleProgramActivity> lEligibleProgramActivities) {
		boolean activityEligible = false;
		
		for (EligibleProgramActivity lEligibleProgramActivity : lEligibleProgramActivities) {
			if (lEligibleProgramActivity.getActivityID().equals(lActivityEvent.getMemberActivity().getActivity().getActivityID())) {
				activityEligible = true;
				break;
			}
		}
		
		return activityEligible;
	}
	
	private boolean isCDHPHRA(String incentiveOptionTypeCode, String packageSubTypeName) {
		boolean hra = false;
		
		if (packageSubTypeName != null) {
			if (BPMConstants.BPM_PRODUCT_SUBTYPE_HRA.equals(packageSubTypeName)) {
				//read member incented table to validate if activity event was incented.
				hra = true;
				if (!this.isHraExist) {
					setHraExist(true);
				}
			}
		} else if (incentiveOptionTypeCode != null) {
					if (BPMConstants.BPM_INCENTIVE_TYPE_HRA.equals(incentiveOptionTypeCode)) {
						//read member incented table to validate if activity event was incented.
						hra = true;
						if (!this.isHraExist) {
							setHraExist(true);
						}
					}
		}
		
		return hra;
	}
	
	private boolean isCDHPHSA(String incentiveOptionTypeCode, String packageSubTypeName) {
		boolean hsa = false;
		
		if (packageSubTypeName != null) {
			if (BPMConstants.BPM_PRODUCT_SUBTYPE_HSA.equals(packageSubTypeName)) {
				//read member incented table to validate if activity event was incented.
				hsa = true;
				if (!this.isHsaExist) {
					setHsaExist(true);
				}
			}
		} else if (incentiveOptionTypeCode != null) {
					if (BPMConstants.BPM_INCENTIVE_TYPE_HSA.equals(incentiveOptionTypeCode)) {
						//read member incented table to validate if activity event was incented.
						hsa = true;
						if (!this.isHsaExist) {
							setHsaExist(true);
						}
					}
		}
		
		return hsa;
	}
	
	private boolean isIntelispend(String incentiveOptionTypeCode) {
		boolean intelispend = false;
		
		if (BPMConstants.REWARD_BATCH_TYPE_INTELISPEND.equals(incentiveOptionTypeCode)) {
			//read member incented table to validate if activity event was incented.
			intelispend = true;
			if (!this.isIntelispendExist) {
				setIntelispendExist(true);
			}
		}
		
		return intelispend;
	}
	
	private boolean isActivityBased(String incentiveOptionTypeCode) {
		boolean isActivityBased = false;
		setMultiActivityBased(false);
		if (BPMConstants.BPM_INCENTED_STATUS_TYPE_ACTIVITY_BASED.equals(incentiveOptionTypeCode) ||
				BPMConstants.BPM_INCENTED_STATUS_TYPE_ACTIVITY_PACKAGE_BASED.equals(incentiveOptionTypeCode) ||
					BPMConstants.BPM_INCENTED_STATUS_TYPE_MULTI_ACTIVITY.equals(incentiveOptionTypeCode)
					) {
			//read member incented table to validate if activity event was incented.
			isActivityBased = true;
			if (BPMConstants.BPM_INCENTED_STATUS_TYPE_MULTI_ACTIVITY.equals(incentiveOptionTypeCode)) {
				setMultiActivityBased(true);
			}
		}
		
		return isActivityBased;
	}
	

	
	private void reconcileActivitiesIncentedToHraHsaFulfillmentTable(StatusCalculationCommand statusCalculationCommand, ArrayList<PersonProgramActivityIncentiveStatus> personProgramActivityIncentiveStatusForHraHsaALL, String groupName, String groupNo) throws Exception {
		String reason;
		statusCalculationCommand.setCurrentCommandText("CDHP Employer Activity Incent To Fulfill Reconciliation");
		
		Collection<PersonProgramActivityIncentiveStatus> lPersonActivityIncentToFulfillReconcileDifferences  = memberService.getCDHPPersonActivityIncentToFulfillReconciled(personProgramActivityIncentiveStatusForHraHsaALL);
	
		if (lPersonActivityIncentToFulfillReconcileDifferences != null && lPersonActivityIncentToFulfillReconcileDifferences.size() > 0) {
			reason = "Activity did not reconcile to fulfillment table.";				
			
		} else {
			reason = "ALL ACTIVITIES RECONCILED TO FULFILLMENT TABLE.";		
		}
		createPersonActivityIncentToFulfillReconciliationReport(statusCalculationCommand, lPersonActivityIncentToFulfillReconcileDifferences, reason,  groupName, groupNo);
		logger.info("@End - Processing Employer Activity Incent To Fulfillment Reconciliation Command. ");
	
	}
	

	private void reconcileActivitiesIncentedToRewardFulfillmentTable(StatusCalculationCommand statusCalculationCommand, ArrayList<PersonProgramActivityIncentiveStatus> personProgramActivityIncentiveStatusForHraHsaALL, String groupName, String groupNo) throws Exception {
		
		statusCalculationCommand.setCurrentCommandText("CDHP Employer Activity Incent To Fulfill Reconciliation");
		
		Collection<PersonProgramActivityIncentiveStatus> lPersonActivityIncentToFulfillReconcileDifferences  = memberService.getRewardPersonActivityIncentToFulfillReconciled(personProgramActivityIncentiveStatusForHraHsaALL);
		
		if (lPersonActivityIncentToFulfillReconcileDifferences != null && lPersonActivityIncentToFulfillReconcileDifferences.size() > 0) {
			String failureReason = "Activity did not reconcile to fulfillment table.";					
			createPersonActivityIncentToFulfillReconciliationReport(statusCalculationCommand, lPersonActivityIncentToFulfillReconcileDifferences, failureReason, groupName, groupNo);
		}
		
		logger.info("@End - Processing Employer Activity Incent To Fulfillment Reconciliation Command. ");
	
	}

/*
* Produce a list of those participants activities that were never fulfilled after being incented.
*/
private void createPersonActivityIncentToFulfillReconciliationReport(StatusCalculationCommand statusCalculationCommand, Collection<PersonProgramActivityIncentiveStatus> lPersonActivityIncentToFulfillReconcileDifferences, String reason, String groupName, String groupNo) throws com.healthpartners.service.imfs.exception.BPMException
{
	logger.info("@Start - Create Person Activity Incent To Fulfill Reconciliation Differences Detail Report. ");
	
	
	StringBuffer batchMailSubject = new StringBuffer();
	
	batchMailSubject
	.append("BPM Batch - Employer Activity Incented To Fulfilled Reconciliation for Group " + groupName + " - " + groupNo);
	
	
	StringBuffer batchMailContent = new StringBuffer();
	batchMailContent
	.append("<table>");
	batchMailContent.append("<tr><td>BPM Batch Name: Employer Activity Incented To Fulfilled Reconciliation Differences for Group " + groupName + " - " + groupNo + "</td></tr>");
	batchMailSubject.append("- SUCCESS");

	batchMailContent.append("<tr><td>Initiated User: "
			+ statusCalculationCommand.getUserID());
	
	batchMailContent.append("<tr></td>Result: SUCCESS</td></tr>");
	batchMailContent.append("<tr></td>Reason: \n");
	batchMailContent.append(reason + "</td></tr>");

	
	batchMailContent
	.append("</table>");
	batchMailContent
	.append("<table>");
	
	if (lPersonActivityIncentToFulfillReconcileDifferences.size() > 0) {
		Map<String, Integer> activitySummaryMap =  summarizeActivitiesNCounts(lPersonActivityIncentToFulfillReconcileDifferences);
		Set<String> keySet = activitySummaryMap.keySet();
		String activityDesc = null;
		Integer activityDescCount = null;
		batchMailContent
		.append("<tr><td>" + statusCalculationCommand.getCurrentCommandText() + " incented activities not fulfilled:  " + "</td></tr>");
		batchMailContent
		.append("<tr><td>-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
		batchMailContent
		.append("<tr><td>---------- A C T I V I T Y    N O T    F U L F I L L E D    S U M M A R Y ---------------------------------------------------------------------------------------------------------------</td></tr>");
		Iterator<String> key = keySet.iterator();
		while (key.hasNext()) {
			activityDesc = key.next();
			activityDescCount = activitySummaryMap.get(activityDesc);
			batchMailContent
			.append("<tr><td>--- " + activityDescCount +  " " + activityDesc + "</td></tr>");
		}
		batchMailContent
		.append("<tr><td>-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
	} 
	batchMailContent
	.append("</table>");
	
	if (lPersonActivityIncentToFulfillReconcileDifferences.size() > 0) {
		batchMailContent
		.append("<table>");
		batchMailContent
		.append("<tr><td>ACTIVITY INCENT TO FULFILL RECONCILIATION DIFFERENCES DETAIL REPORT" +  " </td></tr> ");
		batchMailContent
		.append("</table>");
		// column header
		batchMailContent
		.append("<table>");
		batchMailContent.append("<tr><td> Line</td><td>Group No</td><td>Site No</td><td>Member No</td><td>First Name</td><td>Last Name</td><td>Activity Name</td><td>Incented Date</td><td>Amount</td></tr>");
		
		Iterator<PersonProgramActivityIncentiveStatus> iter  = (Iterator<PersonProgramActivityIncentiveStatus>) lPersonActivityIncentToFulfillReconcileDifferences.iterator();
		int rowCt = 1;
    	while (iter.hasNext()) {
    		PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatusDifference = (PersonProgramActivityIncentiveStatus)iter.next();
				
    		batchMailContent
						.append("<tr><td colspan=12>----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
			batchMailContent.append("<tr><td> "
					+ rowCt + "</td><td>"
					+ lPersonProgramActivityIncentiveStatusDifference.getGroupNo() + "</td><td>"
					+ lPersonProgramActivityIncentiveStatusDifference.getSiteNo() + "</td><td>"
					+ lPersonProgramActivityIncentiveStatusDifference.getMemberNo() + "</td><td>" 
					+ lPersonProgramActivityIncentiveStatusDifference.getFirstName() + "</td><td>" 
					+ lPersonProgramActivityIncentiveStatusDifference.getLastName() + "</td><td>" 
					+ lPersonProgramActivityIncentiveStatusDifference.getActivityName() + "</td><td>" 
					+ lPersonProgramActivityIncentiveStatusDifference.getActivityStatusIncentiveDate() + "</td><td>" 
					+ lPersonProgramActivityIncentiveStatusDifference.getContributionAmt() + 	
					"</td></tr>");
			rowCt++;

			/*if (rowCt > 100) {
				batchMailContent
				.append("<tr><td>   </td></tr>");
				batchMailContent
				.append("<tr><td>   </td></tr>");
				//cap report list at 100
				batchMailContent
				.append("<tr><td colspan=12>***ATTENTION: REPORT CUTOFF AT 100 ROWS.  " + "A TOTAL OF " + lPersonActivityIncentToFulfillReconcileDifferences.size() + " MEMBER ACTIVITY INCENTIVES NOT FULFILLED.</td></tr>");
				break;
			}*/
		
    	} 
    	
	} 
	
	batchMailContent
	.append("</table>");
	
	emailService.setEmailDestination(BPMConstants.BPM_EMAIL_TO_ADDR_RECONCILE_RPT);
	emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
	emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
			batchMailContent.toString());
}
	
	/**
	 * prepare and send summary email
	 */
	private void prepareAndSendSummaryEmail(String groupNo, String groupName, String reconcileStartDateStr) {
		String emailServerHost = null;
		String emailFromAddress = null;
		String dbEnvirnment = "";
		List<String> emailToAddress = new ArrayList<String>();
		StringBuffer emailContent = new StringBuffer();
		StringBuffer emailSubject = new StringBuffer();
		java.util.Date startDate = new java.util.Date();
		Collection<LookUpValueCode> toAddress = null;
	
		
		try {

			Collection<LookUpValueCode> serverHost = lookUpValueService
					.getLUVCodesByGroup(BPMConstants.BPM_EMAIL_HOST_SRVR);
			Collection<LookUpValueCode> fromAddress = lookUpValueService
					.getLUVCodesByGroup(BPMConstants.BPM_EMAIL_FROM_ADDR);
			
			Collection<LookUpValueCode> dbEnvirnments = lookUpValueService
					.getLUVCodesByGroup(BPMConstants.BPM_DB_ENV);
			
			
			toAddress = lookUpValueService.getLUVCodesByGroup(BPMConstants.BPM_EMAIL_TO_ADDR_RECONCILE_RPT);

			// email server host
			Iterator<LookUpValueCode> itrHost = serverHost.iterator();
			if (itrHost.hasNext()) {
				LookUpValueCode lvalue = itrHost.next();
				emailServerHost = lvalue.getLuvDesc();
			}

			// from address
			Iterator<LookUpValueCode> itrTo = fromAddress.iterator();
			if (itrTo.hasNext()) {
				LookUpValueCode lvalue = itrTo.next();
				emailFromAddress = lvalue.getLuvDesc();
			}

		
			// to address
			Iterator<LookUpValueCode> itr = toAddress.iterator();
			while (itr.hasNext()) {
				LookUpValueCode lvalue = itr.next();
				emailToAddress.add(lvalue.getLuvDesc());
			}

			Iterator<LookUpValueCode> itrEnv = dbEnvirnments.iterator();
			while (itrEnv.hasNext()) {
				LookUpValueCode lvalue = itrEnv.next();
				dbEnvirnment = lvalue.getLuvDesc();
				break;
			}
			
			emailSubject
			.append("BPM Batch - Employer Activity Reconciliation for Group " + groupName + " - " + groupNo);
			
			emailContent.append("<table>");
			
			// prepare summary email body
			
			 
			emailContent.append("<table>");
			emailContent.append("<tr><td>Time Start:</td><td> "
					+ BPMUtils.getFormattedDateTime(startDate)
					+ "</td></tr>");
			emailContent.append("<tr><td>Purpose: To ensure participant activities for the group incented.</td></tr>");
			emailContent.append("<tr><td>Database Environment:</td>");
			emailContent.append("<td>" + dbEnvirnment + "</td></tr>");
			
			emailContent.append("<tr><td>Application Server:</td>");
			emailContent.append("<td>" + hostName + "</td></tr>");
			
			emailContent.append("<tr><td>Initiated User:</td><td> "
					+ userID + "</td></tr>");
			emailContent.append("</table>");
			emailContent.append("<table>");
			
			if (isEmployerActivitiesExist()) {
				appendSummaryTotals(emailContent);
				detailSummaryReport(emailContent);
				
			} else {
				emailContent
				.append("<tr><td></td><td></tr>");
				emailContent
				.append("<tr><td></td><td></tr>");
				emailContent
				.append("<tr><td>ATTENTION: No Employer Activity Event records to process!"
						+ "</td></tr>");
				emailContent
				.append("<tr><td></td><td></tr>");
				emailContent
				.append("<tr><td></td><td></tr>");
						
			}
			
			emailContent.append("</table>");
			
			emailContent.append("<table>");
			
			emailContent
			.append("<tr><td>*************************************************************************************************************************************************************************** </td><td>");
				
			
			emailContent.append("</table>");
			
			
			bpmEmailUtility.sendEmail(emailServerHost, emailFromAddress,
					emailToAddress, emailSubject.toString(), emailContent.toString(),
					bpmEmailUtility.EMAIL_CONTENT_TYPE_HTML, null);
		
		} catch (Exception e) {
			logger.debug(
					"Error occurred prior to sending Employer Activity Reconciliation email: "
							+ e.getMessage(), e);
			logger.debug("  emailToAddress=" + emailToAddress);
			logger.debug("  emailFromAddress=" + emailFromAddress);
			logger.debug("  emailSubject=" + emailSubject.toString());
			logger.debug("  emailContent=" + emailContent.toString());
		}
	}
	
	private void appendSummaryTotals(StringBuffer emailContent) {
		
		
		if (activityEventsAL != null) {
			HashMap<Integer, BPMBusinessProgram> lBPMBusinessProgramMap = new HashMap<Integer, BPMBusinessProgram>();
			
			for (ActivityEvent activityEvent : activityEventsAL) {
				BPMBusinessProgram  businessProgramDetail = businessProgramDAO.getBusinessProgramDetail(activityEvent.getMemberActivity().getBusinessProgramID());
				if (businessProgramDetail != null) {
					if (!lBPMBusinessProgramMap.containsKey(businessProgramDetail.getProgramID())) {
						lBPMBusinessProgramMap.put(businessProgramDetail.getProgramID(), businessProgramDetail);
					}
				}
			}
			
			emailContent.append("<table>");
			emailContent
			.append("<tr><td>-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
			emailContent
				.append("<tr><td>Participant activities are registered to the following Business program(s):</td></tr>");	
			emailContent.append("</table>");
			emailContent.append("<table>");
			if (!lBPMBusinessProgramMap.isEmpty()) {
				Collection<BPMBusinessProgram> lBPMBusinessPrograms = lBPMBusinessProgramMap.values();
				
				for (BPMBusinessProgram lBPMBusinessProgram : lBPMBusinessPrograms) {
						
					emailContent
						.append("<tr><td>Group Name: </td><td colspan=2>" + lBPMBusinessProgram.getGroupName() + "</td></tr>");
					emailContent
					.append("<tr><td>Group Number: </td><td>" + lBPMBusinessProgram.getGroupNumber() + "</td></tr>");
					emailContent
						.append("<tr><td>Site Name: </td><td>" + lBPMBusinessProgram.getSiteName() + "</td></tr>");
					emailContent
					.append("<tr><td>Site Number: </td><td>" + lBPMBusinessProgram.getSiteNumber() + "</td></tr>");
					emailContent
						.append("<tr><td>Effective Dates: </td><td>" + BPMUtils.formatDateMMddyyyy(lBPMBusinessProgram.getEffectiveDate()) + " | " + BPMUtils.formatDateMMddyyyy(lBPMBusinessProgram.getEndDate()) + "</td><td></tr>");
					emailContent
					.append("<tr><td>Participation Requirement: </td><td>" + lBPMBusinessProgram.getFamilyParticipationValue() + "</td></tr>");
					emailContent
						.append("<tr><td colspan=2>-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");		
				}
				
				emailContent
				.append("<tr><td></td><td></tr>");
			} else {
				emailContent
				.append("<tr><td>Business Program Not Available</td></tr>");	
			}
			
		}
		
		emailContent.append("</table>");
		
		emailContent.append("<table>");
		emailContent
		.append("<tr><td colspan=2>-------------------  N O    A C T I O N    T O    T A K E    S U M M A R Y    S E C T I O N------------------------------------------------------------------------------------------------------------------</td></tr>");		
		/*emailContent
		.append("<tr><td>--- " + this.inputRecordCount + " Activity Event records read.</td><td></tr> ");
				
		emailContent
		.append("<tr><td>--- " + this.activityEventDuplicatesAL.size() + " Duplicate Activity Event records removed.</td><td></tr> ");
				
		emailContent
		.append("<tr><td>--- " + this.activityEventFilteredOutDuplicatesAL.size() + " Duplicate Activity Event Filtered Out records removed.</td><td></tr> ");
		*/
		if (this.activityEventsAL != null) {
			emailContent
					.append("<tr><td>--- " + this.activityEventsToProcessCount + " Activity Event completers processed through reconciliation.</td><td></tr>");
							
		} 
		
		if (this.isHraExist) {
			String personProgramActivityIncentiveStatusForHraDesc = " HRA Activity Based Activity Event completers incented.";
			if (this.personProgramActivityIncentiveStatusForHraAL != null && personProgramActivityIncentiveStatusForHraAL.size() > 0) {
				emailContent
						.append("<tr><td>--- " + this.personProgramActivityIncentiveStatusForHraAL.size() + personProgramActivityIncentiveStatusForHraDesc + " </td><td></tr>");
			}
			String memberProgramActivityIncentiveStatusForHraDesc = " HRA Member Based Activity Event completers incented.";
			if (this.memberProgramActivityIncentiveStatusForHraAL != null && memberProgramActivityIncentiveStatusForHraAL.size() > 0) {
				emailContent
						.append("<tr><td>--- " + this.memberProgramActivityIncentiveStatusForHraAL.size() + memberProgramActivityIncentiveStatusForHraDesc + "</td><td></tr>");
			} 
		}
		

		if (this.isHsaExist) {
			String personProgramActivityIncentiveStatusForHsaDesc = " HSA Activity Based Activity Event completers incented.";
			if (this.personProgramActivityIncentiveStatusForHsaAL != null && personProgramActivityIncentiveStatusForHsaAL.size() > 0) {
				emailContent
						.append("<tr><td>--- " + this.personProgramActivityIncentiveStatusForHsaAL.size() + personProgramActivityIncentiveStatusForHsaDesc + "</td><td></tr>");
								
			} 
			String memberProgramActivityIncentiveStatusForHsaDesc = " HSA Member Based Activity Event completers incented.";
			if (this.memberProgramActivityIncentiveStatusForHsaAL != null && memberProgramActivityIncentiveStatusForHsaAL.size() > 0) {
				emailContent
						.append("<tr><td>--- " + this.memberProgramActivityIncentiveStatusForHsaAL.size() + memberProgramActivityIncentiveStatusForHsaDesc + "</td><td></tr>");
								
			} 
		}
		
		if (this.isIntelispendExist) {
			
			String personProgramActivityIncentiveStatusForIntelispendDesc = " Intelispend Activity Based Activity Event completers incented.";
			if (this.personProgramActivityIncentiveStatusForIntelispendAL != null && personProgramActivityIncentiveStatusForIntelispendAL.size() > 0) {
				emailContent
						.append("<tr><td>--- " + this.personProgramActivityIncentiveStatusForIntelispendAL.size() + personProgramActivityIncentiveStatusForIntelispendDesc + "</td><td></tr>");
								
			} 
			String memberProgramActivityIncentiveStatusForIntelispendDesc = " Intelispend Member Based Activity Event completers incented.";
			if (memberProgramActivityIncentiveStatusForIntelispendAL != null && memberProgramActivityIncentiveStatusForIntelispendAL.size() > 0) {
				emailContent
						.append("<tr><td>--- " + this.memberProgramActivityIncentiveStatusForIntelispendAL.size() + memberProgramActivityIncentiveStatusForIntelispendDesc + "</td><td></tr>");
								
			}
		}
		
		
		if (isMultiActivityBased()) {
			String activityNotIncentedDesc = " Multi Activity Based Activity Event completers NOT incented. Only one activity incented per activities taken.";
			if (this.activityNotIncentedForActivityBasedRequirementsAL != null && this.activityNotIncentedForActivityBasedRequirementsAL.size() > 0) {
				emailContent
						.append("<tr><td>--- " + this.activityNotIncentedForActivityBasedRequirementsAL.size() + activityNotIncentedDesc + "</td><td></tr>");
								
			} 
		} 
		
		
		String contractProgramIncentiveStatusDesc = " Contract Based Activity Event completers incented.";
		if (this.activityIncentedForContractBasedAL != null && activityIncentedForContractBasedAL.size() > 0) {
			emailContent
					.append("<tr><td>--- " + activityIncentedForContractBasedAL.size() + contractProgramIncentiveStatusDesc + "</td><td></tr>");
						
		} 
		
		
		if (this.activityNonRewardedAL != null && activityNonRewardedAL.size() > 0) {
			emailContent
					.append("<tr><td>--- " + activityNonRewardedAL.size() + " Activity non reward for possible Employer Reward display. </td><td></tr>");
						
		} 
		
		if (this.activityHABypassedAlongWithProgramAL != null && this.activityHABypassedAlongWithProgramAL.size() > 0) {
			emailContent
					.append("<tr><td>--- " + activityHABypassedAlongWithProgramAL.size() + " HA's bypassed that are part of more than one requirement. </td><td></tr>");
						
		} 
		
		if (this.activityWithNoHATakenForMultiActivityAL != null && this.activityWithNoHATakenForMultiActivityAL.size() > 0) {
			emailContent
					.append("<tr><td>--- " + activityWithNoHATakenForMultiActivityAL.size() + " Activity taken missing HA for Multi Activity. </td><td></tr>");
						
		} 
		
		if (this.activityNotLeadToRewardAL != null && this.activityNotLeadToRewardAL.size() > 0) {
			emailContent
					.append("<tr><td>--- " + activityNotLeadToRewardAL.size() + " Activities  incented to  be Employer Administered. </td><td></tr>");
						
		} 
		
		
		
		emailContent
		.append("<tr><td colspan=2>-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
		emailContent
		.append("<tr><td colspan=2>---------------------A C T I O N      T O      T A K E      S U M M A R Y      S E C T I O N         ----------------------------------------------------------------------------------------------------------------------</td></tr>");
		String activityEventPendingDesc = 	" PENDING Activity Event completer records.";
		
		emailContent
			.append("<tr><td>A) --- " + activityEventPendingAL.size() + activityEventPendingDesc + "</td><td></tr>");
		
		String activityEventInProcessDesc = " INPROCESS Activity Event completer records.";
		emailContent
			.append("<tr><td>B) --- " + activityEventInProcessAL.size() + activityEventInProcessDesc + "</td><td></tr>");
		String activityEventFilteredOutDesc = " FILTERED OUT Activity Event completer records.";
		emailContent
					.append("<tr><td>C) --- " + activityEventFilteredOutAL.size() + activityEventFilteredOutDesc + "</td><td></tr>");
		
		String activityNotProgramEligibleDesc = " Activity Event completers where activities are not program eligible.";
		emailContent
					.append("<tr><td>D) --- " + activityNotProgramEligibleAL.size() + activityNotProgramEligibleDesc +  "</td><td></tr>");
		
		String activityNotIncentedForCheckmarkDesc = " Activity Event completers not incented towards checkmark.";
		emailContent
					.append("<tr><td>E) --- " + activityNotIncentedForCheckmarkAL.size() + activityNotIncentedForCheckmarkDesc + "</td><td></tr>");
		
		String activityNoMatchToActivityRequirementDesc = " Activity Event completers not matching to activity requirements.";
		emailContent
					.append("<tr><td>F) --- " + activityNoMatchToActivityRequirementAL.size() + activityNoMatchToActivityRequirementDesc + "</td><td></tr>");
		String activityNotIncentedForContractBasedDesc = " Contract Activity Event completers not matching to activity requirements.";
		emailContent
		.append("<tr><td>G) --- " + activityNotIncentedForContractBasedAL.size() + activityNotIncentedForContractBasedDesc + "</td><td></tr>");
		String activityNotIncentedForMemberBasedDesc = " Member based activity events not matching to member incented activity detail table.";
		emailContent
		.append("<tr><td>H) --- " + activityNotIncentedForMemberBasedAL.size() + activityNotIncentedForMemberBasedDesc + "</td><td></tr>");
		String activityNotIncentedDesc = " Activity Event completers NOT incented.";
		emailContent
					.append("<tr><td>I) --- " + activityNotIncentedForActivityBasedRequirementsAL.size() + activityNotIncentedDesc + "</td><td></tr>");
		emailContent
		.append("<tr><td colspan=2>-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");	
		
		emailContent.append("</table>");
		
		emailContent.append("<table>");
	
		
		if (this.activityEventPendingAL != null && this.activityEventPendingAL.size() > 0) {
			emailContent
			.append("<tr><td>A) --- " + activityEventPendingAL.size() + activityEventPendingDesc + "</td><td></tr>");
			emailContent
			.append("<tr><td>***   ACTION TO TAKE: For pending activities, run the Pending Activities job kicked off through the BPM Admin Tool. </td></tr>");		
		} 
		
		
		
		
	
		if (activityEventInProcessAL != null && this.activityEventInProcessAL.size() > 0) {
			emailContent
			.append("<tr><td colspan=2>-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");		
			emailContent
			.append("<tr><td>B) --- " + activityEventInProcessAL.size() + activityEventInProcessDesc + "</td><td></tr>");
			emailContent
			.append("<tr><td>***   ACTION TO TAKE: For INPROCESS activities, repend these activities and then run the Pending Activities job kicked off through the BPM Admin Tool. </td></tr>");		
		}
		
	
		if (activityEventFilteredOutAL != null && this.activityEventFilteredOutAL.size() > 0) {
			emailContent
			.append("<tr><td colspan=2>-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");		
			emailContent
					.append("<tr><td>C) --- " + activityEventFilteredOutAL.size() + activityEventFilteredOutDesc + "</td><td></tr>");
			emailContent
			.append("<tr><td>***   ACTION TO TAKE: For activities filtered out, go to Member Status screen and look for the reason why activity was filtered out. </td></tr>");
		} 
		
		if (this.activityNotProgramEligibleAL != null && this.activityNotProgramEligibleAL.size() > 0) {
			emailContent
			.append("<tr><td colspan=2>-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");		
			emailContent
					.append("<tr><td>D) --- " + activityNotProgramEligibleAL.size() + activityNotProgramEligibleDesc +  "</td><td></tr>");
			emailContent
			.append("<tr><td>***  ACTION TO TAKE: For activity events not program eligible, may want to research with developer. </td></tr>");			
		} 
		
		if (this.activityNotIncentedForCheckmarkAL != null && this.activityNotIncentedForCheckmarkAL.size() > 0) {
			emailContent
			.append("<tr><td colspan=2>-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");		
			emailContent
					.append("<tr><td>E) --- " + activityNotIncentedForCheckmarkAL.size() + activityNotIncentedForCheckmarkDesc + "</td><td></tr>");
			emailContent
			.append("<tr><td>***   ACTION TO TAKE: For activity events not incented, could be activity requirement not configured or activity is for Employer Reward display.  May want to research with developer. </td></tr>");			
		} 
		
		if (this.activityNoMatchToActivityRequirementAL != null && this.activityNoMatchToActivityRequirementAL.size() > 0) {
			emailContent
			.append("<tr><td colspan=2>-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");		
			emailContent
					.append("<tr><td>F) --- " + activityNoMatchToActivityRequirementAL.size() + activityNoMatchToActivityRequirementDesc + "</td><td></tr>");
			emailContent
			.append("<tr><td>***  ACTION TO TAKE: For activity events not matching to activity requirements, may want to research with developer.</td></tr>");				
		} 
		
		if (this.activityNotIncentedForContractBasedAL != null && this.activityNotIncentedForContractBasedAL.size() > 0) {
			emailContent
			.append("<tr><td colspan=2>-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");		
			emailContent
					.append("<tr><td>G) --- " + activityNotIncentedForContractBasedAL.size() + activityNotIncentedForContractBasedDesc + "</td><td></tr>");
			emailContent
			.append("<tr><td>***  ACTION TO TAKE: For contract related activity events not matching to activity requirements, may want to research with developer.</td></tr>");				
		} 
		
		if (this.activityNotIncentedForMemberBasedAL != null && this.activityNotIncentedForMemberBasedAL.size() > 0) {
			emailContent
			.append("<tr><td colspan=2>-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");		
			emailContent
					.append("<tr><td>H) --- " + activityNotIncentedForMemberBasedAL.size() + activityNotIncentedForMemberBasedDesc + "</td><td></tr>");
			emailContent
			.append("<tr><td>***  ACTION TO TAKE: Member based activity events not matching to member incented activity detail table. Research business program setup.</td></tr>");				
		} 
		
		if (!isMultiActivityBased()) {
			if (this.activityNotIncentedForActivityBasedRequirementsAL != null && this.activityNotIncentedForActivityBasedRequirementsAL.size() > 0) {
				emailContent
				.append("<tr><td colspan=2>-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");		
				emailContent
						.append("<tr><td>I) --- " + activityNotIncentedForActivityBasedRequirementsAL.size() + activityNotIncentedDesc + "</td><td></tr>");
				emailContent
				.append("<tr><td>***  ACTION TO TAKE: For activity event completers not incented, review incentive setup rules, program checkmark requirements or activity requirements.</td></tr>");				
			} 
			
		}
		
		
		emailContent
		.append("<tr><td> </td></tr>");
		emailContent
		.append("<tr><td> </td></tr>");		
		
		
		emailContent.append("</table>");
		
	}
	
	private void detailSummaryReport(StringBuffer emailContent) {
		
		int lineCtr;
		
		//Commented out because business user does not want to see the detail behind what incented
		//successfully.  User requested only interested in activity detail to take action on.
		/*if (personProgramActivityIncentiveStatusForHraAL.size() > 0) {
			String headerDescription = "ACTIVITY BASED HRA  ACTIVITY COMPLETERS INCENTED";	
			buildEmailContent(personProgramActivityIncentiveStatusForHraAL, emailContent, headerDescription);
		} 
		if (personProgramActivityIncentiveStatusForHsaAL.size() > 0) {
			 String headerDescription = "ACTIVITY BASED HSA ACTIVITY COMPLETERS INCENTED";
			 buildEmailContent(personProgramActivityIncentiveStatusForHsaAL, emailContent, headerDescription);
		}
		
		if (personProgramActivityIncentiveStatusForIntelispendAL.size() > 0) {
			 String headerDescription = "ACTIVITY BASED INTELISPEND ACTIVITY COMPLETERS INCENTED";
			 buildEmailContent(personProgramActivityIncentiveStatusForIntelispendAL, emailContent, headerDescription);
		} 
		if (memberProgramActivityIncentiveStatusForIntelispendAL.size() > 0) {
			 String headerDescription = "MEMBER BASED INTELISPEND ACTIVITY COMPLETERS INCENTED";
			 buildEmailContent(memberProgramActivityIncentiveStatusForIntelispendAL, emailContent, headerDescription);
		} 
		if (memberProgramActivityIncentiveStatusForHraAL.size() > 0) {
				 String headerDescription = "MEMBER BASED HRA ACTIVITY COMPLETERS INCENTED";
				 buildEmailContent(memberProgramActivityIncentiveStatusForHraAL, emailContent, headerDescription);
		}
		if (memberProgramActivityIncentiveStatusForHsaAL.size() > 0) {
			 String headerDescription = "MEMBER BASED HSA ACTIVITY COMPLETERS INCENTED";
			 buildEmailContent(memberProgramActivityIncentiveStatusForHsaAL, emailContent, headerDescription);
		} */
		
		
		emailContent.append("<table>");
		emailContent
		.append("<tr><td> </td></tr>");
		emailContent
		.append("<tr><td> </td></tr>");	
		
		//Do not show detail for non incented rewards.
		/*
		if (activityNotLeadToRewardAL !=null && activityNotLeadToRewardAL.size() > 0) {
			emailContent.append("<table>");
			emailContent
			.append("<tr><td>**********************************************************************************************</td></tr>");
			emailContent
			.append("<tr><td>LIST OF PARTICIPANTS WITH ACTIVITY COMPLETERS NOT LEADING TO AN INCENTIVE REWARD: </td><tr>");
			emailContent
			.append("<tr><td>**********************************************************************************************</td></tr>");
			emailContent.append("</table>");
			emailContent.append("<table>");
			emailContent.append("<tr><td> Line</td><td>Member No</td><td>Person ID</td><td>Activity Name</td><td>Source Activity ID</td><td>Error reason</td></tr>");
			lineCtr = 1;
			for (ActivityEvent activityNotLeadToReward : activityNotLeadToRewardAL) {
				emailContent
				.append("<tr><td colspan=6>--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
				emailContent
				.append("<tr><td>" + lineCtr 
						+ "</td><td>"
						+ activityNotLeadToReward.getMemberActivity().getMemberID()
						+ "</td><td>"
						+ activityNotLeadToReward.getMemberActivity().getPersonID()
						+ "</td><td>"  
						+ activityNotLeadToReward.getMemberActivity().getActivity().getName()
						+ "</td><td>"  
						+ activityNotLeadToReward.getMemberActivity().getActivity().getSourceActivityID()
						+ "</td><td>"
						+ "Activity did not lead to an incented reward but possible reduced premium discount, preferred benefit (lessor copay) or reward administered by employer."
						+ "</td></tr>");
				lineCtr++;
			}
			
			emailContent.append("</table>");
		}*/
		
		if (activityEventPendingAL !=null && activityEventPendingAL.size() > 0) {
			emailContent.append("<table>");
			emailContent
			.append("<tr><td>***********************************************************</td></tr>");
			emailContent
			.append("<tr><td>A) LIST OF PARTICIPANTS WITH ACTIVITY COMPLETERS IN A PENDING STATE: </td><tr>");
			emailContent
			.append("<tr><td>***********************************************************</td></tr>");
			emailContent.append("</table>");
			emailContent.append("<table>");
			emailContent.append("<tr><td> Line</td><td>Member No</td><td>Person ID</td><td>Activity Name</td><td>Source Activity ID</td><td>Error reason</td></tr>");
			lineCtr = 1;
			for (ActivityEvent activityEventPending : activityEventPendingAL) {
				emailContent
				.append("<tr><td colspan=6>--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
				emailContent
				.append("<tr><td>" + lineCtr 
						+ "</td><td>"
						+ activityEventPending.getMemberActivity().getMemberID()
						+ "</td><td>"
						+ activityEventPending.getMemberActivity().getPersonID()
						+ "</td><td>"  
						+ activityEventPending.getMemberActivity().getActivity().getName()
						+ "</td><td>"  
						+ activityEventPending.getMemberActivity().getActivity().getSourceActivityID()
						+ "</td><td>"
						+ "Activity event is PENDING"
						+ "</td></tr>");
				lineCtr++;
			}
			
			emailContent.append("</table>");
		}
		
		if (activityEventInProcessAL !=null && activityEventInProcessAL.size() > 0) {
			emailContent.append("<table>");
			emailContent
			.append("<tr><td>***********************************************************************</td></tr>");
			emailContent
			.append("<tr><td>B) LIST OF PARTICIPANTS WITH ACTIVITY COMPLETERS INPROCESS: </td><tr>");
			emailContent
			.append("<tr><td>***********************************************************************</td></tr>");
			emailContent.append("</table>");
			emailContent.append("<table>");
			emailContent.append("<tr><td> Line</td><td>Member No</td><td>Person ID</td><td>Activity Name</td><td>Source Activity ID</td><td>Error reason</td></tr>");
			lineCtr = 1;
			for (ActivityEvent activityEventInProcess : activityEventInProcessAL) {
				emailContent
				.append("<tr><td colspan=6>--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
				emailContent
				.append("<tr><td>" + lineCtr 
						+ "</td><td>"
						+ activityEventInProcess.getMemberActivity().getMemberID()
						+ "</td><td>"
						+ activityEventInProcess.getMemberActivity().getPersonID()
						+ "</td><td>"  
						+ activityEventInProcess.getMemberActivity().getActivity().getName()
						+ "</td><td>"  
						+ activityEventInProcess.getMemberActivity().getActivity().getSourceActivityID()
						+ "</td><td>"
						+ "Activity event is INPROCESS."
						+ "</td></tr>");
				lineCtr++;
			}
			emailContent.append("</table>");
		}
		
		if (activityEventFilteredOutAL !=null && activityEventFilteredOutAL.size() > 0) {
			emailContent.append("<table>");
			emailContent
			.append("<tr><td>***********************************************************</td></tr>");
			emailContent
			.append("<tr><td>C) LIST OF PARTICIPANTS WITH ACTIVITY COMPLETERS FILTERED OUT: </td><tr>");
			emailContent
			.append("<tr><td>***********************************************************</td></tr>");
			emailContent.append("</table>");
			emailContent.append("<table>");
			emailContent.append("<tr><td> Line</td><td>Member No</td><td>Person ID</td><td>Activity Name</td><td>Source Activity ID</td><td>Error reason</td></tr>");
			lineCtr = 1;
			for (ActivityEvent activityEventFilteredOut : activityEventFilteredOutAL) {
				emailContent
				.append("<tr><td colspan=6>--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
				emailContent
				.append("<tr><td>" + lineCtr 
						+ "</td><td>"
						+ activityEventFilteredOut.getMemberActivity().getMemberID()
						+ "</td><td>"
						+ activityEventFilteredOut.getMemberActivity().getPersonID()
						+ "</td><td>"  
						+ activityEventFilteredOut.getMemberActivity().getActivity().getName()
						+ "</td><td>"  
						+ activityEventFilteredOut.getMemberActivity().getActivity().getSourceActivityID()
						+ "</td><td>"
						+ activityEventFilteredOut.getReasonDescription()
						+ "</td></tr>");
				lineCtr++;
			}
			emailContent.append("</table>");
		}
		

		if (this.activityNotProgramEligibleAL !=null && this.activityNotProgramEligibleAL.size() > 0) {
			emailContent.append("<table>");
			emailContent
			.append("<tr><td>***********************************************************</td></tr>");
			emailContent
			.append("<tr><td>D) LIST OF PARTICIPANT ACTIVITY COMPLETERS NOT PROGRAM ELIGIBLE: </td><tr>");
			emailContent
			.append("<tr><td>***********************************************************</td></tr>");
			emailContent.append("</table>");
			emailContent.append("<table>");
			emailContent.append("<tr><td> Line</td><td>Member No</td><td>Person ID</td><td>Activity Name</td><td>Source Activity ID</td><td>Error reason</td></tr>");
			lineCtr = 1;
			for (ActivityEvent activityNotProgramEligible : this.activityNotProgramEligibleAL) {
				emailContent
				.append("<tr><td colspan=6>--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
				emailContent
				.append("<tr><td>" + lineCtr 
						+ "</td><td>"
						+ activityNotProgramEligible.getMemberActivity().getMemberID()
						+ "</td><td>"
						+ activityNotProgramEligible.getMemberActivity().getPersonID()
						+ "</td><td>"  
						+ activityNotProgramEligible.getMemberActivity().getActivity().getName()
						+ "</td><td>"  
						+ activityNotProgramEligible.getMemberActivity().getActivity().getSourceActivityID()
						+ "</td><td>"
						+ "Activity event not program eligible."
						+ "</td></tr>");
				lineCtr++;
			}
			emailContent.append("</table>");
		}
		
		
		if (this.activityNotIncentedForCheckmarkAL !=null && this.activityNotIncentedForCheckmarkAL.size() > 0) {
			emailContent.append("<table>");
			emailContent
			.append("<tr><td>***********************************************************</td></tr>");
			emailContent
			.append("<tr><td>E) LIST OF PARTICIPANT ACTIVITY COMPLETERS NOT INCENTED TOWARDS CHECKMARK: </td><tr>");
			emailContent
			.append("<tr><td>***********************************************************</td></tr>");
			emailContent.append("</table>");
			emailContent.append("<table>");
			emailContent.append("<tr><td> Line</td><td>Member No</td><td>Person ID</td><td>Activity Name</td><td>Source Activity ID</td><td>Error reason</td></tr>");
			lineCtr = 1;
			for (ActivityEvent activityNotIncentedForCheckmark : this.activityNotIncentedForCheckmarkAL) {
				emailContent
				.append("<tr><td colspan=6>--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
				emailContent
				.append("<tr><td>" + lineCtr 
						+ "</td><td>"
						+ activityNotIncentedForCheckmark.getMemberActivity().getMemberID()
						+ "</td><td>"
						+ activityNotIncentedForCheckmark.getMemberActivity().getPersonID()
						+ "</td><td>"  
						+ activityNotIncentedForCheckmark.getMemberActivity().getActivity().getName()
						+ "</td><td>"  
						+ activityNotIncentedForCheckmark.getMemberActivity().getActivity().getSourceActivityID()
						+ "</td><td>"
						+ "Activity event not incented."
						+ "</td></tr>");
				lineCtr++;
			}
			emailContent.append("</table>");
		}
		
		if (this.activityNoMatchToActivityRequirementAL !=null && this.activityNoMatchToActivityRequirementAL.size() > 0) {
			emailContent.append("<table>");
			emailContent
			.append("<tr><td>***********************************************************</td></tr>");
			emailContent
			.append("<tr><td>F) LIST OF PARTICIPANT ACTIVITY COMPLETERS WITH NO ACTIVITY REQUIREMENTS: </td><tr>");
			emailContent
			.append("<tr><td>***********************************************************</td></tr>");
			emailContent.append("</table>");
			emailContent.append("<table>");
			emailContent.append("<tr><td> Line</td><td>Member No</td><td>Person ID</td><td>Activity Name</td><td>Source Activity ID</td><td>Error reason</td></tr>");
			lineCtr = 1;
			for (ActivityEvent activityNoMatchToActivityRequirement : this.activityNoMatchToActivityRequirementAL) {
				emailContent
				.append("<tr><td colspan=6>--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
				emailContent
				.append("<tr><td>" + lineCtr 
						+ "</td><td>"
						+ activityNoMatchToActivityRequirement.getMemberActivity().getMemberID()
						+ "</td><td>"
						+ activityNoMatchToActivityRequirement.getMemberActivity().getPersonID()
						+ "</td><td>"  
						+ activityNoMatchToActivityRequirement.getMemberActivity().getActivity().getName()
						+ "</td><td>"  
						+ activityNoMatchToActivityRequirement.getMemberActivity().getActivity().getSourceActivityID()
						+ "</td><td>"
						+ "Activity event without activity requirements"
						+ "</td></tr>");
				lineCtr++;
			}
			emailContent.append("</table>");
		}
		
		
		
		
		
	
		
		if (this.activityNonRewardedAL !=null && this.activityNonRewardedAL.size() > 0) {
			emailContent.append("<table>");
			emailContent
			.append("<tr><td>***********************************************************</td></tr>");
			emailContent
			.append("<tr><td>LIST OF PARTICIPANT ACTIVITY COMPLETERS FOR POSSIBLE EMPLOYER REWARD DISPLAY ONLY: </td><tr>");
			emailContent
			.append("<tr><td>***********************************************************</td></tr>");
			emailContent.append("</table>");
			emailContent.append("<table>");
			emailContent.append("<tr><td> Line</td><td>Member No</td><td>Person ID</td><td>Activity Name</td><td>Source Activity ID</td><td>Error reason</td></tr>");
			lineCtr = 1;
			for (ActivityEvent activityNonRewarded : this.activityNonRewardedAL) {
				emailContent
				.append("<tr><td colspan=6>--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
				emailContent
				.append("<tr><td>" + lineCtr 
						+ "</td><td>"
						+ activityNonRewarded.getMemberActivity().getMemberID()
						+ "</td><td>"
						+ activityNonRewarded.getMemberActivity().getPersonID()
						+ "</td><td>"  
						+ activityNonRewarded.getMemberActivity().getActivity().getName()
						+ "</td><td>"  
						+ activityNonRewarded.getMemberActivity().getActivity().getSourceActivityID()
						+ "</td><td>"
						+ "Activity event taken but not setup for a reward."
						+ "</td></tr>");
				lineCtr++;
			}
			emailContent.append("</table>");
		}
		
		if (this.activityIncentedForContractBasedAL !=null && this.activityIncentedForContractBasedAL.size() > 0) {
			emailContent.append("<table>");
			emailContent
			.append("<tr><td>***********************************************************</td></tr>");
			emailContent
			.append("<tr><td>LIST OF PARTICIPANT ACTIVITY COMPLETERS FOR CONTRACT BASED: </td><tr>");
			emailContent
			.append("<tr><td>***********************************************************</td></tr>");
			emailContent.append("</table>");
			emailContent.append("<table>");
			emailContent.append("<tr><td> Line</td><td>Member No</td><td>Person ID</td><td>Activity Name</td><td>Source Activity ID</td><td>Error reason</td></tr>");
			lineCtr = 1;
			for (ActivityEvent activityIncentedForContractBased : this.activityIncentedForContractBasedAL) {
				emailContent
				.append("<tr><td colspan=6>--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
				emailContent
				.append("<tr><td>" + lineCtr 
						+ "</td><td>"
						+ activityIncentedForContractBased.getMemberActivity().getMemberID()
						+ "</td><td>"
						+ activityIncentedForContractBased.getMemberActivity().getPersonID()
						+ "</td><td>"  
						+ activityIncentedForContractBased.getMemberActivity().getActivity().getName()
						+ "</td><td>"  
						+ activityIncentedForContractBased.getMemberActivity().getActivity().getSourceActivityID()
						+ "</td><td>"
						+ "Activity event taken and incented as CONTRACT BASED."
						+ "</td></tr>");
				lineCtr++;
			}
			emailContent.append("</table>");
		}
		
		if (this.activityNotIncentedForContractBasedAL !=null && this.activityNotIncentedForContractBasedAL.size() > 0) {
			emailContent.append("<table>");
			emailContent
			.append("<tr><td>***********************************************************</td></tr>");
			emailContent
			.append("<tr><td>G) LIST OF PARTICIPANT ACTIVITY COMPLETERS NOT INCENTED FOR CONTRACT BASED: </td><tr>");
			emailContent
			.append("<tr><td>***********************************************************</td></tr>");
			emailContent.append("</table>");
			emailContent.append("<table>");
			emailContent.append("<tr><td> Line</td><td>Member No</td><td>Person ID</td><td>Activity Name</td><td>Source Activity ID</td><td>Error reason</td></tr>");
			lineCtr = 1;
			for (ActivityEvent activityNotIncentedForContractBased : this.activityNotIncentedForContractBasedAL) {
				emailContent
				.append("<tr><td colspan=6>--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
				emailContent
				.append("<tr><td>" + lineCtr 
						+ "</td><td>"
						+ activityNotIncentedForContractBased.getMemberActivity().getMemberID()
						+ "</td><td>"
						+ activityNotIncentedForContractBased.getMemberActivity().getPersonID()
						+ "</td><td>"  
						+ activityNotIncentedForContractBased.getMemberActivity().getActivity().getName()
						+ "</td><td>"  
						+ activityNotIncentedForContractBased.getMemberActivity().getActivity().getSourceActivityID()
						+ "</td><td>"
						+ "Activity event taken and not incented for CONTRACT BASED."
						+ "</td></tr>");
				lineCtr++;
			}
			emailContent.append("</table>");
		}
		
		if (this.activityNotIncentedForMemberBasedAL !=null && this.activityNotIncentedForMemberBasedAL.size() > 0) {
			emailContent.append("<table>");
			emailContent
			.append("<tr><td>***********************************************************</td></tr>");
			emailContent
			.append("<tr><td>H) LIST OF PARTICIPANT ACTIVITY COMPLETERS NOT INCENTED FOR MEMBER BASED: </td><tr>");
			emailContent
			.append("<tr><td>***********************************************************</td></tr>");
			emailContent.append("</table>");
			emailContent.append("<table>");
			emailContent.append("<tr><td> Line</td><td>Member No</td><td>Person ID</td><td>Activity Name</td><td>Source Activity ID</td><td>Error reason</td></tr>");
			lineCtr = 1;
			for (ActivityEvent activityNotIncentedForMemberBased : this.activityNotIncentedForMemberBasedAL) {
				emailContent
				.append("<tr><td colspan=6>--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
				emailContent
				.append("<tr><td>" + lineCtr 
						+ "</td><td>"
						+ activityNotIncentedForMemberBased.getMemberActivity().getMemberID()
						+ "</td><td>"
						+ activityNotIncentedForMemberBased.getMemberActivity().getPersonID()
						+ "</td><td>"  
						+ activityNotIncentedForMemberBased.getMemberActivity().getActivity().getName()
						+ "</td><td>"  
						+ activityNotIncentedForMemberBased.getMemberActivity().getActivity().getSourceActivityID()
						+ "</td><td>"
						+ "Activity event taken and not incented for MEMBER BASED."
						+ "</td></tr>");
				lineCtr++;
			}
			emailContent.append("</table>");
		}
		
		if (this.activityWithNoHATakenForMultiActivityAL !=null && this.activityWithNoHATakenForMultiActivityAL.size() > 0) {
			emailContent.append("<table>");
			emailContent
			.append("<tr><td>***********************************************************</td></tr>");
			emailContent
			.append("<tr><td>LIST OF PARTICIPANT ACTIVITY COMPLETERS WITH NO HA TAKEN FOR MULTI ACTIVITY INCENTIVE OPTION: </td><tr>");
			emailContent
			.append("<tr><td>***********************************************************</td></tr>");
			emailContent.append("</table>");
			emailContent.append("<table>");
			emailContent.append("<tr><td> Line</td><td>Member No</td><td>Person ID</td><td>Activity Name</td><td>Source Activity ID</td><td>Error reason</td></tr>");
			lineCtr = 1;
			for (ActivityEvent activityWithNoHATakenForMultiActivity : this.activityWithNoHATakenForMultiActivityAL) {
				emailContent
				.append("<tr><td colspan=6>--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
				emailContent
				.append("<tr><td>" + lineCtr 
						+ "</td><td>"
						+ activityWithNoHATakenForMultiActivity.getMemberActivity().getMemberID()
						+ "</td><td>"
						+ activityWithNoHATakenForMultiActivity.getMemberActivity().getPersonID()
						+ "</td><td>"  
						+ activityWithNoHATakenForMultiActivity.getMemberActivity().getActivity().getName()
						+ "</td><td>"  
						+ activityWithNoHATakenForMultiActivity.getMemberActivity().getActivity().getSourceActivityID()
						+ "</td><td>"
						+ "Activity with no HA taken for Multi Activity incentive option."
						+ "</td></tr>");
				lineCtr++;
			}
			emailContent.append("</table>");
		}
		
		
		
		if (this.activityNotIncentedForActivityBasedRequirementsAL !=null && this.activityNotIncentedForActivityBasedRequirementsAL.size() > 0) {
			emailContent.append("<table>");
			
				emailContent
				.append("<tr><td>***********************************************************</td></tr>");
			if (isMultiActivityBased) {
				emailContent
				.append("<tr><td>LIST OF MUlTI ACTIVITY PARTICIPANT ACTIVITY COMPLETERS FOR ACTIVITY BASED REQUIREMENTS: </td><tr>");
				
			} else {
				emailContent
				.append("<tr><td>LIST OF PARTICIPANT ACTIVITY COMPLETERS NOT INCENTED FOR ACTIVITY BASED REQUIREMENTS: </td><tr>");
			}
			emailContent
			.append("<tr><td>***********************************************************</td></tr>");
			emailContent.append("</table>");
			emailContent.append("<table>");
			emailContent.append("<tr><td> Line</td><td>Member No</td><td>Person ID</td><td>Activity Name</td><td>Source Activity ID</td><td>Error reason</td></tr>");
			lineCtr = 1;
			for (ActivityEvent activityNotIncented : this.activityNotIncentedForActivityBasedRequirementsAL) {
				emailContent
				.append("<tr><td colspan=6>--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
				emailContent
				.append("<tr><td>" + lineCtr 
						+ "</td><td>"
						+ activityNotIncented.getMemberActivity().getMemberID()
						+ "</td><td>"
						+ activityNotIncented.getMemberActivity().getPersonID()
						+ "</td><td>"  
						+ activityNotIncented.getMemberActivity().getActivity().getName()
						+ "</td><td>"  
						+ activityNotIncented.getMemberActivity().getActivity().getSourceActivityID()
						+ "</td><td>"
						+ "Activity completer not incented."
						+ "</td></tr>");
				lineCtr++;
			}
			emailContent.append("</table>");
		}
		
		
		
		
		emailContent.append("</table>");
		
	}
		

	
	private void buildEmailContent(Collection<PersonProgramActivityIncentiveStatus> programActivityIncentiveStatusAL, StringBuffer emailContent, String headerDescription) {
		emailContent.append("<table>");
		emailContent
		.append("<tr><td> </td></tr>");
		emailContent
		.append("<tr><td> </td></tr>");
		emailContent
		.append("<tr><td>***********************************************************</td></tr>");
		emailContent.append("<tr><td>" + headerDescription + "</td></tr>");
		emailContent
		.append("<tr><td>***********************************************************</td></tr>");
		emailContent.append("</table>");
		emailContent.append("<table>");
		emailContent.append("<tr><td> Line</td><td>MemberID</td><td>Person ID</td><td>First Name</td><td>Last Name</td><td>Activity Name</td><td>Activity Date</td></tr>");
		
		
		int lineNbr = 1;
		for (PersonProgramActivityIncentiveStatus programActivityIncentiveStatus : programActivityIncentiveStatusAL) {
			
			emailContent
			.append("<tr><td colspan=7>--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
			emailContent.append("<tr><td> "
					+ lineNbr + "</td><td>"
					+ programActivityIncentiveStatus.getMemberNo() + "</td><td>"
					+ programActivityIncentiveStatus.getPersonDemographicsID() + "</td><td>"
					+ programActivityIncentiveStatus.getFirstName() + "</td><td>" 
					+ programActivityIncentiveStatus.getLastName() + "</td><td>"
					+ programActivityIncentiveStatus.getActivityName() + "</td><td>"
					+ programActivityIncentiveStatus.getActivityStatusIncentiveDate() + "</td></tr>" 
					);
			lineNbr++;
		}
	
		
		
		emailContent.append("</table>");
	}
	
	
	private void instantiateObjects() {
		instantiateActivityALs();
		instantiateCheckmarkHashMap();
		
	}
	
	private void instantiateCheckmarkHashMap() {
		
		setHaExistsForParticipantCheckmarkReqHM(new HashMap<String, ActivityEvent>());
		setHaExistsForParticipantActivityReqHM(new HashMap<String, ActivityEvent>());
	}
	
	private void instantiateActivityALs() {
		    setPersonProgramActivityIncentiveStatusForHraAL(new ArrayList<PersonProgramActivityIncentiveStatus>());
		    setPersonProgramActivityIncentiveStatusForHsaAL(new ArrayList<PersonProgramActivityIncentiveStatus>());
		    setPersonProgramActivityIncentiveStatusForIntelispendAL(new ArrayList<PersonProgramActivityIncentiveStatus>());
		    setMemberProgramActivityIncentiveStatusForHraAL(new ArrayList<PersonProgramActivityIncentiveStatus>());
		    setMemberProgramActivityIncentiveStatusForHsaAL(new ArrayList<PersonProgramActivityIncentiveStatus>());
		    setMemberProgramActivityIncentiveStatusForIntelispendAL(new ArrayList<PersonProgramActivityIncentiveStatus>());
		    setActivityEventsAL(new ArrayList<ActivityEvent>());
			setActivityEventPendingAL(new ArrayList<ActivityEvent>());
			setActivityEventInProcessAL(new ArrayList<ActivityEvent>());
			setActivityEventFilteredOutAL(new ArrayList<ActivityEvent>());
			setActivityEventNotEligibleAL(new ArrayList<ActivityEvent>());
		
			setActivityNoMatchToActivityRequirementAL(new ArrayList<ActivityEvent>());
			setActivityNotIncentedForActivityBasedRequirementsAL(new ArrayList<ActivityEvent>());
			setActivityNonRewardedAL(new ArrayList<ActivityEvent>());
			setActivityEventDuplicatesAL(new ArrayList<ActivityEvent>());
			setActivityNotIncentedForCheckmarkAL(new ArrayList<ActivityEvent>());
			setActivityNotProgramEligibleAL(new ArrayList<ActivityEvent>());
			setActivityHABypassedAlongWithProgramAL(new ArrayList<ActivityEvent>());
			setActivityWithNoHATakenForMultiActivityAL(new ArrayList<ActivityEvent>());
			setActivityEventFilteredOutDuplicatesAL(new ArrayList<ActivityEvent>());
			
			resetIncentiveOptionTypeExists();
			setActivityNotIncentedForContractBasedAL(new ArrayList<ActivityEvent>());
			setActivityNotLeadToRewardAL(new ArrayList<ActivityEvent>());
			setActivityNotIncentedForContractBasedAL(new ArrayList<ActivityEvent>());
			setActivityNotIncentedForMemberBasedAL(new ArrayList<ActivityEvent>());
			setActivityIncentedForContractBasedAL(new ArrayList<ActivityEvent>());
			setActivityIncentedForMemberBasedAL(new ArrayList<ActivityEvent>());
			
			
	}
	
	private void resetIncentiveOptionTypeExists() {
			setHraExist(false);
			setHsaExist(false);
			setIntelispendExist(false);
	}
	private void clearActivityALs() {
		
		if (this.personProgramActivityIncentiveStatusForHraAL != null) {
			this.personProgramActivityIncentiveStatusForHraAL.clear();
		}
		
		if (this.personProgramActivityIncentiveStatusForHsaAL != null) {
			this.personProgramActivityIncentiveStatusForHsaAL.clear();
		}
		
		if (this.personProgramActivityIncentiveStatusForIntelispendAL != null) {
			this.personProgramActivityIncentiveStatusForIntelispendAL.clear();
		}
		
		if (this.memberProgramActivityIncentiveStatusForHraAL != null) {
			this.memberProgramActivityIncentiveStatusForHraAL.clear();
		}
		
		if (this.memberProgramActivityIncentiveStatusForHsaAL != null) {
			this.memberProgramActivityIncentiveStatusForHsaAL.clear();
		}
		
		if (this.memberProgramActivityIncentiveStatusForIntelispendAL != null) {
			this.memberProgramActivityIncentiveStatusForIntelispendAL.clear();
		}
		
		if (this.activityEventsAL != null) {
			this.activityEventsAL.clear();
		}
		
		if (this.activityEventPendingAL != null) {
			this.activityEventPendingAL.clear();
		}
		if (this.activityEventInProcessAL != null) {
			this.activityEventInProcessAL.clear();
		}
		if (this.activityEventFilteredOutAL != null) {
			this.activityEventFilteredOutAL.clear();
		}
		
		if (this.activityEventFilteredOutDuplicatesAL != null) {
			this.activityEventFilteredOutDuplicatesAL.clear();
		}
		
		
		if (this.activityEventNotEligibleAL != null) {
			this.activityEventNotEligibleAL.clear();
		}
		
		
		
		if (this.activityNoMatchToActivityRequirementAL != null) {
			this.activityNoMatchToActivityRequirementAL.clear();
		}
		
		if (this.activityNotIncentedForActivityBasedRequirementsAL != null) {
			this.activityNotIncentedForActivityBasedRequirementsAL.clear();
		}
		
		if (this.activityNonRewardedAL != null) {
			this.activityNonRewardedAL.clear();
		}
		
		if (this.activityEventDuplicatesAL != null) {
			this.activityEventDuplicatesAL.clear();
		} 
		
		if (this.activityNotIncentedForCheckmarkAL != null) {
			this.activityNotIncentedForCheckmarkAL.clear();
		} 
		if (this.activityNotProgramEligibleAL != null) {
			this.activityNotProgramEligibleAL.clear();
		} 
		
		if (this.haExistsForParticipantCheckmarkReqHM != null) {
			this.haExistsForParticipantCheckmarkReqHM.clear();
		}
		
		if (this.haExistsForParticipantActivityReqHM != null) {
			this.haExistsForParticipantActivityReqHM.clear();
		}
		
	
		if (this.activityNotIncentedForContractBasedAL != null) {
			this.activityNotIncentedForContractBasedAL.clear();
		}
		
		if (this.activityHABypassedAlongWithProgramAL != null) {
			this.activityHABypassedAlongWithProgramAL.clear();
		}
		
		if (this.activityWithNoHATakenForMultiActivityAL != null) {
			this.activityWithNoHATakenForMultiActivityAL.clear();
		}
		
		if (this.activityNotLeadToRewardAL != null) {
			this.activityNotLeadToRewardAL.clear();
		}
		
		if (this.activityIncentedForContractBasedAL != null) {
			this.activityIncentedForContractBasedAL.clear();
		}
		
		if (this.activityIncentedForMemberBasedAL != null) {
			this.activityIncentedForMemberBasedAL.clear();
		}
		
		
		
	}
	
	private boolean isEmployerActivitiesExist() {
		boolean activitiesExist = false;
		
		if (activityEventsAL != null &&
				activityEventsAL.size() > 0) {
			activitiesExist = true;
		} else if (personProgramActivityIncentiveStatusForHraAL != null &&
				personProgramActivityIncentiveStatusForHraAL.size() > 0) {
				activitiesExist = true;
		} else if (personProgramActivityIncentiveStatusForHsaAL != null &&
				personProgramActivityIncentiveStatusForHsaAL.size() > 0) {
				activitiesExist = true;
		} else if (personProgramActivityIncentiveStatusForIntelispendAL != null &&
				personProgramActivityIncentiveStatusForIntelispendAL.size() > 0) {
				activitiesExist = true;
		} else if (memberProgramActivityIncentiveStatusForHraAL != null &&
					memberProgramActivityIncentiveStatusForHraAL.size() > 0) {
					activitiesExist = true;
		} else if (memberProgramActivityIncentiveStatusForHsaAL != null &&
				memberProgramActivityIncentiveStatusForHsaAL.size() > 0) {
				activitiesExist = true;
		} else if (memberProgramActivityIncentiveStatusForIntelispendAL != null &&
				memberProgramActivityIncentiveStatusForIntelispendAL.size() > 0) {
				activitiesExist = true;
		}  else if (activityEventPendingAL != null &&
						activityEventPendingAL.size() > 0) {
					activitiesExist = true;
		}  else if (activityEventInProcessAL != null &&
						activityEventInProcessAL.size() > 0) {
					activitiesExist = true;
		} else if (activityEventFilteredOutAL != null &&
				activityEventFilteredOutAL.size() > 0) {
						activitiesExist = true;
		} 
		
		return activitiesExist;
	}
	
	private Map<String, Integer> summarizeActivitiesNCounts(Collection<PersonProgramActivityIncentiveStatus> lPersonProgramActivityIncentiveStatuses) {
		Map<String, Integer> activitySummary = new HashMap<String, Integer>();
		
		for (PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus : lPersonProgramActivityIncentiveStatuses) {
			
			if (!activitySummary.containsKey(lPersonProgramActivityIncentiveStatus.getActivityName())) {
				Integer recCount = new Integer(1);
				activitySummary.put(lPersonProgramActivityIncentiveStatus.getActivityName(), recCount);
			} else {
				//count like activities
				Integer recountTemp = activitySummary.get(lPersonProgramActivityIncentiveStatus.getActivityName());
				recountTemp++;
				activitySummary.put(lPersonProgramActivityIncentiveStatus.getActivityName(), recountTemp);
			}
			
		}
		
		return activitySummary;
	}
	
	public void setLookUpValueService(LookUpValueService lookUpValueService) {
		this.lookUpValueService = lookUpValueService;
	}


	public void setBusinessProgramService(
			BusinessProgramService businessProgramService) {
		this.businessProgramService = businessProgramService;
	}
	
	
	
	
	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}

	public void setActivityEventService(ActivityEventService activityEventService) {
		this.activityEventService = activityEventService;
	}
	
	public void setPersonDAO(PersonDAO personDAO) {
		this.personDAO = personDAO;
	}
	
	
	public void setBusinessProgramDAO(BusinessProgramDAO businessProgramDAO) {
		this.businessProgramDAO = businessProgramDAO;
	}
	
	
	
	public void setContractDAO(ContractDAO contractDAO) {
		this.contractDAO = contractDAO;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public void setBpmEmailUtility(BPMEmailUtility bpmEmailUtility) {
		this.bpmEmailUtility = bpmEmailUtility;
	}
	
	

	public void setEmailService(EmailService emailService) {
		this.emailService = emailService;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}
	
	
	
	public ArrayList<PersonProgramActivityIncentiveStatus> getPersonProgramActivityIncentiveStatusForHraAL() {
		return personProgramActivityIncentiveStatusForHraAL;
	}

	public void setPersonProgramActivityIncentiveStatusForHraAL(
			ArrayList<PersonProgramActivityIncentiveStatus> personProgramActivityIncentiveStatusForHraAL) {
		this.personProgramActivityIncentiveStatusForHraAL = personProgramActivityIncentiveStatusForHraAL;
	}

	public ArrayList<PersonProgramActivityIncentiveStatus> getPersonProgramActivityIncentiveStatusForHsaAL() {
		return personProgramActivityIncentiveStatusForHsaAL;
	}

	public void setPersonProgramActivityIncentiveStatusForHsaAL(
			ArrayList<PersonProgramActivityIncentiveStatus> personProgramActivityIncentiveStatusForHsaAL) {
		this.personProgramActivityIncentiveStatusForHsaAL = personProgramActivityIncentiveStatusForHsaAL;
	}

	

	public ArrayList<PersonProgramActivityIncentiveStatus> getPersonProgramActivityIncentiveStatusForIntelispendAL() {
		return personProgramActivityIncentiveStatusForIntelispendAL;
	}

	public void setPersonProgramActivityIncentiveStatusForIntelispendAL(
			ArrayList<PersonProgramActivityIncentiveStatus> personProgramActivityIncentiveStatusForIntelispendAL) {
		this.personProgramActivityIncentiveStatusForIntelispendAL = personProgramActivityIncentiveStatusForIntelispendAL;
	}

	public ArrayList<PersonProgramActivityIncentiveStatus> getMemberProgramActivityIncentiveStatusForHraAL() {
		return memberProgramActivityIncentiveStatusForHraAL;
	}

	public void setMemberProgramActivityIncentiveStatusForHraAL(
			ArrayList<PersonProgramActivityIncentiveStatus> memberProgramActivityIncentiveStatusForHraAL) {
		this.memberProgramActivityIncentiveStatusForHraAL = memberProgramActivityIncentiveStatusForHraAL;
	}

	public ArrayList<PersonProgramActivityIncentiveStatus> getMemberProgramActivityIncentiveStatusForHsaAL() {
		return memberProgramActivityIncentiveStatusForHsaAL;
	}

	public void setMemberProgramActivityIncentiveStatusForHsaAL(
			ArrayList<PersonProgramActivityIncentiveStatus> memberProgramActivityIncentiveStatusForHsaAL) {
		this.memberProgramActivityIncentiveStatusForHsaAL = memberProgramActivityIncentiveStatusForHsaAL;
	}

	public ArrayList<PersonProgramActivityIncentiveStatus> getMemberProgramActivityIncentiveStatusForIntelispendAL() {
		return memberProgramActivityIncentiveStatusForIntelispendAL;
	}

	public void setMemberProgramActivityIncentiveStatusForIntelispendAL(
			ArrayList<PersonProgramActivityIncentiveStatus> memberProgramActivityIncentiveStatusForIntelispendAL) {
		this.memberProgramActivityIncentiveStatusForIntelispendAL = memberProgramActivityIncentiveStatusForIntelispendAL;
	}
	
	

	

	public ArrayList<ActivityEvent> getActivityNotIncentedForContractBasedAL() {
		return activityNotIncentedForContractBasedAL;
	}

	public void setActivityNotIncentedForContractBasedAL(
			ArrayList<ActivityEvent> activityNotIncentedForContractBasedAL) {
		this.activityNotIncentedForContractBasedAL = activityNotIncentedForContractBasedAL;
	}

	public ArrayList<ActivityEvent> getActivityEventsAL() {
		return activityEventsAL;
	}

	public void setActivityEventsAL(ArrayList<ActivityEvent> activityEventsAL) {
		this.activityEventsAL = activityEventsAL;
	}

	public ArrayList<ActivityEvent> getActivityEventPendingAL() {
		return activityEventPendingAL;
	}

	public void setActivityEventPendingAL(
			ArrayList<ActivityEvent> activityEventPendingAL) {
		this.activityEventPendingAL = activityEventPendingAL;
	}

	public ArrayList<ActivityEvent> getActivityEventInProcessAL() {
		return activityEventInProcessAL;
	}

	public void setActivityEventInProcessAL(
			ArrayList<ActivityEvent> activityEventInProcessAL) {
		this.activityEventInProcessAL = activityEventInProcessAL;
	}

	public ArrayList<ActivityEvent> getActivityEventFilteredOutAL() {
		return activityEventFilteredOutAL;
	}

	public void setActivityEventFilteredOutAL(
			ArrayList<ActivityEvent> activityEventFilteredOutAL) {
		this.activityEventFilteredOutAL = activityEventFilteredOutAL;
	}


	public ArrayList<ActivityEvent> getActivityEventUnresolvedMemberIDAL() {
		return activityEventUnresolvedMemberIDAL;
	}

	public void setActivityEventUnresolvedMemberIDAL(
			ArrayList<ActivityEvent> activityEventUnresolvedMemberIDAL) {
		this.activityEventUnresolvedMemberIDAL = activityEventUnresolvedMemberIDAL;
	}
	

	public void setInputRecordCount(Integer inputRecordCount) {
		this.inputRecordCount = inputRecordCount;
	}


	public ArrayList<ActivityEvent> getActivityEventNotEligibleAL() {
		return activityEventNotEligibleAL;
	}

	public void setActivityEventNotEligibleAL(
			ArrayList<ActivityEvent> activityEventNotEligibleAL) {
		this.activityEventNotEligibleAL = activityEventNotEligibleAL;
	}

	

	public ArrayList<ActivityEvent> getActivityNoMatchToActivityRequirementAL() {
		return activityNoMatchToActivityRequirementAL;
	}

	public void setActivityNoMatchToActivityRequirementAL(
			ArrayList<ActivityEvent> activityNoMatchToActivityRequirementAL) {
		this.activityNoMatchToActivityRequirementAL = activityNoMatchToActivityRequirementAL;
	}
	

	public HashMap<String, ActivityEvent> getHaExistsForParticipantCheckmarkReqHM() {
		return haExistsForParticipantCheckmarkReqHM;
	}

	public void setHaExistsForParticipantCheckmarkReqHM(
			HashMap<String, ActivityEvent> haExistsForParticipantCheckmarkReqHM) {
		this.haExistsForParticipantCheckmarkReqHM = haExistsForParticipantCheckmarkReqHM;
	}

	public HashMap<String, ActivityEvent> getHaExistsForParticipantActivityReqHM() {
		return haExistsForParticipantActivityReqHM;
	}

	public void setHaExistsForParticipantActivityReqHM(
			HashMap<String, ActivityEvent> haExistsForParticipantActivityReqHM) {
		this.haExistsForParticipantActivityReqHM = haExistsForParticipantActivityReqHM;
	}

	public ArrayList<ActivityEvent> getActivityNonRewardedAL() {
		return activityNonRewardedAL;
	}

	public void setActivityNonRewardedAL(
			ArrayList<ActivityEvent> activityNonRewardedAL) {
		this.activityNonRewardedAL = activityNonRewardedAL;
	}

	public ArrayList<ActivityEvent> getActivityEventDuplicatesAL() {
		return activityEventDuplicatesAL;
	}

	public void setActivityEventDuplicatesAL(
			ArrayList<ActivityEvent> activityEventDuplicatesAL) {
		this.activityEventDuplicatesAL = activityEventDuplicatesAL;
	}
	
	

	public ArrayList<ActivityEvent> getActivityEventFilteredOutDuplicatesAL() {
		return activityEventFilteredOutDuplicatesAL;
	}

	public void setActivityEventFilteredOutDuplicatesAL(
			ArrayList<ActivityEvent> activityEventFilteredOutDuplicatesAL) {
		this.activityEventFilteredOutDuplicatesAL = activityEventFilteredOutDuplicatesAL;
	}

	

	public ArrayList<ActivityEvent> getActivityNotIncentedForCheckmarkAL() {
		return activityNotIncentedForCheckmarkAL;
	}

	public void setActivityNotIncentedForCheckmarkAL(
			ArrayList<ActivityEvent> activityNotIncentedForCheckmarkAL) {
		this.activityNotIncentedForCheckmarkAL = activityNotIncentedForCheckmarkAL;
	}

	public ArrayList<ActivityEvent> getActivityNotProgramEligibleAL() {
		return activityNotProgramEligibleAL;
	}

	public void setActivityNotProgramEligibleAL(
			ArrayList<ActivityEvent> activityNotProgramEligibleAL) {
		this.activityNotProgramEligibleAL = activityNotProgramEligibleAL;
	}
	
	

	

	public boolean isHraExist() {
		return isHraExist;
	}

	public void setHraExist(boolean isHraExist) {
		this.isHraExist = isHraExist;
	}

	public boolean isHsaExist() {
		return isHsaExist;
	}

	public void setHsaExist(boolean isHsaExist) {
		this.isHsaExist = isHsaExist;
	}

	public boolean isIntelispendExist() {
		return isIntelispendExist;
	}

	public void setIntelispendExist(boolean isIntelispendExist) {
		this.isIntelispendExist = isIntelispendExist;
	}
	

	public boolean isMultiActivityBased() {
		return isMultiActivityBased;
	}

	public void setMultiActivityBased(boolean isMultiActivityBased) {
		this.isMultiActivityBased = isMultiActivityBased;
	}

	public Integer getActivityEventsToProcessCount() {
		return activityEventsToProcessCount;
	}

	public void setActivityEventsToProcessCount(Integer activityEventsToProcessCount) {
		this.activityEventsToProcessCount = activityEventsToProcessCount;
	}

	

	public ArrayList<ActivityEvent> getActivityNotIncentedForActivityBasedRequirementsAL() {
		return activityNotIncentedForActivityBasedRequirementsAL;
	}

	public void setActivityNotIncentedForActivityBasedRequirementsAL(
			ArrayList<ActivityEvent> activityNotIncentedForActivityBasedRequirementsAL) {
		this.activityNotIncentedForActivityBasedRequirementsAL = activityNotIncentedForActivityBasedRequirementsAL;
	}

	public ArrayList<ActivityEvent> getActivityHABypassedAlongWithProgramAL() {
		return activityHABypassedAlongWithProgramAL;
	}

	public void setActivityHABypassedAlongWithProgramAL(
			ArrayList<ActivityEvent> activityHABypassedAlongWithProgramAL) {
		this.activityHABypassedAlongWithProgramAL = activityHABypassedAlongWithProgramAL;
	}

	public ArrayList<ActivityEvent> getActivityWithNoHATakenForMultiActivityAL() {
		return activityWithNoHATakenForMultiActivityAL;
	}

	public void setActivityWithNoHATakenForMultiActivityAL(
			ArrayList<ActivityEvent> activityWithNoHATakenForMultiActivityAL) {
		this.activityWithNoHATakenForMultiActivityAL = activityWithNoHATakenForMultiActivityAL;
	}

	public void setActivityNotLeadToRewardAL(
			ArrayList<ActivityEvent> activityNotLeadToRewardAL) {
		this.activityNotLeadToRewardAL = activityNotLeadToRewardAL;
	}

	public ArrayList<ActivityEvent> getActivityNotIncentedForMemberBasedAL() {
		return activityNotIncentedForMemberBasedAL;
	}
	

	public void setActivityNotIncentedForMemberBasedAL(
			ArrayList<ActivityEvent> activityNotIncentedForMemberBasedAL) {
		this.activityNotIncentedForMemberBasedAL = activityNotIncentedForMemberBasedAL;
	}

	public ArrayList<ActivityEvent> getActivityIncentedForContractBasedAL() {
		return activityIncentedForContractBasedAL;
	}

	public void setActivityIncentedForContractBasedAL(
			ArrayList<ActivityEvent> activityIncentedForContractBasedAL) {
		this.activityIncentedForContractBasedAL = activityIncentedForContractBasedAL;
	}

	public ArrayList<ActivityEvent> getActivityIncentedForMemberBasedAL() {
		return activityIncentedForMemberBasedAL;
	}

	public void setActivityIncentedForMemberBasedAL(
			ArrayList<ActivityEvent> activityIncentedForMemberBasedAL) {
		this.activityIncentedForMemberBasedAL = activityIncentedForMemberBasedAL;
	}
	
	
	
}

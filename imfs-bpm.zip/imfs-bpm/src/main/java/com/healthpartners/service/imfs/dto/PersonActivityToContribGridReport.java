package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.util.Calendar;

public class PersonActivityToContribGridReport implements Serializable
{	
	static final long serialVersionUID = 0L;
	
	private Integer programID;
	
	private String groupNumber;
	
	private String siteNumber;
	
	private String incentiveStatusType;
	
	private String incentiveOptionName;
	
	private String incentiveRuleTypeDesc;
	
	private String memberNumber;
	
	private Integer contractNumber;
	
	private String relationshipName;
	
	private String activityName;
		
	public PersonActivityToContribGridReport()
	{
		super();
	}
	
	

	public Integer getProgramID() {
		return programID;
	}



	public void setProgramID(Integer programID) {
		this.programID = programID;
	}



	public String getGroupNumber() {
		return groupNumber;
	}

	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}

	public String getSiteNumber() {
		return siteNumber;
	}

	public void setSiteNumber(String siteNumber) {
		this.siteNumber = siteNumber;
	}

	public String getIncentiveStatusType() {
		return incentiveStatusType;
	}

	public void setIncentiveStatusType(String incentiveStatusType) {
		this.incentiveStatusType = incentiveStatusType;
	}

	public String getIncentiveOptionName() {
		return incentiveOptionName;
	}

	public void setIncentiveOptionName(String incentiveOptionName) {
		this.incentiveOptionName = incentiveOptionName;
	}

	public String getIncentiveRuleTypeDesc() {
		return incentiveRuleTypeDesc;
	}

	public void setIncentiveRuleTypeDesc(String incentiveRuleTypeDesc) {
		this.incentiveRuleTypeDesc = incentiveRuleTypeDesc;
	}

	public String getMemberNumber() {
		return memberNumber;
	}

	public void setMemberNumber(String memberNumber) {
		this.memberNumber = memberNumber;
	}

	

	public Integer getContractNumber() {
		return contractNumber;
	}



	public void setContractNumber(Integer contractNumber) {
		this.contractNumber = contractNumber;
	}



	public String getRelationshipName() {
		return relationshipName;
	}

	public void setRelationshipName(String relationshipName) {
		this.relationshipName = relationshipName;
	}

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	
	
	
}

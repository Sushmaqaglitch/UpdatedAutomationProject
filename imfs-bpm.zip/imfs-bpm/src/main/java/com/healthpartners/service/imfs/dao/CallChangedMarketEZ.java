package com.healthpartners.service.imfs.dao;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;

import oracle.jdbc.internal.OracleTypes;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.object.StoredProcedure;


/**
 * Calls the Stored Procedure pkg_bpm_smarts.changedMarketEZ.
 * 
 * @author jxbourbour
 *
 */
@Configuration
public class CallChangedMarketEZ extends StoredProcedure 
{

	protected final Log logger = LogFactory.getLog(getClass());


	@Autowired
	DataSource bpmDataSource;


	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}

    private static final String STORED_PROC_NAME = "pkg_bpm_smarts.changedMarketEZ";

    public CallChangedMarketEZ(DataSource bpmDataSource)
    {
        super(bpmDataSource, STORED_PROC_NAME);
        
        // Input Parameter
        // None.
        
        // Output Parameters                           
        declareParameter(new SqlOutParameter("o_changed_mrkt_cursor", OracleTypes.CURSOR, new RowMapper<String>() 
        {
			
			public String mapRow(ResultSet lResultSet, int rowNum) throws SQLException 
			{
				StringBuffer lLine = new StringBuffer();    			    			
    			
    			lLine.append(lResultSet.getInt("grp_id"));
    			lLine.append(",");
    			lLine.append(lResultSet.getInt("subgrp_id"));
    			lLine.append(",");
    			
    			lLine.append(lResultSet.getString("biz_pgm_tp_cd"));
    			lLine.append(",");
    			lLine.append(lResultSet.getString("biz_pgm_nm"));
    			lLine.append(",");
    			
    			lLine.append(lResultSet.getString("next_renewal"));
    			lLine.append(",");
    			lLine.append(lResultSet.getString("last_renewal"));
    			lLine.append(",");
    			
    			lLine.append(lResultSet.getInt("MKT_SEGMENT_ID"));
    			lLine.append(",");
    			lLine.append(lResultSet.getString("grp_no"));
    			lLine.append(",");    			
    			lLine.append((lResultSet.getString("empl_grp_nm")).replace(',', '-'));
    			lLine.append(",");
    			lLine.append(lResultSet.getString("site_id_no"));
    			lLine.append(",");    			
    			lLine.append((lResultSet.getString("EMPL_GRP_SITE_NM")).replace(',', '-'));
    			lLine.append(",");
    			
    			lLine.append(lResultSet.getString("emp_pkg_size_indicator_cd"));
    			lLine.append(",");
    			lLine.append(lResultSet.getString("BEN_PKG_TP_CD"));
    			lLine.append(",");
    			lLine.append(lResultSet.getString("BEN_PKG_NM"));
    			lLine.append(",");
    			lLine.append(lResultSet.getString("PKG_EFF_DT"));
    			lLine.append(",");
    			lLine.append(lResultSet.getString("PKG_END_DT"));
    			    			    			
    			lLine.append("\r\n");
    			
    			return lLine.toString();
			}
		})); 
        
        compile();
    }

    /**
     * 
     * 
     * @param pFilePath
     * @return
     */
    public String execute(String pFilePath)    
    {    	    	
        Map<String, Object> lInputParams = new HashMap<String, Object>(0);
                        
        Map<String, Object> lOutputParams = execute(lInputParams);
                                       
        if(lOutputParams.size() > 0) 
        {           	
        	Calendar lToday = Calendar.getInstance();
        	
        	String lPathAndFileName = pFilePath + BPMConstants.BPM_CHANGED_MARKET_EZ_FOLDER + "/"
        	                                    + BPMConstants.BPM_CHANGED_MARKET_FILE_NAME + "-" + BPMUtils.formatDateCCYYmmddWODel(lToday.getTime()) + ".csv";
        	        	
        	BufferedWriter lBufferedWriter = null;
        	
        	try
        	{      
        		lBufferedWriter = new BufferedWriter(new FileWriter(lPathAndFileName));
        		
        		StringBuffer lColumnHeaders = new StringBuffer();        		
        		lColumnHeaders.append("GRP_ID,");
        		lColumnHeaders.append("SUBGRP_ID,");
        		lColumnHeaders.append("biz_pgm_tp_cd,");
        		lColumnHeaders.append("biz_pgm_nm,");
        		lColumnHeaders.append("NEXT_RENEWAL_DT,");
        		lColumnHeaders.append("LAST_RENEWAL_DT,");
        		
        		lColumnHeaders.append("MKT_SEGMENT_ID,");
        		lColumnHeaders.append("EMPL_GRP_NO,");
        		lColumnHeaders.append("EMPL_GRP_NM,");
        		
        		lColumnHeaders.append("SITE_NO,");
        		lColumnHeaders.append("SITE_NM,");
        		
        		lColumnHeaders.append("PKG_SIZE_IND,");
        		
        		lColumnHeaders.append("BEN_PKG_TP_CD,");
        		lColumnHeaders.append("BEN_PKG_NM,");
        		lColumnHeaders.append("PKG_EFF_DT,");
        		lColumnHeaders.append("PKG_END_DT");
        		
        		
        		lColumnHeaders.append("\r\n");
        		        		
        		lBufferedWriter.write(lColumnHeaders.toString());
        		
        		
        		ArrayList<String> lResults = (ArrayList<String>)lOutputParams.get("o_changed_mrkt_cursor");

        		for(String lLine : lResults)
        		{        			
        			lBufferedWriter.write(lLine);                    
        		}
        		
        		lBufferedWriter.flush();
        		lBufferedWriter.close();
        	}
        	catch(Exception e)
        	{        		        		
        		BPMUtils.logException(logger, e);
        		return "Error. Please check the log file.";
        	}        	
        	
        	return lPathAndFileName;
        }                 
        
        return "No Data Today.";
    }

		        
}

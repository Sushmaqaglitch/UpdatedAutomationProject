package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.sql.Date;
import java.util.Calendar;

public class CDHPFulfillmentTrackingReport implements Serializable
{	
	static final long serialVersionUID = 0L;
	
	private Integer CDHPTransID;
	private Integer programID;
	private String   groupNo;
	private Integer personID;
	private Integer personDemographicsID;
	private Integer groupID;
	private Integer packageID;
	private String  memberNo;
	private Integer contractNo;
	private String  firstName;
	private String  lastName;
	private String  middleName;
	private Date contributionStartDate;
	private Date contributionEndDate;
	private Integer contributionAmount;
	private Integer  contributionTypeCodeId;
	private String  contributionTypeCode;
	private String  contributionType;
	private Date 	contributionDate;
	private Integer memberCount;
	private Date    fileSentDate;
	private String incentiveReportName;
	private String fulfillmentRoutingType;
	private String employerGroupName;
	private String socialSecurityNo;
	
	
	
	
	public Integer getCDHPTransID() {
		return CDHPTransID;
	}
	public void setCDHPTransID(Integer transID) {
		CDHPTransID = transID;
	}
	public Integer getProgramID() {
		return programID;
	}
	public void setProgramID(Integer programID) {
		this.programID = programID;
	}
	
	public String getGroupNo() {
		return groupNo;
	}
	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}
	
	public Integer getPersonID() {
		return personID;
	}
	public void setPersonID(Integer personID) {
		this.personID = personID;
	}
	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}
	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}
	
	
	
	public Integer getGroupID() {
		return groupID;
	}
	public void setGroupID(Integer groupID) {
		this.groupID = groupID;
	}
	
	public Integer getPackageID() {
		return packageID;
	}
	public void setPackageID(Integer packageID) {
		this.packageID = packageID;
	}
	public String getMemberNo() {
		return memberNo;
	}
	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}
	public Integer getContractNo() {
		return contractNo;
	}
	public void setContractNo(Integer contractNo) {
		this.contractNo = contractNo;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	
	public Date getContributionStartDate() {
		return contributionStartDate;
	}
	public void setContributionStartDate(Date contributionStartDate) {
		this.contributionStartDate = contributionStartDate;
	}
	public Date getContributionEndDate() {
		return contributionEndDate;
	}
	public void setContributionEndDate(Date contributionEndDate) {
		this.contributionEndDate = contributionEndDate;
	}
	public Integer getContributionAmount() {
		return contributionAmount;
	}
	public void setContributionAmount(Integer contributionAmount) {
		this.contributionAmount = contributionAmount;
	}
	public String getContributionTypeCode() {
		return contributionTypeCode;
	}
	public void setContributionTypeCode(String contributionTypeCode) {
		this.contributionTypeCode = contributionTypeCode;
	}
	
	public Integer getContributionTypeCodeId() {
		return contributionTypeCodeId;
	}
	public void setContributionTypeCodeId(Integer contributionTypeCodeId) {
		this.contributionTypeCodeId = contributionTypeCodeId;
	}
	
	public String getContributionType() {
		return contributionType;
	}
	public void setContributionType(String contributionType) {
		this.contributionType = contributionType;
	}
	
	public Date getContributionDate() {
		return contributionDate;
	}
	public void setContributionDate(Date contributionDate) {
		this.contributionDate = contributionDate;
	}
	public Integer getMemberCount() {
		return memberCount;
	}
	public void setMemberCount(Integer memberCount) {
		this.memberCount = memberCount;
	}
	
	
	public Date getFileSentDate() {
		return fileSentDate;
	}
	public void setFileSentDate(Date fileSentDate) {
		this.fileSentDate = fileSentDate;
	}
	public String getIncentiveReportName() {
		return incentiveReportName;
	}
	public void setIncentiveReportName(String incentiveReportName) {
		this.incentiveReportName = incentiveReportName;
	}
	public String getFulfillmentRoutingType() {
		return fulfillmentRoutingType;
	}
	public void setFulfillmentRoutingType(String fulfillmentRoutingType) {
		this.fulfillmentRoutingType = fulfillmentRoutingType;
	}
	public String getEmployerGroupName() {
		return employerGroupName;
	}
	public void setEmployerGroupName(String employerGroupName) {
		this.employerGroupName = employerGroupName;
	}
	public String getSocialSecurityNo() {
		return socialSecurityNo;
	}
	public void setSocialSecurityNo(String socialSecurityNo) {
		this.socialSecurityNo = socialSecurityNo;
	}
	
	
	
}

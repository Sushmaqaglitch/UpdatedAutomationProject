/**
 * 
 */
package com.healthpartners.service.imfs.impl;

import java.util.ArrayList;
import java.util.Collection;

import com.healthpartners.service.imfs.dao.QualificationOverrideDAO;
import com.healthpartners.service.imfs.dto.QualificationOverride;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.iface.QualificationOverrideService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.exception.BPMException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;


/**
 * @author tjquist
 * 
 */
@Component
@Service
public class QualificationOverrideServiceImpl implements
		QualificationOverrideService {

	/**
	 * This instance will be (automatically) dependency injected.
	 */
	@Autowired
	private QualificationOverrideDAO qualificationOverrideDAO;
	
	
	/*
	 * @see com.healthpartners.service.bpm.dao.QualificationOverrideServiceImpl#getAllQualificationOverrides(java.lang.Integer,
	 *      java.lang.Integer)
	 */
	public Collection<QualificationOverride> getAllQualificationOverrides(
			Integer personID)
			throws DataAccessException {
		return qualificationOverrideDAO
				.getAllQualificationOverrides(personID);
	}


	/*
	 * @see com.healthpartners.service.bpm.iface.QualificationOverrideService#issueExemption(com.healthpartners.service.bpm.dto.QualificationOverride)
	 */
	public void issueMemberExemption(QualificationOverride qualificationOverride)
			throws BPMException, DataAccessException {
		issueQualificationOverride(qualificationOverride);
	}

	/*
	 * @see com.healthpartners.service.bpm.iface.QualificationOverrideService#issueExemption(java.util.Collection)
	 */
	public void issueMemberExemption(
			Collection<QualificationOverride> qualificationOverrides)
			throws BPMException, DataAccessException {
		issueQualificationOverride(qualificationOverrides);
	}

	/**
	 * private method -internal use
	 * 
	 * @param qualificationOverride
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	private long issueQualificationOverride(
			QualificationOverride qualificationOverride) throws BPMException,
			DataAccessException {
		return qualificationOverrideDAO
				.insertQualificationOverride(qualificationOverride);
	}

	/**
	 * private method -internal use
	 * 
	 * @param qualificationOverrides
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	private Long[] issueQualificationOverride(
			Collection<QualificationOverride> qualificationOverrides)
			throws BPMException, DataAccessException 
	{
		ArrayList<Long> qovs = new ArrayList<Long>();
	
		for(int qov = 0; qov < qualificationOverrides.size(); qov++)
		{
		    qovs.add(qualificationOverrideDAO
				.insertQualificationOverride(((ArrayList<QualificationOverride>)qualificationOverrides).get(qov)));		    
		}
		
		Long[] qovArray = new Long[qovs.size()];		
		qovs.toArray(qovArray);
		
		return qovArray;
	}

	public void deleteAutomaticMemberExemptions(
			Collection<QualificationOverride> qualificationOverrides)
			throws BPMException, DataAccessException {
		qualificationOverrideDAO.deleteAutomaticMemberExemptions(qualificationOverrides);

	}
	
	
	
	/**
	 * Gets the <code>dao</code> instance variable (injected by Spring).
	 * 
	 * @return QualificationOverrideDAO
	 */
	public QualificationOverrideDAO getQualificationOverrideDAO() {
		return qualificationOverrideDAO;
	}

	/**
	 * Set the <code>dao</code> instance variable (injected by Spring).
	 *
	 */
	public void setQualificationOverrideDAO(
			QualificationOverrideDAO qualificationOverrideDAO) {
		this.qualificationOverrideDAO = qualificationOverrideDAO;
	}

}

/**
 * 
 */
package com.healthpartners.service.imfs.filter;

import com.healthpartners.service.imfs.dto.ActivityEvent;
import com.healthpartners.service.imfs.exception.BPMException;

/**
 * @author mxthoutam
 * 
 */
public interface ActivityEventFilter {

	public String doFilter(ActivityEvent activityEvent) throws BPMException;
}

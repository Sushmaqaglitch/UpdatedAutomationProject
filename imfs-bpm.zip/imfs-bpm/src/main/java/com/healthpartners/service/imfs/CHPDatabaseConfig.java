//package com.healthpartners.service.imfs;
//
//import org.springframework.boot.context.properties.ConfigurationProperties;
//import org.springframework.boot.jdbc.DataSourceBuilder;
//import org.springframework.context.annotation.AnnotationConfigApplicationContext;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//import javax.sql.DataSource;
//
//@Configuration
//public class CHPDatabaseConfig {
//
////    @Value("${SPRING_CHP_DATASOURCE_USERNAME}")
////    private String chpUsername;
////
////    @Value("${SPRING_CHP_DATASOURCE_PASSWORD}")
////    private String chpPassword;
////
////    @Value("${SPRING_CHP_DATASOURCE_URL}")
////    private String chpUrl;
//
//
//    // bpm database
//    @Bean(name = "chpDataSource")
//    @ConfigurationProperties(prefix = "spring.datasource.chp")
//    public DataSource getDataSource() {
//
//        DataSource dataSource = DataSourceBuilder.create().build();
//        return dataSource;
//    }
//
//    public static void main(String[] args) {
//        AnnotationConfigApplicationContext context =
//                new AnnotationConfigApplicationContext(CHPDatabaseConfig.class);
//
//    }
//
//}

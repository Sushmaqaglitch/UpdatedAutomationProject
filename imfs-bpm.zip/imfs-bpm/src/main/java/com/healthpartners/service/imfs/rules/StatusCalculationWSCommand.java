/* $Id$ */

package com.healthpartners.service.imfs.rules;

import java.util.HashMap;
import java.util.Map;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.dto.ActivityEvent;
import com.healthpartners.service.imfs.dto.BaseDTO;
import com.healthpartners.service.imfs.dto.TaskEvent;

/**
 * Class represents a command object to send throgh JMS message for status
 * calculation job.
 * 
 * Refer com.healthpartners.service.bpm.impl.ProgramStatusCalculationServiceImpl
 * class and its mehod updateProgramStatus(StatusCalculationCommand
 * statusCalculationCommand) for furher details.
 * 
 * This class stores type of command to perform in the Map<String, Object>
 * parametersMap.
 * These commands will drive the batch webservice.
 * 
 * @author tjquist
 * 
 */
public class StatusCalculationWSCommand extends BaseDTO {

	static final long serialVersionUID = 0L;

	public static final String ACTIVITY_EVENT = "ACTIVITY_EVENT";

	public static final String TASK_EVENT = "TASK_EVENT";
														  
	public static final String PENDING_ACTIVITY_EVENTS = "PENDING_ACTIVITY_EVENTS";
	
	public static final String FILTERED_ACTIVITY_EVENTS = "FILTERED_ACTIVITY_EVENTS";

	public static final String PENDING_TASK_EVENTS = "PENDING_TASK_EVENTS";

	public static final String ETL_MEMBERSHIP_UPDATE = "ETL_MEMBERSHIP_UPDATE";

	public static final String MEMBER_ELAPSED_TIME = "MEMBER_ELAPSED_TIME";

	public static final String PURGE_AUDIT_LOG_TABLE = "PURGE_AUDITLOG_TABLE";
	
	public static final String PURGE_PROCESSLG_TABLE = "PURGE_PROCSTATLOG_TABLE";

	public static final String PURGE_GROUPBASELINEHIST_TABLE = "PURGE_GROUPBASELINEHIST_TABLE";

	public static final String PARAM_BATCH_SIZE = "PARAM_BATCH_SIZE";

	public static final String ONE_PERSON = "ONE_PERSON";

	public static final String MEMBERS_RECALCULATION = "MEMBERS_RECALCULATION";

	public static final String MEMBERSHIP_FEED = "MEMBERSHIP_FEED";
	
	public static final String MEMBERSHIP_PREMIUM_BILLING_FEED = "MEMBERSHIP_PREMIUM_BILLING_FEED";
	
	public static final String AUTO_PROGRAM_SETUP = "AUTO_PROGRAM_SETUP";
	
	public static final String AUTO_PROGRAM_NEW_SETUP = "AUTO_PROGRAM_NEW_SETUP";
	
	public static final String EMPLOYER_GROUP_SITE_SETUP = "EMPLOYER_GROUP_SITE_SETUP";
	
	public static final String EMPLOYER_BASELINE_SETUP = "EMPLOYER_BASELINE_SETUP";
	
	
	public static final String CONTRACT_RECONCILIATION = "CONTRACT_RECONCILIATION";
	
	public static final String EMPLOYER_FULFILLMENT_REPORTING = "EMPLOYER_FULFILLMENT";
	public static final String EMPLOYER_FULFILLMENT_REPORTING_RESEND = "EMPLOYER_FULFILLMENT_RESEND";
	
	public static final String CDHP_HRA_FULFILLMENT_REPORTING = "CDHP_HRA_FULFILLMENT";
	public static final String CDHP_HSA_FULFILLMENT_REPORTING = "CDHP_HSA_FULFILLMENT";

	// public static final String ALL_BUSINESS_PROGRAMS =
	// "ALL_BUSINESS_PROGRAMS";

	// public static final String ONE_BUSINESS_PROGRAM = "ONE_BUSINESS_PROGRAM";

	// map to store type of command
	private Map<String, Object> parametersMap = new HashMap<String, Object>();

	private String userID;

	private String processName;

	// type of process - ex memberhip update etl job - 1, re-calculation-2,
	// admin membership update-10, admin re calc-11
	private Map<String, Integer> processIDsMap = new HashMap<String, Integer>();
	
	//used at the time of processing
	private String currentProcessingCommand;
	
	private String currentCommandText;
	
	public String BASE_URL;
	
	private String groupNo;
	
	public String snapShotEmplFulfillTrackDate;
	
	public String startEmplFulfillTrackDate;
	
	private int daySpanToCtrlFilteredOutActivity;
				  
	

	


	public StatusCalculationWSCommand() { 
		super();
	}

	// / getParametersMap(), setParametersMap() are used in spring configuration
	// for Batch processing
	public Map<String, Object> getParametersMap() {
		return parametersMap;
	}

	public void setParametersMap(Map<String, Object> parametersMap) {
		this.parametersMap = parametersMap;
	}

	public Map<String, Integer> getProcessIDsMap() {
		return processIDsMap;
	}

	public void setProcessIDsMap(Map<String, Integer> processIDsMap) {
		this.processIDsMap = processIDsMap;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}


	
	// ////Use public utility methods to set or get in all programs///////////
	private Object getParameter(String paramName) {
		return parametersMap.get(paramName);
	}

	private void setParameter(String paramName, Object value) {
		parametersMap.put(paramName, value);
	}

	private void setProcessID(String paramName, Integer processID) {
		processIDsMap.put(paramName, processID);
	}

	private Integer getProcessID(String paramName) {
		//default to zero
		Integer lProcessID = new Integer(0);
		if (processIDsMap.get(paramName) != null) {
			lProcessID = processIDsMap.get(paramName);
		}
		return lProcessID;
	}
	
	// /////////ALL Utility Methods///////////
	// 1. activity event
	public boolean isActivityEventCommand() {
		boolean result = parametersMap.containsKey(ACTIVITY_EVENT);
		return result;
	}

	public ActivityEvent getActivityEvent() {
		ActivityEvent activityEvent = null;
		if (isActivityEventCommand()) {
			activityEvent = (ActivityEvent) getParameter(StatusCalculationWSCommand.ACTIVITY_EVENT);
		}
		return activityEvent;
	}

	public void setActivityEventCommand(ActivityEvent activityEvent) {
		setParameter(ACTIVITY_EVENT, activityEvent);
	}

	// 2. task event
	public boolean isTaskEventCommand() {
		boolean result = parametersMap.containsKey(TASK_EVENT);
		return result;
	}

	public TaskEvent getTaskEvent() {
		TaskEvent taskEvent = null;
		if (isTaskEventCommand()) {
			taskEvent = (TaskEvent) getParameter(StatusCalculationWSCommand.TASK_EVENT);
		}
		return taskEvent;
	}

	public void setTaskEventCommand(TaskEvent taskEvent) {
		setParameter(TASK_EVENT, taskEvent);
	}

	// 3 pending activity events
	public boolean isPendingActivityEventsCommand() {
		boolean result = parametersMap.containsKey(PENDING_ACTIVITY_EVENTS);
		return result;
	}

	public void setPendingActivityEventsCommand() {
		setParameter(PENDING_ACTIVITY_EVENTS, PENDING_ACTIVITY_EVENTS);
	}
	
	// 4 filtered activity events
	public boolean isFilteredActivityEventsCommand() {
		boolean result = parametersMap.containsKey(FILTERED_ACTIVITY_EVENTS);
		return result;
	}

	public void setFilteredActivityEventsCommand() {
		setParameter(FILTERED_ACTIVITY_EVENTS, FILTERED_ACTIVITY_EVENTS);
	}
	
	// 5 pending task events
	public boolean isPendingTaskEventsCommand() {
		boolean result = parametersMap.containsKey(PENDING_TASK_EVENTS);
		return result;
	}

	public void setPendingTaskEventsCommand() {
		setParameter(PENDING_TASK_EVENTS, PENDING_TASK_EVENTS);
	}

	// 6. etl membership update
	public boolean isEtlMembershipUpdateCommand() {
		boolean result = parametersMap.containsKey(ETL_MEMBERSHIP_UPDATE);
		return result;
	}

	public boolean isCurrentProcessingEtlMembershipUpdateCommand() {
		boolean result = false;
		if(ETL_MEMBERSHIP_UPDATE.equalsIgnoreCase(currentProcessingCommand)){
			result = true;
		}
		return result;
	}
	
	public void setEtlMembershipUpdateCommand() {
		setParameter(ETL_MEMBERSHIP_UPDATE, ETL_MEMBERSHIP_UPDATE);
	}

	public void setProcessIDForEtlMembershipUpdateCommand(Integer pProcessID) {
		setProcessID(ETL_MEMBERSHIP_UPDATE, pProcessID);
	}
	

	// 7. elapsed time
	public boolean isMemberElapsedTimeCommand() {
		boolean result = parametersMap.containsKey(MEMBER_ELAPSED_TIME);
		return result;
	}

	public void setMemberElapsedTimeCommand() {
		setParameter(MEMBER_ELAPSED_TIME,
				BPMConstants.MEMBER_ELAPSED_TIME_FILE_XML);
	}

	public void setProcessIDForMemberElapsedTimeCommand(Integer pProcessID) {
		setProcessID(MEMBER_ELAPSED_TIME, pProcessID);
	}

	
	// 8. one member
	public boolean isOnePersonCommand() {
		boolean result = parametersMap.containsKey(ONE_PERSON);
		return result;
	}

	public Integer getOnePersonID() {
		Integer personID = null;
		if (isOnePersonCommand()) {
			personID = (Integer) getParameter(StatusCalculationWSCommand.ONE_PERSON);
		}
		return personID;
	}

	public void setOnePersonCommand(Integer onePersonID) {
		setParameter(ONE_PERSON, onePersonID);
	}

	
	// 9. batch size
	public boolean isBatchSizeCommandSet() {
		boolean result = parametersMap.containsKey(PARAM_BATCH_SIZE);
		return result;
	}

	public Integer getBatchSize() {
		Integer batchSize = null;
		if (isBatchSizeCommandSet()) {
			batchSize = (Integer) getParameter(StatusCalculationWSCommand.PARAM_BATCH_SIZE);
		}
		return batchSize;
	}

	public void setBatchSizeCommand(Integer batchSize) {
		setParameter(PARAM_BATCH_SIZE, batchSize);
	}

	// 10 members recalculation commad \
	public boolean isMembersReCalculationCommand() {
		boolean result = parametersMap.containsKey(MEMBERS_RECALCULATION);
		return result;
	}

	public void setMembersReCalculationCommand() {
		setParameter(MEMBERS_RECALCULATION, MEMBERS_RECALCULATION);
	}

	public void setProcessIDForMembersReCalculationCommand(Integer pProcessID) {
		setProcessID(MEMBERS_RECALCULATION, pProcessID);
	}
	

	// 11 membership feed
	public boolean isMbrShipFeedCommand() {
		boolean result = parametersMap.containsKey(MEMBERSHIP_FEED);
		return result;
	}

	public void setMbrShipFeedCommand() {
		setParameter(MEMBERSHIP_FEED, MEMBERSHIP_FEED);
	}
	
	// 12 membership premium billing feed
		public boolean isMbrShipPremiumBillingFeedCommand() {
			boolean result = parametersMap.containsKey(MEMBERSHIP_PREMIUM_BILLING_FEED);
			return result;
		}

		public void setMbrShipPremiumBillingFeedCommand() {
			setParameter(MEMBERSHIP_PREMIUM_BILLING_FEED, MEMBERSHIP_PREMIUM_BILLING_FEED);
		}
	
	public boolean isAutoProgramSetup()
	{
		boolean result = parametersMap.containsKey(AUTO_PROGRAM_SETUP);
		return result;
	}
	
	
	public void setAutoGroupSetup()
	{
		setParameter(AUTO_PROGRAM_SETUP, AUTO_PROGRAM_SETUP);
	}
	
	public boolean isAutoProgramNewSetup()
	{
		boolean result = parametersMap.containsKey(AUTO_PROGRAM_NEW_SETUP);
		return result;
	}
	
	public void setAutoProgramNewSetup()
	{
		setParameter(AUTO_PROGRAM_NEW_SETUP, AUTO_PROGRAM_NEW_SETUP);
	}
	
	public boolean isAutoGroupSiteSetup()
	{
		boolean result = parametersMap.containsKey(EMPLOYER_GROUP_SITE_SETUP);
		return result;
	}
	
	public void setAutoGroupSiteSetup()
	{
		setParameter(EMPLOYER_GROUP_SITE_SETUP, EMPLOYER_GROUP_SITE_SETUP);
	}
	
	public boolean isAutoEmployerBaselineSetup()
	{
		boolean result = parametersMap.containsKey(EMPLOYER_BASELINE_SETUP);
		return result;
	}
	
	public void setAutoEmployerBaselineSetup()
	{
		setParameter(EMPLOYER_BASELINE_SETUP, EMPLOYER_BASELINE_SETUP);
	}
	
	// 12 purge audit log table by date commad 
	
	public boolean isPurgeAuditLogTableCommand()
	{
		
		boolean result = parametersMap.containsKey(PURGE_AUDIT_LOG_TABLE);
		return result;
	}
	
	public void setPurgeAuditLogTableCommand() {
		setParameter(PURGE_AUDIT_LOG_TABLE,
				PURGE_AUDIT_LOG_TABLE);
	}
	
// 13 purge audit log table by date commad 
	
	public boolean isPurgeProcessStatLogTableCommand()
	{		
		
		boolean result = parametersMap.containsKey(PURGE_PROCESSLG_TABLE);

		return result;
	}
	
	public void setPurgeProcessStatLogTableCommand() {
		setParameter(PURGE_PROCESSLG_TABLE,
				PURGE_PROCESSLG_TABLE);
	}

	// 13.5 purge group baseline history table by date commad

	public boolean isPurgeGroupBaselineHistTableCommand()
	{

		boolean result = parametersMap.containsKey(PURGE_GROUPBASELINEHIST_TABLE);

		return result;
	}

	public void setPurgeGroupBaselineHistTableCommand() {
		setParameter(PURGE_GROUPBASELINEHIST_TABLE,
				PURGE_GROUPBASELINEHIST_TABLE);
	}

// 14 person contract history reconciliation command 
	
	public boolean isPersonContractHistReconciliationCommand()
	{		
		
		boolean result = parametersMap.containsKey(CONTRACT_RECONCILIATION);

		return result;
	}
	
	public void setPersonContractHistReconciliationCommandCommand() {
		setParameter(CONTRACT_RECONCILIATION,
				CONTRACT_RECONCILIATION);
	}
	
// 15 employer reporting fulfillment command 
	
	public boolean isEmployerReportingFulfillmentCommand()
	{		
		
		boolean result = parametersMap.containsKey(EMPLOYER_FULFILLMENT_REPORTING);

		return result;
	}
	
	public void setEmployerReportingFulfillmentCommand() {
		setParameter(EMPLOYER_FULFILLMENT_REPORTING,
				EMPLOYER_FULFILLMENT_REPORTING);
	}
	
// 15 resend employer reporting fulfillment command 
	
	public boolean isResendEmployerReportingFulfillmentCommand()
	{		
		
		boolean result = parametersMap.containsKey(EMPLOYER_FULFILLMENT_REPORTING_RESEND);

		return result;
	}
	
	public void setResendEmployerReportingFulfillmentCommand() {
		setParameter(EMPLOYER_FULFILLMENT_REPORTING_RESEND,
				EMPLOYER_FULFILLMENT_REPORTING_RESEND);
	}
	
// 16  cdhp hra member fulfillment command
	
	public boolean isProcessCDHPHRAFulfillment()
	{		
		
		boolean result = parametersMap.containsKey(CDHP_HRA_FULFILLMENT_REPORTING);

		return result;
	}
	
	public void setProcessCDHPHRAFulfillmentCommand() {
		setParameter(CDHP_HRA_FULFILLMENT_REPORTING,
				CDHP_HRA_FULFILLMENT_REPORTING);
	}
	
// 17  cdhp hsa member fulfillment command
	
	public boolean isProcessCDHPHSAFulfillment()
	{		
		
		boolean result = parametersMap.containsKey(CDHP_HSA_FULFILLMENT_REPORTING);

		return result;
	}
	
	public void setProcessCDHPHSAFulfillmentCommand() {
		setParameter(CDHP_HSA_FULFILLMENT_REPORTING,
				CDHP_HSA_FULFILLMENT_REPORTING);
	}
	
	public String getStartEmplFulfillTrackDate() {
		return startEmplFulfillTrackDate;
	}


	public void setStartEmplFulfillTrackDate(String startEmplFulfillTrackDate) {
		this.startEmplFulfillTrackDate = startEmplFulfillTrackDate;
	}

	public String getSnapShotEmplFulfillTrackDate() {
		return snapShotEmplFulfillTrackDate;
	}
	
	public void setSnapShotEmplFulfillTrackDate(String snapshotEmplFulfillTrackDate) {
		this.snapShotEmplFulfillTrackDate = snapshotEmplFulfillTrackDate;
	}
	
	
	
	
	/**
	 * is it not batch commad?
	 * 
	 * @return boolean
	 */
	public boolean isNotABatchCommand() {
		// add any more types
		return (isActivityEventCommand() || isTaskEventCommand() || isOnePersonCommand());
	}

	/**
	 * is it batch commad?
	 * 
	 * @return boolean
	 */
	public boolean isBatchCommand() {
		// || isAllMembersCommand()
		// || isOneBusinessProgramCommand() || isAllBusinessProgramsCommand());
		return (isEtlMembershipUpdateCommand() 
				|| isMemberElapsedTimeCommand()
				|| isPendingActivityEventsCommand()
				|| isPendingTaskEventsCommand()
				|| isMembersReCalculationCommand()
				|| isEmployerReportingFulfillmentCommand()
				|| isResendEmployerReportingFulfillmentCommand()
				|| isMbrShipFeedCommand()
				|| isMbrShipPremiumBillingFeedCommand()
				|| isProcessCDHPHRAFulfillment());
	}


	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}

	public String getCurrentProcessingCommand() {
		return currentProcessingCommand;
	}

	public void setCurrentProcessingCommand(String currentProcessingCommand) {
		this.currentProcessingCommand = currentProcessingCommand;
	}
	
	public void resetCurrentProcessingCommand() {
		this.currentProcessingCommand = null;
	}
	
	

	public Integer getProcessIDForCurrentProcessingCommand(){
		//default to zero
		Integer lProcessID = new Integer(0);
		if (currentProcessingCommand != null && processIDsMap.get(currentProcessingCommand) != null) {
			lProcessID = getProcessID(currentProcessingCommand);
		}
		return lProcessID;
	}
	
	public String getCurrentCommandText() {
		return currentCommandText;
	}

	public void setCurrentCommandText(String currentCommandText) {
		this.currentCommandText = currentCommandText;
	}

	public String getBASE_URL() {
		return BASE_URL;
	}

	public void setBASE_URL(String base_url) {
		BASE_URL = base_url;
	}

	public String getGroupNo() {
		return groupNo;
	}

	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}

	
	public int getDaySpanToCtrlFilteredOutActivity() {
		return daySpanToCtrlFilteredOutActivity;
	}

	public void setDaySpanToCtrlFilteredOutActivity(
			int daySpanToCtrlFilteredOutActivity) {
		this.daySpanToCtrlFilteredOutActivity = daySpanToCtrlFilteredOutActivity;
	}
	
	
	
	/*
	 * // 5. all programs commad public boolean isAllBusinessProgramsCommand() {
	 * boolean result = parametersMap.containsKey(ALL_BUSINESS_PROGRAMS); return
	 * result; } public void setAllBusinessProgramsCommand() {
	 * setParameter(ALL_BUSINESS_PROGRAMS, ALL_BUSINESS_PROGRAMS); } // 7. one
	 * program public boolean isOneBusinessProgramCommand() { boolean result =
	 * parametersMap.containsKey(ONE_BUSINESS_PROGRAM); return result; }
	 * 
	 * public Integer getOneBusinessProgramID() { Integer programID = null; if
	 * (isOneBusinessProgramCommand()) { programID = (Integer)
	 * getParameter(StatusCalculationCommand.ONE_BUSINESS_PROGRAM); } return
	 * programID; }
	 * 
	 * public void setOneBusinessProgramCommand(Integer oneProgramID) {
	 * setParameter(ONE_BUSINESS_PROGRAM, oneProgramID); }
	 */
}

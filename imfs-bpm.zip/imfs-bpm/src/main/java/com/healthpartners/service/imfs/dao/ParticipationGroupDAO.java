package com.healthpartners.service.imfs.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.dto.ParticipationGroup;
import com.healthpartners.service.imfs.dto.ParticipationGroupDetail;
import com.healthpartners.service.imfs.dto.ParticipationGroupRequirement;

public interface ParticipationGroupDAO 
{
	public Collection<ParticipationGroup> getParticipationGroups()
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
		 
	public int insertParticipationGroup(ParticipationGroup pParticipationGroup, String pModifyUserID) 
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;

	public int deleteParticipationGroup(Integer lParticipationGroupID) 
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;

	public int updateParticipationGroup(ParticipationGroup pParticipationGroup, String pModifyUserID) 
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;

	public List<ParticipationGroupRequirement> getParticipationGroupRequirements(Integer lParticipationGroupID)
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
	
	public ParticipationGroup getParticipationGroup(Integer pParticipationGroupID) 
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
	
	public List<ParticipationGroupDetail> getParticipationGroupDetails(ParticipationGroupRequirement requirement)
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
			
	public int insertParticipationGroupDetail(ParticipationGroupDetail detail, String pModifyUserID)
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
}

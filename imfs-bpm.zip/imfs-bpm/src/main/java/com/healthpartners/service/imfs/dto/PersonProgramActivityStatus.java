package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.sql.Date;

public class PersonProgramActivityStatus implements Serializable
{	
	static final long serialVersionUID = 0L;
		
	private Integer personID;
	private Integer activityStatusCodeID;
	private java.sql.Date activityStatusDate;
	private Integer activityID;
	private String authCode;
	private Integer activityStatusOutcomeID;
	private Integer programID;
	private String statusOutcome;
	private String registrationID;
	private Integer personDemographicsID;
	private Integer collectionID;
	public Integer getPersonID() {
		return personID;
	}
	public void setPersonID(Integer personID) {
		this.personID = personID;
	}
	public Integer getActivityStatusCodeID() {
		return activityStatusCodeID;
	}
	public void setActivityStatusCodeID(Integer activityStatusCodeID) {
		this.activityStatusCodeID = activityStatusCodeID;
	}
	public java.sql.Date getActivityStatusDate() {
		return activityStatusDate;
	}
	public void setActivityStatusDate(java.sql.Date activityStatusDate) {
		this.activityStatusDate = activityStatusDate;
	}
	public Integer getActivityID() {
		return activityID;
	}
	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}
	public String getAuthCode() {
		return authCode;
	}
	public void setAuthCode(String authCode) {
		this.authCode = authCode;
	}
	public Integer getActivityStatusOutcomeID() {
		return activityStatusOutcomeID;
	}
	public void setActivityStatusOutcomeID(Integer activityStatusOutcomeID) {
		this.activityStatusOutcomeID = activityStatusOutcomeID;
	}
	public Integer getProgramID() {
		return programID;
	}
	public void setProgramID(Integer programID) {
		this.programID = programID;
	}
	public String getStatusOutcome() {
		return statusOutcome;
	}
	public void setStatusOutcome(String statusOutcome) {
		this.statusOutcome = statusOutcome;
	}
	public String getRegistrationID() {
		return registrationID;
	}
	public void setRegistrationID(String registrationID) {
		this.registrationID = registrationID;
	}
	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}
	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}
	public Integer getCollectionID() {
		return collectionID;
	}
	public void setCollectionID(Integer collectionID) {
		this.collectionID = collectionID;
	}
	
}

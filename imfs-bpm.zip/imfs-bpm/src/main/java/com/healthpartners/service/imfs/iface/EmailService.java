/**
 * 
 */
package com.healthpartners.service.imfs.iface;

import java.util.Collection;


/**
 * Provides a common interface to send project emails.
 * 
 * @author jxbourbour
 */
public interface EmailService 
{
	public void prepareAndSendBatchStatusEmail(String emailSubject, String emailContent);
	
	public void prepareAndSendBatchStatusEmail(String emailSubject, String emailContent, Collection<String> attachmentLocations);
	
	public String getEmailDestination();

	public void setEmailDestination(String emailDestination);  
	
	
	public void setEmailContentType(String emailContentType);
	
	
		
}

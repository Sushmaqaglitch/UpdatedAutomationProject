package com.healthpartners.service.imfs.dto;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

/**
 * This class represents the internal BPM package Data Transfer Object.
 * It is not exposed to web services for example.
 * 
 * @author jxbourbour
 */
public class ContractProgramIncentiveTO extends BaseDTO
{
	static final long serialVersionUID = 0L;
	
	private Integer contractProgramStatusID;
	private Integer businessProgramID;
	private Integer incentiveOptionID;
	private Integer contractNo;
	private String  contractIncentiveStatusCode;
	private Integer contractIncentiveStatusCodeID;
	private Date    contractIncentiveStatusDate; 
	private Integer programIncentiveOptionID;
	private Integer qualificationCheckmarkID;
	private String activationStatusCodeID;
	private String activationStatusCode;
	
	private List<IncentiveStatusActivityDetail> incentiveStatusActivityDetails;
			
	public ContractProgramIncentiveTO()
	{
		super();
	}

	public Integer getContractProgramStatusID() {
		return contractProgramStatusID;
	}

	public void setContractProgramStatusID(Integer contractProgramStatusID) {
		this.contractProgramStatusID = contractProgramStatusID;
	}

	public Integer getBusinessProgramID() {
		return businessProgramID;
	}

	public void setBusinessProgramID(Integer businessProgramID) {
		this.businessProgramID = businessProgramID;
	}

	public Integer getIncentiveOptionID() {
		return incentiveOptionID;
	}

	public void setIncentiveOptionID(Integer incentiveOptionID) {
		this.incentiveOptionID = incentiveOptionID;
	}

	public Integer getContractNo() {
		return contractNo;
	}

	public void setContractNo(Integer contractNo) {
		this.contractNo = contractNo;
	}	

	public Integer getContractIncentiveStatusCodeID() {
		return contractIncentiveStatusCodeID;
	}

	public void setContractIncentiveStatusCodeID(
			Integer contractIncentiveStatusCodeID) {
		this.contractIncentiveStatusCodeID = contractIncentiveStatusCodeID;
	}

	public Date getContractIncentiveStatusDate() {
		return contractIncentiveStatusDate;
	}

	public void setContractIncentiveStatusDate(Date contractIncentiveStatusDate) {
		this.contractIncentiveStatusDate = contractIncentiveStatusDate;
	}

	public String getContractIncentiveStatusCode() {
		return contractIncentiveStatusCode;
	}

	public void setContractIncentiveStatusCode(String contractIncentiveStatusCode) {
		this.contractIncentiveStatusCode = contractIncentiveStatusCode;
	}

	public Integer getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}

	public void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}

	public Integer getQualificationCheckmarkID() {
		return qualificationCheckmarkID;
	}

	public void setQualificationCheckmarkID(Integer qualificationCheckmarkID) {
		this.qualificationCheckmarkID = qualificationCheckmarkID;
	}


	public List<IncentiveStatusActivityDetail> getIncentiveStatusActivityDetails() {
		return incentiveStatusActivityDetails;
	}

	public void setIncentiveStatusActivityDetails(
			List<IncentiveStatusActivityDetail> incentiveStatusActivityDetails) {
		this.incentiveStatusActivityDetails = incentiveStatusActivityDetails;
	}

	public final String getActivationStatusCodeID() {
		return activationStatusCodeID;
	}

	public final void setActivationStatusCodeID(String activationStatusCodeID) {
		this.activationStatusCodeID = activationStatusCodeID;
	}

	public final String getActivationStatusCode() {
		return activationStatusCode;
	}

	public final void setActivationStatusCode(String activationStatusCode) {
		this.activationStatusCode = activationStatusCode;
	}

		
	
}

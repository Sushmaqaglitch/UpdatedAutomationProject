package com.healthpartners.service.imfs.dao;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.dto.ActivityFulfillmentTrackingReportHist;
import com.healthpartners.service.imfs.dto.PersonActivityStage;
import com.healthpartners.service.imfs.dto.PersonActivitySummaryStage;
import com.healthpartners.service.imfs.dto.PersonProgramStage;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;


@Configuration

public class PersonProgramStageDAOJdbc extends JdbcDaoSupport implements PersonProgramStageDAO {
	
	
	private String selectPersonProgramsStage;
	
	private String selectPersonProgramStage;
	

	private String countPersonProgramStageRows;
	

	private String deletePersonProgramsStage;
	
	
	private String insertPersonProgramsStage;
	
	private String selectPersonActivityStageAll;
	
	private String selectPersonActivityStage;
	
	private String insertPersonActivityStage;
	

	private String countPersonActivityStageRows;
	

	private String deletePersonActivitysStage;
	
	
	private String selectPersonActivitySummaryStage;
	
	private String insertPersonActivitySummaryStage;
	
	private String deletePersonActivitySummaryStage;

	protected final Log logger = LogFactory.getLog(getClass());
	
	public PersonProgramStageDAOJdbc() {
		super();
	}

	@Qualifier("cacheDataSource")
	@Autowired
	DataSource cacheDataSource;


	@PostConstruct
	private void initialize() {

		setDataSource(cacheDataSource);
	}
	
	
	/**
	 * Select all PersonProgramStage records.
	 * 
	 * @return PersonProgramStage object.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, com.healthpartners.service.imfs.exception.BPMException.class })
	public Collection<PersonProgramStage> getPersonPrograms()
			throws DataAccessException {
		final ArrayList<PersonProgramStage> lPersonProgramsStage = new ArrayList<PersonProgramStage>();
		StringBuffer query = new StringBuffer();
		query.append(selectPersonProgramsStage);
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {  };
		int types[] = new int[] {  };

		template.query(query.toString(), params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						PersonProgramStage lPersonProgramStage = new PersonProgramStage();
						lPersonProgramStage.setContractNumber(rs
								.getInt("CntrNum"));
						lPersonProgramStage.setMemberStatus(rs
								.getString("CurrentStatus"));
						lPersonProgramStage.setGroupNumber(rs
								.getInt("GrpNum"));
						lPersonProgramStage.setPersonNumber(rs
								.getInt("PersonNum"));
						lPersonProgramStage.setQualificationEndDate(rs
								.getDate("QualEndDate"));
						lPersonProgramStage.setQualificationStartDate(rs
								.getDate("QualStartDate"));
						java.sql.Date runDate = rs.getDate("RunDate");
						lPersonProgramStage.setRunDate(runDate);
						lPersonProgramStage.setRunTime(rs.getTime("RunTime"));
						lPersonProgramStage.setSiteNumber(rs
								.getInt("SiteNum"));
						lPersonProgramStage.setStatusDate(rs
								.getDate("StatusDate"));

						lPersonProgramsStage
								.add(lPersonProgramStage);
					}
				});

		

		return lPersonProgramsStage;
	}
	
		
	/**
	 * Select a PersonProgramStage record given the person number.
	 * 
	 * @return PersonProgramStage object.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, com.healthpartners.service.imfs.exception.BPMException.class })
	public PersonProgramStage getPersonProgram(int pPersonNumber)
			throws DataAccessException {
		final ArrayList<PersonProgramStage> lPersonProgramsStage = new ArrayList<PersonProgramStage>();
		StringBuffer query = new StringBuffer();
		query.append(selectPersonProgramStage);
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { pPersonNumber };
		int types[] = new int[] { Types.INTEGER };

		template.query(query.toString(), params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						PersonProgramStage lPersonProgramStage = new PersonProgramStage();
						lPersonProgramStage.setContractNumber(rs
								.getInt("CntrNum"));
						lPersonProgramStage.setMemberStatus(rs
								.getString("CurrentStatus"));
						lPersonProgramStage.setGroupNumber(rs
								.getInt("GrpNum"));
						lPersonProgramStage.setPersonNumber(rs
								.getInt("PersonNum"));
						lPersonProgramStage.setQualificationEndDate(rs
								.getDate("QualEndDate"));
						lPersonProgramStage.setQualificationStartDate(rs
								.getDate("QualStartDate"));
						lPersonProgramStage.setRunDate(rs.getDate("RunDate"));
						lPersonProgramStage.setRunTime(rs.getTime("RunTime"));
						lPersonProgramStage.setSiteNumber(rs
								.getInt("SiteNum"));
						lPersonProgramStage.setStatusDate(rs
								.getDate("StatusDate"));

						lPersonProgramsStage
								.add(lPersonProgramStage);
					}
				});

		PersonProgramStage personProgramStage = null;
		if (lPersonProgramsStage.size() > 0) {
			personProgramStage = lPersonProgramsStage.get(0);
		}

		return personProgramStage;
	}
	
	
		/**
		 * Select a PersonProgramStage record count.
		 * 
		 * @return PersonProgramStage object.
		 */
		//Produces warnings during compile time to quickly identify typos or API changes
		@Transactional(transactionManager = "CacheDataSourceTransactionManager", readOnly = true, timeout = 300, rollbackFor = { DataAccessException.class, com.healthpartners.service.imfs.exception.BPMException.class })
		public int getPersonProgramCount()
		 			throws DataAccessException {
			 
			final ArrayList count = new ArrayList();
			JdbcTemplate template = getJdbcTemplate();
			Object params[] = new Object[] {  };
			int types[] = new int[] { };
			template.query(countPersonProgramStageRows, params, types,
					new RowCallbackHandler() {
						public void processRow(ResultSet rs) throws SQLException {
							count.add(rs.getInt(1));
						}
			});
			
			Integer countInt = (Integer)count.get(0);
			
			return countInt.intValue();
		}
		
		
	
	

	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, com.healthpartners.service.imfs.exception.BPMException.class })
	public int insertPersonPrograms(Collection<PersonProgramStage> personProgramsStage)
			throws DataAccessException {
		
		
		Iterator<PersonProgramStage> iter = personProgramsStage.iterator();
		
		Integer contractNumber = null;
		String memberStatus = null;
		String contractStatus = null;
		String programType = null;
		Integer groupNumber = null;
		Integer personNumber = null;
		Date qualEndDate = null;
		Date qualStartDate = null;
		Date programEndDate = null;
		Date programStartDate = null;
		Date runDate = null;
		Time runTime = null;
		Integer siteNumber = null;
		Date statusDate = null;
		int rowsInserted = 0;
		
		runDate = new Date(new java.util.Date().getTime());
		long time = runDate.getTime();
		runTime = new Time(time);
		
		while (iter.hasNext()) {
			PersonProgramStage personProgram = iter.next();
			contractNumber = (personProgram.getContractNumber() != null) ? personProgram.getContractNumber() : null;
			contractStatus = (personProgram.getContractStatus() != null) ? personProgram.getContractStatus() : null;
			memberStatus = (personProgram.getMemberStatus() != null) ? personProgram.getMemberStatus() : null;
			groupNumber = (personProgram.getGroupNumber() != null) ? personProgram.getGroupNumber() : null;
			personNumber = (personProgram.getPersonNumber() != null) ? personProgram.getPersonNumber() : null;
			qualEndDate = (personProgram.getQualificationEndDate() != null) ? personProgram.getQualificationEndDate() : null;
			programStartDate = (personProgram.getProgramStartDate() != null) ? personProgram.getProgramStartDate() : null;
			programEndDate = (personProgram.getProgramEndDate() != null) ? personProgram.getProgramEndDate() : null;
			qualStartDate = (personProgram.getQualificationStartDate() != null) ? personProgram.getQualificationStartDate() : null;
			programType = (personProgram.getProgramType() != null) ? personProgram.getProgramType() : null;
			siteNumber = (personProgram.getSiteNumber() != null) ? personProgram.getSiteNumber() : null;
			statusDate = (personProgram.getStatusDate() != null) ? personProgram.getStatusDate() : null;
			
			
			// Persist.
			JdbcTemplate template = getJdbcTemplate();
			Object params[] = new Object[] { contractNumber, contractStatus, memberStatus,
					groupNumber, personNumber, programType,
					qualEndDate, qualStartDate, 
					programEndDate, programStartDate, runDate,
					runTime, siteNumber,
					statusDate };
			int types[] = new int[] { Types.INTEGER, Types.VARCHAR, Types.VARCHAR, 
					Types.INTEGER, Types.INTEGER, Types.VARCHAR,
					Types.DATE, Types.DATE, 
					Types.DATE, Types.DATE, Types.DATE,
					Types.TIME, Types.INTEGER,
					Types.DATE };
			try {
				int rowInserted = template.update(insertPersonProgramsStage, params, types);
				if (rowInserted > 0) {
					rowsInserted++;		
				} 
			} catch (Exception ex) {
				logger.error("Error method insertPersonPrograms possible attempt to insert duplicates: " + ex);
				logger.error("");
				logger.error("contractNumber: " + contractNumber); 
				logger.error("contractStatus: " + contractStatus); 
				logger.error("memberStatus: " + memberStatus); 
				logger.error("groupNumber: " + groupNumber); 
				logger.error("personNumber: " + personNumber);
				logger.error("programType: " + programType);
				logger.error("siteNumber: " + siteNumber);
				
			}
		}
		return rowsInserted;
	}
	
	
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, com.healthpartners.service.imfs.exception.BPMException.class })
	public int deletePersonPrograms(Collection<PersonProgramStage> personProgramsStage)
	throws DataAccessException {
		int deleteCount = 0;
		Iterator iter = personProgramsStage.iterator();
		while (iter.hasNext()) {
			JdbcTemplate template = getJdbcTemplate();
			PersonProgramStage personProgram = (PersonProgramStage)iter.next();
			Integer contractNumber = personProgram.getContractNumber();
			Object params[] = new Object[] { contractNumber };
			int types[] = new int[] { Types.INTEGER };
			int returnCount = template.update(deletePersonProgramsStage, params, types);
			if (returnCount > 0) {
				deleteCount++;
			}
		}
		
		return deleteCount;
	}
	
	
	/**
	 * Select all PersonActivityStageAll records.
	 * 
	 * @return PersonProgramStage object.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, com.healthpartners.service.imfs.exception.BPMException.class })
	public Collection<PersonActivityStage> getPersonActivitys()
			throws DataAccessException {
		final ArrayList<PersonActivityStage> lPersonActivitys = new ArrayList<PersonActivityStage>();
		StringBuffer query = new StringBuffer();
		query.append(selectPersonActivityStageAll);
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {  };
		int types[] = new int[] {  };

		template.query(query.toString(), params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						PersonActivityStage lPersonActivityStage = new PersonActivityStage();
						lPersonActivityStage.setContractNumber(rs
								.getInt("CONTRACT_NUMBER"));
						lPersonActivityStage.setPersonNumber(rs
								.getInt("PERSON_NUMBER"));
						lPersonActivityStage.setActivityCompletionDate(rs
								.getDate("ACTIVITY_COMPLETION_DATE"));
						lPersonActivityStage.setActivityID(rs
								.getInt("ACTIVITY_ID"));
						
						java.sql.Date runDate = rs.getDate("RunDate");
						lPersonActivityStage.setRunDate(runDate);
						
						lPersonActivityStage.setRunTime(rs.getTime("RunTime"));
						
						lPersonActivitys
								.add(lPersonActivityStage);
					}
				});

		

		return lPersonActivitys;
	}
	
		
	/**
	 * Select a PersonProgramStage record given the person number.
	 * 
	 * @return PersonProgramStage object.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, com.healthpartners.service.imfs.exception.BPMException.class })
	public PersonActivityStage getPersonActivity(int pPersonNumber)
			throws DataAccessException {
		final ArrayList<PersonActivityStage> lPersonActivitysStage = new ArrayList<PersonActivityStage>();
		StringBuffer query = new StringBuffer();
		query.append(selectPersonActivityStage);
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {pPersonNumber  };
		int types[] = new int[] { Types.INTEGER };

		template.query(query.toString(), params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						PersonActivityStage lPersonActivityStage = new PersonActivityStage();
						lPersonActivityStage.setContractNumber(rs
								.getInt("CONTRACT_NUMBER"));
						lPersonActivityStage.setPersonNumber(rs
								.getInt("PERSON_NUMBER"));
						lPersonActivityStage.setActivityCompletionDate(rs
								.getDate("ACTIVITY_COMPLETION_DATE"));
						lPersonActivityStage.setActivityID(rs
								.getInt("ACTIVITY_ID"));
						
						java.sql.Date runDate = rs.getDate("RunDate");
						lPersonActivityStage.setRunDate(runDate);
						
						lPersonActivityStage.setRunTime(rs.getTime("RunTime"));
						
						lPersonActivitysStage
								.add(lPersonActivityStage);
					}
		});


		PersonActivityStage personActivityStage = null;
		if (lPersonActivitysStage.size() > 0) {
			personActivityStage = lPersonActivitysStage.get(0);
		}

		return personActivityStage;
	}
	
	
		/**
		 * Select a PersonProgramStage record count.
		 * 
		 * @return PersonProgramStage object.
		 */
		//Produces warnings during compile time to quickly identify typos or API changes
		@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, com.healthpartners.service.imfs.exception.BPMException.class })
		public int getPersonActivityCount()
		 			throws DataAccessException {
			 
			final ArrayList count = new ArrayList();
			JdbcTemplate template = getJdbcTemplate();
			Object params[] = new Object[] {  };
			int types[] = new int[] { };
			template.query(countPersonActivityStageRows, params, types,
					new RowCallbackHandler() {
						public void processRow(ResultSet rs) throws SQLException {
							count.add(rs.getInt(1));
						}
			});
			
			Integer countInt = (Integer)count.get(0);
			
			return countInt.intValue();
		}
		

	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, com.healthpartners.service.imfs.exception.BPMException.class })
	public int insertPersonActivitys(Collection<ActivityFulfillmentTrackingReportHist> lActivityFulfillmentTrackingReportHist)
			throws DataAccessException, Exception {
		
		
		Integer contractNumber = null;
		Integer personNumber = null;
		Integer activityID = null;
		Integer activityTransID = null;
		java.sql.Date activityCompletionDate;
		Date runDate = null;
		Time runTime = null;
		
		int rowsInserted = 0;
		
		runDate = new Date(new java.util.Date().getTime());
		long time = runDate.getTime();
		runTime = new Time(time);
		
		for (ActivityFulfillmentTrackingReportHist lActivityFulfillment : lActivityFulfillmentTrackingReportHist) {
			
			contractNumber = (lActivityFulfillment.getContractNo() != null) ? lActivityFulfillment.getContractNo() : null;
			personNumber = (lActivityFulfillment.getPersonID() != null) ? lActivityFulfillment.getPersonID() : null;
			activityID = (lActivityFulfillment.getActivityID() != null) ? lActivityFulfillment.getActivityID() : null;
			activityTransID = (lActivityFulfillment.getActivityTransID() != null) ? lActivityFulfillment.getActivityTransID() : null;
			activityCompletionDate = (lActivityFulfillment.getActivityIncentiveStatusDate() != null) ? lActivityFulfillment.getActivityIncentiveStatusDate() : null;
			
			
			// Persist.
			JdbcTemplate template = getJdbcTemplate();
			Object params[] = new Object[] { 
					personNumber, 
					contractNumber,  
					activityCompletionDate,
					activityID,
					activityTransID,
					runDate,
					runTime };
			
			int types[] = new int[] { 
					Types.INTEGER, 
					Types.INTEGER,
					Types.DATE,
					Types.INTEGER,
					Types.INTEGER,
					Types.DATE,
					Types.TIME };
			try {
				int rowInserted = template.update(insertPersonActivityStage, params, types);
				if (rowInserted > 0) {
					rowsInserted++;		
				} 
			} catch (Exception ex) {
				logger.error("Error method insertPersonActivitys possible attempt to insert duplicates: " + ex);
				logger.error("");
				logger.error("contractNumber: " + contractNumber); 
				logger.error("personNumber: " + personNumber); 
				logger.error("activityCompletionDate: " + activityCompletionDate); 
				logger.error("activityID: " + activityID); 
				logger.error("transactionHistID: " + activityTransID);
				logger.error("runDate: " + runDate);
				logger.error("runTime: " + runTime);
				throw ex;
				
			}
		}
		return rowsInserted;
	}
	
	
	/*
	 * Delete all person activities from the projection table.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, com.healthpartners.service.imfs.exception.BPMException.class })
	public int deletePersonActivitys()
	throws DataAccessException {
		int deleteCount = 0;
		
		JdbcTemplate template = getJdbcTemplate();
		
		Object params[] = new Object[] { };
		int types[] = new int[] {  };
		int returnCount = template.update(deletePersonActivitysStage, params, types);
		
		return deleteCount;
	}
	
	/**
	 * Select a person activity summary record.  Should always be just one.
	 * 
	 * @return PersonProgramStage object.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, com.healthpartners.service.imfs.exception.BPMException.class })
	public PersonActivitySummaryStage getPersonActivitySummary()
			throws DataAccessException {
		final ArrayList<PersonActivitySummaryStage> lPersonActivitysSummaryStage = new ArrayList<PersonActivitySummaryStage>();
		StringBuffer query = new StringBuffer();
		query.append(selectPersonActivitySummaryStage);
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {  };
		int types[] = new int[] {  };

		template.query(query.toString(), params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						PersonActivitySummaryStage lPersonActivitySummaryStage = new PersonActivitySummaryStage();
						lPersonActivitySummaryStage.setRunDate(rs
								.getDate("RUN_DATE"));
						lPersonActivitySummaryStage.setRunTime(rs
								.getTime("RUN_TIME"));
						lPersonActivitySummaryStage.setNumberOfRecords(rs
								.getInt("NUMBER_OF_RECORDS"));
						
						lPersonActivitysSummaryStage
								.add(lPersonActivitySummaryStage);
					}
		});


		PersonActivitySummaryStage personActivitySummaryStage = null;
		if (lPersonActivitysSummaryStage.size() > 0) {
			personActivitySummaryStage = lPersonActivitysSummaryStage.get(0);
		}

		return personActivitySummaryStage;
	}
	

	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, com.healthpartners.service.imfs.exception.BPMException.class })
	public int insertPersonActivitySummary(PersonActivitySummaryStage lPersonActivitySummaryStage)
			throws DataAccessException, Exception {
		
		int rowsInserted = 0;
		
		Date runDate = new Date(new java.util.Date().getTime());
		long time = runDate.getTime();
		Time runTime = new Time(time);
		
		
		Integer numberOfRecords = (lPersonActivitySummaryStage.getNumberOfRecords() != null) ? lPersonActivitySummaryStage.getNumberOfRecords() : null;
		
		
		// Persist.
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { 
				runDate, 
				runTime,  
				numberOfRecords
				};
		
		int types[] = new int[] { 
				
				Types.DATE,
				Types.TIME,
				Types.INTEGER };
		try {
			int rowInserted = template.update(insertPersonActivitySummaryStage, params, types);
			if (rowInserted > 0) {
				rowsInserted++;		
			} 
		} catch (Exception ex) {
			logger.error("Error method insertPersonActivitys possible attempt to insert duplicates: " + ex);
			logger.error("");
			logger.error("numberOfRecords: " + numberOfRecords); 
			logger.error("runDate: " + runDate); 
			logger.error("runTime: " + runTime); 
			throw ex;
		}
	
		return rowsInserted;
	}
	
	/*
	 * Delete all person activities from the projection table.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, com.healthpartners.service.imfs.exception.BPMException.class })
	public int deletePersonActivitySummary()
	throws DataAccessException {
		int deleteCount = 0;
		
		JdbcTemplate template = getJdbcTemplate();
		
		Object params[] = new Object[] {  };
		int types[] = new int[] { };
		int returnCount = template.update(deletePersonActivitySummaryStage, params, types);
		
		return returnCount;
	}
	

	public String getSelectPersonProgramsStage() {
		return selectPersonProgramsStage;
	}




	public void setSelectPersonProgramsStage(String selectPersonProgramsStage) {
		this.selectPersonProgramsStage = selectPersonProgramsStage;
	}


	public String getCountPersonProgramStageRows() {
		return countPersonProgramStageRows;
	}




	public void setCountPersonProgramStageRows(String countPersonProgramStageRows) {
		this.countPersonProgramStageRows = countPersonProgramStageRows;
	}




	public String getDeletePersonProgramsStage() {
		return deletePersonProgramsStage;
	}




	public void setDeletePersonProgramsStage(String deletePersonProgramsStage) {
		this.deletePersonProgramsStage = deletePersonProgramsStage;
	}




	public String getInsertPersonProgramsStage() {
		return insertPersonProgramsStage;
	}




	public void setInsertPersonProgramsStage(String insertPersonProgramsStage) {
		this.insertPersonProgramsStage = insertPersonProgramsStage;
	}




	public String getSelectPersonProgramStage() {
		return selectPersonProgramStage;
	}




	public void setSelectPersonProgramStage(String selectPersonProgramStage) {
		this.selectPersonProgramStage = selectPersonProgramStage;
	}




	public void setSelectPersonActivityStageAll(String selectPersonActivityStageAll) {
		this.selectPersonActivityStageAll = selectPersonActivityStageAll;
	}




	public void setSelectPersonActivityStage(String selectPersonActivityStage) {
		this.selectPersonActivityStage = selectPersonActivityStage;
	}

	


	public void setInsertPersonActivityStage(String insertPersonActivityStage) {
		this.insertPersonActivityStage = insertPersonActivityStage;
	}





	public void setCountPersonActivityStageRows(String countPersonActivityStageRows) {
		this.countPersonActivityStageRows = countPersonActivityStageRows;
	}






	public void setDeletePersonActivitysStage(String deletePersonActivitysStage) {
		this.deletePersonActivitysStage = deletePersonActivitysStage;
	}





	public void setSelectPersonActivitySummaryStage(
			String selectPersonActivitySummaryStage) {
		this.selectPersonActivitySummaryStage = selectPersonActivitySummaryStage;
	}




	public void setInsertPersonActivitySummaryStage(
			String insertPersonActivitySummaryStage) {
		this.insertPersonActivitySummaryStage = insertPersonActivitySummaryStage;
	}




	public void setDeletePersonActivitySummaryStage(
			String deletePersonActivitySummaryStage) {
		this.deletePersonActivitySummaryStage = deletePersonActivitySummaryStage;
	}
	
	



}
package com.healthpartners.service.imfs.iface;

import com.healthpartners.service.imfs.dto.GroupActivityProgressTracker;
import org.springframework.dao.DataAccessException;


/**
 * Provides Group Activity Progression Tracker update services.
 * 
 * @author tjquist
 * 
 */
public interface GroupActivityProgressTrackerService {

	public GroupActivityProgressTracker getGroupActivityProgressionTracker(String pInputFileName, java.sql.Date pBatchDate, Integer trackingStatusID);
	
	public boolean isFileAlreadyProcessed(GroupActivityProgressTracker lGroupActivityProgressTracker) throws Exception, DataAccessException;
	
	public boolean isFilePreProcess(GroupActivityProgressTracker lGroupActivityProgressTracker) throws Exception, DataAccessException;
	
	public boolean isFileINProcess(GroupActivityProgressTracker lGroupActivityProgressTracker) throws Exception, DataAccessException;
	
	public boolean isNoFileBeenProcessed(GroupActivityProgressTracker lGroupActivityProgressTracker) throws Exception, DataAccessException;
	
	
	public int updateGroupActivityProgressionTracker(GroupActivityProgressTracker pGroupActivityProgressTracker, String userID) throws DataAccessException;

}

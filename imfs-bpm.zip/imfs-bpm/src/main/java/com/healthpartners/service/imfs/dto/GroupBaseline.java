package com.healthpartners.service.imfs.dto;

import java.sql.Date;
import java.sql.Time;
/**
 * 
 * @author jxbourbour
 *
 */
public class GroupBaseline extends BaseDTO {
	
	static final long serialVersionUID = 0L;
	
	private Integer groupID;
	private Integer subGroupID;
	private Date effectiveDate;
	private String programTypeCode;
	private String groupNo;
	private String SiteNo;
	
	private java.sql.Date programEffectiveDate;
	private java.sql.Date programEndDate;
	private String programTypeName;
	private String groupName;
	
		
    public GroupBaseline()
    {
    	super();
    }

	public Integer getGroupID() {
		return groupID;
	}

	public void setGroupID(Integer groupID) {
		this.groupID = groupID;
	}

	public Integer getSubGroupID() {
		return subGroupID;
	}

	public void setSubGroupID(Integer subGroupID) {
		this.subGroupID = subGroupID;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getProgramTypeCode() {
		return programTypeCode;
	}

	public void setProgramTypeCode(String programTypeCode) {
		this.programTypeCode = programTypeCode;
	}

	public String getGroupNo() {
		return groupNo;
	}

	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}

	public String getSiteNo() {
		return SiteNo;
	}

	public void setSiteNo(String siteNo) {
		SiteNo = siteNo;
	}

	public java.sql.Date getProgramEffectiveDate() {
		return programEffectiveDate;
	}

	public void setProgramEffectiveDate(java.sql.Date programEffectiveDate) {
		this.programEffectiveDate = programEffectiveDate;
	}

	public java.sql.Date getProgramEndDate() {
		return programEndDate;
	}

	public void setProgramEndDate(java.sql.Date programEndDate) {
		this.programEndDate = programEndDate;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getProgramTypeName() {
		return programTypeName;
	}

	public void setProgramTypeName(String programTypeName) {
		this.programTypeName = programTypeName;
	}
	
	
	
}

	
package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.util.Calendar;

public class BusinessProgram implements Serializable
{	
	static final long serialVersionUID = 0L;
	
	private String programName;
	private String programDescription;
	private String programTypeCodeID;
	
	private int familyParticipationRequirement;
	private String familyParticipationValue;
	private String familyParticipationDesc;
	private String goldPassDescription;
	private String activityCostRule;
	private Calendar releaseDate;
	
	private Calendar effectiveDate;
	private Calendar endDate;
	private Integer contractNumber; 

	private Calendar qualificationWindowStartDate;	
    private Calendar qualificationWindowEndDate;

	private String additionalGroupProgramInfo;
	
	private Calendar benefitYearStartDate;
	private int benefitLevelCodeID;
	private String benefitLevelDesc;		
	
	private EmployerGroup employerGroup;
	private EligibleActivity[] eligibleActivities;		
	private ProgramIncentiveOption[] programIncentiveOptions;
	
	private AdditionalInformation[] additionalInformation;
	
	private boolean programAvailable;
	
	private Calendar programAvailableDate;
	private Calendar programAvailableEndDate;	
		
	public int getFamilyParticipationRequirement() {
		return familyParticipationRequirement;
	}

	public void setFamilyParticipationRequirement(int familyParticipationRequirement) {
		this.familyParticipationRequirement = familyParticipationRequirement;
	}

	public String getGoldPassDescription() {
		return goldPassDescription;
	}

	public void setGoldPassDescription(String goldPassDescription) {
		this.goldPassDescription = goldPassDescription;
	}
	
	public Calendar getQualificationWindowEndDate() {
		return qualificationWindowEndDate;
	}
	public void setQualificationWindowEndDate(Calendar qualificationWindowEndDate) {
		this.qualificationWindowEndDate = qualificationWindowEndDate;
	}
	
	public Calendar getQualificationWindowStartDate() {
		return qualificationWindowStartDate;
	}
	public void setQualificationWindowStartDate(Calendar qualificationWindowStartDate) {
		this.qualificationWindowStartDate = qualificationWindowStartDate;
	}

	public String getActivityCostRule() {
		return activityCostRule;
	}

	public void setActivityCostRule(String activityCostRule) {
		this.activityCostRule = activityCostRule;
	}

	public String getAdditionalGroupProgramInfo() {
		return additionalGroupProgramInfo;
	}

	public void setAdditionalGroupProgramInfo(String additionalGroupProgramInfo) {
		this.additionalGroupProgramInfo = additionalGroupProgramInfo;
	}

	public Calendar getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(Calendar releaseDate) {
		this.releaseDate = releaseDate;
	}
	
	public Calendar getEndDate() {
		return endDate;
	}

	public void setEndDate(Calendar endDate) {
		this.endDate = endDate;
	}

	public EligibleActivity[] getEligibleActivities() {
		return eligibleActivities;
	}

	public void setEligibleActivities(
			EligibleActivity[] eligibleActivities) {
		this.eligibleActivities = eligibleActivities;
	}
			
	public String getProgramDescription() {
		return programDescription;
	}

	public void setProgramDescription(String programDescription) {
		this.programDescription = programDescription;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}	

	public Calendar getBenefitYearStartDate() {
		return benefitYearStartDate;
	}

	public void setBenefitYearStartDate(Calendar benefitYearStartDate) {
		this.benefitYearStartDate = benefitYearStartDate;
	}
		
	public EmployerGroup getEmployerGroup() {
		return employerGroup;
	}

	public void setEmployerGroup(EmployerGroup employerGroup) {
		this.employerGroup = employerGroup;
	}

	

	public int getBenefitLevelCodeID() {
		return benefitLevelCodeID;
	}

	public void setBenefitLevelCodeID(int benefitLevelCodeID) {
		this.benefitLevelCodeID = benefitLevelCodeID;
	}

	public String getBenefitLevelDesc() {
		return benefitLevelDesc;
	}

	public void setBenefitLevelDesc(String benefitLevelDesc) {
		this.benefitLevelDesc = benefitLevelDesc;
	}

	public String getFamilyParticipationDesc() {
		return familyParticipationDesc;
	}

	public void setFamilyParticipationDesc(String familyParticipationDesc) {
		this.familyParticipationDesc = familyParticipationDesc;
	}	
	
	public String getFamilyParticipationValue() {
		return familyParticipationValue;
	}

	public void setFamilyParticipationValue(String familyParticipationValue) {
		this.familyParticipationValue = familyParticipationValue;
	}

	public String getProgramTypeCodeID() {
		return programTypeCodeID;
	}

	public void setProgramTypeCodeID(String programTypeCodeID) {
		this.programTypeCodeID = programTypeCodeID;
	}

	public Integer getContractNumber() {
		return contractNumber;
	}

	public void setContractNumber(Integer contractNumber) {
		this.contractNumber = contractNumber;
	}

	public final ProgramIncentiveOption[] getProgramIncentiveOptions() {
		return programIncentiveOptions;
	}

	public final void setProgramIncentiveOptions(
			ProgramIncentiveOption[] programIncentiveOptions) {
		this.programIncentiveOptions = programIncentiveOptions;
	}

	public final AdditionalInformation[] getProgramAdditionalInformation() {
		return additionalInformation;
	}

	public final void setProgramAdditionalInformation(
			AdditionalInformation[] additionalInformation) {
		this.additionalInformation = additionalInformation;
	}

	public final boolean isProgramAvailable() {
		return programAvailable;
	}

	public final void setProgramAvailable(boolean programAvailable) {
		this.programAvailable = programAvailable;
	}

	public final Calendar getEffectiveDate() {
		return effectiveDate;
	}

	public final void setEffectiveDate(Calendar effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Calendar getProgramAvailableDate() {
		return programAvailableDate;
	}

	public void setProgramAvailableDate(Calendar programAvailableDate) {
		this.programAvailableDate = programAvailableDate;
	}

	public Calendar getProgramAvailableEndDate() {
		return programAvailableEndDate;
	}

	public void setProgramAvailableEndDate(Calendar programAvailableEndDate) {
		this.programAvailableEndDate = programAvailableEndDate;
	}
	
}

package com.healthpartners.service.imfs.iface;

import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.rules.StatusCalculationCommand;
import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.exception.BPMException;


public interface ArchivePersonContractProgramHistoryService {
	
	public void processArchivePersonContractProgramHistoryCommand(
			StatusCalculationCommand statusCalculationCommand)
			throws BPMException, DataAccessException, BPMException;

}

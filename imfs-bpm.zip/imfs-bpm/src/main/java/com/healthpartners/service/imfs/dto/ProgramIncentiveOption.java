package com.healthpartners.service.imfs.dto;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class ProgramIncentiveOption implements Serializable
{	
	static final long serialVersionUID = 0L;
	
	private IncentiveOption incentiveOption;
	
	private Integer programIncentiveOptionID;
	private Integer businessProgramID;
	private String additionalInfo;
	private String incentiveOptionInfo;
	private Integer incentiveOptionStatusCodeID;
	private String incentiveOptionStatusCode;
	private String incentiveOptionStatusCodeDesc;
	private String effectiveDate;
	private String endDate;
	private String activationDate;
	private String deliveryDate;
	private String fulfillmentRoutingTypeCode;
	
	private Integer incentedStatusTypeCodeID;
	private String incentedStatusTypeCode;
	private Integer participantCap;
	private Integer familyCap;
	private java.sql.Date enrollmentDeadlineDate;
	private java.sql.Date completionDeadlineDate;
	private String incentiveRuleTypeCode;
	private Integer activityCompletionPeriod;
	private java.sql.Date newHireDate;
	
	private Integer participationGroupID;
	private ParticipationGroup participationGroup;	
	
	private ArrayList<IncentiveRequirement> incentiveRequirements; 
	
	private List<ProgramContributionGrid> programContributionGrids;
	
	private Integer incentivePackageRuleGroupID;
	private IncentivePackageRuleGroup incentivePackageRuleGroup;
	private String activationStatusCode;	

    public ProgramIncentiveOption()
    {
    	super();
    }

	public final String getAdditionalInfo() {
		return additionalInfo;
	}

	public final void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	public final Integer getBusinessProgramID() {
		return businessProgramID;
	}

	public final void setBusinessProgramID(Integer businessProgramID) {
		this.businessProgramID = businessProgramID;
	}

	public final IncentiveOption getIncentiveOption() {
		return incentiveOption;
	}

	public final void setIncentiveOption(IncentiveOption incentiveOption) {
		this.incentiveOption = incentiveOption;
	}

	public final String getIncentiveOptionInfo() {
		return incentiveOptionInfo;
	}

	public final void setIncentiveOptionInfo(String incentiveOptionInfo) {
		this.incentiveOptionInfo = incentiveOptionInfo;
	}

	public final String getIncentiveOptionStatusCode() {
		return incentiveOptionStatusCode;
	}

	public final void setIncentiveOptionStatusCode(String incentiveOptionStatusCode) {
		this.incentiveOptionStatusCode = incentiveOptionStatusCode;
	}

	public final String getIncentiveOptionStatusCodeDesc() {
		return incentiveOptionStatusCodeDesc;
	}

	public final void setIncentiveOptionStatusCodeDesc(
			String incentiveOptionStatusCodeDesc) {
		this.incentiveOptionStatusCodeDesc = incentiveOptionStatusCodeDesc;
	}

	public final Integer getIncentiveOptionStatusCodeID() {
		return incentiveOptionStatusCodeID;
	}

	public final void setIncentiveOptionStatusCodeID(
			Integer incentiveOptionStatusCodeID) {
		this.incentiveOptionStatusCodeID = incentiveOptionStatusCodeID;
	}

	public final String getActivationDate() {
		return activationDate;
	}

	public final void setActivationDate(String activationDate) {
		this.activationDate = activationDate;
	}

	public final String getDeliveryDate() {
		return deliveryDate;
	}
	
	public final void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	
	public final String getEffectiveDate() {
		return effectiveDate;
	}

	public final void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public final String getEndDate() {
		return endDate;
	}

	public final void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public ArrayList<IncentiveRequirement> getIncentiveRequirements() {
		return incentiveRequirements;
	}

	public void setIncentiveRequirements(
			ArrayList<IncentiveRequirement> incentiveRequirements) {
		this.incentiveRequirements = incentiveRequirements;
	}

	public String getFulfillmentRoutingTypeCode() {
		return fulfillmentRoutingTypeCode;
	}

	public void setFulfillmentRoutingTypeCode(String fulfillmentRoutingTypeCode) {
		this.fulfillmentRoutingTypeCode = fulfillmentRoutingTypeCode;
	}

	public Integer getIncentedStatusTypeCodeID() {
		return incentedStatusTypeCodeID;
	}

	public void setIncentedStatusTypeCodeID(Integer incentedStatusTypeCodeID) {
		this.incentedStatusTypeCodeID = incentedStatusTypeCodeID;
	}

	public String getIncentedStatusTypeCode() {
		return incentedStatusTypeCode;
	}

	public void setIncentedStatusTypeCode(String incentedStatusTypeCode) {
		this.incentedStatusTypeCode = incentedStatusTypeCode;
	}

	public Integer getParticipantCap() {
		return participantCap;
	}

	public void setParticipantCap(Integer participantCap) {
		this.participantCap = participantCap;
	}

	public Integer getFamilyCap() {
		return familyCap;
	}

	public void setFamilyCap(Integer familyCap) {
		this.familyCap = familyCap;
	}

	public final String getIncentiveRuleTypeCode() {
		return incentiveRuleTypeCode;
	}

	public final void setIncentiveRuleTypeCode(String incentiveRuleTypeCode) {
		this.incentiveRuleTypeCode = incentiveRuleTypeCode;
	}

	public final java.sql.Date getEnrollmentDeadlineDate() {
		return enrollmentDeadlineDate;
	}

	public final void setEnrollmentDeadlineDate(java.sql.Date enrollmentDeadlineDate) {
		this.enrollmentDeadlineDate = enrollmentDeadlineDate;
	}

	public final java.sql.Date getCompletionDeadlineDate() {
		return completionDeadlineDate;
	}

	public final void setCompletionDeadlineDate(java.sql.Date completionDeadlineDate) {
		this.completionDeadlineDate = completionDeadlineDate;
	}

	public Integer getParticipationGroupID() {
		return participationGroupID;
	}

	public void setParticipationGroupID(Integer participationGroupID) {
		this.participationGroupID = participationGroupID;
	}

	public ParticipationGroup getParticipationGroup() {
		return participationGroup;
	}

	public void setParticipationGroup(ParticipationGroup participationGroup) {
		this.participationGroup = participationGroup;
	}

	public Integer getActivityCompletionPeriod() {
		return activityCompletionPeriod;
	}

	public void setActivityCompletionPeriod(Integer activityCompletionPeriod) {
		this.activityCompletionPeriod = activityCompletionPeriod;
	}
	
	public Integer getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}

	public void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}

	public java.sql.Date getNewHireDate() {
		return newHireDate;
	}

	public void setNewHireDate(java.sql.Date newHireDate) {
		this.newHireDate = newHireDate;
	}

	public List<ProgramContributionGrid> getProgramContributionGrids() {
		return programContributionGrids;
	}

	public void setProgramContributionGrids(
			List<ProgramContributionGrid> programContributionGrids) {
		this.programContributionGrids = programContributionGrids;
	}

	public final Integer getIncentivePackageRuleGroupID() {
		return incentivePackageRuleGroupID;
	}

	public final void setIncentivePackageRuleGroupID(
			Integer incentivePackageRuleGroupID) {
		this.incentivePackageRuleGroupID = incentivePackageRuleGroupID;
	}

	public final IncentivePackageRuleGroup getIncentivePackageRuleGroup() {
		return incentivePackageRuleGroup;
	}

	public final void setIncentivePackageRuleGroup(
			IncentivePackageRuleGroup incentivePackageRuleGroup) {
		this.incentivePackageRuleGroup = incentivePackageRuleGroup;
	}

	public final String getActivationStatusCode() {
		return activationStatusCode;
	}

	public final void setActivationStatusCode(String activationStatusCode) {
		this.activationStatusCode = activationStatusCode;
	}
	
	
	
		
}

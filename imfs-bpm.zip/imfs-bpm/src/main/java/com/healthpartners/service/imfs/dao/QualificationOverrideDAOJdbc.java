package com.healthpartners.service.imfs.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.QualificationOverride;
import com.healthpartners.service.imfs.exception.BPMException;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;


/**
 * This class provides insert/update/delete/select jdbc operations for Manual
 * exemptions and automatic exemptions
 * Manual Exemptions - override code is - MANUAL_EXEMPTION
 * Automatic exemptions - override code is - EXEMPTION
 * @author tjquist
 * 
 */
@Configuration
public class QualificationOverrideDAOJdbc extends JdbcDaoSupport implements
		QualificationOverrideDAO {

	/*
	 * SQL statements
	 */
	private String insertQualificationOverride;

	private String deleteQualificationOverride;

	private String getAllQualificationOverrides;

	private String getQualificationOverride;

	private String deleteMemberExemptionsByTypeCode;

	private String selectGroupTransferManualExemptions;

	/*
	 * SQL sequences
	 */
	@Autowired
	private DataFieldMaxValueIncrementer qualificationOverrideIdIncrementer;

	/**
	 * 
	 */
	public QualificationOverrideDAOJdbc() {
		super();
	}

	@Autowired
	DataSource bpmDataSource;

	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}

	/*
	 * @see com.healthpartners.service.bpm.dao.QualificationOverrideDAO#insertQualificationOverride(com.healthpartners.service.bpm.dto.QualificationOverride)
	 */
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public long insertQualificationOverride(
			QualificationOverride qualificationOverride)
			throws DataAccessException 
	{		
	    // Look for a row in the table. 
		ArrayList<QualificationOverride> lExistingOverrides = (ArrayList<QualificationOverride>) 
		getAllQualificationOverridesOfType(
				qualificationOverride.getPersonID(), qualificationOverride.getProgramID(), qualificationOverride.getOverrideCode(), qualificationOverride.getProgramIncentiveOptionID());
		
		if(lExistingOverrides.size() <= 0)
		{		
			// Retrieve the next sequence number .
			Long qualificationOverrideId = new Long(
					qualificationOverrideIdIncrementer.nextLongValue());
	
			// Persist
			JdbcTemplate template = getJdbcTemplate();
	
			Object params[] = new Object[] { qualificationOverrideId,
					qualificationOverride.getProgramID(),
					qualificationOverride.getPersonID(),
					qualificationOverride.getPersonID(),
					BPMConstants.BPM_TYPE_OVERRIDE,
					qualificationOverride.getOverrideCode(),
					qualificationOverride.getApproverUserId(),
					qualificationOverride.getIssueDate(),
					qualificationOverride.getReasonCode(),
					qualificationOverride.getInsertUserId(),
					qualificationOverride.getModifyUserId(),
					qualificationOverride.getContractNo(),
					qualificationOverride.getProgramIncentiveOptionID()
					
					};
	
			int types[] = new int[] { Types.BIGINT, Types.INTEGER, Types.INTEGER, Types.INTEGER,
					Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP,
					Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER };
	
			template.update(insertQualificationOverride, params, types);
			return qualificationOverrideId.longValue();
		}

		return 0;
	}

	/*
	 * @see com.healthpartners.service.bpm.dao.QualificationOverrideDAO#insertQualificationOverride(java.util.Collection)
	 */
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int[] insertQualificationOverride(
			Collection<QualificationOverride> qualOverrides)
			throws DataAccessException {
		int[] numberOfRowsInserted;
		final Object objs[] = qualOverrides.toArray();

		JdbcTemplate template = getJdbcTemplate();

		BatchPreparedStatementSetter setter = null;
		setter = new BatchPreparedStatementSetter() {
			public int getBatchSize() {
				return objs.length;
			}

			public void setValues(PreparedStatement ps, int index)
					throws SQLException {
				Long qualOverrideId = new Long(
						qualificationOverrideIdIncrementer.nextLongValue());
				QualificationOverride qualOverride = (QualificationOverride) objs[index];
				ps.setLong(1, qualOverrideId.longValue());
				ps.setInt(2, qualOverride.getProgramID());
				ps.setInt(3, qualOverride.getPersonID());
				ps.setInt(4, qualOverride.getPersonID());
				ps.setString(5, BPMConstants.BPM_TYPE_OVERRIDE);
				ps.setString(6, qualOverride.getOverrideCode());
				ps.setString(7, qualOverride.getApproverUserId());
				ps.setDate(8, BPMUtils.calendarToSqlDate(qualOverride
						.getIssueDate()));
				ps.setString(9, qualOverride.getReasonCode());
				ps.setString(10, qualOverride.getInsertUserId());
				ps.setString(11, qualOverride.getModifyUserId());
				ps.setInt(12, qualOverride.getContractNo());
			}
		};
		numberOfRowsInserted = template.batchUpdate(
				insertQualificationOverride, setter);
		return numberOfRowsInserted;
	}

	/*
	 * @see com.healthpartners.service.bpm.dao.QualificationOverrideDAO#deleteQualificationOverride(java.lang.Integer)
	 */
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int deleteQualificationOverride(long overrideID)
			throws DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { Long.valueOf(overrideID) };
		int types[] = new int[] { Types.BIGINT };
		return template.update(deleteQualificationOverride, params, types);
	}
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, com.healthpartners.service.imfs.exception.BPMException.class })
	public int deleteAutomaticMemberExemptions(Integer personID,
			Integer programID, Integer contractNo) throws DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { personID, programID, contractNo, 
				BPMConstants.BPM_TYPE_OVERRIDE,
				BPMConstants.OVERRIDE_CODE_EXEMPTION };
		int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.VARCHAR,
				Types.VARCHAR };
		return template.update(deleteMemberExemptionsByTypeCode, params, types);
	}
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int[] deleteAutomaticMemberExemptions(
			Collection<QualificationOverride> qualOverrides)
			throws DataAccessException {
		int[] numberOfRowsDeleted;
		final Object objs[] = qualOverrides.toArray();

		JdbcTemplate template = getJdbcTemplate();

		BatchPreparedStatementSetter setter = null;
		setter = new BatchPreparedStatementSetter() {
			public int getBatchSize() {
				return objs.length;
			}

			public void setValues(PreparedStatement ps, int index)
					throws SQLException {
				QualificationOverride qualOverride = (QualificationOverride) objs[index];
				ps.setInt(1, qualOverride.getPersonID());
				ps.setInt(2, qualOverride.getProgramID());
				ps.setInt(3, qualOverride.getContractNo());
				ps.setString(4, BPMConstants.BPM_TYPE_OVERRIDE);
				ps.setString(5, BPMConstants.OVERRIDE_CODE_EXEMPTION);				
			}
		};
		numberOfRowsDeleted = template.batchUpdate(
				deleteMemberExemptionsByTypeCode, setter);
		return numberOfRowsDeleted;
	}

	/*
	 * @see com.healthpartners.service.bpm.dao.QualificationOverrideDAO#getAllQualificationOverrides(java.lang.Integer,
	 *      java.lang.Integer)
	 */
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<QualificationOverride> getAllQualificationOverrides(Integer personID)
			throws DataAccessException {
		final ArrayList<QualificationOverride> results = new ArrayList<QualificationOverride>();
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { personID};
		int types[] = new int[] { Types.INTEGER };
		template.query(getAllQualificationOverrides, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						
						QualificationOverride qualOverride = new QualificationOverride();
						qualOverride.setId(rs.getLong("QOV_ID")); 
						qualOverride.setProgramID(rs.getInt("BIZ_PGM_ID"));
						qualOverride.setPersonID(rs.getInt("PRSN_DMGRPHCS_ID")); 
						qualOverride.setOverrideType(rs.getString("OVRD_TYPE"));
						qualOverride.setOverrideCode(rs.getString("OVRD_VALUE"));
						qualOverride.setApproverUserId(rs.getString("APRVR_USER_ID")); // APRVR_USER_ID
						qualOverride.setIssueDate(BPMUtils.dateToCalendar(rs.getDate("EXEMPTION_ISSUE_DT")));
						qualOverride.setReasonCode(rs.getString("EXEMPTION_RSN_DESC")); // EXEMPTION_RSN_DESC
						qualOverride.setInsertUserId(rs.getString("INSERT_USR")); // INSERT_USER
						qualOverride.setModifyUserId(rs.getString("MODIFY_USR")); // MODIFY_USER
						qualOverride.setContractNo(rs.getInt("CNTR_NO"));
						qualOverride.setProgramIncentiveOptionID(rs.getInt("biz_pgm_incntv_optn_ID"));
						
						results.add(qualOverride);
					}
				});

		return results;
	}
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<QualificationOverride> getGroupTransferManualExemptions(
			Integer personID, Integer businessProgramID, Integer contractNo, Integer pProgramIncentiveOptionID)
			throws DataAccessException {
		final ArrayList<QualificationOverride> results = new ArrayList<QualificationOverride>();
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { personID, businessProgramID, contractNo, pProgramIncentiveOptionID };
		int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER };
		template.query(selectGroupTransferManualExemptions, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						QualificationOverride qualOverride = new QualificationOverride();
						qualOverride.setId(rs.getLong(1)); // QUALFCTN_OVRD_ID
						qualOverride
								.setProgramID(rs.getObject(2) != null ? Integer
										.valueOf(rs.getInt(2)) : null); // BIZ_PGM_ID
						qualOverride
								.setPersonID(rs.getObject(3) != null ? Integer
										.valueOf(rs.getInt(3)) : null); // PRSN_ID
						qualOverride.setOverrideType(rs.getString(4));
						qualOverride.setOverrideCode(rs.getString(5));
						qualOverride.setApproverUserId(rs.getString(6)); // APRVR_USER_ID
						qualOverride
								.setIssueDate(rs.getObject(7) != null ? BPMUtils
										.dateToCalendar(rs.getDate(7))
										: null); // EXEMPTION_ISSUE_DT
						qualOverride.setReasonCode(rs.getString(8)); // EXEMPTION_RSN_DESC
						qualOverride.setInsertUserId(rs.getString(9)); // INSERT_USER
						qualOverride.setModifyUserId(rs.getString(10)); // MODIFY_USER
						qualOverride.setContractNo(rs.getInt("CNTR_NO"));

						results.add(qualOverride);
					}
				});

		return results;
	}

	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public QualificationOverride getQualificationOverride(long overrideID)
			throws DataAccessException {
		final ArrayList<QualificationOverride> results = new ArrayList<QualificationOverride>();
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { overrideID };
		int types[] = new int[] { Types.BIGINT };
		template.query(getQualificationOverride, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						QualificationOverride qualOverride = new QualificationOverride();
						qualOverride.setId(rs.getLong(1)); // QUALFCTN_OVRD_ID
						qualOverride
								.setProgramID(rs.getObject(2) != null ? Integer
										.valueOf(rs.getInt(2)) : null); // BIZ_PGM_ID
						qualOverride
								.setPersonID(rs.getObject(3) != null ? Integer
										.valueOf(rs.getInt(3)) : null); // PRSN_ID
						qualOverride.setOverrideType(rs.getString(4));
						qualOverride.setOverrideCode(rs.getString(5));
						qualOverride.setApproverUserId(rs.getString(6)); // APRVR_USER_ID
						qualOverride
								.setIssueDate(rs.getObject(7) != null ? BPMUtils
										.dateToCalendar(rs.getDate(7))
										: null); // EXEMPTION_ISSUE_DT
						qualOverride.setReasonCode(rs.getString(8)); // EXEMPTION_RSN_DESC
						qualOverride.setInsertUserId(rs.getString(9)); // INSERT_USER
						qualOverride.setModifyUserId(rs.getString(10)); // MODIFY_USER
						qualOverride.setContractNo(rs.getInt("CNTR_NO"));

						results.add(qualOverride);
					}
				});

		QualificationOverride dto = null;
		if (results.size() > 0) {
			dto = (QualificationOverride) results.get(0);
		}
		return dto;
	}

	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<QualificationOverride> getAllQualificationOverridesOfType(
			Integer personID, Integer businessProgramID, String pOverrideTypeCode, Integer pProgramIncentiveOptionID)
			throws DataAccessException {
		final ArrayList<QualificationOverride> results = new ArrayList<QualificationOverride>();
		JdbcTemplate template = getJdbcTemplate();
		
		try
		{
			Object params[] = new Object[] { personID, businessProgramID, pProgramIncentiveOptionID, pOverrideTypeCode };
			int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.VARCHAR };
			
			StringBuffer lQuery = new StringBuffer();
			lQuery.append(getAllQualificationOverrides);
			lQuery.append(" AND ovrd.BIZ_PGM_ID = ? ");
			lQuery.append(" AND ovrd.BIZ_PGM_INCNTV_OPTN_ID = ? ");
			lQuery.append(" AND lu.LU_VAL = ? ");
			
			template.query(lQuery.toString(), params, types,
					new RowCallbackHandler() 
			{
						public void processRow(ResultSet rs) throws SQLException {
							QualificationOverride qualOverride = new QualificationOverride();
							qualOverride.setId(rs.getLong(1)); // QUALFCTN_OVRD_ID
							qualOverride
									.setProgramID(rs.getObject(2) != null ? Integer
											.valueOf(rs.getInt(2)) : null); // BIZ_PGM_ID
							qualOverride
									.setPersonID(rs.getObject(3) != null ? Integer
											.valueOf(rs.getInt(3)) : null); // PRSN_ID
							qualOverride.setOverrideType(rs.getString(4));
							qualOverride.setOverrideCode(rs.getString(5));
							qualOverride.setApproverUserId(rs.getString(6)); // APRVR_USER_ID
							qualOverride
									.setIssueDate(rs.getObject(7) != null ? BPMUtils
											.dateToCalendar(rs.getDate(7))
											: null); // EXEMPTION_ISSUE_DT
							qualOverride.setReasonCode(rs.getString(8)); // EXEMPTION_RSN_DESC
							qualOverride.setInsertUserId(rs.getString(9)); // INSERT_USER
							qualOverride.setModifyUserId(rs.getString(10)); // MODIFY_USER
							qualOverride.setContractNo(rs.getInt("CNTR_NO"));
	
							results.add(qualOverride);
						}
					});
		}
		catch(Exception e)
		{
			logger.error(e.getMessage() + ", PersonDemogID = " + personID + ", Biz = " + businessProgramID + ", ProgIncntvOptID = " + pProgramIncentiveOptionID + ", OverrideType = " + pOverrideTypeCode);
		}

		return results;
	}

	/**
	 * Sets the insertQualificationOverride SQL statement. Should only be called
	 * by Spring.
	 *
	 */
	public void setInsertQualificationOverride(String sql) {
		this.insertQualificationOverride = sql;
	}

	/**
	 * Sets the deleteQualificationOverride SQL statement. Should only be called
	 * by Spring.
	 *
	 */
	public void setDeleteQualificationOverride(String sql) {
		this.deleteQualificationOverride = sql;
	}

	/**
	 * Sets the getAllQualificationOverrides SQL statement. Should only be
	 * called by Spring.
	 *
	 */
	public void setGetAllQualificationOverrides(String sql) {
		this.getAllQualificationOverrides = sql;
	}

	/**
	 * Sets the getQualificationOverride SQL statement. Should only be called by
	 * Spring.
	 *
	 */
	public void setGetQualificationOverride(String sql) {
		this.getQualificationOverride = sql;
	}

	/**
	 * Sets the Incrementer. Should only be called by Spring.
	 *
	 */
	public void setQualificationOverrideIdIncrementer(
			DataFieldMaxValueIncrementer incrementer) {
		this.qualificationOverrideIdIncrementer = incrementer;
	}

	public String getDeleteMemberExemptionsByTypeCode() {
		return deleteMemberExemptionsByTypeCode;
	}

	public void setDeleteMemberExemptionsByTypeCode(
			String deleteMemberExemptionsByTypeCode) {
		this.deleteMemberExemptionsByTypeCode = deleteMemberExemptionsByTypeCode;
	}

	public String getSelectGroupTransferManualExemptions() {
		return selectGroupTransferManualExemptions;
	}

	public void setSelectGroupTransferManualExemptions(
			String selectGroupTransferManualExemptions) {
		this.selectGroupTransferManualExemptions = selectGroupTransferManualExemptions;
	}

}

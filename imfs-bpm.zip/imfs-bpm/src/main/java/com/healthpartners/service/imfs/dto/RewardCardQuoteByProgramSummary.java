/**
 * 
 */
package com.healthpartners.service.imfs.dto;

import java.util.Collection;
import java.util.HashMap;



/**
 * @author tjquist
 * 
 */
public class RewardCardQuoteByProgramSummary extends BaseAuditableDTO {

	static final long serialVersionUID = 0L;

	private String quoteID;
	
	private HashMap<Integer, RewardControlProgram> programControlReportingMap;
	
	private HashMap<Integer, Integer> programRewardFulfilledSummaryMap;
	
    private HashMap<Integer, Integer> programRecycleBypassSummaryMap;
    
    private HashMap<Integer, Integer> programRecycleReleasedSummaryMap;
    
    private HashMap<Integer, Integer> programMultiActivitySummaryMap;
	
	private HashMap<Integer, Integer> programMissingAddressSummaryMap;


	private HashMap<Integer, Integer> programSentSummaryMap;
	
	private HashMap<Integer, Integer> programErrorSummaryMap;
	
	private HashMap<Integer, Integer> programRewardReadFromFulfilledSummaryMap;
	
	
	private HashMap<Integer, Integer> programRewardFulfillRptHistReadSummaryMap;
	
	
	/**
	 * 
	 */
	public RewardCardQuoteByProgramSummary() {
		
		programControlReportingMap = new HashMap<Integer, RewardControlProgram>();
		programRewardFulfilledSummaryMap = new HashMap<Integer, Integer>();
		programRecycleBypassSummaryMap = new HashMap<Integer, Integer>();
		programRecycleReleasedSummaryMap = new HashMap<Integer, Integer>();
		programMissingAddressSummaryMap = new HashMap<Integer, Integer>();
		programMultiActivitySummaryMap = new HashMap<Integer, Integer>();
		programSentSummaryMap = new HashMap<Integer, Integer>();
		programErrorSummaryMap = new HashMap<Integer, Integer>();
		programRewardReadFromFulfilledSummaryMap = new HashMap<Integer, Integer>();
		programRewardFulfillRptHistReadSummaryMap = new HashMap<Integer, Integer>();
		
	}


	public String getQuoteID() {
		return quoteID;
	}


	public void setQuoteID(String quoteID) {
		this.quoteID = quoteID;
	}


	public HashMap<Integer, RewardControlProgram> getProgramControlReportingMap() {
		return programControlReportingMap;
	}


	public void setProgramControlReportingMap(
			HashMap<Integer, RewardControlProgram> programControlReportingMap) {
		this.programControlReportingMap = programControlReportingMap;
	}


	public HashMap<Integer, Integer> getProgramRewardFulfilledSummaryMap() {
		return programRewardFulfilledSummaryMap;
	}


	public void setProgramRewardFulfilledSummaryMap(
			HashMap<Integer, Integer> programRewardFulfilledSummaryMap) {
		this.programRewardFulfilledSummaryMap = programRewardFulfilledSummaryMap;
	}


	public HashMap<Integer, Integer> getProgramRecycleBypassSummaryMap() {
		return programRecycleBypassSummaryMap;
	}


	public void setProgramRecycleBypassSummaryMap(
			HashMap<Integer, Integer> programRecycleBypassSummaryMap) {
		this.programRecycleBypassSummaryMap = programRecycleBypassSummaryMap;
	}


	public HashMap<Integer, Integer> getProgramRecycleReleasedSummaryMap() {
		return programRecycleReleasedSummaryMap;
	}


	public void setProgramRecycleReleasedSummaryMap(
			HashMap<Integer, Integer> programRecycleReleasedSummaryMap) {
		this.programRecycleReleasedSummaryMap = programRecycleReleasedSummaryMap;
	}


	public HashMap<Integer, Integer> getProgramMissingAddressSummaryMap() {
		return programMissingAddressSummaryMap;
	}


	public void setProgramMissingAddressSummaryMap(
			HashMap<Integer, Integer> programMissingAddressSummaryMap) {
		this.programMissingAddressSummaryMap = programMissingAddressSummaryMap;
	}
	
	


	public HashMap<Integer, Integer> getProgramMultiActivitySummaryMap() {
		return programMultiActivitySummaryMap;
	}


	public void setProgramMultiActivitySummaryMap(
			HashMap<Integer, Integer> programMultiActivitySummaryMap) {
		this.programMultiActivitySummaryMap = programMultiActivitySummaryMap;
	}


	public HashMap<Integer, Integer> getProgramSentSummaryMap() {
		return programSentSummaryMap;
	}


	public void setProgramSentSummaryMap(
			HashMap<Integer, Integer> programSentSummaryMap) {
		this.programSentSummaryMap = programSentSummaryMap;
	}


	public HashMap<Integer, Integer> getProgramErrorSummaryMap() {
		return programErrorSummaryMap;
	}


	public void setProgramErrorSummaryMap(
			HashMap<Integer, Integer> programErrorSummaryMap) {
		this.programErrorSummaryMap = programErrorSummaryMap;
	}


	public HashMap<Integer, Integer> getProgramRewardReadFromFulfilledSummaryMap() {
		return programRewardReadFromFulfilledSummaryMap;
	}


	public void setProgramRewardReadFromFulfilledSummaryMap(
			HashMap<Integer, Integer> programRewardReadFromFulfilledSummaryMap) {
		this.programRewardReadFromFulfilledSummaryMap = programRewardReadFromFulfilledSummaryMap;
	}


	public HashMap<Integer, Integer> getProgramRewardFulfillRptHistReadSummaryMap() {
		return programRewardFulfillRptHistReadSummaryMap;
	}


	public void setProgramRewardFulfillRptHistReadSummaryMap(
			HashMap<Integer, Integer> programRewardFulfillRptHistReadSummaryMap) {
		this.programRewardFulfillRptHistReadSummaryMap = programRewardFulfillRptHistReadSummaryMap;
	}

	
	
	

}

package com.healthpartners.service.imfs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.dto.Risk;
import org.springframework.dao.DataAccessException;
import com.healthpartners.service.imfs.exception.BPMException;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;

/**
 * 
 * @author tjquist
 *
 */
@Configuration
public class RiskDAOJdbc extends JdbcDaoSupport implements RiskDAO 
{
	private String selectRiskByName;
	private String selectRiskByGroupName;
	private String selectAllRisks;

	@Autowired
	DataSource bpmDataSource;


	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}
	
	/**
	 * 
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Risk getRiskByName(String pRiskName)
	{
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { pRiskName };
		int types[] = new int[] { Types.VARCHAR };
		final ArrayList<Risk> lRisks = new ArrayList<Risk>();
		
		template.query(selectRiskByName, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						Risk lRisk = new Risk();
						
						lRisk.setRiskID(rs.getInt("risk_id"));
						lRisk.setRiskName(rs.getString("risk_nm"));
						lRisk.setRiskDesc(rs.getString("risk_desc"));
						lRisk.setRiskHoldDuration(rs.getInt("hold_duration"));
						lRisk.setRiskGroupCodeID(rs.getInt("risk_grp_cd_id"));
						lRisk.setRiskGroupCodeVal(rs.getString("lu_val"));
						lRisks.add(lRisk);
					}
		});
		
		return lRisks.get(0);
	}
	
	/**
	 * 
	 * @param pRiskGroupName
	 * @return
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Risk getRiskByGroupName(String pRiskGroupName)
	{
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { pRiskGroupName };
		int types[] = new int[] { Types.VARCHAR };
		final ArrayList<Risk> lRisks = new ArrayList<Risk>();
		
		template.query(selectRiskByGroupName, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						Risk lRisk = new Risk();
						
						lRisk.setRiskID(rs.getInt("risk_id"));
						lRisk.setRiskName(rs.getString("risk_nm"));
						lRisk.setRiskDesc(rs.getString("risk_desc"));
						lRisk.setRiskHoldDuration(rs.getInt("hold_duration"));
						lRisk.setRiskGroupCodeID(rs.getInt("risk_grp_cd_id"));
						lRisk.setRiskGroupCodeVal(rs.getString("lu_val"));
						lRisks.add(lRisk);
					}
		});
		
		return lRisks.get(0);
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<Risk> getAllRisks()
	{
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = null;
		int types[] = null;
		final ArrayList<Risk> lRisks = new ArrayList<Risk>();
		
		template.query(selectAllRisks, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						Risk lRisk = new Risk();
						
						lRisk.setRiskID(rs.getInt("risk_id"));
						lRisk.setRiskName(rs.getString("risk_nm"));
						lRisk.setRiskDesc(rs.getString("risk_desc"));
						lRisk.setRiskHoldDuration(rs.getInt("hold_duration"));
						lRisk.setRiskGroupCodeID(rs.getInt("risk_grp_cd_id"));
						lRisk.setRiskGroupCodeVal(rs.getString("lu_val"));
						lRisks.add(lRisk);
					}
		});
		
		return lRisks;
	}

	public String getSelectRiskByName() {
		return selectRiskByName;
	}

	public void setSelectRiskByName(String selectRiskByName) {
		this.selectRiskByName = selectRiskByName;
	}

	public String getSelectRiskByGroupName() {
		return selectRiskByGroupName;
	}

	public void setSelectRiskByGroupName(String selectRiskByGroupName) {
		this.selectRiskByGroupName = selectRiskByGroupName;
	}

	public String getSelectAllRisks() {
		return selectAllRisks;
	}

	public void setSelectAllRisks(String selectAllRisks) {
		this.selectAllRisks = selectAllRisks;
	}

	
	
}

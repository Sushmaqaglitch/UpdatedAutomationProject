package com.healthpartners.service.imfs.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.healthpartners.service.imfs.dto.*;
import org.springframework.dao.DataAccessException;

public interface IncentiveOptionDAO 
{
	public Collection<ProgramIncentiveOption> getIncentiveOptions(Integer programID)
	throws DataAccessException;
	
	public int insertProgramIncentiveOption(ProgramIncentiveOption pProgramIncentiveOption, String pUserID) 
	throws DataAccessException;
	
	public Collection<ActivityIncentive> getActivityIncentives(ActivityEvent activityEvent)
	throws DataAccessException;
	
	public Collection<PersonActivityIncentive> getPersonActivityIncentives(Integer pPersonDemographicsID,
			Integer pBusinessProgramID,
			Integer pActivityIncentiveID , Integer pActivityID, String contractNo)
	throws DataAccessException;
	
	public int updatePersonActivityIncentive(PersonActivityIncentive pMemberActivityIncentive, String pUserID)
	throws DataAccessException;
	
	public int updatePersonActivityIncentiveWithContributionAmt(ActivityEvent lActivityEvent, String pUserID)
	throws DataAccessException;
	
	public int updatePersonActivityIncentiveWithModificationDate(PersonActivityIncentToFulfillReconcile lPersonActivityIncentToFulfillReconcileDifference, String pUserID)
			throws DataAccessException;
	
	public Collection<IncentiveRequirement> getIncentiveOptionRequirements(Integer pProgramID, Integer pIncentiveOptionID)
	throws DataAccessException;
	
	public long updateContractProgramIncentive(ContractProgramIncentiveTO pContractProgramIncentiveTO)
	throws DataAccessException;
	
	public long insertContractProgramIncentive(ContractProgramIncentiveTO pContractProgramIncentiveTO)
	throws DataAccessException;
	
	public Collection<ContractProgramIncentiveTO> getContractProgramIncentive(Integer pBusinessProgramID
			, Integer pIncentiveOptionID, Integer pContractNo)
	throws DataAccessException;
	
	public List<IncentiveStatusActivityDetail> getIncentiveStatusActivityDetails(Integer contractProgramIncentiveStatusID,
																				 Integer personProgramActivityStatusID, Integer memberProgramIncentiveStatusID)
		throws DataAccessException;	
	
	public Collection<ActivityIncentive> getActivityIncentives(Integer pBusinessProgramID
			, Integer pIncentiveOptionID
			, Integer pRequirementID)
	throws DataAccessException;
	
	public int insertIncentiveRequirement(IncentiveRequirement pIncentiveRequirement, String pUserID)
	throws DataAccessException;
	
	public int insertActivityIncentive(ActivityIncentive pActivityIncentive, String pUserID)
	throws DataAccessException;
	
	public int insertIncentiveParticipant(IncentiveParticipant pIncentiveParticipant, String pUserID)
	throws DataAccessException;
	
	public long insertMemberProgramIncentive(MemberProgramIncentiveTO pMemberProgramIncentiveTO)
	throws DataAccessException;
	
	public long insertIncentiveStatusActivityDetail(IncentiveStatusActivityDetail lIncentiveStatusActivityDetail)
	throws DataAccessException;
	
	public long insertIncentiveStatusActivityDetailContribution(IncentiveStatusActivityDetailContribution lIncentiveStatusActivityDetailContribution)
			throws DataAccessException;
	
	public Collection<MemberProgramIncentiveTO> getMemberProgramIncentive(Integer pBusinessProgramID
			, Integer pIncentiveOptionID
			, Integer pContractNo
			, Integer pPersonDemographicsID)
	throws DataAccessException;
		
	public long updateMemberProgramIncentive(MemberProgramIncentiveTO pMemberProgramIncentiveTO)
	throws DataAccessException;
	
	public long deleteMemberProgramIncentive(MemberProgramIncentiveTO pMemberProgramIncentiveTO)
	throws DataAccessException;
	
	public long deleteMemberProgramIncentive(Integer pPersonDemographicsID, Integer pProgramID)
	throws DataAccessException;
	
	public long deleteContractProgramIncentive(Integer pContractNo, Integer pProgramID)
	throws DataAccessException;
	
	
	public boolean isActivityCompletionPeriodEnabled(Integer programID) throws DataAccessException;
	
	public int setContractIncentiveAchievedDate(Integer pProgramID, Integer pIncentiveOptionID, Integer pContractID, boolean pSetToNull)
	throws DataAccessException;
	
	public Collection<ActivityIncentive> getIncentiveCheckmarkForActivity(ActivityEvent activityEvent)
	throws DataAccessException;
	
	public int setMemberIncentiveAchievedDate(Integer pPersonDemographicsID, Integer pProgramIncentiveOptionID, boolean pSetToNull)
	throws DataAccessException;
	
	public Collection<ActivityIncentive> getActivityIncentivesOutsideEnrollment(ActivityEvent activityEvent)
			throws DataAccessException;
			
	public Collection<IncentiveParticipant> getIncentiveParticipants(Integer pActivityIncentiveID)
		throws DataAccessException;

	public List<ActivityDefinition> getCollectionActivities(Integer pCollectionID);

	public List<IncentiveStatusActivityDetailContribution> getIncentiveStatusActivityDetailContributions(Integer incentiveStatusActivityDetailID);
	
	public IncentiveOption getIncentiveOptionDefinitionByName(String incentiveOptionName) throws DataAccessException;
	
	public Collection<IncentivesAchievedSummaryByIncentiveOption> getContractIncentivesAchievedByProgramIncentiveOptionSummary(String groupNo) throws DataAccessException;

	public Collection<IncentivesAchievedSummaryByIncentiveOption> getMemberIncentivesAchievedByProgramIncentiveOptionSummary(String groupNo) throws DataAccessException;


}

package com.healthpartners.service.imfs.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dao.PersonDAO;
import com.healthpartners.service.imfs.dto.CDHPFulfillmentTrackingRecycle;
import com.healthpartners.service.imfs.dto.LookUpValueCode;
import com.healthpartners.service.imfs.dto.PersonActivityAchievedContribution;
import com.healthpartners.service.imfs.dto.PersonActivityIncentToFulfillReconcile;
import com.healthpartners.service.imfs.exception.BPMBusinessValidationException;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.iface.ActivityEventService;
import com.healthpartners.service.imfs.iface.BusinessProgramService;
import com.healthpartners.service.imfs.iface.EmailService;
import com.healthpartners.service.imfs.iface.LookUpValueService;
import com.healthpartners.service.imfs.iface.MemberService;
import com.healthpartners.service.imfs.iface.UploadEmployerActivityIncentToFulfillReconService;
import com.healthpartners.service.imfs.iface.UploadEmployerActivityPostprocessService;
import com.healthpartners.service.imfs.rules.StatusCalculationCommand;
@Component
@Service
public class UploadEmployerActivityIncentToFulfillReconServiceImpl implements UploadEmployerActivityIncentToFulfillReconService {

	protected final Log logger = LogFactory.getLog(getClass());
	@Autowired
	private MemberService memberService;
	@Autowired
	private LookUpValueService lookUpValueService;
	@Autowired
	private EmailService emailService;
	@Autowired
	private PersonDAO personDAO;
	
	
	/*
	 * Batch job that will produce a summary report of the incented records that were never fulfilled.  Needs
	 * to run after the HRA batch process responsible for sending transactions to the Surround system.  Incented records
	 * will fall to the CDHP Error Recycle table for action to be taken later but will be reported on under the
	 * CDHP Error Recycle report as it related to activity incented to fulfillment differences.
	 * Note: Only Employer Sponsored Incented Activities never fulfilled are reported on.
	*/
		@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
				BPMBusinessValidationException.class, BPMException.class })
	public void processUploadEmployerActivityIncentToFulfillReconCommand(StatusCalculationCommand statusCalculationCommand) throws BPMException {
			
				logger.info("@Start - Processing Upload Employer Activity Incented To Fulfilled Reconciliation Command. ");
				
				
				String failureReason = null;
				
				
				LookUpValueCode activityEventSourceCodeLuv = null;
				//read from a group control table to get fileLocation by group.  Also, get group number.
				try {
					activityEventSourceCodeLuv = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.ACTIVITY_EVENT_SOURCE_CODES, BPMConstants.ACTIVITY_EVENT_SOURCE_ID_OPTUM);
				} catch (Exception e) {
					logger.error("Exception thrown after luv lookup: " + e.getMessage());
					throw new BPMException(e);
				}
				
				
				
				statusCalculationCommand.setCurrentCommandText("Upload Employer Activity Incent Fulfill Reconciliation");
				
				String systemSourceCode = activityEventSourceCodeLuv.getLuvVal();
				
				Collection<PersonActivityIncentToFulfillReconcile> lPersonActivityIncentToFulfillReconcileDifferences  = memberService.getAllPersonActivityIncentToFulfillReconciled(systemSourceCode, BPMConstants.CDHP_PURCH_SUB_TP_NM_HRA);
				
				// those person incented activities "on hold" in error recycle will be removed from lPersonActivityIncentToFulfillReconcileDifferences.
				Collection<PersonActivityIncentToFulfillReconcile> lPersonActivityIncentToFulfillReconcileOnHoldInErrorRecycle = determineIfAlreadyOnErrorRecycle(lPersonActivityIncentToFulfillReconcileDifferences);
				// write to cdhp_error_recycle table.
				
				Collection<CDHPFulfillmentTrackingRecycle> newCDHPFulfillmentTrackingRecycles = buildCDHPFulfillmentRecycle(lPersonActivityIncentToFulfillReconcileDifferences);
				
				
				for (CDHPFulfillmentTrackingRecycle newCDHPFulfillmentTrackingRecycle : newCDHPFulfillmentTrackingRecycles) {
					//This rule brings to users attention that there were activity incented records left behind after the cdhp fulfillment batch process ran.
					//Transactions that fall to the cdhp error report need to be investigated to determine why and if they need to be fulfilled manually or denied.
					//Once action is taken, set status to denied through the admin tool.  By capturing these transactions in error recycle, we have some history to look back to to see at 
					//what point the activity incentive got held up.
					newCDHPFulfillmentTrackingRecycle.setReasonTollgateRule(BPMConstants.CDHP_RECYCLE_TOLLGATE_RULE_4);
					personDAO.insertCDHPFulfillmentRecycle(newCDHPFulfillmentTrackingRecycle);
				}
				
				generateOnHoldErrorReport(statusCalculationCommand, lPersonActivityIncentToFulfillReconcileOnHoldInErrorRecycle);
				
				generateReconciliationReport(statusCalculationCommand, lPersonActivityIncentToFulfillReconcileDifferences, failureReason);
				
				logger.info("@End - Processing Upload Employer Activity Incent To Fulfillment Reconciliation Command. ");
				
	}
		
		
		/*
		 * Produce a list of those participants activities that were never fulfilled after being incented and are sitting in an ON HOLD state within the CDHP Error recycle table waiting
		 * for action to be taken against them.
		 */
			@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
					BPMBusinessValidationException.class, BPMException.class })
		private void generateOnHoldErrorReport(StatusCalculationCommand statusCalculationCommand, Collection<PersonActivityIncentToFulfillReconcile> lPersonActivityIncentToFulfillReconcileOnHoldInErrorRecycle) throws BPMException
			{
				logger.info("@Start - Generate Member Activity CDHP Error Recycle ON HOLD Detail Report. ");
				
				
				StringBuffer batchMailSubject = new StringBuffer();
				
				batchMailSubject
				.append("BPM Batch - Upload Employer Sponsored Member Activity CDHP Fulfillment Error Recycle ON HOLD Report");
				
				batchMailSubject.append(" / Status");
				StringBuffer batchMailContent = new StringBuffer();
				batchMailContent
				.append("<table>");
				batchMailContent.append("<tr><td>BPM Batch Name: Member Activity CDHP Fulfillment Error Recycle ON HOLD Report</td></tr>");

				batchMailContent.append("<tr><td>Initiated User: "
						+ statusCalculationCommand.getUserID());
				
				if (lPersonActivityIncentToFulfillReconcileOnHoldInErrorRecycle.size() > 0) {
					batchMailSubject.append("- FAILED");
					batchMailContent.append("<tr><td>Result: FAILED</td></tr>");
				} else {
					batchMailSubject.append("- SUCCESS");
					batchMailContent.append("<tr></td>Result: SUCCESS</td></tr>");
				}
				
				batchMailContent
				.append("</table>");
				batchMailContent
				.append("<table>");
				
				
				if (lPersonActivityIncentToFulfillReconcileOnHoldInErrorRecycle.size() > 0) {
					batchMailContent
					.append("<tr><td>-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
					batchMailContent
							.append("<tr><td>Member Activites ON HOLD in CDHP Fulfillment error recycle:  " + lPersonActivityIncentToFulfillReconcileOnHoldInErrorRecycle.size() + "</td></tr>");
					/*batchMailContent
							.append("<tr><td>Member Incented Activity modification dates were updated with todays date for the next HRA Batch run to pickup and send to the Surround System.</td></tr>");*/
					batchMailContent
					.append("<tr><td>-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
				} else {
					batchMailContent
					.append("<tr><td>-----------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
					batchMailContent
					.append("<tr><td> NO MEMBER ACTIVITIES ON HOLD IN CDHP FULFILLMENT ERROR RECYCLE. </td></tr>");
					batchMailContent
					.append("<tr><td>-----------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
				}
				batchMailContent
				.append("</table>");
				
				if (lPersonActivityIncentToFulfillReconcileOnHoldInErrorRecycle.size() > 0) {
					batchMailContent
					.append("<table>");
					batchMailContent
					.append("<tr><td>MEMBER ACTIVITIES ON HOLD IN CDHP FULFILLMENT ERROR RECYCLE DETAIL REPORT" +  " </td></tr> ");
					batchMailContent
					.append("</table>");
					if (lPersonActivityIncentToFulfillReconcileOnHoldInErrorRecycle.size() > 0) {
						// column header
						batchMailContent
						.append("<table>");
						batchMailContent.append("<tr><td> Line</td><td>Group No</td><td>Site No</td><td>Effective Date</td><td>End Date</td><td>Member No</td><td>First Name</td><td>Last Name</td><td>Activity Name</td><td>Amount</td><td>Incented Date</td></tr>");
						
						Iterator<PersonActivityIncentToFulfillReconcile> iter  = (Iterator<PersonActivityIncentToFulfillReconcile>) lPersonActivityIncentToFulfillReconcileOnHoldInErrorRecycle.iterator();
						int rowCt = 1;
				    	while (iter.hasNext()) {
				    		PersonActivityIncentToFulfillReconcile lPersonActivityIncentToFulfillReconcileDifference = (PersonActivityIncentToFulfillReconcile)iter.next();
								
				    		batchMailContent
										.append("<tr><td colspan=12>----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
							batchMailContent.append("<tr><td> "
									+ rowCt + "</td><td>"
									+ lPersonActivityIncentToFulfillReconcileDifference.getGroupNo() + "</td><td>"
									+ lPersonActivityIncentToFulfillReconcileDifference.getSiteNo() + "</td><td>"
									+ lPersonActivityIncentToFulfillReconcileDifference.getProgramEffectiveDate() + "</td><td>" 
									+ lPersonActivityIncentToFulfillReconcileDifference.getProgramEndDate() + "</td><td>" 
									+ lPersonActivityIncentToFulfillReconcileDifference.getMemberNumber() + "</td><td>" 
									+ lPersonActivityIncentToFulfillReconcileDifference.getFirstName() + "</td><td>" 
									+ lPersonActivityIncentToFulfillReconcileDifference.getLastName() + "</td><td>" 
									+ lPersonActivityIncentToFulfillReconcileDifference.getActivityName() + "</td><td>" 
									+ lPersonActivityIncentToFulfillReconcileDifference.getContributionAmount() + "</td><td>" 
									+ lPersonActivityIncentToFulfillReconcileDifference.getIncentedDate() + 	
									"</td></tr>");
							rowCt++;
				
							if (rowCt > 100) {
								batchMailContent
								.append("<tr><td>   </td></tr>");
								batchMailContent
								.append("<tr><td>   </td></tr>");
								//cap report list at 100
								batchMailContent
								.append("<tr><td colspan=12>***ATTENTION: REPORT CUTOFF AT 100 ROWS.  " + "A TOTAL OF " + lPersonActivityIncentToFulfillReconcileOnHoldInErrorRecycle.size() + " MEMBER ACTIVITY INCENTIVES NOT FULFILLED SITTING IN CDHP ERROR RECYCLE.</td></tr>");
								break;
							}
						
				    	} 
				    	
					} 
				}
				
				batchMailContent
				.append("</table>");
		    	emailService.setEmailDestination(BPMConstants.BPM_EMAIL_TO_ADDR_RECONCILE_RPT);
		    	emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
				emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
						batchMailContent.toString());
			}
		
		
		
		/*
		 * Produce a list of those participants activities that were never fulfilled after being incented.
		 */
			@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
					BPMBusinessValidationException.class, BPMException.class })
		private void generateReconciliationReport(StatusCalculationCommand statusCalculationCommand, Collection<PersonActivityIncentToFulfillReconcile> lPersonActivityIncentToFulfillReconcileDifferences, String failureReason) throws BPMException
			{
				logger.info("@Start - Generate Person Activity Incented To Fulfilled Reconciliation Differences Detail Report. ");
				
				
				StringBuffer batchMailSubject = new StringBuffer();
				
				batchMailSubject
				.append("BPM Batch - Upload Employer Sponsored Member Activity Incented To Fulfilled Reconciliation Report");
				
				batchMailSubject.append(" / Status");
				StringBuffer batchMailContent = new StringBuffer();
				batchMailContent
				.append("<table>");
				batchMailContent.append("<tr><td>BPM Batch Name: Member Activity Incented To Fulfilled Reconciliation Differences</td></tr>");

				batchMailContent.append("<tr><td>Initiated User: "
						+ statusCalculationCommand.getUserID());
				
				if (failureReason != null) {
					batchMailSubject.append("- FAILED");
					batchMailContent.append("<tr><td>Result: FAILED</td></tr>");
					batchMailContent.append("<tr></td>Reason: \n");
					batchMailContent.append(failureReason + "</td></tr>");
				} else {
					batchMailSubject.append("- SUCCESS");
					batchMailContent.append("<tr></td>Result: SUCCESS</td></tr>");
				}
				
				batchMailContent
				.append("</table>");
				batchMailContent
				.append("<table>");
				
				if (lPersonActivityIncentToFulfillReconcileDifferences.size() > 0) {
					batchMailContent
					.append("<tr><td>-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
					batchMailContent
							.append("<tr><td>Member Incented Activites not fulfilled:  " + lPersonActivityIncentToFulfillReconcileDifferences.size() + "</td></tr>");
					/*batchMailContent
							.append("<tr><td>Member Incented Activity modification dates were updated with todays date for the next HRA Batch run to pickup and send to the Surround System.</td></tr>");*/
					batchMailContent
					.append("<tr><td>-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
				} else {
					batchMailContent
					.append("<tr><td>------------------------------------------------------------------------------------------</td></tr>");
					batchMailContent
					.append("<tr><td> ALL Member Incented Activities are current with the CDHP Fulfillment table. </td></tr>");
					batchMailContent
					.append("<tr><td> See Upload Employer Sponsored Member Activity CDHP Fulfillment Error Recycle ON HOLD Report for any action to take. </td></tr>");
					batchMailContent
					.append("<tr><td>------------------------------------------------------------------------------------------</td></tr>");
				}
				batchMailContent
				.append("</table>");
				batchMailContent
				.append("<table>");
				batchMailContent
				.append("<tr><td>MEMBER ACTIVITY INCENTED TO FULFILLED RECONCILIATION REPORT (DIFFERENCES REPORTED WRITTEN TO ERROR RECYCLE AS ON HOLD)" +  " </td></tr> ");
				batchMailContent
				.append("</table>");
				if (lPersonActivityIncentToFulfillReconcileDifferences.size() > 0) {
					// column header
					batchMailContent
					.append("<table>");
					batchMailContent.append("<tr><td> Line</td><td>Group No</td><td>Site No</td><td>Effective Date</td><td>End Date</td><td>Member No</td><td>First Name</td><td>Last Name</td><td>Activity Name</td><td>Amount</td><td>Incented Date</td></tr>");
					
					Iterator<PersonActivityIncentToFulfillReconcile> iter  = (Iterator<PersonActivityIncentToFulfillReconcile>) lPersonActivityIncentToFulfillReconcileDifferences.iterator();
					int rowCt = 1;
			    	while (iter.hasNext()) {
			    		PersonActivityIncentToFulfillReconcile lPersonActivityIncentToFulfillReconcileDifference = (PersonActivityIncentToFulfillReconcile)iter.next();
							
			    		batchMailContent
									.append("<tr><td colspan=12>----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
						batchMailContent.append("<tr><td> "
								+ rowCt + "</td><td>"
								+ lPersonActivityIncentToFulfillReconcileDifference.getGroupNo() + "</td><td>"
								+ lPersonActivityIncentToFulfillReconcileDifference.getSiteNo() + "</td><td>"
								+ lPersonActivityIncentToFulfillReconcileDifference.getProgramEffectiveDate() + "</td><td>" 
								+ lPersonActivityIncentToFulfillReconcileDifference.getProgramEndDate() + "</td><td>" 
								+ lPersonActivityIncentToFulfillReconcileDifference.getMemberNumber() + "</td><td>" 
								+ lPersonActivityIncentToFulfillReconcileDifference.getFirstName() + "</td><td>" 
								+ lPersonActivityIncentToFulfillReconcileDifference.getLastName() + "</td><td>" 
								+ lPersonActivityIncentToFulfillReconcileDifference.getActivityName() + "</td><td>" 
								+ lPersonActivityIncentToFulfillReconcileDifference.getContributionAmount() + "</td><td>" 
								+ lPersonActivityIncentToFulfillReconcileDifference.getIncentedDate() + 	
								"</td></tr>");
						rowCt++;
			
						if (rowCt > 100) {
							batchMailContent
							.append("<tr><td>   </td></tr>");
							batchMailContent
							.append("<tr><td>   </td></tr>");
							//cap report list at 100
							batchMailContent
							.append("<tr><td colspan=12>***ATTENTION: REPORT CUTOFF AT 100 ROWS.  " + "A TOTAL OF " + lPersonActivityIncentToFulfillReconcileDifferences.size() + " MEMBER ACTIVITY INCENTIVES NOT FULFILLED.</td></tr>");
							break;
						}
					
			    	} 
			    	
				} 
				
				batchMailContent
				.append("</table>");
		    	emailService.setEmailDestination(BPMConstants.BPM_EMAIL_TO_ADDR_RECONCILE_RPT);
		    	emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
				emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
						batchMailContent.toString());
			}
			
		
		
		/*
		 * method will determine if reconciliation differences between the incented table and fulfillment table are already on the cdhp error recycle table.
		 * Return a collection of those that are on hold in error recycle to be reported on.  Remove from the original collection those that are on hold leaving
		 * records that need to be added to the error recycle and reported on as new person incented activities that were not fulfilled for the first time.
		 * Note:parameter lPersonActivityIncentToFulfillReconcileDifferences is setup to be manipulated with the same object used later in the class.
		 */
		private	Collection<PersonActivityIncentToFulfillReconcile> determineIfAlreadyOnErrorRecycle(Collection<PersonActivityIncentToFulfillReconcile> lPersonActivityIncentToFulfillReconcileDifferences) {
			Collection<PersonActivityIncentToFulfillReconcile> lPersonActivityIncentToFulfillReconcileOnHoldInErrorRecycle = new ArrayList<PersonActivityIncentToFulfillReconcile>(); 
			Collection<PersonActivityIncentToFulfillReconcile> lPersonActivityIncentToFulfillReconcileDeniedInErrorRecycle = new ArrayList<PersonActivityIncentToFulfillReconcile>();
			for (PersonActivityIncentToFulfillReconcile lPersonActivityIncentToFulfillReconcile : lPersonActivityIncentToFulfillReconcileDifferences) {
				Integer programID = lPersonActivityIncentToFulfillReconcile.getProgramID();
				Integer personDemographicsID = lPersonActivityIncentToFulfillReconcile.getPersonDemographicsID();
				Integer activityID = lPersonActivityIncentToFulfillReconcile.getActivityID();
				CDHPFulfillmentTrackingRecycle lCDHPFulfillmentTrackingRecycle = personDAO.getCDHPFulfillRecycleForPerson(programID, personDemographicsID, activityID);
				if (lCDHPFulfillmentTrackingRecycle != null && lCDHPFulfillmentTrackingRecycle.getRecycleStatus().equals(BPMConstants.CDHP_RECYCLE_STATUS_ON_HOLD)) {
					lPersonActivityIncentToFulfillReconcileOnHoldInErrorRecycle.add(lPersonActivityIncentToFulfillReconcile);
				} else if (lCDHPFulfillmentTrackingRecycle != null && lCDHPFulfillmentTrackingRecycle.getRecycleStatus().equals(BPMConstants.CDHP_RECYCLE_STATUS_DENIED)) {
					lPersonActivityIncentToFulfillReconcileDeniedInErrorRecycle.add(lPersonActivityIncentToFulfillReconcile);
				}
			}
			
			if (lPersonActivityIncentToFulfillReconcileOnHoldInErrorRecycle.size() > 0) {
				lPersonActivityIncentToFulfillReconcileDifferences.removeAll(lPersonActivityIncentToFulfillReconcileOnHoldInErrorRecycle);
			}
			if (lPersonActivityIncentToFulfillReconcileDeniedInErrorRecycle.size() > 0) {
				lPersonActivityIncentToFulfillReconcileDifferences.removeAll(lPersonActivityIncentToFulfillReconcileDeniedInErrorRecycle);
			}
		
			
			return lPersonActivityIncentToFulfillReconcileOnHoldInErrorRecycle;
		}

		private Collection<CDHPFulfillmentTrackingRecycle> buildCDHPFulfillmentRecycle(Collection<PersonActivityIncentToFulfillReconcile> lPersonActivityIncentToFulfillReconcileDifferences) throws BPMException {
				Collection<CDHPFulfillmentTrackingRecycle> lCDHPFulfillmentTrackingRecycles = new ArrayList<CDHPFulfillmentTrackingRecycle>();
				
				LookUpValueCode lookUpValueCode = new LookUpValueCode();
				
				for (PersonActivityIncentToFulfillReconcile lPersonActivityIncentToFulfillReconcile : lPersonActivityIncentToFulfillReconcileDifferences) {
					CDHPFulfillmentTrackingRecycle lCDHPFulfillmentTrackingRecycle = new CDHPFulfillmentTrackingRecycle();
					lCDHPFulfillmentTrackingRecycle.setProgramId(lPersonActivityIncentToFulfillReconcile.getProgramID());
					lCDHPFulfillmentTrackingRecycle.setPersonDemographicsID(lPersonActivityIncentToFulfillReconcile.getPersonDemographicsID());
					lCDHPFulfillmentTrackingRecycle.setContractNumber(Integer.valueOf(lPersonActivityIncentToFulfillReconcile.getContractNo()));
					lookUpValueCode = getLUVCodeByGroupNValue(BPMConstants.BPM_CDHP_RECYCLE_STATUS, BPMConstants.CDHP_RECYCLE_STATUS_ON_HOLD);
					lCDHPFulfillmentTrackingRecycle.setRecycleStatusId(lookUpValueCode.getLuvId());
					lCDHPFulfillmentTrackingRecycle.setRecycleStatDate(BPMUtils.calendarToSqlDate(Calendar.getInstance()));
					lCDHPFulfillmentTrackingRecycle.setActivityId(lPersonActivityIncentToFulfillReconcile.getActivityID());
					lCDHPFulfillmentTrackingRecycle.setActivityStatusIncentiveDate(lPersonActivityIncentToFulfillReconcile.getIncentedDate());
					lCDHPFulfillmentTrackingRecycle.setPackageSubTypeName(BPMConstants.CDHP_PURCH_SUB_TP_NM_HRA);
					lCDHPFulfillmentTrackingRecycle.setInsertUser(BPMConstants.BPM_USER_SYSTEM);
					lCDHPFulfillmentTrackingRecycle.setInsertDate(BPMUtils.calendarToSqlDate(Calendar.getInstance()));
					lCDHPFulfillmentTrackingRecycles.add(lCDHPFulfillmentTrackingRecycle);
				}
				
				
				return lCDHPFulfillmentTrackingRecycles;
				
		}
		
		private LookUpValueCode getLUVCodeByGroupNValue(String group, String value) throws BPMException {
			LookUpValueCode lookUpValueCode = null;
			try {
				lookUpValueCode = lookUpValueService.getLUVCodeByGroupNValue(group, value);
			} catch (Exception ex) {
				logger.error("Error performing lookup of LookUpValue id for " +  group);
				throw new BPMException(ex.getMessage(), ex);
			}
			
			return lookUpValueCode;
		}
			
		public void setMemberService(MemberService memberService) {
			this.memberService = memberService;
		}

		public void setLookUpValueService(LookUpValueService lookUpValueService) {
			this.lookUpValueService = lookUpValueService;
		}

		public void setPersonDAO(PersonDAO personDAO) {
			this.personDAO = personDAO;
		}

		public void setEmailService(EmailService emailService) {
			this.emailService = emailService;
		}

		

}

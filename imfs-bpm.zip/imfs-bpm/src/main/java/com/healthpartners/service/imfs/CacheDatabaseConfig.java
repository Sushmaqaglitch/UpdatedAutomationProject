package com.healthpartners.service.imfs;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import javax.sql.DataSource;

import static java.util.Objects.requireNonNull;

@Configuration
public class CacheDatabaseConfig {

    @Autowired
    private Environment env;

    @Bean(name = "cacheDataSource")
    public DataSource getDataSource() {
        String url = requireNonNull(env.getProperty("spring.datasource.cache.url"));
        String username = requireNonNull(env.getProperty("spring.datasource.cache.username"));
        String password = requireNonNull(env.getProperty("spring.datasource.cache.password"));
        String driverClassName = requireNonNull(env.getProperty("spring.datasource.cache.driver-class-name"));
        return DataSourceBuilder.create()
                .url(url)
                .username(username)
                .password(password)
                .driverClassName(driverClassName).build();
    }

    public static void main(String[] args) {
        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(CacheDatabaseConfig.class);

    }


}

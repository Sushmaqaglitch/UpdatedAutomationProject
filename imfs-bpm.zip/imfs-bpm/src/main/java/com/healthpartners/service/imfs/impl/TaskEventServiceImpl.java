package com.healthpartners.service.imfs.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
//import org.springframework.transaction.TransactionDefinition;
//import org.springframework.transaction.TransactionStatus;
//import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.dao.TaskEventLogDAO;
import com.healthpartners.service.imfs.dto.TaskEvent;
import com.healthpartners.service.imfs.exception.BPMBusinessValidationException;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.iface.ProgramStatusCalculationService;
import com.healthpartners.service.imfs.iface.TaskEventService;
//import com.healthpartners.service.imfs.jms.TaskEventGenerator;
import com.healthpartners.service.imfs.rules.StatusCalculationCommand;

/**
 * @author mxthoutam
 * 
 */
@Component
@Service
public class TaskEventServiceImpl implements TaskEventService {


	protected final Log logger = LogFactory.getLog(getClass());

	/**
	 * services references
	 */
	private ProgramStatusCalculationService programStatusCalculationService;

	/**
	 * dao's references
	 */
	@Autowired
	private TaskEventLogDAO taskEventLogDAO;

	/**
	 * messaging references
	 */
//	private TaskEventGenerator taskEventGenerator;

	/**
	 * Transaction manager data source
	 */
	private DataSourceTransactionManager txManager;

	/**
	 * 
	 */
	public TaskEventServiceImpl() {
		super();
	}


	@Transactional(timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public long recieveTaskEvent(TaskEvent taskEvent)
			throws BPMBusinessValidationException, BPMException,
			DataAccessException {
		Long taskEventLogID = Long.valueOf(0);
		//DefaultTransactionDefinition def = new DefaultTransactionDefinition();
		//def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		//TransactionStatus status = txManager.getTransaction(def);
		try {
			// 1. validate,
			validateTaskEvent(taskEvent);

			// 2.log activityevent
			taskEvent
					.setProcessingStatusValue(BPMConstants.PROCESSING_STATUS_PENDING);
			taskEventLogID = taskEventLogDAO.insertTaskEventLog(taskEvent);
			//taskEvent.setTaskEventLogID(taskEventLogID);

			// Commit the transaction before JMS picks
			//txManager.commit(status);
			
			// 3. generate message
//			taskEventGenerator.sendJMS(taskEventLogID);

		} catch (DataAccessException dae) {
			//txManager.rollback(status);
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		} catch (BPMBusinessValidationException ve) {
			//txManager.rollback(status);
			logger.error("BPMBusinessValidationException: " + ve.getMessage(),
					ve);
			throw ve;
		} catch (BPMException ve) {
			//txManager.rollback(status);
			logger.error("BPMException: " + ve.getMessage(), ve);
			throw ve;
		} catch (Exception e) {
			//txManager.rollback(status);
			logger.error("BPMException: " + e.getMessage(), e);
			throw new BPMException(e);
		}

		return taskEventLogID;
	}


	@Transactional(timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public void processTaskEvent(Long taskEventLogID)
			throws BPMBusinessValidationException, BPMException,
			DataAccessException {
		TaskEvent taskEvent = null;
		//DefaultTransactionDefinition def = new DefaultTransactionDefinition();
		//def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		//TransactionStatus status = txManager.getTransaction(def);
		try {

			taskEvent = taskEventLogDAO.getTaskEvent(taskEventLogID);
			// 30.update processing status
			taskEvent
					.setProcessingStatusValue(BPMConstants.PROCESSING_STATUS_INPROCESS);
			taskEventLogDAO.updateTaskEventLogProcessingStatus(taskEvent);

			// 40. any Filtering?

			// 50.Program Status caluculation.
			StatusCalculationCommand statusCalculationCommand = new StatusCalculationCommand();
			statusCalculationCommand.setTaskEventCommand(taskEvent);
			programStatusCalculationService
					.updateProgramStatus(statusCalculationCommand);

			// 60. update processing statuses
			taskEvent
					.setProcessingStatusValue(BPMConstants.PROCESSING_STATUS_COMPLETED);
			taskEventLogDAO.updateTaskEventLogProcessingStatus(taskEvent);

			// Commit the transaction.
			//txManager.commit(status);

		} catch (DataAccessException dae) {
			//txManager.rollback(status);
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		} catch (Exception e) {
			//txManager.rollback(status);
			logger.error("BPMException: " + e.getMessage(), e);
			throw new BPMException(e);
		}

	}

	/**
	 * Validates TaskEvent
	 * 
	 * @param taskEvent
	 * @return void
	 * @throws BPMBusinessValidationException
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	private void validateTaskEvent(TaskEvent taskEvent)
			throws BPMBusinessValidationException, BPMException,
			DataAccessException {
	}


	public void setTaskEventLogDAO(TaskEventLogDAO dao) {
		this.taskEventLogDAO = dao;
	}

	/**
	 * Sets the ProgramStatusCalculationService. Should only be called by
	 * Spring.
	 * 
	 * @param service
	 *            the ProgramStatusCalculationService service
	 */
	public void setProgramStatusCalculationService(
			ProgramStatusCalculationService service) {
		this.programStatusCalculationService = service;
	}


//	public void setTaskEventGenerator(TaskEventGenerator jmsSender) {
//		this.taskEventGenerator = jmsSender;
//	}

	/**
	 * Sets the Spring Transaction Manager. Should only be called by Spring.
	 * 
	 * @param txManager
	 */
	public void setTxManager(DataSourceTransactionManager txManager) {
		this.txManager = txManager;
	}

}

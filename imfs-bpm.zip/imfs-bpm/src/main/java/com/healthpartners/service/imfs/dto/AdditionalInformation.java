package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.util.Calendar;

public class AdditionalInformation implements Serializable
{	
	static final long serialVersionUID = 0L;

    public AdditionalInformation()
    {
    	super();
    }

    private Integer businessProgramID;
    private Integer additionalInfoID;
    private String additionalInfoName;
    private String additionalInfoText;
    private Integer sortOrder;
    private Integer additionalInfoTypeID;

	public final Integer getAdditionalInfoID() {
		return additionalInfoID;
	}
	public final void setAdditionalInfoID(Integer additionalInfoID) {
		this.additionalInfoID = additionalInfoID;
	}
	public final String getAdditionalInfoName() {
		return additionalInfoName;
	}
	public final void setAdditionalInfoName(String additionalInfoName) {
		this.additionalInfoName = additionalInfoName;
	}
	public final String getAdditionalInfoText() {
		return additionalInfoText;
	}
	public final void setAdditionalInfoText(String additionalInfoText) {
		this.additionalInfoText = additionalInfoText;
	}
	public final Integer getSortOrder() {
		return sortOrder;
	}
	public final void setSortOrder(Integer sortOrder) {
		this.sortOrder = sortOrder;
	}	
	public Integer getBusinessProgramID() {
		return businessProgramID;
	}
	public void setBusinessProgramID(Integer businessProgramID) {
		this.businessProgramID = businessProgramID;
	}
	public final Integer getAdditionalInfoTypeID() {
		return additionalInfoTypeID;
	}
	public final void setAdditionalInfoTypeID(Integer additionalInfoTypeID) {
		this.additionalInfoTypeID = additionalInfoTypeID;
	}
	
	
}

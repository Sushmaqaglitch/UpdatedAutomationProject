/**
 * 
 */
package com.healthpartners.service.imfs.dao;

import com.healthpartners.service.imfs.dto.BusinessProgramTO;
import com.healthpartners.service.imfs.rules.RuleAdapter;
import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.exception.BPMException;


/**
 * @author tjquist
 *
 */
public interface RuleGroupDAO {

	/**
	 * gets member exemption rules
	 * 
	 * @param businessProgram
	 * @return RuleAdapter
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public RuleAdapter getMemberExemptionRules(BusinessProgramTO businessProgram)
			throws BPMException, DataAccessException;

	/**
	 * gets Member Status rules
	 * 
	 * @param businessProgram
	 * @return RuleAdapter
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public RuleAdapter getMemberStatusRules(BusinessProgramTO businessProgram)
			throws BPMException, DataAccessException;

	/**
	 * gets Contract Status rules
	 * 
	 * @param businessProgram
	 * @return RuleAdapter
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public RuleAdapter getContractStatusRules(BusinessProgramTO businessProgram)
			throws BPMException, DataAccessException;
}

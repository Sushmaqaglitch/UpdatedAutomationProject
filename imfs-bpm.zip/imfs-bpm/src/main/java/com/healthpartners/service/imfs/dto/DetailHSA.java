package com.healthpartners.service.imfs.dto;



public class DetailHSA
{	
	static final long serialVersionUID = 0L;

    public DetailHSA()
    {
    	super();
    }

    private String recordType;
    private String recordID;
    private String fileDate;
    private String employerTaxID;
    private String hpGroupID;
    private String employerGroupName;
    private String policyHolderSocialSecurityNumber;
    private String policyHolderHPContractID;
    private String policyHolderHPMemberID;
    private String policyHolderLastName;
    private String policyHolderFirstName;
    private String policyHolderMiddleInit;
    private String activityType;
    private String activityID;
    private String activityDate;
    private String contributionDate;
    private Integer contributionAmount;
    private String contributionType;

	
	public String getRecordType() {
		return recordType;
	}
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}
	public String getRecordID() {
		return recordID;
	}
	public void setRecordID(String recordID) {
		this.recordID = recordID;
	}
	
	public String getFileDate() {
		return fileDate;
	}
	public void setFileDate(String fileDate) {
		this.fileDate = fileDate;
	}
	public String getEmployerTaxID() {
		return employerTaxID;
	}
	public void setEmployerTaxID(String employerTaxID) {
		this.employerTaxID = employerTaxID;
	}
	public String getHpGroupID() {
		return hpGroupID;
	}
	public void setHpGroupID(String hpGroupID) {
		this.hpGroupID = hpGroupID;
	}
	
	public String getEmployerGroupName() {
		return employerGroupName;
	}
	public void setEmployerGroupName(String employerGroupName) {
		this.employerGroupName = employerGroupName;
	}
	public String getPolicyHolderSocialSecurityNumber() {
		return policyHolderSocialSecurityNumber;
	}
	public void setPolicyHolderSocialSecurityNumber(
			String policyHolderSocialSecurityNumber) {
		this.policyHolderSocialSecurityNumber = policyHolderSocialSecurityNumber;
	}
	public String getPolicyHolderHPContractID() {
		return policyHolderHPContractID;
	}
	public void setPolicyHolderHPContractID(String policyHolderHPContractID) {
		this.policyHolderHPContractID = policyHolderHPContractID;
	}
	public String getPolicyHolderHPMemberID() {
		return policyHolderHPMemberID;
	}
	public void setPolicyHolderHPMemberID(String policyHolderHPMemberID) {
		this.policyHolderHPMemberID = policyHolderHPMemberID;
	}
	public String getPolicyHolderLastName() {
		return policyHolderLastName;
	}
	public void setPolicyHolderLastName(String policyHolderLastName) {
		this.policyHolderLastName = policyHolderLastName;
	}
	public String getPolicyHolderFirstName() {
		return policyHolderFirstName;
	}
	public void setPolicyHolderFirstName(String policyHolderFirstName) {
		this.policyHolderFirstName = policyHolderFirstName;
	}
	public String getPolicyHolderMiddleInit() {
		return policyHolderMiddleInit;
	}
	public void setPolicyHolderMiddleInit(String policyHolderMiddleInit) {
		this.policyHolderMiddleInit = policyHolderMiddleInit;
	}
	public String getActivityType() {
		return activityType;
	}
	public void setActivityType(String activityType) {
		this.activityType = activityType;
	}
	
	public String getActivityID() {
		return activityID;
	}
	public void setActivityID(String activityID) {
		this.activityID = activityID;
	}
	
	public String getActivityDate() {
		return activityDate;
	}
	public void setActivityDate(String activityDate) {
		this.activityDate = activityDate;
	}
	public String getContributionDate() {
		return contributionDate;
	}
	public void setContributionDate(String contributionDate) {
		this.contributionDate = contributionDate;
	}
	public Integer getContributionAmount() {
		return contributionAmount;
	}
	public void setContributionAmount(Integer contributionAmount) {
		this.contributionAmount = contributionAmount;
	}
	public String getContributionType() {
		return contributionType;
	}
	public void setContributionType(String contributionType) {
		this.contributionType = contributionType;
	}
	
   
}

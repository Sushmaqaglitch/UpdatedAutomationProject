package com.healthpartners.service.imfs.dto;

import java.io.Serializable;

/**
 * 
 * @author jxbourbour
 *
 */
public class ContractIncentiveStatus implements Serializable
{	
	static final long serialVersionUID = 0L;
	
	private Integer programID;	
	private Integer contractNo;
	private String contractStatus;			
	private Integer qualificationCheckmarkID;
	private Integer programIncentiveOptionID;
	private String activationStatus;
		
	public ContractIncentiveStatus()
	{
		super();
	}

	public Integer getProgramID() {
		return programID;
	}

	public void setProgramID(Integer programID) {
		this.programID = programID;
	}

	public Integer getContractNo() {
		return contractNo;
	}

	public void setContractNo(Integer contractNo) {
		this.contractNo = contractNo;
	}

	public String getContractStatus() {
		return contractStatus;
	}

	public void setContractStatus(String contractStatus) {
		this.contractStatus = contractStatus;
	}	

	public Integer getQualificationCheckmarkID() {
		return qualificationCheckmarkID;
	}

	public void setQualificationCheckmarkID(Integer qualificationCheckmarkID) {
		this.qualificationCheckmarkID = qualificationCheckmarkID;
	}

	public Integer getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}

	public void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}

	public final String getActivationStatus() {
		return activationStatus;
	}

	public final void setActivationStatus(String activationStatus) {
		this.activationStatus = activationStatus;
	}

		
}

package com.healthpartners.service.imfs.dao;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;

import oracle.jdbc.internal.OracleTypes;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.healthpartners.service.imfs.common.BPMUtils;

/**
 * Calls the Stored Procedure createSmallGroupBizPgm.
 * 
 * @author jxbourbour
 *
 */
@Configuration
public class CallFilteredOutActivity extends StoredProcedure 
{

	protected final Log logger = LogFactory.getLog(getClass());

	@Autowired
	DataSource bpmDataSource;


	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}

    private static final String STORED_PROC_NAME = "pkg_bpm_utils.FilteredOutActivityReport";

    public CallFilteredOutActivity(DataSource bpmDataSource)
    {
        super(bpmDataSource, STORED_PROC_NAME);
        
        // Input Parameter
        // None.
        
        // Output Parameters                           
        declareParameter(new SqlOutParameter("o_filtered_out_cursor", OracleTypes.CURSOR, new RowMapper<String>() 
        {
			
			public String mapRow(ResultSet lResultSet, int rowNum) throws SQLException 
			{
				StringBuffer lLine = new StringBuffer();
    			    							
				lLine.append(lResultSet.getInt("biz_pgm_id"));
				lLine.append(",");
				lLine.append(lResultSet.getString("biz_pgm_tp_cd"));
				lLine.append(",");
    			lLine.append(lResultSet.getString("empl_grp_no"));
    			lLine.append(",");
    			lLine.append(lResultSet.getString("empl_grp_nm"));
    			lLine.append(",");
    			lLine.append(lResultSet.getString("hp_mem_id"));
    			lLine.append(",");
    			lLine.append(lResultSet.getString("actv_id"));
    			lLine.append(",");
    			lLine.append(lResultSet.getInt("actv_tp_cd_id"));
    			lLine.append(",");
    			lLine.append((lResultSet.getString("actv_nm")).replace(',', '-'));
    			lLine.append(",");
    			lLine.append(lResultSet.getString("auth_cd"));
    			lLine.append(",");
    			lLine.append(lResultSet.getString("rsn_desc"));
    			lLine.append(",");
    			lLine.append((lResultSet.getString("rsn_luv_desc")).replace(',', '-'));
    			lLine.append(",");
    			lLine.append(lResultSet.getInt("rsn_count"));
    			lLine.append("\r\n");
    			
    			return lLine.toString();
			}
		})); 
        
        compile();
    }

    /**
     * 
     *
     * @return
     */
    public String execute(String pFilePath)    
    {    	    	
        Map<String, Object> lInputParams = new HashMap<String, Object>(0);
                        
        Map<String, Object> lOutputParams = execute(lInputParams);
                                       
        if(lOutputParams.size() > 0) 
        {           	
        	Calendar lToday = Calendar.getInstance();
        	
        	String lPathAndFileName = pFilePath + "FilteredOut-" + BPMUtils.formatDateCCYYmmddWODel(lToday.getTime()) + ".csv";        	        	
        	        	
        	BufferedWriter lBufferedWriter = null;
        	
        	try
        	{      
        		lBufferedWriter = new BufferedWriter(new FileWriter(lPathAndFileName));
        		
        		StringBuffer lColumnHeaders = new StringBuffer();
        		lColumnHeaders.append("BIZ_PGM_ID,");
        		lColumnHeaders.append("BIZ_PGM_TP_CD,");
        		lColumnHeaders.append("EMPL_GRP_NO,");
        		lColumnHeaders.append("EMPL_GRP_NM,");
        		lColumnHeaders.append("HP_MEM_ID,");
        		lColumnHeaders.append("ACTV_ID,");
        		lColumnHeaders.append("ACTV_TP_CD_ID,");
        		lColumnHeaders.append("ACTV_NM,");
        		lColumnHeaders.append("AUTH_CD,");
        		lColumnHeaders.append("RSN_DESC,");
        		lColumnHeaders.append("RSN_TXT,");
        		lColumnHeaders.append("NO_OCCURENCES\r\n");
        		        		
        		lBufferedWriter.write(lColumnHeaders.toString());
        		
        		
        		ArrayList<String> lResults = (ArrayList<String>)lOutputParams.get("o_filtered_out_cursor");

        		for(String lLine : lResults)
        		{        			
        			lBufferedWriter.write(lLine);                    
        		}
        		
        		lBufferedWriter.flush();
        		lBufferedWriter.close();
        	}
        	catch(Exception e)
        	{        		        		
        		BPMUtils.logException(logger, e);
        		return "Error. Please check the log file.";
        	}  
        	
        	return lPathAndFileName;
        }                 
        
        return "No Data Today.";
    }

}

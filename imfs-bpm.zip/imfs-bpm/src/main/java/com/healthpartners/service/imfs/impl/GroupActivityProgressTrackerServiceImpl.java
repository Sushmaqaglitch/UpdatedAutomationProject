/**
 * 
 */
package com.healthpartners.service.imfs.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.dao.GroupActivityProgressTrackerDAO;
import com.healthpartners.service.imfs.dto.GroupActivityProgressTracker;
import com.healthpartners.service.imfs.dto.LookUpValueCode;
import com.healthpartners.service.imfs.iface.GroupActivityProgressTrackerService;
import com.healthpartners.service.imfs.iface.LookUpValueService;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/**
 * @author tjquist
 *
 */
@Component
@Service
public class GroupActivityProgressTrackerServiceImpl implements GroupActivityProgressTrackerService {

	@Autowired
	GroupActivityProgressTrackerDAO groupActivityProgressTrackerDAO;
	@Autowired
	LookUpValueService lookUpValueService;
	

	protected final Log logger = LogFactory.getLog(getClass());
	
	/**
	 * 
	 */
	public GroupActivityProgressTrackerServiceImpl() {
		super();
	}

	
	public GroupActivityProgressTracker getGroupActivityProgressionTracker(String pInputFileName, java.sql.Date pBatchDate, Integer trackingStatusID) {
		
		return groupActivityProgressTrackerDAO.getGroupActivityProgressionTracker(pInputFileName, pBatchDate, trackingStatusID);
		
	}
	

	public int updateGroupActivityProgressionTracker(GroupActivityProgressTracker pGroupActivityProgressTracker, String userID) throws DataAccessException {
		
		int result;
		
		GroupActivityProgressTracker lGroupActivityProgressTracker = groupActivityProgressTrackerDAO.getGroupActivityProgressionTracker(pGroupActivityProgressTracker.getInputFileName(), pGroupActivityProgressTracker.getBatchDate(), null);
		
		if (lGroupActivityProgressTracker != null) {
			result = groupActivityProgressTrackerDAO.updateGroupActivityProgressionTracker(pGroupActivityProgressTracker, userID);
		} else {
			result = groupActivityProgressTrackerDAO.insertGroupActivityProgressionTracker(pGroupActivityProgressTracker, userID);
		}
		
		return result;
	}
	
	/*
	 * method determines if tracker record already on file with a POSTPROCESS status to prevent the same file from being processed twice.
	 */
	public boolean isFileAlreadyProcessed(GroupActivityProgressTracker lGroupActivityProgressTracker) throws Exception, DataAccessException {
		
		boolean fileAlreadyProcessed = false;
		
		LookUpValueCode luv = null;
		
		try {
			luv = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.UPL_EMPL_TRACK_STAT_GROUP, BPMConstants.UPL_EMPL_POSTPROCESS_STATUS);
		} catch (DataAccessException e) {
			logger.error("Failed read for luv " + BPMConstants.UPL_EMPL_TRACK_STAT_GROUP + " " + BPMConstants.UPL_EMPL_POSTPROCESS_STATUS);
			throw e;
		}
		
		GroupActivityProgressTracker lGroupActivityProgressTrackerRec = getGroupActivityProgressionTracker(lGroupActivityProgressTracker.getInputFileName(), lGroupActivityProgressTracker.getBatchDate(), luv.getLuvId());
		
		
		if (lGroupActivityProgressTrackerRec != null && lGroupActivityProgressTrackerRec.getTrackingStatusCode().equals(BPMConstants.UPL_EMPL_POSTPROCESS_STATUS)) {
			fileAlreadyProcessed = true;
		}
		
		return fileAlreadyProcessed;
		
	}
	
	/*
	 * method determines if tracker record already on file with a PREPROCESS status to prevent the same file from being processed twice.
	 */
	public boolean isFilePreProcess(GroupActivityProgressTracker lGroupActivityProgressTracker) throws Exception, DataAccessException {
		
		boolean filePreProcess = false;
		
		LookUpValueCode luv = null;
		
		try {
			luv = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.UPL_EMPL_TRACK_STAT_GROUP, BPMConstants.UPL_EMPL_PREPROCESS_STATUS);
		} catch (DataAccessException e) {
			logger.error("Failed read for luv " + BPMConstants.UPL_EMPL_TRACK_STAT_GROUP + " " + BPMConstants.UPL_EMPL_PREPROCESS_STATUS);
			throw e;
		}
		
		GroupActivityProgressTracker lGroupActivityProgressTrackerRec = getGroupActivityProgressionTracker(lGroupActivityProgressTracker.getInputFileName(), lGroupActivityProgressTracker.getBatchDate(), luv.getLuvId());
		
		
		if (lGroupActivityProgressTrackerRec != null && lGroupActivityProgressTrackerRec.getTrackingStatusCode().equals(BPMConstants.UPL_EMPL_PREPROCESS_STATUS)) {
			filePreProcess = true;
		}
		
		return filePreProcess;
		
	}
	
	/*
	 * method determines if tracker record already on file with a INPROCESS status to prevent the same file from being processed twice.
	 */
	public boolean isFileINProcess(GroupActivityProgressTracker lGroupActivityProgressTracker) throws Exception, DataAccessException {
		
		boolean fileINProcess = false;
		
		LookUpValueCode luv = null;
		
		try {
			luv = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.UPL_EMPL_TRACK_STAT_GROUP, BPMConstants.UPL_EMPL_INPROCESS_STATUS);
		} catch (DataAccessException e) {
			logger.error("Failed read for luv " + BPMConstants.UPL_EMPL_TRACK_STAT_GROUP + " " + BPMConstants.UPL_EMPL_INPROCESS_STATUS);
			throw e;
		}
		
		GroupActivityProgressTracker lGroupActivityProgressTrackerRec = getGroupActivityProgressionTracker(lGroupActivityProgressTracker.getInputFileName(), lGroupActivityProgressTracker.getBatchDate(), luv.getLuvId());
		
		
		if (lGroupActivityProgressTrackerRec != null && lGroupActivityProgressTrackerRec.getTrackingStatusCode().equals(BPMConstants.UPL_EMPL_INPROCESS_STATUS)) {
			fileINProcess = true;
		}
		
		return fileINProcess;
		
	}
	
	/*
	 * method determines if tracker record exists for file being processed.
	 */
	public boolean isNoFileBeenProcessed(GroupActivityProgressTracker lGroupActivityProgressTracker) throws Exception, DataAccessException {
		
		boolean noFileHasBeenProcessed = false;
		
		GroupActivityProgressTracker lGroupActivityProgressTrackerRec = getGroupActivityProgressionTracker(lGroupActivityProgressTracker.getInputFileName(), lGroupActivityProgressTracker.getBatchDate(), null);
		
		if (lGroupActivityProgressTrackerRec == null) {
			noFileHasBeenProcessed = true;
		}
		
		return noFileHasBeenProcessed;
		
	}


	public GroupActivityProgressTrackerDAO getGroupActivityProgressTrackerDAO() {
		return groupActivityProgressTrackerDAO;
	}


	public void setGroupActivityProgressTrackerDAO(
			GroupActivityProgressTrackerDAO groupActivityProgressTrackerDAO) {
		this.groupActivityProgressTrackerDAO = groupActivityProgressTrackerDAO;
	}


	public LookUpValueService getLookUpValueService() {
		return lookUpValueService;
	}


	public void setLookUpValueService(LookUpValueService lookUpValueService) {
		this.lookUpValueService = lookUpValueService;
	}
	
	
	
}

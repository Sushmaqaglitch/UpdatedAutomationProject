package com.healthpartners.service.imfs.dto;

import java.sql.Date;
import java.sql.Time;
/**
 * 
 * @author tjquist
 *
 */
public class PersonContractRecycle extends BaseDTO {
	
	static final long serialVersionUID = 0L;
	
	private Integer personContractRecycleId;
	private Integer contractNumber;
	private Integer personNumber;
	private Integer personDemographicsID;
	private Integer programId;
	private Integer contractStatusPrevId;
	private Integer contractStatusCurrentId;
	private String 	contractStatusPrev;
	private String 	contractStatusCurrent;
	private Integer memberStatusPrevId;
	private Integer memberStatusCurrentId;
	private String 	memberStatusPrev;
	private String 	memberStatusCurrent;
	private String  recycleStatus;
	private Integer recycleStatusId;
	private Date qualificationStartDate;
	private Date qualificationEndDate;
	private Date programStartDate;
	private Date programEndDate;
	private Date insertDate;
	private Date modifyDate;
	private Date recycleStatDate;
	private String reasonDesc;
	private String approverUserId;
	private String insertUser;
	private String modifyUser;
	private String luvOnHoldQualifiedReviewWindowInDays;
	private Integer programIncentiveOptionID;
	
	
	public Integer getContractNumber() {
		return contractNumber;
	}
	public void setContractNumber(Integer contractNumber) {
		this.contractNumber = contractNumber;
	}
	public Integer getPersonNumber() {
		return personNumber;
	}
	public void setPersonNumber(Integer personNumber) {
		this.personNumber = personNumber;
	}
	
	public Integer getProgramId() {
		return programId;
	}
	public void setProgramId(Integer programId) {
		this.programId = programId;
	}
	
	public String getRecycleStatus() {
		return recycleStatus;
	}
	public void setRecycleStatus(String recycleStatus) {
		this.recycleStatus = recycleStatus;
	}
	public Date getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}
	public Date getModifyDate() {
		return modifyDate;
	}
	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}
	public Date getRecycleStatDate() {
		return recycleStatDate;
	}
	public void setRecycleStatDate(Date recycleStatDate) {
		this.recycleStatDate = recycleStatDate;
	}
	public String getReasonDesc() {
		return reasonDesc;
	}
	public void setReasonDesc(String reasonDesc) {
		this.reasonDesc = reasonDesc;
	}
	public String getApproverUserId() {
		return approverUserId;
	}
	public void setApproverUserId(String approverUserId) {
		this.approverUserId = approverUserId;
	}
	public String getInsertUser() {
		return insertUser;
	}
	public void setInsertUser(String insertUser) {
		this.insertUser = insertUser;
	}
	public String getModifyUser() {
		return modifyUser;
	}
	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}
	public Integer getRecycleStatusId() {
		return recycleStatusId;
	}
	public void setRecycleStatusId(Integer recycleStatusId) {
		this.recycleStatusId = recycleStatusId;
	}
	public Integer getPersonContractRecycleId() {
		return personContractRecycleId;
	}
	public void setPersonContractRecycleId(Integer personContractRecycleId) {
		this.personContractRecycleId = personContractRecycleId;
	}
	public Integer getContractStatusPrevId() {
		return contractStatusPrevId;
	}
	public void setContractStatusPrevId(Integer contractStatusPrevId) {
		this.contractStatusPrevId = contractStatusPrevId;
	}
	public Integer getContractStatusCurrentId() {
		return contractStatusCurrentId;
	}
	public void setContractStatusCurrentId(Integer contractStatusCurrentId) {
		this.contractStatusCurrentId = contractStatusCurrentId;
	}
	public String getContractStatusPrev() {
		return contractStatusPrev;
	}
	public void setContractStatusPrev(String contractStatusPrev) {
		this.contractStatusPrev = contractStatusPrev;
	}
	public String getContractStatusCurrent() {
		return contractStatusCurrent;
	}
	public void setContractStatusCurrent(String contractStatusCurrent) {
		this.contractStatusCurrent = contractStatusCurrent;
	}
	
	public Integer getMemberStatusPrevId() {
		return memberStatusPrevId;
	}
	public void setMemberStatusPrevId(Integer memberStatusPrevId) {
		this.memberStatusPrevId = memberStatusPrevId;
	}
	public Integer getMemberStatusCurrentId() {
		return memberStatusCurrentId;
	}
	public void setMemberStatusCurrentId(Integer memberStatusCurrentId) {
		this.memberStatusCurrentId = memberStatusCurrentId;
	}
	public String getMemberStatusPrev() {
		return memberStatusPrev;
	}
	public void setMemberStatusPrev(String memberStatusPrev) {
		this.memberStatusPrev = memberStatusPrev;
	}
	public String getMemberStatusCurrent() {
		return memberStatusCurrent;
	}
	public void setMemberStatusCurrent(String memberStatusCurrent) {
		this.memberStatusCurrent = memberStatusCurrent;
	}
	public Date getQualificationStartDate() {
		return qualificationStartDate;
	}
	public void setQualificationStartDate(Date qualificationStartDate) {
		this.qualificationStartDate = qualificationStartDate;
	}
	public Date getQualificationEndDate() {
		return qualificationEndDate;
	}
	public void setQualificationEndDate(Date qualificationEndDate) {
		this.qualificationEndDate = qualificationEndDate;
	}
	public Date getProgramStartDate() {
		return programStartDate;
	}
	public void setProgramStartDate(Date programStartDate) {
		this.programStartDate = programStartDate;
	}
	public Date getProgramEndDate() {
		return programEndDate;
	}
	public void setProgramEndDate(Date programEndDate) {
		this.programEndDate = programEndDate;
	}
	public String getLuvOnHoldQualifiedReviewWindowInDays() {
		return luvOnHoldQualifiedReviewWindowInDays;
	}
	public void setLuvOnHoldQualifiedReviewWindowInDays(
			String luvOnHoldQualifiedReviewWindowInDays) {
		this.luvOnHoldQualifiedReviewWindowInDays = luvOnHoldQualifiedReviewWindowInDays;
	}
	public final Integer getPersonDemographicsID() {
		return personDemographicsID;
	}
	public final void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}
	public Integer getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}
	public void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}
	
	
	
    
}

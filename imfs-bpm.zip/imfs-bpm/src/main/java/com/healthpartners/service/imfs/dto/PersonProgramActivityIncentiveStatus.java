package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class PersonProgramActivityIncentiveStatus implements Serializable
{	
	static final long serialVersionUID = 0L;
		
	private Integer programID;
	private Integer personDemographicsID;
	private Integer activityID;
	private Integer activityIncentiveID;
	private Integer activityStatusCodeID;
	private String registrationID;
	private Date activityStatusIncentiveDate;
	private Integer beneftiContractTypeLuID;
	private Integer programIncentiveOptionID;
	private Integer incentiveOptionID;
	private Integer contributionAmt;
	
	private String groupNo;
	private String SiteNo;
	private String memberNo;
	private String lastName;
	private String firstName;
	private String contractNo;
	private String sourceActivityID;
	private String activityName;
	private String productType;
	private Integer programMemberIncentiveStatusID;
	private List<IncentiveStatusActivityDetail> incentiveStatusActivityDetails;
	private Date insertDate;
	private String purchaserSubtypeName;
	private Integer personProgramActivityStatusID;
	private Date programEffectiveDate;
	private Date programEndDate;
	public Integer getProgramID() {
		return programID;
	}
	public void setProgramID(Integer programID) {
		this.programID = programID;
	}
	
	
	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}
	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}
	public Integer getActivityID() {
		return activityID;
	}
	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}
	public Integer getActivityIncentiveID() {
		return activityIncentiveID;
	}
	public void setActivityIncentiveID(Integer activityIncentiveID) {
		this.activityIncentiveID = activityIncentiveID;
	}
	public Integer getActivityStatusCodeID() {
		return activityStatusCodeID;
	}
	public void setActivityStatusCodeID(Integer activityStatusCodeID) {
		this.activityStatusCodeID = activityStatusCodeID;
	}
	
	
	public String getRegistrationID() {
		return registrationID;
	}
	public void setRegistrationID(String registrationID) {
		this.registrationID = registrationID;
	}
	public Date getActivityStatusIncentiveDate() {
		return activityStatusIncentiveDate;
	}
	public void setActivityStatusIncentiveDate(Date activityStatusIncentiveDate) {
		this.activityStatusIncentiveDate = activityStatusIncentiveDate;
	}
	public Integer getBeneftiContractTypeLuID() {
		return beneftiContractTypeLuID;
	}
	public void setBeneftiContractTypeLuID(Integer beneftiContractTypeLuID) {
		this.beneftiContractTypeLuID = beneftiContractTypeLuID;
	}

	
	public Integer getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}
	public void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}
	public Integer getIncentiveOptionID() {
		return incentiveOptionID;
	}
	public void setIncentiveOptionID(Integer incentiveOptionID) {
		this.incentiveOptionID = incentiveOptionID;
	}
	public Integer getContributionAmt() {
		return contributionAmt;
	}
	public void setContributionAmt(Integer contributionAmt) {
		this.contributionAmt = contributionAmt;
	}
	public String getGroupNo() {
		return groupNo;
	}
	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}
	public String getSiteNo() {
		return SiteNo;
	}
	public void setSiteNo(String siteNo) {
		SiteNo = siteNo;
	}
	
	public String getMemberNo() {
		return memberNo;
	}
	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getContractNo() {
		return contractNo;
	}
	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}
	public String getSourceActivityID() {
		return sourceActivityID;
	}
	public void setSourceActivityID(String sourceActivityID) {
		this.sourceActivityID = sourceActivityID;
	}
	public String getActivityName() {
		return activityName;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	
	public List<IncentiveStatusActivityDetail> getIncentiveStatusActivityDetails() {
		return incentiveStatusActivityDetails;
	}
	public void setIncentiveStatusActivityDetails(
			List<IncentiveStatusActivityDetail> incentiveStatusActivityDetails) {
		this.incentiveStatusActivityDetails = incentiveStatusActivityDetails;
	}
	
	public Integer getProgramMemberIncentiveStatusID() {
		return programMemberIncentiveStatusID;
	}
	public void setProgramMemberIncentiveStatusID(
			Integer programMemberIncentiveStatusID) {
		this.programMemberIncentiveStatusID = programMemberIncentiveStatusID;
	}
	public Date getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}
	public String getPurchaserSubtypeName() {
		return purchaserSubtypeName;
	}
	public void setPurchaserSubtypeName(String purchaserSubtypeName) {
		this.purchaserSubtypeName = purchaserSubtypeName;
	}
	public Integer getPersonProgramActivityStatusID() {
		return personProgramActivityStatusID;
	}
	public void setPersonProgramActivityStatusID(
			Integer personProgramActivityStatusID) {
		this.personProgramActivityStatusID = personProgramActivityStatusID;
	}
	public Date getProgramEffectiveDate() {
		return programEffectiveDate;
	}
	public void setProgramEffectiveDate(Date programEffectiveDate) {
		this.programEffectiveDate = programEffectiveDate;
	}
	public Date getProgramEndDate() {
		return programEndDate;
	}
	public void setProgramEndDate(Date programEndDate) {
		this.programEndDate = programEndDate;
	}
	
	
}

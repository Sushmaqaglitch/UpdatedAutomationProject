package com.healthpartners.service.imfs.dao;

import java.util.Collection;

import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.dto.CDHPBatchLog;
import com.healthpartners.service.imfs.dto.CDHPControlGroup;
import com.healthpartners.service.imfs.dto.CDHPControlGroupProcessTracker;
import com.healthpartners.service.imfs.dto.RewardControlProgram;
import com.healthpartners.service.imfs.dto.RewardControlProgramProcessTracker;
import com.healthpartners.service.imfs.dto.Risk;

public interface RewardControlProgramDAO 
{

	public Collection<RewardControlProgram> getRewardControlPrograms(String quoteID);
	
	public int insertRewardControlProgramProcessTracker(Integer programID, String processStatus, Integer recordsSent)
	throws DataAccessException;
	
	public RewardControlProgramProcessTracker getRewardControlProgramProcessTracker(Integer controlProgramID);
	
}

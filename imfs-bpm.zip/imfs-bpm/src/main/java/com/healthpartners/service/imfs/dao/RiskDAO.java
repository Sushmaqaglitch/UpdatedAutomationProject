package com.healthpartners.service.imfs.dao;

import java.util.Collection;

import com.healthpartners.service.imfs.dto.Risk;

public interface RiskDAO 
{

	public Risk getRiskByName(String pRiskName);
	public Risk getRiskByGroupName(String pRiskGroupName);
	public Collection<Risk> getAllRisks();
}

package com.healthpartners.service.imfs.dao;

import com.healthpartners.service.imfs.dto.ReconLogStage;
import org.springframework.dao.DataAccessException;

public interface ReconLogStageDAO
{

    public abstract ReconLogStage getReconLogStage(Integer integer)
        throws DataAccessException;

    public abstract int insertReconLogStage(ReconLogStage reconlogstage)
        throws DataAccessException;
}
package com.healthpartners.service.imfs.iface;

import com.healthpartners.service.imfs.dto.BPMAuditRecord;
import org.springframework.dao.DataAccessException;


/**
 * Provides AuditLog Insert services.
 * 
 * @author tjquist
 * 
 */
public interface AuditLogService {

	/**
	 
	 */
	
	public Integer insertAuditLog(BPMAuditRecord BPMAuditRecord)
			throws DataAccessException;

	public Integer purgeAuditLogByDate(java.sql.Date purgeDate)
			throws DataAccessException;
	
	public Integer getAuditLogCount()
			throws DataAccessException;

}


package com.healthpartners.service.imfs.iface;

import com.healthpartners.service.imfs.dto.TaskEvent;
import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.exception.BPMBusinessValidationException;
import com.healthpartners.service.imfs.exception.BPMException;

/**
 * @author mxthoutam
 *
 */
public interface TaskEventService {

	/**
	 * Recieves the TaskEvent from web service call
	 * 
	 * @param taskEvent
	 * @return long - activityEventLogID
	 * @throws BPMBusinessValidationException
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public long recieveTaskEvent(TaskEvent taskEvent)
			throws BPMBusinessValidationException, BPMException,
			DataAccessException;

	/**
	 * Process the <code>TaskEvent</code>
	 * 
	 * @param taskEventLogID
	 * @throws BPMBusinessValidationException
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public void processTaskEvent(Long taskEventLogID)
			throws BPMBusinessValidationException, BPMException,
			DataAccessException;


}

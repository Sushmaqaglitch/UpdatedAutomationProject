package com.healthpartners.service.imfs.controller;

import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.iface.ProgramStatusCalculationService;
import com.healthpartners.service.imfs.rules.StatusCalculationCommand;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@ControllerAdvice
@Component
public class ProgramStatusCalculationController {
    protected final Logger logger = LogManager.getLogger(getClass());

    @Autowired
    private ProgramStatusCalculationService programStatusCalculationService;


    private String userID;

    private String processName;

    // type of process - ex memberhip update etl job - 1, re-calculation-2,
    // admin membership update-10, admin re calc-11
    private Map<String, Integer> processIDsMap = new HashMap<String, Integer>();

    //used at the time of processing
    private String currentProcessingCommand;

    private String currentCommandText;

    private int daySpanToCtrlFilteredOutActivity;

    private String snapShotEmplFulfillTrackDate;

    private String snapShotActivityActivityFulfillTrackDate;

    private String startEmplFulfillTrackDate;

    private String startDate;

    private String snapShotCDHPHRAFulfillTrackDate;

    private String groupNo;

    private String hostName;

    private String sourceSystemID;

    private String startAtTwoDaysNolderFlag;

    private boolean batchProcessRunning = false;

    @RequestMapping(value = "/startBatchProcess",
            produces = "application/json",
            method= RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<String> startBatchProcess(@RequestParam("userID") String userID,
                                              @RequestParam("processName") String processName,
                                              @RequestParam("daySpan") Integer daySpan,
                                              @RequestParam("sourceSystemID") String sourceSystemID,
                                              @RequestParam("groupNo") String groupNo)
            throws Exception {


        logger.info("BPMBatchWebservice startBatchProcess called...");
        String message = null;

        try {
            if (batchProcessRunning) {
                //batch process already kicked off and is still running.
                logger.info("BPMBatchWebservice startBatchProcess: batch process still running on managed server.");

            } else if (processName == null) {
                logger.info("BPMBatchWebservice startBatchProcess.updateProgramStatus(), StatusCalculationCommand is null!!!");
            } else {

                StatusCalculationCommand pStatusCalculationCommand = setBatchCommands(userID, processName, sourceSystemID, groupNo);

                if (pStatusCalculationCommand.getParametersMap().size() > 0) {

                    logger.info("Call pProgramStatusCalculationService.updateProgramStatus.");
                    batchProcessRunning = true;
                    pStatusCalculationCommand.setDaySpanToCtrlFilteredOutActivity(daySpan);
                    pStatusCalculationCommand.setUserID(userID);
                    pStatusCalculationCommand.setProcessName(processName);
                    programStatusCalculationService.updateProgramStatus(pStatusCalculationCommand);
                    batchProcessRunning = false;
                } else {
                    message = "No match found using process name " + processName;
                    logger.error(message);
                    return new ResponseEntity<>(message, HttpStatus.EXPECTATION_FAILED);
                }

            }
        }  catch(BPMException se) {
            batchProcessRunning = false;
            message = "BPMException: " + se.getMessage();
            logger.error(message);
            return new ResponseEntity<>(message, HttpStatus.EXPECTATION_FAILED);

        }  finally {
            batchProcessRunning = false;
        }

        return new ResponseEntity<>("Batch service was successfull!", HttpStatus.OK);

    }

    @RequestMapping(value = "/startBatchProcessASEndpointMonitor",
            produces = "application/json",
            method= RequestMethod.POST)
    public ResponseEntity<String> monitoring()
            throws Exception {

        return new ResponseEntity<>("MonitorAlert: /startBatchProcess rest endpoint available!", HttpStatus.OK);

    }

    private StatusCalculationCommand setBatchCommands(String userID, String processName, String sourceSystemID, String groupNo) {
        StatusCalculationCommand pStatusCalculationCommand = new StatusCalculationCommand();

        logger.info("BPMBatchWebservice Batch Command is " + processName);

        if (StatusCalculationCommand.PENDING_ACTIVITY_EVENTS.equals(processName)) {
            pStatusCalculationCommand.setPendingActivityEventsCommand();
            logger.info("PendingActivityEventsCommand is set.");
        }
        if (StatusCalculationCommand.PENDING_TASK_EVENTS.equals(processName)) {
            pStatusCalculationCommand.setPendingTaskEventsCommand();
            logger.info("PendingTaskEventsCommand is set.");
        }
        if (StatusCalculationCommand.MEMBERSHIP_FEED.equals(processName)) {
            pStatusCalculationCommand.setMbrShipFeedCommand();
            logger.info("MbrShipFeedCommand is set.");
        }
        if (StatusCalculationCommand.MEMBERSHIP_PREMIUM_BILLING_FEED.equals(processName)) {
            pStatusCalculationCommand.setMbrShipPremiumBillingFeedCommand();
            logger.info("MbrShipPremiumBillingFeedCommand is set.");
        }
        if (StatusCalculationCommand.PURGE_AUDIT_LOG_TABLE.equals(processName)) {
            pStatusCalculationCommand.setPurgeAuditLogTableCommand();
            logger.info("PurgeAuditLogTableCommand is set.");
        }
        if (StatusCalculationCommand.PURGE_PROCESSLG_TABLE.equals(processName)) {
            pStatusCalculationCommand.setPurgeProcessStatLogTableCommand();
            logger.info("PurgeProcessStatLogTableCommand is set.");
        }
        if (StatusCalculationCommand.PURGE_GROUPBASELINEHIST_TABLE.equals(processName)) {
            pStatusCalculationCommand.setPurgeGroupBaselineHistTableCommand();
            logger.info("PurgeGroupBaselineHistTableCommand is set.");
        }
        //BPM-736
//        if (StatusCalculationCommand.MEMBERS_RECALCULATION.equals(processName)) {
//            pStatusCalculationCommand.setMembersReCalculationCommand();
//            logger.info("MembersReCalculationCommand is set.");
//        }
        if (StatusCalculationCommand.CONTRACT_RECONCILIATION.equals(processName)) {
            pStatusCalculationCommand.setPersonContractHistReconciliationCommandCommand();
            logger.info("PersonContractHistReconciliationCommand is set.");
        }
        if (StatusCalculationCommand.FILTERED_ACTIVITY_EVENTS.equals(processName)) {
            pStatusCalculationCommand.setFilteredActivityEventsCommand();
            logger.info("FilteredActivityEventsCommand is set.");
        }
        if (StatusCalculationCommand.MEMBER_ELAPSED_TIME.equals(processName)) {
            pStatusCalculationCommand.setMemberElapsedTimeCommand();
            logger.info("MemberElapsedTimeCommand is set.");
        }
        //BPM 736 disable service
//        if (StatusCalculationCommand.ETL_MEMBERSHIP_UPDATE.equals(processName)) {
//            pStatusCalculationCommand.setEtlMembershipUpdateCommand();
//            pStatusCalculationCommand.setProcessIDForEtlMembershipUpdateCommand(BPMConstants.ETL_MEMBERSHIP_UPDATE_PRCS_ID);
//            pStatusCalculationCommand.setCurrentProcessingCommand("ETL_MEMBERSHIP_UPDATE");
//            logger.info("EtlMembershipUpdateCommand is set.");
//        }
//        if (StatusCalculationCommand.ETL_MEMBERSHIP_UPDATE_ONLY.equals(processName)) {
//            pStatusCalculationCommand.setEtlMembershipUpdateOnlyCommand();
//            pStatusCalculationCommand.setCurrentProcessingCommand("ETL_MEMBERSHIP_UPDATE_ONLY");
//            logger.info("EtlMembershipUpdateOnlyCommand is set.");
//        }

        if (StatusCalculationCommand.AUTO_PROGRAM_SETUP.equals(processName)) {
            pStatusCalculationCommand.setAutoGroupSetup();
            logger.info("AutoGroupSetup is set.");
        }
        if (StatusCalculationCommand.EMPLOYER_FULFILLMENT_REPORTING.equals(processName)) {
            pStatusCalculationCommand.setEmployerReportingFulfillmentCommand();
            logger.info("Employer Fulfillment Reporting is set.");
        }
        if (StatusCalculationCommand.EMPLOYER_FULFILLMENT_REPORTING_RESEND.equals(processName)) {
            pStatusCalculationCommand.setResendEmployerReportingFulfillmentCommand();
            logger.info("Employer Fulfillment Reporting Resend is set.");
        }
        logger.info("Compare " + StatusCalculationCommand.CDHP_HRA_FULFILLMENT_REPORTING + " to " + processName);
        if (StatusCalculationCommand.CDHP_HRA_FULFILLMENT_REPORTING.equals(processName)) {
            pStatusCalculationCommand.setProcessCDHPHRAFulfillmentCommand();
            logger.info("CDHP HRA Fulfillment Reporting is set.");
        }
        logger.info("Compare " + StatusCalculationCommand.CDHP_HSA_FULFILLMENT_REPORTING + " to " + processName);
        if (StatusCalculationCommand.CDHP_HSA_FULFILLMENT_REPORTING.equals(processName)) {
            pStatusCalculationCommand.setProcessCDHPHSAFulfillmentCommand();
            logger.info("CDHP HSA Fulfillment Reporting is set.");
        }
        logger.info("Compare " + StatusCalculationCommand.REWARD_FULFILLMENT_SEND + " to " + processName);
        if (StatusCalculationCommand.REWARD_FULFILLMENT_SEND.equals(processName)) {
            pStatusCalculationCommand.setProcessRewardFulfillmentCommand();
            logger.info("Reward Card Fulfillment Send is set.");
        }
        logger.info("Compare " + StatusCalculationCommand.REWARD_INTELISPEND_REPORTING + " to " + processName);
        if (StatusCalculationCommand.REWARD_INTELISPEND_REPORTING.equals(processName)) {
            pStatusCalculationCommand.setProcessRewardFilesFromIntelispendFulfillmentCommand();
            logger.info("Reward Card Fulfillment Files From Intelispend is set.");
        }
        logger.info("Compare " + StatusCalculationCommand.AUTO_PROGRAM_NEW_SETUP + " to " + processName);
        if (StatusCalculationCommand.AUTO_PROGRAM_NEW_SETUP.equals(processName)) {
            pStatusCalculationCommand.setAutoProgramNewSmartStepsSetup();
            logger.info("Auto Program New SmartSteps is set.");
        }
        logger.info("Compare " + StatusCalculationCommand.EMPLOYER_GROUP_SITE_SETUP + " to " + processName);
        if (StatusCalculationCommand.EMPLOYER_GROUP_SITE_SETUP.equals(processName)) {
            pStatusCalculationCommand.setEmployerGroupSiteSetup();
            logger.info("Employer Group Site is set.");
        }
        logger.info("Compare " + StatusCalculationCommand.EMPLOYER_BASELINE_SETUP + " to " + processName);
        if (StatusCalculationCommand.EMPLOYER_BASELINE_SETUP.equals(processName)) {
            pStatusCalculationCommand.setEmployerBaselineSetup();
            logger.info("Employer Baseline is set.");
        }


        logger.info("Compare " + StatusCalculationCommand.UPLOAD_EMPLOYER_ACTIVITY_PREPROCESS + " to " + processName);
        if (StatusCalculationCommand.UPLOAD_EMPLOYER_ACTIVITY_PREPROCESS.equals(processName)) {
            pStatusCalculationCommand.setProcessBatchEmployerActivitiesPreprocessCommand();
            logger.info("Upload Employer Sponsored Activity Preprocess is set.");
        }
        logger.info("Compare " + StatusCalculationCommand.UPLOAD_EMPLOYER_ACTIVITY_POSTPROCESS + " to " + processName);
        if (StatusCalculationCommand.UPLOAD_EMPLOYER_ACTIVITY_POSTPROCESS.equals(processName)) {
            pStatusCalculationCommand.setProcessBatchEmployerActivitiesPostprocessCommand();
            logger.info("Upload Employer Sponsored Activity Postprocess is set.");
        }
        logger.info("Compare " + StatusCalculationCommand.OPTUM_INCENTED_TO_FULFILL_RECON + " to " + processName);
        if (StatusCalculationCommand.OPTUM_INCENTED_TO_FULFILL_RECON.equals(processName)) {
            pStatusCalculationCommand.setProcessBatchOptumMemberActivitiesIncentedToFulfillReconCommand();
            logger.info("Upload Optum Employer Sponsored Activity Incented To Fulfill Reconciliation is set.");
        }
        logger.info("Compare " + StatusCalculationCommand.DELETE_TERMED_PARTICIPANTS + " to " + processName);
        if (StatusCalculationCommand.DELETE_TERMED_PARTICIPANTS.equals(processName)) {
            pStatusCalculationCommand.setDeleteTermedParticipantsCommand();
            logger.info("Delete Termed Participants command is set.");
        }
        logger.info("Compare " + StatusCalculationCommand.RESET_ACTIVITY_EVENT_TO_PENDING + " to " + processName);
        if (StatusCalculationCommand.RESET_ACTIVITY_EVENT_TO_PENDING.equals(processName)) {
            pStatusCalculationCommand.setProcessResetActivityEventsFromInprocessToPendingCommand();
            logger.info("Reset Activity Event From IN_PROCESS To PENDING command is set.");
        }
        logger.info("Compare " + StatusCalculationCommand.AUTO_POPULATE_AUDIT_REPORT + " to " + processName);
        if (StatusCalculationCommand.AUTO_POPULATE_AUDIT_REPORT.equals(processName)) {
            pStatusCalculationCommand.setAutoPopulateAuditReport();
            logger.info("Auto Populate Audit Report.");
        }
        logger.info("Compare " + StatusCalculationCommand.ACTIVITY_TO_CONTRIBGRID_RECON + " to " + processName);
        if (StatusCalculationCommand.ACTIVITY_TO_CONTRIBGRID_RECON.equals(processName)) {
            pStatusCalculationCommand.setActivityToContribGridReconReport();
            logger.info("Activity To Contribution Grid Report.");
        }
        logger.info("Compare " + StatusCalculationCommand.POPULATE_MISSING_PEOPLE + " to " + processName);
        if (StatusCalculationCommand.POPULATE_MISSING_PEOPLE.equals(processName)) {
            pStatusCalculationCommand.setPopulateMissingPeopleSetup();
            logger.info("Populate missing people is set.");
        }

        logger.info("Compare " + StatusCalculationCommand.POPULATE_MISSING_ACTIVITIES + " to " + processName);
        if (StatusCalculationCommand.POPULATE_MISSING_ACTIVITIES.equals(processName)) {
            pStatusCalculationCommand.setPopulateMissingActivities();
            logger.info("Populate missing activities is set.");
        }

        logger.info("Compare " + StatusCalculationCommand.RECALC_DUALCOVERED_PARTICIPANTS + " to " + processName);
        if (StatusCalculationCommand.RECALC_DUALCOVERED_PARTICIPANTS.equals(processName)) {
            pStatusCalculationCommand.setRecalcDualCoveredPersons();
            logger.info("Recalc Dual Covered Participants is set.");
        }

        logger.info("Compare " + StatusCalculationCommand.POPULATE_PACKAGE_BASELINE + " to " + processName);
        if (StatusCalculationCommand.POPULATE_PACKAGE_BASELINE.equals(processName)) {
            pStatusCalculationCommand.setPopulatePackageBaseline();
            logger.info("Populate package baseline is set.");
        }
        logger.info("Compare " + StatusCalculationCommand.REPROCESS_INCENTED_ACTIVITY_W_UNRESOLVED + " to " + processName);
        if (StatusCalculationCommand.REPROCESS_INCENTED_ACTIVITY_W_UNRESOLVED.equals(processName)) {
            pStatusCalculationCommand.setProcessUnresolvedContractBenefitTypeForActivityIncentiveCommand();
            logger.info("Reprocess Incented Activities Unresolved Benefit Contract Types command is set.");
        }
        logger.info("Compare " + StatusCalculationCommand.CORRECT_PURCHASER_SUBTYPE + " to " + processName);
        if (StatusCalculationCommand.CORRECT_PURCHASER_SUBTYPE.equals(processName)) {
            pStatusCalculationCommand.setCorrectPurchaserSubtype();
            logger.info("Correct purchaser subtype is set.");
        }
        logger.info("Compare " + StatusCalculationCommand.ACTIVITY_CREATION_BASED_ON_PRECONDITION + " to " + processName);
        if (StatusCalculationCommand.ACTIVITY_CREATION_BASED_ON_PRECONDITION.equals(processName)) {
            pStatusCalculationCommand.setActivityEventCreationBasedOnPreconditionCommand();
            logger.info("Activity creation based on precondition is set.");
        }
        logger.info("Compare " + StatusCalculationCommand.ARCHIVE_PERSONCONTRACTHIST_TABLE + " to " + processName);
        if (StatusCalculationCommand.ARCHIVE_PERSONCONTRACTHIST_TABLE.equals(processName)) {
            pStatusCalculationCommand.setArchivePersonContractProgramHistoryCommand();
            logger.info("Archive Person Contract Program History is set.");
        }
        logger.info("Compare " + StatusCalculationCommand.MEMBERCONTRACTRECYCLE_ACTIONNEEDED_RPT + " to " + processName);
        if (StatusCalculationCommand.MEMBERCONTRACTRECYCLE_ACTIONNEEDED_RPT.equals(processName)) {
            pStatusCalculationCommand.setPersonContractRecycleActionNeededReportCommand();
            logger.info("Person Contract Recycle Action Needed Report command is set.");
        }

        logger.info("Compare " + StatusCalculationCommand.EMPLOYER_ACTIVITY_END_TO_END_RECON + " to " + processName);
        if (StatusCalculationCommand.EMPLOYER_ACTIVITY_END_TO_END_RECON.equals(processName)) {
            pStatusCalculationCommand.setEmployerActivityEndToEndReconCommand();
            logger.info("Employer activity end to end recon command is set.");
        }


        if (userID != null)
        {
            logger.info("User ID is: " + userID);
            pStatusCalculationCommand.setUserID(userID);
        }

        if (processName != null)
        {
            logger.info("Process name is: " + processName);
            pStatusCalculationCommand.setProcessName(processName);
        }

        if (groupNo != null)
        {
            logger.info("Group no is: " + groupNo);
            pStatusCalculationCommand.setGroupNo(groupNo);
        }

        if (sourceSystemID != null)
        {
            logger.info("SourceSystemID is: " + sourceSystemID);
            pStatusCalculationCommand.setSourceSystemID(sourceSystemID);
        }



//        logger.info("SnapShotEmplFulfillTrackDate is: " + pBatchCommandRequest.getSnapShotEmplFulfillTrackDate());
//        pStatusCalculationCommand.setSnapShotEmplFulfillTrackDate(pBatchCommandRequest.getSnapShotEmplFulfillTrackDate());
//
//        logger.info("StartEmplFulfillTrackDate is: " + pBatchCommandRequest.getStartEmplFulfillTrackDate());
//        pStatusCalculationCommand.setStartEmplFulfillTrackDate(pBatchCommandRequest.getStartEmplFulfillTrackDate());
//
//
//        logger.info("StartAtTwoDaysNolderFlag is: " + pBatchCommandRequest.getStartAtTwoDaysNolderFlag());
//        pStatusCalculationCommand.setStartAtTwoDaysNolderFlag(pBatchCommandRequest.getStartAtTwoDaysNolderFlag());
//
//        logger.info("DaySpanToCtrlFilteredOutActivity is: " + pBatchCommandRequest.getDaySpanToCtrlFilteredOutActivity());
//        pStatusCalculationCommand.setDaySpanToCtrlFilteredOutActivity(pBatchCommandRequest.getDaySpanToCtrlFilteredOutActivity());
//
//        pStatusCalculationCommand.setBatchSizeCommand(pBatchCommandRequest.getBatchSize());

        return pStatusCalculationCommand;
    }


}


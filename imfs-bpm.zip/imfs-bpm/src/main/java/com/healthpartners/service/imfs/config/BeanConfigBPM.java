package com.healthpartners.service.imfs.config;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;

import javax.sql.DataSource;

@Configuration
public class BeanConfigBPM {

    @Autowired
    DataSource bpmDataSource;

    @Primary
    @Bean(name = "DataSourceTransactionManager")
    public DataSourceTransactionManager getDataSourceTransactionManager() {
        return new DataSourceTransactionManager(bpmDataSource);
    }

    @Bean(name = "activityEventLogIdIncrementer")
    public OracleSequenceMaxValueIncrementer ActivityEventLogIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("ACTIVITY_EVENT_LOG_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "taskEventLogIdIncrementer")
    public OracleSequenceMaxValueIncrementer TaskEventLogIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("TASK_EVENT_LOG_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "cdhpTransIdIncrementer")
    public OracleSequenceMaxValueIncrementer CDHPTransIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("TASK_EVENT_LOG_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "qualificationOverrideIdIncrementer")
    public OracleSequenceMaxValueIncrementer QualificationOverrideIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("QUALFCTN_OVRD_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "contractStatusIdIncrementer")
    public OracleSequenceMaxValueIncrementer ContractStatusIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("CONTRACT_PROGRAM_STATUS_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "processingStatusLogIdIncrementer")
    public OracleSequenceMaxValueIncrementer ProcessingStatusLogIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("PROCESSING_STATUS_LOG_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "personHoldIdIncrementer")
    public OracleSequenceMaxValueIncrementer PersonHoldIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("phs_seq");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "auditLogIdIncrementer")
    public OracleSequenceMaxValueIncrementer AuditLogIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("audit_log_seq");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "businessProgramIdIncrementer")
    public OracleSequenceMaxValueIncrementer BusinessProgramIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("biz_pgm_id_seq");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "additionalInfoIdIncrementer")
    public OracleSequenceMaxValueIncrementer AdditionalInfoIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("ADDL_INFO_ID_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "personContractHistIdIncrementer")
    public OracleSequenceMaxValueIncrementer PersonContractHistIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("PRSN_CNTR_PGM_HIST_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "personContractRecycleIdIncrementer")
    public OracleSequenceMaxValueIncrementer PersonContractRecycleIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("PRSN_CNTR_PGM_RECYCLE_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "cdhpRecycleIdIncrementer")
    public OracleSequenceMaxValueIncrementer CDHPRecycleIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("CDHP_RECYC_ID_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "rewardRecycleIdIncrementer")
    public OracleSequenceMaxValueIncrementer RewardRecycleIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("REWARD_RECYCLE_ID_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "incentiveRequirementIdIncrementer")
    public OracleSequenceMaxValueIncrementer IncentiveRequirementIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("ACTV_INCNTV_GRP_ID_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "activityIncentiveIdIncrementer")
    public OracleSequenceMaxValueIncrementer ActivityIncentiveIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("ACTV_INCNTV_ID_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "contractIncentiveIdIncrementer")
    public OracleSequenceMaxValueIncrementer ContractIncentiveIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("CNTR_PGM_INCTV_ID_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "memberIncentiveIdIncrementer")
    public OracleSequenceMaxValueIncrementer MemberIncentiveIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("PGM_MEM_INCNTV_STAT_ID_seq");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "incentiveStatusActivityDetailIdIncrementer")
    public OracleSequenceMaxValueIncrementer IncentiveStatusActivityDetailIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("INCTV_STS_ACTV_DTL_ID_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "cdhpLogIdIncrementer")
    public OracleSequenceMaxValueIncrementer CDHPLogIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("CDHP_LOG_ID_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "rewardLogIdIncrementer")
    public OracleSequenceMaxValueIncrementer RewardLogIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("REWARD_BATCH_LOG_ID_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "actvLogIdIncrementer")
    public OracleSequenceMaxValueIncrementer ActvLogIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("ACTV_LOG_ID_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "participationGroupIDIncrementer")
    public OracleSequenceMaxValueIncrementer ParticipationGroupIDIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("incntv_part_grp_id_seq");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "personContractHistArchiveIdIncrementer")
    public OracleSequenceMaxValueIncrementer PersonContractHistArchiveIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("PRSN_CNTR_PGM_HIST_ARCHIVE_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "rewardStatusTransIdIncrementer")
    public OracleSequenceMaxValueIncrementer RewardStatusTransIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("REWARD_TXN_HIST_STS_ID_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "rewardTransIdIncrementer")
    public OracleSequenceMaxValueIncrementer RewardTransIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("REWARD_TXN_HIST_ID_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "transmAuditLogIdIncrementer")
    public OracleSequenceMaxValueIncrementer TransmAuditLogIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("TRNSMSN_AUDIT_LOG_ID_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "rewardOrderDetailIncrementer")
    public OracleSequenceMaxValueIncrementer RewardOrderDetailIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("REWARD_ORDR_DTL_RPT_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "rewardShipDetailIncrementer")
    public OracleSequenceMaxValueIncrementer RewardShipDetailIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("REWARD_SHPNG_DTL_RPT_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "employerRecycleIdIncrementer")
    public OracleSequenceMaxValueIncrementer EmployerRecycleIdIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("EPR_ID_SEQ");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "incentivePackageRuleGroupIDIncrementer")
    public OracleSequenceMaxValueIncrementer IncentivePackageRuleGroupIDIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("incntv_optn_pkg_rule_grp_seq");
        incrementer.afterPropertiesSet();
        return incrementer;
    }

    @Bean(name = "programChangeLogIDIncrementer")
    public OracleSequenceMaxValueIncrementer ProgramChangeLogIDIncrementer() {
        OracleSequenceMaxValueIncrementer incrementer = new OracleSequenceMaxValueIncrementer();
        incrementer.setDataSource(bpmDataSource);
        incrementer.setIncrementerName("biz_pgm_chng_log_seq");
        incrementer.afterPropertiesSet();
        return incrementer;
    }



    @Bean(name = "environmentHost")
    public String EnvironmentHost(@Value("${server.host}") String host) {
        return host;
    }

}

package com.healthpartners.service.imfs.iface;

import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.rules.StatusCalculationCommand;


public interface ResetActivityEventsFromInprocessToPendingService {
	
	public void processResetActivityEventsFromInprocessToPendingCommand(StatusCalculationCommand statusCalculationCommand) throws BPMException;

}

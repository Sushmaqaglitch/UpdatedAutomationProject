package com.healthpartners.service.imfs.dto;



public class HeaderHRA
{	

    public HeaderHRA()
    {
    	super();
    }

    private String recordType;    
    private String fileDate;
    private String fileClassification;
    private String carrierID;
    private String employerGroupID;

	public String getRecordType() {
		return recordType;
	}
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}
	
	public String getFileDate() {
		return fileDate;
	}
	public void setFileDate(String fileDate) {
		this.fileDate = fileDate;
	}
	public String getFileClassification() {
		return fileClassification;
	}
	public void setFileClassification(String fileClassification) {
		this.fileClassification = fileClassification;
	}
	public String getCarrierID() {
		return carrierID;
	}
	public void setCarrierID(String carrierID) {
		this.carrierID = carrierID;
	}
	public String getEmployerGroupID() {
		return employerGroupID;
	}
	public void setEmployerGroupID(String employerGroupID) {
		this.employerGroupID = employerGroupID;
	}
   
	
	
    
}

package com.healthpartners.service.imfs.dto;

import java.sql.Date;

public class RewardCardFulfilled
{	
	
	
	private Integer rewardTransHistID;
	private String groupNo;
	private String siteNo;
	private String memberNo;
	private String firstName;
	private String middleInit;
	private String lastName;
	private Integer programID;
	private Integer personDemographicsID;
	private Integer programIncentiveOptionID;
	private Integer activityID;
	private String activityName;
	private String orderId;
	private String rewardCardNoMasked;
	private Date insertDate;
	private Integer familyCap;
	private Integer participantCap;
	
        
    public RewardCardFulfilled()
    {
    	super();
    }


	public Integer getRewardTransHistID() {
		return rewardTransHistID;
	}


	public void setRewardTransHistID(Integer rewardTransHistID) {
		this.rewardTransHistID = rewardTransHistID;
	}


	public String getGroupNo() {
		return groupNo;
	}


	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}


	public String getSiteNo() {
		return siteNo;
	}


	public void setSiteNo(String siteNo) {
		this.siteNo = siteNo;
	}

	
	
	public String getMemberNo() {
		return memberNo;
	}


	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getMiddleInit() {
		return middleInit;
	}


	public void setMiddleInit(String middleInit) {
		this.middleInit = middleInit;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public Integer getProgramID() {
		return programID;
	}


	public void setProgramID(Integer programID) {
		this.programID = programID;
	}


	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}


	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}


	public Integer getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}


	public void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}

	

	public Integer getActivityID() {
		return activityID;
	}


	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}


	public String getActivityName() {
		return activityName;
	}


	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}


	public String getOrderId() {
		return orderId;
	}


	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}


	public String getRewardCardNoMasked() {
		return rewardCardNoMasked;
	}


	public void setRewardCardNoMasked(String rewardCardNoMasked) {
		this.rewardCardNoMasked = rewardCardNoMasked;
	}


	public Date getInsertDate() {
		return insertDate;
	}


	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}


	public Integer getFamilyCap() {
		return familyCap;
	}


	public void setFamilyCap(Integer familyCap) {
		this.familyCap = familyCap;
	}


	public Integer getParticipantCap() {
		return participantCap;
	}


	public void setParticipantCap(Integer participantCap) {
		this.participantCap = participantCap;
	}

	

    
    
	
}

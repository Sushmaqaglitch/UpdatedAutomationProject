package com.healthpartners.service.imfs.dto;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author jxbourbour
 * 
 */
public class IncentivePackageRuleRequirement implements Serializable {
	static final long serialVersionUID = 0L;

	private Integer incentivePackageRuleGroupID;
	private Integer incentivePackageRuleRequirementID;

	private List<IncentivePackageRuleDetail> incentivePackageRuleDetails = new ArrayList<IncentivePackageRuleDetail>();

	public IncentivePackageRuleRequirement() {
		super();
	}

	public Integer getIncentivePackageRuleGroupID() {
		return incentivePackageRuleGroupID;
	}

	public void setIncentivePackageRuleGroupID(Integer incentivePackageRuleGroupID) {
		this.incentivePackageRuleGroupID = incentivePackageRuleGroupID;
	}

	public Integer getIncentivePackageRuleRequirementID() {
		return incentivePackageRuleRequirementID;
	}

	public void setIncentivePackageRuleRequirementID(
			Integer incentivePackageRuleRequirementID) {
		this.incentivePackageRuleRequirementID = incentivePackageRuleRequirementID;
	}

	public List<IncentivePackageRuleDetail> getIncentivePackageRuleDetails() {
		return incentivePackageRuleDetails;
	}

	public void setIncentivePackageRuleDetails(
			List<IncentivePackageRuleDetail> incentivePackageRuleDetails) {
		this.incentivePackageRuleDetails = incentivePackageRuleDetails;
	}

		
	public IncentivePackageRuleDetail getIncentivePackageRuleDetail(int index) {
		return incentivePackageRuleDetails.get(index);
	}
}

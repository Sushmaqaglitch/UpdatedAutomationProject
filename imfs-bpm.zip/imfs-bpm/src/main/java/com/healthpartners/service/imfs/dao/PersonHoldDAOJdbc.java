package com.healthpartners.service.imfs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.dto.PersonHold;
import com.healthpartners.service.imfs.exception.BPMException;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;

@Configuration
public class PersonHoldDAOJdbc extends JdbcDaoSupport implements PersonHoldDAO
{
	private String insertPersonHold;
	private String selectPersonHolds;
	private String updatePersonHold;

	@Autowired
	private DataFieldMaxValueIncrementer personHoldIdIncrementer;

	@Autowired
	DataSource bpmDataSource;


	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}
	
	/**
	 * Insert a row into the person_hold_status table.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public long insertPersonHold(PersonHold pPersonHold)
	throws DataAccessException
	{
		Long personHoldId = new Long(personHoldIdIncrementer.nextLongValue());
		
		JdbcTemplate template = getJdbcTemplate();

		Object params[] = new Object[] { personHoldId, pPersonHold.getPersonID(), 
				pPersonHold.getRiskName(), 
				pPersonHold.getHoldEffectiveDate(), 
				//pPersonHold.getHoldEndDate(), 
				"BPM", "BPM"};

		int types[] = new int[] { Types.BIGINT, Types.INTEGER, 
				Types.VARCHAR,
				Types.DATE, 
				//Types.DATE,
				Types.VARCHAR, Types.VARCHAR };
		
		template.update(insertPersonHold, params, types);
		
		return personHoldId.longValue();
	}

	/**
	 * Retrieve all the holds for a person.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<PersonHold> getPersonHolds(Integer pPersonID)
	throws DataAccessException
	{
		ArrayList<PersonHold> lPersonHolds = new ArrayList<PersonHold>();
		
		JdbcTemplate template = getJdbcTemplate();				
		Object params[] = new Object[] { pPersonID};	
		int types[] = new int[] { Types.INTEGER }; 
				
		
		template.query(selectPersonHolds, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						PersonHold lPersonHold = new PersonHold();
			
						lPersonHold.setPersonHoldID(rs.getInt("phs_id"));
						lPersonHold.setPersonID(rs.getInt("prsn_id"));
						lPersonHold.setRiskID(rs.getInt("risk_id"));
						lPersonHold.setRiskName(rs.getString("risk_nm"));
						lPersonHold.setRiskHoldDuration(rs.getInt("hold_duration"));
						lPersonHold.setRiskGroupID(rs.getInt("risk_grp_cd_id"));
						lPersonHold.setRiskGroupValue(rs.getString("risk_group_val"));						
						lPersonHold.setHoldEffectiveDate(rs.getDate("hold_eff_dt"));
						lPersonHold.setHoldEndDate(rs.getDate("hold_end_dt"));						
					}
		});
		return lPersonHolds;
	}
	
	/**
	 * 
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public long updatePersonHold(PersonHold pPersonHold)
	throws DataAccessException
	{				
		JdbcTemplate template = getJdbcTemplate();

		Object params[] = new Object[] {pPersonHold.getHoldEffectiveDate(), 
				pPersonHold.getHoldEndDate(),
				"BPM",
				pPersonHold.getPersonID(), 
				pPersonHold.getRiskGroupValue()};

		int types[] = new int[] { Types.DATE, 
				Types.DATE,
				Types.VARCHAR, 
				Types.INTEGER, 
				Types.VARCHAR};
		
		return template.update(updatePersonHold, params, types);				
	}

	public String getInsertPersonHold() {
		return insertPersonHold;
	}

	public void setInsertPersonHold(String insertPersonHold) {
		this.insertPersonHold = insertPersonHold;
	}

	public DataFieldMaxValueIncrementer getPersonHoldIdIncrementer() {
		return personHoldIdIncrementer;
	}

	public void setPersonHoldIdIncrementer(
			DataFieldMaxValueIncrementer personHoldIdIncrementer) {
		this.personHoldIdIncrementer = personHoldIdIncrementer;
	}

	public String getSelectPersonHolds() {
		return selectPersonHolds;
	}

	public void setSelectPersonHolds(String selectPersonHolds) {
		this.selectPersonHolds = selectPersonHolds;
	}

	public String getUpdatePersonHold() {
		return updatePersonHold;
	}

	public void setUpdatePersonHold(String updatePersonHold) {
		this.updatePersonHold = updatePersonHold;
	}	
}

/* $Id: LookUpValueService.java 296322 2015-02-06 19:21:39Z tjquist $ */

package com.healthpartners.service.imfs.iface;

import java.util.Collection;

import com.healthpartners.service.imfs.dto.EnvCode;
import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.exception.BPMException;

/**
 * Provides EnvCode services.
 * 
 * @author tjquist
 */
public interface EnvCodeService {

	

	/**
	 * @see EnvCodeService#getENVCodesByDesc(String)
	 */
	public Collection<EnvCode> getENVCodesByDesc(String envDesc)
			throws BPMException, DataAccessException;
	
	/**
	 * @see EnvCodeService#getENVCodeByID(Integer)
	 */
	public EnvCode getENVCodeByID(Integer envValCodeID)
			throws BPMException, DataAccessException;
	
	
	
	public EnvCode getENVCodeByCode(String code)
			throws BPMException, DataAccessException;
	
}

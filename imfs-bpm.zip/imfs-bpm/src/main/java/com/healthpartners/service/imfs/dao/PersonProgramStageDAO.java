package com.healthpartners.service.imfs.dao;

import java.util.Collection;

import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.dto.ActivityFulfillmentTrackingReportHist;
import com.healthpartners.service.imfs.dto.PersonActivityStage;
import com.healthpartners.service.imfs.dto.PersonActivitySummaryStage;
import com.healthpartners.service.imfs.dto.PersonProgramStage;


public interface PersonProgramStageDAO 
{

	public int getPersonProgramCount() throws DataAccessException;;
	public int insertPersonPrograms(Collection<PersonProgramStage> personPrograms) throws DataAccessException;
	public int deletePersonPrograms(Collection<PersonProgramStage> personPrograms) throws DataAccessException;
	public PersonProgramStage getPersonProgram(int personNumber) throws DataAccessException;
	public Collection<PersonProgramStage> getPersonPrograms() throws DataAccessException;
	
	public int getPersonActivityCount() throws DataAccessException;
	public int insertPersonActivitys(Collection<ActivityFulfillmentTrackingReportHist> lActivityFulfillmentTrackingReportHist) throws DataAccessException, Exception;
	public int deletePersonActivitys() throws DataAccessException;
	public PersonActivityStage getPersonActivity(int personNumber) throws DataAccessException;
	public Collection<PersonActivityStage> getPersonActivitys() throws DataAccessException;
	
	public int deletePersonActivitySummary() throws DataAccessException;
	public PersonActivitySummaryStage getPersonActivitySummary() throws DataAccessException;
	public int insertPersonActivitySummary(PersonActivitySummaryStage lPersonActivitySummaryStage)
			throws DataAccessException, Exception;
		
	
}

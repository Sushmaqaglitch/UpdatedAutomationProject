package com.healthpartners.service.imfs.dao;


import org.springframework.dao.DataAccessException;


import com.healthpartners.service.imfs.dto.GroupActivityProgressTracker;


public interface GroupActivityProgressTrackerDAO {
	
	public GroupActivityProgressTracker getGroupActivityProgressionTracker(String pInputFileName, java.sql.Date pBatchDate, Integer trackingStatusID);
	
	
	public int updateGroupActivityProgressionTracker(GroupActivityProgressTracker pGroupActivityProgressTracker, String userID)
			throws DataAccessException;
	
	
	public int insertGroupActivityProgressionTracker(GroupActivityProgressTracker pGroupActivityProgressTracker, String userID)
			throws DataAccessException;
	
	
}

package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.util.Collection;

/**
 * This represents the activity summary after reading data file
 * 
 * @author tjquist
 * 
 */
public class EmployerActivityContributionsFileData implements Serializable {

	static final long serialVersionUID = 0L;
	
	String groupName;
	
	String groupNo;
	
	private String sourceActivityID;
	
	private String sourceSystemID;
	
	private String insertUserId;
	
	private Collection<EmployerSponsoredActivity> employerSponsoredActivitiesInput;
	
	private Collection<EmployerSponsoredActivity> validMemberActivities;
	
	private Collection<EmployerSponsoredActivity> fatalErrorMemberActivities;
	
	private Collection<EmployerSponsoredActivity> errorRecycleMemberActivities;
	
	private Collection<EmployerSponsoredActivity> previousYearActivitiesOverriddenMemberActivities;
	
	private EmployerSponsoredActivityTrailer employerSponsoredActivityTrailer;
	
	private Integer validTotalAmounts;
	private Integer errorRecycleTotalAmounts;
	
	private boolean rejectWholeFile;
	
	private boolean INProcessState;
	
	private boolean postProcessState;
	
	private String rejectWholeFileReason;


	public EmployerActivityContributionsFileData() {
		super();
	}
    
	

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	
	

	public String getGroupNo() {
		return groupNo;
	}



	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}



	public String getSourceActivityID() {
		return sourceActivityID;
	}



	public void setSourceActivityID(String sourceActivityID) {
		this.sourceActivityID = sourceActivityID;
	}



	public String getSourceSystemID() {
		return sourceSystemID;
	}



	public void setSourceSystemID(String sourceSystemID) {
		this.sourceSystemID = sourceSystemID;
	}



	public Collection<EmployerSponsoredActivity> getValidMemberActivities() {
		return validMemberActivities;
	}



	public void setValidMemberActivities(
			Collection<EmployerSponsoredActivity> validMemberActivities) {
		this.validMemberActivities = validMemberActivities;
	}

	
	

	public Collection<EmployerSponsoredActivity> getFatalErrorMemberActivities() {
		return fatalErrorMemberActivities;
	}



	public void setFatalErrorMemberActivities(
			Collection<EmployerSponsoredActivity> fatalErrorMemberActivities) {
		this.fatalErrorMemberActivities = fatalErrorMemberActivities;
	}

	

	public Collection<EmployerSponsoredActivity> getErrorRecycleMemberActivities() {
		return errorRecycleMemberActivities;
	}



	public void setErrorRecycleMemberActivities(
			Collection<EmployerSponsoredActivity> errorRecycleMemberActivities) {
		this.errorRecycleMemberActivities = errorRecycleMemberActivities;
	}



	public String getInsertUserId() {
		return insertUserId;
	}

	public void setInsertUserId(String insertUserId) {
		this.insertUserId = insertUserId;
	}

	

	public Collection<EmployerSponsoredActivity> getEmployerSponsoredActivitiesInput() {
		return employerSponsoredActivitiesInput;
	}



	public void setEmployerSponsoredActivitiesInput(
			Collection<EmployerSponsoredActivity> employerSponsoredActivitiesInput) {
		this.employerSponsoredActivitiesInput = employerSponsoredActivitiesInput;
	}



	// custom methods
	
	public int getValidMemberActivityCount() {
		return (validMemberActivities != null) ? validMemberActivities.size() : 0;
	}
	
	public int getErrorRecycleMemberActivityCount() {
		return (errorRecycleMemberActivities != null) ? errorRecycleMemberActivities.size() : 0;
	}
	

	public int getPreviousYearActivitiesOverriddenMemberActivityCount() {
		return (previousYearActivitiesOverriddenMemberActivities != null) ? previousYearActivitiesOverriddenMemberActivities.size() : 0;
	}
	
	public int getFatalErrorMemberActivityCount() {
		return (fatalErrorMemberActivities != null) ? fatalErrorMemberActivities.size() : 0;
	}
	
	
	public int getTotalNumberOfMemberActivityLines() {
		//subtract 1 from total that accounts for trailer record.
		return (employerSponsoredActivitiesInput != null) ? employerSponsoredActivitiesInput.size() - 1 : 0;
		
	}



	public EmployerSponsoredActivityTrailer getEmployerSponsoredActivityTrailer() {
		return employerSponsoredActivityTrailer;
	}



	public void setEmployerSponsoredActivityTrailer(
			EmployerSponsoredActivityTrailer employerSponsoredActivityTrailer) {
		this.employerSponsoredActivityTrailer = employerSponsoredActivityTrailer;
	}



	public Integer getValidTotalAmounts() {
		return validTotalAmounts;
	}



	public void setValidTotalAmounts(Integer validTotalAmounts) {
		this.validTotalAmounts = validTotalAmounts;
	}


	public Integer getErrorRecycleTotalAmounts() {
		return errorRecycleTotalAmounts;
	}



	public void setErrorRecycleTotalAmounts(Integer errorRecycleTotalAmounts) {
		this.errorRecycleTotalAmounts = errorRecycleTotalAmounts;
	}
	
	



	public Collection<EmployerSponsoredActivity> getPreviousYearActivitiesOverriddenMemberActivities() {
		return previousYearActivitiesOverriddenMemberActivities;
	}



	public void setPreviousYearActivitiesOverriddenMemberActivities(
			Collection<EmployerSponsoredActivity> previousYearActivitiesOverriddenMemberActivities) {
		this.previousYearActivitiesOverriddenMemberActivities = previousYearActivitiesOverriddenMemberActivities;
	}

	

	public boolean isINProcessState() {
		return INProcessState;
	}



	public void setINProcessState(boolean iNProcessState) {
		INProcessState = iNProcessState;
	}



	public boolean isPostProcessState() {
		return postProcessState;
	}



	public void setPostProcessState(boolean postProcessState) {
		this.postProcessState = postProcessState;
	}



	public boolean isRejectWholeFile() {
		return rejectWholeFile;
	}



	public void setRejectWholeFile(boolean rejectWholeFile) {
		this.rejectWholeFile = rejectWholeFile;
	}

	

	public String getRejectWholeFileReason() {
		return rejectWholeFileReason;
	}



	public void setRejectWholeFileReason(String rejectWholeFileReason) {
		this.rejectWholeFileReason = rejectWholeFileReason;
	}
	
	
	
}

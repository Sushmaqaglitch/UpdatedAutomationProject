package com.healthpartners.service.imfs.factory;

import org.springframework.stereotype.Component;

/**
 * This class allows to load given implemetation of
 * javax.xml.transform.TransformerFactory use - find(implClassName)
 * 
 * @author mxthoutam
 * 
 * This class serves TransformerFactory limitation and loads any implementation
 * class of javax.xml.transform.TransformerFactory. Using find(implClass) ex:
 * SAXON -> net.sf.saxon.TransformerFactoryImpl
 * 
 * TransformerFactory limitation : Obtain a new instance of a
 * TransformerFactory. This static method creates a new factory instance This
 * method uses the following ordered lookup procedure to determine the
 * TransformerFactory implementation class to load:
 * 
 * 1.Use the javax.xml.transform.TransformerFactory system property. 2.Use the
 * properties file "lib/jaxp.properties" in the JRE directory. This
 * configuration file is in standard java.util.Properties format and contains
 * the fully qualified name of the implementation class with the key being the
 * system property defined above. 3.Use the Services API (as detailed in the JAR
 * specification), if available, to determine the classname. The Services API
 * will look for a classname in the file
 * META-INF/services/javax.xml.transform.TransformerFactory in jars available to
 * the runtime. 4.Platform default TransformerFactory instance.
 * 
 * Once an application has obtained a reference to a TransformerFactory it can
 * use the factory to configure and obtain parser instances.
 */
@Component
public class BPMTransformerFactoryFinder {

	private static boolean debug = true;

	private static void dPrint(String msg) {
		if (debug) {
			System.out.println("JAXP: " + msg);
		}
	}

	/**
	 * Create an instance of a class using the specified ClassLoader and
	 * optionally fall back to the current ClassLoader if not found.
	 * 
	 * @param className
	 *            Name of the concrete class corresponding to the service
	 *            provider
	 * 
	 * @param cl
	 *            ClassLoader to use to load the class, null means to use the
	 *            bootstrap ClassLoader
	 * 
	 * @param doFallback
	 *            true if the current ClassLoader should be tried as a fallback
	 *            if the class is not found using cl
	 */
	private static Object newInstance(String className, ClassLoader cl,
			boolean doFallback) throws ConfigurationError {
		// assert(className != null);

		try {
			Class providerClass;
			if (cl == null) {
				// If classloader is null Use the bootstrap ClassLoader.
				// Thus Class.forName(String) will use the current
				// ClassLoader which will be the bootstrap ClassLoader.
				providerClass = Class.forName(className);
			} else {
				try {
					providerClass = cl.loadClass(className);
				} catch (ClassNotFoundException x) {
					if (doFallback) {
						// Fall back to current classloader
						cl = BPMTransformerFactoryFinder.class.getClassLoader();
						providerClass = cl.loadClass(className);
					} else {
						throw x;
					}
				}
			}

			Object instance = providerClass.newInstance();
			dPrint("created new instance of " + providerClass
					+ " using ClassLoader: " + cl);
			return instance;
		} catch (ClassNotFoundException x) {
			throw new ConfigurationError(
					"Provider " + className + " not found", x);
		} catch (Exception x) {
			throw new ConfigurationError("Provider " + className
					+ " could not be instantiated: " + x, x);
		}
	}

	/**
	 * Finds the implementation Class object in the specified order. Main entry
	 * point.
	 * 
	 * @return Class object of factory, never null
	 * 
	 * @param factoryId
	 *            Name of the factory to find, same as a property name
	 * @param fallbackClassName
	 *            Implementation class name, if nothing else is found. Use null
	 *            to mean no fallback.
	 * 
	 * Package private so this code can be shared.
	 */
	public static Object find(String fallbackClassName)
			throws ConfigurationError {

		// Figure out which ClassLoader to use for loading the provider
		// class. If there is a Context ClassLoader then use it.
		ClassLoader classLoader = null;
		try {
			classLoader = Thread.currentThread().getContextClassLoader();
		} catch (SecurityException ex) {
		}

		if (classLoader == null) {
			classLoader = BPMTransformerFactoryFinder.class.getClassLoader();
		}

		return newInstance(fallbackClassName, classLoader, true);
	}

	static class ConfigurationError extends Error {
		static final long serialVersionUID = 0L;

		private Exception exception;

		/**
		 * Construct a new instance with the specified detail string and
		 * exception.
		 */
		ConfigurationError(String msg, Exception x) {
			super(msg);
			this.exception = x;
		}

		Exception getException() {
			return exception;
		}
	}

}

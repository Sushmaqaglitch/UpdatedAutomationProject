
package com.healthpartners.service.imfs.factory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.CDHPFulfillmentTrackingReport;
import com.healthpartners.service.imfs.dto.ContractContributionTO;
import com.healthpartners.service.imfs.dto.DetailEmployerSponsoredActivity;
import com.healthpartners.service.imfs.dto.DetailEmployerSponsoredContractSummary;
import com.healthpartners.service.imfs.dto.DetailHRA;
import com.healthpartners.service.imfs.dto.DetailHSA;
import com.healthpartners.service.imfs.dto.HeaderEmployerSponsoredActivityDetail;
import com.healthpartners.service.imfs.dto.HeaderHRA;
import com.healthpartners.service.imfs.dto.HeaderHSA;
import com.healthpartners.service.imfs.dto.PersonProgramActivityIncentiveStatus;
import com.healthpartners.service.imfs.dto.TrailerEmployerSponsoredActivity;
import com.healthpartners.service.imfs.dto.TrailerEmployerSponsoredContractSummary;
import com.healthpartners.service.imfs.dto.TrailerHRA;
import com.healthpartners.service.imfs.dto.TrailerHSA;
import org.springframework.stereotype.Component;

@Component
public class OutboundEmployerSponsoredReportFactory {

	
	public static DetailEmployerSponsoredActivity detailActivityMapper(PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus, String fileCreateDate) {
		
		String activityStatusIncentiveDate = BPMUtils.formatDateMMddyyyy(lPersonProgramActivityIncentiveStatus.getActivityStatusIncentiveDate());
		
		String incentedDate = BPMUtils.formatDateMMddyyyy(lPersonProgramActivityIncentiveStatus.getInsertDate());
		
		DetailEmployerSponsoredActivity lDetailEmployerSponsoredActivity = new DetailEmployerSponsoredActivity();
		lDetailEmployerSponsoredActivity.setSourceActivityID(lPersonProgramActivityIncentiveStatus.getSourceActivityID());
		lDetailEmployerSponsoredActivity.setActivityName(lPersonProgramActivityIncentiveStatus.getActivityName());
		lDetailEmployerSponsoredActivity.setContractNo(lPersonProgramActivityIncentiveStatus.getContractNo());
		lDetailEmployerSponsoredActivity.setMemberNo(lPersonProgramActivityIncentiveStatus.getMemberNo());
		lDetailEmployerSponsoredActivity.setContributionAmt(String.valueOf(lPersonProgramActivityIncentiveStatus.getContributionAmt()));
		lDetailEmployerSponsoredActivity.setContributionDate(activityStatusIncentiveDate);
		lDetailEmployerSponsoredActivity.setIncentedDate(incentedDate);
		lDetailEmployerSponsoredActivity.setFirstName(lPersonProgramActivityIncentiveStatus.getFirstName());
		lDetailEmployerSponsoredActivity.setLastName(lPersonProgramActivityIncentiveStatus.getLastName());
		lDetailEmployerSponsoredActivity.setGroupNo(lPersonProgramActivityIncentiveStatus.getGroupNo());
		lDetailEmployerSponsoredActivity.setSiteNo(lPersonProgramActivityIncentiveStatus.getSiteNo());
		lDetailEmployerSponsoredActivity.setProductType(lPersonProgramActivityIncentiveStatus.getProductType());
		lDetailEmployerSponsoredActivity.setSourceActivityID(lPersonProgramActivityIncentiveStatus.getSourceActivityID());
		
		return lDetailEmployerSponsoredActivity;
		
	}
	
	
	public static TrailerEmployerSponsoredActivity trailerActivityMapper(int recordCount, int totalContributions) {
		TrailerEmployerSponsoredActivity lTrailerEmployerSponsoredActivity = new TrailerEmployerSponsoredActivity();
		lTrailerEmployerSponsoredActivity.setTotalRecords(Integer.toString(recordCount));
		lTrailerEmployerSponsoredActivity.setTotalContributions(Integer.toString(totalContributions));
		
		return lTrailerEmployerSponsoredActivity;
	}
	
	
	
	public static TrailerEmployerSponsoredContractSummary trailerContractSummaryMapper(int recordCount, int totalContributions) {
		TrailerEmployerSponsoredContractSummary lTrailerEmployerSponsoredContractSummary = new TrailerEmployerSponsoredContractSummary();
		lTrailerEmployerSponsoredContractSummary.setTotalRecords(Integer.toString(recordCount));
		lTrailerEmployerSponsoredContractSummary.setTotalContributions(Integer.toString(totalContributions));
		
		return lTrailerEmployerSponsoredContractSummary;
	}
	
	/*
	 * Purpose of this method is to determine if there exists multiple persons completing activities on the same day for the same
	 * contract.  If this exists, the contribution amounts must be combined to the contract level.  Sort order is critical in order
	 * for this to work.  The SQL returns the result set of those persons acheiving contributions must be ordered by group and contract no. 
	 * 
	 */
	public Collection<DetailEmployerSponsoredContractSummary> detailContractSummaryMapperForRollingUpToContract(Collection<PersonProgramActivityIncentiveStatus> personProgramActivityIncentiveStatuses) {
		
		HashMap combineContributionAmtByContract = new HashMap();
		
		ArrayList<DetailEmployerSponsoredContractSummary> contractContributionsConsideredForCombining = new ArrayList<DetailEmployerSponsoredContractSummary>();
	
		
		PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus = null;
		DetailEmployerSponsoredContractSummary lDetailEmployerSponsoredContractSummary = null;
		
		Integer contractNo = null;
		Integer contributionAmtTotal = 0;
		Integer memberCount = 0;
		Iterator<PersonProgramActivityIncentiveStatus> iterPass1 = (Iterator<PersonProgramActivityIncentiveStatus>) personProgramActivityIncentiveStatuses.iterator();
		
		//Pass 1: Determine if persons for the same contract completed activities and achieved a contribution
		while (iterPass1.hasNext()) {
			lPersonProgramActivityIncentiveStatus = (PersonProgramActivityIncentiveStatus) iterPass1.next();
			contractNo = Integer.valueOf(lPersonProgramActivityIncentiveStatus.getContractNo());
			Integer contributionAmt = lPersonProgramActivityIncentiveStatus.getContributionAmt();
			//Set aside contribution amounts in hash table by contract.  If more than one contribution achieved under the same contract,
			//then combine.
			if (combineContributionAmtByContract.containsKey(contractNo)) {
				// This hash table identifies the contracts that have more than one person achieving a contribution.
				ContractContributionTO combineContractContribution = (ContractContributionTO)combineContributionAmtByContract.get(contractNo);
				contributionAmtTotal = contributionAmt + combineContractContribution.getContributionAmountTotal();
				memberCount++;
				ContractContributionTO lContractContributionTO = mapperContractContribution(contractNo, contributionAmtTotal, memberCount);
				combineContributionAmtByContract.put(contractNo, lContractContributionTO);
				
			} else {
				memberCount = 1;
				ContractContributionTO lContractContributionTO = mapperContractContribution(contractNo, contributionAmt, memberCount);
				//break in contract number.  Set aside contribution amount in seperate hashtable.
				combineContributionAmtByContract.put(contractNo, lContractContributionTO);
				lDetailEmployerSponsoredContractSummary = buildDetailEmployerSponsoredContractSummary(lPersonProgramActivityIncentiveStatus);
				contractContributionsConsideredForCombining.add(lDetailEmployerSponsoredContractSummary);
			}
		}
		
		
		//Iterate through the hraParticipantCompletions collections and pickup contribution amounts from hash table.  If multiple more than one contribution
		//achieved on the same day for the same contract, then the sum of the contribution amounts will be picked up for the one member left in the collection.
		Iterator<DetailEmployerSponsoredContractSummary> iterPass2 = (Iterator<DetailEmployerSponsoredContractSummary>) contractContributionsConsideredForCombining.iterator();
		while (iterPass2.hasNext()) {
			lDetailEmployerSponsoredContractSummary = (DetailEmployerSponsoredContractSummary) iterPass2.next();
			contractNo = Integer.valueOf(lDetailEmployerSponsoredContractSummary.getContractNo());
			//looks for more than one contract having multiple persons achieving contributions on the same day.
			if (combineContributionAmtByContract.containsKey(contractNo)) {
				ContractContributionTO lContractContributionTO = (ContractContributionTO)combineContributionAmtByContract.get(contractNo);
				lDetailEmployerSponsoredContractSummary.setSumOfContributionAmount(lContractContributionTO.getContributionAmountTotal());
				lDetailEmployerSponsoredContractSummary.setMemberCount(lContractContributionTO.getMemberCount());
			}
		}
		
		
		return contractContributionsConsideredForCombining;
	
	}
	
	private ContractContributionTO mapperContractContribution(Integer contractNo, Integer contributionAmtTotal, Integer memberCount) {
		
		ContractContributionTO lContractContributionTO = new ContractContributionTO();
		lContractContributionTO.setContractNo(contractNo);
		lContractContributionTO.setMemberCount(memberCount);
		lContractContributionTO.setContributionAmountTotal(contributionAmtTotal);
		
		return lContractContributionTO;
	}
	
	private ContractContributionTO mapperContractNContributionDateToContribution(Integer contractNo, java.sql.Date contributionDate, Integer contributionAmtTotal) {
		
		ContractContributionTO lContractContributionTO = new ContractContributionTO();
		lContractContributionTO.setContractNo(contractNo);
		lContractContributionTO.setContributionDate(contributionDate);
		lContractContributionTO.setContributionAmountTotal(contributionAmtTotal);
		
		return lContractContributionTO;
	}
	
	private DetailEmployerSponsoredContractSummary buildDetailEmployerSponsoredContractSummary(PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus) {
		
		DetailEmployerSponsoredContractSummary lDetailEmployerSponsoredContractSummary = new DetailEmployerSponsoredContractSummary();
		lDetailEmployerSponsoredContractSummary.setContractNo(lPersonProgramActivityIncentiveStatus.getContractNo());
		lDetailEmployerSponsoredContractSummary.setGroupNo(lPersonProgramActivityIncentiveStatus.getGroupNo());
		lDetailEmployerSponsoredContractSummary.setSiteNo(lPersonProgramActivityIncentiveStatus.getSiteNo());
		lDetailEmployerSponsoredContractSummary.setSumOfContributionAmount(lPersonProgramActivityIncentiveStatus.getContributionAmt());
		
		return lDetailEmployerSponsoredContractSummary;
	}
	
}

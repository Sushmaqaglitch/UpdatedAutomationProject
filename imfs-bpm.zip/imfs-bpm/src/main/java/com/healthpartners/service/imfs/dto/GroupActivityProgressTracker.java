package com.healthpartners.service.imfs.dto;



public class GroupActivityProgressTracker
{	
	static final long serialVersionUID = 0L;
	
	private Integer uid;
	private Integer programID;
	private String groupNo;
	private String groupName;
	private java.sql.Date  batchDate;
	private Integer preprocessCount;
	private Integer postprocessCount;
	private Integer preprocessAmount;
	private Integer postprocessAmount;
	private Integer trackingStatusID;
	private String  trackingStatusCode;
	private String  inputFileName;
	private String  trackingReason;
	
	
	
        
    public GroupActivityProgressTracker()
    {
    	super();
    }

    


	public Integer getUid() {
		return uid;
	}




	public void setUid(Integer uid) {
		this.uid = uid;
	}




	public Integer getProgramID() {
		return programID;
	}

	


	public void setProgramID(Integer programID) {
		this.programID = programID;
	}


	

	public String getGroupNo() {
		return groupNo;
	}




	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}




	public String getGroupName() {
		return groupName;
	}




	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}




	public java.sql.Date getBatchDate() {
		return batchDate;
	}




	public void setBatchDate(java.sql.Date batchDate) {
		this.batchDate = batchDate;
	}


	public Integer getPreprocessCount() {
		return preprocessCount;
	}




	public void setPreprocessCount(Integer preprocessCount) {
		this.preprocessCount = preprocessCount;
	}




	public Integer getPostprocessCount() {
		return postprocessCount;
	}




	public void setPostprocessCount(Integer postprocessCount) {
		this.postprocessCount = postprocessCount;
	}




	public Integer getPreprocessAmount() {
		return preprocessAmount;
	}




	public void setPreprocessAmount(Integer preprocessAmount) {
		this.preprocessAmount = preprocessAmount;
	}




	public Integer getPostprocessAmount() {
		return postprocessAmount;
	}




	public void setPostprocessAmount(Integer postprocessAmount) {
		this.postprocessAmount = postprocessAmount;
	}




	public Integer getTrackingStatusID() {
		return trackingStatusID;
	}




	public void setTrackingStatusID(Integer trackingStatusID) {
		this.trackingStatusID = trackingStatusID;
	}



	public String getTrackingStatusCode() {
		return trackingStatusCode;
	}




	public void setTrackingStatusCode(String trackingStatusCode) {
		this.trackingStatusCode = trackingStatusCode;
	}




	public String getInputFileName() {
		return inputFileName;
	}




	public void setInputFileName(String inputFileName) {
		this.inputFileName = inputFileName;
	}




	public String getTrackingReason() {
		return trackingReason;
	}




	public void setTrackingReason(String trackingReason) {
		this.trackingReason = trackingReason;
	}

    

	
    
	
}

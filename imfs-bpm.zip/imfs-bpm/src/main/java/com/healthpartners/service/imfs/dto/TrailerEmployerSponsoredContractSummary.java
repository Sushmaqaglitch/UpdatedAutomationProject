package com.healthpartners.service.imfs.dto;


public class TrailerEmployerSponsoredContractSummary
{	
	static final long serialVersionUID = 0L;

    public TrailerEmployerSponsoredContractSummary()
    {
    	super();
    }

    private String totalRecords;    
    private String totalContributions;

	public String getTotalRecords() {
		return totalRecords;
	}
	public void setTotalRecords(String totalRecords) {
		this.totalRecords = totalRecords;
	}
	public String getTotalContributions() {
		return totalContributions;
	}
	public void setTotalContributions(String totalContributions) {
		this.totalContributions = totalContributions;
	}

	
}



package com.healthpartners.service.imfs.writeascii;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;

import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.DetailEmployerSponsoredActivity;
import com.healthpartners.service.imfs.dto.DetailEmployerSponsoredContractSummary;
import com.healthpartners.service.imfs.dto.TrailerEmployerSponsoredActivity;
import com.healthpartners.service.imfs.dto.TrailerEmployerSponsoredContractSummary;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.DetailEmployerSponsoredActivity;
import com.healthpartners.service.imfs.dto.DetailEmployerSponsoredContractSummary;
import com.healthpartners.service.imfs.dto.TrailerEmployerSponsoredActivity;
import com.healthpartners.service.imfs.dto.TrailerEmployerSponsoredContractSummary;
 
public class EmployerSponsoredReportFileFormats
{

	protected final Log logger = LogFactory.getLog(getClass());

   
   private FileWriter writer;
   
   
   private Collection<DetailEmployerSponsoredActivity> detailEmployerSponsoredActivitys;
   private Collection<DetailEmployerSponsoredContractSummary> detailEmployerSponsoredContractSummarys;
   
   private TrailerEmployerSponsoredActivity trailerEmployerSponsoredActivity;
   private TrailerEmployerSponsoredContractSummary trailerEmployerSponsoredContractSummary;
   
   private int recsWrittenActivity = 0;
   private int recsWrittenContractSummary = 0;
   
   
   
  
   public void processFileEmployerSponsoredActivityDetail() {
	   Iterator iter = detailEmployerSponsoredActivitys.iterator();
		
	   try {
			writeEmployerSponsoredActivityHeader();
			Integer rowCount = 1;
			while (iter.hasNext()) {
				Object transObject = iter.next();
				
				DetailEmployerSponsoredActivity lDetailEmployerSponsoredActivity = (DetailEmployerSponsoredActivity) transObject;
				writeEmployerSponsoredActivityDetail(lDetailEmployerSponsoredActivity, String.valueOf(rowCount));
				rowCount++;
			}
			
			writeEmployerSponsoredActivityTrailer(trailerEmployerSponsoredActivity);
			
	  } catch(IOException e)
		{
		     e.printStackTrace();
	    } 
   }
   
   public void processFileEmployerSponsoredContractSummary() {
	   Iterator iter = detailEmployerSponsoredContractSummarys.iterator();
		
	   try {
			writeEmployerSponsoredContractSummaryHeader();
			Integer rowCount = 1;
			while (iter.hasNext()) {
				Object transObject = iter.next();
				
				DetailEmployerSponsoredContractSummary lDetailEmployerSponsoredContractSummary = (DetailEmployerSponsoredContractSummary) transObject;
				writeEmployerSponsoredContractSummary(lDetailEmployerSponsoredContractSummary, String.valueOf(rowCount));
				rowCount++;
			}
			
			writeEmployerSponsoredContractSummaryTrailer(trailerEmployerSponsoredContractSummary);
			
	  } catch(IOException e)
		{
		     e.printStackTrace();
	    } 
   }
   
   
 private void writeEmployerSponsoredActivityHeader() throws IOException {
	 String delimiter = ",";
	
	 writer.append(BPMUtils.rightPadString("No", 3));
	 writer.append(delimiter);
	 
	 writer.append(BPMUtils.rightPadString("Incented Date", 14));
	 writer.append(delimiter);
	 
	 writer.append(BPMUtils.rightPadString("Group No", 10));
	 writer.append(delimiter);
	 
	 writer.append(BPMUtils.rightPadString("Site No", 8));
	 writer.append(delimiter);
	 
	 writer.append(BPMUtils.rightPadString("Member No", 10));
	 writer.append(delimiter);
	 
	 writer.append(BPMUtils.rightPadString("Last Name", 20));
	 writer.append(delimiter);
	
	 writer.append(BPMUtils.rightPadString("First Name", 20));
	 writer.append(delimiter);
	 
	 writer.append(BPMUtils.rightPadString("Contract No", 12));
	 writer.append(delimiter);
	 
	 //writer.append(BPMUtils.rightPadString("Activity ID", 12));
	 //writer.append(delimiter);
	 
	 writer.append(BPMUtils.rightPadString("Activity Name", 25));
	 writer.append(delimiter);
	
	 writer.append(BPMUtils.rightPadString("Contribution Amount", 20));
	 writer.append(delimiter);
	 
	 writer.append(BPMUtils.rightPadString("Contribution Date", 20));
	 writer.append(delimiter);
	 
	 writer.append(BPMUtils.rightPadString("Product Type", 20));
	 
	 writer.append('\n');
   }
 
 private void writeEmployerSponsoredContractSummaryHeader() throws IOException {
	 String delimiter = ",";
	
	 writer.append(BPMUtils.rightPadString("No", 3));
	 writer.append(delimiter);
	 
	 writer.append(BPMUtils.rightPadString("Group No", 14));
	 writer.append(delimiter);
	 
	 writer.append(BPMUtils.rightPadString("Site No", 8));
	 writer.append(delimiter);
	 
	 writer.append(BPMUtils.rightPadString("Contract No", 12));
	 writer.append(delimiter);
	 
	 writer.append(BPMUtils.rightPadString("SumOfContribution Amount", 20));
	 
	 writer.append('\n');
   }
 
 private void writeEmployerSponsoredActivityDetail(DetailEmployerSponsoredActivity lDetailEmployerSponsoredActivity, String rowCount) throws IOException {
	 String delimiter = ",";
	 
	 writer.append(BPMUtils.rightPadString(rowCount, 3));
	 writer.append(delimiter);
	 
	 if (lDetailEmployerSponsoredActivity.getIncentedDate() != null) { 
		 writer.append(BPMUtils.rightPadString(lDetailEmployerSponsoredActivity.getIncentedDate(), 14));
	 } else {
		 writer.append(BPMUtils.rightPadString("NULL", 14));
	 }
	 writer.append(delimiter);
	 
	 if (lDetailEmployerSponsoredActivity.getGroupNo() != null) {
		 writer.append(BPMUtils.rightPadString(lDetailEmployerSponsoredActivity.getGroupNo(), 10));
	 } else {
		 writer.append(BPMUtils.rightPadString("NULL", 10));
	 }
	 writer.append(delimiter);
	 
	 if (lDetailEmployerSponsoredActivity.getSiteNo() != null) {
		 writer.append(BPMUtils.rightPadString(lDetailEmployerSponsoredActivity.getSiteNo(), 8));
	 } else {
		 writer.append(BPMUtils.rightPadString("NULL", 8));
	 }
	 writer.append(delimiter);
	 
	 if (lDetailEmployerSponsoredActivity.getMemberNo() != null) {
		 writer.append(BPMUtils.rightPadString(lDetailEmployerSponsoredActivity.getMemberNo(), 10));
	 } else {
		 writer.append(BPMUtils.rightPadString("NULL", 10));
	 }
	 
	 writer.append(delimiter);
	
	 if (lDetailEmployerSponsoredActivity.getLastName() != null) {
		 writer.append(BPMUtils.rightPadString(lDetailEmployerSponsoredActivity.getLastName(), 20));
	 } else {
		 writer.append(BPMUtils.rightPadString("NULL", 20));
	 }
	 writer.append(delimiter);
	 
	 writer.append(BPMUtils.rightPadString(lDetailEmployerSponsoredActivity.getFirstName(), 20));
	 writer.append(delimiter);
	 
	 if (lDetailEmployerSponsoredActivity.getContractNo() != null) {
		 writer.append(BPMUtils.rightPadString(lDetailEmployerSponsoredActivity.getContractNo(), 12));
	 } else {
		 writer.append(BPMUtils.rightPadString("NULL", 12));
	 }
	 writer.append(delimiter);
	 
	/* if (lDetailEmployerSponsoredActivity.getSourceActivityID() != null) {
		 writer.append(BPMUtils.rightPadString(lDetailEmployerSponsoredActivity.getSourceActivityID(), 12));
	 } else {
		 writer.append(BPMUtils.rightPadString("NULL", 12));
	 }
	 writer.append(delimiter);*/
	 
	 if (lDetailEmployerSponsoredActivity.getActivityName() != null) {
		 writer.append(BPMUtils.rightPadString(lDetailEmployerSponsoredActivity.getActivityName(), 25));
	 } else {
		 writer.append(BPMUtils.rightPadString("NULL", 100)); 
	 }
	 writer.append(delimiter);
	 
	 if (lDetailEmployerSponsoredActivity.getContributionAmt() != null) {
		 writer.append(BPMUtils.rightPadString(lDetailEmployerSponsoredActivity.getContributionAmt(), 20));
	 } else {
		 writer.append(BPMUtils.rightPadString("NULL", 20)); 
	 }
	 writer.append(delimiter);
	 
	 if (lDetailEmployerSponsoredActivity.getContributionDate() != null) {
		 writer.append(BPMUtils.rightPadString(lDetailEmployerSponsoredActivity.getContributionDate(), 20));
	 } else {
		 writer.append(BPMUtils.rightPadString("NULL", 20)); 
	 }
	 writer.append(delimiter);
	 
	 if (lDetailEmployerSponsoredActivity.getProductType() != null) {
		 writer.append(BPMUtils.rightPadString(lDetailEmployerSponsoredActivity.getProductType(), 20));
	 } else {
		 writer.append(BPMUtils.rightPadString("NULL", 20));  
	 }
	 
	 writer.append('\n');
	 
	 recsWrittenActivity++;
	 
   }
  

 private void writeEmployerSponsoredContractSummary(DetailEmployerSponsoredContractSummary lDetailEmployerSponsoredContractSummary, String rowCount) throws IOException {
	 String delimiter = ",";
	 
	 writer.append(BPMUtils.rightPadString(rowCount, 3));
	 writer.append(delimiter);
	 
	 if (lDetailEmployerSponsoredContractSummary.getGroupNo() != null) {
		 writer.append(BPMUtils.rightPadString(lDetailEmployerSponsoredContractSummary.getGroupNo(), 14));
	 } else {
		 writer.append(BPMUtils.rightPadString("NULL", 14));
	 }
	 writer.append(delimiter);
	 
	 if (lDetailEmployerSponsoredContractSummary.getSiteNo() != null) {
		 writer.append(BPMUtils.rightPadString(lDetailEmployerSponsoredContractSummary.getSiteNo(), 8));
	 } else {
		 writer.append(BPMUtils.rightPadString("NULL", 8));
	 }
	 writer.append(delimiter);
	 
	 if (lDetailEmployerSponsoredContractSummary.getContractNo() != null) {
		 writer.append(BPMUtils.rightPadString(lDetailEmployerSponsoredContractSummary.getContractNo(), 12));
	 } else {
		 writer.append(BPMUtils.rightPadString("NULL", 12));
	 }
	 writer.append(delimiter);
	 
	 if (lDetailEmployerSponsoredContractSummary.getSumOfContributionAmount() != null) {
		 writer.append(BPMUtils.rightPadString(String.valueOf(lDetailEmployerSponsoredContractSummary.getSumOfContributionAmount()), 20));
	 } else {
		 writer.append(BPMUtils.rightPadString("0", 20));
	 }
	 
	 writer.append('\n');
	 
	 recsWrittenContractSummary++;
	 
   }
 
 
 
 private void writeEmployerSponsoredActivityTrailer(TrailerEmployerSponsoredActivity trailerEmployerSponsoredActivity) throws IOException {
	 String delimiter = ",";
	 String space = " ";
	 writer.append(BPMUtils.rightPadString(space, 5));
	 writer.append(BPMUtils.rightPadString("Total: ", 10));
	 writer.append(BPMUtils.rightPadString(trailerEmployerSponsoredActivity.getTotalRecords(), 10));
	 writer.append(delimiter);
	 writer.append(delimiter);
	 writer.append(delimiter);
	 writer.append(delimiter);
	 writer.append(delimiter);
	 writer.append(delimiter);
	 writer.append(delimiter);
	 writer.append(delimiter);
	 writer.append(BPMUtils.rightPadString("Total Contributions:", 20));
	 writer.append(delimiter);
	 writer.append(BPMUtils.rightPadString(trailerEmployerSponsoredActivity.getTotalContributions(), 10));
	 
	 writer.append('\n');
	 
	 recsWrittenActivity++;
	 
   }
 
  private void writeEmployerSponsoredContractSummaryTrailer(TrailerEmployerSponsoredContractSummary trailerEmployerSponsoredContractSummary) throws IOException {
	 
	 String delimiter = ",";
	 String space = " ";
	 writer.append(BPMUtils.rightPadString(space, 5));
	 writer.append(BPMUtils.rightPadString("Total: ", 10));
	 writer.append(BPMUtils.rightPadString(trailerEmployerSponsoredContractSummary.getTotalRecords(), 10));
	 writer.append(delimiter);
	 writer.append(delimiter);
	 writer.append(delimiter);
	 writer.append(BPMUtils.rightPadString("Total Contributions:", 20));
	 writer.append(delimiter);
	 writer.append(BPMUtils.rightPadString(trailerEmployerSponsoredContractSummary.getTotalContributions(), 10));
	 
	 writer.append('\n');
	 
	 recsWrittenContractSummary++;
	 
   }
 
 
 
 
	public void setFileWriter(FileWriter writer) {
		this.writer = writer;
	}

	public void setDetailEmployerSponsoredActivitys(
			Collection<DetailEmployerSponsoredActivity> detailEmployerSponsoredActivitys) {
		this.detailEmployerSponsoredActivitys = detailEmployerSponsoredActivitys;
	}
	

	public void setDetailEmployerSponsoredContractSummarys(
			Collection<DetailEmployerSponsoredContractSummary> detailEmployerSponsoredContractSummarys) {
		this.detailEmployerSponsoredContractSummarys = detailEmployerSponsoredContractSummarys;
	}
	
	

	public void setTrailerEmployerSponsoredActivity(
			TrailerEmployerSponsoredActivity trailerEmployerSponsoredActivity) {
		this.trailerEmployerSponsoredActivity = trailerEmployerSponsoredActivity;
	}

	public void setTrailerEmployerSponsoredContractSummary(
			TrailerEmployerSponsoredContractSummary trailerEmployerSponsoredContractSummary) {
		this.trailerEmployerSponsoredContractSummary = trailerEmployerSponsoredContractSummary;
	}

	public int getRecsWrittenActivity() {
		return recsWrittenActivity;
	}

	public void setRecsWrittenActivity(int recsWrittenActivity) {
		this.recsWrittenActivity = recsWrittenActivity;
	}

	public int getRecsWrittenContractSummary() {
		return recsWrittenContractSummary;
	}

	public void setRecsWrittenContractSummary(int recsWrittenContractSummary) {
		this.recsWrittenContractSummary = recsWrittenContractSummary;
	}
	 
}
package com.healthpartners.service.imfs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;

import com.healthpartners.service.imfs.dto.ACTVBatchLog;
import com.healthpartners.service.imfs.dto.CDHPBatchLog;
import com.healthpartners.service.imfs.dto.RewardBatchLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.healthpartners.service.imfs.exception.BPMException;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;

/**
 * 
 * @author jxbourbour
 *
 */
@Configuration
public class BatchLogDAOJdbc extends JdbcDaoSupport implements BatchLogDAO 
{
	private String selectCDHPBatchLog;
	private String selectRewardBatchLog;
	private String selectActivityBatchLog;
	private String insertCDHPBatchLog;
	private String insertRewardBatchLog;
	private String insertActivityBatchLog;

	@Autowired
	private DataFieldMaxValueIncrementer cdhpLogIdIncrementer;
	@Autowired
	private DataFieldMaxValueIncrementer rewardLogIdIncrementer;
	@Autowired
	private DataFieldMaxValueIncrementer actvLogIdIncrementer;

	@Autowired
	DataSource bpmDataSource;


	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}



	/**
	 * 
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	public Collection<CDHPBatchLog> getCDHPBatchLog(java.sql.Date fileSentDate)
	{
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { fileSentDate };
		int types[] = new int[] { Types.DATE };
		final ArrayList<CDHPBatchLog> lCDHPBatchLogs = new ArrayList<CDHPBatchLog>();
		
		template.query(selectCDHPBatchLog, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						CDHPBatchLog lCDHPBatchLog = new CDHPBatchLog();
						
						lCDHPBatchLog.setLogID(rs.getInt("cdhp_log_id"));
						lCDHPBatchLog.setBatchType(rs.getString("batch_type"));
						lCDHPBatchLog.setRecordCount(rs.getInt("record_cnt"));
						lCDHPBatchLog.setFileSent(rs.getDate("file_sent_dt"));
						lCDHPBatchLogs.add(lCDHPBatchLog);
					}
		});
		
		return lCDHPBatchLogs;
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public int insertCDHPBatchLog(CDHPBatchLog pCDHPBatchLog)
	throws DataAccessException {
		
	
			JdbcTemplate template = getJdbcTemplate();
			
			Integer cdhpLogId = cdhpLogIdIncrementer
			.nextIntValue();
			
			String batchType = pCDHPBatchLog.getBatchType();
			Integer sameDayContrMemCount = pCDHPBatchLog.getRecordCount();
			
		
		
			Object params[] = new Object[] { cdhpLogId, batchType, sameDayContrMemCount};
			int types[] = new int[] { Types.INTEGER, Types.VARCHAR, Types.INTEGER};
		
			int rowInserted = template.update(insertCDHPBatchLog, params,
					types);
		
			for(int i = 0; i < params.length; i++)
			{
			    params[i] = null;
			}
			types = null;
			
			return rowInserted;
	}

	
	/**
	 * 
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 60, rollbackFor = { BPMException.class})
	public Collection<RewardBatchLog> getRewardBatchLog(java.sql.Date fileSentDate)
	{
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { fileSentDate };
		int types[] = new int[] { Types.DATE };
		final ArrayList<RewardBatchLog> lRewardBatchLogs = new ArrayList<RewardBatchLog>();
		
		template.query(selectRewardBatchLog, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						RewardBatchLog lRewardBatchLog = new RewardBatchLog();
						
						lRewardBatchLog.setLogID(rs.getInt("cdhp_log_id"));
						lRewardBatchLog.setBatchType(rs.getString("batch_type"));
						lRewardBatchLog.setRecordCount(rs.getInt("record_cnt"));
						lRewardBatchLog.setFileSent(rs.getDate("file_sent_dt"));
						lRewardBatchLogs.add(lRewardBatchLog);
					}
		});
		
		return lRewardBatchLogs;
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	
	public int insertRewardBatchLog(RewardBatchLog pRewardBatchLog)
	throws DataAccessException {
		
	
	JdbcTemplate template = getJdbcTemplate();
	
	Integer rewardLogId = rewardLogIdIncrementer.nextIntValue();
	
	String batchType = pRewardBatchLog.getBatchType();
	Integer sameDayContrMemCount = pRewardBatchLog.getRecordCount();
	


	Object params[] = new Object[] { rewardLogId, batchType, sameDayContrMemCount};
	int types[] = new int[] { Types.INTEGER, Types.VARCHAR, Types.INTEGER};

	int rowInserted = template.update(insertRewardBatchLog, params,
			types);

	for(int i = 0; i < params.length; i++)
	{
	    params[i] = null;
	}
	types = null;
	
	return rowInserted;
}
	
	/**
	 * 
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 60, rollbackFor = { BPMException.class})
	public Collection<ACTVBatchLog> getActivityBatchLog(java.sql.Date fileSentDate)
	{
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { fileSentDate };
		int types[] = new int[] { Types.DATE };
		final ArrayList<ACTVBatchLog> lActivityBatchLogs = new ArrayList<ACTVBatchLog>();
		
		template.query(selectActivityBatchLog, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						ACTVBatchLog lACTVBatchLog = new ACTVBatchLog();
						
						lACTVBatchLog.setLogID(rs.getInt("cdhp_log_id"));
						lACTVBatchLog.setBatchType(rs.getString("batch_type"));
						lACTVBatchLog.setRecordCount(rs.getInt("record_cnt"));
						lACTVBatchLog.setFileSent(rs.getDate("file_sent_dt"));
						lActivityBatchLogs.add(lACTVBatchLog);
					}
		});
		
		return lActivityBatchLogs;
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 60, rollbackFor = { BPMException.class})
	public int insertActivityBatchLog(ACTVBatchLog pActivityBatchLog)
	throws DataAccessException {
		
	
		JdbcTemplate template = getJdbcTemplate();
		
		Integer rewardLogId = rewardLogIdIncrementer.nextIntValue();
		
		String batchType = pActivityBatchLog.getBatchType();
		Integer sameDayContrMemCount = pActivityBatchLog.getRecordCount();
		
	
	
		Object params[] = new Object[] { rewardLogId, batchType, sameDayContrMemCount};
		int types[] = new int[] { Types.INTEGER, Types.VARCHAR, Types.INTEGER};
	
		int rowInserted = template.update(insertActivityBatchLog, params,
				types);
	
		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
		
		return rowInserted;
	}
	@Transactional(timeout = 60, rollbackFor = { BPMException.class})
	public String getSelectCDHPBatchLog() {
		return selectCDHPBatchLog;
	}
	@Transactional(timeout = 60, rollbackFor = { BPMException.class})
	public void setSelectCDHPBatchLog(String selectCDHPBatchLog) {
		this.selectCDHPBatchLog = selectCDHPBatchLog;
	}
	@Transactional(timeout = 60, rollbackFor = { BPMException.class})
	public String getInsertCDHPBatchLog() {
		return insertCDHPBatchLog;
	}
	@Transactional(timeout = 60, rollbackFor = { BPMException.class})
	public void setInsertCDHPBatchLog(String insertCDHPBatchLog) {
		this.insertCDHPBatchLog = insertCDHPBatchLog;
	}

	public DataFieldMaxValueIncrementer getCdhpLogIdIncrementer() {
		return cdhpLogIdIncrementer;
	}

	public void setCdhpLogIdIncrementer(
			DataFieldMaxValueIncrementer cdhpLogIdIncrementer) {
		this.cdhpLogIdIncrementer = cdhpLogIdIncrementer;
	}

	public DataFieldMaxValueIncrementer getRewardLogIdIncrementer() {
		return rewardLogIdIncrementer;
	}

	public void setRewardLogIdIncrementer(
			DataFieldMaxValueIncrementer rewardLogIdIncrementer) {
		this.rewardLogIdIncrementer = rewardLogIdIncrementer;
	}
	
	

	public DataFieldMaxValueIncrementer getActvLogIdIncrementer() {
		return actvLogIdIncrementer;
	}

	public void setActvLogIdIncrementer(
			DataFieldMaxValueIncrementer actvLogIdIncrementer) {
		this.actvLogIdIncrementer = actvLogIdIncrementer;
	}

	public String getSelectRewardBatchLog() {
		return selectRewardBatchLog;
	}

	public void setSelectRewardBatchLog(String selectRewardBatchLog) {
		this.selectRewardBatchLog = selectRewardBatchLog;
	}

	public String getInsertRewardBatchLog() {
		return insertRewardBatchLog;
	}

	public void setInsertRewardBatchLog(String insertRewardBatchLog) {
		this.insertRewardBatchLog = insertRewardBatchLog;
	}

	public String getSelectActivityBatchLog() {
		return selectActivityBatchLog;
	}

	public void setSelectActivityBatchLog(String selectActivityBatchLog) {
		this.selectActivityBatchLog = selectActivityBatchLog;
	}

	public String getInsertActivityBatchLog() {
		return insertActivityBatchLog;
	}

	public void setInsertActivityBatchLog(String insertActivityBatchLog) {
		this.insertActivityBatchLog = insertActivityBatchLog;
	}
	
	
	
	

	
	
}

package com.healthpartners.service.imfs.dto;

import java.util.TreeSet;

/**
 * represents a person attribute. Attributes are name, value pairs one names
 * attribute can have multiple values. For example
 * <code>medical_coverage_active</code> can have multiple values
 * <code>1234, 4567, 9345</code> each corresponding to a coverage.
 * 
 * @author axpagey
 * 
 */
public class PersonAttribute extends BaseDTO {

	static final long serialVersionUID = 0L;

	private String attributeName;

	private TreeSet<String> attributeValues;

	public PersonAttribute() {
		super();
		attributeValues = new TreeSet<String>();
	}

	public PersonAttribute(String attributeName, TreeSet<String> attributeValues) {
		this();
		this.attributeName = attributeName;
		this.attributeValues = attributeValues;
	}

	public PersonAttribute(String attributeName, String attributeValue) {
		this();
		this.attributeName = attributeName;
		addAttributeValue(attributeValue);
	}

	/**
	 * @return the attributeName
	 */
	public String getAttributeName() {
		return attributeName;
	}

	/**
	 * @param attributeName
	 *            the attributeName to set
	 */
	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}

	/**
	 * Gets the collection attribute values.
	 * 
	 * @return
	 */
	public TreeSet<String> getAttributeValues() {
		return attributeValues;
	}

	public String getAttributeValue() {
		String result = null;
		if (attributeValues.size() <= 1) {
			result = (String) attributeValues.first();
		} else {
			throw new RuntimeException(
					"Attempt to access multi-value attribute as a single value. "
							+ "Use getAttributeValues");
		}
		return result;
	}

	/**
	 * Sets the attribute value list to the specified list.
	 * 
	 * @param attributeValue
	 */
	public void setAttributeValues(TreeSet<String> attributeValues) {
		this.attributeValues = attributeValues;
	}

	public void setAttributeValue(String attributeValue) {
		if (attributeValues.size() == 0) {
			addAttributeValue(attributeValue);
		} else {
			throw new RuntimeException("Attempt to assign a single value"
					+ " when multiple values already exist for attribute:"
					+ attributeName + " use addAttribute instead.");
		}
	}

	/**
	 * Adds a new value to the list of attribute values.
	 * 
	 * @param attributeValue
	 * @return count of number of items in attribute value list
	 */
	public int addAttributeValue(String attributeValue) {
		attributeValues.add(attributeValue);
		return attributeValues.size();
	}
}

package com.healthpartners.service.imfs.dto;

import java.io.Serializable;

public class EnvCode implements Serializable 
{	
	static final long serialVersionUID = 0L;
	
	private Integer envCodeID;
    private String envCode;
    private String envCodeValue;
    private String envCodeDesc;
    
    public EnvCode()
    {
    	super();
    }
    
	public Integer getEnvCodeID() {
		return envCodeID;
	}

	public void setEnvCodeID(Integer envCodeID) {
		this.envCodeID = envCodeID;
	}

	public String getEnvCode() {
		return envCode;
	}

	public void setEnvCode(String envCode) {
		this.envCode = envCode;
	}

	public String getEnvCodeValue() {
		return envCodeValue;
	}

	public void setEnvCodeValue(String envCodeValue) {
		this.envCodeValue = envCodeValue;
	}

	public String getEnvCodeDesc() {
		return envCodeDesc;
	}

	public void setEnvCodeDesc(String envCodeDesc) {
		this.envCodeDesc = envCodeDesc;
	}	        
}

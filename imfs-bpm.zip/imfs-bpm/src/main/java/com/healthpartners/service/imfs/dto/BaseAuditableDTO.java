/**
 * 
 */
package com.healthpartners.service.imfs.dto;

/**
 * @author tjquist
 *
 */
public abstract class BaseAuditableDTO extends BaseDTO {

	static final long serialVersionUID = 0L;
	
	private String insertUserId;
	
	private String modifyUserId;
	
	private String approverUserId;
	
	public BaseAuditableDTO() {
		super();
	}
	
	/**
	 * @return the insertUserId
	 */
	public String getInsertUserId() {
		return insertUserId;
	}
	/**
	 * @return the modifyUserId
	 */
	public String getModifyUserId() {
		return modifyUserId;
	}
	/**
	 * @param insertUserId the insertUserId to set
	 */
	public void setInsertUserId(String insertUserId) {
		this.insertUserId = insertUserId;
	}
	/**
	 * @param modifyUserId the modifyUserId to set
	 */
	public void setModifyUserId(String modifyUserId) {
		this.modifyUserId = modifyUserId;
	}

	/**
	 * @return the approverUserId
	 */
	public String getApproverUserId() {
		return approverUserId;
	}

	/**
	 * @param approverUserId the approverUserId to set
	 */
	public void setApproverUserId(String approverUserId) {
		this.approverUserId = approverUserId;
	}


}

package com.healthpartners.service.imfs.dto;

import java.sql.Date;

public class BusinessProgramType extends BaseDTO
{
    static final long serialVersionUID = 0L;
    
    private Integer programID;
    private String businessProgramType;
    private String businessProgramTypeName;
    private Integer marketIndicatorID;
    private Integer authPromoTypeCodeID;
    private String authPromoTypeCode;
    
    private Date renewalDate;
    private Date setupDate;
    
    public BusinessProgramType()
    {
    	super();
    }

	public String getBusinessProgramType() {
		return businessProgramType;
	}

	public void setBusinessProgramType(String businessProgramType) {
		this.businessProgramType = businessProgramType;
	}

	public Integer getMarketIndicatorID() {
		return marketIndicatorID;
	}

	public void setMarketIndicatorID(Integer marketIndicatorID) {
		this.marketIndicatorID = marketIndicatorID;
	}

	public Integer getAuthPromoTypeCodeID() {
		return authPromoTypeCodeID;
	}

	public void setAuthPromoTypeCodeID(Integer authPromoTypeCodeID) {
		this.authPromoTypeCodeID = authPromoTypeCodeID;
	}

	public String getAuthPromoTypeCode() {
		return authPromoTypeCode;
	}

	public void setAuthPromoTypeCode(String authPromoTypeCode) {
		this.authPromoTypeCode = authPromoTypeCode;
	}

	public Date getRenewalDate() {
		return renewalDate;
	}

	public void setRenewalDate(Date renewalDate) {
		this.renewalDate = renewalDate;
	}

	public Date getSetupDate() {
		return setupDate;
	}

	public void setSetupDate(Date setupDate) {
		this.setupDate = setupDate;
	}

	public Integer getProgramID() {
		return programID;
	}

	public void setProgramID(Integer programID) {
		this.programID = programID;
	}

	public String getBusinessProgramTypeName() {
		return businessProgramTypeName;
	}

	public void setBusinessProgramTypeName(String businessProgramTypeName) {
		this.businessProgramTypeName = businessProgramTypeName;
	}

	
	
}

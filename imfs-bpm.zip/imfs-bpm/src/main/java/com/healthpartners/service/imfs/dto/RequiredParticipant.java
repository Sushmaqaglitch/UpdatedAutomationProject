package com.healthpartners.service.imfs.dto;

import java.util.Calendar;

/**
 * @author tjquist
 * 
 */
public class RequiredParticipant extends BaseDTO {

	static final long serialVersionUID = 0L;

	private String memberID;
	private Integer programID;

	private Calendar currentBusinessProgramEffectiveDate;
	private String programTypeCode;
	private boolean participant;
    private boolean haAvailable;
    private String qualificationYear;

	/**
	 * 
	 */
	public RequiredParticipant() {
		super();
	}

	public final Calendar getCurrentBusinessProgramEffectiveDate() {
		return currentBusinessProgramEffectiveDate;
	}

	public final void setCurrentBusinessProgramEffectiveDate(
			Calendar currentBusinessProgramEffectiveDate) {
		this.currentBusinessProgramEffectiveDate = currentBusinessProgramEffectiveDate;
	}

	public final String getMemberID() {
		return memberID;
	}

	public final void setMemberID(String memberID) {
		this.memberID = memberID;
	}

	public String getProgramTypeCode() {
		return programTypeCode;
	}

	public void setProgramTypeCode(String programTypeCode) {
		this.programTypeCode = programTypeCode;
	}

	public boolean isHaAvailable() {
		return haAvailable;
	}

	public void setHaAvailable(boolean haAvailable) {
		this.haAvailable = haAvailable;
	}

	public boolean isParticipant() {
		return participant;
	}

	public void setParticipant(boolean participant) {
		this.participant = participant;
	}

	public String getQualificationYear() {
		return qualificationYear;
	}

	public void setQualificationYear(String qualificationYear) {
		this.qualificationYear = qualificationYear;
	}

	public Integer getProgramID() {
		return programID;
	}

	public void setProgramID(Integer programID) {
		this.programID = programID;
	}

	
}

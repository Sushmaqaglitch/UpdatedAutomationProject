package com.healthpartners.service.imfs.dao;

import java.util.Collection;

import com.healthpartners.service.imfs.dto.*;
import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.exception.BPMException;

public interface ContractDAO {

	/**
	 * Updates member contract status - batch.
	 *
	 * @return number of rows updated
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public int[] updateMemberContractStatus(
			Collection<MemberProgramUpdateTO> memberProgramUpdates)
			throws DataAccessException;

	/**
	 * Updates member contract status.
	 *
	 * @return number of rows updated
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public int updateMemberContractStatus(
			MemberProgramUpdateTO memberProgramUpdate)
			throws DataAccessException;

	/**
	 * gets member contract status.
	 * 
	 * @param contractNumber
	 * @param policyHolderID
	 * @param bisinessProgramID
	 * @return QualificationOverride
	 * @throws DataAccessException
	 */
	public MemberProgramUpdateTO getMemberContractStatus(
			Integer contractNumber, Integer policyHolderID,
			Integer bisinessProgramID) throws DataAccessException;
	
	/**
	 * gets contract status.
	 *
	 * @param programID
	 * @param programIncentiveOptionID
	 * @param contractNumber
	 * @throws DataAccessException
	 */
	public ContractProgramStatusTO getContractStatus(Integer programID, Integer programIncentiveOptionID, Integer contractNumber) throws DataAccessException;
	
	/**
	 * select bad member contracts 
	 * 
	 * @param pBadContractStartDate - start date when bad contracts were first created
	 
	 * @throws DataAccessException
	 */
	
	public  Collection<BadContract> getBadMemberContracts(
			String pBadContractStartDate) throws DataAccessException;
	
	/**
	 * inserts member contract status.
	 * 
	 * @param memberProgramUpdate
	 * @return id
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public long insertMemberContractStatus(
			MemberProgramUpdateTO memberProgramUpdate)
			throws DataAccessException;

	/**
	 * deletes record
	 * 
	 * @param contractProgramStatusID
	 * @return
	 * @throws DataAccessException
	 */
	public int deleteMemberContractStatus(long contractProgramStatusID)
			throws DataAccessException;

	public int deleteMemberContractStatusByPersonID(Integer personID,
			Integer contractNumber, Integer pProgramID) throws DataAccessException;

	public Collection<MemberContractProgramTO> getMemberContractProgramStatus(
			Integer pPersonID, Integer relationshipCode, Integer pTargetQualificationYear)
			throws DataAccessException;
	
	public Collection<MemberContractProgramTO> getMemberContractProgramStatusTermed(
			Integer pPersonID, Integer relationshipCode, Integer pTargetQualificationYear)
			throws DataAccessException;

	public long insertMemberContractStatus(Integer pPersonID,
			Integer pProgramID, Integer pContractNumber, String pMemberStatus,
			String pUserID) throws DataAccessException;

	public long updateMemberContractStatus(Integer pProgramIncentiveOptionID,
			Integer pProgramID, Integer pContractNumber, String pMemberStatus,
			String pUserID) throws DataAccessException;

	public Collection<MemberUpdate> getBPMMemberContracts(Integer pPersonID)
	throws DataAccessException;

	public Collection<MemberUpdate> getBPMMembersForProgramContract(
			Integer pContractNumber, Integer programID)
			throws DataAccessException;
	
	public Collection<MemberUpdate> getBPMMembersForProgramContractV2(Integer pContractNumber,
			Integer programID) 
			throws DataAccessException;
	
	public Collection<ContractHistory> getContractHistory(Integer pPersonID) 
	throws DataAccessException;
	public Collection<ContractHistory> getContractHistoryForDependent(Integer pPersonID) 
			throws DataAccessException;
	public Collection<PackageHistory> getPackageHistory(Integer pPersonID, Integer pContractNo) 
	throws DataAccessException;
	public Collection<PackageHistory> getPackageHistoryForDependent(Integer pPersonID, Integer pContractNo) 
			throws DataAccessException;
	public Collection<SubgroupHistory> getSubgroupHistory(Integer pPersonID, Integer pContractNo) 
	throws DataAccessException;
	public Collection<MemberUpdate> getIsParticipating(Integer personID, Integer pID, String pWhichColumn)
	throws DataAccessException;
	
	public Integer getContractStatusCount(String pContractStatus, Integer pBusinessProgramID) 
	throws DataAccessException;
	
	public ContractPolicyHolderInfo getNameOfPHByContract(Integer pContractNo) 
	throws DataAccessException;
	
	public Collection<CDHPFulfillmentTrackingReport> getCDHPFulfillmentTrackingReport(String groupNo, String productType, java.sql.Date transactionDate)
	throws DataAccessException; 
	
	public Collection<CDHPFulfillmentTrackingReport> getContractContributions(Integer programID, Integer contractNo, Integer incentiveOptionID) 
	throws DataAccessException;
	
	public boolean hasMemberContractStatusRow(Integer pContractNumber, Integer pProgramIncentiveOptionID, Integer pProgramID) 
	throws DataAccessException;
	
	public Contract getContractOfPH(Integer pContractNo) 
			throws DataAccessException;
}

/* $Id$ */

package com.healthpartners.service.imfs.common;

import java.util.Iterator;

import com.healthpartners.service.imfs.dto.MemberUpdate;

/**
 * Common constants for the BPM project.
 * 
 * @author pbhenninger
 */

public interface BPMConstants {
	
	public static final String HP_BPM_COMMON_DATE_FORMAT = "MM/dd/yyyy";
	
	public static final String PIPE_DELIMITED = "\\|";
	
	public static final String EMPLOYER_ACTIVITY_DATAFILE_DELEMETER = "\\,";

	// BPM types/groups in LUV table
	public static final String BPM_TYPE_MEMBER_STATUS = "BPM_MEMBER_STATUS";
	
	public static final String BPM_CONTRACT_STATUS = "BPM_CONTRACT_STATUS";
	
	public static final String BPM_RECYCLE_STATUS = "BPM_RECYCLE_STATUS";
	
	public static final String BPM_CDHP_RECYCLE_STATUS = "CDHP_RECYCLE_STATUS";
	
	public static final String BPM_REWARD_RECYCLE_STATUS = "REWARD_RECYCLE_STAT";

	public static final String BPM_TYPE_MEMBER_STATUS_REASON = "BPM_MEMBER_STATUSRSN";

	public static final String BPM_TYPE_CONTRACT_STATUS = "BPM_CONTRACT_STATUS";

	public static final String BPM_TYPE_OVERRIDE = "BPM_OVRD_TP";

	public static final String BPM_TYPE_ACTIVITY_STATUS = "BPM_ACTIVITY_STATUS";

	public static final String BPM_TYPE_ACTIVITY_STATUS_OUTCOME = "BPM_ACT_STS_OUTCOME";

	public static final String BPM_TYPE_ACTIVITY_TYPE = "BPM_ACTIVITY_TP";

	public static final String BPM_TYPE_BPM_PROCESS = "BPM_PROCESS_TP";

	public static final String BPM_TYPE_BPM_PROCESS_STATUS = "BPM_PROCESS_STS_TP";
	
	public static final String BPM_CONTRACT_INCENTIVE_STATUS = "BPM_CNTR_INCTV";

	// Activity Event/ Task / processing log  Processing Status
	public static final String PROCESSING_STATUS_PENDING = "PENDING";

	public static final String PROCESSING_STATUS_INPROCESS = "IN_PROCESS";

	public static final String PROCESSING_STATUS_COMPLETED = "COMPLETED";

	public static final String PROCESSING_STATUS_FILTERD_OUT = "FILTERD_OUT";

	public static final String PROCESSING_STATUS_FILTERD_IN = "FILTERD_IN";

	public static final String ALL_BENEFIT_YEARS = "ALL";
	
	//Cache Coverage Webservice Account info
	
	public static final String CACHE_COVERAGE_USERNAME = "CACHE_COV_USERNAME";
	public static final String CACHE_COVERAGE_PASSWORD = "CACHE_COV_PASSWORD";
	public static final String CACHE_COVERAGE_WSDL 	   = "CACHE_COV_WSDL";

	public static final String TRANSPORT_READ_TIMEOUT = "transport.read.timeout";
	public static final int DEFAULT_READ_TIMEOUT_SECONDS=10;
	
	
	public static final String EMPLOYER_ACTIVITY_STATUS_COMPLETED = "Y";
	
	// Qualification Override
	// This is automatic exemption
	public static final String OVERRIDE_CODE_EXEMPTION = "EXEMPTION";

	public static final String OVERRIDE_CODE_MANUAL_EXEMPTION = "MANUAL_EXEMPTION";
	
	// Email destination
	public static final String EMAIL_DESTINATION_MEMBERSHIP = "MEMBERSHIP";
	public static final String EMAIL_DESTINATION_CDHP_HRA = "CDHP HRA";
	public static final String EMAIL_DESTINATION_CDHP_HSA = "CDHP HSA";
	public static final String EMAIL_DESTINATION_ACTIVITY_TOB = "ACTIVITY TOB";
	public static final String EMAIL_DESTINATION_MEMBERSHIP_ONHOLD_RPT = "ONHOLD_RPT";
	public static final String EMAIL_DESTINATION_MEMBERSHIP_ACTION_NEEDED_RPT = "ACTION_NEEDED_RPT";
	public static final String EMAIL_DESTINATION_REWARDS_INTELISPEND = "INTELISPEND";
	
	//CDHP Fulfilement routing types
	public static final String CDHP_FLFLMNT_RTNG_TP_HPDIT = "SND_TO_HPDIT";
	public static final String CDHP_FLFLMNT_RTNG_TP_EMP_PORTAL = "SND_EMP_PORTAL";
	
	//Other Fulfillment routing types connected to vendor (ex. Intelispend produces gift cards)
	public static final String CDHP_FLFLMNT_RTNG_TP_INTELISPEND = "SND_TO_INTELISPEND";
	public static final String CDHP_FLFLMNT_RTNG_TP_CDHP = "SND_TO_CDHP";

	//Other Fulfillment routing types
	public static final String ACTIVITY_FLFLMNT_RTNG_TP_MEMBERSHIP_PREMIUM_BILLING = "SND_TO_MBPB";
	
	//Upload Employer Tracking Status
    public static final String UPL_EMPL_TRACK_STAT_GROUP = "UPL_EMPL_TRACK_STAT";
  	public static final String UPL_EMPL_PREPROCESS_STATUS = "PREPROCESS";
  	public static final String UPL_EMPL_INPROCESS_STATUS = "INPROCESS";
  	public static final String UPL_EMPL_POSTPROCESS_STATUS = "POSTPROCESS";
	
	//Email content type
	public static final String MAIL_CONTENT_TYPE_HTML = "HTML";
	public static final String MAIL_CONTENT_TYPE_TEXT = "TEXT";

	public static final String EMPL_SPONSORED_TO_ADDR = "EMPL_SPNSRED_TO_ADDR";
	public static final String EMPL_SPONSORED_TO_WELLSFARGO = "EMPL_SPNSRED_TO_WELLSFARGO";
	public static final String EMPL_SPONSORED_TO_TARGET = "EMPL_SPNSRED_TO_TARGET";
	public static final String EMPL_SPONSORED_TO_DAIKIN = "EMPL_SPNSRED_TO_DAIKIN";
	
	// EV 96022 - Optum Processing - Wells Fargo Customer Email Notification
	public static final String EMPL_SPNSRED_CONFRM = "EMPL_SPNSRED_CONFRM";
	public static final String EMPL_SPNSRED_WELLSFARGO = "EMPL_SPNSRED_WELLSFARGO";
	

	// Member Processing Status
	public static final String MEMBER_PROCESSING_STATUS_INPROCESS = "IN_PROCESS";

	public static final String MEMBER_PROCESSING_STATUS_COMPLETED = "COMPLETED";

	// Rule Set Names
	public static final String RULESET_NAME_MEMBER_STATUS = "memberStatusRules";

	public static final String RULESET_NAME_CONTRACT_STATUS = "ContractStatusRuleSet";

	public static final String RULESET_NAME_MEMBER_EXEMPTION = "MemberExemptionRuleSet";

	public static final String RULESET_NAME_MEMBER_GOLDPASS = "MemberGoldpassRuleSet";

	// Member Program Statuses
	public static final String MEMBER_STATUS_NEW = "NEW";

	public static final String MEMBER_STATUS_HOLD_FOR_CONTACT = "HOLD_FOR_CONTACT";

	public static final String MEMBER_STATUS_HA_COMPLETED = "HA_COMPLETED";

	public static final String MEMBER_STATUS_ACTIVE = "ACTIVE";

	public static final String MEMBER_STATUS_QUALIFIED = "QUALIFIED";

	public static final String MEMBER_STATUS_DID_NOT_QUALIFY = "DID_NOT_QUALIFY";
	
	public static final String MEMBER_STATUS_PROGRAM_COMPLETED = "MEMBER_COMPLETED";
	
	public static final String MEMBER_STATUS_PROGRAM_NOT_COMPLETED = "MEMBER_NOT_COMPLETED";
	
	public static final String MEMBER_STATUS_COMPLETED = "COMPLETED";
	
	public static final String MEMBER_STATUS_DID_NOT_COMPLETE = "DID_NOT_COMPLETE";

	public static final String MEMBER_STATUS_EXEMPT = "EXEMPT";

	public static final String MEMBER_STATUS_NOT_REQUIRED = "NOT_REQUIRED";

	public static final String MEMBER_STATUS_HA_PENDING = "HA_PENDING";

	public static final String MEMBER_STATUS_ELIGIBLE = "ELIGIBLE";
	
	public static final String MEMBER_STATUS_EXEMPT_ELIGIBLE = "EXEMPT_ELIGIBLE";
	public static final String MEMBER_STATUS_EXEMPT_HOLD = "EXEMPT_HOLD";
	public static final String MEMBER_STATUS_EXEMPT_HA_COMPLETED = "EXEMPT_HA_COMPLETED";
	public static final String MEMBER_STATUS_EXEMPT_ACTIVE = "EXEMPT_ACTIVE";
	public static final String MEMBER_STATUS_EXEMPT_QUALIFIED = "EXEMPT_QUALIFIED";
	
	public static final String MEMBER_STATUS_HOLD_FOR_PHONE = "HOLD_FOR_PHONE";
	
	public static final String MEMBER_STATUS_INITIALIZE = "INITIALIZE";
	
	//Output subdirectory
	
	
	public static final String OUTPUT_HRA_SUBDIR = "output_bpm_hra/";
	

	// Member Status Reasons
	public static final String MEMBER_STATUS_RSN_CONTACT_TIMEOUT = "CONTACT_TIMEOUT";

	public static final String MEMBER_STATUS_RSN_HIGH_RISK = "RISK";

	public static final String MEMBER_STATUS_RSN_NEW_CONTRACT = "NEW_CONTRACT";

	public static final String MEMBER_STATUS_RSN_REINSTATEMENT = "REINSTATEMENT";

	public static final String MEMBER_STATUS_RSN_SERIOUSLY_ILL = "SERIOUSLY_ILL";

	public static final String MEMBER_STATUS_RSN_EMPLOYER_DISCRETION = "EMPLOYER_DISCRETION";

	public static final String MEMBER_STATUS_RSN_APPEAL = "APPEAL";

	public static final String MEMBER_STATUS_RSN_QUAL_WINDOW_CLOSED = "WINDOW_CLOSED";

	public static final String MEMBER_STATUS_RSN_NEW_ON_CONTRACT = "NEW_ON_CONTRACT";

	public static final String MEMBER_STATUS_RSN_CONTRACT_GOLD_PASS = "CONTRACT_GOLD_PASS";

	// Program Participation Requirement
	public static final String BPM_PARTICIP_REQ_PH_ONLY_W_HEALTH = "PH_WITH_HEALTH";

	public static final String BPM_PARTICIP_REQ_PH_ONLY = "PH_ONLY";

	public static final String BPM_PARTICIP_REQ_PH_AND_SPOUSE = "PH_AND_SPOUSE";

	public static final String BPM_PARTICIP_REQ_PH_AND_SPOUSE_W_HEALTH = "PH_AND_SPOUSE_W_HEALTH";

	public static final String BPM_PARTICIP_REQ_PH_AND_SPOUSE_OR_DOM = "PH_AND_SPOUSE_OR_DOM";
	
	public static final String BPM_PARTICIP_REQ_ALL_18_PLUS = "ALL_18_PLUS";
	
	public static final String BPM_PARTICIP_REQ_PH_SPOUSE_OPTIONAL = "PH_SPOUSE_OPT"; 
	public static final String BPM_PARTICIP_REQ_PH_18_OPTIONAL = "PH_18_OPT";
	public static final String BPM_PARTICIP_REQ_PH_SPOUSE_DOM_OPTIONAL = "PH_SPOUSE_DOM_OPT";
	
	public static final String BPM_PARTICIP_REQ_PH_AND_SPOUSE_18_OPT = "PH_SP_18_OPT";
	public static final String BPM_PARTICIP_REQ_PH_AND_SPOUSE_DOM_18_OPT = "PH_SP_DP_18_OPT";

	// Activities
	public static final String ACTIVITY_HEALTHY_BENEFITS_HA = "Health Assessment";
	public static final String ACTIVITY_HEALTHY_BENEFITS_HA_ID = "0001";

	
	// contract status
	public static final String CONTRACT_STATUS_OPEN = "OPEN";

	public static final String CONTRACT_STATUS_QUALIFIED = "QUALIFIED";

	public static final String CONTRACT_STATUS_DID_NOT_QUALIFY = "DID_NOT_QUALIFY";

	public static final String CONTRACT_STATUS_GOLD_PASS = "GOLD_PASS";

	public static final String CONTRACT_STATUS_ELIGIBLE = "ELIGIBLE";
	
	public static final String CONTRACT_STATUS_NOT_APPLICABLE = "NOT_APPLICABLE";
	
	public static final String CONTRACT_STATUS_NONE = "NONE";
	
    // Membership Feed Person Contract Recycle Status
	public static final String PERSON_CONTRACT_RECYCLE_STATUS_APPROVED = "APPROVED";
	
	public static final String PERSON_CONTRACT_RECYCLE_STATUS_RELEASED = "RELEASED";
	
	public static final String PERSON_CONTRACT_RECYCLE_STATUS_DENIED = "DENIED";
	
	public static final String PERSON_CONTRACT_RECYCLE_STATUS_ON_HOLD = "ON_HOLD";
	
	// Status Tracking History Person Contract Recycle Status
	public static final String PERSON_CONTRACT_RECYCLE_STATUS_ACTION_NEEDED = "ACTION_NEEDED";
	public static final String PERSON_CONTRACT_RECYCLE_STATUS_ACTION_TAKEN = "ACTION_TAKEN";
	
	// Employer Recycle Status group
	public static final String BPM_EMPL_RECYCLE_STATUS = "EMPL_RECYCLE_STATUS";
	public static final String BPM_EMPL_RECYCLE_STATUS_ON_HOLD = "ON_HOLD";
	
	// CDHP Fulfillment Recycle Status
	
	public static final String CDHP_RECYCLE_STATUS_APPROVED = "APPROVED";
	
	public static final String CDHP_RECYCLE_STATUS_RELEASED = "RELEASED";
	
	public static final String CDHP_RECYCLE_STATUS_DENIED = "DENIED";
	
	public static final String CDHP_RECYCLE_STATUS_ON_HOLD = "ON_HOLD";
	
	// Reward Fulfillment Recycle Status
	
		public static final String REWARD_RECYCLE_STATUS_APPROVED = "APPROVED";
		
		public static final String REWARD_RECYCLE_STATUS_RELEASED = "RELEASED";
		
		public static final String REWARD_RECYCLE_STATUS_DENIED = "DENIED";
		
		public static final String REWARD_RECYCLE_STATUS_ON_HOLD = "ON_HOLD";
		
	
	// CDHP Fulfillment Recycle Tollgate Rule descriptions
	
	public static final String CDHP_RECYCLE_TOLLGATE_RULE_1 = "Person activity contribution already achieved across a contract or package.";
	public static final String CDHP_RECYCLE_TOLLGATE_RULE_2 = "Person activity contribution achieved when added to past contributions for participant exceeds participant cap amount.";
	public static final String CDHP_RECYCLE_TOLLGATE_RULE_3 = "Person activity contribution achieved when added to past contributions for the contract exceeds family cap amount.";
	public static final String CDHP_RECYCLE_TOLLGATE_RULE_4 = "Activity incentive not fulfilled.  Please investigate, take action, and set error records to denied.";
	
	//Status tracking history tollgate rules
	public static final String PERSON_CONTRACT_HIST_RECYCLE_TOLLGATE_RULE_1 = "Status still ELIGIBLE after qualification period.  Review for validity.";
	public static final String PERSON_CONTRACT_HIST_RECYCLE_TOLLGATE_RULE_2 = "Status changed from QUALIFIED to DID_NOT_QUALIFY.  Review for validity.";
	public static final String PERSON_CONTRACT_HIST_RECYCLE_TOLLGATE_RULE_3 = "Status changed from DID_NOT_QUALIFY to QUALIFIED with no exemption in benefit year. Review for validity.";

	//public static final String PERSON_CONTRACT_HIST_RECYCLE_TOLLGATE_RULE_5 = "Status changed from QUALIFIED to ELIGIBLE.  Action needed";
	//public static final String PERSON_CONTRACT_HIST_RECYCLE_TOLLGATE_RULE_6 = "Status changed from DID_NOT_QUALIFY to ELIGIBLE.  Action needed";
	//public static final String PERSON_CONTRACT_HIST_RECYCLE_TOLLGATE_RULE_7 = "Status changed from QUALIFY to DID_NOT_QUALIFY.  Action needed";



	public static final String PERSON_CONTRACT_HIST_ACTION_TAKEN_REASON = "Status changed back meeting tollgate rules due to status calculation.";	
	
	
	// Activity status
	public static final String ACTIVITY_STATUS_ACTIVE = "ACTIVE";

	public static final String ACTIVITY_STATUS_INACTIVE = "INACTIVE";

	public static final String ACTIVITY_STATUS_COMPLETE = "COMPLETE";
	
	public static final String ACTIVITY_STATUS_WAIVE = "WAIVE";

	public static final String ACTIVITY_STATUS_RECOMMENDED = "RECOMMENDED";
	
	public static final String ACTIVITY_STATUS_RECOMMENDED_CAN_NOT_COMPLETE = "REC_CAN_NOT_COMPLETE";

	public static final String ACTIVITY_STATUS_CANCELED = "CANCEL";

	public static final String ACTIVITY_STATUS_PENDING = "PENDING";

	public static final String ACTIVITY_STATUS_DELETE = "DELETE";
	
	public static final String ACTIVITY_STATUS_EXEMPT = "ACTV_EXMPT";
	
	public static final String ACTIVITY_STATUS_MET = "MET";
	public static final String ACTIVITY_STATUS_NOT_MET = "NOT_MET";
	
	 public static final String ACTIVITY_STATUS_INCENTIVE_ACHIEVED = "INCTV_ACHIEVED";
	 public static final String ACTIVITY_STATUS_INCENTIVE_NOT_ACHIEVED = "INCTV_NOT_ACHIEVED";
	

	// Activity Status outcome
	public static final String ACTIVITY_STATUS_OUTCOME_HIGH_RISK_DIABETES = "RISK_DIABETES";

	public static final String ACTIVITY_STATUS_OUTCOME_HIGH_RISK_CAD = "RISK_CAD";

	public static final String ACTIVITY_STATUS_OUTCOME_HIGH_RISK_DEPRESS = "RISK_DEPRESSION";

	public static final String ACTIVITY_STATUS_OUTCOME_HIGH_RISK_ALCOHOL = "RISK_ALCOHOL";

	public static final String ACTIVITY_STATUS_OUTCOME_GENERIC_RISK = "RISK";
	
	public static final String RISK_LUV_GROUP = "BPM_RISK_GROUP";
	
	public static final String RISK_GROUP_UNKNOWN = "UNKNOWN";

	// Activity Types
	public static final String ACTIVITY_TYPE_ONLINE_COURSE = "ONLINE";

	public static final String ACTIVITY_TYPE_DISEASE_MGMT = "DISEASE_MGMT";
	
	public static final String ACTIVITY_TYPE_TOBACCO_MGMT = "TOBACCO_MGMT";

	public static final String ACTIVITY_TYPE_PHONE_COURSE = "PHONE";

	public static final String ACTIVITY_TYPE_EMPLOYER_PGM = "EMPLOYER_PGM";
	
	public static final String ACTIVITY_TYPE_RISK = "RISK";
	
	//Incentive Rule Type
	public static final String BPM_LUV_INCENTIVE_ENROLLMENT_RULE_CODE = "INCNTV_RULE_TP";
	
	public static final String BPM_LUV_INCENTIVE_ENROLLMENT_RULE_TYPE_COVERAGE_EFF_DT = "COVERAGE_EFF_DT";
	

	// Relationship Types
	public static final String RELATIONSHIP_TYPE_SELF = "SELF";

	public static final String RELATIONSHIP_TYPE_SPOUSE = "SPOUSE";

	public static final String RELATIONSHIP_TYPE_DOMESTIC_PARTNER = "DOMESTIC PARTNER";

	public static final String RELATIONSHIP_TYPE_EX_SPOUSE = "EX-SPOUSE";

	public static final String BPM_TARGET_QUAL_YEAR_LUV = "BPM_TARGET_QUAL_YEAR";

	//Relationship Types in support of MemberAdapter class
	public static final String MEMBER_REL_TYPE_SELF = "SELF";

	public static final String MEMBER_REL_TYPE_SPOUSE = "SPOUSE";

	public static final String MEMBER_REL_TYPE_DOMESTIC_PARTNER = "DOMESTIC PARTNER";

	public static final String PARTICIPATION_GROUP_REQ_SELF = "PH_ONLY";

	public static final String PARTICIPATION_GROUP_REQ_SPOUSE = "SPOUSE_ONLY";

	public static final String PARTICIPATION_GROUP_REQ_SPOUSE_OR_DOM_PARTNER = "SPOUSE_OR_DOM";

	// BPM system user
	public static final String BPM_USER_SYSTEM = "BPM";
	
	//External vendor
	public static final String INTELISPEND_USER_SYSTEM = "INTELISPEND";

	// Task status
	public static final String TASK_STATUS_ACTIVE = "ACTIVE";

	public static final String TASK_STATUS_INACTIVE = "INACTIVE";

	public static final String TASK_STATUS_COMPLETE = "COMPLETE";

	public static final String TASK_STATUS_CANCELED = "CANCELED";
	
	public static final String TASK_STATUS_WAIVE = "WAIVE";

	public static final String TASK_STATUS_DELETE = "DELETE";

	// Task ID
	public static final String TASK_ID_HA_FOLLOWUP_HBG = "FOLUP_HBG";

	public static final String TASK_ID_HA_FOLLOWUP_BHIO = "FOLUP_BHIO";

	// BPM process
	public static final String BPM_PROCESS_ACTIVITY_UPDATE = "ACTV_UPD";

	// BPM process status
	public static final String BPM_PROCESS_STATUS_IN_PROCESS = "IN_PROCESS";

	public static final String BPM_PROCESS_STATUS_COMPLETED = "COMPLETED";
	
	//BPM Purge process commands

	public static final String BPM_PURGE = "BPM_PURGE";
	public static final String PURGE_GROUPBASELINEHIST_TABLE_MONTHTOKEEP = "GRP_BASE_HIST_MONTHTOKEEP";
	public static final String PURGE_AUDIT_LOG_TABLE_MONTHTOKEEP = "AUDITLOG_MONTHTOKEEP";
	public static final String PURGE_PROCESSLG_TABLE_MONTHTOKEEP = "PROCESSLG_MONTHTOKEP";

	public static final String PURGE_PERSON_CONTRACT_HIST_ARCHIVE_TABLE_MONTHTOKEEP = "PRSN_CONTRACT_HIST_MONTHTOKEEP";
	
	
	//Person Contract History Reconciliation Cutoff Date
	public static final String BPM_RECON_CUTOFF = "BPM_RECON_CUTOFF";
	public static final String PRSN_CONTRACT_HIST_RECON_CUTOFF_DATE = "BPM_WEEKS_TO_RECON";

	//Activity Event Cutoff Date to prevent older activities from entering the BPM System.
	public static final String BPM_ACTIVITY_EVENT_CUTOFF = "BPM_ACTV_EVNT_CUTOFF";
	
	//Reset IN_PROCESS Activity Event To PENDING Cutoff Date
	public static final String BPM_INPROCESS_ACTIVITY_CUTOFF = "BPM_INPROCESS_CUTOFF";
	public static final String RESET_INPROCESS_ACTIVITY_EVENT_CUTOFF_DATE = "BPM_WEEKS_TO_RESET";
	

	// Exemption / Gold pass reason
	public static final String BPM_EXEMPTION_REASON_JOINDT_AFTER_GRPNEWHIREDT = "Joined After Group's New Hire Date";
	public static final String BPM_EXEMPTION_REASON_TRANSFER_AFTER_GRPNEWHIREDT = "Site/Package Transfer After Group New Hire Date";

	public static final String BPM_EXEMPTION_REASON_CONTRACT_HAS_GOLDPASS = "Contract has Gold Pass";

	public static final String BPM_EXEMPTION_REASON_CONTRACTDT_AFTER_GRPNEWHIREDT = "Contract Date is After Group's New Hire Date";

	// constants for Timed out days for hold for contacts
	public static final int TASK_TIME_OUT_DAYS_HBG = 35; // 14;

	public static final int TASK_TIME_OUT_DAYS_BHIO = 35; // 21;

	public static final int HA_RISK_OUTCOME_TIME_OUT_DAYS = 7; // 2

	public static final int DISEASE_MGMT_ACTIVITY_COMPLETED_TIME_OUT_MONTHS = 5;

	public static final int DISEASE_MGMT_ACTIVITY_COMPLETED_TIME_OUT_DAYS = 150;

	public static final int DISEASE_MGMT_ACTIVITY_INACTIVE_GRACE_DAYS = 21;

	public static final String PROGRAM_TYPE_CODE_HEALTY_BENEFITS = "1";
	public static final String PROGRAM_TYPE_CODE_SMART_STEPS = "2";
	public static final String PROGRAM_TYPE_CODE_HIP = "3";
	public static final String PROGRAM_TYPE_CODE_JOURNEYWELL = "4";
	public static final String PROGRAM_TYPE_CODE_NEW_JOURNEYWELL = "5";
	public static final String PROGRAM_TYPE_CODE_JOURNEYWELL_4 = "6";
	public static final String PROGRAM_TYPE_CODE_OTHERWELLNESS = "7";
	public static final String PROGRAM_TYPE_CODE_EZPLAN = "9";
	public static final String PROGRAM_TYPE_CODE_OCTAVIUS = "22";
	

	
	
	// elapsed time(time outs - hold for contact etc) sql file name to use for
	// xml and xls
	public static final String MEMBER_ELAPSED_TIME_FILE_XML = "batchResources/memberElapsedTime.xml";
	
	public static final String MEMBER_ELAPSED_TIME_FILE_XSL = "batchResources/memberElapsedTime.xsl";

	public static final Integer PERSON_PROCESS_TYPE_DEFULT = new Integer(1);

	public static final String XML_TRANSFORM_SAXON_IMPLEMENTATION = "net.sf.saxon.TransformerFactoryImpl";

	// emailing

	public static final String BPM_EMAIL_FROM_ADDR = "BPM_EMAIL_FROM_ADDR";
	
	public static final String BPM_EMAIL_TO_ADDR_MEMBERSHIP = "BPM_MBRSHP_TO_ADDR";
	
	public static final String BPM_EMAIL_TO_ADDR_MEMBERSHIP_ONHOLD_RPT = "BPM_RECY_RPT_TO_ADDR";
	
	public static final String BPM_EMAIL_TO_ADDR_RECONCILE_RPT = "BPM_RECON_RP_TO_ADDR";
	
	public static final String BPM_EMAIL_TO_ADDR_EMPL_FULFILL_RPT = "EMPL_FULFILL_TO_ADDR";
	
	public static final String BPM_EMAIL_TO_ADDR = "BPM_EMAIL_TO_ADDR";
	
	public static final String BPM_EMAIL_TO_ADDR_HRA = "BPM_EMAIL_TO_ADDRHRA";
	
	public static final String BPM_EMAIL_TO_ADDR_HSA = "BPM_EMAIL_TO_ADDRHSA";

	public static final String BPM_EMAIL_HOST_SRVR = "BPM_EMAIL_HOST_SRVR";
	
	public static final String BPM_DB_ENV = "BPM_ADMIN_DB_ENV";
	
	public static final String BPM_HISTORY_CONTRACT = "contract";
	public static final String BPM_HISTORY_SUBGROUP = "subgroup";
	public static final String BPM_HISTORY_PACKAGE = "package";
	
	public static final int ETL_MEMBERSHIP_UPDATE_PRCS_ID = 1;	
	public static final int MEMBERS_RECALCULATION_PRCS_ID = 2;
	
	public static final String BPM_MEMBERSHIP_DISTRIBUTION_EMAIL = "BPM_MBRSHP_TO_ADDR";
	
	// success/fail.

	public static final String RESULT_SUCCESS = "SUCCESS";

	public static final String RESULT_FAILURE = "FAILURE";

	
	//auditing webservice readonly
	
	public static final String AUDIT_APPEVENT_BPM_WEBSERVICE_ISREQUIREDPARTICIPANT = "isRequiredParticipant";
	public static final String AUDIT_APPEVENT_BPM_WEBSERVICE_GETGROUPPROGRAM = "getGroupProgram";
	public static final String AUDIT_APPEVENT_BPM_WEBSERVICE_GETMEMBERSTATUS = "getMemberStatus";

	public static final String AUDIT_APPID_BPM_WEBSERVICE = "/webservices/bpm/1.0/bpm";
	
   //auditing webservice update
	
	public static final String AUDIT_APPEVENT_BPM_WEBSERVICE_UPDATEACTIVITYSTATUS = "updateActivityStatus";
	public static final String AUDIT_APPEVENT_BPM_WEBSERVICE_UPDATETASKSTATUS = "updateTaskStatus";
	
	public static final String AUDIT_APPID_BPM_UPDATE_WEBSERVICE = "webservices/bpm-upd/1.0/bpm-upd";
	
	public static final String BPM_INCENTIVE_TYPE_HP_BENEFIT = "BENEFIT";
	public static final String BPM_INCENTIVE_TYPE_EMPLOYER = "EMPLOYER"; 
	public static final String BPM_INCENTIVE_TYPE_NONE = "NONE";
	public static final String BPM_INCENTIVE_TYPE_OTHER = "OTHER";
	public static final String BPM_INCENTIVE_TYPE_VENDOR = "VENDOR";
	
	public static final String BPM_INCENTIVE_STATUS_WEB = "WEB";
	public static final String BPM_INCENTIVE_STATUS_WEB_HCSS = "WEB_HCSS";
	public static final String BPM_INCENTIVE_STATUS_HCSS = "HCSS";
	public static final String BPM_INCENTIVE_STATUS_INACTIVE = "INACTIVE";
	
	public static final String BPM_EXCLUSION_TYPE = "BPM_EXCLUSION_TP";
	
	public static final String BPM_ACTIVITY_TYPE_HA = "HA";
	public static final String BPM_ACTIVITY_TYPE_SCREENING = "SCREENING";
	public static final String BPM_ACTIVITY_TYPE_BIO_MARKER = "BIO_MARKER";
	public static final String BPM_ACTIVITY_TYPE_RISK = "RISK";
	public static final String BPM_ACTIVITY_TYPE_GOAL_COMPLETION = "GOAL_COMPLETION";
	
	public static final String BPM_SS_HA_AUTH_CODE_PREFIX = "SSHA";
	public static final String BPM_SS_PROMO_CODE_PREFIX = "SSPR";
	public static final String BPM_PROGRAM_TYPE_CODE_HEALTY_BENEFITS = "1";
	public static final String BPM_PROGRAM_TYPE_CODE_SMART_STEPS = "2";
	public static final String BPM_ACTIVITY_GROUP_SMART_STEPS = "SMARTSTEPS";
	
    //	 11 months added to the month of the effective date. For ex. Jan (month 1) + 11
	public static final int BPM_DEFAULT_GROUP_END_MONTH = 11;
	
	public static final String BPM_SOURCE_SYSTEM_DEMO = "10";
	public static final String BPM_HB_DEMO_MEM_ID_LUV = "BPM_HB_DEMO_MEM_ID";
	public static final String BPM_SS_DEMO_MEM_ID_LUV = "BPM_SS_DEMO_MEM_ID";
	
	public static final String BPM_PROGRAM_STATUS_ACTIVE = "ACTIVE";
	public static final String BPM_PROGRAM_STATUS_WITHDRAWN = "WITHDRAWN";
	
	public static final int BPM_DEFAULT_STATUS_CALC_END_MONTH = 6;
	
    public static final int BPM_ADMIN_MEMBERSHIP_UPDATE_PRCS_ID = 10;
    public static final String BPM_PROCESS_PAST_CONTRACT_END_DATES = "Process members with ELIGIBLE status beyond contract end date";
    public static final String BPM_PROCESS_MEMBER_ELIGIBLE_BEYOND_QUALIFICATION_PERIOD = "Process members with ELIGIBLE status beyond qualification end date";
    
    public static final int BPM_ADMIN_UNRESOLVED_BENEFIT_CONTRACT_TYPE_PRCS_ID = 12;
    
    //Activity event source id.
    public static final String ACTIVITY_EVENT_SOURCE_CODES = "ACTIVITY_SRCE_CD";
    public static final String ACTIVITY_EVENT_SOURCE_ID_OPTUM = "30";
    
    //Employer Fulfillment Reporting
    public static final String BPM_FULFILLMENT_ROUTING_NONE = "NONE";
    
    public static final String BPM_EMPL_FULFILL_CSV_PATH_ALLINA = "EMPL_FUL_RPT_ALLINA";
    public static final String BPM_CDHP_FULFILL_ASCII_PATH_HRA = "CDHP_FUL_RPT_HRA";
    public static final String CDHP_BATCH_TYPE_HRA = "HRA";
    public static final String CDHP_BATCH_TYPE_HSA = "HSA";
    //Tobacco
    public static final String ACTIVITY_BATCH_TYPE_TOB = "TOB";
    
    public static final String REWARD_BATCH_TYPE_INTELISPEND = "INTELISPEND";
    
    public static final String CDHP_PURCH_SUB_TP_NM_HRA = "GROUP - HRA";
    public static final String CDHP_PURCH_SUB_TP_NM_HSA = "GROUP - HSA";
    public static final String PURCH_SUB_TP_NM_COL = "PURCH_SUB_TP_NM";
    public static final String BEN_PKG_TP_COL = "BEN_PKG_TP";
    
    
    
    public static final String CDHP_RUN_FREQ_DAILY = "DAILY";
    public static final String CDHP_RUN_FREQ_WEEKLY = "WEEKLY";
    public static final String CDHP_RUN_FREQ_MONTHLY = "MONTHLY";
    public static final String CDHP_RUN_FREQ_QUARTERLY = "QUARTERLY";
    
    //FTP Domain, account, and password LUV group and value
    //LUV Group
    public static final String BPM_FTP_HOST_SRVR = "BPM_FTP_HOST_SRVR";
    //LUV Value
    public static final String WINFTP_DOMAIN = "WINFTP_DOMAIN";
    public static final String WINFTP_ALLINA_DIR = "WINFTP_ALLINA_DIR";
    public static final String WINFTP_ACT = "WINFTP_ACT";
    public static final String WINFTP_PW = "WINFTP_PW";
    public static final String EDI_DOMAIN = "EDI_DOMAIN";
    public static final String EDI_DIR = "EDI_DIR";
    public static final String EDI_ACT = "EDI_ACT";
    public static final String EDI_PW = "EDI_PW";
    
    
    //DB CDHP Environment
    public static final String CDHP_TRANS_ENV = "CDHP_TRANS_ENV";
    
    public static final String EMAIL_DESTINATION_EMPLOYER_FULFILLMENT_RPT = "EMPL_FULFILL_RPT";
    
    //CDHP File layout types
    public static final String CDHP_HSA_FILE_LAYOUT_TP_A = "HSA-A";
    
    //Employer Fulfillment Activity Reporting frequency.

    public static final String BPM_EMPL_FULFILL_ACT_RPT_FREQ_WEDNESDAY_WEEK2 = "WEDNESDAY_WEEK2";
    public static final String BPM_EMPL_FULFILL_ACT_RPT_FREQ_WEDNESDAY_WEEK4 = "WEDNESDAY_WEEK4";
    public static final String BPM_EMPL_FULFILL_ACT_RPT_FREQ_OFF_WEEK = "OFF_WEEK";
    
    //Day of week constants
    public static final String SUNDAY = "SUNDAY";
    public static final String MONDAY = "MONDAY";
    public static final String TUESDAY = "TUESDAY";
    public static final String WEDNESDAY = "WEDNESDAY";
    public static final String THURSDAY = "THURSDAY";
    public static final String FRIDAY = "FRIDAY";
    public static final String SATURDAY = "SATURDAY";
    
    
    //Controls day of week to pass in for sending activity completers to employer.
    public static final String BPM_EMPL_FULFILL_DAY_OF_WEEK_GROUPING = "EMPL_FULFILL_DAY";
    public static final String BPM_EMPL_FULFILL_DAY_OF_WEEK = "DAY_OF_WEEK";
    public static final String BPM_EMPL_FULFILL_CTRL_WEEKOFMONTH = "EMPL_FULFILL_MONTH";   
    public static final String BPM_EMPL_FULFILL_WEEK_CTRL1 = "WEEK_CTRL1";
    public static final String BPM_EMPL_FULFILL_WEEK_CTRL2 = "WEEK_CTRL2";
    
    //Controls number of transactions to process each time the Autopopulate batch job is run.
    
    public static final String BPM_AUTOPOPULATE_CTRL = "AUTOPOPULATE_CTRL";
    public static final String AUTOPOPULATE_CTRL_CT = "AUTOPOPULATE_CTRL_CT";
    
    //Intelispend report file groups
    public static final String BPM_INTELISPEND_RPT = "INTELISPEND_RPT";
    
    //Intelispend report file location value
    public static final String BPM_INTELISPEND_SHIP_FILEPATH_FROM = "SHIP_FILEPATH_FROM";
    public static final String BPM_INTELISPEND_SHIP_FILEPATH_TO = "SHIP_FILEPATH_TO";
    public static final String BPM_INTELISPEND_ORDER_FILEPATH_FROM = "ORDER_FILEPATH_FROM";
    public static final String BPM_INTELISPEND_ORDER_FILEPATH_TO = "ORDER_FILEPATH_TO";
    
    //Control Group IO File Direcory Setup Routing type group
    public static final String CNTRL_GRP_RT_TYPE = "CNTRL_GRP_RT_TYPE";
    public static final String UPL_EMPLOYER_SPONSORED = "UPL_EMPLOYER_SPONSORED";
    
    //Optum Post Process Detail Reporting Controls
    public static final String CNTRL_OPTUM_DETAIL_RPT = "CNTRL_OPTUM_RPT";
    public static final String CNTRL_OPTUM_VALID_ACTIVITY_ENABLED = "VALID_ACTVTY_ENABLED";
    
    //Employer sponsored upload path location
    public static final String UPL_EMPL_FILE_PREPROCESS = "UPL_EMPL_FILE_PRE";
    public static final String UPL_EMPL_FILE_PROCESSED = "UPL_EMPL_FILE_PRO";
    
    //Employer Sponsored Update switch group
    public static final String ESP_UPDATE_SWITCH = "ESP_UPDATE_SWITCH";
    public static final String ESP_UPDATE_ON = "Y";
   
    
    
    
    // Contract Incentive Statuses
    public static final String BPM_CONTRACT_INCENTIVE_ACHIEVED = "INCTV_ACHIEVED";
    public static final String BPM_CONTRACT_INCENTIVE_NOT_ACHIEVED = "INCTV_NOT_ACHIEVED";
    public static final String BPM_INCENTED_STATUS_TYPE_CONTRACT_BASED = "CONTRACT_BASED";
    public static final String BPM_INCENTED_STATUS_TYPE_MEMBER_BASED = "MEMBER_BASED";
    public static final String BPM_INCENTED_STATUS_TYPE_ACTIVITY_BASED = "ACTIVITY_BASED";
    public static final String BPM_INCENTED_STATUS_TYPE_ACTIVITY_PACKAGE_BASED = "ACTIVITY_PKGE_BASED";
    public static final String BPM_INCENTED_STATUS_TYPE_MULTI_ACTIVITY = "MULTI_ACTIVITY"; 
    public static final String BPM_INCENTED_STATUS_TYPE_ACTIVITY_ACTIVE = "ACTIVITY_ACTIVE";
    public static final String BPM_INCENTED_STATUS_TYPE_ACTIVITY_COMPLETE = "ACTIVITY_COMPLETE";
    public static final String BPM_INCENTED_STATUS_TYPE_ACTIVITY_MET = "MET";
    public static final String BPM_INCENTED_STATUS_TYPE_ACTIVITY_NOT_MET = "NOT_MET";
    
    public static final String BPM_FILTERD_OUT_RSN = "BPM_FILTERD_OUT_RSN";
    
    //Activity Event Filtered Out Code of zero indicates all edits were passed.
    public static final String BPM_FILTERD_OUT_RSN_CD0_OK = "0";
    
    // If activity is not HA, and there is no Registration ID, filter it out.
    public static final String BPM_FILTERD_OUT_RSN_CD1_NO_REGID = "1";
    
    //HA Activity Status pending.
    public static final String BPM_FILTERD_OUT_RSN_CD2_HA_PENDING = "2";
    
    /* If there is an existing COMPLETE, filter-out the incoming ACTIVE.
	* Reason being, if we let this activity in, it becomes the latest status for this activity.
	* If the activity has been completed, we don't want an earlier Active to become the latest.
	*/
    public static final String BPM_FILTERD_OUT_RSN_CD3_ACTIVE_W_EXISTING_COMPLETE = "3";
    
    // If there is an existing WAIVE for the program-year, filter this out.
    public static final String BPM_FILTERD_OUT_RSN_CD4_WAIVE = "4";
    
    /* Check if this activity is COMPLETE, INACTIVE, CANCEL or DELETE, the ACTIVE must exist within the same program year.
	* If the ACTIVE exists it's Ok. Otherwise filter out.
	* This rule does NOT apply to DM and Employer Sponsored activities.
	*/
    public static final String BPM_FILTERD_OUT_RSN_CD5_NO_ACTIVE = "5";
    
    /*
     * Eligible program activities do not exist.
     */
    public static final String BPM_FILTERD_OUT_RSN_CD6_NO_ACTIVITIES = "6";
    
    /*
     * Activity event sent is for a non participating member.
     */
    public static final String BPM_FILTERD_OUT_RSN_CD7_NON_PART_MEMBER = "7";
    
    // No matching auth code found
    public static final String BPM_FILTERD_OUT_RSN_CD9_NO_AUTH_CD = "9";
    
    // Past Incentive EnrollmentDate
    public static final String BPM_FILTERD_OUT_RSN_CD10_PAST_ENROLL_DATE = "10";
    
 // Past Incentive EnrollmentDate
    public static final String BPM_FILTERD_OUT_RSN_CD11_PAST_COMPLETION_DATE = "11";
 

    public static final String BPM_FILTERD_OUT_RSN_CD12_ACTIVITY_ID_NOT_FD = "12";
    
    public static final String BPM_FILTERD_OUT_RSN_CD13_REGISTRATION_ID_MISSING = "13";
    
    public static final String BPM_FILTERD_OUT_RSN_CD14_ACTIVITY_DATE_MISSING = "14";
    
    public static final String BPM_FILTERD_OUT_RSN_CD15_BEYOND_ELIGIBLE_ACTIVITY_PERIOD = "15";
    
    // Enrollment Date Rules
    public static String BPM_INCENTIVE_ENROLL_COMMUNICATE = "COMMUNICATED";
    public static String BPM_INCENTIVE_ENROLL_ENROLL_BY = "ENROLL_BY";
    public static String BPM_INCENTIVE_ENROLL_ENROLL_BY_NO_FILTER = "ENROLL_BY_NO_FLTER";
    public static String BPM_INCENTIVE_ENROLL_COMPLETE_BY = "COMPLETE_BY";
    public static String BPM_INCENTIVE_ENROLL_COMPLETE_BY_NO_FILTER = "COMPLETE_BY_NO_FLTER";
    public static String BPM_INCENTIVE_ENROLL_COMPLETE_WITHIN_NO_FILTER = "COMPL_WITHIN_NOFLTER";
    public static String BPM_INCENTIVE_ENROLL_COVERAGE_EFF_DT = "COVERAGE_EFF_DT";
    
    //Relationship codes.
    public static Integer RELSHP_SELF = 1;
    public static Integer RELSHP_SPOUSE = 2;
	public static Integer RELSHP_DEPENDENT = 7;
    public static Integer RELSHP_DOM_PARTNER = 13;
    //Benefit Contract Type
    public static String BEN_CON_TYPE_UNRESOLVED = "BEN_CON_UNRESOLVED";
    public static String BEN_CON_TYPE_SELF = "BEN_CON_SELF";
    public static String  BEN_CON_TYPE_SELF_SPOUSE = "BEN_CON_PH_SP";
	public static String  BEN_CON_TYPE_SELF_DOM = "BEN_CON_PH_DM";
    public static String BEN_CON_TYPE_SELF_PLUS_1 = "BEN_CON_PH_ONE";
    public static String BEN_CON_TYPE_SELF_PLUS_FAMILY = "BEN_CON_FAMILY";
    public static String BEN_CON_TYPE_SELF_FAM_NO_SP = "BEN_CON_PH_FAM_NO_SP";
	public static String BEN_CON_TYPE_BEN_CON_DEP = "BEN_CON_DEP";

    
    public static String BPM_MEMBER_WITH_MEDICAL_PLAN = "M";
    public static String BPM_NON_MEMBER_WITHOUT_PLAN = "J";
    
    public static String BPM_QUAL_STAT_CD_MET = "MET";
    public static String BPM_QUAL_STAT_CD_NOT_MET = "NOT_MET";
    
    public static String BPM_MEMBER_ACTIVATION_INCENTIVE_STATUS = "ACTIVE";
    
   
    //Reward Card Transmission Audit Log Status  
    //Luv Group level
    public static String TRANSM_AUDIT_STATUS = "TRANSM_AUDIT_STATUS";
    
    //Luv Value level
    public static String TRANSM_RECEIVED = "RECEIVED";
    public static String TRANSM_SENT = "SENT";
   
    //Reward Card Fulfillment Tracking Status - Reward Card Status ID 
    //Luv Group level
    public static String REWARD_CARD_STATUS_TP = "REWARD_CARD_STAT_TP";
    
    //Luv Value level
    public static String AWAITING_ADDRESS = "AWAITING_ADDRESS";
    public static String ADDRESS_VERIFIED = "ADDRESS_VERIFIED";
    public static String ORDERED = "ORDERED";
    public static String ACCEPTED = "ACCEPTED";
    public static String REJECTED = "REJECTED";
    public static String SHIPPED = "SHIPPED";
    public static String REPLACEMENT_SHIPPED = "REPLACEMENT_SHIPPED";
    public static String CARD_TYPE_REPLACEMENT = "Replacement";

	// Participation Group Codes
	public static String BPM_DEFAULT_FOR_ALL_CD = "DEFAULT_FOR_ALL";
	public static String BPM_HLTH_PLAN_IND_CD = "HLTH_PLAN_IND";
	public static String BPM_HLTH_PLAN_PARTICP_CD = "HLTH_PLAN_PARTICP";
	public static String BPM_NON_HLTH_PLAN_CD = "NON_HLTH_PLAN";
	public static String BPM_PH_AND_SPOUSE_CD = "PH_AND_SPOUSE";
	public static String BPM_PH_AND_SPOUSE_OR_DOM_CD = "PH_AND_SPOUSE_OR_DOM";
	public static String BPM_PH_ONLY_CD = "PH_ONLY";
	public static String BPM_SPOUSE_ONLY_CD = "SPOUSE_ONLY";
	public static String BPM_SPOUSE_OR_DOM_CD = "SPOUSE_OR_DOM";
	public static String BPM_18_PLUS_CD = "18_PLUS";

    // Participation Group Detail Codes
    public static String BPM_PROD_TP_CD = "PROD_TP_CD";
    public static String BPM_JW_OFFER_CD = "JW_OFFER_CD";
    public static String BPM_JW_REPORTING_UNIT = "JW_REPORTING_UNIT";
    public static String BPM_DIVISION_CD = "DIVISION_CD";
    public static String BPM_EMPLOYEE_FLG = "EMPLOYEE_FLG";
    public static String BPM_ELIG_HIRE_DT = "ELIG_HIRE_DT";
    public static String BPM_RELATIONSHIP_CD = "REL_CD";
	public static String BPM_DOB_CD = "DOB_DT";
    public static String BPM_HLTH_PLAN_CD = "HLTH_PLAN_CD";
    
    //Intelispend SOAP parameter ENV (environment) parameters
    public static String INTELISPEND_PARM = "INTELISPEND_PARM";
    
    public static String REWARDCARD_USER_NM = "REWARDCARD_USER_NM";
    public static String REWARDCARD_PASSWORD = "REWARDCARD_PASSWORD";
    public static String FILE_FORMAT = "FILE_FORMAT";
    public static String FILE_TYPE = "FILE_TYPE";
    public static String REWARDCARD_URL = "REWARDCARD_URL";
    
 
    public static String BPM_INCENTIVE_TYPE_HRA = "HRA";
    public static String BPM_INCENTIVE_TYPE_HSA = "HSA";
 
    public static String BPM_PRODUCT_SUBTYPE_HRA = "GROUP - HRA";
    public static String BPM_PRODUCT_SUBTYPE_HSA = "GROUP - HSA";
 
    public static String BPM_FUTURE_DATE = "01/01/9999";
    
    public static String BPM_SMALL_GROUP_TP = "BPM_SMALL_GROUP_TP";
    
    public static String BPM_TARGET = "0856";
    public static String BPM_DAIKIN = "32130";
    public static String BPM_WELLSFARGO = "60805";
    
    public static String BPM_FILTERED_OUT_LUV_GRP = "ACTV_EVNT_RPRT";
    public static String BPM_FILTERED_OUT_PATH_LUVAL = "FILE_PATH";
    
    public static String BPM_AUTOPOPULATE_AUDIT_GRP = "AUTOPOPULATE_AUD";
    public static String BPM_AUTOPOPULATE_AUDIT_PATH_LUVAL = "FILE_PATH";
    
    //Incentive Option Unit Types
    public static String BPM_IO_UNIT_TYPE_DOLLAR = "DOLLARS";
    public static String BPM_IO_UNIT_TYPE_UNITS = "UNITS";
    
    // Autopopulate Audit Report folder and file names
    public static String BPM_CHANGED_MARKET_EZ_FOLDER = "ChangedMarketEZ";
    public static String BPM_CHANGED_MARKET_FILE_NAME = "ChangedMarketEZ";
    public static String BPM_CHANGED_MARKET_Non_EZ = "ChangedMarketNonEZ";
    public static String BPM_ENDED_GROUPS = "EndedGroups";
    public static String BPM_ENDED_GROUPS_BIZ_SETUP = "EndedGroupsBizSetup";
    public static String BPM_ENDED_MEDICAL = "EndedMedical";
    
    //Incentive Option
    public static String INCENTIVE_OPTION_TYPE_NAME_DESC_PREFERRED_BENEFIT = "Preferred Benefit"; 
    public static String INCENTIVE_OPTION_TYPE_NAME_DESC_NAME_PREMIUM_DISCOUNT = "Premium Discount";
    public static String INCENTIVE_OPTION_TYPE_NAME_DESC_NAME_PREMIUM_DISCOUNT_I = "Premium Discount I";
    public static String INCENTIVE_OPTION_TYPE_NAME_DESC_TOBACCO = "Tobacco Cessation";
    
	public static final String INCENTIVE_OPTION_TYPE_NAME_SMARTSTEPS = "SMART_STEPS";
	
    
    public static String BPM_YES = "Y";
    
    public static String PROGRAM_INCENTIVE_OPTION_ACTIVATION_ACTIVE = "ACTIVE";
    public static String PROGRAM_INCENTIVE_OPTION_ACTIVATION_NOT_ACTIVE = "NOT_ACTIVE";
    
    //Activity
    
    public static final String ACTIVITY_SOURCE_ID_ESP021 = "ESP021";
    public static final String ACTIVITY_STATUS = "COMPLETE";
    public static final String ACTIVITY_SOURCE_SYSTEM_ID_VERMEER = "80";
    public static final String GROUPNO_VERMEER = "27324";
    public static final String SITENO_VERMEER = "JW";
    
}
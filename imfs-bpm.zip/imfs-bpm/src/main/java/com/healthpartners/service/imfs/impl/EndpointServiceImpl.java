package com.healthpartners.service.imfs.impl;

import com.healthpartners.service.imfs.iface.EndpointService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.ArrayList;

@Component
@Service
public class EndpointServiceImpl implements EndpointService {
    protected final Log logger = LogFactory.getLog(getClass());

    private static String uriPath = "/api/startBatchProcess";

    public String startBatchProcess(String userID, String processName, Integer daySpan, String sourceSystemID, String groupNo, String hostServer) throws Exception
    {
        String messageResponse = null;

        try {
            messageResponse = callEndPointWithWebClient(userID, processName, daySpan, sourceSystemID, groupNo, hostServer);
        } catch (Exception e) {
            throw e;
        }

        return messageResponse;
    }

    private String callEndPointWithWebClient(String userID,
                                             String processName,
                                             Integer daySpan,
                                             String sourceSystemID,
                                             String groupNo,
                                             String hostServer)
    {

        WebClient webClient = WebClient.create(hostServer);

        Mono<ClientResponse> result = webClient.post()
                .uri(uriBuilder -> uriBuilder
                        .path(uriPath)
                        .queryParam("userID", userID)
                        .queryParam("processName", processName)
                        .queryParam("daySpan", daySpan)
                        .queryParam("sourceSystemID", sourceSystemID)
                        .queryParam("groupNo", groupNo)
                        .build())

                .exchange();


        String messageResponse = result.flatMap(res -> res.bodyToMono(String.class)).blockOptional().toString();

        logger.info("returnMessage " + messageResponse);

        return messageResponse;

    }
}

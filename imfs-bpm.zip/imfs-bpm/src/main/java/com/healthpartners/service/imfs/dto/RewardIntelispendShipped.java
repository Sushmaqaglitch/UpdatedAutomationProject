
package com.healthpartners.service.imfs.dto;

import com.healthpartners.service.imfs.common.BPMUtils;

/**
 * Represents line item from the shipped data csv file sent from Intelispend
 * @author tjquist
 *
 */
public class RewardIntelispendShipped {

	
	private Integer shipDetailReportID;
	
	private String orderDate;
	
	private String orderNumber;
	
	private String cardNumberMasked;
	
	private String amount;
	
	private String shipDate;
	
	private String lastName;
	
	private String firstName;
	
	private String addressLine1;
	
	private String addressLine2;
	
	private String city;
	
	private String state;
	
	private String postalCode;
	
	private String groupNumberIndicativeData1;
	
	private String groupNameIndicativeData2;
	
	private String personIDIndicativeData3;
	
	private String rewardFulfillHistIDIndicativeData4;
	
	private String indicativeData5;
	
	private String quoteID;
	
	private String shipReportFileName;
	
	private Integer processStatusCode;
	
	private String proxyCardNumber;
	
	//pidNumber is reward card transaction id (uid) from reward_fulfill_trck_hist_sts table.
	private String pidNumber;
	
	private String shippedVia;
	
	private String shipTrackingNumber;
	
	private String rewardCardType;
	
	private Integer personDemographicsID;

	
	public RewardIntelispendShipped() {
		super();
	}




	public Integer getShipDetailReportID() {
		return shipDetailReportID;
	}




	public void setShipDetailReportID(Integer shipDetailReportID) {
		this.shipDetailReportID = shipDetailReportID;
	}




	public String getOrderDate() {
		return orderDate;
	}




	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}




	public String getOrderNumber() {
		return orderNumber;
	}




	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}


	public String getCardNumberMasked() {
		return cardNumberMasked;
	}

	public void setCardNumberMasked(String cardNumberMasked) {
		this.cardNumberMasked = cardNumberMasked;
	}

	public String getProxyCardNumber() {
		return proxyCardNumber;
	}




	public void setProxyCardNumber(String proxyCardNumber) {
		this.proxyCardNumber = proxyCardNumber;
	}




	public String getAmount() {
		return amount;
	}




	public void setAmount(String amount) {
		this.amount = amount;
	}



	public String getShipDate() {
		return shipDate;
	}




	public void setShipDate(String shipDate) {
		this.shipDate = shipDate;
	}




	public String getLastName() {
		return lastName;
	}




	public void setLastName(String lastName) {
		this.lastName = lastName;
	}




	public String getFirstName() {
		return firstName;
	}




	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}




	public String getAddressLine1() {
		return addressLine1;
	}




	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}




	public String getAddressLine2() {
		return addressLine2;
	}




	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}




	public String getCity() {
		return city;
	}




	public void setCity(String city) {
		this.city = city;
	}




	public String getState() {
		return state;
	}




	public void setState(String state) {
		this.state = state;
	}




	public String getPostalCode() {
		return postalCode;
	}




	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}



	public String getGroupNumberIndicativeData1() {
		return groupNumberIndicativeData1;
	}




	public void setGroupNumberIndicativeData1(String groupNumberIndicativeData1) {
		this.groupNumberIndicativeData1 = groupNumberIndicativeData1;
	}




	public String getGroupNameIndicativeData2() {
		return groupNameIndicativeData2;
	}




	public void setGroupNameIndicativeData2(String groupNameIndicativeData2) {
		this.groupNameIndicativeData2 = groupNameIndicativeData2;
	}




	public String getPersonIDIndicativeData3() {
		return personIDIndicativeData3;
	}




	public void setPersonIDIndicativeData3(String personIDIndicativeData3) {
		this.personIDIndicativeData3 = personIDIndicativeData3;
	}

	


	public String getRewardFulfillHistIDIndicativeData4() {
		return rewardFulfillHistIDIndicativeData4;
	}




	public void setRewardFulfillHistIDIndicativeData4(
			String rewardFulfillHistIDIndicativeData4) {
		this.rewardFulfillHistIDIndicativeData4 = rewardFulfillHistIDIndicativeData4;
	}




	public String getIndicativeData5() {
		return indicativeData5;
	}




	public void setIndicativeData5(String indicativeData5) {
		this.indicativeData5 = indicativeData5;
	}




	public String getQuoteID() {
		return quoteID;
	}




	public void setQuoteID(String quoteID) {
		this.quoteID = quoteID;
	}



	

	public String getShipReportFileName() {
		return shipReportFileName;
	}




	public void setShipReportFileName(String shipReportFileName) {
		this.shipReportFileName = shipReportFileName;
	}




	public Integer getProcessStatusCode() {
		return processStatusCode;
	}




	public void setProcessStatusCode(Integer processStatusCode) {
		this.processStatusCode = processStatusCode;
	}




	public String getPidNumber() {
		return pidNumber;
	}




	public void setPidNumber(String pidNumber) {
		this.pidNumber = pidNumber;
	}




	public String getShippedVia() {
		return shippedVia;
	}




	public void setShippedVia(String shippedVia) {
		this.shippedVia = shippedVia;
	}




	public String getShipTrackingNumber() {
		return shipTrackingNumber;
	}




	public void setShipTrackingNumber(String shipTrackingNumber) {
		this.shipTrackingNumber = shipTrackingNumber;
	}




	public String getRewardCardType() {
		return rewardCardType;
	}




	public void setRewardCardType(String rewardCardType) {
		this.rewardCardType = rewardCardType;
	}




	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}




	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}

	
	
	
	
}

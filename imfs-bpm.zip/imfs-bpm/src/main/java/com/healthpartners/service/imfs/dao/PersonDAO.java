package com.healthpartners.service.imfs.dao;

import com.healthpartners.service.imfs.dto.ActivityEvent;
import com.healthpartners.service.imfs.dto.ActivityFulfillmentTrackingReportHist;
import com.healthpartners.service.imfs.dto.BPMBusinessProgram;
import com.healthpartners.service.imfs.dto.CDHPFulfillmentTrackingRecycle;
import com.healthpartners.service.imfs.dto.CDHPFulfillmentTrackingReportHist;
import com.healthpartners.service.imfs.dto.Contract;
import com.healthpartners.service.imfs.dto.EmployerFulfillmentMemberActivity;
import com.healthpartners.service.imfs.dto.Member;
import com.healthpartners.service.imfs.dto.MemberActivity;
import com.healthpartners.service.imfs.dto.MemberProgramUpdateTO;
import com.healthpartners.service.imfs.dto.MemberUpdate;
import com.healthpartners.service.imfs.dto.Person;
import com.healthpartners.service.imfs.dto.PersonActivityAchievedContribution;
import com.healthpartners.service.imfs.dto.PersonActivityAchievedReward;
import com.healthpartners.service.imfs.dto.PersonActivityIncentToFulfillReconcile;
import com.healthpartners.service.imfs.dto.PersonActivityToContribGridReport;
import com.healthpartners.service.imfs.dto.PersonContractHist;
import com.healthpartners.service.imfs.dto.PersonContractRecycle;
import com.healthpartners.service.imfs.dto.PersonContractRecycleList;
import com.healthpartners.service.imfs.dto.PersonPackage;
import com.healthpartners.service.imfs.dto.PersonProgramActivityIncentiveStatus;
import com.healthpartners.service.imfs.dto.PersonProgramHealthPlan;
import com.healthpartners.service.imfs.dto.PersonProgramStage;
import com.healthpartners.service.imfs.dto.PersonRelationship;
import com.healthpartners.service.imfs.dto.RequiredParticipant;
import com.healthpartners.service.imfs.dto.RewardFulfillmentTrackingReportHist;
import com.healthpartners.service.imfs.dto.RewardIntelispendShipped;
import org.springframework.dao.DuplicateKeyException;
import com.healthpartners.service.imfs.exception.BPMException;
import org.springframework.dao.DataAccessException;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;


public interface PersonDAO {
    public Person getPersonByMemberId(String memberId)
            throws DataAccessException;

    public Person getPersonByPersonId(Integer personId)
            throws DataAccessException;


    /**
     * MemberStatus used by web service call
     *
     * @return
     * @throws DataAccessException
     */
    public Member getMemberStatus(int personID, int pProgramID, boolean pCalledFromWebPortal) throws DataAccessException;

    public Contract getMemberContractStatus(int personID, int pProgramID, int pRelationshipCode, int pContractNumber, boolean pCalledFromWebPortal)
            throws DataAccessException;

    Collection<PersonRelationship> getPersonRelationship(Integer personId)
            throws DataAccessException;

    public Collection<Member> getParticipatingMember(String pMemberID,
                                                     String pTargetQualificationYear, Calendar pCurrentDate) throws DataAccessException;

    public Collection<Member> getParticipatingMemberRetroactive(String pMemberID,
                                                                String pTargetQualificationYear, Calendar activityStatusDate) throws DataAccessException;

    public Collection<MemberUpdate> getParticipatingUpdatedMember(Integer personID)
            throws DataAccessException;

    public Collection<String> getOffHoldForContactMemberList() throws DataAccessException;

    public int deleteMemberProgramStatus(Integer personID, Integer programID)
            throws DataAccessException;

    public boolean hasMemberProgramStatusRow(Integer pPersonID, Integer pProgramID, Integer pRelationshipCodeID, Integer pProgramIncentiveOptionID);

    public boolean matchIncomingManualOrderToRewardFulfillHist(String external_txn_id)
            throws DataAccessException;

    public boolean matchIncomingOrderNoToFulfillOrderNo(Integer fulfillHistID, String orderNumber)
            throws DataAccessException;

    public int updateMemberProgramStatus(Integer pPersonID
            , Integer pProgramID
            , String pMemberStatus
            , String lPersonHealthPlanCode
            , Integer lQualificationCheckmarkID
            , Integer pRelationshipCodeID
            , String pUserID
            , Date coverageEffectiveDate
            , Integer pProgramIncentiveOptionID);

    public int insertMemberProgramStatus(Integer pPersonID
            , Integer pProgramID
            , String pMemberStatus
            , String lPersonHealthPlanCode
            , Integer pRelationshipCodeID
            , String pUserID
            , Date coverageEffectiveDate
            , Integer pProgramIncentiveOptionID)
            throws DataAccessException, DuplicateKeyException;

    public int insertPersonActivityFulfillmentHistory(MemberActivity lMemberActivity)
            throws DataAccessException, BPMException;

    /**
     * Updates member program status.
     *
     * @param memberProgramUpdate
     * @return number of rows updated
     * @throws BPMException
     * @throws DataAccessException
     */
    public int updateMemberProgramStatus(
            MemberProgramUpdateTO memberProgramUpdate)
            throws DataAccessException;

    /**
     * Updates member program status in batch.
     *
     * @return number of rows updated
     * @throws BPMException
     * @throws DataAccessException
     */
    public int[] updateMemberProgramStatus(
            Collection<MemberProgramUpdateTO> memberProgramUpdates)
            throws DataAccessException;

    /**
     * inserts member program status.
     *
     * @param memberProgramUpdate
     * @return number of rows updated
     * @throws BPMException
     * @throws DataAccessException
     */
    public int insertMemberProgramStatus(
            MemberProgramUpdateTO memberProgramUpdate)
            throws DataAccessException;

    public int updateMemberProgramStatusContractStatusDate(Integer pPersonID, Integer pProgramID) throws DataAccessException;

    public int updateMemberProgramStatusPartEndDate(Integer pPersonID, Integer pProgramID, java.sql.Date pParticipationEndDate) throws DataAccessException;

    public int updateMemberProgramStatusExternalPersonID(Integer pPersonDemographicsID, Integer pProgramID, String pExternalPersonID) throws DataAccessException;

    /**
     * gets MemberProgramStatus - a QualificationOverride
     *
     * @param personID
     * @param businessProgramID
     * @return <code>MemberProgramUpdateTO</code>
     * @throws DataAccessException
     */
    public MemberProgramUpdateTO getMemberProgramStatus(
            Integer personID, Integer businessProgramID)
            throws DataAccessException;

    public MemberProgramUpdateTO getMemberProgramStatusDetail(Integer personID,
                                                              Integer businessProgramID) throws DataAccessException;

    public Integer getPersonID(String memberID) throws DataAccessException;

    public Integer getPersonDemographicsIDFromPersonID(String personID) throws DataAccessException;

    public Integer getPersonIDFromPersonDemographicsID(Integer personDemographicsID) throws DataAccessException;

    public String getMemberID(Integer personID) throws DataAccessException;

    /**
     * Gets personIds executing sql. used for elapsed time calculations
     *
     * @return Collection<Integer> of persinIds
     * @throws DataAccessException
     */
    public Collection<Integer> getPersonsEligibleBeyondQualificationPeriod() throws DataAccessException;

    /**
     * Gets members who's had a status change after the last run date.
     *
     * @return Collection<PersonProgramStage> to be sent to membership staging project table.
     * @throws DataAccessException
     */
    public Collection<PersonProgramStage> getMembershipStatusFeed(String processName)
            throws DataAccessException;

    public int endMemberParticipation(Integer pPersonID, Integer pProgramID, String pUserID)
            throws DataAccessException;

    public Collection<RequiredParticipant> getParticipant(String pMemberID, String pTargetQualificationYear, Calendar pCurrentDate)
            throws DataAccessException;

    public Collection<PersonRelationship> getPersonRelationship(Integer personID, Integer pBusinessProgramID)
            throws DataAccessException;

    public int insertPersonProgramStatus18YearOldsForIncentiveOptionByProgramType(String programType, String incentiveOptionName)
            throws DataAccessException;

    public PersonContractHist getPersonContractHistForContractStatus(int pGroupNo, int pSiteNo, int pPersonNumber, int pContractNo, Date pQualStartDate) throws DataAccessException;

    public int getPersonContractHistCount() throws DataAccessException;

    public int insertPersonContractsHist(Collection<PersonContractHist> personProgramsHist) throws DataAccessException;

    public int insertPersonContractHist(PersonContractHist personProgramHist) throws DataAccessException, BPMException;

    public int deletePersonContractHist(Date cutoffDate) throws DataAccessException;

    public int insertPersonContractsHistArchive(Collection<PersonContractHist> personProgramsHistArchive) throws DataAccessException;

    public PersonContractHist getPersonContractHistForPersonContractMax(Integer personNumber, Integer contractNo, Integer programId, Integer programIncentiveOptionID) throws DataAccessException;

    public PersonContractHist getPersonContractHist(Integer programID, Integer personDemographicsID, Integer programIncentiveOptionID)
            throws DataAccessException;

    public Collection<PersonContractHist> getPersonContractsHistForArchive(Date archiveCutoffDate)
            throws DataAccessException;

    public int getPersonContractRecycleCount() throws DataAccessException;

    public boolean isPersonContractProgramHistExist(Integer programID, Integer personDemographicsID, Integer programIncentiveOptionID);

    public int insertPersonContractRecycle(PersonContractRecycle personContractsRecycle) throws DataAccessException, BPMException;

    public int updatePersonContractRecycleStatus(PersonContractRecycle personContractRecycle) throws DataAccessException, BPMException;

    public int updatePersonContractRecycleStatusPerTollgateRules(PersonContractRecycle personContractRecycle) throws DataAccessException, BPMException;

    public int updatePersonContractRecycleStatusWithReasonDesc(PersonContractRecycle personContractRecycle) throws DataAccessException, BPMException;

    public int deletePersonContractsRecycle(Collection<PersonContractRecycle> personContractsRecycle) throws DataAccessException;

    public Collection<PersonContractRecycle> getPersonContractRecycleOnHolds() throws DataAccessException;

    public Collection<PersonContractRecycleList> getPersonContractRecycleByRecycleStatus(String recycleStatus) throws DataAccessException;

    public Collection<PersonContractRecycle> getPersonContractsRecycle() throws DataAccessException;

    public PersonContractRecycle getPersonContractRecycleForPersonContract(Integer pContractNumber, Integer pPersonNumber, Integer pBizProgId, Integer pProgramIncentiveOptionID) throws DataAccessException;

    public Collection<PersonContractRecycle> getPersonContractsRecycleForStatus(Integer pRecycleStatusId) throws DataAccessException;

    public int setContractParticipationEndDate(Integer pPersonID, Integer pProgramID, Integer pContractNo, String pUserID)
            throws DataAccessException;

    public int insertProcessingStatusLogForPastContractEndDates()
            throws DataAccessException;

    public Collection<PersonContractHist> getPersonContractHistoryReconciled(java.sql.Date pCutoffDateToReconcile)
            throws DataAccessException;

    public Collection<PersonActivityIncentToFulfillReconcile> getPersonActivityIncentToFulfillReconciled(String sourceSystemCode, String productSubType)
            throws DataAccessException;

    public Collection<PersonActivityIncentToFulfillReconcile> getMemberActivityIncentToFulfillReconciled(String sourceSystemCode, String productSubType)
            throws DataAccessException;

    public Collection<CDHPFulfillmentTrackingReportHist> getPersonContributions(Integer programID, Integer contractNo, Integer personDemographicsID, Integer incentiveOptionID)
            throws DataAccessException;

    public int insertEmployerFulfillmentMemberActivityCompletions(String groupNo, String additionalActivityCompletersToProcessBasedOnWeekNDayOfMonth)
            throws DataAccessException;

    public Collection<EmployerFulfillmentMemberActivity> getEmployerFulfillmentMemberActivityCompletions(String pGroupNo, java.sql.Date pSnapShotDate, java.sql.Date pStartDate)
            throws DataAccessException;

    public Collection<BPMBusinessProgram> getPersonBusinessPrograms(Integer pPersonDemographicsID, boolean pOnlyCurrentBusinessPrograms, boolean pAllowBusinessProgramSiteTransfers)
            throws BPMException, DataAccessException;

    public ArrayList<PersonActivityAchievedContribution> getAllCDHPHRAParticipantContributions()
            throws DataAccessException;

    public ArrayList<PersonActivityAchievedContribution> getAllCDHPHSAParticipantContributions()
            throws DataAccessException;

    public ArrayList<PersonActivityAchievedContribution> getCDHPHRAEmployerSponsoredParticipantContributions()
            throws DataAccessException;

    public ArrayList<PersonActivityAchievedContribution> getCDHPHRAEmployerSponsoredParticipantContributionRecycleApprovals()
            throws DataAccessException;


    public boolean isMultiActivityRewardFulfilled(
            PersonActivityAchievedReward lPersonActivityAchievedReward) throws DataAccessException;

    public CDHPFulfillmentTrackingReportHist findPersonCDHPContributionAlreadySent(PersonActivityAchievedContribution lPersonActivityAchievedContribution)
            throws DataAccessException;

    public int insertCDHPCompletion(PersonActivityAchievedContribution cdhpParticipantCompletion)
            throws DataAccessException;

    public int insertCDHPCompletionHistory(PersonActivityAchievedContribution cdhpParticipantCompletion)
            throws DataAccessException;

    public int insertRewardFulfillHistory(PersonActivityAchievedReward participantCompletion)
            throws DataAccessException;


    public CDHPFulfillmentTrackingRecycle getCDHPFulfillRecycleForPerson(int programID, int pPersonDemographicsID, int activityID)
            throws DataAccessException;

    public int updateCDHPFulfillRecycleStatus(CDHPFulfillmentTrackingRecycle lCDHPFulfillmentTrackingRecycle)
            throws DataAccessException, BPMException;

    public int insertCDHPFulfillmentRecycle(CDHPFulfillmentTrackingRecycle newCDHPFulfillmentTrackingRecycle)
            throws DataAccessException, BPMException;


    public Collection<PersonProgramActivityIncentiveStatus> getUnresolvedPersonPgmActivityIncentiveStatus() throws DataAccessException;

    public PersonProgramActivityIncentiveStatus getPersonPgmActivityIncentiveStatus(ActivityEvent lActivityEvent)
            throws DataAccessException;

    public List<PersonProgramActivityIncentiveStatus> getMemberPgmActivityIncentiveStatuses(Integer programID, Integer personDemographicsID, String activityStatusCode, String memberStatusCode)
            throws DataAccessException;

    public PersonProgramActivityIncentiveStatus getPersonPgmActivityIncentiveStatusEnhanced(Integer programID, Integer personDemographicsID, Integer activityID, Date activityStatusDate, Integer contributionAmt)
            throws DataAccessException;

    public List<PersonProgramActivityIncentiveStatus> getContractPgmActivityIncentiveStatus(Integer programID, Integer contractNo, Integer incentiveOptionID, Integer activityID)
            throws DataAccessException;

    public PersonProgramActivityIncentiveStatus getMemberPgmActivityIncentiveStatus(Integer programID, Integer personDemographicsID, Integer incentiveOptionID, Integer activityID)
            throws DataAccessException;

    public PersonProgramActivityIncentiveStatus getMemberPgmActivityIncentiveStatusEnhanced(Integer programID, Integer personDemographicsID, Integer activityID, Date activityStatusDate, Integer contributionAmt)
            throws DataAccessException;

    public Collection<CDHPFulfillmentTrackingReportHist> getCDHPFulfillmentTrackingReportHist(String productType, Integer programID, Integer personDemographicsID, Integer activityID)
            throws DataAccessException;

    public Collection<CDHPFulfillmentTrackingReportHist> getCDHPFulfillmentTrackingReportHistByGroup(String groupNo, String productType, java.sql.Date transactionDate)
            throws DataAccessException;

    public Collection<RewardFulfillmentTrackingReportHist> getRewardFulfillmentTrackingReportHistByProgram(Integer programID, Integer incentiveOptionID, String quoteID, java.sql.Date transactionDate)
            throws DataAccessException;

    public Integer getProgramByRewardFulfillTransHistID(Integer fulfillTransHistID);

    public Integer getPersonSoicalSecurityNo(Integer lPersonID)
            throws DataAccessException;

    public String getMemberNoUsingMODS(String lExternalPersonID)
            throws Exception, DataAccessException;

    public List<PersonProgramHealthPlan> getPersonHealthPlanCode(Integer pPersonDemographicsID, Integer pBusinessProgramID, Integer pContractNo)
            throws DataAccessException;

    public int updatePersonHealthPlanCode(Integer pPersonDemographicsID
            , Integer pBusinessProgramID
            , Integer pProgramIncentiveOptionID
            , Integer pRelationshipID
            , String pHealthPlanCode)
            throws DataAccessException;

    public PersonProgramActivityIncentiveStatus getPersonPgmActivityIncentives(Integer programID, Integer personDemograhicsID)
            throws DataAccessException;

    public List<PersonActivityAchievedReward> getAllParticipantRewards(Integer programID, java.sql.Date lastSuccessfulRunDate)
            throws DataAccessException;

    public Integer getRewardFulfillHistIDByExternalTransID(String externalTransactionID) throws DataAccessException;

    public int updateRewardFulfillRptTrackHist(
            RewardIntelispendShipped lRewardIntelispendShipped)
            throws DataAccessException;

    public int updateRewardFulfillmentHistWTodaysDate(
            Integer rewardTransHistID)
            throws DataAccessException;

    public int updateRewardFulfillmentHistWOrderNumber(Integer rewardTransHistID, String orderNumber)
            throws DataAccessException;

    public int insertRewardFulfillmentStatus(
            Integer rewardTransHistID, Integer reasonCodeID, Date statusDate, String systemID)
            throws DataAccessException;

    public String findLatestRewardFulfillStatus(Integer rewardTransHistID, Integer rewardStatusID) throws DataAccessException;

    public Collection<PersonPackage> getPersonPackages(Integer pPersonDemographicsID, Integer pProgramID)
            throws DataAccessException;

    public Collection<PersonPackage> getPersonPackagesRetroTerms(Integer pPersonDemographicsID, Integer pProgramID)
            throws DataAccessException;

    public List<java.sql.Date> selectContractEndDates(Integer pPersonDemographicsID, Integer pProgramID, Integer pContractNo)
            throws DataAccessException;

    public List<java.sql.Date> selectSubgroupEndDates(Integer pPersonDemographicsID, Integer pProgramID, Integer pContractNo)
            throws DataAccessException;

    public List<java.sql.Date> selectPackageEndDates(Integer pPersonDemographicsID, Integer pProgramID, Integer pContractNo)
            throws DataAccessException;

    public int updateParticipationEndDate(Integer pPersonID, Integer pProgramID, java.sql.Date pEndDate, Integer pRelationshipCodeID, String pUserID)
            throws DataAccessException;

    public ArrayList<PersonActivityAchievedContribution> getCDHPHRAContractParticipantContributions()
            throws DataAccessException;

    public ArrayList<PersonActivityAchievedContribution> getCDHPHRAMemberParticipantContributions()
            throws DataAccessException;

    public ArrayList<PersonActivityAchievedContribution> getCDHPHSAContractParticipantContributions()
            throws DataAccessException;

    public ArrayList<PersonActivityAchievedContribution> getCDHPHSAMemberParticipantContributions()
            throws DataAccessException;

    public Collection<PersonActivityAchievedReward> getContractRewards(Integer programID, java.sql.Date lastSuccessfulRunDate)
            throws DataAccessException;

    public Collection<PersonActivityAchievedReward> getContractRewardsWithContribGrid(Integer programID, java.sql.Date lastSuccessfulRunDate)
            throws DataAccessException;

    public List<PersonActivityAchievedReward> getMemberRewards(Integer programID, java.sql.Date lastSuccessfulRunDate)
            throws DataAccessException;

    public ArrayList<PersonActivityAchievedReward> getMemberRewardsWithContribGrid(Integer programID, java.sql.Date lastSuccessfulRunDate)
            throws DataAccessException;

    public Collection<MemberActivity> getPersonProgramActivityStatusAchieved(String activityOutcome);

    public Collection<ActivityFulfillmentTrackingReportHist> getActivityFulfillmentTrackingReportHist(String fulfillmentRoutingType, java.sql.Date transactionDate)
            throws DataAccessException;

    public List<PersonActivityToContribGridReport> getPersonActivityToContribGridReport(String fulfillmentRoutingTypeCode)
            throws DataAccessException;

    public List<PersonActivityToContribGridReport> getPersonContractActivityToContribGridReport(String fulfillmentRoutingTypeCode)
            throws DataAccessException;

    public boolean isContractIncentedForActivity(
            Integer programID, Integer contractNumber) throws DataAccessException;

    public boolean isPersonActivityFulfillmentHistoryNotExist(
            MemberActivity pMemberActivity) throws DataAccessException;

    public Collection<String> getMemberIDFromPersonDetails(String firstName, String middleInitial,
                                                           String lastName, String gender, java.sql.Date dateOfBirth)
            throws DataAccessException;

    public boolean validateParticipatingMember(String memberID) throws DataAccessException;

    public int updatePersonQualificationCheckmark(Integer pPersonDemographicsID
            , Integer pBusinessProgramID
            , Integer pProgramIncentiveOptionID
            , Integer pQualificationCheckmarkID)
            throws DataAccessException;

    public boolean isCDHPPersonActivityIncentToFulfillReconcile(
            PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus) throws DataAccessException;

    public boolean isRewardPersonActivityIncentToFulfillReconcile(
            PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus) throws DataAccessException;

    public ArrayList<PersonActivityAchievedContribution> getCDHPHRAContractParticipantContributionsWithContribGrid()
            throws DataAccessException;

    public ArrayList<PersonActivityAchievedContribution> getCDHPHRAMemberParticipantContributionsWithContribGrid()
            throws DataAccessException;

    public ArrayList<PersonActivityAchievedContribution> getCDHPHSAMemberParticipantContributionsWithContribGrid()
            throws DataAccessException;

    public java.sql.Date getFirstContractStatusDate(Integer pPersonID, Integer pProgramID);

    public ArrayList<PersonActivityAchievedContribution> getCDHPHSAContractParticipantContributionsWithContribGrid()
            throws DataAccessException;


}

/* $Id$ */

package com.healthpartners.service.imfs.dto;

import java.util.Collection;
import java.util.HashMap;
import java.util.TreeSet;

/**
 * Represents a person. Maps to the <code>prsn</code> table.
 * 
 * @author pbhenninger
 */
public class Person extends BaseDTO {

	static final long serialVersionUID = 0L;

	private Integer id;

	private String memberId;

	private String firstName;

	private String middleName;

	private String lastName;

	private String genderDescription;

	private String addressLine1;

	private String addressLine2;

	private String city;

	private String county;

	private String state;

	private String zip;

	private java.util.Date dateOfBirth;

	private java.util.Date dateOfDeath;

	private java.util.Date messageGenerationTimestamp;

	private String messageGenerationStatusCode;

	private String emailAddress;

	private HashMap<String, PersonAttribute> attributes = new HashMap<String, PersonAttribute>();

	private HashMap<String, MemberActivity> activities = new HashMap<String, MemberActivity>();

	private Collection coverages;

	public Person() {
		super();
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public PersonAttribute getAttribute(String attributeName) {
		PersonAttribute attribute = null;

		if (attributeName != null) {
			attribute = (PersonAttribute) attributes.get(attributeName);
		}

		return attribute;
	}

	public Collection getAllAttributes() {
		return attributes.values();
	}

	public void setAttribute(PersonAttribute attribute) {
		if (attribute != null) {
			String attributeName = attribute.getAttributeName();
			TreeSet<String> attributeValues = attribute.getAttributeValues();
			PersonAttribute newAttribute = (PersonAttribute) attributes
					.get(attributeName);
			if (newAttribute == null) {
				newAttribute = new PersonAttribute(attributeName,
						attributeValues);
			} else {
				newAttribute.setAttributeValues(attributeValues);
			}
			attributes.put(attributeName, newAttribute);
		}
	}

	public void setActivity(MemberActivity activity) {
		if (activity != null) {
			String activityName = activity.getActivity().getName();
			MemberActivity newActivity = (MemberActivity) activities
					.get(activityName);
			if (newActivity == null) {
				activities.put(activityName, activity);
			}
		}
	}

	public void removeAttribute(String attributeName) {
		attributes.remove(attributeName);
	}

	public void removeActivity(String activityName) {
		activities.remove(activityName);
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCounty() {
		return county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	public Collection getCoverages() {
		return coverages;
	}

	public void setCoverages(Collection coverages) {
		this.coverages = coverages;
	}

	public java.util.Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(java.util.Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public java.util.Date getDateOfDeath() {
		return dateOfDeath;
	}

	public void setDateOfDeath(java.util.Date dateOfDeath) {
		this.dateOfDeath = dateOfDeath;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getGenderDescription() {
		return genderDescription;
	}

	public void setGenderDescription(String genderDescription) {
		this.genderDescription = genderDescription;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getMessageGenerationStatusCode() {
		return messageGenerationStatusCode;
	}

	public void setMessageGenerationStatusCode(
			String messageGenerationStatusCode) {
		this.messageGenerationStatusCode = messageGenerationStatusCode;
	}

	public java.util.Date getMessageGenerationTimestamp() {
		return messageGenerationTimestamp;
	}

	public void setMessageGenerationTimestamp(
			java.util.Date messageGenerationTimestamp) {
		this.messageGenerationTimestamp = messageGenerationTimestamp;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	/**
	 * Format the user name for display.
	 * 
	 * @return the user name, or "member" if not defined.
	 */
	public String getDisplayName() {
		StringBuffer sb = new StringBuffer("");

		if (getFirstName() != null) {
			sb.append(getFirstName());
			sb.append(" ");
		}

		if (getLastName() != null) {
			sb.append(getLastName());
		}

		if (sb.length() == 0) {
			sb.append("member");
		}

		return sb.toString();
	}

	/**
	 * Format the user full name for display.
	 * 
	 * @return the user full name, or "member" if not defined.
	 */
	public String getDisplayFullName() {
		StringBuffer sb = new StringBuffer("");

		if (getFirstName() != null) {
			sb.append(getFirstName());
			sb.append(" ");
		}

		if (getMiddleName() != null) {
			sb.append(getMiddleName());
			sb.append(" ");
		}

		if (getLastName() != null) {
			sb.append(getLastName());
		}

		if (sb.length() == 0) {
			sb.append("member");
		}

		return sb.toString();
	}
}

package com.healthpartners.service.imfs.dto;

import java.sql.Date;
import java.sql.Time;
/**
 * 
 * @author tjquist
 *
 */
public class RewardFulfillmentTrackingRecycle extends BaseDTO {
	
	static final long serialVersionUID = 0L;
	
	private Integer rewardRecycleId;
	private Integer rewardTransHistID;
	private String  recycleStatus;
	private Integer recycleStatusId;
	private String reasonCodeID;
	private String fieldColumn;
	private String itemNo;
	private String reasonDesc;
	private String approverUserId;
	private Date insertDate;
	private Date modifyDate;
	private String insertUser;
	private String modifyUser;
	
	
	
	
	public Integer getRewardRecycleId() {
		return rewardRecycleId;
	}
	public void setRewardRecycleId(Integer rewardRecycleId) {
		this.rewardRecycleId = rewardRecycleId;
	}
	
	public Integer getRewardTransHistID() {
		return rewardTransHistID;
	}
	public void setRewardTransHistID(Integer rewardTransHistID) {
		this.rewardTransHistID = rewardTransHistID;
	}
	public String getRecycleStatus() {
		return recycleStatus;
	}
	public void setRecycleStatus(String recycleStatus) {
		this.recycleStatus = recycleStatus;
	}
	public Integer getRecycleStatusId() {
		return recycleStatusId;
	}
	public void setRecycleStatusId(Integer recycleStatusId) {
		this.recycleStatusId = recycleStatusId;
	}
	
	
	
	public String getReasonCodeID() {
		return reasonCodeID;
	}
	public void setReasonCodeID(String reasonCodeID) {
		this.reasonCodeID = reasonCodeID;
	}
	public String getFieldColumn() {
		return fieldColumn;
	}
	public void setFieldColumn(String fieldColumn) {
		this.fieldColumn = fieldColumn;
	}
	public String getItemNo() {
		return itemNo;
	}
	public void setItemNo(String itemNo) {
		this.itemNo = itemNo;
	}
	public String getReasonDesc() {
		return reasonDesc;
	}
	public void setReasonDesc(String reasonDesc) {
		this.reasonDesc = reasonDesc;
	}
	
	
	public String getApproverUserId() {
		return approverUserId;
	}
	public void setApproverUserId(String approverUserId) {
		this.approverUserId = approverUserId;
	}
	public Date getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}
	public Date getModifyDate() {
		return modifyDate;
	}
	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}
	public String getInsertUser() {
		return insertUser;
	}
	public void setInsertUser(String insertUser) {
		this.insertUser = insertUser;
	}
	public String getModifyUser() {
		return modifyUser;
	}
	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}
	
	
	
	
    
}

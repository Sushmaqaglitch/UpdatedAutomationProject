package com.healthpartners.service.imfs.dto;

import java.io.Serializable;

/**
 * 
 * @author jxbourbour
 *
 */
public class ContractProgramIncentive implements Serializable
{	
	static final long serialVersionUID = 0L;
	
	private Integer businessProgramID;
	private Integer contractNumber;
	private Integer incentiveOptionID;
	private String incentiveOptionName;
	private String incentiveOptionDesc;
	private Integer contractStatusCodeID;
	private String contractStatusCode;
	private java.sql.Date contractStatusAchievedDate;
	private java.sql.Date contractStatusDate;
	

	public ContractProgramIncentive()
    {
    	super();
    }

	public Integer getBusinessProgramID() {
		return businessProgramID;
	}

	public void setBusinessProgramID(Integer businessProgramID) {
		this.businessProgramID = businessProgramID;
	}

	public Integer getContractNumber() {
		return contractNumber;
	}

	public void setContractNumber(Integer contractNumber) {
		this.contractNumber = contractNumber;
	}

	public Integer getIncentiveOptionID() {
		return incentiveOptionID;
	}

	public void setIncentiveOptionID(Integer incentiveOptionID) {
		this.incentiveOptionID = incentiveOptionID;
	}

	public Integer getContractStatusCodeID() {
		return contractStatusCodeID;
	}

	public void setContractStatusCodeID(Integer contractStatusCodeID) {
		this.contractStatusCodeID = contractStatusCodeID;
	}

	public String getContractStatusCode() {
		return contractStatusCode;
	}

	public void setContractStatusCode(String contractStatusCode) {
		this.contractStatusCode = contractStatusCode;
	}

	public java.sql.Date getContractStatusDate() {
		return contractStatusDate;
	}

	public void setContractStatusDate(java.sql.Date contractStatusDate) {
		this.contractStatusDate = contractStatusDate;
	}

	public String getIncentiveOptionName() {
		return incentiveOptionName;
	}

	public void setIncentiveOptionName(String incentiveOptionName) {
		this.incentiveOptionName = incentiveOptionName;
	}

	public String getIncentiveOptionDesc() {
		return incentiveOptionDesc;
	}

	public void setIncentiveOptionDesc(String incentiveOptionDesc) {
		this.incentiveOptionDesc = incentiveOptionDesc;
	}

	public java.sql.Date getContractStatusAchievedDate() {
		return contractStatusAchievedDate;
	}

	public void setContractStatusAchievedDate(
			java.sql.Date contractStatusAchievedDate) {
		this.contractStatusAchievedDate = contractStatusAchievedDate;
	}

	

			
}

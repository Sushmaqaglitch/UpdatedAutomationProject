/* $Id$ */

package com.healthpartners.service.imfs.rules;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.ActivityCollection;
import com.healthpartners.service.imfs.dto.ActivityDefinition;
import com.healthpartners.service.imfs.dto.ActivityIncentive;
import com.healthpartners.service.imfs.dto.CheckmarkDetail;
import com.healthpartners.service.imfs.dto.CheckmarkRequirement;
import com.healthpartners.service.imfs.dto.ContractHistory;
import com.healthpartners.service.imfs.dto.ContractIncentiveStatus;
import com.healthpartners.service.imfs.dto.ContractProgramIncentiveTO;
import com.healthpartners.service.imfs.dto.ContractTO;
import com.healthpartners.service.imfs.dto.CoverageDatesTO;
import com.healthpartners.service.imfs.dto.GenericStatusType;
import com.healthpartners.service.imfs.dto.IncentivePackageRuleDetail;
import com.healthpartners.service.imfs.dto.IncentivePackageRuleRequirement;
import com.healthpartners.service.imfs.dto.IncentiveParticipant;
import com.healthpartners.service.imfs.dto.IncentiveRequirement;
import com.healthpartners.service.imfs.dto.IncentiveStatusActivityDetail;
import com.healthpartners.service.imfs.dto.IncentiveStatusActivityDetailContribution;
import com.healthpartners.service.imfs.dto.LookUpValueCode;
import com.healthpartners.service.imfs.dto.MemberActivity;
import com.healthpartners.service.imfs.dto.MemberContractProgramTO;
import com.healthpartners.service.imfs.dto.MemberProgramIncentiveTO;
import com.healthpartners.service.imfs.dto.MemberTO;
import com.healthpartners.service.imfs.dto.PackageHistory;
import com.healthpartners.service.imfs.dto.ParticipationGroup;
import com.healthpartners.service.imfs.dto.ParticipationGroupDetail;
import com.healthpartners.service.imfs.dto.ParticipationGroupRequirement;
import com.healthpartners.service.imfs.dto.PersonActivityIncentive;
import com.healthpartners.service.imfs.dto.PersonIncentiveStatus;
import com.healthpartners.service.imfs.dto.PersonPackage;
import com.healthpartners.service.imfs.dto.PersonProgramActivityIncentiveStatus;
import com.healthpartners.service.imfs.dto.PersonRelationship;
import com.healthpartners.service.imfs.dto.ProgramContributionGrid;
import com.healthpartners.service.imfs.dto.ProgramIncentiveOption;
import com.healthpartners.service.imfs.dto.QualificationCheckmark;
import com.healthpartners.service.imfs.dto.QualificationOverride;
import com.healthpartners.service.imfs.dto.Risk;
import com.healthpartners.service.imfs.dto.SubgroupHistory;
import org.apache.log4j.Logger;

/**
 * Adapter for a <code>Member</code> object and <code>Person</code> object that
 * provides a view of the data that is easier to integrate with rules decision
 * table.
 * 
 * @author pbhenninger
 */
public class MemberAdapter {

	protected final Logger logger = Logger.getLogger(this.getClass());

	protected final String familyCountCode = "FAM";
	protected final String participantCountCode = "PART";

	// relative members - spouse, dom
	private Collection<MemberAdapter> relatedMembers;

	// Map with <programID, member program status>
	private Map<Integer, String> memberBusinessProgramStatusMap = new HashMap<Integer, String>();

	// Map with <programID, member contract status>
	private Map<Integer, String> memberContractStatusMap = new HashMap<Integer, String>();
	private Map<Integer, ContractProgramIncentiveTO> memberContractIncentiveStatusMap = new HashMap<Integer, ContractProgramIncentiveTO>();

	// Map with <programID, member exemption>
	private Map<Integer, String> memberExemptionMap = new HashMap<Integer, String>();
	private Map<Integer, String> memberManualExemptionMap = new HashMap<Integer, String>();

	// Map with <programID, member exemption reason>
	private Map<Integer, String> memberExemptionReasonMap = new HashMap<Integer, String>();

	ArrayList<PersonActivityIncentive> existingPersonActivityIncentives = new ArrayList<PersonActivityIncentive>();
	ArrayList<PersonActivityIncentive> existingRelatedPersonActivityIncentives = new ArrayList<PersonActivityIncentive>();

	private ArrayList<PersonActivityIncentive> personActivityIncentives = new ArrayList<PersonActivityIncentive>();

	private ArrayList<ContractProgramIncentiveTO> contractProgramIncentives = new ArrayList<ContractProgramIncentiveTO>();
	private ArrayList<MemberProgramIncentiveTO> existingRelatedMemberProgramIncentives = new ArrayList<MemberProgramIncentiveTO>();
	private ArrayList<MemberProgramIncentiveTO> memberProgramIncentives = new ArrayList<MemberProgramIncentiveTO>();
	private ArrayList<MemberProgramIncentiveTO> newMemberProgramIncentives = new ArrayList<MemberProgramIncentiveTO>();
	private ArrayList<MemberActivity> memberActivitiesMeetingRequirements = new ArrayList<MemberActivity>();
	private Map<Integer, ArrayList<MemberActivity>> memberActivitiesMeetingRequirementsMap = new HashMap<Integer, ArrayList<MemberActivity>>();

	private Calendar currentDateTime;

	// all risk groups
	private ArrayList<LookUpValueCode> riskGroupCodes;

	private ArrayList<Risk> risks;

	// contract history
	private ArrayList<ContractHistory> contractHistories;

	// package history
	private ArrayList<PackageHistory> packageHistories;

	// sub group history
	private ArrayList<SubgroupHistory> subgroupHistories;

	private SimpleDateFormat fmt = new SimpleDateFormat("MM/dd/yyyy");

	// here is the member of this adapter
	private MemberTO member;

	private Calendar coverageEffectiveDate;

	private boolean activityCompletionPeriodEnabled;

	private Map<Integer, Integer> qualificationCheckmarkMap = new HashMap<Integer, Integer>();
	private ArrayList<PersonPackage> personPackages = new ArrayList<PersonPackage>();

	private ArrayList<QualificationCheckmark> participatingQualificationCheckmarks = new ArrayList<QualificationCheckmark>();

	private Map<Integer, PersonIncentiveStatus> personIncentiveStatusMap = new HashMap<Integer, PersonIncentiveStatus>();
	private Map<Integer, ContractIncentiveStatus> contractIncentiveStatusMap = new HashMap<Integer, ContractIncentiveStatus>();
	private Map<Integer, MemberProgramIncentiveTO> memberBasedIncentiveStatusMap = new HashMap<Integer, MemberProgramIncentiveTO>();		

	/**
	 * contructor with MemberTO
	 * 
	 * @param member
	 */
	public MemberAdapter(MemberTO member) {
		super();
		this.member = member;
	}

	public MemberTO getMember() {
		return member;
	}

	/**
	 * fetches calculated new member status
	 *
	 * @param businessProgramId
	 * @return
	 */
	public String getNewMemberStatus(int businessProgramId) {
		return memberBusinessProgramStatusMap.get(businessProgramId);
	}

	/**
	 * set new member status
	 * 
	 * @param businessProgramId
	 * @param newMemberStatus
	 * @return
	 */
	public void setNewMemberStatus(int businessProgramId, String newMemberStatus) {
		memberBusinessProgramStatusMap.put(businessProgramId, newMemberStatus);
	}

	/**
	 * fetches calculated new Contract status
	 * 
	 * @param programIncentiveOptionID
	 * @return
	 */
	public String getNewContractStatus(int programIncentiveOptionID) {
		return memberContractStatusMap.get(programIncentiveOptionID);
	}

	public ContractProgramIncentiveTO getNewContractIncentiveStatus(
			int programIncentiveOptionID) {
		return memberContractIncentiveStatusMap.get(programIncentiveOptionID);
	}

	public String getExemptionReason(int businessProgramId) {
		return memberExemptionReasonMap.get(businessProgramId);
	}

	public Collection<MemberAdapter> getRelatedMembers() {
		return relatedMembers;
	}

	public void setRelatedMembers(Collection<MemberAdapter> relatedMembers) {
		this.relatedMembers = relatedMembers;
	}

	/**
	 * Retrieves the person identifier.
	 * 
	 * @return the person identifier
	 */
	public int getId() {
		int result = member.getPersonID().intValue();
		return result;
	}

	public int getPHId() {
		int result = member.getPHpersonID().intValue();
		return result;
	}

	/**
	 * Determines whether the member is eligible for the Business program of
	 * group / site
	 * 
	 * @param program
	 *            the business program
	 * @return true if the member is eligible for the program, false otherwise
	 */
	public boolean isEligibleForBusinessProgram(BusinessProgramAdapter program) {
		boolean result = false;

		if (program == null || program.getBusinessProgramId() == null) {
			logger.error("Referenced business program or identifier is null");
			result = false;
		} else {
			MemberContractProgramTO memberContractProgram = null;
			if (program.getBusinessProgram().isEvaluateTermedContract()) {
				MemberContractProgramTO memberTermedContractProgram = null;
				if (member.getMemberTermedContractPrograms() != null
						&& program.getBusinessProgramId() != null) {
					Iterator<MemberContractProgramTO> itr = member
							.getMemberTermedContractPrograms().iterator();
					while (itr.hasNext()) {
						memberTermedContractProgram = itr.next();
						if (memberTermedContractProgram != null
								&& memberTermedContractProgram
										.getBusinessProgramID() != null
								&& program.getBusinessProgramId().intValue() == memberTermedContractProgram
										.getBusinessProgramID().intValue()) {
							result = true;
							break;
						}
					}
				}

			} else if (member.getMemberContractPrograms() != null
					&& program.getBusinessProgramId() != null) {
				Iterator<MemberContractProgramTO> itr = member
						.getMemberContractPrograms().iterator();
				while (itr.hasNext()) {
					memberContractProgram = itr.next();
					if (memberContractProgram != null
							&& memberContractProgram.getBusinessProgramID() != null
							&& program.getBusinessProgramId().intValue() == memberContractProgram
									.getBusinessProgramID().intValue()) {
						result = true;
						break;
					}
				}
			}
		}

		return result;
	}

	/**
	 * Determines whether the member should receive an automatic exemption.
	 * 
	 * @param program
	 *            an instance of BusinessProgramAdapter
	 * @return true if the member should receive an exemption, false otherwise
	 */
	public boolean isMemberExemptionChanging(BusinessProgramAdapter program) {
		boolean result = false;

		Integer businessProgramId = program.getBusinessProgramId();

		// check for Manual exemption -
		if (isMemberGotAnyManualExemption(program)) {
			// no need to calulate for any automatic exemption
			result = false;

			// When member is exempt, need to populate the qualification
			// checkmark ID with a
			// default value.
			ArrayList<QualificationCheckmark> lQualificationCheckmarks = (ArrayList<QualificationCheckmark>) program
					.getQualificationCheckmarks();

			if (lQualificationCheckmarks != null
					&& lQualificationCheckmarks.size() > 0) {
				// EV 58085 - commented out populating checkmark with default.
				// qualificationCheckmarkMap.put(program.getBusinessProgramId()
				// ,
				// lQualificationCheckmarks.get(0).getQualificationCheckmarkID());
			}
		} else if (isMemberJoinedAfterGroupNewHireDate(program)) {
			if (!isMemberJoinedAfterProgramEndDate(program)) {
				// The member join the contract after the new hire date, but not
				// after program end date.

				result = true;
				// memberExemptionReasonMap.put(program.getBusinessProgramId(),
				// BPMConstants.BPM_EXEMPTION_REASON_JOINDT_AFTER_GRPNEWHIREDT);
			}
		} else if (isSiteAndPackageExempt(program)) {
			result = true;
			// memberExemptionReasonMap.put(program.getBusinessProgramId(),
			// BPMConstants.BPM_EXEMPTION_REASON_TRANSFER_AFTER_GRPNEWHIREDT);
		}
		/*
		 * - removed Golpasses - per rules version 1.25 else if
		 * (isContractGotManualGoldPass(program)) { // if contract status is
		 * gold pass, issue exemption result = true;
		 * memberExemptionReasonMap.put(program.getBusinessProgramId(),
		 * BPMConstants.BPM_EXEMPTION_REASON_CONTRACT_HAS_GOLDPASS); }
		 */

		if (result) {
			// put in map
			// memberExemptionMap.put(businessProgramId,
			// BPMConstants.OVERRIDE_CODE_EXEMPTION);

			// When member is exempt, need to populate the qualification
			// checkmark ID with a
			// default value.
			ArrayList<QualificationCheckmark> lQualificationCheckmarks = (ArrayList<QualificationCheckmark>) program
					.getQualificationCheckmarks();

			if (lQualificationCheckmarks != null
					&& lQualificationCheckmarks.size() > 0) {
				// EV 58085 - commented out populating checkmark with default.
				// qualificationCheckmarkMap.put(program.getBusinessProgramId()
				// ,
				// lQualificationCheckmarks.get(0).getQualificationCheckmarkID());
			}
		}

		logger.info("@@isMemberExemptionChanging=" + result + ", personID="
				+ member.getPersonID() + ", programID=" + businessProgramId);
		return result;
	}

	/**
	 * Calculate member status change based on program type.
	 * 
	 * @param program
	 *            an instance of BusinessProgramAdapter
	 * @return true if the member status should be changed, false otherwise
	 */
	public boolean isMemberStatusChanging(BusinessProgramAdapter program) {
		boolean result = false;

		if (BPMConstants.PROGRAM_TYPE_CODE_SMART_STEPS.equals(program
				.getBusinessProgramTypeCodeId())) {
			result = isMemberStatusChangingWithinSmartSteps(program);
		} else if (BPMConstants.PROGRAM_TYPE_CODE_HEALTY_BENEFITS
				.equals(program.getBusinessProgramTypeCodeId())
				|| BPMConstants.PROGRAM_TYPE_CODE_JOURNEYWELL.equals(program
						.getBusinessProgramTypeCodeId())) {
			result = isMemberStatusChangingWithinHealthyBenefits(program);
		}

		return result;
	}

	/**
	 * Determines whether the member status should be changed for SmartSteps.
	 * The calculation is based upon the member's activity history and external
	 * factors (such as the current date).
	 * 
	 * @param program
	 *            an instance of BusinessProgramAdapter
	 * @return true if the member status should be changed, false otherwise
	 */
	public boolean isMemberStatusChangingWithinSmartSteps(
			BusinessProgramAdapter program) {

		boolean result = false;
		// Retrieve the current member status.
		String memberStatus = null;
		Integer businessProgramId = program.getBusinessProgramId();
		if (memberBusinessProgramStatusMap.containsKey(businessProgramId)) {
			memberStatus = memberBusinessProgramStatusMap
					.get(businessProgramId);
		} else {
			memberStatus = member.getMemberStatusCodeValue(businessProgramId);
			memberBusinessProgramStatusMap.put(businessProgramId, memberStatus);
		}

		// Default the new member status to ELIGIBLE.
		String newMemberStatus = BPMConstants.MEMBER_STATUS_ELIGIBLE;

		// 03-17-09 Since the web can not handle the combo-Exempt statuses for
		// Smart Steps, for now set the status to Member Completed for all Smart
		// Steps Exempts.
		if (isMemberGotAnyExemption(program)) {
			newMemberStatus = BPMConstants.MEMBER_STATUS_PROGRAM_COMPLETED;
		}

		// member status change based on activity
		newMemberStatus = calculateMemberStatusByActivity(newMemberStatus,
				program);
		// program window closed - compute for did not complete program
		// qualification really means program met by completing all activities
		// required.
		if (isMemberNotQualifiedForProgram(program, newMemberStatus)) {
			// If the member has any exemptions, status is EXEMPT
			if (isMemberGotAnyExemption(program)) {
				newMemberStatus = BPMConstants.MEMBER_STATUS_PROGRAM_COMPLETED;
			} else {
				// Without exemptions, member status is DID NOT COMPLETE
				// PROGRAM.
				newMemberStatus = BPMConstants.MEMBER_STATUS_PROGRAM_NOT_COMPLETED;
			}
		}

		// If the calculated member status changed, save the new status.
		if (!newMemberStatus.equals(memberStatus)) {
			memberBusinessProgramStatusMap.put(businessProgramId,
					newMemberStatus);
			result = true;
		}

		logger.info("@@isMemberStatusChangingWithinSmartSteps=" + result
				+ ", newMemberStatus=" + newMemberStatus + ", personID="
				+ member.getPersonID() + ", programID=" + businessProgramId);

		return result;
	}

	/**
	 * Determines whether the member status should be changed for SmartSteps.
	 * The calculation is based upon the member's activity history and external
	 * factors (such as the current date).
	 * 
	 * @param program
	 *            an instance of BusinessProgramAdapter
	 * @return true if the member status should be changed, false otherwise
	 */
	public boolean isMemberStatusChangingWithinHIP(
			BusinessProgramAdapter program) {

		boolean result = false;
		// Retrieve the current member status.
		String memberStatus = null;
		Integer businessProgramId = program.getBusinessProgramId();
		if (memberBusinessProgramStatusMap.containsKey(businessProgramId)) {
			memberStatus = memberBusinessProgramStatusMap
					.get(businessProgramId);
		} else {
			memberStatus = member.getMemberStatusCodeValue(businessProgramId);
			memberBusinessProgramStatusMap.put(businessProgramId, memberStatus);
		}

		// Default the new member status to ELIGIBLE.
		String newMemberStatus = BPMConstants.MEMBER_STATUS_ELIGIBLE;

		// 03-17-09 Since the web can not handle the combo-Exempt statuses for
		// HIP, for now set the status to Member Completed for all HIP Exempts.
		if (isMemberGotAnyExemption(program)) {
			newMemberStatus = BPMConstants.MEMBER_STATUS_QUALIFIED;
		}

		// member status change based on activity and task history.
		// Healthy Benefits and HIP use this method.
		newMemberStatus = calculateMemberStatusByActivityAndTaskHistory(
				newMemberStatus, program);
		// program window closed - compute for did not complete program
		// qualification really means program met by completing all activities
		// required.
		if (isMemberNotQualifiedForProgram(program, newMemberStatus)) {
			// If the member has any exemptions, status is EXEMPT
			if (isMemberGotAnyExemption(program)) {
				newMemberStatus = BPMConstants.MEMBER_STATUS_QUALIFIED;
			} else {
				// Without exemptions, member status is DID NOT COMPLETE
				// PROGRAM.
				newMemberStatus = BPMConstants.MEMBER_STATUS_DID_NOT_QUALIFY;
			}
		}

		// If the calculated member status changed, save the new status.
		if (!newMemberStatus.equals(memberStatus)) {
			memberBusinessProgramStatusMap.put(businessProgramId,
					newMemberStatus);
			result = true;
		}

		logger.info("@@isMemberStatusChangingWithinHIP=" + result
				+ ", newMemberStatus=" + newMemberStatus + ", personID="
				+ member.getPersonID() + ", programID=" + businessProgramId);

		return result;
	}

	/**
	 * Determines whether the member status should be changed for Healthy
	 * Benefits program. The calculation is based upon the member's activity
	 * history, task history and external factors (such as the current date).
	 * 
	 * @param program
	 *            an instance of BusinessProgramAdapter
	 * @return true if the member status should be changed, false otherwise
	 */
	public boolean isMemberStatusChangingWithinHealthyBenefits(
			BusinessProgramAdapter program) {

		   boolean result = false;
		   // Retrieve the current member status.
		   String memberStatus = null;
		
			Integer businessProgramId = program.getBusinessProgramId();
			if (memberBusinessProgramStatusMap.containsKey(businessProgramId)) {
				memberStatus = memberBusinessProgramStatusMap
						.get(businessProgramId);
			} else {
				memberStatus = member.getMemberStatusCodeValue(businessProgramId);
				memberBusinessProgramStatusMap.put(businessProgramId, memberStatus);
			}
	
			// Default the new member status to ELIGIBLE.
			String newMemberStatus = BPMConstants.MEMBER_STATUS_ELIGIBLE;
	
			if (isMemberGotAnyExemption(program)) {
				newMemberStatus = BPMConstants.MEMBER_STATUS_EXEMPT;
			}
	
			// Should the member status change based on activity, Task history?
			newMemberStatus = calculateMemberStatusByActivityAndTaskHistory(
					newMemberStatus, program);
			// qualifcation window closed - compute for did not qualify
			if (isMemberNotQualifiedForProgram(program, newMemberStatus)) {
				// If the member has any exemptions, status is EXEMPT
				if (isMemberGotAnyExemption(program)) {
					newMemberStatus = BPMConstants.MEMBER_STATUS_EXEMPT;
				} else {
					// Without exemptions, member status is DID NOT QUALIFY.
					newMemberStatus = BPMConstants.MEMBER_STATUS_DID_NOT_QUALIFY;
				}
			}											
	
			// If the calculated member status changed, save the new status.
			if (!newMemberStatus.equals(memberStatus)) {
				memberBusinessProgramStatusMap.put(businessProgramId,
						newMemberStatus);
				result = true;
				
				/*
				 * EV 85338 - Commented out for Dec 18 - 2014 release. 
				 * This needs more work to change the single member status
				 * to multiple member statuses for each incentive.
				for(ProgramIncentiveOption lProgramIncentiveOption : lProgramIncentiveOptions)
				{
					boolean lRoleParticipatesInIncentive = determineParticipation(
							lProgramIncentiveOption.getParticipationGroup(),
							program);					
					
					if (lRoleParticipatesInIncentive) 
					{
						    findOrCreatePersonIncentiveStatus(program
								, lProgramIncentiveOption.getProgramIncentiveOptionID()
								, 0
								, newMemberStatus);
						
						logger.info("@@isMemberStatusChangingWithinHealthyBenefits=" + result
								+ ", newMemberStatus=" + newMemberStatus + ", personID="
								+ member.getPersonID() + ", programIncentiveOptionID=" + lProgramIncentiveOption.getProgramIncentiveOptionID());
			        }
		        }
		        * EV 85338 - Commented out for Dec 18 - 2014 release.
		        */
	     }

		return result;
	}

	/**03202203
	 * Determines whether the contract status should be changed.
	 * 
	 * @param program
	 *            an instance of BusinessProgramAdapter
	 * @return true if the contract status should be changed, false otherwise
	 */
	public boolean isContractStatusChanging(BusinessProgramAdapter program) 
	{
		boolean result = false;
		String contractStatus = null;
		String newContractStatus = null;


		determineMemberAlignmentWithProgramIncentiveOptionUsingRelationshipNPackage(personPackages, (ArrayList<ProgramIncentiveOption>)program
					.getProgramIncentiveOptions(), program);
		
		for (ProgramIncentiveOption lProgramIncentiveOption : program.getProgramIncentiveOptions()) 
		{
			// EV 95424
			// This program-incentive-option has passed the
			// determineMemberAlignmentWithProgramIncentiveOptionUsingRelationshipNPackage check, so it is an ACTIVE incentive option.
			if(BPMConstants.PROGRAM_INCENTIVE_OPTION_ACTIVATION_ACTIVE.equalsIgnoreCase(lProgramIncentiveOption.getActivationStatusCode()))
			{	
				if (memberContractStatusMap.containsKey(lProgramIncentiveOption
						.getProgramIncentiveOptionID())) {
					contractStatus = memberContractStatusMap
							.get(lProgramIncentiveOption
									.getProgramIncentiveOptionID());
				} else {
					contractStatus = getMember().getContractStatusCodeValue(
							lProgramIncentiveOption.getProgramIncentiveOptionID());
					memberContractStatusMap.put(
							lProgramIncentiveOption.getProgramIncentiveOptionID(),
							contractStatus);
				}
	
				// default to ELIGIBLE
				newContractStatus = BPMConstants.CONTRACT_STATUS_ELIGIBLE;
				
				newContractStatus = calculateContractStatusFromGroupParticipationRequirements(
						newContractStatus, program, lProgramIncentiveOption);
	
				// If the calculated contract status changed, save the new status.
				if (!newContractStatus.equals(contractStatus)) {
					memberContractStatusMap.put(
							lProgramIncentiveOption.getProgramIncentiveOptionID(),
							newContractStatus);
					result = true;
				}
			}
			else
			{
				newContractStatus = BPMConstants.CONTRACT_STATUS_ELIGIBLE;
			}

			// EV 58085						
			ContractIncentiveStatus lContractIncentiveStatus = createContractIncentiveStatus(
					program,
					lProgramIncentiveOption.getProgramIncentiveOptionID(),
					0, newContractStatus
					, lProgramIncentiveOption.getActivationStatusCode());
			contractIncentiveStatusMap.put(
					lProgramIncentiveOption.getProgramIncentiveOptionID(),
					lContractIncentiveStatus);
			// EV 58085
		

			logger.info("@@isContractStatusChanging=" + result
					+ ", newContractStatus=" + newContractStatus
					+ ", personID=" + member.getPersonID() + ", programID = "
					+ program.getBusinessProgramId()
					+ ", programIncentiveOptionID="
					+ lProgramIncentiveOption.getProgramIncentiveOptionID());
		}

		return result;

	}

	/**
	 * Calculate contract-program-incentive status.
	 * 
	 * @param program
	 * @return
	 */
	public boolean isContractIncentiveStatusChanging(
			BusinessProgramAdapter program) {
		calculateContractIncentiveStatus(program);
		return true;
	}

	public boolean isMemberIncentiveStatusChanging(
			BusinessProgramAdapter program) {
		calculateMemberIncentiveStatus(program);
		return true;
	}

	/**
	 * calculate member status based on activity and task history
	 * 
	 * @param program
	 * @param memberStatus
	 * @return memberStatus
	 */
	private String calculateMemberStatusByActivityAndTaskHistory(
			String memberStatus, BusinessProgramAdapter program) {

		// logger.info("@@calculateMemberStatusByActivityAndTaskHistory called");
		// default to
		String newMemberStatus = memberStatus;

		// health assesment activity - completed?
		boolean healthAssesmentCompleted = isHealthAssesmentProgramActivityCompleted(program);

		// any activity - started?
		boolean programActivityStarted = isProgramActivityStarted(program);

		// any activity - completed ?
		boolean programActivityCompleted = isProgramActivityCompleted(program);

		boolean programQualificationPeriodEnded = hasProgramEnded(program);

		logger.info("HA Completed=" + healthAssesmentCompleted
				+ ", Activity Started=" + programActivityStarted
				+ ", Activity Completed=" + programActivityCompleted);

		// check for hold for contact

		if (isHoldForContact(program, programActivityStarted,
				programActivityCompleted, healthAssesmentCompleted,
				programQualificationPeriodEnded)) {
			// Hold
			newMemberStatus = BPMConstants.MEMBER_STATUS_HOLD_FOR_CONTACT;
		} else {
			if (healthAssesmentCompleted) {
				// HA completed
				newMemberStatus = BPMConstants.MEMBER_STATUS_HA_COMPLETED;
			}
			if (healthAssesmentCompleted && programActivityStarted) {
				// HA completed and activity started
				newMemberStatus = BPMConstants.MEMBER_STATUS_ACTIVE;
			}

			if (checkQualificationCheckmarks(program) == true) {
				// HA completed and activity completed
				newMemberStatus = BPMConstants.MEMBER_STATUS_QUALIFIED;
			}
		}

		if (isMemberGotAnyExemption(program)) {
			/*
			if (BPMConstants.MEMBER_STATUS_ELIGIBLE.equals(newMemberStatus)) {
				newMemberStatus = BPMConstants.MEMBER_STATUS_EXEMPT_ELIGIBLE;
			}
			if (BPMConstants.MEMBER_STATUS_HOLD_FOR_CONTACT
					.equals(newMemberStatus)) {
				newMemberStatus = BPMConstants.MEMBER_STATUS_EXEMPT_HOLD;
			}
			if (BPMConstants.MEMBER_STATUS_HA_COMPLETED.equals(newMemberStatus)) {
				newMemberStatus = BPMConstants.MEMBER_STATUS_EXEMPT_HA_COMPLETED;
			}
			if (BPMConstants.MEMBER_STATUS_ACTIVE.equals(newMemberStatus)) {
				newMemberStatus = BPMConstants.MEMBER_STATUS_EXEMPT_ACTIVE;
			}
			if (BPMConstants.MEMBER_STATUS_QUALIFIED.equals(newMemberStatus)) {
				newMemberStatus = BPMConstants.MEMBER_STATUS_EXEMPT_QUALIFIED;
			}
			*/
			
			newMemberStatus = BPMConstants.MEMBER_STATUS_EXEMPT;
		}

		return newMemberStatus;
	}

	/**
	 * calculate member status based on activity
	 * 
	 * @param program
	 * @param memberStatus
	 * @return memberStatus
	 */
	private String calculateMemberStatusByActivity(String memberStatus,
			BusinessProgramAdapter program) {

		logger.info("@@calculateMemberStatusByActivity called");
		// default to
		String newMemberStatus = memberStatus;

		// health assesment activity - completed?
		boolean healthAssesmentCompleted = isHealthAssesmentProgramActivityCompleted(program);

		// any activity - started?
		boolean programActivityStarted = isProgramActivityStarted(program);

		// any activity - completed ?
		boolean programActivityCompleted = isProgramActivityCompleted(program);

		logger.info("@@healthAssesmentCompleted=" + healthAssesmentCompleted);
		logger.info("@@programActivityStarted=" + programActivityStarted);
		logger.info("@@programActivityCompleted=" + programActivityCompleted);

		if (healthAssesmentCompleted) {
			// HA completed
			newMemberStatus = BPMConstants.MEMBER_STATUS_HA_COMPLETED;
		}
		if (healthAssesmentCompleted && programActivityStarted) {
			// HA completed and activity started
			newMemberStatus = BPMConstants.MEMBER_STATUS_ACTIVE;
		}

		if (checkQualificationCheckmarks(program) == true) {
			// HA completed and activity completed
			newMemberStatus = BPMConstants.MEMBER_STATUS_PROGRAM_COMPLETED;
		}

		if (isMemberGotAnyExemption(program)) {
			/*
			if (BPMConstants.MEMBER_STATUS_ELIGIBLE.equals(newMemberStatus)) {
				newMemberStatus = BPMConstants.MEMBER_STATUS_EXEMPT_ELIGIBLE;
			}
			if (BPMConstants.MEMBER_STATUS_HA_COMPLETED.equals(newMemberStatus)) {
				newMemberStatus = BPMConstants.MEMBER_STATUS_EXEMPT_HA_COMPLETED;
			}
			if (BPMConstants.MEMBER_STATUS_ACTIVE.equals(newMemberStatus)) {
				newMemberStatus = BPMConstants.MEMBER_STATUS_EXEMPT_ACTIVE;
			}
			*/
			
			newMemberStatus = BPMConstants.MEMBER_STATUS_EXEMPT;
			
			if (BPMConstants.MEMBER_STATUS_PROGRAM_COMPLETED
					.equals(newMemberStatus)) {
				// 03-17-09 Since the web can not handle the combo-Exempt
				// statuses for
				// Smart Steps, for now set the status to Member Completed for
				// all Smart Steps Exempts.
				newMemberStatus = BPMConstants.MEMBER_STATUS_PROGRAM_COMPLETED;
			}
		}

		return newMemberStatus;
	}

	/**
	 * Decides wether an eligible program actvity has been started
	 * 
	 * @param program
	 */
	public boolean isProgramActivityStarted(BusinessProgramAdapter program) {

		boolean result = false;

		// disease mgmt activity
		if (isDiseaseManagementProgramActivityStarted(program)) {
			result = true;
		} else {

			Collection<MemberActivity> otherActivities = member
					.getNonDMNonHAMemberActivities(program
							.getBusinessProgramId(), program
							.getBusinessProgram().isEvaluateTermedContract());
			Iterator<MemberActivity> iter = otherActivities.iterator();
			while (iter.hasNext()) {
				MemberActivity activity = iter.next();
				// Retrieve eligible activity details.
				String activityName = activity.getActivity().getName();
				String activityStatus = activity.getActivityStatus()
						.getStatusCodeValue();
				if (isActivityStarted(activityName, activityStatus)) {
					result = true;
				}
			} // while
		}

		// logger.info("@isProgramActivityStarted=" + result);
		return result;
	}

	/**
	 * Decides wether an eligible program actvity has been started
	 * 
	 * @param program
	 */
	public boolean isProgramActivityCompleted(BusinessProgramAdapter program) {

		boolean result = false;

		// disease mgmt activity
		if (isDiseaseManagementProgramActivityCompleted(program)) {
			result = true;
		} else {
			Collection<MemberActivity> otherActivities = member
					.getNonDMNonHAMemberActivities(program
							.getBusinessProgramId(), program
							.getBusinessProgram().isEvaluateTermedContract());
			Iterator<MemberActivity> iter = otherActivities.iterator();
			while (iter.hasNext()) {
				MemberActivity activity = iter.next();
				// Retrieve eligible activity details.
				String activityName = activity.getActivity().getName();
				String activityStatus = activity.getActivityStatus()
						.getStatusCodeValue();
				if (isActivityCompleted(activityName, activityStatus)) {
					result = true;
				}
			} // while
		}
		// logger.info("@isProgramActivityCompleted=" + result);
		return result;
	}

	/**
	 * Determines if we are past the program qualification end date.
	 * 
	 * @param program
	 * @return
	 */
	protected boolean hasProgramEnded(BusinessProgramAdapter program) {
		Calendar lToday = Calendar.getInstance();
		
		BPMUtils.setTimeToZero(lToday);
		BPMUtils.setTimeToZero(program.getBusinessProgram().getQualificationWindowEndDate());

		if (program.isEligibleProgramActivityOverrideExist()) {
			// pre and/or post enrollment activities exist so allow status calc
			// to take place after the qualificaiton period.

		} else if (lToday.after(program.getBusinessProgram()
				.getQualificationWindowEndDate())) {
			return true;
		}

		return false;
	}

	/**
	 * Decides wether an HealthAssesment program actvity has been started
	 * 
	 * @param program
	 */
	public boolean isHealthAssesmentProgramActivityCompleted(
			BusinessProgramAdapter program) {
		boolean result = false;
		Collection<MemberActivity> haActivities = member
				.getHealthAssesmentMemberActivities(program
						.getBusinessProgramId(), program.getBusinessProgram()
						.isEvaluateTermedContract());
		Iterator<MemberActivity> iter = haActivities.iterator();
		while (iter.hasNext()) {
			MemberActivity activity = iter.next();
			// Retrieve eligible activity details.
			String activityName = activity.getActivity().getName();
			String activityStatus = activity.getActivityStatus()
					.getStatusCodeValue();
			if (isActivityCompleted(activityName, activityStatus)) {
				result = true;
			}
		} // end while

		// logger.info("isHealthAssesmentProgramActivityCompleted=" + result);
		return result;
	}

	/**
	 * Determines whether the member has the specified member status. The status
	 * names can be found in the LU_VAL column in the LUV table, where the
	 * LU_GRP is "BPM_MEMBER_STATUS".
	 * 
	 * @param status
	 *            a status name
	 * @return true if the member has the specified member status, false
	 *         otherwise
	 */
	public boolean havingMemberStatus(int businessProgramId, String status) {
		boolean result = false;

		String currentStatus = member
				.getMemberStatusCodeValue(businessProgramId);
		result = ((currentStatus == null && status == null) || currentStatus
				.equalsIgnoreCase(status));

		return result;
	}

	/**
	 * Determines whether the member does not have the specified member status.
	 * The status names can be found in the LU_VAL column in the LUV table,
	 * where the LU_GRP is "BPM_MEMBER_STATUS".
	 * 
	 * @param status
	 *            a status name
	 * @return true if the member does not have the specified member status,
	 *         false otherwise
	 */
	public boolean notHavingMemberStatus(int businessProgramId, String status) {
		boolean result = !havingMemberStatus(businessProgramId, status);
		return result;
	}

	/**
	 * Determines whether the completed Health Assessment had an outcome of
	 * "High Risk".
	 * 
	 * @param activity
	 *            the MemberActivityt
	 * @return true if the HA outcome is "High Risk", false otherwise
	 */
	public boolean isHealthAssessmentOutcomeHighRisk(MemberActivity activity) {
		boolean result = false;
		String activityName = activity.getActivity().getName();
		String activityStatus = activity.getActivityStatus()
				.getStatusCodeValue();

		// Is the HA activity status "Complete"?
		if (isHeathAssesmentCompleted(activityName, activityStatus)) {
			String activityOutcome = activity.getActivityStatus().getOutCome();
			logger.info("@ activityOutcome = " + activityOutcome);
			// Is the activity outcome of type "High Risk"?
			if (activityOutcome != null
					&& activityOutcome
							.contains(BPMConstants.MEMBER_STATUS_RSN_HIGH_RISK)) {
				result = true;
			}
		}
		logger.info("@isHealthAssessmentOutcomeHighRisk=" + result);
		return result;
	}

	/**
	 * Determines whether an eligible activity been started.
	 * 
	 * @param activityName
	 *            the name of the activity event
	 * @param activityStatus
	 *            the status of the activity event
	 * @return true if the eligible activity been started, false otherwise
	 */
	public boolean isActivityStarted(String activityName, String activityStatus) {
		boolean result = false;

		// Is the activity status "Active"?
		if (BPMConstants.ACTIVITY_STATUS_ACTIVE.equals(activityStatus)
				|| BPMConstants.ACTIVITY_STATUS_INACTIVE.equals(activityStatus)
				|| BPMConstants.ACTIVITY_STATUS_COMPLETE.equals(activityStatus)
				|| BPMConstants.ACTIVITY_STATUS_MET.equals(activityStatus)) { // issue
			// #30
			result = true;
		}
		// logger.info("@isActivityStarted=" + result);
		return result;
	}

	/**
	 * Determines whether an eligible activity been completed.
	 * 
	 * @param activityName
	 *            the name of the activity event
	 * @param activityStatus
	 *            the status of the activity event
	 * @return true if the eligible activity been completed, false otherwise
	 */
	public boolean isActivityCompleted(String activityName,
			String activityStatus) {
		boolean result = false;

		// Is the activity status "Complete"?
		if (BPMConstants.ACTIVITY_STATUS_COMPLETE.equals(activityStatus)
				|| BPMConstants.ACTIVITY_STATUS_WAIVE.equals(activityStatus)
				|| BPMConstants.ACTIVITY_STATUS_EXEMPT.equals(activityStatus)
				|| BPMConstants.ACTIVITY_STATUS_MET.equals(activityStatus)) {
			result = true;
		} else if (BPMConstants.ACTIVITY_HEALTHY_BENEFITS_HA
				.equals(activityName)
				&& BPMConstants.ACTIVITY_STATUS_PENDING.equals(activityStatus)) {
			result = true;
		}
		// logger.info("@isActivityCompleted=" + result);
		return result;
	}

	/**
	 * If incentive is upon activity sign-up and activity status is active,
	 * return.
	 * 
	 * @return true if activity gets the incentive, false otherwise
	 */
	private boolean isActivityActiveByEnrollmentEnrollByDate(
			MemberActivity pMemberActivity, java.sql.Date effectiveDate, java.sql.Date completeByDeadlineDate, String incentiveRuleTypeCode) {

		boolean activityCountsForThisIncentive = false;
		if (BPMConstants.ACTIVITY_STATUS_ACTIVE
				.equalsIgnoreCase(pMemberActivity.getActivityStatus()
						.getStatusCodeValue())) {
			if (BPMConstants.BPM_INCENTIVE_ENROLL_ENROLL_BY
					.equals(incentiveRuleTypeCode)) {
				java.sql.Date statusEffectiveDateSql = BPMUtils
						.calendarToSqlDate(pMemberActivity.getActivityStatus()
								.getStatusEffectiveDate());
				if (completeByDeadlineDate != null) {
					if (statusEffectiveDateSql.after(completeByDeadlineDate)) {
						// false
					} else {
						activityCountsForThisIncentive = true;
					}
				}
			}
		}

		return activityCountsForThisIncentive;
	}

	/**
	 * If incentive is upon activity completion and activity status is complete,
	 * return.
	 * 
	 * @return true if activity gets the incentive, false otherwise
	 */

	private boolean isActivityCompletedByEnrollmentCompleteByDate(
			MemberActivity pMemberActivity, java.sql.Date completeByDeadlineDate, String incentiveRuleTypeCode) {
		// If incentive is upon activity completion and activity status is
		// complete,
		// return.
		boolean activityCountsForThisIncentive = false;

		if (isActivityCompleted(pMemberActivity.getActivity().getName(),
				pMemberActivity.getActivityStatus().getStatusCodeValue())) {
			if (BPMConstants.BPM_INCENTIVE_ENROLL_COMPLETE_BY
					.equals(incentiveRuleTypeCode)) {
				java.sql.Date statusEffectiveDateSql = BPMUtils
						.calendarToSqlDate(pMemberActivity.getActivityStatus()
								.getStatusEffectiveDate());
				if (completeByDeadlineDate != null) {
					if (statusEffectiveDateSql.after(completeByDeadlineDate)) {
						// false
					} else {
						activityCountsForThisIncentive = true;
					}
				}
			}
		}

		return activityCountsForThisIncentive;
	}

	/**
	 * If incentive is upon activity sign-up and activity status is complete and
	 * rule type of enroll by no filter is in place, incent. A rule type with no
	 * filter allows the activity to flow through the filtering service and on
	 * to the status calculation.
	 * 
	 * @return true if activity gets the incentive, false otherwise
	 */
	private boolean isActivityActiveByEnrollmentEnrollByDateNoFilter(
			MemberActivity pMemberActivity, java.sql.Date completeByDeadlineDate, String incentiveRuleTypeCode) {

		boolean activityCountsForThisIncentive = false;
		if (BPMConstants.ACTIVITY_STATUS_ACTIVE
				.equalsIgnoreCase(pMemberActivity.getActivityStatus()
						.getStatusCodeValue())) {
			if (BPMConstants.BPM_INCENTIVE_ENROLL_ENROLL_BY_NO_FILTER
					.equals(incentiveRuleTypeCode)) {
				java.sql.Date statusEffectiveDateSql = BPMUtils
						.calendarToSqlDate(pMemberActivity.getActivityStatus()
								.getStatusEffectiveDate());
				if (completeByDeadlineDate != null) {
					if (statusEffectiveDateSql.after(completeByDeadlineDate)) {
						// false
					} else {
						activityCountsForThisIncentive = true;
					}
				}
			}
		}

		return activityCountsForThisIncentive;
	}

	/**
	 * If incentive is upon activity completion and activity status is complete,
	 * return. A rule type with no filter allows the activity to flow through
	 * the filtering service and on to the status calculation.
	 * 
	 * @return true if activity gets the incentive, false otherwise
	 */

	private boolean isActivityCompletedByEnrollmentCompleteByDateNoFilter(
			MemberActivity pMemberActivity, java.sql.Date completeByDeadlineDate, String incentiveRuleTypeCode) {
		// If incentive is upon activity completion and activity status is
		// complete,
		// return.
		boolean activityCountsForThisIncentive = false;
		if (isActivityCompleted(pMemberActivity.getActivity().getName(),
				pMemberActivity.getActivityStatus().getStatusCodeValue())) {
			if (BPMConstants.BPM_INCENTIVE_ENROLL_COMPLETE_BY_NO_FILTER
					.equals(incentiveRuleTypeCode)) {
				java.sql.Date statusEffectiveDateSql = BPMUtils
						.calendarToSqlDate(pMemberActivity.getActivityStatus()
								.getStatusEffectiveDate());
				if (completeByDeadlineDate != null) {
					if (statusEffectiveDateSql.after(completeByDeadlineDate)) {
						// false
					} else {
						activityCountsForThisIncentive = true;
					}
				}
			}
		}

		return activityCountsForThisIncentive;
	}

	/**
	 * EV58080 - add new rule type. If incentive is upon activity completion and
	 * activity status is complete with a rule type of communicated, return.
	 * 
	 * @return true if activity gets the incentive, false otherwise
	 */

	private boolean isActivityCompletedWithRuleTypeCommunicated(
			MemberActivity pMemberActivity, String incentiveRuleTypeCode) {
		// If incentive is upon activity completion and activity status is
		// complete,
		// return.
		boolean activityCountsForThisIncentive = false;
		if (isActivityCompleted(pMemberActivity.getActivity().getName(),
				pMemberActivity.getActivityStatus().getStatusCodeValue())) {
			if (BPMConstants.BPM_INCENTIVE_ENROLL_COMMUNICATE
					.equals(incentiveRuleTypeCode)) {
				activityCountsForThisIncentive = true;
			}
		}

		return activityCountsForThisIncentive;
	}

	/**
	 * If incentive is upon activity completion, activity status is complete,
	 * and activity taken within effective and end date defined within the
	 * incentive option. A rule type with no filter allows the activity to flow
	 * through the filtering service and on to the status calculation.
	 * 
	 * @return true if activity gets the incentive, false otherwise
	 */

	private boolean isActivityCompletedWithRuleTypeCompleteWithin(
			 MemberActivity pMemberActivity, java.sql.Date effectiveDate, java.sql.Date completeByDeadlineDate, String incentiveRuleTypeCode) {
		// If incentive is upon activity completion and activity status is
		// complete,
		// return.
		boolean activityCountsForThisIncentive = false;
		if (isActivityCompleted(pMemberActivity.getActivity().getName(),
				pMemberActivity.getActivityStatus().getStatusCodeValue())) {
			if (BPMConstants.BPM_INCENTIVE_ENROLL_COMPLETE_WITHIN_NO_FILTER
					.equals(incentiveRuleTypeCode)) {
				java.sql.Date statusEffectiveDateSql = BPMUtils
						.calendarToSqlDate(pMemberActivity.getActivityStatus()
								.getStatusEffectiveDate());
				if (effectiveDate != null
						&& completeByDeadlineDate != null) {
					if (statusEffectiveDateSql.before(effectiveDate)
							|| statusEffectiveDateSql.after(completeByDeadlineDate)) {
						// outside of incentive period
						activityCountsForThisIncentive = false;
					} else {
						// within incentive period along with other criteria
						// being met.
						activityCountsForThisIncentive = true;
					}
				}
			}
		}

		return activityCountsForThisIncentive;
	}

	/**
	 * if activity completed and there exists an extended auth code, determine
	 * if completed within the extended auth code effect and end date. Met
	 * criteria will allow activity to be incented. See EV 58500 - Incentive
	 * Improvement Pre-Enrollment rule. Note that this incentive rule is not
	 * connected to a rule type from incentive option.
	 * 
	 * @return true if activity gets the incentive, false otherwise
	 */
	// EV58500 - commented out method.
	/*
	 * private boolean
	 * isActivityCompletedOutsideQualificationPeriodUsingExtendedAuthCode
	 * (MemberActivity pMemberActivity, BusinessProgramAdapter pProgramAdapter)
	 * {
	 * 
	 * boolean activityCountsForThisIncentive = false;
	 * 
	 * String lActivityAuthCode = pMemberActivity.getAuthPromoCode();
	 * 
	 * // If the activity auth code is found in the regular eligible activity
	 * auth codes // return false. for(AuthCode lEligibleAuthCode :
	 * pProgramAdapter.getEligibleAuthCodes()) {
	 * if(lEligibleAuthCode.getAuthCode().equalsIgnoreCase(lActivityAuthCode)) {
	 * return false; } }
	 * 
	 * // Otherwise look in the extended auth codes.
	 * 
	 * if (isActivityCompleted(pMemberActivity.getActivity().getName(),
	 * pMemberActivity.getActivityStatus().getStatusCodeValue())) { if
	 * (pProgramAdapter.getExtendedAuthCodes() != null) { Collection<AuthCode>
	 * lAuthCodes =
	 * (Collection<AuthCode>)pProgramAdapter.getExtendedAuthCodes();
	 * Iterator<AuthCode> iter = lAuthCodes.iterator(); while (iter.hasNext()) {
	 * AuthCode lAuthCode = (AuthCode)iter.next();
	 * if(lAuthCode.getAuthCode().equals(pMemberActivity.getAuthPromoCode())) {
	 * java.sql.Date statusEffectiveDateSql =
	 * BPMUtils.calendarToSqlDate(pMemberActivity
	 * .getActivityStatus().getStatusEffectiveDate());
	 * if(lAuthCode.getEffectiveDate() != null && lAuthCode.getEndDate()!= null)
	 * { if (statusEffectiveDateSql.before(lAuthCode.getEffectiveDate()) ||
	 * statusEffectiveDateSql.after(lAuthCode.getEndDate())) { //outside of
	 * extended auth code incentive period } else {
	 * activityCountsForThisIncentive = true; } } } } }
	 * 
	 * }
	 * 
	 * return activityCountsForThisIncentive; }
	 */

	/**
	 * Health assesement - complete ?
	 * 
	 * @param activityName
	 * @param activityStatus
	 * @return
	 */
	public boolean isHeathAssesmentCompleted(String activityName,
			String activityStatus) {
		boolean result = false;

		if (isHealthAssesmentActivity(activityName)
				&& isActivityCompleted(activityName, activityStatus)) {
			result = true;
			logger.info("@isHeathAssesmentCompleted=" + result);
		}
		return result;
	}

	/**
	 * is it a HA activity?
	 * 
	 * @param activityName
	 * @return boolean
	 */
	public boolean isHealthAssesmentActivity(String activityName) {
		boolean result = false;
		if (BPMConstants.ACTIVITY_HEALTHY_BENEFITS_HA.equals(activityName)) {
			result = true;
		}
		return result;
	}

	/**
	 * is it a DM activity?
	 * 
	 * @param activity
	 * @return boolean
	 */
	public boolean isDiseaseManagementActivity(MemberActivity activity) {
		boolean result = false;

		String activityType = activity.getActivity().getActivityTypeValue();
		if (BPMConstants.ACTIVITY_TYPE_DISEASE_MGMT
				.equalsIgnoreCase(activityType)) {
			result = true;
		}
		return result;
	}

	/**
	 * Decides wether an DiseaseManagement program actvity has been started
	 * 
	 * @param program
	 */
	public boolean isDiseaseManagementProgramActivityStarted(
			BusinessProgramAdapter program) {
		boolean result = false;

		DiseaseMgmtHelper diseaseMgmtHelper = new DiseaseMgmtHelper();

		Collection<MemberActivity> memberActivities = member
				.getDiseaseManagementMemberActivities(program
						.getBusinessProgramId(), program.getBusinessProgram()
						.isEvaluateTermedContract());

		result = diseaseMgmtHelper.isDiseaseManagementProgramActivityStarted(
				memberActivities, program, this.getCurrentDateTime());

		return result;
	}

	/**
	 * Decides wether an DiseaseManagement program actvity has been Completed
	 * 
	 * @param program
	 */
	public boolean isDiseaseManagementProgramActivityCompleted(
			BusinessProgramAdapter program) {
		boolean result = false;

		DiseaseMgmtHelper diseaseMgmtHelper = new DiseaseMgmtHelper();

		Collection<MemberActivity> memberActivities = member
				.getDiseaseManagementMemberActivities(program
						.getBusinessProgramId(), program.getBusinessProgram()
						.isEvaluateTermedContract());

		result = diseaseMgmtHelper.isDiseaseManagementProgramActivityCompleted(
				memberActivities, program, this.getCurrentDateTime());

		return result;
	}

	/*
	 * This method looks through incentive options for business program to see
	 * if rule type of coverage effect date and a time period value is
	 * configured. Return time period if exists. Also calculate coverage
	 * effective date and set date to object (MemberAdapter). EV79549 - added
	 * null pointer check on IncentiveRuleTypeCode and ActivityCompletionPeriod.
	 */
	private Integer determineIncentiveOptionTimePeriod(
			BusinessProgramAdapter program,
			Integer pThisCheckmarkIncentiveOptionID) {

		Integer activityCompletionPeriod = null;

		// get activity completion period from program incentive option.
		for (ProgramIncentiveOption lProgramIncentiveOption : program
				.getProgramIncentiveOptions()) {
			if (lProgramIncentiveOption.getProgramIncentiveOptionID()
					.intValue() == pThisCheckmarkIncentiveOptionID.intValue()
					&& lProgramIncentiveOption.getIncentiveRuleTypeCode() != null
					&& lProgramIncentiveOption
							.getIncentiveRuleTypeCode()
							.equals(BPMConstants.BPM_INCENTIVE_ENROLL_COVERAGE_EFF_DT)) {
				if (lProgramIncentiveOption.getActivityCompletionPeriod() != null
						&& lProgramIncentiveOption
								.getActivityCompletionPeriod() > 0) {
					activityCompletionPeriod = lProgramIncentiveOption
							.getActivityCompletionPeriod();
					break;
				}
			}
		}

		if (activityCompletionPeriod != null && activityCompletionPeriod > 0) {
			Calendar coverageEffectiveDate = determineCoverageEffectiveDate(program);
			// set coverage effective date to member adapter object to it will
			// later be updated back to the person_program_status table.
			this.setCoverageEffectiveDate(coverageEffectiveDate);
		}

		return activityCompletionPeriod;

	}

	/**
	 * Determine if activity completed within timeframe specified
	 *
	 * @param activityCompletionPeriod
	 * @return
	 */
	private boolean isActivityCompletedWithinTimePeriod(
			Integer activityCompletionPeriod, MemberActivity pMemberActivity) {
		boolean activityCompletedWithinTimePeriod = false;
		Calendar coverageEffectiveDate = this.getCoverageEffectiveDate();

		// A coverageEffective date of null indicates new hire and
		// participant would not be required to complete the program
		// during the program year.
		if (this.getCoverageEffectiveDate() != null) {
			// if completed check to see if activity completed within timeframe;
			Integer daysBetween = 0;
			Calendar completionDate = retrieveMemberActivityCompletionDate(pMemberActivity);
			if (completionDate != null) {
				daysBetween = BPMUtils.getDaysBetweenDates(completionDate,
						coverageEffectiveDate);
			}

			if (daysBetween.intValue() <= activityCompletionPeriod.intValue()) {
				activityCompletedWithinTimePeriod = true;
				pMemberActivity.setActivityCompletedWithinTimePeriod(true);
			} else {
				pMemberActivity.setActivityCompletedWithinTimePeriod(false);
			}
		}

		logger.info("@isActivityCompletedWithinTimePeriod="
				+ activityCompletedWithinTimePeriod);

		return activityCompletedWithinTimePeriod;
	}

	/*
	 * find status completion date for activity buried in status history array.
	 */
	private Calendar retrieveMemberActivityCompletionDate(
			MemberActivity lMemberActivity) {
		Calendar completionDate = null;
		GenericStatusType[] lGenericStatusType = lMemberActivity
				.getStatusHistory();

		for (int i = 0; i < lGenericStatusType.length; i++) {
			if (lGenericStatusType[i].getStatusCodeValue().equals(
					BPMConstants.ACTIVITY_STATUS_COMPLETE)) {
				completionDate = lGenericStatusType[i].getStatusEffectiveDate();
			}
		}

		return completionDate;
	}

	/**
	 * calculate member status for Hold for contact
	 * 
	 * @return true if member status should be 'Hold For Contact'
	 */

	public boolean isHoldForContact(BusinessProgramAdapter program,
			boolean programActivityStarted, boolean programActivityCompleted,
			boolean healthAssesmentCompleted,
			boolean programQualificationPeriodEnded) {

		boolean result = false;

		HoldForContactHelper holdForContactHelper = new HoldForContactHelper(
				member, getCurrentDateTime(), riskGroupCodes, risks);

		result = holdForContactHelper.isHoldForContact(program,
				programActivityStarted, programActivityCompleted,
				healthAssesmentCompleted, programQualificationPeriodEnded);

		logger.info("@isHoldForContact = " + result + " for programID "
				+ program.getBusinessProgramId());
		return result;
	}

	/**
	 * Determines whether the member is not qualified for the program. Exempt
	 * status(es) also count for Qualification.
	 * 
	 * @param memberStatus
	 *            the status of the member
	 * @param program
	 *            the business program
	 * @return true if the HA outcome is "High Risk", false otherwise
	 */
	public boolean isMemberNotQualifiedForProgram(
			BusinessProgramAdapter program, String memberStatus) {
		boolean result = false;

		if (!BPMConstants.MEMBER_STATUS_QUALIFIED.equals(memberStatus)
				&& !BPMConstants.MEMBER_STATUS_EXEMPT_QUALIFIED
						.equals(memberStatus)
				&& !BPMConstants.MEMBER_STATUS_EXEMPT_ELIGIBLE
						.equals(memberStatus)
				&& !BPMConstants.MEMBER_STATUS_EXEMPT_HOLD.equals(memberStatus)
				&& !BPMConstants.MEMBER_STATUS_EXEMPT_ACTIVE
						.equals(memberStatus)
				&& !BPMConstants.MEMBER_STATUS_EXEMPT_HA_COMPLETED
						.equals(memberStatus)) {

			if (program.isEligibleProgramActivityOverrideExist()) {
				// pre and/or post enrollment activities exist so allow status
				// calc to take place after the qualificaiton period.

			} else if (isTodayAfterProgramQualificationEndDate(program)) {
				result = true;
			}
		}

		return result;
	}

	/**
	 * Determines whether today is after the program qualification end date.
	 * 
	 * @return true if after the program qualification end date, false otherwise
	 */
	public boolean isTodayAfterProgramQualificationEndDate(
			BusinessProgramAdapter program) {
		boolean result = false;

		// Is today after the program qualification end date?
		if (program != null) {
			java.util.Calendar now = getCurrentDateTime();
			Calendar end = program.getBusinessProgram()
					.getQualificationWindowEndDate();

			// Set the times to 0, so that only the dates are compared.
			BPMUtils.setTimeToZero(now);
			BPMUtils.setTimeToZero(end);

			if (end == null || now.compareTo(end) > 0) {
				result = true;
			}
		}

		return result;
	}

	/**
	 * member has any manual exemption?
	 * 
	 * @param program
	 * @return
	 */
	public boolean isMemberGotAnyManualExemption(BusinessProgramAdapter program) {
		boolean result = false;
		// 1.if any exemptions - manual/ or any previous exemptions
		Collection<QualificationOverride> memberExemptions = this.member
				.getMemberExemptions();

		for (ProgramIncentiveOption lProgramIncentiveOption : program
				.getProgramIncentiveOptions()) {
			for (QualificationOverride lQualificationOverride : memberExemptions) {
				if (BPMConstants.OVERRIDE_CODE_MANUAL_EXEMPTION
						.equalsIgnoreCase(lQualificationOverride
								.getOverrideCode())
						&& lQualificationOverride.getProgramIncentiveOptionID()
								.intValue() == lProgramIncentiveOption
								.getProgramIncentiveOptionID().intValue()) {
					result = true;

					// EV 58085 Create a Person Incentive Status for this
					// incentive and set its status to EXEMPT.
					findOrCreatePersonIncentiveStatus(program,
							lProgramIncentiveOption
									.getProgramIncentiveOptionID(), 0,
							BPMConstants.MEMBER_STATUS_EXEMPT);
					// EV 58085
				}
			}
		}

		return result;
	}

	/**
	 * 
	 * @param pProgramIncentiveOption
	 * @return
	 */
	public boolean isMemberGotAnyManualExemptionByIncentive(
			ProgramIncentiveOption pProgramIncentiveOption) {
		boolean result = false;
		// 1.if any exemptions - manual/ or any previous exemptions
		Collection<QualificationOverride> memberExemptions = this.member
				.getMemberExemptions();
								       
		for (QualificationOverride lQualificationOverride : memberExemptions) {
			if (BPMConstants.OVERRIDE_CODE_MANUAL_EXEMPTION
					.equalsIgnoreCase(lQualificationOverride.getOverrideCode())
					&& lQualificationOverride.getProgramIncentiveOptionID()
							.intValue() == pProgramIncentiveOption
							.getProgramIncentiveOptionID().intValue()) {				
				result = true;
			}
		}

		return result;
	}

	/**
	 * member has any automatic exemptions?
	 * 
	 * @param program
	 * @return
	 */
	public boolean isMemberGotAnyAutomaticExemption(
			BusinessProgramAdapter program) {
		boolean result = false;
		Collection<QualificationOverride> memberExemptions = member
				.getMemberExemptions();

		for (ProgramIncentiveOption lProgramIncentiveOption : program
				.getProgramIncentiveOptions()) {
			for (QualificationOverride lQualificationOverride : memberExemptions) {
				if (BPMConstants.OVERRIDE_CODE_EXEMPTION
						.equalsIgnoreCase(lQualificationOverride
								.getOverrideCode())
						&& lQualificationOverride.getProgramIncentiveOptionID()
								.intValue() == lProgramIncentiveOption
								.getProgramIncentiveOptionID().intValue()) {
					result = true;

					// EV 58085 Create a Person Incentive Status for this
					// incentive and set its status to EXEMPT.
					findOrCreatePersonIncentiveStatus(program,
							lProgramIncentiveOption
									.getProgramIncentiveOptionID(), 0,
							BPMConstants.MEMBER_STATUS_EXEMPT);
					// EV 58085
				}
			}
		}
		return result;
	}

	/**
	 * 
	 * @param pProgramIncentiveOption
	 * @return
	 */
	public boolean isMemberGotAnyAutomaticExemption(
			ProgramIncentiveOption pProgramIncentiveOption) {
		boolean result = false;
		Collection<QualificationOverride> memberExemptions = member
				.getMemberExemptions();

		for (QualificationOverride lQualificationOverride : memberExemptions) {
			if (BPMConstants.OVERRIDE_CODE_EXEMPTION
					.equalsIgnoreCase(lQualificationOverride.getOverrideCode())
					&& lQualificationOverride.getProgramIncentiveOptionID()
							.intValue() == pProgramIncentiveOption
							.getProgramIncentiveOptionID().intValue()) {
				result = true;
			}
		}

		return result;
	}

	/**
	 * 
	 * @param program
	 * @return
	 */
	public boolean hasMemberGotAnyGeneratedExemption(
			BusinessProgramAdapter program) {
		boolean result = false;

		for (ProgramIncentiveOption lProgramIncentiveOption : program
				.getProgramIncentiveOptions()) {
			if (memberExemptionMap.get(lProgramIncentiveOption
					.getProgramIncentiveOptionID().intValue()) != null) {
				result = true;

				// EV 58085 Create a Person Incentive Status for this incentive
				// and set its status to EXEMPT.
				findOrCreatePersonIncentiveStatus(program,
						lProgramIncentiveOption.getProgramIncentiveOptionID(),
						0, BPMConstants.MEMBER_STATUS_EXEMPT);
				// EV 58085
			}
		}
		return result;
	}

	/**
	 * 
	 * @param pProgramIncentiveOption
	 * @return
	 */
	public boolean hasMemberGotAnyGeneratedExemption(
			ProgramIncentiveOption pProgramIncentiveOption) {
		boolean result = false;

		if (memberExemptionMap.get(pProgramIncentiveOption
				.getProgramIncentiveOptionID().intValue()) != null) {
			result = true;
		}

		return result;
	}

	/**
	 * determines if any exemption issued to member
	 * 
	 * @param program
	 * @return
	 */
	public boolean isMemberGotAnyExemption(BusinessProgramAdapter program) {

		return (isMemberGotAnyManualExemption(program)
				|| isMemberGotAnyAutomaticExemption(program) || hasMemberGotAnyGeneratedExemption(program));

	}

	public boolean isMemberGotAnyExemptionByIncentive(
			ProgramIncentiveOption pProgramIncentiveOption) {
		return (isMemberGotAnyManualExemptionByIncentive(pProgramIncentiveOption)
				|| isMemberGotAnyAutomaticExemption(pProgramIncentiveOption) || hasMemberGotAnyGeneratedExemption(pProgramIncentiveOption));
	}

	/**
	 * calculates contract status based on GroupParticipationRequirements
	 * 
	 * @param program
	 * @return
	 */
	public String calculateContractStatusFromGroupParticipationRequirements(
			String contractStatus, BusinessProgramAdapter program,
			ProgramIncentiveOption pProgramIncentiveOption) {
		String newContractStatus = null;
		MemberAdapter contractHolder = null;
		MemberAdapter spouse = null;
		MemberAdapter dompartner = null;

		// default value
		newContractStatus = contractStatus;

		Integer businessProgramId = program.getBusinessProgramId();

		// find policyHolder, spouse, dom partner
		contractHolder = getContractHolder(businessProgramId);

		if (contractHolder != null) {
			spouse = contractHolder.getSpouse(businessProgramId);
			dompartner = contractHolder.getDomesticPartner(businessProgramId);
		} else {
			// policy holder is No Benefits Contract
			// find this member as either spouse/dom partner
			String relationship = member
					.getRelationshipToContractHolder(businessProgramId);
			if (PersonRelationship.REL_TYPE_SPOUSE.equals(relationship)) {
				spouse = this;
			} else if (PersonRelationship.REL_TYPE_DOMESTIC_PARTNER
					.equals(relationship)) {
				dompartner = this;
			}
		}
				

		// logger.info("--- -This- person ID = " +
		// this.getMember().getPersonID() + ", Rel to Contract Holder = " +
		// this.getMember().getRelationshipToContractHolder(businessProgramId));

		// participation requirement - PH only, PH and Spouse or DOM
		String participationRequirement = program.getFamilyParticipationValue();

		//participation requirement configured into programIncentiveOption used
		// as part of program participation requirement evaluation at the contract level.
		String incentiveOptionParticipationRequirement = pProgramIncentiveOption.getParticipationGroup().getParticipationGroupName();

		//BPM Story 754 - Get HealthPlan Indicator for contract.
		String healthPlanCode = member.getMemberContractProgramTO(program.getBusinessProgramId()).getMemberContract()
				.getHealthPlanCode();

		//logger.info("---- Business Program " + businessProgramId +
		// " part Req is = " + participationRequirement);

		// 07-16-2010 - The three new optional participation requirements bring
		// in the Spouse, Domestic Partner,
		// or all members 18 and older to participate. But for status
		// calculation, only the policy holder
		// status is used to determine program completion.
		if (BPMConstants.BPM_PARTICIP_REQ_PH_ONLY
				.equals(participationRequirement)
				|| BPMConstants.BPM_PARTICIP_REQ_PH_SPOUSE_OPTIONAL
				.equals(participationRequirement)
				|| BPMConstants.BPM_PARTICIP_REQ_PH_18_OPTIONAL
				.equals(participationRequirement)
				|| BPMConstants.BPM_PARTICIP_REQ_PH_SPOUSE_DOM_OPTIONAL
				.equals(participationRequirement)) {
			// calculate contract status based on PH only
			newContractStatus = calculateContractStatusByOneMemberOnly(
					businessProgramId, contractHolder, newContractStatus,
					pProgramIncentiveOption);
		} else if (BPMConstants.BPM_PARTICIP_REQ_PH_AND_SPOUSE
				.equals(participationRequirement) &&
				(BPMConstants.BPM_PARTICIP_REQ_PH_ONLY_W_HEALTH.equals(incentiveOptionParticipationRequirement) &&
						healthPlanCode.equals(BPMConstants.BPM_MEMBER_WITH_MEDICAL_PLAN))) {
			newContractStatus = calculateContractStatusByOneMemberOnly(
					businessProgramId, contractHolder, newContractStatus,
					pProgramIncentiveOption);
		} else if (BPMConstants.BPM_PARTICIP_REQ_PH_AND_SPOUSE
				.equals(participationRequirement)
				|| BPMConstants.BPM_PARTICIP_REQ_PH_AND_SPOUSE_18_OPT
				.equals(participationRequirement)) {
			// calculate contract status based on PH and spouse
			newContractStatus = calculateContractStatusByTwoMembersOnly(
					businessProgramId, contractHolder, spouse,
					newContractStatus, pProgramIncentiveOption);
		} else if (BPMConstants.BPM_PARTICIP_REQ_PH_AND_SPOUSE_OR_DOM
				.equals(participationRequirement)
				|| BPMConstants.BPM_PARTICIP_REQ_PH_AND_SPOUSE_DOM_18_OPT
				.equals(participationRequirement)) {
			// calculate contract status based on PH and spouse or DOM
			newContractStatus = calculateContractStatusByPolicyHolderAndSpouseOrPartner(
					newContractStatus, contractHolder, spouse, dompartner,
					businessProgramId, pProgramIncentiveOption);
			//Story BPM-730 and BPM-754 ISR Enhancement
		} else if (BPMConstants.BPM_PARTICIP_REQ_ALL_18_PLUS
				.equals(participationRequirement) &&
				(BPMConstants.BPM_PARTICIP_REQ_PH_ONLY.equals(incentiveOptionParticipationRequirement) ||
						BPMConstants.BPM_PARTICIP_REQ_PH_ONLY_W_HEALTH.equals(incentiveOptionParticipationRequirement) &&
								healthPlanCode.equals(BPMConstants.BPM_MEMBER_WITH_MEDICAL_PLAN))
		) {
			newContractStatus = calculateContractStatusByOneMemberOnly(
					businessProgramId, contractHolder, newContractStatus,
					pProgramIncentiveOption);
			//Story BPM-730 and BPM-754 ISR Enhancement
		} else if (BPMConstants.BPM_PARTICIP_REQ_ALL_18_PLUS
				.equals(participationRequirement) &&
				(BPMConstants.BPM_PARTICIP_REQ_PH_AND_SPOUSE.equals(incentiveOptionParticipationRequirement) ||
						BPMConstants.BPM_PARTICIP_REQ_PH_AND_SPOUSE_W_HEALTH.equals(incentiveOptionParticipationRequirement) &&
								healthPlanCode.equals(BPMConstants.BPM_MEMBER_WITH_MEDICAL_PLAN) ||
						BPMConstants.BPM_PARTICIP_REQ_PH_AND_SPOUSE_OR_DOM.equals(incentiveOptionParticipationRequirement))) {

			newContractStatus = calculateContractStatusByPolicyHolderAndSpouseOrPartner(
					newContractStatus, contractHolder, spouse, dompartner,
					businessProgramId, pProgramIncentiveOption);
		} else if (BPMConstants.BPM_PARTICIP_REQ_ALL_18_PLUS
				.equals(participationRequirement)) {
			// calculate contract status based on PH and spouse or DOM
			newContractStatus = calculateContractStatusByPolicyHolder18Plus(
					newContractStatus, contractHolder, spouse, dompartner,
					businessProgramId, pProgramIncentiveOption);
		}

		return newContractStatus;
	}

	/**
	 * 
	 * @param program
	 * @return
	 */
	private void calculateContractIncentiveStatus(BusinessProgramAdapter program) {
		
		Integer lBusinessProgramID = program.getBusinessProgramId();

		ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>) program
				.getProgramIncentiveOptions();

		/**
		 * Determine if this person would receive certain incentives based on
		 * the person's benefit-packages. This method will remove or keep
		 * HRA/HSA incentives depending on the person's benefit-package.
		 */
		determineMemberAlignmentWithProgramIncentiveOptionUsingRelationshipNPackage(personPackages, lProgramIncentiveOptions,
				program);

		// For every Program Incentive Option that is contract based.
		for (ProgramIncentiveOption lProgramIncentiveOption : lProgramIncentiveOptions) 
		{
			if (BPMConstants.BPM_INCENTED_STATUS_TYPE_CONTRACT_BASED
					.equalsIgnoreCase(lProgramIncentiveOption
							.getIncentedStatusTypeCode())) {

				// If all the requirements for this incentive have been met, the
				// contract incentive has been
				// achieved.
				ContractProgramIncentiveTO lContractProgramIncentiveTO = new ContractProgramIncentiveTO();

				lContractProgramIncentiveTO
						.setBusinessProgramID(lBusinessProgramID);
				lContractProgramIncentiveTO
						.setIncentiveOptionID(lProgramIncentiveOption
								.getIncentiveOption().getIncentiveOptionID());
				lContractProgramIncentiveTO
						.setProgramIncentiveOptionID(lProgramIncentiveOption
								.getProgramIncentiveOptionID());
				lContractProgramIncentiveTO.setContractNo(getMember()
						.getMemberContract(lBusinessProgramID).getContract()
						.getContractNumber());

				// EV 95424 
				lContractProgramIncentiveTO.setActivationStatusCode(lProgramIncentiveOption.getActivationStatusCode());
				
				ArrayList<IncentiveStatusActivityDetail> lIncentiveStatusActivityDetails = new ArrayList<IncentiveStatusActivityDetail>();
				lContractProgramIncentiveTO
						.setIncentiveStatusActivityDetails(lIncentiveStatusActivityDetails);

				String benefitContractType = member.getMemberContract(
						program.getBusinessProgramId())
						.getBenefitContractType();
				Integer relationshipCode = member.getMemberContract(
						program.getBusinessProgramId())
						.getRelationshipCode();
				ArrayList<MemberActivity> memberActivitiesMeetingRequirements = this
						.getMemberActivitiesMeetingRequirements();

				if (memberActivitiesMeetingRequirements != null
						&& memberActivitiesMeetingRequirements.size() > 0) {
					for (MemberActivity memberActivitiesMeetingRequirement : memberActivitiesMeetingRequirements) {
						// EV84334 Assign the right contribution amount from
						// the program incentive option contribution grid
						Integer personProgramActivityStatusID = memberActivitiesMeetingRequirement
								.getPersonProgramActivityStatusID();
						ProgramContributionGrid lProgramContributionGrid = getProgramContributionGrid(
								lProgramIncentiveOption,
								benefitContractType, BPMConstants.RELSHP_SELF);
						IncentiveStatusActivityDetail lIncentiveStatusActivityDetail = new IncentiveStatusActivityDetail();
						if (lProgramContributionGrid != null) {
							if (isEligibleForContractIncentive(memberActivitiesMeetingRequirement, program, lContractProgramIncentiveTO.getContractNo())) {
								if (isContractIncentiveBelowCap(program,
										lContractProgramIncentiveTO, lProgramIncentiveOption)) {
									lIncentiveStatusActivityDetail = createIncentiveStatusActivityDetailNContribution(getPHId(), lProgramContributionGrid, benefitContractType
											, personProgramActivityStatusID
											, lProgramIncentiveOption.getProgramIncentiveOptionID());
									lIncentiveStatusActivityDetails
											.add(lIncentiveStatusActivityDetail);
								}
							}
						}
					}
				}



				// EV 58085 : Contract status for this member and this
				// programIncentiveOptionID
				String lContractStatus = (String) memberContractStatusMap
						.get(lProgramIncentiveOption
								.getProgramIncentiveOptionID());
				// 07-23-10
				// When the Incentive is Contract based, use the contract status
				// to determine the
				// contract-incentive status.
				if (BPMConstants.CONTRACT_STATUS_QUALIFIED
						.equals(lContractStatus)) {
					lContractProgramIncentiveTO
							.setContractIncentiveStatusCode(BPMConstants.BPM_CONTRACT_INCENTIVE_ACHIEVED);
				} else {
					lContractProgramIncentiveTO
							.setContractIncentiveStatusCode(BPMConstants.BPM_CONTRACT_INCENTIVE_NOT_ACHIEVED);
				}

                memberContractIncentiveStatusMap.put(
                        lProgramIncentiveOption
                                .getProgramIncentiveOptionID(),
                        lContractProgramIncentiveTO);

			}// end first if
		}// end for loop
	}
	
	/*
	 * This method determines if an activity is eligible for contract incentive.
	 */
	private boolean isEligibleForContractIncentive(MemberActivity memberActivityMeetingRequirement, BusinessProgramAdapter pProgramAdapter, Integer contractNo) {
		boolean isEligible = true;
		ArrayList<ContractProgramIncentiveTO> contractProgramIncentives = this
				.getContractProgramIncentives();
		Integer personProgramActivityStatusID = memberActivityMeetingRequirement.getPersonProgramActivityStatusID();
		Integer activityID = memberActivityMeetingRequirement.getActivity().getActivityID();
		Calendar lIncentiveDate = memberActivityMeetingRequirement.getActivityStatus().getStatusEffectiveDate();
		Integer programID = memberActivityMeetingRequirement.getBusinessProgramID();
		
		
		//1. Check for contract terms.  Do not incent.
		if (isActivityTakenAfterContractTerm(programID, contractNo, lIncentiveDate, activityID)) {
			isEligible = false;
			// EV 90008 - prevents duplicate incented activities when a
			// site transfer is performed.
			//2. Check for site terms. Do not incent.
		} else if (isContractBasedActivityAlreadyIncentedPerSiteTransfer(activityID, lIncentiveDate)) {
			isEligible = false;
		//3. Check for activities already incented
		} else {
			
			for (ContractProgramIncentiveTO contractProgramIncentive : contractProgramIncentives) {
				List<IncentiveStatusActivityDetail> lIncentiveStatusActivityDetails  = contractProgramIncentive.getIncentiveStatusActivityDetails();
				for (IncentiveStatusActivityDetail lIncentiveStatusActivityDetail : lIncentiveStatusActivityDetails) {
					if (lIncentiveStatusActivityDetail.getPersonProgramActivityStatusID().equals(personProgramActivityStatusID)) {
						isEligible = false;
						break;
					}
					
				}
			}
		}
		return isEligible;
	}
	
	/*
	 * This method determines if an activity within Member Based has already been incented, if not then create one.
	 */
	private IncentiveStatusActivityDetail createNewMemberIncentive(BusinessProgramAdapter program, ProgramIncentiveOption lProgramIncentiveOption, MemberActivity lMemberActivityMeetingRequirement, MemberProgramIncentiveTO lMemberProgramIncentiveTONew,
																	Integer personDemographicsId,	ProgramContributionGrid lProgramContributionGrid, String benefitContractType) 
	{		
		IncentiveStatusActivityDetail lIncentiveStatusActivityDetailResult = null;
		
		Integer programID = lMemberProgramIncentiveTONew.getBusinessProgramID();
		Integer contractNo = lMemberProgramIncentiveTONew.getContractNo();
		
		Integer personProgramActivityStatusID = lMemberActivityMeetingRequirement.getPersonProgramActivityStatusID();
		
		ArrayList<MemberProgramIncentiveTO> memberProgramIncentivesCurrent = this.getMemberProgramIncentives(); //existing member incentives.
		
		for (MemberProgramIncentiveTO memberProgramIncentiveCurrent : memberProgramIncentivesCurrent) 
		{								
			if (lMemberProgramIncentiveTONew.getBusinessProgramID().equals(memberProgramIncentiveCurrent.getBusinessProgramID()) &&
					lProgramIncentiveOption.getProgramIncentiveOptionID().equals(memberProgramIncentiveCurrent.getProgramIncentiveOptionID()) &&
					lMemberProgramIncentiveTONew.getPersonDemographicsID().equals(memberProgramIncentiveCurrent.getPersonDemographicsID())) {
				Collection<IncentiveStatusActivityDetail> lIncentiveStatusActivityDetails  = memberProgramIncentiveCurrent.getIncentiveStatusActivityDetails();
				
				Integer incentiveOptionID = memberProgramIncentiveCurrent.getIncentiveOptionID();
				Integer activityID = lMemberActivityMeetingRequirement.getActivity().getActivityID();
				Calendar incentiveDate = lMemberActivityMeetingRequirement.getActivityStatus().getStatusEffectiveDate();
				
		
				boolean activityIncented = false;
				// EV 90008 - prevents duplicate incented activities when a
				// site transfer or contract term is performed.
				//Check for contract terms.  Do not incent.
				if (isActivityTakenAfterContractTerm(programID, contractNo, incentiveDate, activityID)) {
					activityIncented = true;
					// EV 90008 - prevents duplicate incented activities when a
					// site transfer is performed.
				} else if (isMemberBasedActivityAlreadyIncentedPerSiteTransfer(incentiveOptionID, activityID, incentiveDate)) {
						activityIncented = true;
				}
				if (activityIncented) {
					
				} else if (lIncentiveStatusActivityDetails == null || lIncentiveStatusActivityDetails.size() == 0) {
					// Don't incent an activity if taken after a contract has
					// been termed.
					if (isMemberIncentiveBelowTheCap(program,
						lMemberProgramIncentiveTONew, lProgramIncentiveOption)) {
						lIncentiveStatusActivityDetailResult = createIncentiveStatusActivityDetailNContribution(personDemographicsId, lProgramContributionGrid, benefitContractType
								, personProgramActivityStatusID
								, lProgramIncentiveOption.getProgramIncentiveOptionID());
					}
				
				} else {
					//EV89525 - now handles multiple incentive for the same checkmark attached to the same incentive option.
					//Determine if person program activity status id from person program activity status table is already incented (already in the list of activities incented).  If not, create an incentive.
					
					for (IncentiveStatusActivityDetail lIncentiveStatusActivityDetail : lIncentiveStatusActivityDetails) {
						if (lIncentiveStatusActivityDetail.getPersonProgramActivityStatusID().equals(personProgramActivityStatusID)) {
							activityIncented = true;
							break;
						}
					}
				
					//EV89525 - moved capping business rule to this location. before an incentive is considered, it must be within the cap.
					if (isMemberIncentiveBelowTheCap(program,
							lMemberProgramIncentiveTONew, lProgramIncentiveOption)) {
						lIncentiveStatusActivityDetailResult = createIncentiveStatusActivityDetailNContribution(personDemographicsId, lProgramContributionGrid, benefitContractType
								, personProgramActivityStatusID
								, lProgramIncentiveOption.getProgramIncentiveOptionID());
					}
				}
			}
		}
	
		return lIncentiveStatusActivityDetailResult;
	}

	private void calculateMemberIncentiveStatus(BusinessProgramAdapter program) {
		ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>) program
				.getProgramIncentiveOptions();

		/**
		 * Determine if this person would receive certain incentives based on
		 * the person's benefit-packages. This method will remove or keep
		 * HRA/HSA incentives depending on the person's benefit-package.
		 */

		determineMemberAlignmentWithProgramIncentiveOptionUsingRelationshipNPackage(personPackages, lProgramIncentiveOptions, program);

		// For every Program Incentive Option that is Member-Based.
		for (ProgramIncentiveOption lProgramIncentiveOption : lProgramIncentiveOptions) {
			if (BPMConstants.BPM_INCENTED_STATUS_TYPE_MEMBER_BASED
					.equalsIgnoreCase(lProgramIncentiveOption
							.getIncentedStatusTypeCode())) {
				Integer programID = program.getBusinessProgramId();
				Integer programIncentiveOptionID = lProgramIncentiveOption.getProgramIncentiveOptionID();
				PersonIncentiveStatus lPersonIncentiveStatus = personIncentiveStatusMap
						.get(programIncentiveOptionID);
				

				MemberProgramIncentiveTO lMemberProgramIncentiveTONew = new MemberProgramIncentiveTO();
				lMemberProgramIncentiveTONew.setPersonDemographicsID(getId());
				lMemberProgramIncentiveTONew.setBusinessProgramID(programID);
				lMemberProgramIncentiveTONew.setContractNo(getMember()
						.getMemberContract(program.getBusinessProgramId())
						.getContract().getContractNumber());
				lMemberProgramIncentiveTONew
						.setIncentiveOptionID(lProgramIncentiveOption
								.getIncentiveOption().getIncentiveOptionID());
				lMemberProgramIncentiveTONew
						.setQualificationCheckmarkID(lPersonIncentiveStatus
								.getQualificationCheckmarkID());
				lMemberProgramIncentiveTONew
						.setProgramIncentiveOptionID(lProgramIncentiveOption
								.getProgramIncentiveOptionID());
				
				// EV 95424				
				lMemberProgramIncentiveTONew.setActivationStatusCode(lProgramIncentiveOption.getActivationStatusCode());
																			
				
				String benefitContractType = member.getMemberContract(
						program.getBusinessProgramId())
						.getBenefitContractType();
				Integer relationshipCode = member.getMemberContract(
						program.getBusinessProgramId())
						.getRelationshipCode();
				ProgramContributionGrid lProgramContributionGrid = getProgramContributionGrid(
						lProgramIncentiveOption, benefitContractType,
						relationshipCode);
				
				//memberActivitiesMeetingRequirements collection reflects those activities rolled together
				//that were responsible for meeting the qualification checkmark assigned to the program
				//incentive option.								
					
				if (BPMConstants.CONTRACT_STATUS_QUALIFIED
						.equals(lPersonIncentiveStatus.getPersonStatus())
				 || BPMConstants.MEMBER_STATUS_EXEMPT
						.equals(lPersonIncentiveStatus.getPersonStatus())) 
				{
					lMemberProgramIncentiveTONew
							.setMemberIncentiveStatusCode(BPMConstants.BPM_CONTRACT_INCENTIVE_ACHIEVED);					
				} else {
					lMemberProgramIncentiveTONew
							.setMemberIncentiveStatusCode(BPMConstants.BPM_CONTRACT_INCENTIVE_NOT_ACHIEVED);						
				}
				
				
                ArrayList<MemberActivity> memberActivitiesMeetingRequirementsForProgramIncentiveOption =  null;								
				
				// Look up the MemberActivity objects that satisfied requirements for this ProgramIncentiveOption.
				if (this.getMemberActivitiesMeetingRequirementsMap() != null && this.getMemberActivitiesMeetingRequirementsMap().containsKey(programIncentiveOptionID)) 
				{
					memberActivitiesMeetingRequirementsForProgramIncentiveOption = this.getMemberActivitiesMeetingRequirementsMap().get(programIncentiveOptionID);				
				}
				
				// EV84334 Assign the right contribution amount from the
				// program incentive option contribution grid
				//should always be just one occurrence of a member activity that was met per relationship.								
				if (lProgramContributionGrid != null && memberActivitiesMeetingRequirementsForProgramIncentiveOption != null) 
				{					
					for (MemberActivity lMemberActivityMeetingRequirement : memberActivitiesMeetingRequirementsForProgramIncentiveOption) 
					{												
						//EV88832
						IncentiveStatusActivityDetail lIncentiveStatusActivityDetail = createNewMemberIncentive(program, lProgramIncentiveOption, lMemberActivityMeetingRequirement, lMemberProgramIncentiveTONew, getId(), lProgramContributionGrid,
								benefitContractType);
						if (lIncentiveStatusActivityDetail != null) 
						{
							lMemberProgramIncentiveTONew.getIncentiveStatusActivityDetails().add(lIncentiveStatusActivityDetail);												
															
						    if(lMemberProgramIncentiveTONew.getMemberProgramIncentiveID() == null)
						    {
						    	newMemberProgramIncentives.add(lMemberProgramIncentiveTONew);
						    }
						}											
					}
				}								

				//If member activity requirement NOT already evaluated for incentive by
				//program incentive option.
				//if (memberActivitiesMeetingRequirementsForProgramIncentiveOption != null) {
					  if (!memberBasedIncentiveStatusMap.containsKey(lProgramIncentiveOption.getProgramIncentiveOptionID())) {
							memberBasedIncentiveStatusMap.put(lProgramIncentiveOption
									.getProgramIncentiveOptionID(),
									lMemberProgramIncentiveTONew);
					  }
				//}
					  
				this.getMemberProgramIncentives().addAll(newMemberProgramIncentives);	  
			    // Done with this program-incentive-option
				
			} // If member-based program-incentive-option						
		}
		
	}

	/*
	 * Build out incentive status activity detail and contribution records.
	 */
	private IncentiveStatusActivityDetail createIncentiveStatusActivityDetailNContribution(
			Integer personDemographicsID,
			ProgramContributionGrid lProgramContributionGrid,
			String benefitContractType
			, Integer personProgramActivityStatusID
			, Integer programIncentiveOptionID) 
	{
		
		IncentiveStatusActivityDetail lIncentiveStatusActivityDetail = new IncentiveStatusActivityDetail();
		IncentiveStatusActivityDetailContribution lIncentiveStatusActivityDetailContribution = new IncentiveStatusActivityDetailContribution();

		lIncentiveStatusActivityDetail
				.setPersonDemographicsID(personDemographicsID);
		lIncentiveStatusActivityDetail
				.setPersonProgramActivityStatusID(personProgramActivityStatusID);
		
		lIncentiveStatusActivityDetail.setProgramIncentiveOptionID(programIncentiveOptionID);

		if (benefitContractType == null || lProgramContributionGrid == null) {
			// set field elements to default values which can later
			// determine how many benefit contract types returned nulls.
			Integer defaultID = -1;
			lIncentiveStatusActivityDetailContribution
					.setBenefitContractTypeID(defaultID);
			lIncentiveStatusActivityDetailContribution.setContributionAmount(0);
			lIncentiveStatusActivityDetailContribution
					.setContributionGridID(defaultID);
		} else if (benefitContractType
				.equals(BPMConstants.BEN_CON_TYPE_UNRESOLVED)) {
			// set field elements to default values which can later
			// determine how many went unresolved.
			Integer defaultID = -2;
			lIncentiveStatusActivityDetailContribution
					.setBenefitContractTypeID(defaultID);
			lIncentiveStatusActivityDetailContribution.setContributionAmount(0);
			lIncentiveStatusActivityDetailContribution
					.setContributionGridID(defaultID);
		} else if (lProgramContributionGrid != null) {
			lIncentiveStatusActivityDetailContribution
					.setBenefitContractTypeID(lProgramContributionGrid
							.getBenefitContractTypeID());
			lIncentiveStatusActivityDetailContribution
					.setContributionAmount(lProgramContributionGrid
							.getContributionAmount());
			lIncentiveStatusActivityDetailContribution
					.setContributionGridID(lProgramContributionGrid
							.getContributionGridID());
		}

		if (lIncentiveStatusActivityDetailContribution != null) {
			lIncentiveStatusActivityDetail
					.getIncentiveStatusActivityDetailContributions().add(
							lIncentiveStatusActivityDetailContribution);
		}

		return lIncentiveStatusActivityDetail;

	}

	/**
	 * caluculate contract status based on PH and spouse or DOM
	 * 
	 * @param newContractStatus
	 * @param contractHolder
	 * @param spouse
	 * @param dompartner
	 * @param businessProgramId
	 * @return
	 */
	private String calculateContractStatusByPolicyHolderAndSpouseOrPartner(
			String newContractStatus, MemberAdapter contractHolder,
			MemberAdapter spouse, MemberAdapter dompartner,
			Integer businessProgramId,
			ProgramIncentiveOption pProgramIncentiveOption) {

		if (spouse == null && dompartner == null) {
			// if no spouse or dom, then it is PH only
			newContractStatus = calculateContractStatusByOneMemberOnly(
					businessProgramId, contractHolder, newContractStatus,
					pProgramIncentiveOption);
		} else if (spouse != null && dompartner == null) {
			// if PH has spouse, but no dom
			newContractStatus = calculateContractStatusByTwoMembersOnly(
					businessProgramId, contractHolder, spouse,
					newContractStatus, pProgramIncentiveOption);
		} else if (dompartner != null && spouse == null) {
			// if PH has DOM, but no spouse
			newContractStatus = calculateContractStatusByTwoMembersOnly(
					businessProgramId, contractHolder, dompartner,
					newContractStatus, pProgramIncentiveOption);
			//Story BPM-365
			//if two members appear, need to process one of them so contract
			//status calculation is performed against the contract.
			//Story BPM-389
			//if you are processing two members and one returns DNQ, default to DNQ.
			//This was not accounted for testing of story BPM-365
		} else if (spouse != null && dompartner != null) {
			//when two members are present, a contract status of DNQ will
			// take precedence given the participation requirement involving more than
			// one member on the contract having to qualify at the contract level.
			String contractStatusSpouse = calculateContractStatusByTwoMembersOnly(
					businessProgramId, contractHolder, spouse,
					newContractStatus, pProgramIncentiveOption);
			String contractStatusDomPartner = calculateContractStatusByTwoMembersOnly(
					businessProgramId, contractHolder, dompartner,
					newContractStatus, pProgramIncentiveOption);

			if (contractStatusSpouse.equals(contractStatusDomPartner)) {
				newContractStatus = contractStatusSpouse;
			} else if (contractStatusSpouse.equals(BPMConstants.CONTRACT_STATUS_DID_NOT_QUALIFY)) {
				newContractStatus = contractStatusSpouse;
			} else if (contractStatusDomPartner.equals(BPMConstants.CONTRACT_STATUS_DID_NOT_QUALIFY)) {
				newContractStatus = contractStatusDomPartner;
			}
		}

		return newContractStatus;
	}


	/**
	 * 
	 * @param newContractStatus
	 * @param contractHolder
	 * @param spouse
	 * @param dompartner
	 * @param businessProgramId
	 * @return
	 */
	private String calculateContractStatusByPolicyHolder18Plus(
			String newContractStatus, MemberAdapter contractHolder,
			MemberAdapter spouse, MemberAdapter dompartner,
			Integer businessProgramId,
			ProgramIncentiveOption pProgramIncentiveOption) {
		ArrayList<String> lDependantsStatuses = new ArrayList<String>();

		// When the requirement is 18 Plus, then everyone on the contract needs
		// to be Qualified for the
		// contract to be qualified.
		// First get the statuses of each person on the contract.
		if (relatedMembers != null && relatedMembers.size() > 0) {
			for (MemberAdapter lMemberOnContract : relatedMembers) {
				String lMemberStatus = calculateContractStatusByOneMemberOnly(
						businessProgramId, lMemberOnContract,
						newContractStatus, pProgramIncentiveOption);

				lDependantsStatuses.add(lMemberStatus);
			}
		}

		// Add this members status to the list of all the statuses for the
		// people on the contract.
		lDependantsStatuses.add(calculateContractStatusByOneMemberOnly(
				businessProgramId, this, newContractStatus,
				pProgramIncentiveOption));

		// If only one person is not Qualified, then the contract does not
		// qualify.
		for (String lPersonStatus : lDependantsStatuses) {
			if (!BPMUtils.isStatusQualifiedOrExempt(lPersonStatus)) {
				return lPersonStatus;
			}
		}

		// If we cleared the loop, and we did not hit the return statement, then
		// everyone on the contract was qualified.

		return BPMConstants.CONTRACT_STATUS_QUALIFIED;
	}

	/**
	 * caluculate contract status based on PH only
	 * 
	 * @param businessProgramId
	 * @return contract status
	 */
	private String calculateContractStatusByOneMemberOnly(
			Integer businessProgramId, MemberAdapter memberOne,
			String contractStatus,
			ProgramIncentiveOption pProgramIncentiveOption) {
		// default to
		String newContractStatus = contractStatus;
				
		if (memberOne == null) {
			// NONE in Benefits
			// If memberOne do nothing, this will keep the value of the
			// newContractStatus the
			// same as current contractStatus.
		} else if (memberOne.isMemberGotAnyExemptionByIncentive(pProgramIncentiveOption)) {
			// new rules BR-12.4 dated 11-jan-2008
			newContractStatus = BPMConstants.CONTRACT_STATUS_QUALIFIED;
			// newContractStatus = BPMConstants.CONTRACT_STATUS_GOLD_PASS;
		} else if (memberOne.isMemberStatusQualified(pProgramIncentiveOption)) {
			newContractStatus = BPMConstants.CONTRACT_STATUS_QUALIFIED;
		} else if (memberOne.isMemberStatusDidNotQualify(pProgramIncentiveOption)) {
			newContractStatus = BPMConstants.CONTRACT_STATUS_DID_NOT_QUALIFY;
		}

		
		return newContractStatus;
	}

	/**
	 * caluculate contract status based on PH and spouse or DOM
	 *
	 * @param memberTwo
	 * @param businessProgramId
	 * @return contract status
	 */
	private String calculateContractStatusByTwoMembersOnly(
			Integer businessProgramId, MemberAdapter memberOne,
			MemberAdapter memberTwo, String contractStatus,
			ProgramIncentiveOption pProgramIncentiveOption) {
								
		
		// default to
		String newContractStatus = contractStatus;
		if (memberOne == null && memberTwo == null) {
			// None one in Benefits
		} else if (memberOne != null && memberTwo == null) {
			// only one member, lets call one member calculation
			newContractStatus = calculateContractStatusByOneMemberOnly(
					businessProgramId, memberOne, contractStatus,
					pProgramIncentiveOption);
		} else if (memberOne == null && memberTwo != null) {
			// only one member, lets call one member calculation
			newContractStatus = calculateContractStatusByOneMemberOnly(
					businessProgramId, memberTwo, contractStatus,
					pProgramIncentiveOption);
		} else if ((memberOne.isMemberStatusQualified(pProgramIncentiveOption) ||
				   memberOne.isMemberGotAnyExemptionByIncentive(pProgramIncentiveOption))
						   && (memberTwo.isMemberStatusQualified(pProgramIncentiveOption) ||
						   		memberTwo.isMemberGotAnyExemptionByIncentive(pProgramIncentiveOption))) {
			// new rules BR-12.4 dated 11-jan-2008
			newContractStatus = BPMConstants.CONTRACT_STATUS_QUALIFIED;

		} else if (memberOne.isMemberStatusDidNotQualify(pProgramIncentiveOption)
				|| memberTwo.isMemberStatusDidNotQualify(pProgramIncentiveOption)) {
			// if one of them didn't qualify, contract is not qualified
			newContractStatus = BPMConstants.CONTRACT_STATUS_DID_NOT_QUALIFY;
		}
		
		return newContractStatus;
	}

	/**
	 * determines if member status is EXEMPT
	 *
	 * @return member status
	 */
	public boolean isMemberStatusExempt(BusinessProgramAdapter program) {
		return isMemberGotAnyExemption(program);
	}

	/**
	 * determines if member status is QUALIFIED
	 * 
	 * @param pProgramIncentiveOption
	 * @return member status
	 */
	public boolean isMemberStatusQualified(
			ProgramIncentiveOption pProgramIncentiveOption) {
		PersonIncentiveStatus lPersonIncentiveStatus = personIncentiveStatusMap.get(pProgramIncentiveOption.getProgramIncentiveOptionID());

		return (lPersonIncentiveStatus != null &&
				(BPMConstants.MEMBER_STATUS_QUALIFIED.equalsIgnoreCase(lPersonIncentiveStatus.getPersonStatus())
				|| BPMConstants.MEMBER_STATUS_EXEMPT_QUALIFIED.equalsIgnoreCase(lPersonIncentiveStatus.getPersonStatus())
				|| BPMConstants.MEMBER_STATUS_EXEMPT.equalsIgnoreCase(lPersonIncentiveStatus.getPersonStatus()))
				);

		/*
		 * String newMemberStatus = member
		 * .getMemberStatusCodeValue(businessProgramId); if
		 * (memberBusinessProgramStatusMap.get(businessProgramId) != null &&
		 * !newMemberStatus .equalsIgnoreCase(memberBusinessProgramStatusMap
		 * .get(businessProgramId))) { newMemberStatus =
		 * memberBusinessProgramStatusMap .get(businessProgramId); }
		 * 
		 * return
		 * (BPMConstants.MEMBER_STATUS_QUALIFIED.equalsIgnoreCase(newMemberStatus
		 * ) || BPMConstants.MEMBER_STATUS_EXEMPT_QUALIFIED.equalsIgnoreCase(
		 * newMemberStatus) );
		 */
	}

	/**
	 * determines if member status is DID_NOT_QUALIFY
	 * 
	 * @param pProgramIncentiveOption
	 * @return member status
	 */
	public boolean isMemberStatusDidNotQualify(ProgramIncentiveOption pProgramIncentiveOption) 
	{
		PersonIncentiveStatus lPersonIncentiveStatus = personIncentiveStatusMap
				.get(pProgramIncentiveOption.getProgramIncentiveOptionID());

		return (lPersonIncentiveStatus != null 
			&& (BPMConstants.MEMBER_STATUS_DID_NOT_QUALIFY.equalsIgnoreCase(lPersonIncentiveStatus.getPersonStatus()))
				);
	}

	public boolean isMemberStatusHAComplete(Integer businessProgramId) {
		String newMemberStatus = member
				.getMemberStatusCodeValue(businessProgramId);
		if (memberBusinessProgramStatusMap.get(businessProgramId) != null
				&& !newMemberStatus
						.equalsIgnoreCase(memberBusinessProgramStatusMap
								.get(businessProgramId))) {
			newMemberStatus = memberBusinessProgramStatusMap
					.get(businessProgramId);
		}
		return (BPMConstants.MEMBER_STATUS_HA_COMPLETED
				.equalsIgnoreCase(newMemberStatus) || BPMConstants.MEMBER_STATUS_EXEMPT_HA_COMPLETED
				.equalsIgnoreCase(newMemberStatus));
	}

	public boolean isMemberStatusActive(Integer businessProgramId) {
		String newMemberStatus = member
				.getMemberStatusCodeValue(businessProgramId);
		if (memberBusinessProgramStatusMap.get(businessProgramId) != null
				&& !newMemberStatus
						.equalsIgnoreCase(memberBusinessProgramStatusMap
								.get(businessProgramId))) {
			newMemberStatus = memberBusinessProgramStatusMap
					.get(businessProgramId);
		}
		return (BPMConstants.MEMBER_STATUS_ACTIVE
				.equalsIgnoreCase(newMemberStatus) || BPMConstants.MEMBER_STATUS_EXEMPT_ACTIVE
				.equalsIgnoreCase(newMemberStatus));
	}

	/**
	 * determines if contract date is after group's new hire date
	 * 
	 * @param businessProgram
	 * @return true/false
	 */
	public boolean isContractDateAfterGroupNewHireDate(
			BusinessProgramAdapter businessProgram) {
		// NOTE : contract date is assumed to be policy holder's contract
		// effective date
		boolean result = false;
		Calendar contractDate = null;
		if (businessProgram != null) {
			Integer businessProgramId = businessProgram.getBusinessProgramId();
			contractDate = member
					.getContractDateOfPolicyHolder(businessProgramId);
			Calendar groupNewHireDate = businessProgram.getNewHireDate();

			BPMUtils.setTimeToZero(contractDate);
			BPMUtils.setTimeToZero(groupNewHireDate);

			if (contractDate != null
					&& groupNewHireDate != null
					&& contractDate.getTime().compareTo(
							groupNewHireDate.getTime()) >= 0) {
				result = true;
			}
		}

		return result;
	}

	/**
	 * Determines if contract date is after the qualification end date
	 * 
	 * @param businessProgram
	 * @return true/false
	 */
	public boolean isContractDateAfterQualificationEndDate(
			BusinessProgramAdapter businessProgram) {
		// NOTE : contract date is assumed to be policy holder's contract
		// effective date
		boolean result = false;
		Calendar contractDate = null;
		if (businessProgram != null) {
			Integer businessProgramId = businessProgram.getBusinessProgramId();
			contractDate = member
					.getContractDateOfPolicyHolder(businessProgramId);
			Calendar lQualificationEndDate = businessProgram
					.getBusinessProgram().getQualificationWindowEndDate();

			BPMUtils.setTimeToZero(contractDate);
			BPMUtils.setTimeToZero(lQualificationEndDate);

			if (contractDate != null
					&& lQualificationEndDate != null
					&& contractDate.getTime().compareTo(
							lQualificationEndDate.getTime()) >= 0) {
				result = true;
			}
		}

		return result;
	}

	/**
	 * determines if member joined after groups new hire date This is for a
	 * non-policy holder that joins an existing contract.
	 * 
	 * @param programAdapter
	 * @return true/false
	 */
	public boolean isMemberJoinedAfterGroupNewHireDate(
			BusinessProgramAdapter programAdapter) {
		// NOTE : MemberJoinedDate is assumed to be member contract effective
		// date
		boolean result = false;
		Calendar memberJoinedDate = null;
		Calendar lNewHireDate = Calendar.getInstance();

		if (programAdapter != null) {
			for (ProgramIncentiveOption lProgramIncentiveOption : programAdapter
					.getProgramIncentiveOptions()) {
				memberJoinedDate = getEarliestContractDate(programAdapter);
				lNewHireDate.setTime(lProgramIncentiveOption.getNewHireDate());

				if (memberJoinedDate == null) {
					return false;
				}

				BPMUtils.setTimeToZero(memberJoinedDate);
				BPMUtils.setTimeToZero(lNewHireDate);

				// EV 58085 If joined after New Hire Date but not after
				// Program End Date.
				if (memberJoinedDate.getTime()
						.compareTo(lNewHireDate.getTime()) >= 0
						&& !isMemberJoinedAfterProgramEndDate(programAdapter)) {
					memberExemptionMap.put(lProgramIncentiveOption
							.getProgramIncentiveOptionID(),
							BPMConstants.OVERRIDE_CODE_EXEMPTION);
					memberExemptionReasonMap
							.put(lProgramIncentiveOption
									.getProgramIncentiveOptionID(),
									BPMConstants.BPM_EXEMPTION_REASON_JOINDT_AFTER_GRPNEWHIREDT);

					// Create a Person Incentive Status for this incentive and
					// set its status to EXEMPT.
					findOrCreatePersonIncentiveStatus(programAdapter,
							lProgramIncentiveOption
									.getProgramIncentiveOptionID(), 0,
							BPMConstants.MEMBER_STATUS_EXEMPT);

					result = true;
				}
				// EV 58085
			}
		}
		return result;
	}

	/**
	 * Determines if member joined after qualification end date This is for a
	 * non-policy holder that joins an existing contract.
	 * 
	 * @param businessProgram
	 * @return true/false
	 */
	public boolean isMemberJoinedAfterQualificationEndDate(
			BusinessProgramAdapter businessProgram) {
		// NOTE : MemberJoinedDate is assumed to be member contract effective
		// date
		boolean result = false;
		Calendar memberJoinedDate = null;
		if (businessProgram != null) {
			memberJoinedDate = getEarliestContractDate(businessProgram);
			Calendar qualificationEndDate = businessProgram
					.getBusinessProgram().getQualificationWindowEndDate();

			if (memberJoinedDate == null) {
				return false;
			}

			BPMUtils.setTimeToZero(memberJoinedDate);
			BPMUtils.setTimeToZero(qualificationEndDate);

			if (memberJoinedDate.getTime().compareTo(
					qualificationEndDate.getTime()) >= 0) {
				result = true;
			}
		}

		return result;
	}

	/**
	 * Determines if member joined after program end date This is for a
	 * non-policy holder that joins an existing contract.
	 * 
	 * @param businessProgram
	 * @return true/false
	 */
	public boolean isMemberJoinedAfterProgramEndDate(
			BusinessProgramAdapter businessProgram) {
		// NOTE : MemberJoinedDate is assumed to be member contract effective
		// date
		boolean result = false;
		Calendar memberJoinedDate = null;
		if (businessProgram != null) {
			memberJoinedDate = getEarliestContractDate(businessProgram);
			Calendar lProgramEndDate = businessProgram.getBusinessProgram()
					.getEndDate();

			if (memberJoinedDate == null) {
				return false;
			}

			BPMUtils.setTimeToZero(memberJoinedDate);
			BPMUtils.setTimeToZero(lProgramEndDate);

			if (memberJoinedDate.getTime().compareTo(lProgramEndDate.getTime()) >= 0) {
				result = true;
			}
		}

		return result;
	}

	/**
	 * Check to see if a site transfer, or a package transfer has happened after
	 * the group new hire date, or end of program window.
	 * 
	 * If the site transfer is from a participating to another participating
	 * site, it is considered continuous. If there is no gap in coverage during
	 * the package transfer, it is considered continuous.
	 *
	 * @return
	 */
	private boolean isSiteAndPackageExempt(BusinessProgramAdapter programAdapter) {
		Calendar lNewHireDate = Calendar.getInstance();

		boolean result = false;
		Calendar lProgramEffectiveDate = programAdapter.getBusinessProgram()
				.getEffectiveDate();
		Calendar lProgramEndDate = programAdapter.getBusinessProgram()
				.getEndDate();

		for (ProgramIncentiveOption lProgramIncentiveOption : programAdapter
				.getProgramIncentiveOptions()) {
			result = false;
			lNewHireDate.setTime(lProgramIncentiveOption.getNewHireDate());

			CoverageDatesTO lCoverageDatesTO = getLatestCoverageDates(
					programAdapter, lProgramEffectiveDate, lProgramEndDate);

			Calendar packageDate = lCoverageDatesTO.getPackageDate();
			Calendar subgroupDate = lCoverageDatesTO.getSubgroupDate();

			if (subgroupDate != null) {
				BPMUtils.setTimeToZero(subgroupDate);
			}

			if (packageDate != null) {
				BPMUtils.setTimeToZero(packageDate);
			}
			BPMUtils.setTimeToZero(lProgramEndDate);
			BPMUtils.setTimeToZero(lNewHireDate);

			if (subgroupDate != null
					&& subgroupDate.getTime().compareTo(
							lProgramEndDate.getTime()) >= 0) {
				logger.info("Subgroup Date = "
						+ fmt.format(subgroupDate.getTime()));
				logger.info("Subgroup change (from non-particip to particip) after Program End Date.");
				result = false;
			}
			if (packageDate != null
					&& packageDate.getTime().compareTo(
							lProgramEndDate.getTime()) >= 0) {
				logger.info("Package Date = "
						+ fmt.format(packageDate.getTime()));
				logger.info("Package change (from non-particip to particip) after Program End Date.");
				result = false;
			}
			if (subgroupDate != null
					&& subgroupDate.getTime().compareTo(lNewHireDate.getTime()) >= 0) {
				logger.info("Subgroup Date = "
						+ fmt.format(subgroupDate.getTime()));
				logger.info("Subgroup change (from non-particip to particip) after New Hire Date.");
				result = true;
			}
			if (packageDate != null
					&& packageDate.getTime().compareTo(lNewHireDate.getTime()) >= 0) {
				logger.info("Package Date = "
						+ fmt.format(packageDate.getTime()));
				logger.info("Package change (from non-particip to particip) after New Hire Date.");
				result = true;
			}

			// EV 58085
			if (result == true) {
				memberExemptionMap.put(
						lProgramIncentiveOption.getProgramIncentiveOptionID(),
						BPMConstants.OVERRIDE_CODE_EXEMPTION);
				memberExemptionReasonMap
						.put(lProgramIncentiveOption
								.getProgramIncentiveOptionID(),
								BPMConstants.BPM_EXEMPTION_REASON_JOINDT_AFTER_GRPNEWHIREDT);

				// Create a Person Incentive Status for this incentive and set
				// its status to EXEMPT.
				findOrCreatePersonIncentiveStatus(programAdapter,
						lProgramIncentiveOption.getProgramIncentiveOptionID(),
						0, BPMConstants.MEMBER_STATUS_EXEMPT);
			}
			// EV 58085
		}

		logger.info("Site or Package Transfer Exempt = " + result);

		return result;
	}

	/*
	 * Capture latest subgroup and package dates. Also, determines gap in
	 * coverage.
	 */
	private CoverageDatesTO getLatestCoverageDates(
			BusinessProgramAdapter businessProgram,
			Calendar lProgramEffectiveDate, Calendar lProgramEndDate) {

		CoverageDatesTO lCoverageDatesTO = new CoverageDatesTO();

		boolean lCurrentSubgroupExists = false;
		boolean lCurrentPackageExists = false;
		Calendar packageDate = null;
		Calendar subgroupDate = null;

		if (businessProgram != null) {

			if (subgroupHistories != null) {
				SubgroupHistory lCurrentSubgroup = null;

				// EV 19514
				// Check to see if there is at least one current subgroup.
				// If not, the subgroup is termed.
				for (int w = 0; w < subgroupHistories.size(); w++) {
					if (subgroupHistories.get(w).isCurrent()) {
						lCurrentSubgroupExists = true;
						break;
					}
				}

				int j = 0;
				if (lCurrentSubgroupExists == false) {
					for (j = 0; j < subgroupHistories.size(); j++) {
						if (subgroupHistories.get(j).getGroupID().intValue() == businessProgram
								.getBusinessProgram().getGroupID()
								&& subgroupHistories.get(j).getSubgroupID()
										.intValue() == businessProgram
										.getBusinessProgram().getSubgroupID()) {
							lCurrentSubgroup = subgroupHistories.get(j);
							break;
						}
					}
				} else {
					// Find the first subgroup whose group is the same as the
					// passed in business program.
					for (j = 0; j < subgroupHistories.size(); j++) {
						if ((subgroupHistories.get(j).getEffectiveDate()
								.before(lProgramEffectiveDate.getTime()) || (subgroupHistories
								.get(j).getEffectiveDate()
								.after(lProgramEffectiveDate.getTime()) && subgroupHistories
								.get(j).getEffectiveDate()
								.before(lProgramEndDate.getTime())))
								&& subgroupHistories.get(j).getGroupID()
										.intValue() == businessProgram
										.getBusinessProgram().getGroupID()
								&& subgroupHistories.get(j).getSubgroupID()
										.intValue() == businessProgram
										.getBusinessProgram().getSubgroupID()) {
							lCurrentSubgroup = subgroupHistories.get(j);
							break;
						}
					}
				}

				if (lCurrentSubgroup != null) {
					subgroupDate = Calendar.getInstance();
					subgroupDate.setTime(lCurrentSubgroup.getEffectiveDate());

					SubgroupHistory lPreviousSubgroup = null;
					for (int k = j; k < subgroupHistories.size(); k++) {
						lPreviousSubgroup = subgroupHistories.get(k);

						// Check if the previous subgroup in the list has the
						// same group ID
						// as the business program that was passed in.
						if (lPreviousSubgroup.getGroupID().intValue() == businessProgram
								.getBusinessProgram().getGroupID()) {
							if (lPreviousSubgroup.isParticipating() == false) {
								// Previous Subgroup was not participating, this
								// one is.
								// Member has switched from a non-participating
								// Subgroup
								// to a participating one.
								// Take the new Subgroup date and break.
								subgroupDate.setTime(lCurrentSubgroup
										.getEffectiveDate());
								break;
							} else {
								subgroupDate.setTime(lPreviousSubgroup
										.getEffectiveDate());
								lCurrentSubgroup = lPreviousSubgroup;
							}
						}
					}
				}
			}

			if (packageHistories != null) {
				for (int w = 0; w < packageHistories.size(); w++) {
					if (packageHistories.get(w).isCurrent()) {
						lCurrentPackageExists = true;
						break;
					}
				}

				PackageHistory lCurrentPackage = null;
				int j = 0;

				if (lCurrentPackageExists == false) {
					for (j = 0; j < packageHistories.size(); j++) {
						if (packageHistories.get(j).getGroupID().intValue() == businessProgram
								.getBusinessProgram().getGroupID()
								&& packageHistories.get(j).getSubgroupID()
										.intValue() == businessProgram
										.getBusinessProgram().getSubgroupID()) {
							lCurrentPackage = packageHistories.get(j);
							break;
						}
					}
				} else {
					// Find the package that is in the same group as the
					// business program.
					for (j = 0; j < packageHistories.size(); j++) {
						if ((packageHistories.get(j).getEffectiveDate()
								.before(lProgramEffectiveDate.getTime()) || (packageHistories
								.get(j).getEffectiveDate()
								.after(lProgramEffectiveDate.getTime()) && packageHistories
								.get(j).getEffectiveDate()
								.before(lProgramEndDate.getTime())))
								&& packageHistories.get(j).getGroupID()
										.intValue() == businessProgram
										.getBusinessProgram().getGroupID()
								&& packageHistories.get(j).getSubgroupID()
										.intValue() == businessProgram
										.getBusinessProgram().getSubgroupID()) {
							lCurrentPackage = packageHistories.get(j);
							break;
						}
					}
				}

				if (lCurrentPackage != null) {
					packageDate = Calendar.getInstance();
					packageDate.setTime(lCurrentPackage.getEffectiveDate());

					PackageHistory lPreviousPackage = null;
					for (int k = j; k < packageHistories.size(); k++) {
						lPreviousPackage = packageHistories.get(k);

						// Check if the previous package in the list has the
						// same same group number
						// as the business program that was passed in.
						if (lPreviousPackage.getGroupID().intValue() == businessProgram
								.getBusinessProgram().getGroupID()) {
							if (lPreviousPackage.isParticipating() == false) {
								// Previous package was not participating, this
								// one is.
								// Member has switched from a non-participating
								// package
								// to a participating one.
								// Take the new package date.
								packageDate.setTime(lCurrentPackage
										.getEffectiveDate());
								break;
							} else {
								Calendar lCurrentStartDate = Calendar
										.getInstance();
								lCurrentStartDate.setTime(lCurrentPackage
										.getEffectiveDate());
								Calendar lPreviousEndDate = Calendar
										.getInstance();
								lPreviousEndDate.setTime(lPreviousPackage
										.getEndDate());

								int lGapInCoverage = BPMUtils
										.getDaysBetweenDates(lCurrentStartDate,
												lPreviousEndDate);
								// Was there a gap in coverage?
								// If there was, treat it like a package
								// transfer.
								if (lGapInCoverage > 1) {
									logger.info("Gap in Coverage = "
											+ lGapInCoverage + " days.");
									packageDate.setTime(lCurrentPackage
											.getEffectiveDate());
									break;
								} else {
									// If the previous one was also
									// participating
									packageDate.setTime(lPreviousPackage
											.getEffectiveDate());
									lCurrentPackage = lPreviousPackage;
								}
							}
						}
					}
				}
			}
		}

		lCoverageDatesTO.setPackageDate(packageDate);
		lCoverageDatesTO.setSubgroupDate(subgroupDate);

		return lCoverageDatesTO;
	}

	/*
	 * Determine coverage effective based on package date and business program
	 * effective date.
	 */
	private Calendar determineCoverageEffectiveDate(
			BusinessProgramAdapter businessProgram) {
		Calendar coverageEffectiveDate = null;

		Calendar lProgramEffectiveDate = businessProgram.getBusinessProgram()
				.getEffectiveDate();
		Calendar lProgramEndDate = businessProgram.getBusinessProgram()
				.getEndDate();

		CoverageDatesTO latestCoverageDates = getLatestCoverageDates(
				businessProgram, lProgramEffectiveDate, lProgramEndDate);

		Calendar packageDate = latestCoverageDates.getPackageDate();

		// default to program effective date.
		if (packageDate == null) {

			return lProgramEffectiveDate;
		}

		if (packageDate.before(lProgramEffectiveDate)
				|| packageDate.equals(lProgramEffectiveDate)) {
			coverageEffectiveDate = lProgramEffectiveDate;
			// possible new hire or dependent add
		} else if (packageDate.after(lProgramEffectiveDate)) {
			coverageEffectiveDate = packageDate;
		}

		return coverageEffectiveDate;
	}

	/**
	 * Determines whether the member is the contract holder for a specific
	 * business program.
	 * 
	 * @param businessProgramId
	 *            the business program identifier
	 * @return true if the member is the contract holder, false otherwise
	 */
	public boolean isContractHolder(int businessProgramId) {
		boolean result = false;

		String relationship = member
				.getRelationshipToContractHolder(businessProgramId);

		if (PersonRelationship.REL_TYPE_SELF.equals(relationship)) {
			result = true;
		}

		return result;
	}

	private MemberAdapter getContractHolder(int businessProgramId) {
		MemberAdapter mbr = null;

		if (isContractHolder(businessProgramId)) {
			mbr = this;
		} else if (relatedMembers != null && relatedMembers.size() > 0) {
			mbr = getRelatedMember(businessProgramId,
					PersonRelationship.REL_TYPE_SELF);
		}

		return mbr;
	}

	private MemberAdapter getSpouse(int businessProgramId) {
		MemberAdapter mbr = null;

		if (relatedMembers != null && relatedMembers.size() > 0) {
			if (isContractHolder(businessProgramId)) {
				mbr = getRelatedMember(businessProgramId,
						PersonRelationship.REL_TYPE_SPOUSE);
			} else {
				mbr = getRelatedMember(businessProgramId,
						PersonRelationship.REL_TYPE_SELF);
			}
		}

		return mbr;
	}

	private MemberAdapter getDomesticPartner(int businessProgramId) {
		MemberAdapter mbr = null;

		if (relatedMembers != null && relatedMembers.size() > 0) {
			if (isContractHolder(businessProgramId)) {
				mbr = getRelatedMember(businessProgramId,
						PersonRelationship.REL_TYPE_DOMESTIC_PARTNER);
			} else {
				mbr = getRelatedMember(businessProgramId,
						PersonRelationship.REL_TYPE_SELF);
			}
		}

		return mbr;
	}

	private MemberAdapter getRelatedMember(int businessProgramId,
			String relationship) {
		MemberAdapter mbr = null;

		Iterator<MemberAdapter> iter = relatedMembers.iterator();
		while (iter.hasNext() && mbr == null) {
			MemberAdapter relatedMember = iter.next();
			if (relatedMember != null
					&& relatedMember.getMember() != null
					&& relatedMember.getMember().getMemberContractProgramTO(businessProgramId) != null
					&& relatedMember.getMember().getMemberContractProgramTO(businessProgramId).getBusinessProgramID().intValue() == businessProgramId
					&& relationship
							.equals(relatedMember.getMember()
									.getRelationshipToContractHolder(
											businessProgramId))) {
				mbr = relatedMember;
			}
		}

		return mbr;
	}

	private Calendar getEarliestContractDate(
			BusinessProgramAdapter businessProgram) {
		Calendar contractDate = null;
		boolean lCurrentContractExists = false;

		if (businessProgram != null) {

			if (contractHistories != null) {
				// EV 19514
				// Check to see if there is at least one current contract.
				// If not, the contract is termed.
				for (int w = 0; w < contractHistories.size(); w++) {
					if (contractHistories.get(w).isCurrent()) {
						lCurrentContractExists = true;
						break;
					}
				}

				int j = 0;
				ContractHistory lCurrentContract = null;

				// If there are no current contracts (the contract has been
				// terminated)
				// find the first contract whose biz program ID matches the biz
				// program ID passed in.
				if (lCurrentContractExists == false) {
					for (j = 0; j < contractHistories.size(); j++) {
						if (contractHistories.get(j).getGroupID().intValue() == businessProgram
								.getBusinessProgram().getGroupID()
								&& contractHistories.get(j).getSubgroupID()
										.intValue() == businessProgram
										.getBusinessProgram().getSubgroupID()) {
							lCurrentContract = contractHistories.get(j);
							break;
						}
					}
				} else {
					// Find the first contract whose contract is the same as the
					// passed in business program.
					for (j = 0; j < contractHistories.size(); j++) {
						if (contractHistories.get(j).isCurrent()
								&& contractHistories.get(j).getGroupID()
										.intValue() == businessProgram
										.getBusinessProgram().getGroupID()
								&& contractHistories.get(j).getSubgroupID()
										.intValue() == businessProgram
										.getBusinessProgram().getSubgroupID()) {
							lCurrentContract = contractHistories.get(j);
							break;
						}
					}
				}

				if (lCurrentContract != null) {
					contractDate = Calendar.getInstance();
					contractDate.setTime(lCurrentContract.getEffectiveDate());

					ContractHistory lPreviousContract = null;
					for (int k = j; k < contractHistories.size(); k++) {
						lPreviousContract = contractHistories.get(k);

						// Check if the previous contract in the list has the
						// same group ID
						// as the business program that was passed in, and it's
						// the same relationship.
						// (If the relationship changes it's considered a new
						// contract.
						if (lPreviousContract.getGroupID().intValue() == businessProgram
								.getBusinessProgram().getGroupID()
								&& lPreviousContract.getGroupID().intValue() == businessProgram
										.getBusinessProgram().getSubgroupID()
								&& lPreviousContract.getRelationshipCode()
										.intValue() == lCurrentContract
										.getRelationshipCode().intValue()) {
							Calendar lCurrentStartDate = Calendar.getInstance();
							lCurrentStartDate.setTime(lCurrentContract
									.getEffectiveDate());
							Calendar lPreviousEndDate = Calendar.getInstance();
							lPreviousEndDate.setTime(lPreviousContract
									.getEndDate());

							int lGapInCoverage = BPMUtils.getDaysBetweenDates(
									lCurrentStartDate, lPreviousEndDate);
							// Was there a gap in coverage?
							// If there was, treat it like a contract transfer.
							if (lGapInCoverage > 1) {
								logger.info("Gap in Coverage = "
										+ lGapInCoverage + " days.");
								contractDate.setTime(lCurrentContract
										.getEffectiveDate());
								break;
							} else {
								// Continuous coverage
								contractDate.setTime(lPreviousContract
										.getEffectiveDate());
								lCurrentContract = lPreviousContract;
							}
						}
					}
				}
			}
		}

		return contractDate;
	}

	/**
	 * Check each Qualification Checkmark to see if it is completed. ALL
	 * checkmark requirements need to be completed.
	 * 
	 * @param program
	 * @return
	 */
	public boolean checkQualificationCheckmarks(BusinessProgramAdapter program) {
		ArrayList<QualificationCheckmark> lQualificationCheckmarks = (ArrayList<QualificationCheckmark>) program
				.getQualificationCheckmarks();

		if (lQualificationCheckmarks == null
				|| lQualificationCheckmarks.size() < 1) {
			// No checkmarks have been set up for this buiness program.
			return false;
		}

		/*
		 * Go through the participation group requirements and compare them with
		 * the member's membership attributes. If the member's attributes match
		 * the participation, add this qualification-checkmark to the
		 * participating-checkmarks array.
		 */
		for (QualificationCheckmark lQualificationCheckmark : lQualificationCheckmarks) {
			boolean lPersonParticipatesInThisCheckmark = determineParticipation(
					lQualificationCheckmark.getParticipationGroup(), program);

			if (lPersonParticipatesInThisCheckmark == true) {
				participatingQualificationCheckmarks
						.add(lQualificationCheckmark);
			}
		}

		ArrayList<Boolean> lMetCheckmarkRequirements = new ArrayList<Boolean>();
		ArrayList<Boolean> lMetQualificationCheckmarks = new ArrayList<Boolean>();

		for (int i = 0; i < participatingQualificationCheckmarks.size(); i++) {
			QualificationCheckmark lQualificationCheckmark = participatingQualificationCheckmarks
					.get(i);

			// Initialize this qualification checkmark to false.
			lMetQualificationCheckmarks.add(i, new Boolean(false));
			// Clear the checkmark-requirements.
			lMetCheckmarkRequirements.clear();

			boolean lThisRequirementSatisfied = true;

			ArrayList<CheckmarkRequirement> lCheckmarkRequirements = lQualificationCheckmark
					.getCheckmarkRequirements();

			for (int j = 0; j < lCheckmarkRequirements.size(); j++) {
				CheckmarkRequirement lCheckmarkRequirement = lCheckmarkRequirements
						.get(j);

				// Check the details of each requirement.
				lThisRequirementSatisfied = checkRequirementDetails(
						lCheckmarkRequirement, program,
						lQualificationCheckmark.getProgramIncentiveOptionID());

				// Check if this requirement be Met or Not-Met.
				// One qualification checkmark might be: BIO Marker Met, and
				// take an Online class.
				// Another qualification checkmark might be: BIO Marker NOT_Met,
				// and take a phone class.

				if (lThisRequirementSatisfied
						&& BPMConstants.BPM_QUAL_STAT_CD_MET
								.equals(lCheckmarkRequirement
										.getQualificationStatusCode())) {
					lMetCheckmarkRequirements.add(j, new Boolean(true));
				} else if (!lThisRequirementSatisfied
						&& BPMConstants.BPM_QUAL_STAT_CD_NOT_MET
								.equals(lCheckmarkRequirement
										.getQualificationStatusCode())) {
					// If the checkmark was not met, and the requirement status
					// condition is NOT_MET, mark the
					// checkmark requirement as true.
					lMetCheckmarkRequirements.add(j, new Boolean(true));
				} else {
					lMetCheckmarkRequirements.add(j, new Boolean(false));
				}
			}

			// Went through all the qualification-checkmark requirements.
			// Now check all the requirements.
			// The relationship between the CheckmarkRequirements is one of AND.
			// If one is false, the qualification checkmark does not qualify.
			for (Boolean lCheckmarkRequirement : lMetCheckmarkRequirements) {
				if (lCheckmarkRequirement) {
					if (lMetQualificationCheckmarks.get(i) != null) {
						lMetQualificationCheckmarks.remove(i);
					}
					lMetQualificationCheckmarks.add(i, new Boolean(true));
				} else if (!lCheckmarkRequirement) {
					// The relationship between the CheckmarkRequirements is one
					// of AND.
					// All Requirements need to be satisfied. If one is false,
					// the qualification checkmark does not qualify.
					if (lMetQualificationCheckmarks.get(i) != null) {
						lMetQualificationCheckmarks.remove(i);
					}
					lMetQualificationCheckmarks.add(i, new Boolean(false));
					break;
				}
			}
		} // for i Qualification Checkmarks

		boolean lMetQualificationCheckmark = false;

		for (int i = 0; i < participatingQualificationCheckmarks.size(); i++) {
			// If this person's activities satisfied one of the qualification
			// checkmarks, it is qualified.
			if (lMetQualificationCheckmarks.get(i)) {
				logger.info("Qualified with "
						+ participatingQualificationCheckmarks.get(i)
								.getQualificationCheckmarkName());
				qualificationCheckmarkMap.put(program.getBusinessProgramId(),
						participatingQualificationCheckmarks.get(i)
								.getQualificationCheckmarkID());

				// -------------------------------------------------
				// EV 58085 - Assign Checkmarks to Incentive Options.
				// -------------------------------------------------
				// Assign the Met qualification checkmark ID, to the program
				// incentive option.
				checkIncentiveQualificationCheckmarks(program,
						participatingQualificationCheckmarks.get(i)
								.getQualificationCheckmarkID(),
						participatingQualificationCheckmarks.get(i)
								.getProgramIncentiveOptionID());

				lMetQualificationCheckmark = true;
			}
		}

		return lMetQualificationCheckmark;
	}

	/**
	 * Check the Requirement Details and the Member Activities to see if ANY of
	 * activities or activity types have been taken.
	 * 
	 * @param lCheckmarkRequirement
	 * @param pThisCheckmarkIncentiveOptionID
	 * @return
	 */
	private boolean checkRequirementDetails(
			CheckmarkRequirement lCheckmarkRequirement,
			BusinessProgramAdapter pProgramAdapter,
			Integer pThisCheckmarkIncentiveOptionID) {
		int lMemberActivityTaken = 0;
		int lRequiredQuantity = lCheckmarkRequirement.getQuantity();
		boolean lRequirementsMet = false;
		ArrayList<MemberActivity> lMemberActivities = (ArrayList<MemberActivity>) member
				.getMemberActivities(pProgramAdapter.getBusinessProgramId(),
						pProgramAdapter.getBusinessProgram()
								.isEvaluateTermedContract());
		ArrayList<MemberActivity> lMemberActivitiesMeetingRequirements = new ArrayList<MemberActivity>();

		// Within a CheckmarkRequirement, the relationship between the Details
		// is one of OR.
		// If one of them is met, the detail has been met.
		ArrayList<CheckmarkDetail> lCheckmarkDetails = lCheckmarkRequirement
				.getCheckmarkDetails();

		for (int i = 0; i < lCheckmarkDetails.size(); i++) {
			CheckmarkDetail lCheckmarkDetail = lCheckmarkDetails.get(i);
			
			//EV90207
			ProgramIncentiveOption lProgramIncentiveOption = findProgramIncentiveOption(pProgramAdapter, pThisCheckmarkIncentiveOptionID);
			if (lProgramIncentiveOption == null) {
				//break out of loop when checkmark is not for program.
				break;
			}
			java.sql.Date effectiveDate = BPMUtils.convertStringToSqlDate(lProgramIncentiveOption.getEffectiveDate(), BPMConstants.HP_BPM_COMMON_DATE_FORMAT);
			java.sql.Date completeByDeadlineDate = lProgramIncentiveOption.getCompletionDeadlineDate();
			String incentiveRuleTypeCode = lProgramIncentiveOption.getIncentiveRuleTypeCode();
			String incentedStatusTypeCode = lProgramIncentiveOption.getIncentedStatusTypeCode();
			
			// Can only have either an Activity, or an Activity Type per Detail.
			if (lCheckmarkDetail.getActivityID() != null
					&& lCheckmarkDetail.getActivityID().intValue() > 0) {
				
				for (MemberActivity lMemberActivity : lMemberActivities) {
					if (lMemberActivity.getActivity().getActivityID()
							.intValue() == lCheckmarkDetail.getActivityID()
							.intValue()) {
						if (this.isActivityCompleted(lMemberActivity
								.getActivity().getName(), lMemberActivity
								.getActivityStatus().getStatusCodeValue())) {
							// EV76364 - evaluate incentive option time period
							// if configured to an incentive option.
							Integer activityCompletionPeriod = determineIncentiveOptionTimePeriod(
									pProgramAdapter,
									pThisCheckmarkIncentiveOptionID);
							if (activityCompletionPeriod != null
									&& activityCompletionPeriod > 0) {
								if (isActivityCompletedWithinTimePeriod(
										activityCompletionPeriod,
										lMemberActivity)) {
									// Count this activity as one that satisfied
									// this requirement.
									lMemberActivitiesMeetingRequirements
											.add(lMemberActivity);
									lMemberActivityTaken++;
								}
							} else {
								//EV90207
								boolean activityCountsForThisIncentive = evaluateActivityIncentiveRules(
										lMemberActivity, pProgramAdapter, effectiveDate, completeByDeadlineDate, incentiveRuleTypeCode, incentedStatusTypeCode);
								if (activityCountsForThisIncentive) {
									lMemberActivitiesMeetingRequirements
											.add(lMemberActivity);
									lMemberActivityTaken++;
								}
							}
						}
					}
				}
			} else if (lCheckmarkDetail.getActivityTypeCodeID() != null
					&& lCheckmarkDetail.getActivityTypeCodeID().intValue() > 0) {
				for (MemberActivity lMemberActivity : lMemberActivities) {
					if (lMemberActivity.getActivityTypeCodeID().intValue() == lCheckmarkDetail
							.getActivityTypeCodeID().intValue()) {
						if (this.isActivityCompleted(lMemberActivity
								.getActivity().getName(), lMemberActivity
								.getActivityStatus().getStatusCodeValue())) {
							// EV76364 - evaluate incentive option time period
							// if configured to an incentive option.
							Integer activityCompletionPeriod = determineIncentiveOptionTimePeriod(
									pProgramAdapter,
									pThisCheckmarkIncentiveOptionID);
							if (activityCompletionPeriod != null
									&& activityCompletionPeriod > 0) {
								if (isActivityCompletedWithinTimePeriod(
										activityCompletionPeriod,
										lMemberActivity)) {
									// Count this activity as one that satisfied
									// this requirement.
									lMemberActivitiesMeetingRequirements
											.add(lMemberActivity);
									lMemberActivityTaken++;
								}
							} else {
								//EV90207
								boolean activityCountsForThisIncentive = evaluateActivityIncentiveRules(
										lMemberActivity, pProgramAdapter, effectiveDate, completeByDeadlineDate, incentiveRuleTypeCode, incentedStatusTypeCode);
								if (activityCountsForThisIncentive) {
									lMemberActivitiesMeetingRequirements
											.add(lMemberActivity);
									lMemberActivityTaken++;
								}
							}
						}
					}
				}
			} else if (lCheckmarkDetail.getActivityCollection() != null
					&& lCheckmarkDetail.getActivityCollection()
							.getCollectionID() > 0
					&& lCheckmarkDetail.getActivityCollection()
							.getCollectionActivities() != null) {

				lRequirementsMet = isCollectionMet(lCheckmarkDetail
						.getActivityCollection().getCollectionActivities(),
						lCheckmarkDetail.getActivityCollection(),
						lMemberActivities, lMemberActivitiesMeetingRequirements);

				// If requirementsMet is true, return. If not, we still want to
				// the check the other details
				// if one of them is true, then the requirement is true.
				if (lRequirementsMet) {
					lMemberActivityTaken++;
				}
			}

		}

		if (lMemberActivityTaken >= lRequiredQuantity) {
			
			for(MemberActivity lMemberActivity : lMemberActivitiesMeetingRequirements)
			{								
				lMemberActivity.setBusinessProgramIncentiveOptionID(pThisCheckmarkIncentiveOptionID);							
			}
			
			this.setMemberActivitiesMeetingRequirements(lMemberActivitiesMeetingRequirements);
			//EV88832				
			this.getMemberActivitiesMeetingRequirementsMap().put(pThisCheckmarkIncentiveOptionID, lMemberActivitiesMeetingRequirements);																
			
			lRequirementsMet = true;
		} else {
			lRequirementsMet = false;
		}

		return lRequirementsMet;
	}
	
	
	/**
	 * 
	 * @param pCollectionActivities
	 * @return
	 */
	public boolean isCollectionMet(
			List<ActivityDefinition> pCollectionActivities,
			ActivityCollection pActivityCollection,
			ArrayList<MemberActivity> pMemberActivities,
			ArrayList<MemberActivity> pMemberActivitiesMeetingRequirements) {
		int lRequiredQuantity = pActivityCollection.getRequiredQuantity();
		int lTakenQuantity = 0;
		for (ActivityDefinition lCollectionActivity : pCollectionActivities) {
			for (int j = 0; j < pMemberActivities.size(); j++) {
				MemberActivity lMemberActivity = pMemberActivities.get(j);

				if (lMemberActivity.getActivity().getActivityID().intValue() == lCollectionActivity
						.getActivityID().intValue()) {
					// If the member activity is one of the activities in the
					// checkmark collection
					// and member activity has been completed, increment
					// taken-quantity
					if (isActivityCompleted(lMemberActivity.getActivity()
							.getName(), lMemberActivity.getActivityStatus()
							.getStatusCodeValue())) {
						lTakenQuantity++;
						// Capture only the first activity as part of the
						// collection.
						if (lTakenQuantity == 1
								&& pMemberActivitiesMeetingRequirements != null) {
							pMemberActivitiesMeetingRequirements
									.add(lMemberActivity);
						}
					}
				}
			}
		}
		// If the required quantity has been satisfied, this checkmark detail
		// has been met.
		// We can NOT have a collection with a required quantity of 0. This has
		// to be enforced in the
		// bpm-admin page validation, but check here as well.
		if (lRequiredQuantity > 0) {
			if (lTakenQuantity >= lRequiredQuantity) {
				logger.info("Collection TakenQuantity = " + lTakenQuantity
						+ ", RequiredQuantity = " + lRequiredQuantity
						+ ", Met = true");
				return true;
			} else {
				// if an activity was recorded but all activities as a whole did
				// not meet
				// the collection requirements, then clear the ArrayList.
				if (pMemberActivitiesMeetingRequirements != null) {
					pMemberActivitiesMeetingRequirements.clear();
				}
				logger.info("Collection TakenQuantity = " + lTakenQuantity
						+ ", RequiredQuantity = " + lRequiredQuantity
						+ ", Met = false");
				return false;
			}
		}

		// If required quantity had been met, it would have returned true above.
		// If we got this far, there was no match. Return false.
		return false;
	}
	
	/* EV90207
	 * Loop through and find a program incentive option that corresponds to the checkmarkIncentiveOptionID.
	 */
	private ProgramIncentiveOption findProgramIncentiveOption(BusinessProgramAdapter programAdapter, Integer checkmarkIncentiveOptionID) {
		ProgramIncentiveOption programIncentiveOptionResult = null;
		Collection<ProgramIncentiveOption> lProgramIncentiveOptions = programAdapter.getProgramIncentiveOptions();
		for (ProgramIncentiveOption lProgramIncentiveOption : lProgramIncentiveOptions) {
			if (lProgramIncentiveOption.getProgramIncentiveOptionID().intValue() == checkmarkIncentiveOptionID.intValue()) {
				programIncentiveOptionResult = lProgramIncentiveOption;
			}
		}
		
		return programIncentiveOptionResult;
	}

	/**
	 * 
	 * @param program
	 * @return
	 */
	public void checkIncentiveOptions(BusinessProgramAdapter program) {

		ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>) program
				.getProgramIncentiveOptions();

		/**
		 * Determine if this person would receive certain incentives based on
		 * the person's benefit-packages. This method will remove or keep
		 * HRA/HSA incentives depending on the person's benefit-package.
		 */
		determineMemberAlignmentWithProgramIncentiveOptionUsingRelationshipNPackage(personPackages, lProgramIncentiveOptions,
				program);

		for (ProgramIncentiveOption lProgramIncentiveOption : lProgramIncentiveOptions) 
		{
			if (BPMConstants.PROGRAM_INCENTIVE_OPTION_ACTIVATION_ACTIVE.equalsIgnoreCase(lProgramIncentiveOption.getActivationStatusCode())
					&&
					(BPMConstants.BPM_INCENTED_STATUS_TYPE_ACTIVITY_BASED
					.equalsIgnoreCase(lProgramIncentiveOption
							.getIncentedStatusTypeCode())
					|| BPMConstants.BPM_INCENTED_STATUS_TYPE_ACTIVITY_PACKAGE_BASED
							.equalsIgnoreCase(lProgramIncentiveOption
									.getIncentedStatusTypeCode())
					|| BPMConstants.BPM_INCENTED_STATUS_TYPE_MULTI_ACTIVITY
							.equalsIgnoreCase(lProgramIncentiveOption
									.getIncentedStatusTypeCode()))) 
			{
				// If this incentive is required for the person's role, prod
				// type code, health plan, etc...
				boolean lRoleParticipatesInIncentive = determineParticipation(
						lProgramIncentiveOption.getParticipationGroup(),
						program);

				if (lRoleParticipatesInIncentive) {
					// If the Incentive Option is activity-based, loop through
					// the activity-incentives, and
					// person activities, until an activity that counts towards
					// that activity-incentive is found.
					// In the checkMemberActivities method, once that activity
					// is found, a personActivityIncentive
					// is added to the personActivityIncentives list.

					checkMemberActivities(lProgramIncentiveOption, program);
				}
			}
		}

	}

	

	/**
	 * Check all Member Activities against the Incentive Requirements, Family
	 * Participation role, and the incentive caps. Count all activities as long
	 * as under cap.
	 * 
	 * @param pProgramIncentiveOption
	 * @param pProgramAdapter
	 */
	private void checkMemberActivities(
			ProgramIncentiveOption pProgramIncentiveOption,
			BusinessProgramAdapter pProgramAdapter) {
		ArrayList<MemberActivity> lMemberActivities = (ArrayList<MemberActivity>) member
				.getMemberActivities(pProgramAdapter.getBusinessProgramId(),
						pProgramAdapter.getBusinessProgram()
								.isEvaluateTermedContract());

		// For each requirement, keep an entry in this array. Record whether
		// that requirement was met or not.
		ArrayList<Boolean> lMetRequirements = new ArrayList<Boolean>();
		ArrayList<Boolean> lBelowCapThatWasMet = new ArrayList<Boolean>();
		ArrayList<PersonActivityIncentive> lPersonActivityIncentivesThatWereMet = new ArrayList<PersonActivityIncentive>();

		ArrayList<IncentiveRequirement> lIncentiveRequirements = pProgramIncentiveOption
				.getIncentiveRequirements();
		ArrayList<Integer> lNumberOfActivitiesRequired = new ArrayList<Integer>();

		// Initialize the activities taken for each requirement to 0.
		for (int req = 0; req < lIncentiveRequirements.size(); req++) {
			lNumberOfActivitiesRequired.add(new Integer(0));
			lMetRequirements.add(new Boolean(false));
			lBelowCapThatWasMet.add(new Boolean(false));
		}

		for (int j = 0; j < lMemberActivities.size(); j++) {
			for (int req = 0; req < lIncentiveRequirements.size(); req++) {
				ArrayList<ActivityIncentive> lActivityIncentives = lIncentiveRequirements
						.get(req).getActivityIncentives();

				for (int i = 0; i < lActivityIncentives.size(); i++) {
					ActivityIncentive lActivityIncentive = lActivityIncentives
							.get(i);

					MemberActivity lMemberActivity = lMemberActivities.get(j);

					ContractTO lMemberContract = member
							.getMemberContract(lMemberActivity
									.getBusinessProgramID().intValue());
					Integer contractNo = lMemberContract.getContract()
							.getContractNumber();
					Integer relationship = lMemberContract
							.getRelationshipCode();

					Collection<IncentiveParticipant> lIncentiveParticipants = lActivityIncentive
							.getIncentiveParticipants();

					for (IncentiveParticipant lIncentiveParticipant : lIncentiveParticipants) {

						// Match to relationship
						if (relationship.intValue() == lIncentiveParticipant
								.getRelationshipCode().intValue()) {
							// Now check if the person has completed any
							// activity or an activity of the required
							// type.
							boolean lActivityCountsForThisIncentive = countActivityAgainstIncentive(
									lMemberActivity, lMemberActivities,
									lActivityIncentive, pProgramAdapter);

							boolean lBelowCap = false;
							if (lActivityCountsForThisIncentive) {
								String unitTypeCode = pProgramIncentiveOption
										.getIncentiveOption()
										.getIncentiveUnitTypeCode();
								lBelowCap = isIncentiveBelowOrMatchToCap(
										lActivityIncentive, lMemberActivity,
										lPersonActivityIncentivesThatWereMet,
										unitTypeCode);
							}

							if (lActivityCountsForThisIncentive && lBelowCap) {
								if (lNumberOfActivitiesRequired.size() > 0) {
									// If this is a multi-activity incentive,
									// and this is the 2nd or higher activity
									// taken,
									// increment the number taken by 1.
									int lNumberOfActivitiesAlreadyCountedForThisRequirement = lNumberOfActivitiesRequired
											.get(req).intValue();
									lNumberOfActivitiesAlreadyCountedForThisRequirement++;
									lNumberOfActivitiesRequired.remove(req);
									lNumberOfActivitiesRequired
											.add(req,
													new Integer(
															lNumberOfActivitiesAlreadyCountedForThisRequirement));
								}

								// EV 65424 - INC0315660, as long as we are
								// below cap, keep counting the activities.
								PersonActivityIncentive lPersonActivityIncentive = createPersonActivityIncentive(
										member.getPersonID(),
										lMemberActivity.getBusinessProgramID(),
										contractNo, lMemberActivity,
										lActivityIncentive,
										lIncentiveParticipant
												.getMaximumQuantity(),
										lIncentiveParticipant
												.getRelationshipCode()
										, pProgramIncentiveOption.getProgramIncentiveOptionID());

								// logger.info("--- Adding " +
								// lPersonActivityIncentive.getActivityID());

								lPersonActivityIncentivesThatWereMet
										.add(lPersonActivityIncentive);

								if (lNumberOfActivitiesRequired.size() > 0
										&& lNumberOfActivitiesRequired.get(req) != null
										&& lNumberOfActivitiesRequired.get(req)
												.intValue() >= lIncentiveRequirements
												.get(req).getRequiredQuantity()) {
									// The relationship between the activities
									// within one requirement is one of OR.
									// If one activity requirement is met, that
									// one requirement is satisfied.
									lMetRequirements.remove(req);
									lMetRequirements
											.add(req, new Boolean(true));

									lBelowCapThatWasMet.remove(req);
									lBelowCapThatWasMet.add(req, new Boolean(
											lBelowCap));
								}
							}
						} // if relationship match
					} // iterate through lIncentiveParticipants

				} // for i to activity incentive size
			} // for req, requirements
		} // for j activities

		boolean lThisIncentiveOptionSatisfied = false;

		// In case there is more than one requirement, the relationship between
		// requirements is one of AND.
		// If one is not met, the program-incentive-option can not be achieved.
		// And if there is only one requirement, we will loop only once.

		for (int req = 0; req < lIncentiveRequirements.size(); req++) {
			if (lMetRequirements.size() < 1 || lMetRequirements.size() <= req
					|| lMetRequirements.get(req) == null
					|| lMetRequirements.get(req).booleanValue() == false) {
				lThisIncentiveOptionSatisfied = false;
				// If one is not met, the program-incentive-option can not be
				// achieved.
				break;
			} else {
				lThisIncentiveOptionSatisfied = true;
			}
		}

		// If all the requirements have been satisfied, then the
		// program-incentive-option can be
		// recorded in the person-activity-incentive-status table.
		if (lThisIncentiveOptionSatisfied) {
			for (PersonActivityIncentive lPersonActivityIncentive : lPersonActivityIncentivesThatWereMet) {
				// EV78853 - No need to revisit capping rules when previously
				// done in this method.
				// boolean lBelowOrMatchToCap =
				// isIncentiveBelowOrMatchToCap(lPersonActivityIncentive);

				// if(lBelowOrMatchToCap)
				// {
				lPersonActivityIncentive.setActivationStatusCode(BPMConstants.PROGRAM_INCENTIVE_OPTION_ACTIVATION_ACTIVE);
				addToPersonActivityIncentives(lPersonActivityIncentive);
				// }
			}
		}
	}

	
	/**
	 * 
	 * @param pMemberActivity
	 * @param pActivityIncentive
	 * @param pProgramAdapter
	 * @return
	 */
	private boolean countActivityAgainstIncentive(
			MemberActivity pMemberActivity,
			ArrayList<MemberActivity> pMemberActivities,
			ActivityIncentive pActivityIncentive,
			BusinessProgramAdapter pProgramAdapter) {
		boolean lActivityCountsForThisIncentive = false;
		boolean lIsActivityInTheCollection = false;

		ActivityCollection lActivityCollection = pActivityIncentive
				.getActivityCollection();
		
		java.sql.Date effectiveDate = pActivityIncentive.getEffectiveDate();
		java.sql.Date completeByDeadlineDate = pActivityIncentive.getCompleteByDeadlineDate();
		String incentiveRuleTypeCode = pActivityIncentive.getIncentiveRuleTypeCode();
		String incentedStatusTypeCode = pActivityIncentive.getIncentedStatusTypeCode();

		// Is the activity being checked in the collection?
		if (lActivityCollection.getCollectionActivities() != null) {
			for (ActivityDefinition lCollectionActivity : lActivityCollection
					.getCollectionActivities()) {
				if (pMemberActivity.getActivity().getActivityID().intValue() == lCollectionActivity
						.getActivityID().intValue()) {
					lIsActivityInTheCollection = true;
					break;
				}
			}
		}

		// If this checkmark has a collection assigned to it, the collection ID
		// will be greater than 0.
		if (lActivityCollection != null
				&& lActivityCollection.getCollectionID() > 0
				&& lIsActivityInTheCollection) {
			List<ActivityDefinition> lCollectionActivities = lActivityCollection
					.getCollectionActivities();

			if (lCollectionActivities != null
					&& lCollectionActivities.size() > 0) {
				lActivityCountsForThisIncentive = isCollectionMet(
						lCollectionActivities, lActivityCollection,
						pMemberActivities, null);
			}
		}

		// Can only have either an Activity, or an Activity Type per Detail.
		if (pActivityIncentive.getActivityID() != null
				&& pActivityIncentive.getActivityID().intValue() > 0) {
			if (pMemberActivity.getActivity().getActivityID().intValue() == pActivityIncentive
					.getActivityID().intValue()) {
				lActivityCountsForThisIncentive = evaluateActivityIncentiveRules(
						pMemberActivity, pProgramAdapter, effectiveDate, completeByDeadlineDate, incentiveRuleTypeCode, incentedStatusTypeCode);
			}
		} else if (pActivityIncentive.getActivityTypeID() != null
				&& pActivityIncentive.getActivityTypeID().intValue() > 0) {
			if (pMemberActivity.getActivityTypeCodeID().intValue() == pActivityIncentive
					.getActivityTypeID().intValue()) {
				lActivityCountsForThisIncentive = evaluateActivityIncentiveRules(
						pMemberActivity, pProgramAdapter, effectiveDate, completeByDeadlineDate, incentiveRuleTypeCode, incentedStatusTypeCode);
			}
		}

		// EV46192 - If evaluating when termed contract exists, compare termed
		// date to activity status date.
		// Activities achieved after term date do not get incented. This code
		// was added to address
		// activities submitted retroactively.

		if (pProgramAdapter.getBusinessProgram().isEvaluateTermedContract()) {
			if (pMemberActivity
					.getActivityStatus()
					.getStatusEffectiveDate()
					.after(pProgramAdapter.getBusinessProgram()
							.getContractEndDate())) {
				// do not incent
				lActivityCountsForThisIncentive = false;
			}
		}

		return lActivityCountsForThisIncentive;
	}

	/**
	 * It's important to note that the incentive capping rule will only work
	 * when incentive option unit type is set to units. The contribution amount
	 * defined as an attribute in the current activity (ActivityIncentive) being
	 * processed is always a 0 amount. Also for OPTUM (clearing house for
	 * employers wanting to assign their own contribution amounts), the capping
	 * rule will not detect an exceeding contribution amount for the current
	 * activity since it does not carry forward the contribution amount from the
	 * activity event record. A second set of capping rules exist within the
	 * HRA, HSA, and Intelispend batch processes. One last note: Units or
	 * Dollars are accumulating at the incentive option level not across
	 * incentive options.
	 *
	 * @return
	 */
	private boolean isIncentiveBelowOrMatchToCap(
			ActivityIncentive pActivityIncentiveCurrent,
			MemberActivity lMemberActivity,
			Collection<PersonActivityIncentive> lPersonActivityIncentivesThatWereMet,
			String unitTypeCode) {

		int lNumberOfParticipantReceivedIncentives = 0;
		int lNumberOfFamilyReceivedIncentives = 0;

		boolean lBelowOrMatchToParticipantCap = false;
		boolean lBelowOrMatchToFamilyCap = false;

		// 1. Count towards the cap all incented activities of member's
		// relationships.
		for (int r = 0; r < existingRelatedPersonActivityIncentives.size(); r++) {
			if (existingRelatedPersonActivityIncentives.get(r)
					.getIncentiveOptionGroupID().intValue() == pActivityIncentiveCurrent
					.getActivityIncentiveGroupID().intValue()
					&& existingRelatedPersonActivityIncentives.get(r)
							.getIncentiveOptionRequirementID().intValue() == pActivityIncentiveCurrent
							.getActivityIncentiveGroupReqID().intValue()
					// EV 78853
					&& existingRelatedPersonActivityIncentives.get(r)
							.getIncentiveOptionID().intValue() == pActivityIncentiveCurrent
							.getIncentiveOptionID().intValue()) {
				// Number of the times a person related to the participant has
				// received this incentive,
				// to be compared with the family cap.
				// EV78853
				if (unitTypeCode != null
						&& unitTypeCode
								.equals(BPMConstants.BPM_IO_UNIT_TYPE_UNITS)) {
					// Increment by 1 when incentive option unit type is
					// "UNITS".
					lNumberOfFamilyReceivedIncentives++;
				} else {
					if (existingRelatedPersonActivityIncentives.get(r)
							.getIncentiveQuantity() != null
							&& existingRelatedPersonActivityIncentives.get(r)
									.getIncentiveQuantity() > 0) {
						lNumberOfFamilyReceivedIncentives += existingRelatedPersonActivityIncentives
								.get(r).getIncentiveQuantity();
					}
				}
			}
		}

		PersonActivityIncentive lPersonActivityIncentiveMatch = null;

		// 2.Count towards the cap activities already incented for member.
		for (PersonActivityIncentive lPersonActivityIncentive : personActivityIncentives) {

			if (lPersonActivityIncentive != null) {
				// If this activity-incentive has already been counted for this
				// person,
				// add it to the incentives received by this person, as well as
				// the overall received by the family.
				// Before a person receives the very first activity, the person
				// activity group & req are null. So
				// check for null group and req ID.
				if (lPersonActivityIncentive.getIncentiveOptionGroupID() != null
						&& lPersonActivityIncentive
								.getIncentiveOptionRequirementID() != null
						&& lPersonActivityIncentive.getIncentiveOptionGroupID()
								.intValue() == pActivityIncentiveCurrent
								.getActivityIncentiveGroupID().intValue()
						&& lPersonActivityIncentive
								.getIncentiveOptionRequirementID().intValue() == pActivityIncentiveCurrent
								.getActivityIncentiveGroupReqID().intValue()
						// EV78853
						&& lPersonActivityIncentive.getIncentiveOptionID()
								.intValue() == pActivityIncentiveCurrent
								.getIncentiveOptionID().intValue()) {
					if (lPersonActivityIncentive.getIncentiveQuantity() != null) {
						// lPersonActivityIncentive = the row in the
						// prsn_pgm_actv_incntv_sts table.
						// The very first time ever, the getIncentiveQuantity
						// will be zero.
						// Then once counted, this method will make sure it's
						// below cap.
						// EV78853
						if (unitTypeCode != null
								&& unitTypeCode
										.equals(BPMConstants.BPM_IO_UNIT_TYPE_UNITS)) {
							// Increment by 1 when incentive option unit type is
							// "UNITS".
							lNumberOfFamilyReceivedIncentives++;
							lNumberOfParticipantReceivedIncentives++;
						} else {
							if (lPersonActivityIncentive.getIncentiveQuantity() != null
									&& lPersonActivityIncentive
											.getIncentiveQuantity().SIZE > 0) {
								lNumberOfFamilyReceivedIncentives += lPersonActivityIncentive
										.getIncentiveQuantity();
								lNumberOfParticipantReceivedIncentives += lPersonActivityIncentive
										.getIncentiveQuantity();
							}
						}
						lPersonActivityIncentiveMatch = lPersonActivityIncentive;
					}
				}
			}
		}

		// 3.Count towards the cap activities approved to be incented.
		for (PersonActivityIncentive lPersonActivityIncentive : lPersonActivityIncentivesThatWereMet) {

			if (lPersonActivityIncentive != null) {
				// If this activity-incentive has already been counted for this
				// person,
				// add it to the incentives received by this person, as well as
				// the overall received by the family.
				// Before a person receives the very first activity, the person
				// activity group & req are null. So
				// check for null group and req ID.
				if (lPersonActivityIncentive.getIncentiveOptionGroupID() != null
						&& lPersonActivityIncentive
								.getIncentiveOptionRequirementID() != null
						&& lPersonActivityIncentive.getIncentiveOptionGroupID()
								.intValue() == pActivityIncentiveCurrent
								.getActivityIncentiveGroupID().intValue()
						&& lPersonActivityIncentive
								.getIncentiveOptionRequirementID().intValue() == pActivityIncentiveCurrent
								.getActivityIncentiveGroupReqID().intValue()
						// EV78853
						&& lPersonActivityIncentive.getIncentiveOptionID()
								.intValue() == pActivityIncentiveCurrent
								.getIncentiveOptionID().intValue()) {
					if (lPersonActivityIncentive.getIncentiveQuantity() != null) {
						// lPersonActivityIncentive = the row in the
						// prsn_pgm_actv_incntv_sts table.
						// The very first time ever, the getIncentiveQuantity
						// will be zero.
						// Then once counted, this method will make sure it's
						// below cap.
						// EV78853
						if (unitTypeCode != null
								&& unitTypeCode
										.equals(BPMConstants.BPM_IO_UNIT_TYPE_UNITS)) {
							// Increment by 1 when incentive option unit type is
							// "UNITS".
							lNumberOfFamilyReceivedIncentives++;
							lNumberOfParticipantReceivedIncentives++;
						} else {
							if (lPersonActivityIncentive.getIncentiveQuantity() != null
									&& lPersonActivityIncentive
											.getIncentiveQuantity().SIZE > 0) {
								lNumberOfFamilyReceivedIncentives += lPersonActivityIncentive
										.getIncentiveQuantity();
								lNumberOfParticipantReceivedIncentives += lPersonActivityIncentive
										.getIncentiveQuantity();
							}
						}
						lPersonActivityIncentiveMatch = lPersonActivityIncentive;
					}
				}
			}
		}

		// 4. Determine if member activity being processed is already incented.
		// If not,
		// count it against the cap.
		boolean matchToActivityIncentive = false;
		for (PersonActivityIncentive lPersonActivityIncentive : personActivityIncentives) {
			if (lPersonActivityIncentive.getBusinessProgramID().intValue() == lMemberActivity
					.getBusinessProgramID().intValue()
					&& lPersonActivityIncentive.getPersonDemographicsID()
							.intValue() == lMemberActivity
							.getPersonDemographicsID().intValue()
					&& lPersonActivityIncentive.getActivityID().intValue() == lMemberActivity
							.getActivity().getActivityID().intValue()
					&& lPersonActivityIncentive.getRegistrationID().equals(
							lMemberActivity.getRegistrationID())) {
				matchToActivityIncentive = true;
				break;
			}
		}

		if (matchToActivityIncentive) {
			// do not count against cap. Activity already counted.
		} else if (lPersonActivityIncentiveMatch != null) {
			// count against cap.
			if (lPersonActivityIncentiveMatch.getIncentiveQuantity() != null) {
				if (unitTypeCode != null
						&& unitTypeCode
								.equals(BPMConstants.BPM_IO_UNIT_TYPE_UNITS)) {
					// Increment by 1 when incentive option unit type is
					// "UNITS".
					lNumberOfFamilyReceivedIncentives++;
					lNumberOfParticipantReceivedIncentives++;
				} else {
					if (lPersonActivityIncentiveMatch.getIncentiveQuantity() != null
							&& lPersonActivityIncentiveMatch
									.getIncentiveQuantity().SIZE > 0) {
						lNumberOfFamilyReceivedIncentives += lPersonActivityIncentiveMatch
								.getIncentiveQuantity();
						lNumberOfParticipantReceivedIncentives += lPersonActivityIncentiveMatch
								.getIncentiveQuantity();
					}
				}
			}
		} else if (lMemberActivity != null) {
			if (unitTypeCode != null
					&& unitTypeCode.equals(BPMConstants.BPM_IO_UNIT_TYPE_UNITS)) {
				// Increment by 1 when incentive option unit type is "UNITS".
				lNumberOfFamilyReceivedIncentives++;
				lNumberOfParticipantReceivedIncentives++;
			}
		}

		// if current activity being processed does NOT MATCH to activity
		// already incented.
		if (!matchToActivityIncentive) {
			if (lNumberOfParticipantReceivedIncentives <= pActivityIncentiveCurrent
					.getParticipantCap()) {
				lBelowOrMatchToParticipantCap = true;
			}

			if (lNumberOfFamilyReceivedIncentives <= pActivityIncentiveCurrent
					.getFamilyCap()) {
				lBelowOrMatchToFamilyCap = true;
			}
		}

		return (lBelowOrMatchToParticipantCap && lBelowOrMatchToFamilyCap);

	}

	/*
	 * EV 84334 Search for the contribution grid that matches to the benefit
	 * contract type and relationship associated to the member.
	 */
	private ProgramContributionGrid getProgramContributionGrid(
			ProgramIncentiveOption lProgramIncentiveOption,
			String benefitContractType, Integer relationshipCode) {

		ProgramContributionGrid lProgramContributionGridResult = null;

		List<ProgramContributionGrid> lProgramContributionGrids = lProgramIncentiveOption
				.getProgramContributionGrids();

		for (ProgramContributionGrid lProgramContributionGrid : lProgramContributionGrids) {
			if (lProgramContributionGrid.getBenefitContractTypeVal().equals(
					benefitContractType)
					&& lProgramContributionGrid.getRelationshipCodeID().equals(
							relationshipCode)) {
				lProgramContributionGridResult = lProgramContributionGrid;
				break;
			}
		}

		return lProgramContributionGridResult;
	}

	/*
	 * This method determines if current contract incentive is over family cap
	 * limit. 1. Count towards the cap contractive incentive. 2. Count towards
	 * the cap pending contract incentive.
	 */

	private boolean isContractIncentiveBelowCap(
			BusinessProgramAdapter programAdapter,
			ContractProgramIncentiveTO lContractProgramIncentiveTOPending,
			ProgramIncentiveOption lProgramIncentiveOption) {
		boolean isBelowFamilyCap = false;

		//if activity taken not achieved because didn't meet all requirements by contract,
		//ignore from counting against cap.  Want to count only what was achieved which should
		//be all participants per contract.
		String contractIncentiveStatusCode = lContractProgramIncentiveTOPending.getContractIncentiveStatusCode();
		if (contractIncentiveStatusCode != null && contractIncentiveStatusCode.equals(BPMConstants.BPM_CONTRACT_INCENTIVE_NOT_ACHIEVED)) {
			isBelowFamilyCap = true;
			return isBelowFamilyCap;
		}
		
		//Paricipant Capping rule not being used if values not set.
		if (lProgramIncentiveOption.getParticipantCap() == null || lProgramIncentiveOption.getParticipantCap().intValue() == 0) {
			isBelowFamilyCap = true;
			return isBelowFamilyCap;
		}
		//Family Capping rule not being used if values not set.
		if (lProgramIncentiveOption.getFamilyCap() == null || lProgramIncentiveOption.getFamilyCap().intValue() == 0) {
			isBelowFamilyCap = true;
			return isBelowFamilyCap;
		}

		Integer lNumberOfFamilyContractIncentives = new Integer(0);

		String unitTypeCode = lProgramIncentiveOption.getIncentiveOption()
				.getIncentiveUnitTypeCode();

		// 1. Count current contract incentive towards the cap of contract
		// incentive.
		ArrayList<ContractProgramIncentiveTO> contractProgramIncentives = this
				.getContractProgramIncentives();


		lNumberOfFamilyContractIncentives = countNumberOfContractIncentives(
				contractProgramIncentives, unitTypeCode,
				lNumberOfFamilyContractIncentives);

		// 2. Count pending Contract incentive family cap.
		lNumberOfFamilyContractIncentives = countPendingContractIncentive(
				lContractProgramIncentiveTOPending, unitTypeCode,
				lNumberOfFamilyContractIncentives);

        if (lNumberOfFamilyContractIncentives < lProgramIncentiveOption.getFamilyCap()) {
			isBelowFamilyCap = true;
		}

		return isBelowFamilyCap;
	}

	/*
	 * This method determines if current member activity being processed exceeds
	 * capping rules. 1. Count towards the cap all incented activities of
	 * member's relationships. 2. Count towards the cap activities already
	 * incented for member. 3. Count current Member activity taken against cap.
	 * 4. Compare count totals against family and participant caps.
	 */

	private boolean isMemberIncentiveBelowTheCap(
			BusinessProgramAdapter programAdapter,
			MemberProgramIncentiveTO lMemberProgramIncentiveTONew,
			ProgramIncentiveOption lProgramIncentiveOption) 
	{		
		boolean lBelowOrMatchToParticipantCap = false;
		boolean lBelowOrMatchToFamilyCap = false;

		Integer lNumberOfFamilyReceivedIncentives = 0;
		Integer lNumberOfParticipantReceivedIncentives = 0;
		
		Map<Integer, Integer> personIncentiveCountMap = new HashMap<Integer, Integer>();
		Map<Integer, Integer> familyIncentiveCountMap = new HashMap<Integer, Integer>();
		
		//if activity taken not achieved because didn't meet all requirements by member,
		//ignore from counting against cap.  Want to count only what was achieved. 
		if (lMemberProgramIncentiveTONew.getMemberIncentiveStatusCode().equals(BPMConstants.BPM_CONTRACT_INCENTIVE_NOT_ACHIEVED)) {			
			return lBelowOrMatchToFamilyCap;
		}
		
		//Paricipant Capping rule not being used if values not set.
		if (lProgramIncentiveOption.getParticipantCap() == null || lProgramIncentiveOption.getParticipantCap().intValue() == 0) {
			lBelowOrMatchToFamilyCap = true;			
			return lBelowOrMatchToFamilyCap;
		}
		//Family Capping rule not being used if values not set.
		if (lProgramIncentiveOption.getFamilyCap() == null || lProgramIncentiveOption.getFamilyCap().intValue() == 0) {
			lBelowOrMatchToFamilyCap = true;			
			return lBelowOrMatchToFamilyCap;
		}
	
		Integer programIncentiveOptionID = lProgramIncentiveOption.getProgramIncentiveOptionID();
		String unitTypeCode = lProgramIncentiveOption.getIncentiveOption().getIncentiveUnitTypeCode();
		
		lNumberOfParticipantReceivedIncentives = 
				personIncentiveCountMap.get(programIncentiveOptionID);
		
		// There are no counts for this program-incentive-option.
	    // Create one and initialize the counts to 0.
		if(lNumberOfParticipantReceivedIncentives == null)
		{
			lNumberOfParticipantReceivedIncentives = new Integer(0);
			personIncentiveCountMap.put(programIncentiveOptionID, lNumberOfParticipantReceivedIncentives);
		}
		
		lNumberOfFamilyReceivedIncentives = 
				familyIncentiveCountMap.get(programIncentiveOptionID);
		
		if(lNumberOfFamilyReceivedIncentives == null)
		{
			lNumberOfFamilyReceivedIncentives = new Integer(0);
			personIncentiveCountMap.put(programIncentiveOptionID, lNumberOfFamilyReceivedIncentives);
		}

		// 1. Count towards the cap all incented activities of member's
		// relationships and current member being processed.
		Integer lPersonDemographicsID = lMemberProgramIncentiveTONew.getPersonDemographicsID();
		countNumberOfFamilyRelatedIncentives(unitTypeCode, programIncentiveOptionID, familyIncentiveCountMap);				
		
		// 2. Count current Member activity taken against cap.
		countMemberProgramIncentiveCurrent(lMemberProgramIncentiveTONew, unitTypeCode, programIncentiveOptionID
						, personIncentiveCountMap, familyIncentiveCountMap);
		
		// 3.Count towards the cap activities already incented for member. 
		countNumberOfMemberIncentivesCurrentAlreadyProcessed(lMemberProgramIncentiveTONew, unitTypeCode, programIncentiveOptionID
				, personIncentiveCountMap, familyIncentiveCountMap);
				
		lNumberOfFamilyReceivedIncentives = familyIncentiveCountMap.get(programIncentiveOptionID);
		lNumberOfParticipantReceivedIncentives = personIncentiveCountMap.get(programIncentiveOptionID);
				
		// 4. Compare count totals against family and participant caps.
		if (lNumberOfParticipantReceivedIncentives <= lProgramIncentiveOption
				.getParticipantCap()) {
			lBelowOrMatchToParticipantCap = true;
		}

		if (lNumberOfFamilyReceivedIncentives <= lProgramIncentiveOption
				.getFamilyCap()) {
			lBelowOrMatchToFamilyCap = true;
		}		
		
		return (lBelowOrMatchToParticipantCap && lBelowOrMatchToFamilyCap);
	}
	
	/*
	 * Method will count all incentives on the contract except for the current member being processed
	 * represented in variable personDemographicsID passed in as a parameter.  
	 */
	private void countNumberOfFamilyRelatedIncentives(String unitTypeCode, Integer programIncentiveOptionID
			, Map<Integer, Integer> familyIncentiveCountMap) 
	{
		Integer lNumberOfFamilyActivityIncentives = familyIncentiveCountMap.get(programIncentiveOptionID);
		
		if(lNumberOfFamilyActivityIncentives == null)
		{
			lNumberOfFamilyActivityIncentives = new Integer(0);
		}
				
		ArrayList<MemberProgramIncentiveTO> existingRelatedMemberProgramIncentives = this
				.getExistingRelatedMemberProgramIncentives();
		// 1. Count towards the cap all incented activities of member's
		// relationships.
		if (existingRelatedMemberProgramIncentives != null) {
			for (MemberProgramIncentiveTO lMemberProgramIncentiveTO : existingRelatedMemberProgramIncentives) {
				if (lMemberProgramIncentiveTO.getPersonDemographicsID().intValue() == this.getMember().getPersonID().intValue()) 
				{
					//ignore counting member incentives that belong to current member being processed.
					//incentives for the member will be counted in method countNumberOfFamilyNParticipantMemberProgramIncentivesCurrent
				//has to match to correct incentive option before being considered.
				} else if (lMemberProgramIncentiveTO.getProgramIncentiveOptionID().equals(programIncentiveOptionID)) {
					
					if (lMemberProgramIncentiveTO.getMemberIncentiveStatusCode().equals(BPMConstants.BPM_CONTRACT_INCENTIVE_ACHIEVED)) {
						if (unitTypeCode != null
								&& unitTypeCode
										.equals(BPMConstants.BPM_IO_UNIT_TYPE_UNITS)) {
							// Increment by 1 when incentive option unit type is
							// "UNITS".
							int numberOfActivityIncentives = lMemberProgramIncentiveTO.getIncentiveStatusActivityDetails().size();
							lNumberOfFamilyActivityIncentives = lNumberOfFamilyActivityIncentives + numberOfActivityIncentives;
						} else {
							Integer contributionAmountTotal = sumContributionAmountTotalForMemberActivityIncentives(lMemberProgramIncentiveTO
									.getIncentiveStatusActivityDetails());
							if (contributionAmountTotal != null && contributionAmountTotal > 0) {
								lNumberOfFamilyActivityIncentives += contributionAmountTotal;
							}
						}
					}
				}
			}
		}

		familyIncentiveCountMap.put(programIncentiveOptionID, lNumberOfFamilyActivityIncentives);

		return;
	}

	
	/**
	 * Method will count family and current participant being processed.
	 */
	private void countNumberOfMemberIncentivesCurrentAlreadyProcessed ( MemberProgramIncentiveTO lMemberProgramIncentiveTONew,		
			String unitTypeCode, Integer programIncentiveOptionID
			, Map<Integer, Integer> personIncentiveCountMap
			, Map<Integer, Integer> familyIncentiveCountMap) 
	{
		Integer lNumberOfFamilyActivityIncentives = familyIncentiveCountMap.get(programIncentiveOptionID);
		Integer lNumberOfParticipantActivityIncentives = personIncentiveCountMap.get(programIncentiveOptionID);	
		
		// Count towards the cap current activities taken.
		ArrayList<MemberProgramIncentiveTO> lMemberProgramIncentives = this
				.getMemberProgramIncentives();
		if (lMemberProgramIncentives != null) {
			for (MemberProgramIncentiveTO lMemberProgramIncentiveTO : lMemberProgramIncentives) 
			{				
				if (this.getMember().getPersonID().intValue() == lMemberProgramIncentiveTO.getPersonDemographicsID().intValue() && 
						lMemberProgramIncentiveTO.getProgramIncentiveOptionID().equals(programIncentiveOptionID)) 
				{
					if (lMemberProgramIncentiveTO.getMemberIncentiveStatusCode().equals(BPMConstants.BPM_CONTRACT_INCENTIVE_ACHIEVED)) {
						if (unitTypeCode != null
								&& unitTypeCode
										.equals(BPMConstants.BPM_IO_UNIT_TYPE_UNITS)) {
							// Increment by 1 when incentive option unit type is
							// "UNITS".  Note: Incentive hasn't been created yet for current member.
							
							// EV 96549 - Count the number of incentive activity details for the
							// given program-incentive-option-id.
							//int numberOfActivityIncentives = 
							//		numberOfActivityStatusDetailsForIncentiveOption(lMemberProgramIncentiveTO.getIncentiveStatusActivityDetails(), programIncentiveOptionID);	
							//EV103675 - this will fix over incenting for a contract.
							//EV103931 - overcounting fix
							int currentlyIncentedCt = lMemberProgramIncentiveTO.getIncentiveStatusActivityDetails().size();
							lNumberOfFamilyActivityIncentives = lNumberOfFamilyActivityIncentives + currentlyIncentedCt;
							lNumberOfParticipantActivityIncentives = lNumberOfParticipantActivityIncentives + currentlyIncentedCt;
							
						} else {
							Integer contributionAmountTotal = sumContributionAmountTotalForMemberActivityIncentives(lMemberProgramIncentiveTO
									.getIncentiveStatusActivityDetails());
							if (contributionAmountTotal != null && contributionAmountTotal > 0) {
								lNumberOfFamilyActivityIncentives += contributionAmountTotal;
								lNumberOfParticipantActivityIncentives += contributionAmountTotal;
							}
						}
					}										
				}
			}
		}
		
		personIncentiveCountMap.put(programIncentiveOptionID, lNumberOfParticipantActivityIncentives);
		familyIncentiveCountMap.put(programIncentiveOptionID, lNumberOfFamilyActivityIncentives);
		
		return;
	}
	
	/**
	 * Count the number of incentive activity details for the
	 * given program-incentive-option-id.
	 *  
	 * @param pIncentiveStatusActivityDetails
	 * @param pProgramIncentiveOptionID
	 * @return
	 */
	private Integer numberOfActivityStatusDetailsForIncentiveOption(ArrayList<IncentiveStatusActivityDetail> pIncentiveStatusActivityDetails, Integer pProgramIncentiveOptionID)
	{
		Integer lActivityDetailsForThisIncentive = 0;
		
		for(IncentiveStatusActivityDetail lIncentiveStatusActivityDetail : pIncentiveStatusActivityDetails)
		{
			if(lIncentiveStatusActivityDetail.getProgramIncentiveOptionID().intValue() == pProgramIncentiveOptionID.intValue())
			{
				lActivityDetailsForThisIncentive++;
			}
		}
		
		return lActivityDetailsForThisIncentive;
	}
	
	
	private void countMemberProgramIncentiveCurrent(			
			MemberProgramIncentiveTO lMemberProgramIncentiveTONew,
			String unitTypeCode, Integer programIncentiveOptionID
			, Map<Integer, Integer> personIncentiveCountMap
			, Map<Integer, Integer> familyIncentiveCountMap) 
	{		
		Integer lNumberOfFamilyActivityIncentives = familyIncentiveCountMap.get(programIncentiveOptionID);
		Integer lNumberOfParticipantActivityIncentives = personIncentiveCountMap.get(programIncentiveOptionID);
		
		if (lMemberProgramIncentiveTONew != null) {	
			if (this.getMember().getPersonID().intValue() == lMemberProgramIncentiveTONew.getPersonDemographicsID().intValue() &&
					lMemberProgramIncentiveTONew.getProgramIncentiveOptionID().equals(programIncentiveOptionID)) 
			{				
				if (lMemberProgramIncentiveTONew.getMemberIncentiveStatusCode().equals(BPMConstants.BPM_CONTRACT_INCENTIVE_ACHIEVED)) {
					if (unitTypeCode != null
							&& unitTypeCode
									.equals(BPMConstants.BPM_IO_UNIT_TYPE_UNITS)) {
						// Increment by 1 when incentive option unit type is
						// "UNITS".
						lNumberOfFamilyActivityIncentives = lNumberOfFamilyActivityIncentives + 1;
						lNumberOfParticipantActivityIncentives = lNumberOfParticipantActivityIncentives + 1;
						
					} else {
						Integer contributionAmountTotal = sumContributionAmountTotalForMemberActivityIncentives(lMemberProgramIncentiveTONew
								.getIncentiveStatusActivityDetails());
						if (contributionAmountTotal != null && contributionAmountTotal > 0) {
							lNumberOfFamilyActivityIncentives += contributionAmountTotal;
							lNumberOfParticipantActivityIncentives += contributionAmountTotal;
						}
					}
				}								
			}
			
		}

		personIncentiveCountMap.put(programIncentiveOptionID, lNumberOfParticipantActivityIncentives);
		familyIncentiveCountMap.put(programIncentiveOptionID, lNumberOfFamilyActivityIncentives);		

		return;
	}
	
	private Integer countNumberOfContractIncentives(
			ArrayList<ContractProgramIncentiveTO> contractProgramIncentives,
			String unitTypeCode, Integer lNumberOfFamilyContractIncentives) {

		// Count towards the cap all incented activities of member's
		// relationships.
		if (contractProgramIncentives != null) { 
			for (ContractProgramIncentiveTO contractProgramIncentive : contractProgramIncentives) {
				Collection<IncentiveStatusActivityDetail> lIncentiveStatusActivityDetails = contractProgramIncentive
						.getIncentiveStatusActivityDetails();
				for (IncentiveStatusActivityDetail lIncentiveStatusActivityDetail : lIncentiveStatusActivityDetails) {
					Integer contributionAmount = retrieveContributionAmountForContract(lIncentiveStatusActivityDetail);
					if (unitTypeCode != null
							&& unitTypeCode
									.equals(BPMConstants.BPM_IO_UNIT_TYPE_UNITS)) {
						// Increment by 1 when incentive option unit type is
						// "UNITS".
						lNumberOfFamilyContractIncentives++;
					} else if (contributionAmount != null && contributionAmount > 0) {
						lNumberOfFamilyContractIncentives += contributionAmount;
					}
				}
			}
		}

		return lNumberOfFamilyContractIncentives;
	}

	private Integer countPendingContractIncentive(
			ContractProgramIncentiveTO lContractProgramIncentiveTO,
			String unitTypeCode, Integer lNumberOfFamilyContractIncentives) {

		// 1. Count towards the cap all incented activities of member's
		// relationships.
		Collection<IncentiveStatusActivityDetail> lIncentiveStatusActivityDetails = lContractProgramIncentiveTO
				.getIncentiveStatusActivityDetails();
		if (lIncentiveStatusActivityDetails != null) {
			for (IncentiveStatusActivityDetail lIncentiveStatusActivityDetail : lIncentiveStatusActivityDetails) {
				Integer contributionAmount = null;
				Collection<IncentiveStatusActivityDetailContribution> lIncentiveStatusActivityDetailContributions = lIncentiveStatusActivityDetail
						.getIncentiveStatusActivityDetailContributions();
				for (IncentiveStatusActivityDetailContribution lIncentiveStatusActivityDetailContribution : lIncentiveStatusActivityDetailContributions) {
					if (lIncentiveStatusActivityDetailContribution
							.getContributionAmount() != null) {
						// just retrieving first occurence. There should only be one
						// contribution per contract incentive.
						contributionAmount = lIncentiveStatusActivityDetailContribution
								.getContributionAmount();
						break;
					}
				}
				if (unitTypeCode != null
						&& unitTypeCode
								.equals(BPMConstants.BPM_IO_UNIT_TYPE_UNITS)) {
					// Increment by 1 when incentive option unit type is
					// "UNITS".
					lNumberOfFamilyContractIncentives++;
				} else if (contributionAmount != null && contributionAmount > 0) {
							lNumberOfFamilyContractIncentives += contributionAmount;
				}
			}
		}


		return lNumberOfFamilyContractIncentives;

	}

	/*
	 * Method will return the contribution amount from the incentive status
	 * activity detail for member incentive.
	 */
	private Integer sumContributionAmountTotalForMemberActivityIncentives(
			Collection<IncentiveStatusActivityDetail> lIncentiveStatusActivityDetails) {
		int contributionAmount = 0;

		if (lIncentiveStatusActivityDetails != null) {
			for (IncentiveStatusActivityDetail lIncentiveStatusActivityDetail : lIncentiveStatusActivityDetails) {
				Collection<IncentiveStatusActivityDetailContribution> lIncentiveStatusActivityDetailContributions = lIncentiveStatusActivityDetail
						.getIncentiveStatusActivityDetailContributions();
				for (IncentiveStatusActivityDetailContribution lIncentiveStatusActivityDetailContribution : lIncentiveStatusActivityDetailContributions) {
					if (lIncentiveStatusActivityDetailContribution
							.getContributionAmount() != null) {
						contributionAmount = contributionAmount + lIncentiveStatusActivityDetailContribution
								.getContributionAmount();
					}
				}
			}
		}

		return contributionAmount;
	}

	/*
	 * Method will return the contribution amount from the incentive status
	 * activity detail contract incentive.
	 */
	private Integer retrieveContributionAmountForContract(
			IncentiveStatusActivityDetail lIncentiveStatusActivityDetailFromContract) {
		Integer contributionAmount = null;

		Collection<IncentiveStatusActivityDetailContribution> lIncentiveStatusActivityDetailContributions = lIncentiveStatusActivityDetailFromContract
				.getIncentiveStatusActivityDetailContributions();
		for (IncentiveStatusActivityDetailContribution lIncentiveStatusActivityDetailContribution : lIncentiveStatusActivityDetailContributions) {
			if (lIncentiveStatusActivityDetailContribution
					.getContributionAmount() != null) {
				contributionAmount = lIncentiveStatusActivityDetailContribution
						.getContributionAmount();
				break;
			}
		}

		return contributionAmount;
	}

	/**
	 * Add the Member Activity to the list of Person Activity Incentives.
	 *
	 */
	private void addToPersonActivityIncentives(
			PersonActivityIncentive pPersonActivityIncentive) {
		// If this person has received this incentive before, is there a Max ?
		// Is there a family cap for this Biz Program Incentive, and have the
		// people on the same
		// contract as this member, exhausted the family cap ?
		int lRelationshipCode = pPersonActivityIncentive.getRelationshipCode();

		// logger.info("--- Activity ID = " +
		// pPersonActivityIncentive.getActivityID());

		// First time this activity is coming through.
		if (lRelationshipCode == member
				.getRelationshipCode(pPersonActivityIncentive
						.getBusinessProgramID())) {
			ContractTO lMemberContract = member
					.getMemberContract(pPersonActivityIncentive
							.getBusinessProgramID());

			if (isActivityTakenAfterContractTerm(lMemberContract,
					pPersonActivityIncentive)) {
				// EV 54158 - fix prevents duplicate incented activities when a
				// site transfer is performed.
				// So don't incent an activity if taken after a contract has
				// been termed.
			} else if (isActivityBasedActivityAlreadyIncentedPerSiteTransfer(pPersonActivityIncentive)) {
				// EV 56429 - prevent activity from being incented under new
				// site if already incented under old site within
				// the same program year.
			} else {
				boolean lAlreadyInTheList = false;

				for (PersonActivityIncentive lPersonActivityIncentive : personActivityIncentives) {
					if (lPersonActivityIncentive.getActivityID().intValue() == pPersonActivityIncentive
							.getActivityID().intValue()
							&& lPersonActivityIncentive.getRegistrationID()
									.equals(pPersonActivityIncentive
											.getRegistrationID())
							&& lPersonActivityIncentive.getIncentiveOptionID()
									.intValue() == pPersonActivityIncentive
									.getIncentiveOptionID().intValue()) {
						lAlreadyInTheList = true;
						break;
					}
				}				
				
				if (!lAlreadyInTheList) {
					// This activity-based incentive has been achieved. 
					// Set the activation status to ACTIVE.
					pPersonActivityIncentive.setActivationStatusCode(BPMConstants.PROGRAM_INCENTIVE_OPTION_ACTIVATION_ACTIVE);
					// Create and populate a PersonActivityIncentive. It will
					// later be saved in the database.
					personActivityIncentives.add(pPersonActivityIncentive);
				}
			}
		}
	}

	/**
	 * This method makes calls to all the incentive rules for determing whether
	 * or not an activity gets incented.
	 * 
	 * @param pMemberActivity
	 * @param pProgramAdapter
	 * @return
	 */
	private boolean evaluateActivityIncentiveRules(
			MemberActivity pMemberActivity,
			BusinessProgramAdapter pProgramAdapter,
			java.sql.Date effectiveDate, java.sql.Date completeByDeadlineDate, String incentiveRuleTypeCode, String incentedStatusTypeCode) {

		boolean lActivityCountsForThisIncentive = false;
		
		
		// check for completed activity within incentive rule methods
		// if(isActivityCompleted(pMemberActivity.getActivity().getName(),
		// pMemberActivity.getActivityStatus().getStatusCodeValue())
		//EV90207 - as part of the contract and member based incentive rules, it was determined
		//			that the DM rules are no longer needed since they are not being managed in BPM.
		if (	//isDiseaseManagementProgramActivityCompleted(pProgramAdapter)
				
				//|| isDiseaseManagementProgramActivityStarted(pProgramAdapter)
				isActivityActiveByEnrollmentEnrollByDate(pMemberActivity, effectiveDate, completeByDeadlineDate, incentiveRuleTypeCode)
				|| isActivityCompletedByEnrollmentCompleteByDate(
						pMemberActivity, completeByDeadlineDate, incentiveRuleTypeCode)
				|| isActivityCompletedByEnrollmentCompleteByDateNoFilter(
						pMemberActivity, completeByDeadlineDate, incentiveRuleTypeCode)
				|| isActivityActiveByEnrollmentEnrollByDateNoFilter(
						pMemberActivity, completeByDeadlineDate, incentiveRuleTypeCode)
				|| isActivityCompletedWithRuleTypeCommunicated(
						pMemberActivity, incentiveRuleTypeCode)
				|| isActivityCompletedWithRuleTypeCompleteWithin(
						pMemberActivity, effectiveDate, completeByDeadlineDate, incentiveRuleTypeCode)
				|| isActivityMet(pMemberActivity, incentedStatusTypeCode)
				|| isActivityExemptOrWaived(pMemberActivity)
		// EV58500 - ||
		// isActivityCompletedOutsideQualificationPeriodUsingExtendedAuthCode(pMemberActivity,
		// pProgramAdapter)
		) {

			/*
			 * logger.info(pMemberActivity.getActivity().getSourceActivityID() +
			 * ", IInctv Op ID = " + pActivityIncentive.getIncentiveOptionID() +
			 * " 1. " +
			 * isDiseaseManagementProgramActivityCompleted(pProgramAdapter) +
			 * " 2. " +
			 * isDiseaseManagementProgramActivityStarted(pProgramAdapter) +
			 * " 3. " +
			 * isActivityActiveByEnrollmentEnrollByDate(pActivityIncentive,
			 * pMemberActivity) + " 4. " +
			 * isActivityCompletedByEnrollmentCompleteByDate(pActivityIncentive,
			 * pMemberActivity) + " 5. " +
			 * isActivityCompletedByEnrollmentCompleteByDateNoFilter
			 * (pActivityIncentive, pMemberActivity) + " 6. " +
			 * isActivityActiveByEnrollmentEnrollByDateNoFilter
			 * (pActivityIncentive, pMemberActivity) + " 7. " +
			 * isActivityCompletedWithRuleTypeCommunicated(pActivityIncentive,
			 * pMemberActivity) + " 8. " +
			 * isActivityCompletedWithRuleTypeCompleteWithin(pActivityIncentive,
			 * pMemberActivity) + " 9. " + isActivityMet(pActivityIncentive,
			 * pMemberActivity) + " 10. " +
			 * isActivityExemptOrWaived(pMemberActivity) + " 11. " +
			 * isActivityCompletedOutsideQualificationPeriodUsingExtendedAuthCode
			 * (pMemberActivity, pProgramAdapter) );
			 */

			lActivityCountsForThisIncentive = true;
		}

		return lActivityCountsForThisIncentive;

	}

	/**
	 *
	 * @param pMemberActivity
	 * @return
	 */
	private boolean isActivityMet(
			MemberActivity pMemberActivity, String incentedStatusTypeCode) {
		boolean lIsActivityMet = false;

		if (BPMConstants.BPM_INCENTED_STATUS_TYPE_ACTIVITY_MET
				.equals(incentedStatusTypeCode)) {
			if (BPMConstants.BPM_INCENTED_STATUS_TYPE_ACTIVITY_MET
					.equals(pMemberActivity.getActivityStatus()
							.getStatusCodeValue())) {
				return true;
			}
		} else if (BPMConstants.BPM_INCENTED_STATUS_TYPE_ACTIVITY_NOT_MET
				.equals(incentedStatusTypeCode)) {
			if (BPMConstants.BPM_INCENTED_STATUS_TYPE_ACTIVITY_NOT_MET
					.equals(pMemberActivity.getActivityStatus()
							.getStatusCodeValue())) {
				return true;
			}
		}

		return lIsActivityMet;
	}

	/**
	 * 
	 * @param pMemberActivity
	 * @return
	 */
	private boolean isActivityExemptOrWaived(MemberActivity pMemberActivity) {
		if (BPMConstants.ACTIVITY_STATUS_WAIVE.equals(pMemberActivity
				.getActivityStatus().getStatusCodeValue())
				|| BPMConstants.ACTIVITY_STATUS_EXEMPT.equals(pMemberActivity
						.getActivityStatus().getStatusCodeValue())) {
			return true;
		}

		return false;
	}

	/**
	 * 
	 * @param pPersonDemographicsID
	 * @param pBusinessProgramID
	 * @param pMemberActivity
	 * @param pActivityIncentive
	 * @return
	 */
	private PersonActivityIncentive createPersonActivityIncentive(
			Integer pPersonDemographicsID, Integer pBusinessProgramID,
			Integer contractNo, MemberActivity pMemberActivity,
			ActivityIncentive pActivityIncentive, Integer pIncentiveQuantity,
			Integer pRelationshipCode
			, Integer pProgramIncentiveOptionID) {
		PersonActivityIncentive lPersonActivityIncentive = new PersonActivityIncentive();

		lPersonActivityIncentive.setContractNo(contractNo);
		lPersonActivityIncentive.setPersonDemographicsID(pPersonDemographicsID);
		lPersonActivityIncentive.setActivityID(pMemberActivity.getActivity()
				.getActivityID());
		lPersonActivityIncentive.setActivityIncentiveID(pActivityIncentive
				.getActivityIncentiveID());
		lPersonActivityIncentive.setBusinessProgramID(pBusinessProgramID);
		lPersonActivityIncentive.setActivityStatusCode(pMemberActivity
				.getActivityStatus().getStatusCodeValue());
		lPersonActivityIncentive.setActivityStatusCodeID(pMemberActivity
				.getActivityStatus().getStatusCodeID());
		lPersonActivityIncentive.setIncentiveStatusDate(new java.sql.Date(
				pMemberActivity.getActivityStatus().getStatusEffectiveDate()
						.getTime().getTime()));
		lPersonActivityIncentive.setRegistrationID(pMemberActivity
				.getRegistrationID());
		lPersonActivityIncentive.setIncentiveOptionGroupID(pActivityIncentive
				.getActivityIncentiveGroupID());
		lPersonActivityIncentive
				.setIncentiveOptionRequirementID(pActivityIncentive
						.getActivityIncentiveGroupReqID());
		lPersonActivityIncentive.setIncentiveOptionID(pActivityIncentive
				.getIncentiveOptionID());
		lPersonActivityIncentive.setIncentiveQuantity(pIncentiveQuantity);
		lPersonActivityIncentive.setCollectionID(pActivityIncentive
				.getActivityCollection().getCollectionID());
		lPersonActivityIncentive.setRelationshipCode(pRelationshipCode);

		lPersonActivityIncentive.setParticipantCap(pActivityIncentive
				.getParticipantCap());
		lPersonActivityIncentive
				.setFamilyCap(pActivityIncentive.getFamilyCap());
		
		lPersonActivityIncentive.setProgramIncentiveOptionID(pProgramIncentiveOptionID);

		return lPersonActivityIncentive;
	}

	/*
	 * Activity based method for checking activity against contract terms.
	 */
	private boolean isActivityTakenAfterContractTerm( 
			ContractTO lMemberContract,
			PersonActivityIncentive pPersonActivityIncentive) {
		boolean activityTakenAfterContractTerm = false;

		Calendar lIncentiveDate = Calendar.getInstance();
		lIncentiveDate.setTime(pPersonActivityIncentive
				.getIncentiveStatusDate());

		if (lIncentiveDate.after(lMemberContract.getContract()
				.getContractEndDate())) {
			activityTakenAfterContractTerm = true;
		}

		return activityTakenAfterContractTerm;
	}
	/*
	 * Checking activity against contract terms.
	 * Determine if an activity completed under an active contract within the same group matches that of an activity already completed
	 * under a termed contract.
	 */
	private boolean isActivityTakenAfterContractTerm(Integer programID, Integer contractNo,
			Calendar lIncentiveDate, Integer activityID) {
		boolean activityTakenAfterContractTerm = false;
		Collection<MemberContractProgramTO> lMemberContractProgramTOTerms = member
				.getMemberTermedContractPrograms();
		
		for (MemberContractProgramTO lMemberContractProgramTOTerm : lMemberContractProgramTOTerms) {
			if (lMemberContractProgramTOTerm.getBusinessProgramID().equals(programID) && lMemberContractProgramTOTerm.getMemberContract().getContract().getContractNumber().equals(contractNo)) {
				Collection<MemberActivity> lMemberActivitys = lMemberContractProgramTOTerm.getMemberActivities();
				for (MemberActivity lMemberActivity : lMemberActivitys) {
					if (lMemberActivity.getActivity().getActivityID().equals(activityID)) {
						if (lIncentiveDate.after(lMemberContractProgramTOTerm.getMemberContract().getContract()
								.getContractEndDate())) {
							activityTakenAfterContractTerm = true;
						}
					}
				}
			}
		}

		return activityTakenAfterContractTerm;

	}



	/*
	 * Determine if activity based incentives exist under a business program
	 * site term. If true, then validate to see if the existing activity for the
	 * member has already been incented when member was enrolled under the
	 * previous site or the site that is now termed. Without this edit,
	 * activities can be incented twice under 2 different sites. An activity is
	 * only eligible to be incented once under the same group.
	 */
	private boolean isActivityBasedActivityAlreadyIncentedPerSiteTransfer(
			PersonActivityIncentive pPersonActivityIncentive) {

		boolean activityAlreadyIncented = false;

		// Did a possible site transfer occur?
		if (member.getActivityBasedIncentivesForTermedSite() != null
				&& member.getActivityBasedIncentivesForTermedSite().size() > 0) {
			// perform a lookup against the members current incented activities
			// taken from members business program termed site.
			// if activity is found, then don't incent the activity under the
			// members active business program to avoid duplicate incentives.

			Collection<PersonProgramActivityIncentiveStatus> lPersonProgramActivityIncentiveStatuses = member
					.getActivityBasedIncentivesForTermedSite();

			for (PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus : lPersonProgramActivityIncentiveStatuses) {
				if (member.getPersonID().equals(
						lPersonProgramActivityIncentiveStatus
								.getPersonDemographicsID())
						&& pPersonActivityIncentive.getActivityID().equals(
								lPersonProgramActivityIncentiveStatus
										.getActivityID())) {
					activityAlreadyIncented = true;
				}
			}
		}

		return activityAlreadyIncented;

	}
	
	/*
	 * EV90008 - Determine if member based activity approved for an incentive 
	 * was already incented under a termed site.
	 * Occasionally, a site transfer from a previous year will be present and this is ignored
	 * by declaring the activity incented.
	 */
	private boolean isMemberBasedActivityAlreadyIncentedPerSiteTransfer(Integer incentiveOptionID,
			Integer activityID, Calendar activityIncentiveDateCal) {

		boolean activityAlreadyIncented = false;
		
		Date activityIncentiveDate = BPMUtils.calendarToSqlDate(activityIncentiveDateCal);
		
		// Did a possible site transfer occur?
		if (member.getMemberBasedIncentivesForTermedSite() != null
				&& member.getMemberBasedIncentivesForTermedSite().size() > 0) {
		
			Collection<PersonProgramActivityIncentiveStatus> lPersonProgramActivityIncentiveStatusesTermedSites = member
					.getMemberBasedIncentivesForTermedSite();
	
			for ( PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatusTermedSite : lPersonProgramActivityIncentiveStatusesTermedSites) {
				Date programEffectiveDate = lPersonProgramActivityIncentiveStatusTermedSite.getProgramEffectiveDate();
				Date programEndDate = lPersonProgramActivityIncentiveStatusTermedSite.getProgramEndDate();
				
				if (BPMUtils.isBetweenDates(activityIncentiveDate, programEffectiveDate, programEndDate)) {
					if (member.getPersonID().equals(
							lPersonProgramActivityIncentiveStatusTermedSite
									.getPersonDemographicsID())) {
						if (incentiveOptionID.equals(lPersonProgramActivityIncentiveStatusTermedSite.getIncentiveOptionID())) {
							if (activityID.equals(
								lPersonProgramActivityIncentiveStatusTermedSite
										.getActivityID())) {
							
								if (lPersonProgramActivityIncentiveStatusTermedSite.getIncentiveStatusActivityDetails().size() > 0) {
									activityAlreadyIncented = true;
									break;
								}
							}
						} //end if	
					} //end if
				} else {
					//if currrent activity incentive date is outside of program year,
					//ignore evaluating site transfers from a previous year
					//by declaring the activity already incented.
					activityAlreadyIncented = true;
					break;
				}
			} //end for
		} //end if

		return activityAlreadyIncented;

	}
	

	/*
	 * EV90008 - Determine if contract based incentives exist under a business program
	 * site term. If true, then validate to see if the existing activity for the
	 * contract has already been incented when member was enrolled under the
	 * previous site or the site that is now termed. Without this edit,
	 * activities can be incented twice under 2 different sites. An activity is
	 * only eligible to be incented once.
	 */
	private boolean isContractBasedActivityAlreadyIncentedPerSiteTransfer(
			Integer activityID, Calendar activityIncentiveDateCal ) {

		boolean activityAlreadyIncented = false;
		
		Date activityIncentiveDate = BPMUtils.calendarToSqlDate(activityIncentiveDateCal);

		// Did a possible site transfer occur?
		if (member.getContractBasedIncentivesForTermedSite() != null
				&& member.getContractBasedIncentivesForTermedSite().size() > 0) {
			Collection<PersonProgramActivityIncentiveStatus> lPersonProgramActivityIncentiveStatusesTermedSites = member
					.getContractBasedIncentivesForTermedSite();
			for ( PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatusTermedSite : lPersonProgramActivityIncentiveStatusesTermedSites) {
				Date programEffectiveDate = lPersonProgramActivityIncentiveStatusTermedSite.getProgramEffectiveDate();
				Date programEndDate = lPersonProgramActivityIncentiveStatusTermedSite.getProgramEndDate();
				
				if (BPMUtils.isBetweenDates(activityIncentiveDate, programEffectiveDate, programEndDate)) {
					if (member.getPersonID().equals(
							lPersonProgramActivityIncentiveStatusTermedSite
									.getPersonDemographicsID())) {
						if (activityID.equals(
								lPersonProgramActivityIncentiveStatusTermedSite
										.getActivityID())) {
							if (lPersonProgramActivityIncentiveStatusTermedSite.getIncentiveStatusActivityDetails().size() > 0) {
								activityAlreadyIncented = true;
								break;
							}
						} //end if	
					} //end if
				} else {
					//if currrent activity incentive date is outside of program year,
					//ignore evaluating site transfers from a previous year
					//by declaring the activity already incented.
					activityAlreadyIncented = true;
					break;
				}
			} //end for
		} //end if

		return activityAlreadyIncented;

	}
	
	/**
	 * gets current date/time. to allow testing to specific date,
	 * currentDateTime is populated from LUV value of database. otherwise
	 * currentDateTime is null and returns today/now.
	 * 
	 * @return Calendar
	 */
	public Calendar getCurrentDateTime() {
		if (currentDateTime == null) {
			return Calendar.getInstance();
		}
		return (Calendar) currentDateTime.clone();
	}

	/**
	 * 
	 * @return
	 */
	
	protected boolean determineParticipation(
			ParticipationGroup pParticipationGroup,
			BusinessProgramAdapter pProgramAdapter) {
		ArrayList<Boolean> lRequirementSatisfied = new ArrayList<Boolean>();

		if (pParticipationGroup == null) {
			logger.error("Participation Group is null for biz program ID = "
					+ pProgramAdapter.getBusinessProgramId());
		}
		
		// 11-20-2015 This is causing a null pointer exception when the member is already termed,
		// the contract is null.
		if(member.getMemberContractProgramTO(pProgramAdapter.getBusinessProgramId()) == null ||
				member.getMemberContractProgramTO(pProgramAdapter.getBusinessProgramId()).getMemberContract() == null)
		{
			return false;
		}

		for (int req = 0; pParticipationGroup != null
				&& req < pParticipationGroup
						.getParticipationGroupRequirements().size(); req++) {
			// Initialize this requirement to false;
			lRequirementSatisfied.add(req, new Boolean(false));

			ParticipationGroupRequirement lParticipationGroupRequirement = pParticipationGroup
					.getParticipationGroupRequirements().get(req);

			// The relationship between the Details is one of OR. If one is met,
			// the requirement is satisfied.
			for (ParticipationGroupDetail lParticipationGroupDetail : lParticipationGroupRequirement
					.getParticipationGroupDetails()) {
				if (BPMConstants.BPM_PROD_TP_CD
						.equals(lParticipationGroupDetail
								.getParticipationGroupDetailCode())) {
					if (lParticipationGroupDetail.getSourceCode()
							.equalsIgnoreCase(
									member.getMemberContractProgramTO(
											pProgramAdapter
													.getBusinessProgramId())
											.getMemberContract()
											.getHealthPlanCode())
							|| lParticipationGroupDetail
									.getSourceCode()
									.equals(String
											.valueOf(member
													.getMemberContractProgramTO(
															pProgramAdapter
																	.getBusinessProgramId())
													.getMemberContract()
													.getHealthPlanCode()))) {
						if (lRequirementSatisfied.get(req) != null) {
							lRequirementSatisfied.remove(req);
						}
						lRequirementSatisfied.add(req, new Boolean(true));
					}
				} else if (BPMConstants.BPM_JW_OFFER_CD
						.equals(lParticipationGroupDetail
								.getParticipationGroupDetailCode())) {
					if (lParticipationGroupDetail.getSourceCode()
							.equalsIgnoreCase(
									member.getMemberContractProgramTO(
											pProgramAdapter
													.getBusinessProgramId())
											.getMemberContract()
											.getJWOfferCode())) {
						if (lRequirementSatisfied.get(req) != null) {
							lRequirementSatisfied.remove(req);
						}
						lRequirementSatisfied.add(req, new Boolean(true));
					}
				} else if (BPMConstants.BPM_JW_REPORTING_UNIT
						.equals(lParticipationGroupDetail
								.getParticipationGroupDetailCode())) {
					if (lParticipationGroupDetail.getSourceCode()
							.equalsIgnoreCase(
									member.getMemberContractProgramTO(
											pProgramAdapter
													.getBusinessProgramId())
											.getMemberContract()
											.getJWReportingUnit())) {
						if (lRequirementSatisfied.get(req) != null) {
							lRequirementSatisfied.remove(req);
						}
						lRequirementSatisfied.add(req, new Boolean(true));
					}
				} else if (BPMConstants.BPM_DIVISION_CD
						.equals(lParticipationGroupDetail
								.getParticipationGroupDetailCode())) {
					if (lParticipationGroupDetail.getSourceCode()
							.equalsIgnoreCase(
									member.getMemberContractProgramTO(
											pProgramAdapter
													.getBusinessProgramId())
											.getMemberContract()
											.getDivisionCode())) {
						if (lRequirementSatisfied.get(req) != null) {
							lRequirementSatisfied.remove(req);
						}
						lRequirementSatisfied.add(req, new Boolean(true));
					}
				} else if (BPMConstants.BPM_EMPLOYEE_FLG
						.equals(lParticipationGroupDetail
								.getParticipationGroupDetailCode())) {
					if (lParticipationGroupDetail.getSourceCode()
							.equalsIgnoreCase(
									member.getMemberContractProgramTO(
											pProgramAdapter
													.getBusinessProgramId())
											.getMemberContract()
											.getEmployeeFlag())) {
						if (lRequirementSatisfied.get(req) != null) {
							lRequirementSatisfied.remove(req);
						}
						lRequirementSatisfied.add(req, new Boolean(true));
					}
				} else if (BPMConstants.BPM_ELIG_HIRE_DT
						.equals(lParticipationGroupDetail
								.getParticipationGroupDetailCode())) {
					java.sql.Date lParticipationDetailDate = BPMUtils
							.formatDateMMddyyyy(lParticipationGroupDetail
									.getSourceCode());

					if (lParticipationDetailDate.equals(member
							.getMemberContractProgramTO(
									pProgramAdapter.getBusinessProgramId())
							.getMemberContract().getEligibleHireDate())) {
						if (lRequirementSatisfied.get(req) != null) {
							lRequirementSatisfied.remove(req);
						}
						lRequirementSatisfied.add(req, new Boolean(true));
					}
				} else if (BPMConstants.BPM_18_PLUS_CD.equals(pParticipationGroup.getParticipationGroupName())) {
							if (BPMConstants.BPM_DOB_CD
										.equals(lParticipationGroupDetail
												.getParticipationGroupDetailCode())) {
								if (BPMUtils.is18Plus(member.getDateOfBirth())) {
									if (lRequirementSatisfied.get(req) != null) {
										lRequirementSatisfied.remove(req);
									}
									lRequirementSatisfied.add(req, new Boolean(true));
								}
							}
				} else if (BPMConstants.BPM_RELATIONSHIP_CD
						.equals(lParticipationGroupDetail
								.getParticipationGroupDetailCode())) {
					if (lParticipationGroupDetail.getSourceCode()
							.equalsIgnoreCase(
									member.getMemberContractProgramTO(
											pProgramAdapter
													.getBusinessProgramId())
											.getMemberContract()
											.getRelationshipToPolicyHolder())
							|| lParticipationGroupDetail
									.getSourceCode()
									.equals(String
											.valueOf(member
													.getMemberContractProgramTO(
															pProgramAdapter
																	.getBusinessProgramId())
													.getMemberContract()
													.getRelationshipCode()))) {
						if (lRequirementSatisfied.get(req) != null) {
							lRequirementSatisfied.remove(req);
						}
						lRequirementSatisfied.add(req, new Boolean(true));
					}
				}

				else if (BPMConstants.BPM_HLTH_PLAN_CD
						.equals(lParticipationGroupDetail
								.getParticipationGroupDetailCode())) {
					if (lParticipationGroupDetail.getSourceCode()
							.equalsIgnoreCase(
									member.getMemberContractProgramTO(
											pProgramAdapter
													.getBusinessProgramId())
											.getMemberContract()
											.getHealthPlanCode())
							|| lParticipationGroupDetail
									.getSourceCode()
									.equals(String
											.valueOf(member
													.getMemberContractProgramTO(
															pProgramAdapter
																	.getBusinessProgramId())
													.getMemberContract()
													.getHealthPlanCode()))) {
						if (lRequirementSatisfied.get(req) != null) {
							lRequirementSatisfied.remove(req);
						}
						lRequirementSatisfied.add(req, new Boolean(true));
					}
				}

			}
		} // for req

		// The relationship of the requirements to the incentive participation
		// group is one of AND. If one requirement is not satisfied
		// the participation group is not satisfied.
		for (int req = 0; pParticipationGroup != null
				&& req < pParticipationGroup
						.getParticipationGroupRequirements().size(); req++) {
			if (!lRequirementSatisfied.get(req)) {
				logger.info("determineParticipation is returning false, contract = "
						+ member.getMemberContractProgramTO(
								pProgramAdapter.getBusinessProgramId())
								.getMemberContract().getContract()
								.getContractNumber()
						+ " , PRD_TP = "
						+ member.getMemberContractProgramTO(
								pProgramAdapter.getBusinessProgramId())
								.getMemberContract().getProductTypeCode()
						+ " , HLTH_PLN = "
						+ member.getMemberContractProgramTO(
								pProgramAdapter.getBusinessProgramId())
								.getMemberContract().getHealthPlanCode()
						+ " , Rel = "
						+ member.getMemberContractProgramTO(
								pProgramAdapter.getBusinessProgramId())
								.getMemberContract()
								.getRelationshipToPolicyHolder());
				return false;
			}
		}

		logger.info("determineParticipation is returning true, contract = "
				+ member.getMemberContractProgramTO(
						pProgramAdapter.getBusinessProgramId())
						.getMemberContract().getContract().getContractNumber()
				+ " "
				+ member.getMemberContractProgramTO(
						pProgramAdapter.getBusinessProgramId())
						.getMemberContract().getRelationshipToPolicyHolder());
		return true;
	}

	/**
	 * 
	 * @param pPersonPackages
	 * @param lProgramIncentives
	 */

	/* Purpose:
		Manages member incentives activation status by relationship and package or just package.  Refactored in support
		of story BPM-136.
	 */
	//protected void determinePersonPackage(
	protected void determineMemberAlignmentWithProgramIncentiveOptionUsingRelationshipNPackage(
			ArrayList<PersonPackage> pPersonPackages,
			ArrayList<ProgramIncentiveOption> lProgramIncentives,
			BusinessProgramAdapter pProgramAdapter) 
	{		
		boolean lPersonHasPackageForThisIncentive = false;
		boolean lPersonHasRelationshipToPHForThisIncentive = false;

		String relationshipToPolicyHolder = member.getMemberContract(
				pProgramAdapter.getBusinessProgramId())
				.getRelationshipToPolicyHolder();

		for (ProgramIncentiveOption lProgramIncentiveOption : lProgramIncentives) 
		{
			String participationGroupRequirementName = lProgramIncentiveOption.getParticipationGroup().getParticipationGroupName();
			if (isParticipationGroupRequirementNameQualifyForAlignmentEvaluation(participationGroupRequirementName)) {
				lPersonHasRelationshipToPHForThisIncentive = isMemberRelationshipToPHAlignedWithParticipantGroupRequirementName(relationshipToPolicyHolder, participationGroupRequirementName);
				if (lPersonHasRelationshipToPHForThisIncentive) {
					lPersonHasPackageForThisIncentive = isMemberPackageAlignedWithPackageRuleRequirementName(lProgramIncentiveOption, pPersonPackages);
				}
			} else {
				lPersonHasPackageForThisIncentive = isMemberPackageAlignedWithPackageRuleRequirementName(lProgramIncentiveOption, pPersonPackages);
			}
			
			if(lPersonHasPackageForThisIncentive == true)
			{	
				lProgramIncentiveOption.setActivationStatusCode(BPMConstants.PROGRAM_INCENTIVE_OPTION_ACTIVATION_ACTIVE);
			}
			else
			{
				lProgramIncentiveOption.setActivationStatusCode(BPMConstants.PROGRAM_INCENTIVE_OPTION_ACTIVATION_NOT_ACTIVE);
			}
						
			lPersonHasPackageForThisIncentive = false;
		}
		
		return;
	}


	
	
	/* 
	 * Commenting out the old determinePersonPackage (pre incentive-package-rule)
	 */
	/*
	protected void determinePersonPackage(
			ArrayList<PersonPackage> pPersonPackages,
			ArrayList<ProgramIncentiveOption> lProgramIncentives,
			BusinessProgramAdapter pProgramAdapter) {
		int lNumberOfIncentives = lProgramIncentives.size();

		boolean lPersonHasHRA = false;
		boolean lPersonHasHSA = false;

		for (PersonPackage lPersonPackage : pPersonPackages) {
			// If Package is HRA, remove the incentives that are not HRA.
			if (BPMUtils.isTypeHRA(lPersonPackage)) {
				lPersonHasHRA = true;
			}
		}

		for (PersonPackage lPersonPackage : pPersonPackages) {
			// If Package is HRA, remove the incentives that are not HRA.
			if (BPMUtils.isTypeHSA(lPersonPackage)) {
				lPersonHasHSA = true;
			}
		}

		// EV64661 - originally if else block commented out to prevent HRA HSA
		// incentives from being removed from the incentive list.
		// Needs further investigation.

		if (lPersonHasHRA == false && lPersonHasHSA == false) {
			for (int inctv = 0; inctv < lNumberOfIncentives; inctv++) {
				// No HRA HSA packages, remove all the HRA HSA incentives from
				// the incentive list.
				if (BPMConstants.BPM_INCENTIVE_TYPE_HRA
						.contains(lProgramIncentives.get(inctv)
								.getIncentiveOption()
								.getIncentiveOptionTypeCode())
						|| BPMConstants.BPM_INCENTIVE_TYPE_HSA
								.contains(lProgramIncentives.get(inctv)
										.getIncentiveOption()
										.getIncentiveOptionTypeCode())) {
					lProgramIncentives.remove(inctv);
					//in case there is a mix of HRA/HSA and non HRA/HSA incentive options
					//configured, set to -1 so the first occurrence of the array is
					//always considered.
					if (inctv > 0) {
						inctv = -1;
					}
					lNumberOfIncentives--;
				}
			}
		}

		for (PersonPackage lPersonPackage : pPersonPackages) {
			// If Package is HRA, remove the incentives that are not HRA.
			if (BPMUtils.isTypeHRA(lPersonPackage)
					&& lPersonPackage.getProgramID().intValue() == pProgramAdapter
							.getBusinessProgramId().intValue()) {
				for (int inctv = 0; inctv < lNumberOfIncentives; inctv++) {
					if (!BPMConstants.BPM_INCENTIVE_TYPE_HRA
							.contains(lProgramIncentives.get(inctv)
									.getIncentiveOption()
									.getIncentiveOptionTypeCode())) {
						lProgramIncentives.remove(inctv);
						if (inctv > 0) {
							//inctv--;
							inctv = -1;
						}
						lNumberOfIncentives--;
					}
				}
			}

			// If Package is HSA, remove the incentives that are not HSA.
			if (BPMUtils.isTypeHSA(lPersonPackage)
					&& lPersonPackage.getProgramID().intValue() == pProgramAdapter
							.getBusinessProgramId().intValue()) {
				for (int inctv = 0; inctv < lNumberOfIncentives; inctv++) {
					if (!BPMConstants.BPM_INCENTIVE_TYPE_HSA
							.contains(lProgramIncentives.get(inctv)
									.getIncentiveOption()
									.getIncentiveOptionTypeCode())) {
						lProgramIncentives.remove(inctv);
						if (inctv > 0) {
							//inctv--;
							inctv = -1;
						}
						lNumberOfIncentives--;
					}
				}
			}
		}
	}
	*/

	private boolean isParticipationGroupRequirementNameQualifyForAlignmentEvaluation(String participationGroupRequirementName) {
		boolean useForAlignmentEvaluation = false;

		if (participationGroupRequirementName == null) {
			return useForAlignmentEvaluation;
		}

		if (participationGroupRequirementName.equals(BPMConstants.PARTICIPATION_GROUP_REQ_SELF) ||
				participationGroupRequirementName.equals(BPMConstants.PARTICIPATION_GROUP_REQ_SPOUSE) ||
					participationGroupRequirementName.equals(BPMConstants.PARTICIPATION_GROUP_REQ_SPOUSE_OR_DOM_PARTNER)) {
			useForAlignmentEvaluation = true;
		}

		return useForAlignmentEvaluation;
	}

	/* if no HRA HSA packages, remove all the HRA HSA incentives from
	the incentive list.  Also ensures person package aligns with incentive package.
	*/
	private boolean isMemberPackageAlignedWithPackageRuleRequirementName(ProgramIncentiveOption lProgramIncentiveOption, ArrayList<PersonPackage> pPersonPackages) {
		boolean lPersonHasPackageForThisIncentive = false;

		for(IncentivePackageRuleRequirement lIncentivePackageRuleRequirement : lProgramIncentiveOption.getIncentivePackageRuleGroup().getIncentivePackageRuleRequirements()) {
			for (IncentivePackageRuleDetail lIncentivePackageRuleDetail : lIncentivePackageRuleRequirement.getIncentivePackageRuleDetails()) {
				if (BPMConstants.PURCH_SUB_TP_NM_COL.equalsIgnoreCase(lIncentivePackageRuleDetail.getIncentivePackageRuleCodeValue())) {
					for (PersonPackage lPersonPackage : pPersonPackages) {
						if (lPersonPackage.getPackageSubTypeName().equalsIgnoreCase(lIncentivePackageRuleDetail.getSourceCode())) {
							lPersonHasPackageForThisIncentive = true;
							break;
						}
					}
				}

				if (BPMConstants.BEN_PKG_TP_COL.equalsIgnoreCase(lIncentivePackageRuleDetail.getIncentivePackageRuleCodeValue())) {
					for (PersonPackage lPersonPackage : pPersonPackages) {
						if (lPersonPackage.getPackageType().equalsIgnoreCase(lIncentivePackageRuleDetail.getSourceCode())) {
							lPersonHasPackageForThisIncentive = true;
							break;
						}
					}
				}
			}
		}

		return lPersonHasPackageForThisIncentive;
	}


	private boolean isMemberRelationshipToPHAlignedWithParticipantGroupRequirementName(String relationshipToPolicyHolder, String participationGroupRequirementName) {
		boolean isAligned = false;

		if (relationshipToPolicyHolder == null || participationGroupRequirementName == null) {
			return isAligned;
		}
		if (isRelationshipBothPolicyHolder(relationshipToPolicyHolder, participationGroupRequirementName)) {
			isAligned = true;
		} else if (isRelationshipBothSpouse(relationshipToPolicyHolder, participationGroupRequirementName)) {
			isAligned = true;
		} else if (isRelationshipBothSpouseOrDomesticPartner(relationshipToPolicyHolder, participationGroupRequirementName)) {
			isAligned = true;
		}

		return isAligned;

	}

	private boolean isRelationshipBothPolicyHolder(String relationshipToPolicyHolder, String participationGroupRequirementName) {
		if (relationshipToPolicyHolder.equals(BPMConstants.MEMBER_REL_TYPE_SELF) &&
				participationGroupRequirementName.equals(BPMConstants.PARTICIPATION_GROUP_REQ_SELF)) {
			return true;
		}

		return false;
	}

	private boolean isRelationshipBothSpouse(String relationshipToPolicyHolder, String participationGroupRequirementName) {
		if (relationshipToPolicyHolder.equals(BPMConstants.MEMBER_REL_TYPE_SPOUSE) &&
				participationGroupRequirementName.equals(BPMConstants.PARTICIPATION_GROUP_REQ_SPOUSE)) {
			return true;
		}

		return false;
	}

	private boolean isRelationshipBothSpouseOrDomesticPartner(String relationshipToPolicyHolder, String participationGroupRequirementName) {

		if (relationshipToPolicyHolder.equals(BPMConstants.MEMBER_REL_TYPE_SPOUSE) &&
				participationGroupRequirementName.equals(BPMConstants.PARTICIPATION_GROUP_REQ_SPOUSE_OR_DOM_PARTNER)) {
			return true;
		} else if (relationshipToPolicyHolder.equals(BPMConstants.MEMBER_REL_TYPE_DOMESTIC_PARTNER) &&
				participationGroupRequirementName.equals(BPMConstants.PARTICIPATION_GROUP_REQ_SPOUSE_OR_DOM_PARTNER)) {
			return true;
		}

		return false;
	}


	/**
	 * Find out which qualification checkmark this incentive was attached to.
	 * Once found create a PersonIncentiveStatus object and populate it. The
	 * PersonIncentiveStatus is used to update the person_program_status table
	 * with the pgm_chmrk_incntv_optn_id for the person-program-relation.
	 * 
	 * @param pProgramAdapter
	 */
	private void checkIncentiveQualificationCheckmarks(
			BusinessProgramAdapter pProgramAdapter,
			Integer pMetQualificationCheckmarkID,
			Integer pProgramIncentiveOptionID) {
		// -------------------------------------------------
		// EV 58085 - Assign Checkmarks to Incentive Options.
		// -------------------------------------------------
		for (QualificationCheckmark lQualificationCheckmark : pProgramAdapter
				.getQualificationCheckmarks()) {
			// Update the program status with the one qualification checkmark
			// that qualified.
			if (BPMConstants.BPM_INCENTED_STATUS_TYPE_CONTRACT_BASED
					.equalsIgnoreCase(lQualificationCheckmark
							.getIncentedStatusTypeCode())
					|| BPMConstants.BPM_INCENTED_STATUS_TYPE_MEMBER_BASED
							.equalsIgnoreCase(lQualificationCheckmark
									.getIncentedStatusTypeCode())) {
				// If the qualification checkmark was met, it will get the user
				// the corresponding incentive.
				if (pMetQualificationCheckmarkID.intValue() == lQualificationCheckmark
						.getQualificationCheckmarkID().intValue()) {
					for (ProgramIncentiveOption lProgramIncentiveOption : pProgramAdapter
							.getProgramIncentiveOptions()) {
						// EV 83140 Find the Program Incentive Option.
						// Then for that Program Incentive Option, if this
						// person role participates in that
						// Program Incentive Option, grant the incentive.
						if (lProgramIncentiveOption
								.getProgramIncentiveOptionID().intValue() == pProgramIncentiveOptionID
								.intValue()) {
							boolean lRoleParticipatesInIncentive = determineParticipation(
									lProgramIncentiveOption
											.getParticipationGroup(),
									pProgramAdapter);

							if (lRoleParticipatesInIncentive) {
								findOrCreatePersonIncentiveStatus(
										pProgramAdapter,
										pProgramIncentiveOptionID,
										pMetQualificationCheckmarkID,
										BPMConstants.MEMBER_STATUS_QUALIFIED);
							}
						}
					}
				}
			}

		}
		// -------------------------------------------------
		// EV 58085 - Assign Checkmarks to Incentive Options.
		// -------------------------------------------------

		return;
	}

	/**
	 * 
	 * @param pProgramAdapter
	 * @param pProgramIncentiveOptionID
	 * @param pMetQualificationCheckmarkID
	 * @param pPersonStatus
	 */
	public void findOrCreatePersonIncentiveStatus(
			BusinessProgramAdapter pProgramAdapter,
			Integer pProgramIncentiveOptionID,
			Integer pMetQualificationCheckmarkID, String pPersonStatus) {
		PersonIncentiveStatus lPersonIncentiveStatus = personIncentiveStatusMap
				.get(pProgramIncentiveOptionID);

		if (lPersonIncentiveStatus == null) {
			for (QualificationCheckmark lParticipatingQualificationCheckmark : participatingQualificationCheckmarks) {
				if (lParticipatingQualificationCheckmark
						.getQualificationCheckmarkID().intValue() == pMetQualificationCheckmarkID
						.intValue()) {
					lPersonIncentiveStatus = createPersonIncentiveStatus(
							pProgramAdapter, pProgramIncentiveOptionID,
							pMetQualificationCheckmarkID, pPersonStatus
							, BPMConstants.PROGRAM_INCENTIVE_OPTION_ACTIVATION_ACTIVE);
					personIncentiveStatusMap.put(pProgramIncentiveOptionID,
							lPersonIncentiveStatus);
				}
			}
		} else {
			lPersonIncentiveStatus
					.setQualificationCheckmarkID(pMetQualificationCheckmarkID);
			lPersonIncentiveStatus.setPersonStatus(pPersonStatus);
		}

	}

	/**
	 * Create a PersonIncentiveStatus object that holds the status of the person
	 * for the given program-incentive-option.
	 * 
	 * @param pProgramAdapter
	 * @param pProgramIncentiveOptionID
	 * @param pMetQualificationCheckmarkID
	 * @param pPersonStatus
	 * @return
	 */
	public PersonIncentiveStatus createPersonIncentiveStatus(
			BusinessProgramAdapter pProgramAdapter,
			Integer pProgramIncentiveOptionID,
			Integer pMetQualificationCheckmarkID, String pPersonStatus
			, String pActivationStatus) 
	{
		PersonIncentiveStatus lPersonIncentiveStatus = new PersonIncentiveStatus();

		lPersonIncentiveStatus.setProgramID(pProgramAdapter
				.getBusinessProgramId());
		lPersonIncentiveStatus.setPersonStatus(pPersonStatus);
		lPersonIncentiveStatus.setPersonDemographicsID(member.getPersonID());
		lPersonIncentiveStatus.setRelationshipCode(member
				.getRelationshipCode(pProgramAdapter.getBusinessProgramId()));
		lPersonIncentiveStatus
				.setProgramIncentiveOptionID(pProgramIncentiveOptionID);
		lPersonIncentiveStatus
				.setQualificationCheckmarkID(pMetQualificationCheckmarkID);
		lPersonIncentiveStatus.setActivationStatus(pActivationStatus);

		return lPersonIncentiveStatus;
	}

	/**
	 * Create a ContractIncentiveStatus object that holds the status of the
	 * contract for the given program-incentive-option.
	 * 
	 * @param pProgramAdapter
	 * @param pProgramIncentiveOptionID
	 * @param pMetQualificationCheckmarkID
	 * @return
	 */
	public ContractIncentiveStatus createContractIncentiveStatus(
			BusinessProgramAdapter pProgramAdapter,
			Integer pProgramIncentiveOptionID,
			Integer pMetQualificationCheckmarkID, String pNewContractStatus
			, String pActivationStatus) 
	{
		ContractIncentiveStatus lContractIncentiveStatus = new ContractIncentiveStatus();

		lContractIncentiveStatus.setProgramID(pProgramAdapter
				.getBusinessProgramId());
		lContractIncentiveStatus.setContractNo(pProgramAdapter
				.getBusinessProgram().getContractNumber());
		lContractIncentiveStatus
				.setQualificationCheckmarkID(pMetQualificationCheckmarkID);
		lContractIncentiveStatus
				.setProgramIncentiveOptionID(pProgramIncentiveOptionID);
		lContractIncentiveStatus.setContractStatus(pNewContractStatus);				

		return lContractIncentiveStatus;
	}

	public void setCurrentDateTime(Calendar currentDateTime) {
		this.currentDateTime = currentDateTime;
	}

	public ArrayList<LookUpValueCode> getRiskGroupCodes() {
		return riskGroupCodes;
	}

	public void setRiskGroupCodes(ArrayList<LookUpValueCode> riskGroupCodes) {
		this.riskGroupCodes = riskGroupCodes;
	}

	public ArrayList<Risk> getRisks() {
		return risks;
	}

	public void setRisks(ArrayList<Risk> risks) {
		this.risks = risks;
	}

	public final ArrayList<ContractHistory> getContractHistories() {
		return contractHistories;
	}

	public final void setContractHistories(
			ArrayList<ContractHistory> contractHistories) {
		this.contractHistories = contractHistories;
	}

	public final ArrayList<PackageHistory> getPackageHistories() {
		return packageHistories;
	}

	public final void setPackageHistories(
			ArrayList<PackageHistory> packageHistories) {
		this.packageHistories = packageHistories;
	}

	public final ArrayList<SubgroupHistory> getSubgroupHistories() {
		return subgroupHistories;
	}

	public final void setSubgroupHistories(
			ArrayList<SubgroupHistory> subgroupHistories) {
		this.subgroupHistories = subgroupHistories;
	}

	public Map<Integer, ContractProgramIncentiveTO> getMemberContractIncentiveStatusMap() {
		return memberContractIncentiveStatusMap;
	}

	public void setMemberContractIncentiveStatusMap(
			Map<Integer, ContractProgramIncentiveTO> memberContractIncentiveStatusMap) {
		this.memberContractIncentiveStatusMap = memberContractIncentiveStatusMap;
	}

	public ArrayList<PersonActivityIncentive> getExistingRelatedPersonActivityIncentives() {
		return existingRelatedPersonActivityIncentives;
	}

	public void setExistingRelatedPersonActivityIncentives(
			ArrayList<PersonActivityIncentive> existingRelatedPersonActivityIncentives) {
		this.existingRelatedPersonActivityIncentives = existingRelatedPersonActivityIncentives;
	}

	public ArrayList<PersonActivityIncentive> getPersonActivityIncentives() {
		return personActivityIncentives;
	}

	public void setPersonActivityIncentives(
			ArrayList<PersonActivityIncentive> personActivityIncentives) {
		this.personActivityIncentives = personActivityIncentives;
	}

	public ArrayList<ContractProgramIncentiveTO> getContractProgramIncentives() {
		return contractProgramIncentives;
	}

	public void setContractProgramIncentives(
			ArrayList<ContractProgramIncentiveTO> contractProgramIncentives) {
		this.contractProgramIncentives = contractProgramIncentives;
	}

	public ArrayList<MemberProgramIncentiveTO> getExistingRelatedMemberProgramIncentives() {
		return existingRelatedMemberProgramIncentives;
	}

	public void setExistingRelatedMemberProgramIncentives(
			ArrayList<MemberProgramIncentiveTO> existingRelatedMemberProgramIncentives) {
		this.existingRelatedMemberProgramIncentives = existingRelatedMemberProgramIncentives;
	}

	public ArrayList<MemberProgramIncentiveTO> getMemberProgramIncentives() {
		return memberProgramIncentives;
	}

	public void setMemberProgramIncentives(
			ArrayList<MemberProgramIncentiveTO> memberProgramIncentives) {
		this.memberProgramIncentives = memberProgramIncentives;
	}

	public Map<Integer, Integer> getQualificationCheckmarkMap() {
		return qualificationCheckmarkMap;
	}

	public void setQualificationCheckmarkMap(
			Map<Integer, Integer> qualificationCheckmarkMap) {
		this.qualificationCheckmarkMap = qualificationCheckmarkMap;
	}

	public ArrayList<PersonPackage> getPersonPackages() {
		return personPackages;
	}

	public void setPersonPackages(ArrayList<PersonPackage> personPackages) {
		this.personPackages = personPackages;
	}

	public Calendar getCoverageEffectiveDate() {
		return coverageEffectiveDate;
	}

	public void setCoverageEffectiveDate(Calendar coverageEffectiveDate) {
		this.coverageEffectiveDate = coverageEffectiveDate;
	}

	public boolean isActivityCompletionPeriodEnabled() {
		return activityCompletionPeriodEnabled;
	}

	public void setActivityCompletionPeriodEnabled(
			boolean activityCompletionPeriodEnabled) {
		this.activityCompletionPeriodEnabled = activityCompletionPeriodEnabled;
	}

	public Map<Integer, PersonIncentiveStatus> getPersonIncentiveStatusMap() {
		return personIncentiveStatusMap;
	}

	public void setPersonIncentiveStatusMap(
			Map<Integer, PersonIncentiveStatus> personIncentiveStatusMap) {
		this.personIncentiveStatusMap = personIncentiveStatusMap;
	}

	public Map<Integer, ContractIncentiveStatus> getContractIncentiveStatusMap() {
		return contractIncentiveStatusMap;
	}

	public void setContractIncentiveStatusMap(
			Map<Integer, ContractIncentiveStatus> contractIncentiveStatusMap) {
		this.contractIncentiveStatusMap = contractIncentiveStatusMap;
	}

	public ArrayList<QualificationCheckmark> getParticipatingQualificationCheckmarks() {
		return participatingQualificationCheckmarks;
	}

	public void setParticipatingQualificationCheckmarks(
			ArrayList<QualificationCheckmark> participatingQualificationCheckmarks) {
		this.participatingQualificationCheckmarks = participatingQualificationCheckmarks;
	}

	public Map<Integer, MemberProgramIncentiveTO> getMemberBasedIncentiveStatusMap() {
		return memberBasedIncentiveStatusMap;
	}

	public void setMemberBasedIncentiveStatusMap(
			Map<Integer, MemberProgramIncentiveTO> memberBasedIncentiveStatusMap) {
		this.memberBasedIncentiveStatusMap = memberBasedIncentiveStatusMap;
	}

	public ArrayList<MemberActivity> getMemberActivitiesMeetingRequirements() {
		return memberActivitiesMeetingRequirements;
	}

	public void setMemberActivitiesMeetingRequirements(
			ArrayList<MemberActivity> memberActivitiesMeetingRequirements) {
		this.memberActivitiesMeetingRequirements = memberActivitiesMeetingRequirements;
	}

	public Map<Integer, ArrayList<MemberActivity>> getMemberActivitiesMeetingRequirementsMap() {
		return memberActivitiesMeetingRequirementsMap;
	}

	public void setMemberActivitiesMeetingRequirementsMap(
			Map<Integer, ArrayList<MemberActivity>> memberActivitiesMeetingRequirementsMap) {
		this.memberActivitiesMeetingRequirementsMap = memberActivitiesMeetingRequirementsMap;
	}		

				

}
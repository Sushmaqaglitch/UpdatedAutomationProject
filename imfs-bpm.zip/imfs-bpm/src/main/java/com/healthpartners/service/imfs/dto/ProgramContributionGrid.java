package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;

public class ProgramContributionGrid implements Serializable
{	
	static final long serialVersionUID = 0L;
		
	private Integer rowID;
	private Integer contributionGridID;
	private Integer programIncentiveOptionID;
	private Integer benefitContractTypeID;
	private String  benefitContractTypeVal;
	private String  benefitContractTypeDesc;
	private Integer relationshipCodeID;
	private String  relationshipCode;
	private Integer contributionAmount;
	
	
	private boolean used;
	
	public ProgramContributionGrid()
	{
		super();
	}
	
	public Integer getRowID() {
		return rowID;
	}

	public void setRowID(Integer rowID) {
		this.rowID = rowID;
	}

	public Integer getContributionGridID() {
		return contributionGridID;
	}

	public void setContributionGridID(Integer contributionGridID) {
		this.contributionGridID = contributionGridID;
	}

	public Integer getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}

	public void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}

	

	public Integer getBenefitContractTypeID() {
		return benefitContractTypeID;
	}

	public void setBenefitContractTypeID(Integer benefitContractTypeID) {
		this.benefitContractTypeID = benefitContractTypeID;
	}
	
	

	public String getBenefitContractTypeVal() {
		return benefitContractTypeVal;
	}

	public void setBenefitContractTypeVal(String benefitContractTypeVal) {
		this.benefitContractTypeVal = benefitContractTypeVal;
	}

	public String getBenefitContractTypeDesc() {
		return benefitContractTypeDesc;
	}

	public void setBenefitContractTypeDesc(String benefitContractTypeDesc) {
		this.benefitContractTypeDesc = benefitContractTypeDesc;
	}

	public Integer getRelationshipCodeID() {
		return relationshipCodeID;
	}

	public void setRelationshipCodeID(Integer relationshipCodeID) {
		this.relationshipCodeID = relationshipCodeID;
	}
	
	

	public String getRelationshipCode() {
		return relationshipCode;
	}

	public void setRelationshipCode(String relationshipCode) {
		this.relationshipCode = relationshipCode;
	}

	public Integer getContributionAmount() {
		return contributionAmount;
	}

	public void setContributionAmount(Integer contributionAmount) {
		this.contributionAmount = contributionAmount;
	}

	

	public boolean isUsed() {
		return used;
	}

	public void setUsed(boolean used) {
		this.used = used;
	}
	
	
}

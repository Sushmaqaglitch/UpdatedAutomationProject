package com.healthpartners.service.imfs.dto;

public class BatchCommandResponse 
{				
	private String resultStatus;

	public String getResultStatus() {
		return resultStatus;
	}

	public void setResultStatus(String resultStatus) {
		this.resultStatus = resultStatus;
	}

			
	

	
}

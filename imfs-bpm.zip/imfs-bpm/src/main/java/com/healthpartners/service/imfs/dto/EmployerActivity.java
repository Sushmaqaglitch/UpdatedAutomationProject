
package com.healthpartners.service.imfs.dto;

import com.healthpartners.service.imfs.common.BPMUtils;

import java.io.Serializable;
import java.util.StringTokenizer;


/**
 * Represents line item from the data text file - for Employer administered activities- example - start tribune seminar activity
 * @author tjquist
 *
 */
public class EmployerActivity implements Serializable {

	static final long serialVersionUID = 0L;
	
	private String dataLine;
	
	//to separate data elements
	private String dataDelimeter;
	
	private String firstName;
	
	private String middleInitial;
	
	private String lastName;
	
	private String dateOfBirth;
	
	private String gender;
	
	private String completedFlag;
	
	private String RegistrationID;
	
	private String activityStatus;
	
	private String sourceActivityID;
	
	//Data elements for employer activity contributions.
	private String contributionAmountStr;
	private Integer contributionAmount;
	
	private String activityDateStr;
	
	private String externalEmployerPersonId;
	
	private String activityName;
	
	//line number of the data file
	private String lineNumber;
	
	//after validating member data
	private String memberID;
	private String authCode;
	
	private String overrideReason;
	private String activityID;
	private java.sql.Date activityDate;

	
	public EmployerActivity() {
		super();
	}

	/**
	 * creates EmployerActivity from the lineItemData, delimeter and line number
	 * @param dataLine
	 * @param dataDelimeter
	 * @param lineNumber
	 */
	public EmployerActivity(String dataLine, String dataDelimeter, String lineNumber, boolean convertForEmployerActivityContribution) {
		super();
		this.dataLine = dataLine;
		this.dataDelimeter = dataDelimeter;
		this.lineNumber = lineNumber;
		
		if (convertForEmployerActivityContribution) {
			converLineItemDataToElementsForActivityContributions();
		} else {
			converLineItemDataToElements();
		}
	}

	private void converLineItemDataToElements(){
		if(dataLine != null && dataLine.length() > 0 && dataDelimeter != null){
			
			String[] dataArray=dataLine.split(dataDelimeter);

			if(dataArray[0] != null)
			{
			    firstName = dataArray[0].trim();
			    firstName = firstName.replace("'", "");
			}
			
			if(dataArray[1] != null)
			{
				middleInitial = dataArray[1].trim();
			}
						
			if(dataArray[2] != null)
			{
			    lastName = dataArray[2].trim();
			    lastName = lastName.replace("'", "");
			}
			
			if(dataArray[3] != null)
			{
			   dateOfBirth = dataArray[3].trim();
			}
			
			if(dataArray[4] != null)
			{
			   gender = dataArray[4].trim();
			}
			
			if(dataArray[5] != null)
			{
			   completedFlag = dataArray[5].trim();
			}
			
			if(dataArray.length > 6 &&  dataArray[6] != null)
			{
			   memberID = dataArray[6].trim();
			}
		}
	}
	
	private void converLineItemDataToElementsForActivityContributions(){
		if(dataLine != null && dataLine.length() > 0 && dataDelimeter != null){
			
			String[] dataArray=dataLine.split(dataDelimeter);

			if(dataArray[0] != null)
			{
			    firstName = dataArray[0].trim();
			    firstName = firstName.replace("'", "");
			}
			
			if(dataArray[1] != null)
			{
				middleInitial = dataArray[1].trim();
			}
						
			if(dataArray[2] != null)
			{
			    lastName = dataArray[2].trim();
			    lastName = lastName.replace("'", "");
			}
			
			if(dataArray[3] != null)
			{
			   dateOfBirth = dataArray[3].trim();
			}
			
			if(dataArray[4] != null)
			{
			   gender = dataArray[4].trim();
			}
			if(dataArray[5] != null)
			{
				completedFlag = dataArray[5].trim();
			}
			if(dataArray[6] != null)
			{
				memberID = dataArray[6].trim();
			}
			if(dataArray[7] != null)
			{
				externalEmployerPersonId = dataArray[7].trim();
			}
			
			if(dataArray[8] != null)
			{
			    activityName = dataArray[8].trim();
			    activityName = activityName.replace("'", "");
			}
			
			if(dataArray[9] != null)
			{
				//Posting date from file maps to activityDateStr
			    activityDateStr = dataArray[9].trim();
			    activityDateStr = activityDateStr.replace("'", "");
			    activityDate = BPMUtils.getSqlDateFromString(activityDateStr);
			}
			
			
			
			if(dataArray[10] != null)
			{
			    contributionAmountStr = dataArray[10].trim();
			    contributionAmountStr = contributionAmountStr.replace("'", "");
			    contributionAmount = Integer.valueOf(contributionAmountStr);
			}
			
			
			
			
			
			
			
			
		}
	}
	
	public String getCompletedFlag() {
		return completedFlag;
	}



	public void setCompletedFlag(String completedFlag) {
		this.completedFlag = completedFlag;
	}



	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLineNumber() {
		return lineNumber;
	}


	public void setLineNumber(String lineNumber) {
		this.lineNumber = lineNumber;
	}

	public String getMiddleInitial() {
		return middleInitial;
	}

	public void setMiddleInitial(String middleInitial) {
		this.middleInitial = middleInitial;
	}
	
	

	public String getDataDelimeter() {
		return dataDelimeter;
	}

	public void setDataDelimeter(String dataDelimeter) {
		this.dataDelimeter = dataDelimeter;
	}

	public String getDataLine() {
		return dataLine;
	}

	public void setDataLine(String dataLine) {
		this.dataLine = dataLine;
	}

	public String getMemberID() {
		return memberID;
	}

	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}

	
	public String getRegistrationID() {
		return RegistrationID;
	}

	public void setRegistrationID(String registrationID) {
		RegistrationID = registrationID;
	}

	@Override
	public String toString() {
		StringBuffer toStbf = new StringBuffer();
		toStbf.append(lineNumber);
		toStbf.append(dataDelimeter);
		toStbf.append(firstName);
		toStbf.append(dataDelimeter);
		toStbf.append(middleInitial);
		toStbf.append(dataDelimeter);
		toStbf.append(lastName);
		toStbf.append(dataDelimeter);
		toStbf.append(dateOfBirth);
		toStbf.append(dataDelimeter);
		toStbf.append(gender);
		toStbf.append(dataDelimeter);
		toStbf.append(completedFlag);		
		return toStbf.toString();
	}

	public String getActivityStatus() {
		return activityStatus;
	}

	public void setActivityStatus(String activityStatus) {
		this.activityStatus = activityStatus;
	}
	
	

	public String getSourceActivityID() {
		return sourceActivityID;
	}

	public void setSourceActivityID(String sourceActivityID) {
		this.sourceActivityID = sourceActivityID;
	}

	public final String getAuthCode() {
		return authCode;
	}

	public final void setAuthCode(String authCode) {
		this.authCode = authCode;
	}

	public String getOverrideReason() {
		return overrideReason;
	}

	public void setOverrideReason(String overrideReason) {
		this.overrideReason = overrideReason;
	}

	public String getActivityID() {
		return activityID;
	}

	public void setActivityID(String activityID) {
		this.activityID = activityID;
	}

	public java.sql.Date getActivityDate() {
		return activityDate;
	}

	public void setActivityDate(java.sql.Date activityDate) {
		this.activityDate = activityDate;
	}

	public String getContributionAmountStr() {
		return contributionAmountStr;
	}

	public void setContributionAmountStr(String contributionAmountStr) {
		this.contributionAmountStr = contributionAmountStr;
	}

	public Integer getContributionAmount() {
		return contributionAmount;
	}

	public void setContributionAmount(Integer contributionAmount) {
		this.contributionAmount = contributionAmount;
	}

	public void setActivityDateStr(String activityDateStr) {
		this.activityDateStr = activityDateStr;
	}


	public String getExternalEmployerPersonId() {
		return externalEmployerPersonId;
	}

	public void setExternalEmployerPersonId(String externalEmployerPersonId) {
		this.externalEmployerPersonId = externalEmployerPersonId;
	}

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	
	

	
	
}

package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.sql.Date;

public class PersonHold implements Serializable
{	
	static final long serialVersionUID = 0L;
	
	Integer personHoldID;
	Integer personID;
	Integer riskID;
	String riskName;
	Integer riskGroupID;
	String riskGroupValue;
	Integer riskHoldDuration;
	
	Date holdEffectiveDate;
	Date holdEndDate;
	
	public Date getHoldEffectiveDate() {
		return holdEffectiveDate;
	}
	public void setHoldEffectiveDate(Date holdEffectiveDate) {
		this.holdEffectiveDate = holdEffectiveDate;
	}
	public Date getHoldEndDate() {
		return holdEndDate;
	}
	public void setHoldEndDate(Date holdEndDate) {
		this.holdEndDate = holdEndDate;
	}
	public Integer getPersonHoldID() {
		return personHoldID;
	}
	public void setPersonHoldID(Integer personHoldID) {
		this.personHoldID = personHoldID;
	}
	public Integer getPersonID() {
		return personID;
	}
	public void setPersonID(Integer personID) {
		this.personID = personID;
	}
	public Integer getRiskID() {
		return riskID;
	}
	public void setRiskID(Integer riskID) {
		this.riskID = riskID;
	}	
	public String getRiskName() {
		return riskName;
	}
	public void setRiskName(String riskName) {
		this.riskName = riskName;
	}
	public Integer getRiskGroupID() {
		return riskGroupID;
	}
	public void setRiskGroupID(Integer riskGroupID) {
		this.riskGroupID = riskGroupID;
	}
	public String getRiskGroupValue() {
		return riskGroupValue;
	}
	public void setRiskGroupValue(String riskGroupValue) {
		this.riskGroupValue = riskGroupValue;
	}
	public Integer getRiskHoldDuration() {
		return riskHoldDuration;
	}
	public void setRiskHoldDuration(Integer riskHoldDuration) {
		this.riskHoldDuration = riskHoldDuration;
	}

	
}

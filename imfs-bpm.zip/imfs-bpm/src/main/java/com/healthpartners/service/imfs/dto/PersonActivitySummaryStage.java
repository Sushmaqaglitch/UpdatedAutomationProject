package com.healthpartners.service.imfs.dto;

import java.sql.Date;
import java.sql.Time;
/**
 * DTO for capturing person activity completers to be sent to Cache membership.  Currently, sending Tobacco Cessation Completers.
 * @author tjquist
 *
 */
public class PersonActivitySummaryStage extends BaseDTO {
	
	
	
	private Integer numberOfRecords;
	private Date runDate;
	private Time runTime;
	public Integer getNumberOfRecords() {
		return numberOfRecords;
	}
	public void setNumberOfRecords(Integer numberOfRecords) {
		this.numberOfRecords = numberOfRecords;
	}
	public Date getRunDate() {
		return runDate;
	}
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	public Time getRunTime() {
		return runTime;
	}
	public void setRunTime(Time runTime) {
		this.runTime = runTime;
	}
	
	
	
    
    
}

/**
 * 
 */
package com.healthpartners.service.imfs.iface;

import java.util.Collection;

import com.healthpartners.service.imfs.dto.GroupSiteYearStage;
import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.exception.BPMException;


/**
 * @author tjquist.
 * 
 */





public interface GroupSiteYearStageService {

	/**
	 * gets person program count.
	 * 
	 * @return count
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public int getGroupSiteYearCount()
			throws BPMException, DataAccessException;


	/**
	 * write a collection of person program records to cache projection table.
	 * 
	 * @param groupSiteYears
	 * @return number of records inserted
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public int insertGroupSiteYears(Collection<GroupSiteYearStage> groupSiteYears)
			throws BPMException, DataAccessException;

	/**
	 * delete person program records contained in collection object
	 * 
	 * @param groupSiteYears
	 * @return count of records deleted
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public int deleteGroupSiteYears(Collection<GroupSiteYearStage> groupSiteYears) 
			throws BPMException, DataAccessException;

	/**
	 * gets groupSiteYear record by key
	 *
	 */
	public GroupSiteYearStage getGroupSiteYear(int groupNumber, int siteNumber, java.sql.Date qualStartDate)
			throws BPMException, DataAccessException;
	
	/**
	 * get Collection groupSiteYears
	 * 
	 * @return Collection<GroupSiteYearStage>
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public Collection<GroupSiteYearStage> getGroupSiteYears()
	throws BPMException, DataAccessException;
	
}

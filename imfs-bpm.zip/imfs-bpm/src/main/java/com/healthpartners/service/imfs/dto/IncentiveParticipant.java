package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * 
 * @author jxbourbour
 *
 */
public class IncentiveParticipant implements Serializable
{	
	static final long serialVersionUID = 0L;
	
	private Integer activityIncentiveID;
	private Integer relationshipCode;	
	private Integer maximumQuantity;		
			       
    public IncentiveParticipant()
    {
    	super();
    }

	public Integer getActivityIncentiveID() {
		return activityIncentiveID;
	}

	public void setActivityIncentiveID(Integer activityIncentiveID) {
		this.activityIncentiveID = activityIncentiveID;
	}

	

	public Integer getRelationshipCode() {
		return relationshipCode;
	}

	public void setRelationshipCode(Integer relationshipCode) {
		this.relationshipCode = relationshipCode;
	}

	public Integer getMaximumQuantity() {
		return maximumQuantity;
	}

	public void setMaximumQuantity(Integer maximumQuantity) {
		this.maximumQuantity = maximumQuantity;
	}
}

/* $Id$ */

package com.healthpartners.service.imfs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.dto.BPMAuditRecord;
import com.healthpartners.service.imfs.exception.BPMException;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;

@Configuration
public class AuditLogDAOJdbc extends JdbcDaoSupport implements AuditLogDAO {

	/*
	 * Audit Log SQL statements
	 */
	private String insertAuditLog;
	
	private String purgeAuditLogByDate;
	
	private String selectAuditLogCount;
	

	/*
	 * SQL sequences
	 */
	@Autowired
	private DataFieldMaxValueIncrementer auditLogIdIncrementer;

	public AuditLogDAOJdbc() {
		super();
	}

	@Autowired
	DataSource bpmDataSource;


	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}

	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public Integer insertAuditLog(BPMAuditRecord bpmAuditRecord)
			throws DataAccessException {
		// Retrieve the next sequence number for the audit log entry.
		Integer auditLogId = new Integer(auditLogIdIncrementer.nextIntValue());

		// Persist the audit log entry.
		JdbcTemplate template = getJdbcTemplate();
		Date logDate = new Date();
		Object params[] = new Object[] {
				auditLogId,
				logDate, // Insert date/time stamp
				logDate, // Modify date/time stamp
				bpmAuditRecord.getApplicationId(),
				bpmAuditRecord.getApplicationEvent(),
				bpmAuditRecord.getEventResult(), bpmAuditRecord.getParam1(),
				bpmAuditRecord.getParam2(), bpmAuditRecord.getParam3(),
				bpmAuditRecord.getParam4() };
		int types[] = new int[] { Types.INTEGER, Types.TIMESTAMP,
				Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
				Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };
		template.update(insertAuditLog, params, types);

		return auditLogId;
	}
	

	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public Integer purgeAuditLogByDate(java.sql.Date purgeDate)
			throws DataAccessException {
		

		// Persist the audit log entry.
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {			
				purgeDate // comes from LUV table
				};
		int types[] = new int[] { 
				Types.TIMESTAMP};
		int deleteCount = template.update(purgeAuditLogByDate, params, types);

		return deleteCount;
	}
	
	

	@Transactional(timeout = 60, rollbackFor = { BPMException.class})
	public Integer getAuditLogCount() throws DataAccessException {
		final ArrayList<Integer> results = new ArrayList<Integer>();
		JdbcTemplate template = getJdbcTemplate();
		template.query(selectAuditLogCount,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						results.add(new Integer(rs.getInt(1)));
					}
				});

		Integer numberOfAuditLogRecords = 0;
		if (results.size() > 0) {
			numberOfAuditLogRecords = results.get(0).intValue();
		}

		return numberOfAuditLogRecords;

	}

	/**
	 * Sets the audit log incrementer. Should only be called by Spring.
	 *
	 */
	public void setAuditLogIdIncrementer(
			DataFieldMaxValueIncrementer auditLogIdIncrementer) {
		this.auditLogIdIncrementer = auditLogIdIncrementer;
	}

	/**
	 * Sets the insertAuditLog SQL statement. Should only be called by Spring.
	 *
	 */
	public void setInsertAuditLog(String sql) {
		this.insertAuditLog = sql;
	}

	public void setPurgeAuditLogByDate(String purgeAuditLogByDate) {
		this.purgeAuditLogByDate = purgeAuditLogByDate;
	}

	public void setSelectAuditLogCount(String selectAuditLogCount) {
		this.selectAuditLogCount = selectAuditLogCount;
	}
}

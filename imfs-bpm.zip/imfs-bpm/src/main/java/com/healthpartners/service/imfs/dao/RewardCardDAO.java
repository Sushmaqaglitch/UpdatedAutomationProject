package com.healthpartners.service.imfs.dao;

import java.sql.Date;
import java.util.Collection;

import com.healthpartners.service.imfs.dto.*;
import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.exception.BPMException;

public interface RewardCardDAO 
{

	public Collection<RewardCardQuote> getQuotesFromBusProgramsWithRewardCards()
			throws DataAccessException, BPMException;
	
	public RewardCardAddress getRewarCardAddress(Integer rewardTransHistID, Integer programID, Integer personDemographicsID, Integer incentiveOptionID) throws DataAccessException, BPMException;
	
	public RewardCardAddress getRewarCardAddress(Integer programID, Integer personDemographicsID, Integer incentiveOptionID) throws DataAccessException, BPMException;

	public RewardCardAddress getPersonAddressUsingMODS(Integer personDemographicsID) throws DataAccessException, BPMException;
	
	public int updateRewardFulfillRecycleStatus(RewardFulfillmentTrackingRecycle lRewardFulfillmentTrackingRecycle) throws DataAccessException, BPMException;
	
	public int updateRewardCardAddressWMissingTransHistID(RewardCardAddress lRewardCardAddress) 
			throws DataAccessException, BPMException;
	
	public int updateRewardCardAddressWithProgramID(Integer rewardCardAddressID, Integer programID) 
			throws DataAccessException, BPMException;
	
	public int insertRewardFulfillmentRecycle(RewardFulfillmentTrackingRecycle newRewardFulfillmentTrackingRecycle, String systemUser)
			throws DataAccessException, BPMException;
	
	public int insertRewardOrderDetailReport(RewardIntelispendOrdered lRewardIntelispendOrdered)
			throws DataAccessException, BPMException;
	
	public int updateRewardShipDetailReport(
			RewardIntelispendShipped lRewardIntelispendShipped)
			throws DataAccessException, BPMException;
	
	public Integer insertTransmissionAuditLog(Integer transactionID, Integer sendReceiveCodeID, Integer transmissionStatusID)
			throws DataAccessException;
	
	public Collection<RewardFulfillmentTrackingRecycle> getRewardFulfillRecycle(int rewardTransHistID)
			throws DataAccessException;
	
	public boolean doesErrorExistInRewardRecycle(Integer rewardTransHistID, String itemNo)
			throws DataAccessException;
	
	public Collection<RewardCardRecycleDetail> getRewardRecycleByProgramOnHold(Integer programID, java.sql.Date selectionDate)
			throws DataAccessException;
	
	
	public Integer findDuplicateRewardShipped(RewardIntelispendShipped lRewardIntelispendShipped) throws DataAccessException;
	
	public Integer findDuplicateRewardOrdered(RewardIntelispendOrdered lRewardIntelispendOrdered) throws DataAccessException;
	
	public Integer getProgramID(Integer rewardTransHistID) throws DataAccessException;
	
	public Collection<RewardCardFulfilled> getRewardCardsFulfilled(String groupNo, String siteNo, Date startDate)
			throws DataAccessException;
	
	public RewardCardClientData getRewardCardClientData(Integer pProgramID, Integer pIncentiveOptionID)
	throws DataAccessException;
	
}

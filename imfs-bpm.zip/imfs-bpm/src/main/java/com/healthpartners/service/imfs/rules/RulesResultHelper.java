
package com.healthpartners.service.imfs.rules;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

import com.healthpartners.service.imfs.dto.BaseDTO;


import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.dto.ActivityEvent;
import com.healthpartners.service.imfs.dto.BaseDTO;
import com.healthpartners.service.imfs.dto.ContractIncentiveStatus;
import com.healthpartners.service.imfs.dto.ContractProgramIncentiveTO;
import com.healthpartners.service.imfs.dto.MemberActivity;
import com.healthpartners.service.imfs.dto.MemberProgramIncentiveTO;
import com.healthpartners.service.imfs.dto.MemberProgramUpdateTO;
import com.healthpartners.service.imfs.dto.PersonActivityIncentive;
import com.healthpartners.service.imfs.dto.PersonIncentiveStatus;
import com.healthpartners.service.imfs.dto.ProgramIncentiveOption;
import com.healthpartners.service.imfs.dto.QualificationCheckmark;
import com.healthpartners.service.imfs.dto.QualificationOverride;
import org.apache.log4j.Logger;


/**
 * Class stores results after running rules for status calculation
 * 1. generated automatic exemptions
 * 2. generated member program statuses
 * 3. generated member contract program statuses
 *  
 * @author mxthoutam
 * 
 */
public class RulesResultHelper extends BaseDTO {

	static final long serialVersionUID = 0L;

	protected final Logger logger = Logger.getLogger(this.getClass());

	//new automatic exemptions
	private Collection<QualificationOverride> generatedExemptions;

	//update contract status for member program
	private Collection<MemberProgramUpdateTO> generatedMemberContractStatuses;
	
	private Collection<ContractProgramIncentiveTO> generatedContractIncentiveStatuses;
	
	private Collection<MemberProgramIncentiveTO> generatedMemberProgramIncentiveStatuses;

	//update member program status
	private Collection<MemberProgramUpdateTO> generatedMemberProgramStatuses;

	//delete existing automatic exemptions
	private Collection<QualificationOverride> deleteAutomaticExemptions;
	
	private ArrayList<ActivityEvent> personProgramActivityStatusCompleters = new ArrayList<ActivityEvent>();
	private ArrayList<ActivityEvent> personProgramActivityStatusNonCompleters = new ArrayList<ActivityEvent>();
	
	private Collection<PersonActivityIncentive> personActivityIncentives;

	/**
	 * default constructor
	 */
	public RulesResultHelper() {
		super();
		//initialize to empty collections
		generatedExemptions = new ArrayList<QualificationOverride>();
		generatedMemberContractStatuses = new ArrayList<MemberProgramUpdateTO>();
		generatedMemberProgramStatuses = new ArrayList<MemberProgramUpdateTO>();
		deleteAutomaticExemptions = new ArrayList<QualificationOverride>();
		generatedContractIncentiveStatuses = new ArrayList<ContractProgramIncentiveTO>();
		personActivityIncentives = new ArrayList<PersonActivityIncentive>();
		generatedMemberProgramIncentiveStatuses = new ArrayList<MemberProgramIncentiveTO>();
	}

	/**
	 * creates automatic exemption and adds to collection generatedExemptions
	 *
	 */
	public void createMemberExemption(MemberAdapter memberAdapter,
			BusinessProgramAdapter programAdapter) 
	{
		// EV 58085
		for(ProgramIncentiveOption lProgramIncentiveOption : programAdapter.getProgramIncentiveOptions())
		{	
			boolean lParticipatesInThisIncentive = 
			    memberAdapter.determineParticipation(lProgramIncentiveOption.getParticipationGroup(), programAdapter);
			
			if(lParticipatesInThisIncentive == true)
			{
				int lPersonID = memberAdapter.getId();
				int lProgramID = programAdapter.getBusinessProgramId();		
				String lStatusReasonCodeValue = memberAdapter
						.getExemptionReason(programAdapter.getBusinessProgramId());
				
				QualificationOverride qualificationOverride = new QualificationOverride(
						lPersonID, lProgramID, BPMConstants.BPM_TYPE_OVERRIDE,
						BPMConstants.OVERRIDE_CODE_EXEMPTION, lStatusReasonCodeValue);
				qualificationOverride.setContractNo( memberAdapter.getMember().getMemberContract(lProgramID).getContract().getContractNumber());		
				qualificationOverride.setInsertUserId(BPMConstants.BPM_USER_SYSTEM);
				qualificationOverride.setModifyUserId(BPMConstants.BPM_USER_SYSTEM);
				qualificationOverride.setProgramIncentiveOptionID(lProgramIncentiveOption.getProgramIncentiveOptionID());
				
				if(qualificationOverride.getApproverUserId() == null || qualificationOverride.getApproverUserId().length() < 1)
				{
				    qualificationOverride.setApproverUserId(BPMConstants.BPM_USER_SYSTEM);
				}
				generatedExemptions.add(qualificationOverride);
			}
		}
	}

	/**
	 * creates delete exemption and adds to collection deleteAutomaticExemptions
	 * @param personID
	 * @param programID
	 */
	public void deleteAutomaticMemberExemption(Integer personID,
			Integer programID, Integer contractNo) {
		QualificationOverride qualificationOverride = new QualificationOverride();
		qualificationOverride.setPersonID(personID);
		qualificationOverride.setProgramID(programID);
		qualificationOverride.setContractNo(contractNo);
		qualificationOverride.setOverrideType(BPMConstants.BPM_TYPE_OVERRIDE);
		qualificationOverride
				.setOverrideCode(BPMConstants.OVERRIDE_CODE_EXEMPTION);
		deleteAutomaticExemptions.add(qualificationOverride);
	}

	/**
	 * creates contract status and adds to collection generatedMemberContractStatuses
	 *
	 * @param programID
	 * @param contractNumber

	 * @param statusReasonCodeValue
	 * 
	 */
	public void createMemberContractStatus(Integer personID, Integer programID,
			Integer contractNumber, 
			String statusReasonCodeValue
			, Integer pProgramIncentiveOptionID
			, Map<Integer, ContractIncentiveStatus> pContractIncentiveStatusMap) 
	{
		MemberProgramUpdateTO memberContractStatus = new MemberProgramUpdateTO();
		memberContractStatus.setProgramID(programID);
		
		if (contractNumber != null) {
			memberContractStatus.setContractNumber(contractNumber);
		} else {
			if (pContractIncentiveStatusMap.containsKey(pProgramIncentiveOptionID)) {
				ContractIncentiveStatus lContractIncentiveStatus = pContractIncentiveStatusMap.get(pProgramIncentiveOptionID);
				contractNumber = lContractIncentiveStatus.getContractNo();
				memberContractStatus.setContractNumber(contractNumber);
			}
		}
		
		memberContractStatus.setPersonID(personID);		
		memberContractStatus.setStatusReasonCodeValue(statusReasonCodeValue);
		memberContractStatus.setIssueDate(Calendar.getInstance()); // today
		memberContractStatus.setInsertUserId(BPMConstants.BPM_USER_SYSTEM);
		memberContractStatus.setModifyUserId(BPMConstants.BPM_USER_SYSTEM);
		memberContractStatus.setProgramIncentiveOptionID(pProgramIncentiveOptionID);
		
		// EV 58085
		if(pContractIncentiveStatusMap != null && pContractIncentiveStatusMap.get(pProgramIncentiveOptionID) != null)
		{							
			logger.info("@@@changeContractStatus called@ for personId  = "
					+ personID + ", contract no = " + contractNumber
					+ ", biz pgrm id = " + programID
					+ ", bizProgramIncentiveOptionID = " + pProgramIncentiveOptionID
					+ ", statusCodeValue = " + pContractIncentiveStatusMap.get(pProgramIncentiveOptionID).getContractStatus());
			
			memberContractStatus.setStatusCodeValue(pContractIncentiveStatusMap.get(pProgramIncentiveOptionID).getContractStatus());			
			memberContractStatus.setQualificationCheckmarkID(pContractIncentiveStatusMap.get(pProgramIncentiveOptionID).getQualificationCheckmarkID());
		}
		// EV 58085
		
		generatedMemberContractStatuses.add(memberContractStatus);
	}
	
	/**
	 * 
	 * @param personID
	 * @param programID
	 * @param contractNumber
	 * @param incentiveStatusCodeValue
	 */
	public void createMemberContractIncentiveStatus(Integer programID, Integer incentiveOptionID, 
			Integer contractNumber, String incentiveStatusCodeValue) 
	{
		
		
	}

	/**
	 * creates member status and adds to collection generatedMemberProgramStatuses
	 * 
	 * @param personID
	 * @param programID
	 * @param statusReasonCodeValue
	 */
	public void createMemberProgramStatus(Integer personID, Integer programID,
		       String statusReasonCodeValue, Calendar coverageEffectiveDate 
			, Integer pProgramIncentiveOptionID
			, Map<Integer, PersonIncentiveStatus> pPersonIncentiveStatusMap
			, boolean pHasProgramEnded) 
	{
		MemberProgramUpdateTO memberProgramStatus = new MemberProgramUpdateTO();
		memberProgramStatus.setPersonID(personID);
		memberProgramStatus.setProgramID(programID);			
		memberProgramStatus.setStatusReasonCodeValue(statusReasonCodeValue);
		memberProgramStatus.setIssueDate(Calendar.getInstance()); // today
		memberProgramStatus.setInsertUserId(BPMConstants.BPM_USER_SYSTEM);
		memberProgramStatus.setModifyUserId(BPMConstants.BPM_USER_SYSTEM);	
		memberProgramStatus.setCoverageEffectiveDate(coverageEffectiveDate);							
		
		memberProgramStatus.setProgramIncentiveOptionID(pProgramIncentiveOptionID);
		
		// EV 58085
		if(pPersonIncentiveStatusMap != null && pPersonIncentiveStatusMap.get(pProgramIncentiveOptionID) != null)
		{			
			logger.info("@@@changeMemberStatus called@ for personId  = " + personID
					+ ", businessProgramId = " + programID
					+ ", programIncentiveOptionID = " + pProgramIncentiveOptionID
					+ ", statusCodeValue = " + pPersonIncentiveStatusMap.get(pProgramIncentiveOptionID).getPersonStatus());
			
			if(pHasProgramEnded == true && 
					(BPMConstants.MEMBER_STATUS_ELIGIBLE.equals(pPersonIncentiveStatusMap.get(pProgramIncentiveOptionID).getPersonStatus())
				  || BPMConstants.MEMBER_STATUS_ACTIVE.equals(pPersonIncentiveStatusMap.get(pProgramIncentiveOptionID).getPersonStatus())))
			{
				pPersonIncentiveStatusMap.get(pProgramIncentiveOptionID).setPersonStatus(BPMConstants.MEMBER_STATUS_DID_NOT_QUALIFY);
			} else {
				//BPM-152 - SET MEMBER STATUS TO ELIGIBLE IF NULL
				if (pPersonIncentiveStatusMap.get(pProgramIncentiveOptionID).getPersonStatus() == null) {
					pPersonIncentiveStatusMap.get(pProgramIncentiveOptionID).setPersonStatus(BPMConstants.MEMBER_STATUS_ELIGIBLE);
				}
			}
			
			memberProgramStatus.setRelationshipCodeID(pPersonIncentiveStatusMap.get(pProgramIncentiveOptionID).getRelationshipCode());
			memberProgramStatus.setStatusCodeValue(pPersonIncentiveStatusMap.get(pProgramIncentiveOptionID).getPersonStatus());
		    memberProgramStatus.setQualificationCheckmarkID(pPersonIncentiveStatusMap.get(pProgramIncentiveOptionID).getQualificationCheckmarkID());
		}
		// EV 58085
		
		generatedMemberProgramStatuses.add(memberProgramStatus);
	}
	

	/**
	 * creates member status and adds to collection generatedMemberProgramStatuses
	 * 
	 * @param memberAdapter
	 * @param programAdapter
	 */
	public void changeMemberStatus(MemberAdapter memberAdapter,
			BusinessProgramAdapter programAdapter) {
		int personId = memberAdapter.getId();
		int businessProgramId = programAdapter.getBusinessProgramId();		
		String statusReasonCodeValue = null;
		boolean lHasProgramEnded = memberAdapter.hasProgramEnded(programAdapter);
		
		// EV 58085
		for(ProgramIncentiveOption lProgramIncentiveOption : programAdapter.getProgramIncentiveOptions())
		{	
			boolean lParticipatesInThisIncentive = 
			    memberAdapter.determineParticipation(lProgramIncentiveOption.getParticipationGroup(), programAdapter);
			
			if(lParticipatesInThisIncentive == true)
			{
			    createMemberProgramStatus(personId, businessProgramId, 
					statusReasonCodeValue, memberAdapter.getCoverageEffectiveDate()
					, lProgramIncentiveOption.getProgramIncentiveOptionID()
					, memberAdapter.getPersonIncentiveStatusMap()
					, lHasProgramEnded);
			}
		}
		// EV 58085		
	}


	/**
	 * creates contract status and adds to collection generatedMemberContractStatuses
	 * 
	 * @param memberAdapter
	 * @param programAdapter
	 */
	public void changeContractStatus(MemberAdapter memberAdapter,
			BusinessProgramAdapter programAdapter) {
		Integer businessProgramId = programAdapter.getBusinessProgramId();
		Integer personID = memberAdapter.getMember().getPersonID();
		Integer contractNumber = null;
		
		if (memberAdapter.getMember().getMemberContract(
				businessProgramId) != null) {
			contractNumber = memberAdapter.getMember().getMemberContract(
					businessProgramId).getContract().getContractNumber();	
		}
		
		String statusReasonCodeValue = null;				
		
		// EV 58085
		for(ProgramIncentiveOption lProgramIncentiveOption : programAdapter.getProgramIncentiveOptions())
		{
			// EV 83578 - If not contract-based incentive, set the contract status to NONE
			if(!BPMConstants.BPM_INCENTED_STATUS_TYPE_CONTRACT_BASED.equalsIgnoreCase(
					lProgramIncentiveOption.getIncentedStatusTypeCode()))			
			{
				memberAdapter.getContractIncentiveStatusMap().get(lProgramIncentiveOption.getProgramIncentiveOptionID()).setContractStatus(BPMConstants.CONTRACT_STATUS_NONE);
			}
			
			createMemberContractStatus(personID, businessProgramId, contractNumber,
		    		  statusReasonCodeValue
					, lProgramIncentiveOption.getProgramIncentiveOptionID()
					, memberAdapter.getContractIncentiveStatusMap());
		}
		// EV 58085
		
	}
	
	/**
	 * For Smart Steps Contract Status is NOT APPLICABLE.
	 * @param memberAdapter
	 * @param programAdapter
	 */
	public void changeSmartStepsContractStatus(MemberAdapter memberAdapter,
			BusinessProgramAdapter programAdapter) {
		Integer businessProgramId = programAdapter.getBusinessProgramId();
		Integer personID = memberAdapter.getMember().getPersonID();
		Integer contractNumber = memberAdapter.getMember().getMemberContract(
				businessProgramId).getContract().getContractNumber();		
		String statusReasonCodeValue = null;
		
		for(ProgramIncentiveOption lProgramIncentiveOption : programAdapter.getProgramIncentiveOptions())
		{			
			if(!BPMConstants.BPM_INCENTED_STATUS_TYPE_CONTRACT_BASED.equalsIgnoreCase(
					lProgramIncentiveOption.getIncentedStatusTypeCode()))			
			{
				// EV 83578 - If not contract-based incentive, set the contract status to NONE
				memberAdapter.getContractIncentiveStatusMap().get(lProgramIncentiveOption.getProgramIncentiveOptionID()).setContractStatus(BPMConstants.CONTRACT_STATUS_NONE);
			}
			else
			{
				memberAdapter.getContractIncentiveStatusMap().get(lProgramIncentiveOption.getProgramIncentiveOptionID()).setContractStatus(BPMConstants.CONTRACT_STATUS_NOT_APPLICABLE);
			}
			
			createMemberContractStatus(personID, businessProgramId, contractNumber
					, statusReasonCodeValue
					, lProgramIncentiveOption.getProgramIncentiveOptionID()
					, memberAdapter.getContractIncentiveStatusMap());
		}
	}
	
	/**
	 * 
	 * @param memberAdapter
	 * @param programAdapter
	 */
	public void changeContractIncentiveStatus(MemberAdapter memberAdapter,
			BusinessProgramAdapter programAdapter) 
	{
		Map<Integer, ContractProgramIncentiveTO> memberContractIncentiveStatusMap = 
		    memberAdapter.getMemberContractIncentiveStatusMap();

		Iterator<Integer> iterator = memberContractIncentiveStatusMap.keySet().iterator();

		while(iterator. hasNext())
		{		
			generatedContractIncentiveStatuses.add(memberContractIncentiveStatusMap.get(iterator.next()));
		}				
	}		
	
	
	public void changeMemberProgramIncentiveStatus(MemberAdapter memberAdapter,
			BusinessProgramAdapter programAdapter) 
	{
		Map<Integer, MemberProgramIncentiveTO> memberBasedIncentiveStatusMap = 
		    memberAdapter.getMemberBasedIncentiveStatusMap();

		Iterator<Integer> iterator = memberBasedIncentiveStatusMap.keySet().iterator();

		while(iterator. hasNext())
		{		
			generatedMemberProgramIncentiveStatuses.add(memberBasedIncentiveStatusMap.get(iterator.next()));
		}				
	}
	
	
	/**
	 * Determine which person activities are selected for update back to the person program activity status table.
	 * EV76364 - Looking for activities that have completed within a time period and achieved or not achieved indicated
	 *           by flag. 
	 * @param memberAdapter
	 */
	public void changePersonProgramActivityStatus(MemberAdapter memberAdapter, BusinessProgramAdapter programAdapter)
	{
		ArrayList<MemberActivity> lMemberActivitiesCompleters = new ArrayList<MemberActivity>();
		ArrayList<MemberActivity> lMemberActivitiesNonCompleters = new ArrayList<MemberActivity>();
		
		Collection<MemberActivity> lMemberActivityList = memberAdapter.getMember().getMemberActivities(programAdapter.getBusinessProgramId(), programAdapter.getBusinessProgram().isEvaluateTermedContract());
		
		//identify completers.
		for (MemberActivity lMemberActivity : lMemberActivityList) {
			if (lMemberActivity != null) {
				if (lMemberActivity.getActivityCompletedWithinTimePeriod() != null && lMemberActivity.getActivityCompletedWithinTimePeriod() == true) {
				lMemberActivitiesCompleters.add(lMemberActivity);
				}
				if (lMemberActivity.getActivityCompletedWithinTimePeriod() != null && lMemberActivity.getActivityCompletedWithinTimePeriod() == false) {
					lMemberActivitiesNonCompleters.add(lMemberActivity);
				}
			}
		}
		
		if (lMemberActivitiesCompleters.size() > 0) {
			Collection<ActivityEvent> lActivityEventCompleters = createActivityEventFromMemberActivity(lMemberActivitiesCompleters);
			this.getPersonProgramActivityStatusCompleters().addAll(lActivityEventCompleters);
			this.changeMemberStatus(memberAdapter, programAdapter);
		}
		
		if (lMemberActivitiesNonCompleters.size() > 0) {
			Collection<ActivityEvent> lActivityEventNonCompleters = createActivityEventFromMemberActivity(lMemberActivitiesNonCompleters);
			this.getPersonProgramActivityStatusNonCompleters().addAll(lActivityEventNonCompleters);
			this.changeMemberStatus(memberAdapter, programAdapter);
		}
	}

	
	/**
	 * 
	 * @param memberAdapter
	 * @param programAdapter
	 */
	public void changePersonActivityIncentives(MemberAdapter memberAdapter,
			BusinessProgramAdapter programAdapter)
	{
		personActivityIncentives.addAll(memberAdapter.getPersonActivityIncentives());
	}

	/**
	 * creates automatic exemption and adds to collection generatedExemptions
	 * 
	 * @param memberAdapter
	 * @param programAdapter
	 */
	public void changeMemberExemption(MemberAdapter memberAdapter,
			BusinessProgramAdapter programAdapter) {				
				
		createMemberExemption(memberAdapter, programAdapter);
	}

	/**
	 * marking to delete existing automatic exemptions
	 * @param memberAdapter
	 * @param programAdapter
	 */
	public void markForDeleteAutomaticMemberExemptions(MemberAdapter memberAdapter,
			BusinessProgramAdapter programAdapter) {
		int personId = memberAdapter.getId();
		int businessProgramId = programAdapter.getBusinessProgramId();
		
		if(memberAdapter.getMember() != null && memberAdapter.getMember().getMemberContract(businessProgramId) != null)
		{
		    deleteAutomaticMemberExemption(personId, businessProgramId
				, memberAdapter.getMember().getMemberContract(businessProgramId).getContract().getContractNumber());
		}
	}
	
	/*
	 * Convert member activity record to activity event record that will be later used to update to
	 * the person program activity status table.
	 */
	private Collection<ActivityEvent> createActivityEventFromMemberActivity(Collection<MemberActivity> lMemberActivities) {
		ArrayList<ActivityEvent> lActivityEvents = new ArrayList<ActivityEvent>();
		
		for (MemberActivity lMemberActivity : lMemberActivities) {
			ActivityEvent lActivityEvent = new ActivityEvent();
			lActivityEvent.setMemberID(lMemberActivity.getMemberID());
			if (lMemberActivity.getActivityCompletedWithinTimePeriod() != null) {
				
				 if (lMemberActivity.getActivityCompletedWithinTimePeriod() == true) {
					lMemberActivity.getActivityStatus().setOutCome(BPMConstants.ACTIVITY_STATUS_INCENTIVE_ACHIEVED);
				} else {
					lMemberActivity.getActivityStatus().setOutCome(BPMConstants.ACTIVITY_STATUS_INCENTIVE_NOT_ACHIEVED);
				}
			}
			
			lActivityEvent.setMemberActivity(lMemberActivity);
			lActivityEvents.add(lActivityEvent);
		}
		
		return lActivityEvents;
	}
	
	/**
	 * 
	 * Loop through the contract-based and member-based incentives.
	 * Set the incentive-activation-status-code of the member udpate
	 * to the activation status of the corresponding incentive-option.
	 * 
	 */
	public void setIncentiveActivationStatusCodes()
	{
		for(MemberProgramIncentiveTO lMemberProgramIncentive : generatedMemberProgramIncentiveStatuses)
		{
			for(MemberProgramUpdateTO lMemberProgramUpdate : generatedMemberProgramStatuses)
			{
			    if(lMemberProgramIncentive.getProgramIncentiveOptionID().intValue() == lMemberProgramUpdate.getProgramIncentiveOptionID().intValue())
			    {
			    	lMemberProgramUpdate.setActivationStatusCode(lMemberProgramIncentive.getActivationStatusCode());
			    }
			}
			
			for(MemberProgramUpdateTO lMemberProgramUpdate : generatedMemberContractStatuses)
			{
			    if(lMemberProgramIncentive.getProgramIncentiveOptionID().intValue() == lMemberProgramUpdate.getProgramIncentiveOptionID().intValue())
			    {
			    	lMemberProgramUpdate.setActivationStatusCode(lMemberProgramIncentive.getActivationStatusCode());
			    }
			}
		}
		
		for(ContractProgramIncentiveTO lContractProgramIncentive : generatedContractIncentiveStatuses)
		{
			for(MemberProgramUpdateTO lMemberProgramUpdate : generatedMemberProgramStatuses)
			{
			    if(lContractProgramIncentive.getProgramIncentiveOptionID().intValue() == lMemberProgramUpdate.getProgramIncentiveOptionID().intValue())
			    {
			    	lMemberProgramUpdate.setActivationStatusCode(lContractProgramIncentive.getActivationStatusCode());
			    }
			}
		}
		
		for(ContractProgramIncentiveTO lContractProgramIncentive : generatedContractIncentiveStatuses)
		{
			for(MemberProgramUpdateTO lMemberProgramUpdate : generatedMemberContractStatuses)
			{
			    if(lContractProgramIncentive.getProgramIncentiveOptionID().intValue() == lMemberProgramUpdate.getProgramIncentiveOptionID().intValue())
			    {
			    	lMemberProgramUpdate.setActivationStatusCode(lContractProgramIncentive.getActivationStatusCode());
			    }
			}
		}
		
		for(PersonActivityIncentive lPersonActivityIncentive : getPersonActivityIncentives())
		{						
			for(MemberProgramUpdateTO lMemberProgramUpdate : generatedMemberContractStatuses)			
		    {								
				if(lPersonActivityIncentive.getProgramIncentiveOptionID().intValue() == lMemberProgramUpdate.getProgramIncentiveOptionID().intValue())
				{
		    	    lMemberProgramUpdate.setActivationStatusCode(lPersonActivityIncentive.getActivationStatusCode());
				}
		    }
		}
	}

	/**
	 * @return the generatedExemptions
	 */
	public Collection<QualificationOverride> getGeneratedExemptions() {
		return generatedExemptions;
	}

	/**
	 * @return the generatedMemberContractStatuses
	 */
	public Collection<MemberProgramUpdateTO> getGeneratedMemberContractStatuses() {
		return generatedMemberContractStatuses;
	}

	/**
	 * @return the generatedMemberProgramStatuses
	 */
	public Collection<MemberProgramUpdateTO> getGeneratedMemberProgramStatuses() {
		return generatedMemberProgramStatuses;
	}

	public Collection<QualificationOverride> getDeleteAutomaticExemptions() {
		return deleteAutomaticExemptions;
	}

	public Collection<ContractProgramIncentiveTO> getGeneratedContractIncentiveStatuses() {
		return generatedContractIncentiveStatuses;
	}

	public void setGeneratedContractIncentiveStatuses(
			Collection<ContractProgramIncentiveTO> generatedContractIncentiveStatuses) {
		this.generatedContractIncentiveStatuses = generatedContractIncentiveStatuses;
	}

	public Collection<PersonActivityIncentive> getPersonActivityIncentives() {
		return personActivityIncentives;
	}

	public void setPersonActivityIncentives(
			Collection<PersonActivityIncentive> personActivityIncentives) {
		this.personActivityIncentives = personActivityIncentives;
	}

	public Collection<MemberProgramIncentiveTO> getGeneratedMemberProgramIncentiveStatuses() {
		return generatedMemberProgramIncentiveStatuses;
	}

	public void setGeneratedMemberProgramIncentiveStatuses(
			Collection<MemberProgramIncentiveTO> generatedMemberProgramIncentiveStatuses) {
		this.generatedMemberProgramIncentiveStatuses = generatedMemberProgramIncentiveStatuses;
	}

	public ArrayList<ActivityEvent> getPersonProgramActivityStatusCompleters() {
		return personProgramActivityStatusCompleters;
	}

	public void setPersonProgramActivityStatusCompleters(
			ArrayList<ActivityEvent> personProgramActivityStatusCompleters) {
		this.personProgramActivityStatusCompleters = personProgramActivityStatusCompleters;
	}

	public ArrayList<ActivityEvent> getPersonProgramActivityStatusNonCompleters() {
		return personProgramActivityStatusNonCompleters;
	}

	public void setPersonProgramActivityStatusNonCompleters(
			ArrayList<ActivityEvent> personProgramActivityStatusNonCompleters) {
		this.personProgramActivityStatusNonCompleters = personProgramActivityStatusNonCompleters;
	}

	
	

	
}

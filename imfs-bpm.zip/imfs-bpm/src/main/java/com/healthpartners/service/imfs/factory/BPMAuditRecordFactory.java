/* $Id$ */

package com.healthpartners.service.imfs.factory;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.dto.BPMAuditRecord;
import org.springframework.stereotype.Component;

@Component
public class BPMAuditRecordFactory {

	public static BPMAuditRecord createGenericEventRecord(String app,
			String event, String result, String param1, String param2,
			String param3, String param4) {
		BPMAuditRecord auditRecord = new BPMAuditRecord();

		auditRecord.setApplicationId(app);
		auditRecord.setApplicationEvent(event);
		auditRecord.setEventResult(result);
		auditRecord.setParam1(param1);
		auditRecord.setParam2(param2);
		auditRecord.setParam3(param3);
		auditRecord.setParam4(param4);

		return auditRecord;
	}

	public static BPMAuditRecord createIsRequiredParticipantEventRecord(
			String result, String sourceSystemId, String memberId) {
		BPMAuditRecord auditRecord = new BPMAuditRecord();

		auditRecord
				.setApplicationId(BPMConstants.AUDIT_APPID_BPM_WEBSERVICE);
		auditRecord
				.setApplicationEvent(BPMConstants.AUDIT_APPEVENT_BPM_WEBSERVICE_ISREQUIREDPARTICIPANT);
		auditRecord.setEventResult(result);
		auditRecord.setParam1(sourceSystemId);
		auditRecord.setParam2(memberId);

		return auditRecord;
	}
	
	public static BPMAuditRecord createGetMemberStatusEventRecord(
			String result, String sourceSystemId, String groupId, String memberId) {
		BPMAuditRecord auditRecord = new BPMAuditRecord();

		auditRecord
				.setApplicationId(BPMConstants.AUDIT_APPID_BPM_WEBSERVICE);
		auditRecord
				.setApplicationEvent(BPMConstants.AUDIT_APPEVENT_BPM_WEBSERVICE_GETMEMBERSTATUS);
		auditRecord.setEventResult(result);
		auditRecord.setParam1(sourceSystemId);
		auditRecord.setParam2(groupId);
		auditRecord.setParam3(memberId);

		return auditRecord;
	}
	
	public static BPMAuditRecord createGetGroupProgramEventRecord(
			String result, String sourceSystemId, String groupId, String memberId) {
		BPMAuditRecord auditRecord = new BPMAuditRecord();

		auditRecord
				.setApplicationId(BPMConstants.AUDIT_APPID_BPM_WEBSERVICE);
		auditRecord
				.setApplicationEvent(BPMConstants.AUDIT_APPEVENT_BPM_WEBSERVICE_GETGROUPPROGRAM);
		auditRecord.setEventResult(result);
		auditRecord.setParam1(sourceSystemId);
		auditRecord.setParam2(groupId);
		auditRecord.setParam3(memberId);

		return auditRecord;
	}
	
	
	
}

package com.healthpartners.service.imfs.dto;

import java.util.Calendar;

/**
 * This class represents the internal BPM package Data Transfer Object.
 * It is not exposed to web services for example.
 * 
 * @author jxbourbour
 */
public class PackageHistory extends BaseDTO
{
	static final long serialVersionUID = 0L;
	
	private Integer ID;
	private Integer contractNumber;
	private java.sql.Date effectiveDate;
	private java.sql.Date endDate;
	private boolean current;
	private boolean participating;
	private Integer groupID;
	private Integer subgroupID;

	public PackageHistory()
	{
		super();
	}

	public boolean isCurrent() {
		return current;
	}

	public void setCurrent(boolean current) {
		this.current = current;
	}

	public java.sql.Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(java.sql.Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Integer getID() {
		return ID;
	}

	public void setID(Integer id) {
		ID = id;
	}

	public final boolean isParticipating() {
		return participating;
	}

	public final void setParticipating(boolean participating) {
		this.participating = participating;
	}

	public java.sql.Date getEndDate() {
		return endDate;
	}

	public void setEndDate(java.sql.Date endDate) {
		this.endDate = endDate;
	}

	public final Integer getContractNumber() {
		return contractNumber;
	}

	public final void setContractNumber(Integer contractNumber) {
		this.contractNumber = contractNumber;
	}

	public final Integer getGroupID() {
		return groupID;
	}

	public final void setGroupID(Integer groupID) {
		this.groupID = groupID;
	}

	public final Integer getSubgroupID() {
		return subgroupID;
	}

	public final void setSubgroupID(Integer subgroupID) {
		this.subgroupID = subgroupID;
	}
		
}

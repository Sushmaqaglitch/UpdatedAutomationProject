package com.healthpartners.service.imfs.dto;


public class RewardIntelispendResponse
{	
	 
	String successDesc;
	String errorItemno;
	String errorFieldColumn;
	String errorDesc;
	String errorRewardTransHistID;
	Integer recycleStatusID;
	
	public String getSuccessDesc() {
		return successDesc;
	}
	public void setSuccessDesc(String successDesc) {
		this.successDesc = successDesc;
	}
	public String getErrorItemno() {
		return errorItemno;
	}
	public void setErrorItemno(String errorItemno) {
		this.errorItemno = errorItemno;
	}
	public String getErrorFieldColumn() {
		return errorFieldColumn;
	}
	public void setErrorFieldColumn(String errorFieldColumn) {
		this.errorFieldColumn = errorFieldColumn;
	}
	public String getErrorDesc() {
		return errorDesc;
	}
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
	
	public String getErrorRewardTransHistID() {
		return errorRewardTransHistID;
	}
	public void setErrorRewardTransHistID(String errorRewardTransHistID) {
		this.errorRewardTransHistID = errorRewardTransHistID;
	}
	public Integer getRecycleStatusID() {
		return recycleStatusID;
	}
	public void setRecycleStatusID(Integer recycleStatusID) {
		this.recycleStatusID = recycleStatusID;
	}

	
    

	
   
}

package com.healthpartners.service.imfs.impl;

import java.sql.Date;
import java.sql.SQLTimeoutException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;
import java.util.function.Predicate;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.QueryTimeoutException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dao.ActivityDAO;
import com.healthpartners.service.imfs.dao.AdditionalInfoDAO;
import com.healthpartners.service.imfs.dao.BatchLogDAO;
import com.healthpartners.service.imfs.dao.BusinessProgramDAO;
import com.healthpartners.service.imfs.dao.CallCreateSmallGroupBizPgm;
import com.healthpartners.service.imfs.dao.ContributionGridDAO;
import com.healthpartners.service.imfs.dao.EmployerRecycleDAO;
import com.healthpartners.service.imfs.dao.GroupBaselineDAO;
import com.healthpartners.service.imfs.dao.IncentiveOptionDAO;
import com.healthpartners.service.imfs.dao.IncentivePackageRuleDAO;
import com.healthpartners.service.imfs.dao.ParticipationGroupDAO;
import com.healthpartners.service.imfs.dao.PersonDAO;
import com.healthpartners.service.imfs.dao.QualificationCheckmarkDAO;
import com.healthpartners.service.imfs.dto.ACTVBatchLog;
import com.healthpartners.service.imfs.dto.ActivityFulfillmentTrackingReportHist;
import com.healthpartners.service.imfs.dto.ActivityIncentive;
import com.healthpartners.service.imfs.dto.AdditionalInformation;
import com.healthpartners.service.imfs.dto.AuthCode;
import com.healthpartners.service.imfs.dto.BPMAuditRecord;
import com.healthpartners.service.imfs.dto.BPMBusinessProgram;
import com.healthpartners.service.imfs.dto.BusinessProgram;
import com.healthpartners.service.imfs.dto.BusinessProgramTO;
import com.healthpartners.service.imfs.dto.BusinessProgramType;
import com.healthpartners.service.imfs.dto.CheckmarkRequirement;
import com.healthpartners.service.imfs.dto.ContractProgramIncentiveTO;
import com.healthpartners.service.imfs.dto.EligibleActivity;
import com.healthpartners.service.imfs.dto.EligibleProgramActivity;
import com.healthpartners.service.imfs.dto.GroupBaseline;
import com.healthpartners.service.imfs.dto.GroupSiteYearStage;
import com.healthpartners.service.imfs.dto.IncentivePackageRuleGroup;
import com.healthpartners.service.imfs.dto.IncentiveParticipant;
import com.healthpartners.service.imfs.dto.IncentiveRequirement;
import com.healthpartners.service.imfs.dto.MarketRequirement;
import com.healthpartners.service.imfs.dto.MemberActivity;
import com.healthpartners.service.imfs.dto.MemberProgramIncentiveTO;
import com.healthpartners.service.imfs.dto.MemberProgramStatus;
import com.healthpartners.service.imfs.dto.MemberProgramUpdateTO;
import com.healthpartners.service.imfs.dto.ParticipationGroup;
import com.healthpartners.service.imfs.dto.PersonActivityIncentive;
import com.healthpartners.service.imfs.dto.PersonActivityStage;
import com.healthpartners.service.imfs.dto.ProgramCheckmark;
import com.healthpartners.service.imfs.dto.ProgramContributionGrid;
import com.healthpartners.service.imfs.dto.ProgramIncentiveOption;
import com.healthpartners.service.imfs.dto.QualificationCheckmark;
import com.healthpartners.service.imfs.dto.ReconLogStage;
import com.healthpartners.service.imfs.dto.RejectedPerson;
import com.healthpartners.service.imfs.dto.WebServiceRequest;
import com.healthpartners.service.imfs.exception.BPMBusinessValidationException;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.factory.BPMAuditRecordFactory;
import com.healthpartners.service.imfs.iface.AuditLogService;
import com.healthpartners.service.imfs.iface.BusinessProgramService;
import com.healthpartners.service.imfs.iface.EmailService;
import com.healthpartners.service.imfs.iface.MemberService;
import com.healthpartners.service.imfs.iface.MembershipFeedStageService;
import com.healthpartners.service.imfs.iface.QualificationTimeService;
import com.healthpartners.service.imfs.rules.StatusCalculationCommand;

@Component
@Service
public class BusinessProgramServiceImpl implements BusinessProgramService 
{
	@Autowired
	private BusinessProgramDAO businessProgramDAO;
	@Autowired
	private ActivityDAO activityDAO;
	@Autowired
	private PersonDAO personDAO;
	@Autowired
	private BatchLogDAO batchLogDAO;
	@Autowired
	private QualificationTimeService qualificationTimeService;
	@Autowired
	private IncentiveOptionDAO incentiveOptionDAO;
	@Autowired
	private AdditionalInfoDAO additionalInfoDAO;
	@Autowired
	private GroupBaselineDAO groupBaselineDAO;
	@Autowired
	private EmailService emailService;
	@Autowired
	private QualificationCheckmarkDAO qualificationCheckmarkDAO;
	@Autowired
	private ParticipationGroupDAO  participationGroupDAO;
	@Autowired
	private AuditLogService auditLogService;
	@Autowired
	private MembershipFeedStageService membershipFeedStageService;
	@Autowired
	private MemberService memberService;
	@Autowired
	private EmployerRecycleDAO employerRecycleDAO;
	@Autowired
	private ContributionGridDAO contributionGridDAO;
	@Autowired
	private IncentivePackageRuleDAO incentivePackageRuleDAO;
	
	// Stored procedure
	@Autowired
	private CallCreateSmallGroupBizPgm callCreateSmallGroupBizPgm;
	

	protected final Log logger = LogFactory.getLog(getClass());
	
	public Collection<BusinessProgram> getBusinessPrograms(String pMemberID,
			int pProgramID, String targetQualificationYear, String groupNumber) {
		return new ArrayList<BusinessProgram>();
	}

	public Collection<BusinessProgram> getBusinessPrograms(String pMemberID) {
		return new ArrayList<BusinessProgram>();
	}
	
	public Collection<BusinessProgramTO> getBusinessProgramTOs(String pMemberID) {
		return new ArrayList<BusinessProgramTO>();
	}
	
	public Collection<BusinessProgramTO> getAllBusinessPrograms(Integer pPersonID, boolean pCalledFromWebPortal)
	throws DataAccessException
	{
		return businessProgramDAO.getAllBusinessPrograms(pPersonID, pCalledFromWebPortal);
	}

	/**
     * Called by the web service, this method returns a collection of MemberProgramStatus
     * objects. Each MemberProgramStatus object in the collection represents a target benefit year.
     * It contains the Program for that year, and all the Eligible Activities for that program.
     * 
     * @param pWebServiceRequest     
     * @return Collection<MemberProgramStatus>
     */
	public Collection<MemberProgramStatus> getGroupProgram(WebServiceRequest pWebServiceRequest) 
	{
		ArrayList<MemberProgramStatus> lMemberProgramStatuses = new ArrayList<MemberProgramStatus>();
		ArrayList<BusinessProgramTO> lBusinessProgramTOs = new ArrayList<BusinessProgramTO>(); 
		
		// If group-programs are requested for ALL years this program has been around
		if(pWebServiceRequest.getTargetQualificationYear().equalsIgnoreCase(BPMConstants.ALL_BENEFIT_YEARS))
		{
			// Get all benefit years for which this program has been around.
			ArrayList lNumberOfQualificationYears = (ArrayList<Integer>)
    	        businessProgramDAO.getQualificationYears(pWebServiceRequest.getProgramCode());
			
			// For each benefit year call getBusinessProgramTOForYear
			for(int i = 0; i < lNumberOfQualificationYears.size(); i++)
	    	{	    			    		
	    		Integer lTargetQualificationYear = (Integer)lNumberOfQualificationYears.get(i);
	    		ArrayList<BusinessProgramTO> lFetchedBusinessProgramTOs = (ArrayList<BusinessProgramTO>)  
	   		     getBusinessProgramTOForYear(pWebServiceRequest.getProgramCode(), 
	   		    		lTargetQualificationYear.intValue(), 
	   				pWebServiceRequest.getGroupNumber(), 
	   				pWebServiceRequest.getSiteID());	    			    		
	   			
	   			lBusinessProgramTOs.addAll(lFetchedBusinessProgramTOs);
	    	}
		}
		else
		{
			// If group-programs are requested for a specific year
			ArrayList<BusinessProgramTO> lFetchedBusinessProgramTOs = (ArrayList<BusinessProgramTO>)  
		     getBusinessProgramTOForYear(pWebServiceRequest.getProgramCode(), 
				Integer.valueOf(pWebServiceRequest.getTargetQualificationYear()), 
				pWebServiceRequest.getGroupNumber(), 
				pWebServiceRequest.getSiteID());
			
			lBusinessProgramTOs.addAll(lFetchedBusinessProgramTOs);
		}
		
		for(int j = 0; j < lBusinessProgramTOs.size(); j++)
		{
			BusinessProgramTO lBusinessProgramTO = (BusinessProgramTO)lBusinessProgramTOs.get(j);						
			
			// See if for this Biz Program the HA period has opened up yet.
			ArrayList<Integer> lProgramIDs = (ArrayList<Integer>)
			businessProgramDAO.getHAAvailable(lBusinessProgramTO.getProgramID(),
					pWebServiceRequest.getTargetQualificationYear(), Calendar.getInstance());
			
			lBusinessProgramTO.getBusinessProgram().setProgramAvailable(false);
						
			for (int k = 0; k < lProgramIDs.size(); k++) 
			{
				Integer lProgramID = (Integer) lProgramIDs.get(k);		
				if (lProgramID != null && lProgramID.intValue() == lBusinessProgramTO.getProgramID()) 
				{
					lBusinessProgramTO.getBusinessProgram().setProgramAvailable(true);
					break;
				}				
			}			
				    
			MemberProgramStatus lMemberProgramStatus = new MemberProgramStatus();
		    lMemberProgramStatus.setBusinessProgram(lBusinessProgramTO.getBusinessProgram());				    
		    
		    lMemberProgramStatuses.add(lMemberProgramStatus);
		}
				
		return lMemberProgramStatuses;
	}
	
	/**
	 * Retrieves the Business Program for a given program id, target benefit year,
	 * group and site id.
	 * The Business Program contains a list of the Eligible Activities for that program.
	 * 
	 * @param pProgramCode
	 * @param pTargetQualificationYear
	 * @param pGroupNo
	 * @param pSiteNo 
	 * @return
	 */
	public Collection<BusinessProgramTO> getBusinessProgramTOForYear(String pProgramCode,
			int pTargetQualificationYear,
			String pGroupNo,
			String pSiteNo) 
	{		
		ArrayList<BusinessProgramTO> lBusinessProgramTOs = (ArrayList<BusinessProgramTO>)			
		     businessProgramDAO.getGroupBusinessProgramTO(pProgramCode, 
				pTargetQualificationYear, 
				pGroupNo, 
				pSiteNo);
		
		for(int i = 0; i < lBusinessProgramTOs.size(); i++)
		{
			BusinessProgramTO lBusinessProgramTO = (BusinessProgramTO)lBusinessProgramTOs.get(i);
			ArrayList<EligibleActivity> lEligibleActivities = 
				(ArrayList<EligibleActivity>)getEligibleActivities(lBusinessProgramTO.getProgramID());
		
		    EligibleActivity[] lEligibleActivityArray = new EligibleActivity[lEligibleActivities.size()];
		    lEligibleActivities.toArray(lEligibleActivityArray);	
		    lBusinessProgramTO.getBusinessProgram().setEligibleActivities(lEligibleActivityArray);
		    
		    ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = 
				(ArrayList<ProgramIncentiveOption>)getProgramIncentiveOptions(lBusinessProgramTO.getProgramID());
		
		    ProgramIncentiveOption[] lProgramIncentiveOptionArray = new ProgramIncentiveOption[lProgramIncentiveOptions.size()];
		    lProgramIncentiveOptions.toArray(lProgramIncentiveOptionArray);	
		    lBusinessProgramTO.getBusinessProgram().setProgramIncentiveOptions(lProgramIncentiveOptionArray);
		    
		    ArrayList<AdditionalInformation> lAdditionalInfos = 
				(ArrayList<AdditionalInformation>)getProgramAdditionalInfos(lBusinessProgramTO.getProgramID());
		
		    AdditionalInformation[] lProgramAdittionalInfoArray = new AdditionalInformation[lAdditionalInfos.size()];
		    lAdditionalInfos.toArray(lProgramAdittionalInfoArray);	
		    lBusinessProgramTO.getBusinessProgram().setProgramAdditionalInformation(lProgramAdittionalInfoArray);
		      
		    
		}
		
		return lBusinessProgramTOs;
	}
	
	/**
	 * This method reads data from the bpm_grp_baseline_ds table.
	 * An ETL batch program will have already populated the bpm_grp_baseline_ds table.  
	 * For every group, subgroup, renewal date, it creates a corresponding business program. 
	 * It also creates default auth/promo codes for
	 * eligible activities, default incentive options, and additional program info.	 
	 */	
	public void autoPopulateBusinessPrograms(Integer batchCount)
	{
		logger.info("******Starting autoPopulateBusinessPrograms.");
		// Read from the group baseline table.
		// The SQL will exclude business program for the group-subgroup-year that already exist.
		ArrayList<GroupBaseline> lGroupBaselineList = (ArrayList<GroupBaseline>) 
			groupBaselineDAO.selectFromGroupBaseline(batchCount);
		
		
        // Read default Incentive Options, and Additional Program Info from template business program
		// that has a grp ID 0.
		Integer lTemplateProgramID = null;	
		ArrayList<BPMBusinessProgram> lBPMBusinessProgramTemplates = (ArrayList<BPMBusinessProgram>) 
			businessProgramDAO.selectProgramTemplate(BPMConstants.BPM_PROGRAM_TYPE_CODE_SMART_STEPS);
		if(lBPMBusinessProgramTemplates.size() > 0)
		{
		    lTemplateProgramID = lBPMBusinessProgramTemplates.get(0).getProgramID();
		}
		else
		{
			// No Template has been set up, send an email alert.			
			emailService.prepareAndSendBatchStatusEmail("BPM Batch Process Status (Auto Populate BusinessPrograms) - FAILED", 
			    		"No Template has been set up for Auto Business Program Setup !");
			return;
		}
		try {
			for(int g = 0;  g < lGroupBaselineList.size(); g++)
			{					
				populateOneProgram((GroupBaseline)lGroupBaselineList.get(g), lBPMBusinessProgramTemplates.get(0));				 		
			}
		} catch (DataAccessException da) {
			// Send an email alert for batch job failure	
			StringBuffer batchMailSubject = new StringBuffer();
			batchMailSubject.append("BPM Batch Process Status(Auto Populate BusinessPrograms) - FAILED");
			StringBuffer batchMailContent = new StringBuffer();
			batchMailContent.append("\nNumber of AutoSetup records attempted to be written: "
					+ lGroupBaselineList.size() + "\n");
			batchMailContent.append("\nDataAcessException error thrown within AutoPopulateBusinessPrograms.  Here is the contents of the error: " + da);
			
			// send email batch summary
			emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
					batchMailContent.toString());
			
			da.printStackTrace();
			return;
			
		} catch (Exception e) {
			// Send an email alert for batch job failure	
			
			StringBuffer batchMailSubject = new StringBuffer();
			batchMailSubject.append("BPM Batch Process Status (Auto Populate BusinessPrograms) - FAILED");
			StringBuffer batchMailContent = new StringBuffer();
			batchMailContent.append("\nNumber of AutoSetup records attempted to be written: "
					+ lGroupBaselineList.size() + "\n");
			batchMailContent.append("\nException error thrown within AutoPopulateBusinessPrograms.  Here is the contents of the error: " + e);
			
			emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
					batchMailContent.toString());
			
			e.printStackTrace();
			return;
		}
		
		emailService.prepareAndSendBatchStatusEmail("BPM Batch Process Status (Auto Populate BusinessPrograms) - SUCCESS", 
				"AutoPopulateBusinessPrograms completed. Number of Business Programs = " + lGroupBaselineList.size());
		
		logger.info("******Done autoPopulateBusinessPrograms. Number of Business Programs=" + lGroupBaselineList.size());
	}
	
	/*
	 * Select acheived Tobacco Cessation programs for participants and send to Cache Membership.
	 */
	
	public void processMemberIncentivesForMembershipPremiumBillingCommand(StatusCalculationCommand statusCalculationCommand) {
		
		logger.info("@Start - Tobacco Cessation Feed to Cache Membership. ");
		
		String failureReason = null;
		String elapsedTime = null;
		java.util.Date startDate = new java.util.Date();
		java.util.Date endDate = null;
		
		BPMAuditRecord bpmAuditRecord = new BPMAuditRecord();
		ReconLogStage reconLogStage = new ReconLogStage();
		
		int tobaccoCount = 0;
		
		String processName = statusCalculationCommand.getProcessName();
		bpmAuditRecord.setApplicationId(processName);
		bpmAuditRecord.setApplicationEvent("processMembershipPremiumBillingCommand");
		statusCalculationCommand.setCurrentCommandText("Membership Premium Billing Feed");
		
		int recordsSentToMembershipPremiumBillingCount = 0;
		int activityTableCount = 0;
		try {
			activityTableCount =  membershipFeedStageService.getPersonActivityCount();
		} catch (Exception e) {
			failureReason = BPMUtils.getStakTraceAsString(e);
			logger.error(failureReason, e);
		}
		
		if (activityTableCount == 0) {
			try {
				
				int recsWrittenPersonActivityAchieved = 0;
				
			    Collection<PersonActivityStage> lPersonActivityStage = null; 
			    Collection<MemberActivity> lMemberActivitys  = personDAO.getPersonProgramActivityStatusAchieved(BPMConstants.ACTIVITY_STATUS_INCENTIVE_ACHIEVED);
				
				tobaccoCount = lMemberActivitys.size();
			
				
				if (lMemberActivitys.size() > 0) {
					recsWrittenPersonActivityAchieved = memberService.insertPersonActivityFulfillmentHistory(lMemberActivitys);
				}
			
			    
				Calendar pCalendar = Calendar.getInstance();
				
				java.sql.Date fileSentDate = new java.sql.Date(pCalendar.getTime().getTime());
				
				if (statusCalculationCommand.getSnapShotActivityActivityFulfillTrackDate() != null) {
					fileSentDate = BPMUtils.getDateMMDDYYYYFromString(statusCalculationCommand.getSnapShotActivityActivityFulfillTrackDate());
				} 
				
				logger.info("@@@@ - FileSentDate is " + BPMUtils.formatDateCCYYmmddFormat(fileSentDate));
				Collection<ActivityFulfillmentTrackingReportHist> activityFulfillmentTrackingRpts = memberService.getActivityFulfillmentTrackingReportHist(BPMConstants.ACTIVITY_FLFLMNT_RTNG_TP_MEMBERSHIP_PREMIUM_BILLING, fileSentDate);
				
				
				logger.info("@@@@ - Tabaacco Cessation Activities to send " + activityFulfillmentTrackingRpts.size());
				
				if ( activityFulfillmentTrackingRpts.size() > 0) {
					recordsSentToMembershipPremiumBillingCount = membershipFeedStageService.insertPersonActivitys(activityFulfillmentTrackingRpts);
				}
				
				membershipFeedStageService.insertPersonActivitySummary(recordsSentToMembershipPremiumBillingCount);
				
				
				logger.info("@@@@ - Tobacco Cessation activities achieved and sent to Cache Membership Premium Billing " + recordsSentToMembershipPremiumBillingCount);
				
				int recBatchLogWritten = insertActivityBatchLog(recordsSentToMembershipPremiumBillingCount, BPMConstants.ACTIVITY_BATCH_TYPE_TOB);
				logger.info("@@@@ - CDHP Batch Log record written count " + recBatchLogWritten);
				bpmAuditRecord.setParam4(Integer.toString(recBatchLogWritten));
					
			} catch (Exception e) {
				failureReason = BPMUtils.getStakTraceAsString(e);
				logger.error(failureReason, e);
			} finally {
				endDate = new java.util.Date();
				elapsedTime = BPMUtils
						.getTimeDifferenceAsString(startDate, endDate);
				logger.info("@@@@End - activities that sent to Cache Membership Premium Billing ="
						+ recordsSentToMembershipPremiumBillingCount + "..Total Time =" + elapsedTime);
			}
		} else {
				endDate = new java.util.Date();
				elapsedTime = BPMUtils
						.getTimeDifferenceAsString(startDate, endDate);
				failureReason = ("Person Activity Stage (BpmPersonActv Cache) TABLE NOT EMPTY! Contact Membership Premium Billing Team to investigate why.  Membership Premium Billing feed will not occur until this table get's cleared out.  Number currently in the table is "
					+ activityTableCount);
		}		
		

		
	StringBuffer batchMailSubject = new StringBuffer();
	batchMailSubject.append("BPM Membership Premium Billing Batch Process Status");
	
	StringBuffer batchMailContent = new StringBuffer();
	batchMailContent.append("<tr><td>" + "BPM Batch Name: " + statusCalculationCommand.getCurrentCommandText());

	batchMailContent.append("<tr><td>" + "Initiated User: "
			+ statusCalculationCommand.getUserID() + "</td></tr>");
	batchMailContent.append("<tr><td>" + "Time Start: "
			+ BPMUtils.getFormattedDateTime(startDate) + "</td></tr>");

	 
	batchMailContent
	.append("<tr><td>" + "Number of activities sent to Cache Membership Premium Billing is "
			+ recordsSentToMembershipPremiumBillingCount + "</td></tr>");

	
	
	if (failureReason != null) {
		
		batchMailSubject.append("- FAILED");
		batchMailContent.append("<tr><td>" + "Result: FAILED" + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Reason: ");
		batchMailContent.append(failureReason + "</td></tr>");
		bpmAuditRecord.setEventResult(BPMConstants.RESULT_FAILURE);
	} else {
		
		batchMailSubject.append("- SUCCESS");
		batchMailContent.append("<tr><td>" + "Result: SUCCESS" + "</td></tr>");
		bpmAuditRecord.setEventResult(BPMConstants.RESULT_SUCCESS);
	}
	emailService.setEmailDestination(BPMConstants.EMAIL_DESTINATION_ACTIVITY_TOB);
	emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
			batchMailContent.toString());
	
	Integer newAuditLogId = createAuditEventLogEntry(bpmAuditRecord);
	
	reconLogStage.setAuditLogId(newAuditLogId);
	reconLogStage.setAppEventResultId(bpmAuditRecord.getEventResult());
	reconLogStage.setAppEventId(bpmAuditRecord.getApplicationEvent());
	reconLogStage.setAppId(bpmAuditRecord.getApplicationId());
	reconLogStage.setParam1Id(bpmAuditRecord.getParam1());
	reconLogStage.setParam2Id(bpmAuditRecord.getParam2());
	reconLogStage.setParam3Id(bpmAuditRecord.getParam3());
	reconLogStage.setParam4Id(bpmAuditRecord.getParam4());
	

	
	writeToAuditLog(statusCalculationCommand, batchMailSubject.toString(), startDate.toString(), endDate.toString(),
			elapsedTime.toString(), Integer.toString(recordsSentToMembershipPremiumBillingCount));


	if (failureReason != null) {
		logger.error("BPM to Cache Membership Premium Billing batch process Failed: " + failureReason);
		
	}
	
	
	logger.info("@End - processMemberIncentivesForMembershipPremiumBillingCommand. ");
	}
	
	
	/**
	 * 
	 * @param batchCount
	 */
	public void autoPopulateNewSmartSteps(Integer batchCount)
	{
		logger.info("----Starting autoPopulateNewSmartSteps ");
		
		int lNumberOfGroupBaselineProcessed = 0;
		
		ArrayList<GroupBaseline> lGroupsWithOverlapRenewalDates = new ArrayList<GroupBaseline> ();
		
		// 1. First, select a list of all the small groups
		Collection<BusinessProgramType> lSmallGroupTypes = businessProgramDAO.getSmallGroupTypeIDs();

		checkForMissingTemplateData((ArrayList<BusinessProgramType>)lSmallGroupTypes);

		// 2. Then loop the list of business program types, for each one
		// get the auth and promo codes, and 
		// get the market indicator requirements.
		for(BusinessProgramType lSmallGroupType : lSmallGroupTypes)						
		{
			String lAuthCode = null;
			String lPromoCode = null;						
			
			Collection<AuthCode> lAuthPromoCodes = 
			    businessProgramDAO.getNewSmartStepsProgramAuthPromoCode(lSmallGroupType.getProgramID());
						
			
			for(AuthCode lAuthPromoCode : lAuthPromoCodes)
			{
				if(lAuthPromoCode.getAuthCodeTypeCode().contains(BPMConstants.BPM_ACTIVITY_TYPE_HA))
				{
					lAuthCode = lAuthPromoCode.getAuthCode();
				}
				else
				{
					lPromoCode = lAuthPromoCode.getAuthCode();
				}
			}
			
		    Collection<MarketRequirement> lMarketRequirements = businessProgramDAO.gMarketIndicatorRequirements(lSmallGroupType.getMarketIndicatorID());		    		    		    
		
            for(MarketRequirement lMarketRequirement : lMarketRequirements)
            {            	
		    	// 3. Then get the requirement details		    
            	lMarketRequirement.setMarketRequirementDetails( 
		        		businessProgramDAO.getMarketRequirementDetails(lSmallGroupType.getMarketIndicatorID(), lMarketRequirement.getMarketIndicatorReqID()));
            }
                                      
	        // 4. Then put together the query to read from empl_grp_baseline using the column_nm and the value(s) from step 3.		        
            Collection<GroupBaseline> lGroupBaselineGroups =  
	        	    businessProgramDAO.getNewSmartStepsGroupBaseline(lMarketRequirements, batchCount);        
            
            lGroupsWithOverlapRenewalDates.addAll(businessProgramDAO.getAutoPopulateOverlaps(lMarketRequirements));
	        
	        lNumberOfGroupBaselineProcessed += lGroupBaselineGroups.size();
	        
	        for(GroupBaseline lGroupBaseline : lGroupBaselineGroups)
	        {	        	
	        	logger.info("----Calling autoPopulateNewSmartSteps " + lSmallGroupType.getBusinessProgramType()
		        		+ " " + lGroupBaseline.getEffectiveDate() // renewal date	        		
		        		+ " " + lGroupBaseline.getGroupID() + " " + lGroupBaseline.getSubGroupID() + " " + lAuthCode +  " " + lPromoCode +  " " + lSmallGroupType.getAuthPromoTypeCode());
	        	
		        // Now call the stored procedure to populate business_program, eligible_activities, incentive_options,
		        // extended_auth_codes, and additional_info tables for this group and site.	        	
		        callCreateSmallGroupBizPgm.execute(lSmallGroupType.getBusinessProgramType()
	        		, lGroupBaseline.getEffectiveDate() // renewal date	        		
	        		, lGroupBaseline.getGroupID(), lGroupBaseline.getSubGroupID(), lAuthCode, lPromoCode, lSmallGroupType.getAuthPromoTypeCode());	        	
	        }
		}
				
		emailService.prepareAndSendBatchStatusEmail("BPM Batch Process Status (Auto Populate New SmartSteps) - SUCCESS", 
				"autoPopulateNewSmartSteps completed. Number of Business Programs = " + lNumberOfGroupBaselineProcessed);
		
		
		if(lGroupsWithOverlapRenewalDates.size() > 0)
		{
			StringBuffer lEmailBody = new StringBuffer();
			lEmailBody.append("Market\t\t\t" + "Group\t\t\t" + "GroupNo\t" + "SiteNo\t" + "Renewal Date\t" + "Biz Eff Date\t" + "Biz End Date");
			lEmailBody.append("\r\n\n");
			lEmailBody.append("-------------------------------------------------------------------------------------------------------------------------------------------");
			lEmailBody.append("\r\n\n");
			for(GroupBaseline lGroupBaseline : lGroupsWithOverlapRenewalDates)
			{
				lEmailBody.append(lGroupBaseline.getProgramTypeName() + "\t");
				lEmailBody.append(lGroupBaseline.getGroupName() + "\t");
				
				lEmailBody.append(lGroupBaseline.getGroupNo() + "\t" + lGroupBaseline.getSiteNo() + "\t"); 
				lEmailBody.append(BPMUtils.formatDateMMddyyyy(lGroupBaseline.getEffectiveDate()) + "\t");
				lEmailBody.append(BPMUtils.formatDateMMddyyyy(lGroupBaseline.getProgramEffectiveDate()) + "\t");
				lEmailBody.append(BPMUtils.formatDateMMddyyyy(lGroupBaseline.getProgramEndDate()));
				lEmailBody.append("\r\n\n");
			}
			
			emailService.prepareAndSendBatchStatusEmail("BPM Batch Process Status (Auto Populate Overlapping Group Report) - SUCCESS", 
					"The following Groups, and Sites have Renewal Dates in the middle of an Active business program:\n\r" + lEmailBody.toString());
		}
		
		
		logger.info("******Done autoPopulateNewSmartSteps. Number of Business Programs=" + lNumberOfGroupBaselineProcessed);		
	}
	
	
	/**
	 * Populates one Business Program, and the Eligible Activities, Incentive Option(s), and Additional
	 * Information(s) for it.
	 * 
	 * @param pGroupBaseline
	 * @param pTemplateBPMBusinessProgram
	 */
	@Transactional(timeout = 60, rollbackFor = { DataAccessException.class,
			BPMBusinessValidationException.class, BPMException.class })
	public void populateOneProgram(GroupBaseline pGroupBaseline, BPMBusinessProgram pTemplateBPMBusinessProgram) throws Exception, DataAccessException
	{
        // For every row read from group baseline, create a business program and populate.			
		BPMBusinessProgram lBPMBusinessProgram = new BPMBusinessProgram();
		
		// Set the group ID, subgroup ID, and the group effective date to values read from
		// the group baseline table.
		lBPMBusinessProgram.setGroupID(pGroupBaseline.getGroupID());
		lBPMBusinessProgram.setSubgroupID(pGroupBaseline.getSubGroupID());			
		// 03-06-2009 : May change to Business Program Effective date is always 01/01 of the 
		// current year.
		Calendar lEffectiveDate = Calendar.getInstance();			
		lEffectiveDate = pTemplateBPMBusinessProgram.getEffectiveDate();
		lBPMBusinessProgram.setEffectiveDate(lEffectiveDate);
						
		lBPMBusinessProgram.setProgramTypeCodeID(pGroupBaseline.getProgramTypeCode());
		
		lBPMBusinessProgram.setFamilyParticipationValue(pTemplateBPMBusinessProgram.getFamilyParticipationValue());		
				
		// Set New Hire Date to 1/1/9999
		Calendar lFutureNewHireDate = Calendar.getInstance();
		lFutureNewHireDate.set(Calendar.MONTH, 0);
		lFutureNewHireDate.set(Calendar.DAY_OF_MONTH, 1);
		lFutureNewHireDate.set(Calendar.YEAR, 9999);
		lBPMBusinessProgram.setNewHireDate(lFutureNewHireDate);												
		
		// End date is the last day of 12 months from the effective date.
		lBPMBusinessProgram.setReleaseDate(lBPMBusinessProgram.getEffectiveDate());
		lBPMBusinessProgram.setQualificationWindowStartDate(lBPMBusinessProgram.getEffectiveDate());
		lBPMBusinessProgram.setEndDate(BPMUtils.generateDefaultProgramEndDate(lBPMBusinessProgram.getEffectiveDate()));
		lBPMBusinessProgram.setQualificationWindowEndDate(lBPMBusinessProgram.getEndDate());
		lBPMBusinessProgram.setProgramStatusCodeValue(BPMConstants.BPM_PROGRAM_STATUS_ACTIVE);
				
		lBPMBusinessProgram.setQualificationCheckmarkID(pTemplateBPMBusinessProgram.getQualificationCheckmarkID());
		lBPMBusinessProgram.setEligiblePackageID(pTemplateBPMBusinessProgram.getEligiblePackageID());
		lBPMBusinessProgram.setStatusCalcEndDate(BPMUtils.generateDefaultStatusCalcEndDate(lBPMBusinessProgram.getEndDate(), lBPMBusinessProgram));
		
		// Insert the new Business Program.
		try {
			businessProgramDAO.insertBusinessProgram(lBPMBusinessProgram, BPMConstants.BPM_USER_SYSTEM);
		}
		
		catch (DataAccessException da) {
			logger.info("DataAccessException error  " + da.toString());
			logger.info("BusinessProgramServiceImpl.populateOneProgram:  Error inserting business program.");
			logger.info("Business program attributes follow:");
			System.out.println("Biz program type is   " + lBPMBusinessProgram.getProgramTypeCodeID());
			System.out.println("Group id is           " + lBPMBusinessProgram.getGroupID());
			System.out.println("Subgroup id is        " + lBPMBusinessProgram.getSubgroupID());
			throw da;
			
		}  
		catch (Exception e) {
				logger.info("Exception error  " + e.toString());
				logger.info("BusinessProgramServiceImpl.populateOneProgram:  Error inserting business program.");
				logger.info("Business program attributes follow:");
				System.out.println("Biz program type is   " + lBPMBusinessProgram.getProgramTypeCodeID());
				System.out.println("Group id is           " + lBPMBusinessProgram.getGroupID());
				System.out.println("Subgroup id is        " + lBPMBusinessProgram.getSubgroupID());
				throw e;
				
	     }
		
		// Get the Eligible Activities set up for the Smart Steps template.
		// Populate with this business programs program ID, and the Auth and Promo codes.
		ArrayList<EligibleProgramActivity> lActivities = (ArrayList<EligibleProgramActivity>) 
		    activityDAO.getEligibleProgramActivities(pTemplateBPMBusinessProgram.getProgramID());
		
		for(int i = 0; i < lActivities.size(); i++)
		{
			lActivities.get(i).setBusinessProgramID(lBPMBusinessProgram.getProgramID());
			lActivities.get(i).setBusinessProgramEffectiveDate(lBPMBusinessProgram.getEffectiveDate());
			lActivities.get(i).setBusinessProgramEndDate(lBPMBusinessProgram.getEndDate());
            // Populate with default Auth and Promo Codes
			if(BPMConstants.BPM_ACTIVITY_TYPE_HA.equals(lActivities.get(i).getActivityTypeCodeValue()))
			{
				lActivities.get(i).setAuthCode(BPMUtils.generateProgramAuthPromoCode(lBPMBusinessProgram, BPMConstants.BPM_SS_HA_AUTH_CODE_PREFIX));
			}
			else
			{
				lActivities.get(i).setAuthCode(BPMUtils.generateProgramAuthPromoCode(lBPMBusinessProgram, BPMConstants.BPM_SS_PROMO_CODE_PREFIX));
			}                	
			
			// Insert Eligible Activity
			activityDAO.insertEligibleActivity(lActivities.get(i), BPMConstants.BPM_USER_SYSTEM);											
		}
		
		// Insert Incentive Options and Additional Info.
		// First retrieve Incentive Options and Additional Info for the business program template.
		ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>)
	        incentiveOptionDAO.getIncentiveOptions(pTemplateBPMBusinessProgram.getProgramID());
		
		// For each Program Incentive Option, also retrieve and copy the Incentive Requirements,
		// Activity Incentives, and Incentive Participants.
		for(int i = 0; i < lProgramIncentiveOptions.size(); i++)
		{
			lProgramIncentiveOptions.get(i).setBusinessProgramID(lBPMBusinessProgram.getProgramID());
			lProgramIncentiveOptions.get(i).setFulfillmentRoutingTypeCode(BPMConstants.BPM_FULFILLMENT_ROUTING_NONE);
			
			// Save the program incentive option.
			incentiveOptionDAO.insertProgramIncentiveOption(lProgramIncentiveOptions.get(i), BPMConstants.BPM_USER_SYSTEM);
			 
			ArrayList<IncentiveRequirement> lIncentiveRequirements = (ArrayList<IncentiveRequirement>)
				incentiveOptionDAO.getIncentiveOptionRequirements(pTemplateBPMBusinessProgram.getProgramID()
						, lProgramIncentiveOptions.get(i).getIncentiveOption().getIncentiveOptionID());

			for(int r = 0; r < lIncentiveRequirements.size(); r++)
			{
				// Set the business program ID to the newly created one.				
				lIncentiveRequirements.get(r).setProgramID(lBPMBusinessProgram.getProgramID());
				int lNewlyInsertedRequirementGroupID = 
				    incentiveOptionDAO.insertIncentiveRequirement(lIncentiveRequirements.get(r), BPMConstants.BPM_USER_SYSTEM);
				
				ArrayList<ActivityIncentive> lActivityIncentives = (ArrayList<ActivityIncentive>)
				    incentiveOptionDAO.getActivityIncentives(pTemplateBPMBusinessProgram.getProgramID()
						, lProgramIncentiveOptions.get(i).getIncentiveOption().getIncentiveOptionID()
						, lIncentiveRequirements.get(r).getActivityIncentiveGroupReqID());
				
				for(int ai = 0; ai < lActivityIncentives.size(); ai++)
				{
					// Set the new biz program ID, and the new requirement group ID.
					lActivityIncentives.get(ai).setBusinessProgramID(lBPMBusinessProgram.getProgramID());
					lActivityIncentives.get(ai).setActivityIncentiveGroupID(lNewlyInsertedRequirementGroupID);
					
					int lNewlyInsertedActivityIncentiveID = 
					    incentiveOptionDAO.insertActivityIncentive(lActivityIncentives.get(ai), BPMConstants.BPM_USER_SYSTEM);
					
					ArrayList<IncentiveParticipant> lIncentiveParticipants = lActivityIncentives.get(ai).getIncentiveParticipants();
					
					for(int ip = 0; ip < lIncentiveParticipants.size(); ip++)
					{
						// Set the new activity incentive ID.
						lIncentiveParticipants.get(ip).setActivityIncentiveID(lNewlyInsertedActivityIncentiveID);
					    incentiveOptionDAO.insertIncentiveParticipant(lIncentiveParticipants.get(ip), BPMConstants.BPM_USER_SYSTEM);
					}					
				} // activity incentives
			} // incentive requirements
		} // program incentive options
	    
		ArrayList<AdditionalInformation> lAdditionalInformations = (ArrayList<AdditionalInformation>)
		    additionalInfoDAO.getAdditionalInfo(pTemplateBPMBusinessProgram.getProgramID());
		
		for(int i = 0; i < lAdditionalInformations.size(); i++)
		{
			lAdditionalInformations.get(i).setBusinessProgramID(lBPMBusinessProgram.getProgramID());
			
			// Save the program additional info.
			additionalInfoDAO.insertAdditionalInformation(lAdditionalInformations.get(i), BPMConstants.BPM_USER_SYSTEM);
		}
		
		// Copy and Save Program Checkmarks from one to another.		 
        ArrayList<ProgramCheckmark> lProgramCheckmarks = (ArrayList<ProgramCheckmark>) 
            	qualificationCheckmarkDAO.getProgramCheckmarks(pTemplateBPMBusinessProgram.getProgramID());
        
        if(lProgramCheckmarks.size() > 0)
        {
        	for(ProgramCheckmark lProgramCheckmark : lProgramCheckmarks)
        	{
        		lProgramCheckmark.setBusinessProgramID(lBPMBusinessProgram.getProgramID());        		        		
        	}
        	qualificationCheckmarkDAO.updateProgramCheckmarks(lProgramCheckmarks, lBPMBusinessProgram.getProgramID(), BPMConstants.BPM_USER_SYSTEM);
        }
	}
	
	public Integer createAuditEventLogEntry(BPMAuditRecord bpmAuditRecord) {
		
		Integer auditLogId = null;
		
		try {
			auditLogId = auditLogService.insertAuditLog(bpmAuditRecord);
		} catch (Exception e) {
			logger.error("Error writing AuditEventLogEntry " + e);
		}
		
		return auditLogId;
	}
	
	private int insertActivityBatchLog(int recordsSent, String batchType) {
		
		ACTVBatchLog pACTVBatchLog = new ACTVBatchLog();
		pACTVBatchLog.setBatchType(batchType);
		pACTVBatchLog.setRecordCount(recordsSent);
		
		int batchLogCount = batchLogDAO.insertActivityBatchLog(pACTVBatchLog);
	
		
		return batchLogCount;
	}
	
	
	public void writeToAuditLog(StatusCalculationCommand statusCalculationCommand, String batchMailSubject, String startDate, String endDate,
			String elapsedTime, String counts) {
		
		BPMAuditRecord bpmAuditRecord = BPMAuditRecordFactory
		.createGenericEventRecord(statusCalculationCommand.getUserID(),  statusCalculationCommand.getCurrentCommandText(), 	 
		batchMailSubject, startDate, endDate,
		elapsedTime, counts);
		this.createAuditEventLogEntry(bpmAuditRecord);
			
	}
	
	public Collection<EligibleActivity> getEligibleActivities(Integer programID)
    {    	
    	return getActivityDAO().getEligibleActivities(programID);
    }
	
	public Collection<AuthCode> getExtendedAuthCodes(Integer programID)
    {    	
		return getActivityDAO().selectExtendedAuthCodes(programID);
    }
	
	public Collection<AuthCode> getEligibleAuthCodes(Integer programID)
    {    	
		return getActivityDAO().selectEligibleAuthCodes(programID);
    }
	
	public Collection<ProgramIncentiveOption> getProgramIncentiveOptions(Integer programID)
	{
		return getIncentiveOptionDAO().getIncentiveOptions(programID);
	}
	
	public Collection<IncentiveRequirement> getIncentiveRequirements(int pProgramID, int pIncentiveOptionID)
	{
		return getIncentiveOptionDAO().getIncentiveOptionRequirements(pProgramID, pIncentiveOptionID);
	}
	
	public Collection<AdditionalInformation> getProgramAdditionalInfos(Integer programID)
	{
		return getAdditionalInfoDAO().getAdditionalInfo(programID);
	}
	
	public Collection<EligibleProgramActivity> getEligibleProgramActivities(Integer programID)
	{
		return getActivityDAO().getEligibleProgramActivities(programID);
	}

	/*
	 * @see com.healthpartners.service.bpm.iface.BusinessProgramService#getActiveBusinessPrograms()
	 */
	public Collection<BusinessProgramTO> getActiveBusinessPrograms()
			throws BPMBusinessValidationException, BPMException,
			DataAccessException 
	{		
		int lTargetQualificationYear = qualificationTimeService.getTargetBenefitYear() - 1;
		
		ArrayList<BusinessProgramTO> lBusinessProgramTOs = 
		    (ArrayList<BusinessProgramTO>)businessProgramDAO.getBusinessProgramTOs("", lTargetQualificationYear, "", "");

		return lBusinessProgramTOs;				
	}
	
	public List<ProgramContributionGrid> getProgramContributionGrids(Integer programIncentiveOptionID)
			throws BPMBusinessValidationException,
			DataAccessException  {
		    
		 List<ProgramContributionGrid> lProgramContributionGrids = contributionGridDAO.getProgramContributionGrids(programIncentiveOptionID);
		   
		 return lProgramContributionGrids;
	}
	
	/**
	 * This method returns a list of Business Programs based on group, site, year which is
	 * part of the feed to the membership cache system.
	 *
	 */
	public Collection<GroupSiteYearStage> getBPMGroupSiteYear() 
		throws BPMBusinessValidationException, BPMException,
		DataAccessException 
	{		
		
		ArrayList<GroupSiteYearStage> lBPMGroupSiteYears = 
		    (ArrayList<GroupSiteYearStage>)businessProgramDAO.getBPMGroupSiteYear();
		
		return lBPMGroupSiteYears;				
	}
	
	public long updateContractProgramIncentive(ContractProgramIncentiveTO pContractProgramIncentiveTO)
	throws BPMException, DataAccessException
	{
		return incentiveOptionDAO.updateContractProgramIncentive(pContractProgramIncentiveTO);
	}
	
	public long insertContractProgramIncentive(ContractProgramIncentiveTO pContractProgramIncentiveTO)
	throws BPMException, DataAccessException
	{
		return incentiveOptionDAO.insertContractProgramIncentive(pContractProgramIncentiveTO);
	}
	
	public Collection<ContractProgramIncentiveTO> getContractProgramIncentive(Integer pBusinessProgramID
			, Integer pIncentiveOptionID, Integer pContractNo)
	throws BPMException, DataAccessException
	{
		return incentiveOptionDAO.getContractProgramIncentive(pBusinessProgramID, pIncentiveOptionID, pContractNo);
	}
	
	public long updatePersonActivityIncentive(PersonActivityIncentive pPersonActivityIncentive, String pUserID)
	throws BPMException, DataAccessException
	{
		return incentiveOptionDAO.updatePersonActivityIncentive(pPersonActivityIncentive, pUserID);
	}
	
	public long deleteContractProgramIncentives(Collection<MemberProgramUpdateTO> pContractStatuses, Collection<BPMBusinessProgram> businessPrograms)
	{
		for(MemberProgramUpdateTO lContractStatus : pContractStatuses)
		{
			for(BPMBusinessProgram lBusinessProgram : businessPrograms)
			{
				incentiveOptionDAO.deleteContractProgramIncentive(lContractStatus.getContractNumber(), lBusinessProgram.getProgramID());
			}
		}
		
		return 0;
	}
	
	public long deleteMemberProgramIncentives(Integer pPersonDemographicsID, Collection<BPMBusinessProgram> businessPrograms)
	{
		for(BPMBusinessProgram lBusinessProgram : businessPrograms)
		{
			incentiveOptionDAO.deleteMemberProgramIncentive(pPersonDemographicsID, lBusinessProgram.getProgramID());
		}
		
		return 0;
	}

	
	public Collection<QualificationCheckmark> getQualificationCheckmarks(int pBusinessProgramID)
	throws BPMException, DataAccessException
	{
		return this.qualificationCheckmarkDAO.getQualificationCheckmarks(pBusinessProgramID);
	}
	
	public Collection<CheckmarkRequirement> getCheckmarkRequirements(Integer pQualificationCheckmarkID)
	throws BPMException, DataAccessException
	{
		return this.qualificationCheckmarkDAO.getCheckmarkRequirements(pQualificationCheckmarkID);
	}
	
	
	/**
	 * Return participation group give the ID.
	 * 
	 * @param pParticipationGroupID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public ParticipationGroup getParticipationGroup(Integer pParticipationGroupID)
	throws BPMException, DataAccessException
	{
		ParticipationGroup lParticipationGroup = participationGroupDAO.getParticipationGroup(pParticipationGroupID);
		
		if(lParticipationGroup != null)
		{
			// The getParticipationGroupRequirements method also retrieves the requirement details.
			lParticipationGroup.setParticipationGroupRequirements(
			    participationGroupDAO.getParticipationGroupRequirements(pParticipationGroupID));
		}
		
		return lParticipationGroup;
	}
	
	/**
	 * 
	 * @param pIncentivePackageRuleGroupID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public IncentivePackageRuleGroup getPackageRuleGroup(Integer pIncentivePackageRuleGroupID)
	throws BPMException, DataAccessException
	{
		IncentivePackageRuleGroup lIncentivePackageRuleGroup = incentivePackageRuleDAO.getIncentivePackageRuleGroup(pIncentivePackageRuleGroupID);
		
		if(lIncentivePackageRuleGroup != null)
		{
			lIncentivePackageRuleGroup.setIncentivePackageRuleRequirements(
                 incentivePackageRuleDAO.getIncentivePackageRuleRequirements(pIncentivePackageRuleGroupID));
		}
		
		return lIncentivePackageRuleGroup;
	}

	public BusinessProgramDAO getBusinessProgramDAO() {
		return businessProgramDAO;
	}

	public void setBusinessProgramDAO(BusinessProgramDAO businessProgramDAO) {
		this.businessProgramDAO = businessProgramDAO;
	}

	public ActivityDAO getActivityDAO() {
		return activityDAO;
	}

	public void setActivityDAO(ActivityDAO activityDAO) {
		this.activityDAO = activityDAO;
	}
	
	

	public PersonDAO getPersonDAO() {
		return personDAO;
	}

	public void setPersonDAO(PersonDAO personDAO) {
		this.personDAO = personDAO;
	}

	public QualificationTimeService getQualificationTimeService() {
		return qualificationTimeService;
	}

	public void setQualificationTimeService(
			QualificationTimeService qualificationTimeService) {
		this.qualificationTimeService = qualificationTimeService;
	}

	public final IncentiveOptionDAO getIncentiveOptionDAO() {
		return incentiveOptionDAO;
	}

	public final void setIncentiveOptionDAO(IncentiveOptionDAO incentiveOptionDAO) {
		this.incentiveOptionDAO = incentiveOptionDAO;
	}
	
	public AdditionalInfoDAO getAdditionalInfoDAO() {
		return additionalInfoDAO;
	}

	public void setAdditionalInfoDAO(AdditionalInfoDAO additionalInfoDAO) {
		this.additionalInfoDAO = additionalInfoDAO;
	}

	public GroupBaselineDAO getGroupBaselineDAO() {
		return groupBaselineDAO;
	}

	public void setGroupBaselineDAO(GroupBaselineDAO groupBaselineDAO) {
		this.groupBaselineDAO = groupBaselineDAO;
	}

	public EmailService getEmailService() {
		return emailService;
	}

	public void setEmailService(EmailService emailService) {
		this.emailService = emailService;
	}

	public final QualificationCheckmarkDAO getQualificationCheckmarkDAO() {
		return qualificationCheckmarkDAO;
	}

	public final void setQualificationCheckmarkDAO(
			QualificationCheckmarkDAO qualificationCheckmarkDAO) {
		this.qualificationCheckmarkDAO = qualificationCheckmarkDAO;
	}

	public ParticipationGroupDAO getParticipationGroupDAO() {
		return participationGroupDAO;
	}

	public void setParticipationGroupDAO(ParticipationGroupDAO participationGroupDAO) {
		this.participationGroupDAO = participationGroupDAO;
	}
	
	


	public void setBatchLogDAO(BatchLogDAO batchLogDAO) {
		this.batchLogDAO = batchLogDAO;
	}

	public long insertMemberProgramIncentive(MemberProgramIncentiveTO pMemberProgramIncentiveTO)
	throws DataAccessException
	{
		return this.incentiveOptionDAO.insertMemberProgramIncentive(pMemberProgramIncentiveTO);
	}
			
	public Collection<MemberProgramIncentiveTO> getMemberProgramIncentive(Integer pBusinessProgramID
			, Integer pIncentiveOptionID
			, Integer pContractNo
			, Integer pPersonDemographicsID)
	throws DataAccessException
	{
		return this.incentiveOptionDAO.getMemberProgramIncentive(pBusinessProgramID, pIncentiveOptionID, pContractNo, pPersonDemographicsID);
	}
		
	/**
	 * 
	 */
	public long updateMemberProgramIncentive(MemberProgramIncentiveTO pMemberProgramIncentiveTO)
	throws DataAccessException
	{
		String lCurrentStatus = null;
		
		ArrayList<MemberProgramIncentiveTO> lMemberProgramIncentives = (ArrayList<MemberProgramIncentiveTO>) 
				getMemberProgramIncentive(pMemberProgramIncentiveTO.getBusinessProgramID()
						, pMemberProgramIncentiveTO.getIncentiveOptionID()
						, pMemberProgramIncentiveTO.getContractNo()
						, pMemberProgramIncentiveTO.getPersonDemographicsID());
		
		if(lMemberProgramIncentives.size() > 0)
		{
			lCurrentStatus = lMemberProgramIncentives.get(0).getMemberIncentiveStatusCode();
			if (pMemberProgramIncentiveTO.getMemberProgramIncentiveID() == null) {
				Integer lMemberProgramIncentiveID = lMemberProgramIncentives.get(0).getMemberProgramIncentiveID();
				pMemberProgramIncentiveTO.setMemberProgramIncentiveID(lMemberProgramIncentiveID);
			}
		}
		
		long lNumberOfRowsUpdated = 
		    incentiveOptionDAO.updateMemberProgramIncentive(pMemberProgramIncentiveTO);
						
		
		String lNewStatus = pMemberProgramIncentiveTO.getMemberIncentiveStatusCode();
		boolean lSetToNull = false;
	    // EV 84878
	    // If the status has changed from did-not-achieve to achieved, set the date.		    
	    if(BPMConstants.BPM_CONTRACT_INCENTIVE_ACHIEVED.equals(lNewStatus))
	    {
	    	lSetToNull = false;	    	
	    }
	    
	    if(BPMConstants.BPM_CONTRACT_INCENTIVE_NOT_ACHIEVED.equals(lNewStatus))
	    {
	    	// If the status is NOT_ACHIEVED, set the achieved date to null.
	    	lSetToNull = true;
	    }
	    
	    if(BPMConstants.BPM_CONTRACT_INCENTIVE_NOT_ACHIEVED.equals(lCurrentStatus)
	    		&& (lNewStatus == null || BPMConstants.BPM_CONTRACT_INCENTIVE_NOT_ACHIEVED.equals(lNewStatus)))
	    {
	    	// If the status is NOT_ACHIEVED, set the achieved date to null.
	    	lSetToNull = true;
	    }
					    
	    // Set the Achieved Date the first time the incentive is Achieved. Otherwise it is set to NULL.
        incentiveOptionDAO.setMemberIncentiveAchievedDate(pMemberProgramIncentiveTO.getPersonDemographicsID()
        	, pMemberProgramIncentiveTO.getProgramIncentiveOptionID()    			
	   		, lSetToNull);
	    
		// EV 84878
        
		personDAO.updatePersonQualificationCheckmark(pMemberProgramIncentiveTO.getPersonDemographicsID()
			            , pMemberProgramIncentiveTO.getBusinessProgramID()
			            , pMemberProgramIncentiveTO.getProgramIncentiveOptionID()
			            , pMemberProgramIncentiveTO.getQualificationCheckmarkID());					

		return lNumberOfRowsUpdated;
	}
	
	public long deleteMemberProgramIncentive(MemberProgramIncentiveTO pMemberProgramIncentiveTO)
	throws DataAccessException
	{
		return incentiveOptionDAO.deleteMemberProgramIncentive(pMemberProgramIncentiveTO);
	}
	
	public int setContractIncentiveAchievedDate(Integer pProgramID, Integer pIncentiveOptionID, Integer pContractID, boolean pSetToNull)
	throws DataAccessException
	{
		return incentiveOptionDAO.setContractIncentiveAchievedDate(pProgramID, pIncentiveOptionID, pContractID, pSetToNull);
	}
	
	public Collection<RejectedPerson> getEmployerRecycle(Integer activityId,
			String firstName, String lastName, Date dateOfBirth, Date activityDate, Date recycleStatusDate, Integer recycleStatusId, Integer personDemographicsID, Integer contributionAmt)
			throws DataAccessException {
		
		Collection<RejectedPerson> lRejectedPersons = employerRecycleDAO.getEmployerRecycle(activityId,
				firstName, lastName, dateOfBirth, activityDate, recycleStatusDate, recycleStatusId, personDemographicsID, contributionAmt);
		
		return lRejectedPersons;
	}
	
	public Collection<RejectedPerson> getPersonEmployerPossibleMatches(String firstName, String lastName, Date birthDate, String groupNo)
			throws DataAccessException, SQLTimeoutException, QueryTimeoutException
    {
		return employerRecycleDAO.getPersonEmployerRecyclePossibleMatches(firstName, lastName, birthDate, groupNo);
	}
	
	public void insertEmployerRecycle(RejectedPerson pRejectedPerson, String pUserID)
	throws BPMException, DataAccessException
	{
		employerRecycleDAO.insertEmployerRecycle(pRejectedPerson, pUserID);
	}
	
	public void insertEmployerRecycleWithContribution(RejectedPerson pRejectedPerson, String pUserID)
	throws BPMException, DataAccessException
	{
		employerRecycleDAO.insertEmployerRecycleWithContribution(pRejectedPerson, pUserID);
	}
	
	/**
	 * 
	 * @param lSmallGroupTypes
	 */
	protected void checkForMissingTemplateData(ArrayList<BusinessProgramType> lSmallGroupTypes)
	{
		for(int i = 0; i < lSmallGroupTypes.size(); i++)
		{
			boolean lDataMissing = false;
			StringBuffer lDataMissingText = new StringBuffer();
			
			Integer lProgramID = businessProgramDAO.getTemplateBusinessProgramID(lSmallGroupTypes.get(i).getBusinessProgramType());
			
			Integer lEligibleActivityCount = businessProgramDAO.getTemplateActivitiesCount(lProgramID);
			//See Jira story BPM-60
//			Integer lCheckmarkCount = businessProgramDAO.getTemplateCheckmarkCount(lProgramID);
			Integer lIncentiveCount = businessProgramDAO.getTemplateIncentivesCount(lProgramID);
			
			if(lEligibleActivityCount < 1)
			{
				lDataMissing = true;
				lDataMissingText.append(", Eligible Activities");
			}
			//See Jira story BPM-60
//			if(lCheckmarkCount < 1)
//			{
//				lDataMissing = true;
//				lDataMissingText.append(", Program Checkmarks");
//			}
			if(lIncentiveCount < 1)
			{
				lDataMissing = true;
				lDataMissingText.append(", Incentive Options");				
			}
			
			if(lDataMissing)
			{
				// Send Email
				emailService.prepareAndSendBatchStatusEmail("BPM Batch Process Status (Auto Populate Small Groups) - Missing Template Data", 
						"The template for type " + lSmallGroupTypes.get(i).getBusinessProgramTypeName() + " is missing " + lDataMissingText.toString() + ".");
				
				lSmallGroupTypes.remove(i);
				i = 0;
			}
		}
		
	}
	
	

	public CallCreateSmallGroupBizPgm getCallCreateSmallGroupBizPgm() {
		return callCreateSmallGroupBizPgm;
	}

	public void setCallCreateSmallGroupBizPgm(
			CallCreateSmallGroupBizPgm callCreateSmallGroupBizPgm) {
		this.callCreateSmallGroupBizPgm = callCreateSmallGroupBizPgm;
	}

	public AuditLogService getAuditLogService() {
		return auditLogService;
	}

	public void setAuditLogService(AuditLogService auditLogService) {
		this.auditLogService = auditLogService;
	}

	public MembershipFeedStageService getMembershipFeedStageService() {
		return membershipFeedStageService;
	}

	public void setMembershipFeedStageService(
			MembershipFeedStageService membershipFeedStageService) {
		this.membershipFeedStageService = membershipFeedStageService;
	}

	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}

	public EmployerRecycleDAO getEmployerRecycleDAO() {
		return employerRecycleDAO;
	}

	public void setEmployerRecycleDAO(EmployerRecycleDAO employerRecycleDAO) {
		this.employerRecycleDAO = employerRecycleDAO;
	}

	public ContributionGridDAO getContributionGridDAO() {
		return contributionGridDAO;
	}

	public void setContributionGridDAO(ContributionGridDAO contributionGridDAO) {
		this.contributionGridDAO = contributionGridDAO;
	}

	public final IncentivePackageRuleDAO getIncentivePackageRuleDAO() {
		return incentivePackageRuleDAO;
	}

	public final void setIncentivePackageRuleDAO(
			IncentivePackageRuleDAO incentivePackageRuleDAO) {
		this.incentivePackageRuleDAO = incentivePackageRuleDAO;
	}
	
	
	
}
/* $Id: BPMConstants.java 216881 2012-10-01 12:55:52Z tjquist $ */

package com.healthpartners.service.imfs.common;


/**
 * Common constants representing tags that map to Intelispend XML schema.
 * 
 * @author tjquist
 */

public interface XMLIntelispendTags {

	
	public static final String START_PRODUCT = "<Product DefaultShip='True'>";
	public static final String END_PRODUCT = "</Product>";
	
	public static final String START_ORDER_ITEM = "<Order_Item>";
	public static final String END_ORDER_ITEM = "</Order_Item>";
	
	//Tag for fulfillment history id.  We use Indicative_data_4 for this data element.
	public static final String START_CARDHOLDER_PID_NO = "<Cardholder_PID_Number>";
	public static final String END_CARDHOLDER_PID_NO = "</Cardholder_PID_Number>";
	
	
	public static final String START_FIRST_NAME = "<Demo_First_Name>";
	public static final String END_FIRST_NAME = "</Demo_First_Name>";
	
	public static final String START_MIDDLE_INIT = "<Middle_Name_or_Initial>";
	public static final String END_MIDDLE_INIT = "</Middle_Name_or_Initial>";
	
	public static final String START_LAST_NAME = "<Demo_Last_Name>";
	public static final String END_LAST_NAME = "</Demo_Last_Name>";
	
	public static final String START_CARD_EMBOSS_NAME = "<Card_Emboss_Name>";
	public static final String END_CARD_EMBOSS_NAME = "</Card_Emboss_Name>";
	
	public static final String START_FOURTH_LINE_EMBOSS = "<Fourth_Line_Emboss_Text>";
	public static final String END_FOURTH_LINE_EMBOSS = "</Fourth_Line_Emboss_Text>";
	
	
	public static final String START_ADDRESS_ELEMENT_1 = "<Address_Element_1>";
	public static final String END_ADDRESS_ELEMENT_1 = "</Address_Element_1>";
	
	public static final String START_ADDRESS_ELEMENT_2 = "<Address_Element_2>";
	public static final String END_ADDRESS_ELEMENT_2 = "</Address_Element_2>";
	
	public static final String START_CITY = "<Address_Element_8>";
	public static final String END_CITY = "</Address_Element_8>";
	
	public static final String START_STATE = "<Address_Element_9>";
	public static final String END_STATE = "</Address_Element_9>";
	
	public static final String START_ZIP_CODE = "<Address_Element_10>";
	public static final String END_ZIP_CODE = "</Address_Element_10>";
	
	public static final String START_EXT_ZIP_CODE = "<Address_Element_11>";
	public static final String END_EXT_ZIP_CODE = "</Address_Element_11>";
       
	public static final String START_FUNDING_AMT = "<Transaction_Amount>";
	public static final String END_FUNDING_AMT = "</Transaction_Amount>";
	
	public static final String START_TRANS_DESC = "<Transaction_Description>";
	public static final String END_TRANS_DESC = "</Transaction_Description>";
	
	public static final String START_CARD_CARRIER_MESSAGE = "<Card_Carrier_Message>";
	public static final String END_CARD_CARRIER_MESSAGE = "</Card_Carrier_Message>";
	
	public static final String START_PROGRAM_PARTICIPATION_STATUS = "<Program_Participation_Status>";
	public static final String END_PROGRAM_PARTICIPATION_STATUS = "</Program_Participation_Status>";
	
	public static final String START_GROUP_NUMBER = "<Indicative_Data_1>";
	public static final String END_GROUP_NUMBER = "</Indicative_Data_1>";
	
	public static final String START_GROUP_NAME = "<Indicative_Data_2>";
	public static final String END_GROUP_NAME = "</Indicative_Data_2>";
	
	public static final String START_PARTICIPANT_ID = "<Indicative_Data_3>";
	public static final String END_PARTICIPANT_ID = "</Indicative_Data_3>";
	
	public static final String START_FULFILLMENT_TRK_ID = "<Indicative_Data_4>";
	public static final String END_FULFILLMENT_TRK_ID = "</Indicative_Data_4>";
	
	// EV 96095 Intelispend Know Your Client Tags
	
	public static final String KYC_ADDRESS_INFO = "<KYC_Address_Information>";
	public static final String KYC_END_ADDRESS_INFO = "</KYC_Address_Information>";
	
	public static final String KYC_COMPANY_NAME = "<KYC_Company_Name>";
	public static final String KYC_END_COMPANY_NAME = "</KYC_Company_Name>";
	
	public static final String KYC_CONTACT_NAME = "<KYC_Contact_Name>";
	public static final String KYC_END_CONTACT_NAME = "</KYC_Contact_Name>";
	
	public static final String KYC_ADDRESS_LINE_1 = "<KYC_Address_Line_1>";
	public static final String KYC_END_ADDRESS_LINE_1 = "</KYC_Address_Line_1>";
	
	public static final String KYC_ADDRESS_LINE_2 = "<KYC_Address_Line_2>";
	public static final String KYC_END_ADDRESS_LINE_2 = "</KYC_Address_Line_2>";
	
	public static final String KYC_CITY = "<KYC_City>";
	public static final String KYC_END_CITY = "</KYC_City>";
	
	public static final String KYC_STATE = "<KYC_State>";
	public static final String KYC_END_STATE = "</KYC_State>";
	
	public static final String KYC_ZIP = "<KYC_Zip>";
	public static final String KYC_END_ZIP = "</KYC_Zip>";
	
	public static final String KYC_TAX_ID = "<KYC_Tax_ID>";
	public static final String KYC_END_TAX_ID = "</KYC_Tax_ID>";
}


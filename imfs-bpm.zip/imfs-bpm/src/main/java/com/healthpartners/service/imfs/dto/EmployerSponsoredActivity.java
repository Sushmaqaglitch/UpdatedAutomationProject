
package com.healthpartners.service.imfs.dto;



/**
 * Represents line item from the optum data csv file.
 * @author tjquist
 *
 */
public class EmployerSponsoredActivity {

	private String groupFileSourceName;
	
	
	private String firstName;
	
	private String lastName;
	
	private String activityName;
	
	private String amountEarned;
	
	private String postingDate;
	
	private String middleName;
	
	private String processDate;
	
	private String activityDate;
	
	private String activityDate2;
	
	private String effectiveDate;
	
	private String publishDate;
	
	private String personID;
	
	private String address1;
	
	private String address2;
	
	private String city;
	
	private String stateOrProvince;
	
	private String postalCode;
	
	private String countryName;
	
	private String memberSSN;
	
	private String primaryMemberSSN;
	
	private String maritalStatus;
	
	private String gender;
	
	private String daytimePhoneNumber;
	
	private String eveningPhoneNumber;
	
	private String emailFromEligibility;
	
	private String emailFromRegisProfile;
	
	private String dateOfBirth;
	
	private String relationship;
	
	private String familysUniqueIdentifier;
	
	private String alternateMemberID;
	
	private String accountID;
	
	private String population;
	
	private String division;
	
	private String healthPlanProduct;
	
	private String relationshipID;
	
	private String unionStatus;
	
	private String employeeStatus;
	
	private String PVRC;
	
	private String workLocation;
	
	private String dependentID;
	
	private String externalPersonID;
	
	private String sourceSystemID;
	
	private EmployerSponsoredActivityTrailer employerSponsoredActivityTrailer;
	
	//field elements populated internally
	private String activityNameInternal;
	private Integer activityID;
	private String sourceActivityID;
	private String memberID;
	//for now, registration ID and authCode determined within the code but
	//could be subject to a registration id and auth code from a source
	//system in the future.  This as of 03/28/2014.
	private String registrationID;
	private String authCode;
	private String reasonDesc;
	
	private String errorReason;
	
	
	public EmployerSponsoredActivity() {
		super();
	}


	public String getGroupFileSourceName() {
		return groupFileSourceName;
	}

	public void setGroupFileSourceName(String groupFileSourceName) {
		this.groupFileSourceName = groupFileSourceName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public String getAmountEarned() {
		return amountEarned;
	}

	public void setAmountEarned(String amountEarned) {
		this.amountEarned = amountEarned;
	}

	public String getPostingDate() {
		return postingDate;
	}

	public void setPostingDate(String postingDate) {
		this.postingDate = postingDate;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getProcessDate() {
		return processDate;
	}

	public void setProcessDate(String processDate) {
		this.processDate = processDate;
	}

	public String getActivityDate() {
		return activityDate;
	}


	public void setActivityDate(String activityDate) {
		this.activityDate = activityDate;
	}
	
	
	
	
	public String getActivityDate2() {
		return activityDate2;
	}


	public void setActivityDate2(String activityDate2) {
		this.activityDate2 = activityDate2;
	}


	public String getEffectiveDate() {
		return effectiveDate;
	}


	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}


	public String getPublishDate() {
		return publishDate;
	}

	public void setPublishDate(String publishDate) {
		this.publishDate = publishDate;
	}

	public String getPersonID() {
		return personID;
	}


	public void setPersonID(String personID) {
		this.personID = personID;
	}


	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getStateOrProvince() {
		return stateOrProvince;
	}

	public void setStateOrProvince(String stateOrProvince) {
		this.stateOrProvince = stateOrProvince;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getMemberSSN() {
		return memberSSN;
	}

	public void setMemberSSN(String memberSSN) {
		this.memberSSN = memberSSN;
	}

	public String getPrimaryMemberSSN() {
		return primaryMemberSSN;
	}


	public void setPrimaryMemberSSN(String primaryMemberSSN) {
		this.primaryMemberSSN = primaryMemberSSN;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDaytimePhoneNumber() {
		return daytimePhoneNumber;
	}

	public void setDaytimePhoneNumber(String daytimePhoneNumber) {
		this.daytimePhoneNumber = daytimePhoneNumber;
	}

	public String getEveningPhoneNumber() {
		return eveningPhoneNumber;
	}

	public void setEveningPhoneNumber(String eveningPhoneNumber) {
		this.eveningPhoneNumber = eveningPhoneNumber;
	}

	public String getEmailFromEligibility() {
		return emailFromEligibility;
	}

	public void setEmailFromEligibility(String emailFromEligibility) {
		this.emailFromEligibility = emailFromEligibility;
	}

	public String getEmailFromRegisProfile() {
		return emailFromRegisProfile;
	}


	public void setEmailFromRegisProfile(String emailFromRegisProfile) {
		this.emailFromRegisProfile = emailFromRegisProfile;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public String getFamilysUniqueIdentifier() {
		return familysUniqueIdentifier;
	}


	public void setFamilysUniqueIdentifier(String familysUniqueIdentifier) {
		this.familysUniqueIdentifier = familysUniqueIdentifier;
	}


	public String getAlternateMemberID() {
		return alternateMemberID;
	}

	public void setAlternateMemberID(String alternateMemberID) {
		this.alternateMemberID = alternateMemberID;
	}


	public String getAccountID() {
		return accountID;
	}

	public void setAccountID(String accountID) {
		this.accountID = accountID;
	}

	public String getPopulation() {
		return population;
	}

	public void setPopulation(String population) {
		this.population = population;
	}


	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getHealthPlanProduct() {
		return healthPlanProduct;
	}


	public void setHealthPlanProduct(String healthPlanProduct) {
		this.healthPlanProduct = healthPlanProduct;
	}

	public String getRelationshipID() {
		return relationshipID;
	}

	public void setRelationshipID(String relationshipID) {
		this.relationshipID = relationshipID;
	}

	public String getUnionStatus() {
		return unionStatus;
	}

	public void setUnionStatus(String unionStatus) {
		this.unionStatus = unionStatus;
	}

	public String getEmployeeStatus() {
		return employeeStatus;
	}

	public void setEmployeeStatus(String employeeStatus) {
		this.employeeStatus = employeeStatus;
	}

	public String getPVRC() {
		return PVRC;
	}

	public void setPVRC(String pVRC) {
		PVRC = pVRC;
	}

	public String getWorkLocation() {
		return workLocation;
	}

	public void setWorkLocation(String workLocation) {
		this.workLocation = workLocation;
	}

	public String getDependentID() {
		return dependentID;
	}

	public void setDependentID(String dependentID) {
		this.dependentID = dependentID;
	}
	
	


	public String getExternalPersonID() {
		return externalPersonID;
	}


	public void setExternalPersonID(String externalPersonID) {
		this.externalPersonID = externalPersonID;
	}

	

	public String getSourceSystemID() {
		return sourceSystemID;
	}


	public void setSourceSystemID(String sourceSystemID) {
		this.sourceSystemID = sourceSystemID;
	}


	public EmployerSponsoredActivityTrailer getEmployerSponsoredActivityTrailer() {
		return employerSponsoredActivityTrailer;
	}


	public void setEmployerSponsoredActivityTrailer(
			EmployerSponsoredActivityTrailer employerSponsoredActivityTrailer) {
		this.employerSponsoredActivityTrailer = employerSponsoredActivityTrailer;
	}


	public String getActivityNameInternal() {
		return activityNameInternal;
	}


	public void setActivityNameInternal(String activityNameInternal) {
		this.activityNameInternal = activityNameInternal;
	}


	public Integer getActivityID() {
		return activityID;
	}


	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}


	public String getSourceActivityID() {
		return sourceActivityID;
	}


	public void setSourceActivityID(String sourceActivityID) {
		this.sourceActivityID = sourceActivityID;
	}


	public String getMemberID() {
		return memberID;
	}


	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}


	public String getRegistrationID() {
		return registrationID;
	}


	public void setRegistrationID(String registrationID) {
		this.registrationID = registrationID;
	}


	public String getAuthCode() {
		return authCode;
	}


	public void setAuthCode(String authCode) {
		this.authCode = authCode;
	}


	public String getReasonDesc() {
		return reasonDesc;
	}


	public void setReasonDesc(String reasonDesc) {
		this.reasonDesc = reasonDesc;
	}


	public String getErrorReason() {
		return errorReason;
	}


	public void setErrorReason(String errorReason) {
		this.errorReason = errorReason;
	}


	
	
}

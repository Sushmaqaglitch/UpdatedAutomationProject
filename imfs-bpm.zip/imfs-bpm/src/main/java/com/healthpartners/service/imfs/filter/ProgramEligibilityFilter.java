
package com.healthpartners.service.imfs.filter;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dao.ActivityDAO;
import com.healthpartners.service.imfs.dao.IncentiveOptionDAO;
import com.healthpartners.service.imfs.dao.LookUpValueDAOJdbc;
import com.healthpartners.service.imfs.dto.ActivityEvent;
import com.healthpartners.service.imfs.dto.ActivityIncentive;
import com.healthpartners.service.imfs.dto.AuthCode;
import com.healthpartners.service.imfs.dto.EligibleProgramActivity;
import com.healthpartners.service.imfs.dto.LookUpValueCode;
import com.healthpartners.service.imfs.dto.MemberActivity;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.iface.EmailService;
import com.healthpartners.service.imfs.filter.ActivityEventFilter;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * @author mxthoutam
 * 
 */
public class ProgramEligibilityFilter implements ActivityEventFilter {


	protected final Log logger = LogFactory.getLog(getClass());

	private ActivityDAO activityDAO;
	private LookUpValueDAOJdbc lookUpValueDAO;
	private IncentiveOptionDAO incentiveOptionDAO;
	private EmailService emailService;

	/*
	 * @see com.healthpartners.service.bpm.filter.ActivityEventFilter#doFilter(com.healthpartners.service.bpm.dto.ActivityEvent)
	 */
	public String doFilter(ActivityEvent activityEvent) throws BPMException {
		String result = BPMConstants.BPM_FILTERD_OUT_RSN_CD0_OK; // filter IN
		boolean lEmailSent = false;
		// logger.info("@@ called ProgramEligibilityFilter--");
		try {
			
			EligibleProgramActivity lEligibleProgramActivity = null;
			ArrayList<String> lAllAuthCodes = new ArrayList<String>();
			
			ArrayList<EligibleProgramActivity> lEligibleProgramActivities = (ArrayList<EligibleProgramActivity>)activityDAO
					.getBusinessProgramsForActivity(activityEvent.getMemberActivity().getActivity().getSourceActivityID(),
							activityEvent.getMemberID(), activityEvent.getMemberActivity().getAuthPromoCode(),
							activityEvent.getMemberActivity().getActivityStatus().getStatusEffectiveDate());
			
			Collection<ActivityIncentive> lActivityIncentives = incentiveOptionDAO.getActivityIncentives(activityEvent);
			
			// EV 79743 - Check the activity against the Qualification program-checkmark activities.
			Collection<ActivityIncentive> lCheckmarkIncentives = incentiveOptionDAO.getIncentiveCheckmarkForActivity(activityEvent);
						

			Integer lFirstBusinessProgramID = 0;
			// EV 41020 - Check the Enrollment Deadline Date. If it has passed filter out the activity.
			// But if the member is dual-covered, send an email notification to the BPM group so that
			// the activity can be analyzed for the other business program.
			
			//if arraylist not empty
			if (!lEligibleProgramActivities.isEmpty())	{	
				Integer lBusinessProgramID = lEligibleProgramActivities.get(0).getBusinessProgramID();
				if(lFirstBusinessProgramID.intValue() == 0)
				{
					lFirstBusinessProgramID = lBusinessProgramID;
				}
			}
			
						
			Iterator<ActivityIncentive> iter = (Iterator<ActivityIncentive>) lActivityIncentives.iterator();						
			
			//take first occurrence of activity incentive.  Same activity could be required across incentive options.
			ActivityIncentive lActivityIncentive = null;
			while (iter.hasNext()) {
				lActivityIncentive = iter.next();
				
				java.sql.Date statusEffectiveDateSql = null;
				if (lActivityIncentive != null && (lActivityIncentive.getIncentedStatusTypeCodeDesc().equals(BPMConstants.BPM_INCENTED_STATUS_TYPE_ACTIVITY_BASED) ||
												  lActivityIncentive.getIncentedStatusTypeCodeDesc().equals(BPMConstants.BPM_INCENTED_STATUS_TYPE_ACTIVITY_PACKAGE_BASED) ||
												  lActivityIncentive.getIncentedStatusTypeCodeDesc().equals(BPMConstants.BPM_INCENTED_STATUS_TYPE_MULTI_ACTIVITY))) {
					
					if(BPMConstants.BPM_INCENTIVE_ENROLL_ENROLL_BY.equals(lActivityIncentive.getIncentiveRuleTypeCode()))				    	
				    {			
				    	statusEffectiveDateSql = BPMUtils.calendarToSqlDate(activityEvent.getMemberActivity().getActivityStatus().getStatusEffectiveDate());
				    	if(BPMConstants.ACTIVITY_STATUS_ACTIVE.equals((activityEvent.getMemberActivity().getActivityStatus().getStatusCodeValue()))
				    			&& lActivityIncentive.getEnrollByDeadlineDate() != null
				    			&& statusEffectiveDateSql.after(lActivityIncentive.getEnrollByDeadlineDate())
				    			)
				    	{
				    		
				    		lEmailSent = determineMemberActivityDualCovered(lEligibleProgramActivities, lFirstBusinessProgramID, lEmailSent,  lActivityIncentive, activityEvent);
				    		
				    		return BPMConstants.BPM_FILTERD_OUT_RSN_CD10_PAST_ENROLL_DATE;
				    	}
				    }
				 
				 	
					 if(BPMConstants.BPM_INCENTIVE_ENROLL_COMPLETE_BY.equals(lActivityIncentive.getIncentiveRuleTypeCode()))				    	
					 {			
					   	statusEffectiveDateSql = BPMUtils.calendarToSqlDate(activityEvent.getMemberActivity().getActivityStatus().getStatusEffectiveDate());
					   	if(BPMConstants.ACTIVITY_STATUS_COMPLETE.equals((activityEvent.getMemberActivity().getActivityStatus().getStatusCodeValue()))
					   			&& lActivityIncentive.getCompleteByDeadlineDate() != null
					   			&& statusEffectiveDateSql.after(lActivityIncentive.getCompleteByDeadlineDate())
					 		)
					   	{
					   		lEmailSent = determineMemberActivityDualCovered(lEligibleProgramActivities, lFirstBusinessProgramID, lEmailSent,  lActivityIncentive, activityEvent);   		
					   		return BPMConstants.BPM_FILTERD_OUT_RSN_CD11_PAST_COMPLETION_DATE;
					    }
					 }
				}
			}
					
			
			// EV 79743 - Check the activity against the Qualification program-checkmark activities, and the incentive
			// enrollment, and completion deadline dates.
			// This only applies to CONTRACT_BASED, and MEMBER_BASED incentives.
			
			Iterator<ActivityIncentive> lCheckmarkIncentivesIterator = (Iterator<ActivityIncentive>) lCheckmarkIncentives.iterator();
			ActivityIncentive lCheckmarkIncentive = null;
			while (lCheckmarkIncentivesIterator.hasNext()) 
			{
				lCheckmarkIncentive = lCheckmarkIncentivesIterator.next();
				
				java.sql.Date statusEffectiveDateSql = null;
				if (lCheckmarkIncentive != null && (lCheckmarkIncentive.getIncentedStatusTypeCodeDesc().equals(BPMConstants.BPM_INCENTED_STATUS_TYPE_CONTRACT_BASED) ||
												  lCheckmarkIncentive.getIncentedStatusTypeCodeDesc().equals(BPMConstants.BPM_INCENTED_STATUS_TYPE_MEMBER_BASED))) 
				{
					if(BPMConstants.BPM_INCENTIVE_ENROLL_ENROLL_BY.equals(lCheckmarkIncentive.getIncentiveRuleTypeCode()))				    	
				    {			
				    	statusEffectiveDateSql = BPMUtils.calendarToSqlDate(activityEvent.getMemberActivity().getActivityStatus().getStatusEffectiveDate());
				    	if(BPMConstants.ACTIVITY_STATUS_ACTIVE.equals((activityEvent.getMemberActivity().getActivityStatus().getStatusCodeValue()))
				    			&& lCheckmarkIncentive.getEnrollByDeadlineDate() != null
				    			&& statusEffectiveDateSql.after(lCheckmarkIncentive.getEnrollByDeadlineDate()))
				    	{
				    		lEmailSent = determineMemberActivityDualCovered(lEligibleProgramActivities, lFirstBusinessProgramID, lEmailSent,  lCheckmarkIncentive, activityEvent);
				    		
				    		return BPMConstants.BPM_FILTERD_OUT_RSN_CD10_PAST_ENROLL_DATE;
				    	}
				    }
				 
				 	
					if(BPMConstants.BPM_INCENTIVE_ENROLL_COMPLETE_BY.equals(lCheckmarkIncentive.getIncentiveRuleTypeCode()))				    	
					{			
					   	statusEffectiveDateSql = BPMUtils.calendarToSqlDate(activityEvent.getMemberActivity().getActivityStatus().getStatusEffectiveDate());
					   	if(BPMConstants.ACTIVITY_STATUS_COMPLETE.equals((activityEvent.getMemberActivity().getActivityStatus().getStatusCodeValue()))
					   			&& lCheckmarkIncentive.getCompleteByDeadlineDate() != null
					   			&& statusEffectiveDateSql.after(lCheckmarkIncentive.getCompleteByDeadlineDate()))
					   	{
					   		lEmailSent = determineMemberActivityDualCovered(lEligibleProgramActivities, lFirstBusinessProgramID, lEmailSent,  lCheckmarkIncentive, activityEvent);   		
					   		return BPMConstants.BPM_FILTERD_OUT_RSN_CD11_PAST_COMPLETION_DATE;
					    }
					}
				}
			}
			
			//EV109777 - Add filtered out edit to not allow activities that were taken beyond the program eligible activity effective date period.
			for (EligibleProgramActivity eligibleProgramActivity : lEligibleProgramActivities) {
				if (activityEvent.getMemberActivity().getActivity().getActivityID().equals(eligibleProgramActivity.getActivityID())) {
					if (activityEvent.getMemberActivity().getActivityStatus().getStatusEffectiveDate().after(eligibleProgramActivity.getProgramActivityQualificationEndDate())) {
						return BPMConstants.BPM_FILTERD_OUT_RSN_CD15_BEYOND_ELIGIBLE_ACTIVITY_PERIOD;
					}
				}
			}

			

			if (lEligibleProgramActivities == null || lEligibleProgramActivities.size() < 1) 
			{				
				return BPMConstants.BPM_FILTERD_OUT_RSN_CD6_NO_ACTIVITIES;
			}
			else
			{
				for(int elig = 0; elig < lEligibleProgramActivities.size(); elig++)
				{
					lAllAuthCodes.add(lEligibleProgramActivities.get(elig).getAuthCode());
				}
				lEligibleProgramActivity = lEligibleProgramActivities.get(0); 
			}
			
			// Look up Extended Auth Codes
			ArrayList<AuthCode> lExtendedAuthCodes = (ArrayList<AuthCode>)
			    activityDAO.selectExtendedAuthCodes(lEligibleProgramActivity.getBusinessProgramID());						
			
			for(int ext = 0; ext < lExtendedAuthCodes.size(); ext++)
			{
				lAllAuthCodes.add(lExtendedAuthCodes.get(ext).getAuthCode());
			}						
			
			boolean lAuthCodeFound = false;
			// If Activity is HA, check the Auth Code
			// 10-10-2012 EV 60521: If the activity type is Screening, Bio Marker, or Risk Outcome
			// check the auth-promo code.
			String lActivityType = activityEvent.getMemberActivity().getActivity().getActivityTypeValue();
			
			if(BPMConstants.BPM_ACTIVITY_TYPE_HA.equals(lActivityType)
					|| BPMConstants.BPM_ACTIVITY_TYPE_SCREENING.equals(lActivityType)
					|| BPMConstants.BPM_ACTIVITY_TYPE_BIO_MARKER.equals(lActivityType)
					|| BPMConstants.BPM_ACTIVITY_TYPE_RISK.equals(lActivityType))
			{
				for(int auths = 0; auths < lAllAuthCodes.size(); auths++)
				{
					if(lAllAuthCodes.get(auths) != null && activityEvent.getMemberActivity().getAuthPromoCode() != null)
					{
						if(lAllAuthCodes.get(auths).trim().equalsIgnoreCase(activityEvent.getMemberActivity().getAuthPromoCode().trim()))
						{
							lAuthCodeFound = true;
							break;
						}
					}
				}
				
				if(lAuthCodeFound == false)
				{
					// The auth code of the incoming activity-event was not found.
					return BPMConstants.BPM_FILTERD_OUT_RSN_CD9_NO_AUTH_CD;
				}
			}
			
			
						
			// Lookup Exclustion Types from the LUV table.
			Collection<LookUpValueCode> lExclusionTypes = lookUpValueDAO.getLUVCodesByGroup(BPMConstants.BPM_EXCLUSION_TYPE);
			
			// If activity is not HA, and there is no Registration ID, filter it out.
			if(!BPMConstants.ACTIVITY_HEALTHY_BENEFITS_HA_ID.equals(activityEvent.getMemberActivity().getActivity().getSourceActivityID()))
			{
				if(activityEvent.getMemberActivity().getRegistrationID() == null || 
						activityEvent.getMemberActivity().getRegistrationID().trim().length() < 1)
				{
					return BPMConstants.BPM_FILTERD_OUT_RSN_CD1_NO_REGID;
				}
				
			
                // If has STAT OUTCOME and Eligible Activity Exclusion Flag is set,
				// lookup in the Exclustion Types LUVs.
				// If the OUTCOME is one of the Exclusion Types, set result = false.
				/*
				 * 01/05/2009 - The Exclusion Option will not be implemented for now.
				 * Uncomment once it is implemented.
				if(activityEvent.getMemberActivity().getActivityStatus().getOutCome() != null 						
						&& lEligibleProgramActivity != null 
						&& lEligibleProgramActivity.getExclusionOptionFlag().equalsIgnoreCase("Y"))
				{
					Iterator<LookUpValueCode> lExclusionTypesIterator = lExclusionTypes.iterator();
					if (lExclusionTypesIterator.hasNext()) 
					{
						LookUpValueCode lvalue = lExclusionTypesIterator.next();
						String lExclustionTypeValue = lvalue.getLuvVal();
						
						if(lExclustionTypeValue.equals(activityEvent.getMemberActivity().getActivityStatus().getOutCome()))
						{
							result = false;
						}
					}					
				}
				*/
			}						
																	
			// Check if a Complete has been received for this activity
			if(result.equals(BPMConstants.BPM_FILTERD_OUT_RSN_CD0_OK))
			{
				ArrayList<MemberActivity> lExistingComplete = (ArrayList<MemberActivity>)
				activityDAO.getExistingActivity(activityEvent.getMemberID(), activityEvent
							.getMemberActivity().getActivity().getSourceActivityID(),
							new java.sql.Date(activityEvent.getMemberActivity().getActivityStatus().getStatusEffectiveDate().getTime().getTime()),
							activityEvent.getMemberActivity().getAuthPromoCode(),
							activityEvent.getMemberActivity().getRegistrationID(),
							BPMConstants.ACTIVITY_STATUS_COMPLETE);								
				
				if(lExistingComplete.size() > 0)				   
				{
					if(BPMConstants.ACTIVITY_HEALTHY_BENEFITS_HA_ID.equals(activityEvent.getMemberActivity().getActivity().getSourceActivityID()))
					{
						if(BPMConstants.ACTIVITY_STATUS_PENDING.equals(activityEvent.getMemberActivity().getActivityStatus().getStatusCodeValue()))
						{
                            result = BPMConstants.BPM_FILTERD_OUT_RSN_CD2_HA_PENDING;
						}
					}
					else
					{
						// If the activity is being WAIVED, let it in. If NOT Waive, check the date.
						if(!(BPMConstants.ACTIVITY_STATUS_WAIVE.equals(activityEvent.getMemberActivity().getActivityStatus().getStatusCodeValue())
						  || BPMConstants.ACTIVITY_STATUS_EXEMPT.equals(activityEvent.getMemberActivity().getActivityStatus().getStatusCodeValue()))
						  )
						{						
	                        // If there is already a Complete, Check the activity date.
							// If the received-activity-date is older than the existing complete,
							// filter out the received activity. 						
													
							for(int i = 0; i < lExistingComplete.size(); i++)
							{
								MemberActivity lExistingMemberActivity = (MemberActivity)lExistingComplete.get(i);																
								
								// If there is an existing COMPLETE, filter-out the incoming ACTIVE.
								// Reason being, if we let this activity in, it becomes the latest status for this activity.
								// If the activity has been completed, we don't want an earlier Active to become the latest.																
								
								if(BPMConstants.ACTIVITY_STATUS_COMPLETE.equals((lExistingMemberActivity.getActivityStatus().getStatusCodeValue())))
								{
									if(BPMConstants.ACTIVITY_STATUS_ACTIVE.equals((activityEvent.getMemberActivity().getActivityStatus().getStatusCodeValue())))
									{	
										result = BPMConstants.BPM_FILTERD_OUT_RSN_CD3_ACTIVE_W_EXISTING_COMPLETE;
									}
							    }															
							}																									
						} // if not waive
					} // else of if HA
				} // if existing complete
								
				ArrayList<MemberActivity> lExistingWaive = (ArrayList<MemberActivity>)
				activityDAO.getExistingWaive(activityEvent.getMemberID(), activityEvent
							.getMemberActivity().getActivity()
							.getSourceActivityID(), new java.sql.Date(activityEvent.getMemberActivity().getActivityStatus().getStatusEffectiveDate().getTime().getTime()));								
				
	            // If there is an existing WAIVE for this program-year, filter this out.
				if(lExistingWaive.size() > 0)
				{
					result = BPMConstants.BPM_FILTERD_OUT_RSN_CD4_WAIVE;
				}			
			}
									
			
			// Check if this activity is COMPLETE, INACTIVE, CANCEL or DELETE, the ACTIVE or ACTV_EXMPT must exist within the same program year.
			// If the ACTIVE or ACTV_EXMPT exists it's Ok. Otherwise filter out.
			// This rule does NOT apply to DM and Employer Sponsored activities.
			// EV 58500 - Added Screening to allow an activity type of SCREENING through without an ACTIVE SCREENING activity event.
			// 09-16-2013 - Add Goal Completion to the list. Goal Completion does not need ACTIVE either.
			if(!BPMConstants.ACTIVITY_HEALTHY_BENEFITS_HA_ID.equals(activityEvent.getMemberActivity().getActivity().getSourceActivityID())
					&& !BPMConstants.ACTIVITY_TYPE_DISEASE_MGMT.equals(activityEvent.getMemberActivity().getActivity().getActivityTypeValue())
					&& !BPMConstants.ACTIVITY_TYPE_EMPLOYER_PGM.equals(activityEvent.getMemberActivity().getActivity().getActivityTypeValue())
					&& !BPMConstants.BPM_ACTIVITY_TYPE_SCREENING.equals(activityEvent.getMemberActivity().getActivity().getActivityTypeValue())
					&& !BPMConstants.BPM_ACTIVITY_TYPE_GOAL_COMPLETION.equals(activityEvent.getMemberActivity().getActivity().getActivityTypeValue())
					&& 
					(BPMConstants.ACTIVITY_STATUS_COMPLETE.equals(activityEvent.getMemberActivity().getActivityStatus().getStatusCodeValue())
					  || BPMConstants.ACTIVITY_STATUS_INACTIVE.equals(activityEvent.getMemberActivity().getActivityStatus().getStatusCodeValue())
					  || BPMConstants.ACTIVITY_STATUS_CANCELED.equals(activityEvent.getMemberActivity().getActivityStatus().getStatusCodeValue())
					  //|| BPMConstants.ACTIVITY_STATUS_DELETE.equals(activityEvent.getMemberActivity().getActivityStatus().getStatusCodeValue())
					  )
					)
			{
				ArrayList<MemberActivity> lExistingActive = (ArrayList<MemberActivity>)
				activityDAO.getExistingActivity(activityEvent.getMemberID(), activityEvent
							.getMemberActivity().getActivity().getSourceActivityID(),
							new java.sql.Date(activityEvent.getMemberActivity().getActivityStatus().getStatusEffectiveDate().getTime().getTime()),
							activityEvent.getMemberActivity().getAuthPromoCode(),
							activityEvent.getMemberActivity().getRegistrationID(),
							BPMConstants.ACTIVITY_STATUS_ACTIVE);
				
				// For this Complete, there is an Active in the same year. Ok.
				if(lExistingActive.size() > 0)
				{
					result = BPMConstants.BPM_FILTERD_OUT_RSN_CD0_OK;
				}
				else
				{
					// For this Complete, there is no Active in the same year. Filter out.
					result = BPMConstants.BPM_FILTERD_OUT_RSN_CD5_NO_ACTIVE;
				}
			}
				
			
		} catch (Exception e) {
			BPMUtils.logException(logger, e);
			throw new BPMException(e);
		}

		return result;
	}
	
	/* If activity is eligible in more than one business program, check if
	* the member is dual covered. It is being filtered out, so send an email notification.
	* (the query returns more than one row due to extended auth codes.
	*/
	
	private boolean determineMemberActivityDualCovered(ArrayList<EligibleProgramActivity> lEligibleProgramActivities, Integer lFirstBusinessProgramID, boolean lEmailSent, ActivityIncentive lActivityIncentive, ActivityEvent activityEvent) {
		
		if(lEligibleProgramActivities.size() > 1)				    			
		{
			for(int lBiz = 0; lBiz < lEligibleProgramActivities.size(); lBiz++)
			{
				// There is at least one biz program ID that is different from the first one. This member is dual-covered.
				// Send an email.
				if(lEligibleProgramActivities.get(lBiz).getBusinessProgramID().intValue() != lFirstBusinessProgramID.intValue()
						&& lEmailSent == false)
				{
					sendEmail(activityEvent, lActivityIncentive.getBusinessProgramID(), lActivityIncentive.getEnrollByDeadlineDate(), lActivityIncentive.getCompleteByDeadlineDate());
					lEmailSent = true;
				}
			}				    			
		}
		return lEmailSent;
	}
	
	private void sendEmail(ActivityEvent activityEvent, Integer programID, java.sql.Date enrollByDeadlineDate, java.sql.Date completeByDeadlineDate)
	{
		StringBuffer batchMailSubject = new StringBuffer();
		batchMailSubject.append("Dual Covered Member Activity Filtered Out");
		StringBuffer batchMailContent = new StringBuffer();
		batchMailContent.append("Member ID: " + activityEvent.getMemberID() + "\n");
		batchMailContent.append("Activity: " + activityEvent.getMemberActivity().getActivity().getSourceActivityID() + "\n");
		batchMailContent.append("Has been filtered out for this Business Program ID:" + programID + "\n");
		if (enrollByDeadlineDate != null) {
			batchMailContent.append("Because it was past the Enrollment Deadline Date of: "+ BPMUtils.getFormattedDateTime(enrollByDeadlineDate) + "\n");
		} else if (completeByDeadlineDate != null) {
			batchMailContent.append("Because it was past the Completion Deadline Date of: "+ BPMUtils.getFormattedDateTime(completeByDeadlineDate) + "\n");
		}
		batchMailContent.append("But it may be Eligible for other business programs.\n");
		batchMailContent.append("If so, the activity will need to be added into the person_program_activity_status table.\n");
		
		// send email batch summary
		emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
				batchMailContent.toString());		
	}
	
	

	public ActivityDAO getActivityDAO() {
		return activityDAO;
	}

	public void setActivityDAO(ActivityDAO activityDAO) {
		this.activityDAO = activityDAO;
	}

	public LookUpValueDAOJdbc getLookUpValueDAO() {
		return lookUpValueDAO;
	}

	public void setLookUpValueDAO(LookUpValueDAOJdbc lookUpValueDAO) {
		this.lookUpValueDAO = lookUpValueDAO;
	}

	public final IncentiveOptionDAO getIncentiveOptionDAO() {
		return incentiveOptionDAO;
	}

	public final void setIncentiveOptionDAO(IncentiveOptionDAO incentiveOptionDAO) {
		this.incentiveOptionDAO = incentiveOptionDAO;
	}

	public final EmailService getEmailService() {
		return emailService;
	}

	public final void setEmailService(EmailService emailService) {
		this.emailService = emailService;
	}

	
	
}

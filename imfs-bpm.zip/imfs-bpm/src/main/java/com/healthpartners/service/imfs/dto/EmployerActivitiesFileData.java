package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.util.Collection;

/**
 * This represents the activity summary after reading data file
 * 
 * @author tjquist
 * 
 */
public class EmployerActivitiesFileData implements Serializable {

	static final long serialVersionUID = 0L;

	private String sourceActivityID;
	
	private String activityName;
	
	private String sourceSystemID;
	
	private java.sql.Date statusEffectiveDate;
	
	private String insertUserId;

	private Collection<EmployerActivity> completedMemberActivities;

	private Collection<EmployerActivity> incompleteMemberActivities;

	private Collection<EmployerActivity> validMemberActivities;

	private Collection<EmployerActivity> invalidMemberActivities;

	public EmployerActivitiesFileData() {
		super();
	}

	public Collection<EmployerActivity> getInvalidMemberActivities() {
		return invalidMemberActivities;
	}

	public void setInvalidMemberActivities(
			Collection<EmployerActivity> invalidMemberActivities) {
		this.invalidMemberActivities = invalidMemberActivities;
	}

	public String getSourceActivityID() {
		return sourceActivityID;
	}

	public void setSourceActivityID(String sourceActivityID) {
		this.sourceActivityID = sourceActivityID;
	}

	public Collection<EmployerActivity> getValidMemberActivities() {
		return validMemberActivities;
	}

	public void setValidMemberActivities(Collection<EmployerActivity> validMemberActivities) {
		this.validMemberActivities = validMemberActivities;
	}

	public Collection<EmployerActivity> getCompletedMemberActivities() {
		return completedMemberActivities;
	}

	public void setCompletedMemberActivities(
			Collection<EmployerActivity> completedMemberActivities) {
		this.completedMemberActivities = completedMemberActivities;
	}

	public Collection<EmployerActivity> getIncompleteMemberActivities() {
		return incompleteMemberActivities;
	}

	public void setIncompleteMemberActivities(
			Collection<EmployerActivity> incompleteMemberActivities) {
		this.incompleteMemberActivities = incompleteMemberActivities;
	}

	
	public String getSourceSystemID() {
		return sourceSystemID;
	}

	public void setSourceSystemID(String sourceSystemID) {
		this.sourceSystemID = sourceSystemID;
	}

	
	public java.sql.Date getStatusEffectiveDate() {
		return statusEffectiveDate;
	}

	public void setStatusEffectiveDate(java.sql.Date statusEffectiveDate) {
		this.statusEffectiveDate = statusEffectiveDate;
	}

	public String getInsertUserId() {
		return insertUserId;
	}

	public void setInsertUserId(String insertUserId) {
		this.insertUserId = insertUserId;
	}

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	// custom methods
	public int getValidMemberActivityCount() {
		return (validMemberActivities != null) ? validMemberActivities.size() : 0;
	}

	public int getInvalidMemberActivityCount() {
		return (invalidMemberActivities != null) ? invalidMemberActivities.size() : 0;
	}

	public int getIncompleteMemberActivityCount() {
		return (incompleteMemberActivities != null) ? incompleteMemberActivities
				.size()
				: 0;
	}

	public int getTotalNumberOfMemberActivityLines() {

		return (getValidMemberActivityCount() + getInvalidMemberActivityCount() + getIncompleteMemberActivityCount());
	}
}

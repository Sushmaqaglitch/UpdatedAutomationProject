package com.healthpartners.service.imfs.dto;

import java.util.Calendar;

/**
 * This class represents the internal BPM package Data Transfer Object.
 * It is not exposed to web services for example.
 * 
 * @author jxbourbour
 *
 */
public class BusinessProgramTO extends BaseDTO
{
    static final long serialVersionUID = 0L;        
    
    BusinessProgram businessProgram;
    private Calendar membershipProcessDate;
	
    // Database table ID.
	private int programID;
	private int groupID;
	private int subGroupID;
	
	public BusinessProgramTO()
    {
        super();    	
    }

	public int getProgramID() {
		return programID;
	}

	public void setProgramID(int programID) {
		this.programID = programID;
	}

	public BusinessProgram getBusinessProgram() {
		return businessProgram;
	}

	public void setBusinessProgram(BusinessProgram businessProgram) {
		this.businessProgram = businessProgram;
	}

	public final Calendar getMembershipProcessDate() {
		return membershipProcessDate;
	}

	public final void setMembershipProcessDate(Calendar membershipProcessDate) {
		this.membershipProcessDate = membershipProcessDate;
	}

	public int getGroupID() {
		return groupID;
	}

	public void setGroupID(int groupID) {
		this.groupID = groupID;
	}

	public int getSubGroupID() {
		return subGroupID;
	}

	public void setSubGroupID(int subGroupID) {
		this.subGroupID = subGroupID;
	}
	
	
}

package com.healthpartners.service.imfs.iface;

import com.healthpartners.service.imfs.exception.BPMException;
import java.sql.Date;
import java.util.Collection;

import com.healthpartners.service.imfs.dto.*;
import org.springframework.dao.DataAccessException;

public interface MembershipFeedStageService
{

    public abstract int getPersonProgramCount()
        throws BPMException, DataAccessException;

    public abstract int insertPersonPrograms(Collection<PersonProgramStage> personPrograms)
        throws BPMException, DataAccessException;

    public abstract int deletePersonPrograms(Collection<PersonProgramStage> personPrograms)
        throws BPMException, DataAccessException;

    public abstract PersonProgramStage getPersonProgram(int i)
        throws BPMException, DataAccessException;

    public abstract Collection<PersonProgramStage> getPersonPrograms()
        throws BPMException, DataAccessException;
    

    public abstract int getGroupSiteYearCount()
        throws BPMException, DataAccessException;

    public abstract int insertGroupSiteYears(Collection<GroupSiteYearStage> groupSiteYears)
        throws BPMException, DataAccessException;

    public abstract int deleteGroupSiteYears(Collection<GroupSiteYearStage> groupSiteYears)
        throws BPMException, DataAccessException;

    public abstract GroupSiteYearStage getGroupSiteYear(int i, int j, Date date)
        throws BPMException, DataAccessException;

    public abstract Collection<GroupSiteYearStage> getGroupSiteYears()
        throws BPMException, DataAccessException;

    public abstract int insertReconLogStage(ReconLogStage reconlogstage)
        throws BPMException, DataAccessException;

    public abstract ReconLogStage getReconLogStage(Integer integer)
        throws BPMException, DataAccessException;
    
    public int getPersonActivityCount()
			throws BPMException, DataAccessException;
	
	public Collection<PersonActivityStage> getPersonActivitys()
		throws BPMException, DataAccessException;
		
	public PersonActivityStage getPersonActivity(int personNumber)
		throws BPMException, DataAccessException;
		
	public int insertPersonActivitys(Collection<ActivityFulfillmentTrackingReportHist> lActivityFulfillmentTrackingReportHist)
		throws BPMException, DataAccessException, Exception;
	
	
	public int deletePersonActivitys() 
		throws BPMException, DataAccessException;
		
	public int insertPersonActivitySummary(int recordsSentToMembershipPremiumBillingCount)
		throws BPMException, DataAccessException, Exception; 
	public PersonActivitySummaryStage getPersonActivitySummary() throws BPMException, DataAccessException;
		
	public int deletePersonActivitySummary() 
		throws BPMException, DataAccessException;
		

	
}
package com.healthpartners.service.imfs.dto;

import java.util.Calendar;

public class EligibleProgramActivity 
{
    private Integer businessProgramID;
    private Integer activityID;
    private String activityName;
    private String authCode;
    private Calendar businessProgramEffectiveDate;
    private Calendar businessProgramEndDate;
    private String exclusionOptionFlag;
    private String activityGroupName;
    private String activityTypeCodeValue;
    private Integer incentiveOverrideCodeID;
    private Calendar enrollmentDeadlineDate;
    private Calendar programActivityQualificationEffectiveDate;
    private Calendar programActivityQualificationEndDate;
    
    public EligibleProgramActivity()
    {    	
    }
    
	public Integer getActivityID() {
		return activityID;
	}
	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}
	public String getAuthCode() {
		return authCode;
	}
	public void setAuthCode(String authCode) {
		this.authCode = authCode;
	}
	public Integer getBusinessProgramID() {
		return businessProgramID;
	}
	public void setBusinessProgramID(Integer businessProgramID) {
		this.businessProgramID = businessProgramID;
	}

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public final Calendar getBusinessProgramEffectiveDate() {
		return businessProgramEffectiveDate;
	}

	public final void setBusinessProgramEffectiveDate(
			Calendar businessProgramEffectiveDate) {
		this.businessProgramEffectiveDate = businessProgramEffectiveDate;
	}

	public final Calendar getBusinessProgramEndDate() {
		return businessProgramEndDate;
	}

	public final void setBusinessProgramEndDate(Calendar businessProgramEndDate) {
		this.businessProgramEndDate = businessProgramEndDate;
	}

	public final String getExclusionOptionFlag() {
		return exclusionOptionFlag;
	}

	public final void setExclusionOptionFlag(String exclusionOptionFlag) {
		this.exclusionOptionFlag = exclusionOptionFlag;
	}

	public String getActivityGroupName() {
		return activityGroupName;
	}

	public void setActivityGroupName(String activityGroupName) {
		this.activityGroupName = activityGroupName;
	}

	public String getActivityTypeCodeValue() {
		return activityTypeCodeValue;
	}

	public void setActivityTypeCodeValue(String activityTypeCodeValue) {
		this.activityTypeCodeValue = activityTypeCodeValue;
	}

	public Integer getIncentiveOverrideCodeID() {
		return incentiveOverrideCodeID;
	}

	public void setIncentiveOverrideCodeID(Integer incentiveOverrideCodeID) {
		this.incentiveOverrideCodeID = incentiveOverrideCodeID;
	}

	public Calendar getEnrollmentDeadlineDate() {
		return enrollmentDeadlineDate;
	}

	public void setEnrollmentDeadlineDate(Calendar enrollmentDeadlineDate) {
		this.enrollmentDeadlineDate = enrollmentDeadlineDate;
	}

	public Calendar getProgramActivityQualificationEffectiveDate() {
		return programActivityQualificationEffectiveDate;
	}

	public void setProgramActivityQualificationEffectiveDate(Calendar programActivityQualificationEffectiveDate) {
		this.programActivityQualificationEffectiveDate = programActivityQualificationEffectiveDate;
	}

	public Calendar getProgramActivityQualificationEndDate() {
		return programActivityQualificationEndDate;
	}

	public void setProgramActivityQualificationEndDate(Calendar programActivityQualificationEndDate) {
		this.programActivityQualificationEndDate = programActivityQualificationEndDate;
	}

	
    
}

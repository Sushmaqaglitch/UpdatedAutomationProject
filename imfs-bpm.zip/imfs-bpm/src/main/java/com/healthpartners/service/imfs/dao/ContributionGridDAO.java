package com.healthpartners.service.imfs.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.healthpartners.service.imfs.dto.ContributionGridBenefitContractTypeRelationship;
import com.healthpartners.service.imfs.dto.ProgramContributionGrid;
import org.springframework.dao.DataAccessException;



public interface ContributionGridDAO 
{
	public List<ProgramContributionGrid> getProgramContributionGrids(Integer programIncentiveOptionID)
			throws DataAccessException;
	
	public Collection<ContributionGridBenefitContractTypeRelationship> getContributionGridBenefitContractTypeRelationships(Integer benefitContractTypeID)
			throws DataAccessException;
	
}

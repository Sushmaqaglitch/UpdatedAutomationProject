package com.healthpartners.service.imfs.dao;

import java.util.Collection;

import com.healthpartners.service.imfs.dto.ControlGroupIOFileDirSetup;
import org.springframework.dao.DataAccessException;


public interface ControlGroupIOFileDirSetupDAO 
{

	public Collection<ControlGroupIOFileDirSetup> getControlGroupsIOFileDirSetup(Integer routingTypeID) throws DataAccessException;
	
}

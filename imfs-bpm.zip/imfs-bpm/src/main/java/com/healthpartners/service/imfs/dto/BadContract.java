package com.healthpartners.service.imfs.dto;

import java.util.Calendar;

public class BadContract 
{
	private Integer contractPgmStatId;
	private Integer bizProgramId;
	private Integer personId;
	
	
	public BadContract()
	{
		super();
	}


	public Integer getBizProgramId() {
		return bizProgramId;
	}


	public void setBizProgramId(Integer bizProgramId) {
		this.bizProgramId = bizProgramId;
	}


	public Integer getPersonId() {
		return personId;
	}


	public void setPersonId(Integer personId) {
		this.personId = personId;
	}


	public Integer getContractPgmStatId() {
		return contractPgmStatId;
	}


	public void setContractPgmStatId(Integer contractPgmStatId) {
		this.contractPgmStatId = contractPgmStatId;
	}


	

}

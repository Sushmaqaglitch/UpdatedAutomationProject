package com.healthpartners.service.imfs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.*;

import com.fasterxml.jackson.databind.util.Named;
import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.exception.BPMException;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;

@Configuration
public class IncentiveOptionDAOJdbc extends JdbcDaoSupport implements IncentiveOptionDAO
{
	private String selectProgramIncentiveOptions;
	private String insertProgramIncentiveOption;
	private String selectIncentiveForActivity;
	private String selectIncentiveForActivityOutsideEnrollment;
	private String selectPersonActivityIncentive;
	private String updatePersonActivityIncentive;
	private String updatePersonActivityIncentiveWithContributionAmt;
	private String updatePersonActivityIncentiveWithModificationDate;
	private String insertIntoPersonActivityIncentive;
	private String selectIncentiveParticipant;
	private String selectIncentiveRequirements;
	private String selectActivityIncentive;
	private String selectContractProgramIncentive;
	private String insertContractProgramIncentive;
	private String updateContractProgramIncentive;
	private String deleteContractProgramIncentive;
	private String insertIncentiveStatusActivityDetail;
	private String insertIncentiveStatusActivityDetailContribution;
	private String insertIncentiveRequirement;
	private String insertActivityIncentive;
	private String insertIncentiveParticipant;
	private String selectIncentiveStatusActivityDetails;
	private String selectIncentiveStatusActivityDetailContributions;
	
	private String selectMemberProgramIncentive;
	private String insertMemberProgramIncentive;
	private String updateMemberProgramIncentive;
	private String deleteMemberProgramIncentive;
	
	private String selectCollectionActivities;
	
	private String updateContractIncentiveAchievedDate;
	private String updateMemberIncentiveAchievedDate;
	
	private String isActivityCompletionPeriodEnabled;
	@Autowired
	private DataFieldMaxValueIncrementer incentiveRequirementIdIncrementer;
	@Autowired
	private DataFieldMaxValueIncrementer activityIncentiveIdIncrementer;
	@Autowired
	private DataFieldMaxValueIncrementer contractIncentiveIdIncrementer;
	@Autowired
	private DataFieldMaxValueIncrementer memberIncentiveIdIncrementer;
	@Autowired
	private DataFieldMaxValueIncrementer incentiveStatusActivityDetailIdIncrementer;
	
    private String selectIncentiveCheckmarkForActivity;  
    
    private String selectPersonProgramActivityStatusByID;
    
    private String selectIncentiveOptionDefinitionByName;
    private String selectContractIncentivesAchievedByProgramIncentiveOptionSummary;
    private String selectMemberIncentivesAchievedByProgramIncentiveOptionSummary;
	
	public IncentiveOptionDAOJdbc() {
		super();
	}

	@Autowired
	DataSource bpmDataSource;

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;


	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}

	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<ProgramIncentiveOption> getIncentiveOptions(Integer programID)
	throws DataAccessException
	{

		Object params[] = new Object[] { programID };
		int types[] = new int[] { Types.INTEGER };

		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setBizPgmId(programID);
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<ProgramIncentiveOption> lProgramIncentiveOptions = namedParameterJdbcTemplate.query(selectProgramIncentiveOptions, namedParameters, new RowMapper()
		{
			@Override
			public ProgramIncentiveOption mapRow(ResultSet rs, int i) throws SQLException {
				ProgramIncentiveOption lProgramIncentiveOption = new ProgramIncentiveOption();
				IncentiveOption lIncentiveOption = new IncentiveOption();

				lProgramIncentiveOption.setIncentiveOption(lIncentiveOption);

				lIncentiveOption.setIncentiveOptionID(rs.getInt("INCNTV_OPTN_ID"));
				lIncentiveOption.setIncentiveOptionName(rs.getString("INCNTV_OPTN_NM"));
				lIncentiveOption.setIncentiveOptionDesc(rs.getString("INCNTV_OPTN_DESC"));
				lIncentiveOption.setIncentiveOptionTypeCodeID(rs.getInt("INCNTV_OPTN_TP_CD_ID"));
				lIncentiveOption.setIncentiveOptionTypeCode(rs.getString("option_type_val"));
				lIncentiveOption.setIncentiveOptionTypeDesc(rs.getString("option_type_desc"));
				lIncentiveOption.setIncentiveUnitTypeCodeID(rs.getInt("incntv_unit_tp_cd_id"));
				lIncentiveOption.setIncentiveUnitTypeCode(rs.getString("INCNTV_UNIT_TYPE_CODE"));

				lProgramIncentiveOption.setBusinessProgramID(rs.getInt("BIZ_PGM_ID"));
				lProgramIncentiveOption.setEffectiveDate(BPMUtils.getFormattedDateTime(rs.getDate("INCNTV_OPTN_EFF_DT")));
				lProgramIncentiveOption.setEndDate(BPMUtils.getFormattedDateTime(rs.getDate("INCNTV_OPTN_END_DT")));
				lProgramIncentiveOption.setActivationDate(BPMUtils.getFormattedDateTime(rs.getDate("INCNTV_OPTN_ACTV_DT")));
				lProgramIncentiveOption.setDeliveryDate(BPMUtils.getFormattedDateTime(rs.getDate("INCNTV_OPTN_DLVRY_DT")));
				lProgramIncentiveOption.setAdditionalInfo(rs.getString("INCNTV_OPTN_ADDL_INFO"));
				lProgramIncentiveOption.setIncentiveOptionInfo(rs.getString("INCNTV_OPTN_INFO"));
				lProgramIncentiveOption.setIncentiveOptionStatusCodeID(rs.getInt("STAT_CD_ID"));
				lProgramIncentiveOption.setIncentiveOptionStatusCode(rs.getString("option_stat_val"));
				lProgramIncentiveOption.setIncentiveOptionStatusCodeDesc(rs.getString("option_stat_desc"));

				lProgramIncentiveOption.setIncentedStatusTypeCodeID(rs.getInt("INCNTD_STS_TP_CD_ID"));
				lProgramIncentiveOption.setIncentedStatusTypeCode(rs.getString("INCNTD_STS_TP_CD"));
				lProgramIncentiveOption.setParticipantCap(rs.getInt("PARTICIP_CAP"));
				lProgramIncentiveOption.setFamilyCap(rs.getInt("FAMILY_CAP"));
				lProgramIncentiveOption.setEnrollmentDeadlineDate(rs.getDate("ENROLL_DEADLINE_DATE"));
				lProgramIncentiveOption.setCompletionDeadlineDate(rs.getDate("COMPL_DEADLINE_DATE"));
				lProgramIncentiveOption.setIncentiveRuleTypeCode(rs.getString("INCNTV_RULE_TYPE"));

				lProgramIncentiveOption.setParticipationGroupID(rs.getInt("INCNTV_PART_GRP_ID"));
				lProgramIncentiveOption.setActivityCompletionPeriod(rs.getInt("ACTV_CMPLTN_PRD"));

				lProgramIncentiveOption.setProgramIncentiveOptionID(rs.getInt("BIZ_PGM_INCNTV_OPTN_ID"));
				lProgramIncentiveOption.setNewHireDate(rs.getDate("NEW_HIRE_DT"));

				lProgramIncentiveOption.setIncentivePackageRuleGroupID(rs.getInt("INCNTV_OPTN_PKG_RULE_GRP_ID"));
				return lProgramIncentiveOption;
			}

		});
		

		
		return lProgramIncentiveOptions;
	}
	
	/**
	 * 
	 * @param pProgramIncentiveOption
	 * @param pUserID
	 * @return
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int insertProgramIncentiveOption(ProgramIncentiveOption pProgramIncentiveOption, String pUserID) 
	throws DataAccessException
	{
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { pProgramIncentiveOption.getBusinessProgramID()
				, pProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID()
				, pProgramIncentiveOption.getAdditionalInfo(), pProgramIncentiveOption.getIncentiveOptionInfo()
				, pProgramIncentiveOption.getIncentiveOptionStatusCodeID()
				, BPMUtils.getDateFromString(pProgramIncentiveOption.getEffectiveDate())
				, BPMUtils.getDateFromString(pProgramIncentiveOption.getEndDate())
				, BPMUtils.getDateFromString(pProgramIncentiveOption.getActivationDate())
				, BPMUtils.getDateFromString(pProgramIncentiveOption.getDeliveryDate())
				, pProgramIncentiveOption.getFulfillmentRoutingTypeCode()
				, pProgramIncentiveOption.getIncentedStatusTypeCodeID()
				, pProgramIncentiveOption.getParticipantCap()
				, pProgramIncentiveOption.getFamilyCap()
				, pUserID};
		int types[] = new int[] { Types.INTEGER, Types.INTEGER, 
				Types.VARCHAR, Types.VARCHAR, 
				Types.INTEGER, 
				Types.DATE, Types.DATE, Types.DATE, Types.DATE,	
				Types.VARCHAR, // Fulfillment Routing Code
				Types.INTEGER, Types.INTEGER, Types.INTEGER, // Incented Status, Particip, and Family Cap  
				Types.VARCHAR};

		int rowInserted = template.update(insertProgramIncentiveOption, params, types);
		
		return rowInserted;
	}
	
	
	/**
	 * 
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<ActivityIncentive> getActivityIncentives(ActivityEvent activityEvent)
	throws DataAccessException
	{	
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { activityEvent.getActivityEventLogID() };
		int types[] = new int[] { Types.INTEGER };
				
		ArrayList<ActivityIncentive> activityIncentives = (ArrayList<ActivityIncentive>)
		    template.query(selectIncentiveForActivity, params, types, new incentiveForActivityMapper());
		
		Collection<ActivityIncentive> activityIncentivesOutsideEnrollment = getActivityIncentivesOutsideEnrollment(activityEvent);
		
		//EV58500
		if (activityIncentivesOutsideEnrollment.size() > 0) {
			activityIncentives.addAll(activityIncentivesOutsideEnrollment);
		}
		
		
		for(int i = 0; i < activityIncentives.size(); i++)
		{
			activityIncentives.get(i).setIncentiveParticipants((ArrayList<IncentiveParticipant>)
					getIncentiveParticipants(activityIncentives.get(i).getActivityIncentiveID()));
		}

		return activityIncentives;
	}


	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<ActivityIncentive> getIncentiveCheckmarkForActivity(ActivityEvent activityEvent)
	throws DataAccessException
	{
		final ArrayList <ActivityIncentive> lActivityIncentives = new ArrayList<ActivityIncentive>();
		
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { activityEvent.getActivityEventLogID()  };
		int types[] = new int[] { Types.INTEGER };
				
		template.query(selectIncentiveCheckmarkForActivity, params, types, new RowCallbackHandler() 
		{
			public void processRow(ResultSet rs) throws SQLException 
			{					
				ActivityIncentive lActivityIncentive = new ActivityIncentive();															
				
				lActivityIncentive.setIncentiveOptionID(rs.getInt("INCNTV_OPTN_ID"));				
				lActivityIncentive.setBusinessProgramID(rs.getInt("BIZ_PGM_ID"));
				lActivityIncentive.setActivityID(rs.getInt("ACTV_ID"));
				lActivityIncentive.setActivityTypeID(rs.getInt("ACTV_TP_CD_ID"));
	            lActivityIncentive.setParticipantCap(rs.getInt("particip_cap"));
				lActivityIncentive.setFamilyCap(rs.getInt("family_cap"));	            
	            lActivityIncentive.setEnrollByDeadlineDate(rs.getDate("enroll_deadline_dt"));
				lActivityIncentive.setCompleteByDeadlineDate(rs.getDate("compl_deadline_dt"));
	            lActivityIncentive.setIncentiveRuleTypeCode(rs.getString("rule_type_code"));
				lActivityIncentive.setIncentedStatusTypeCodeDesc(rs.getString("incented_status_type_code"));
										
				lActivityIncentives.add(lActivityIncentive);								
			}
		});
		
		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
		
		return lActivityIncentives;
	}
			
	
	/**
	 * EV58500 - Method will return activity incentives outside of business program that are considered pre or post enrollment activities taken.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<ActivityIncentive> getActivityIncentivesOutsideEnrollment(ActivityEvent activityEvent)
	throws DataAccessException
	{	
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { activityEvent.getActivityEventLogID() };
		int types[] = new int[] { Types.INTEGER };
				
		ArrayList<ActivityIncentive> activityIncentives = (ArrayList<ActivityIncentive>)
		    template.query(selectIncentiveForActivityOutsideEnrollment, params, types, new incentiveForActivityMapper());
		
		for(int i = 0; i < activityIncentives.size(); i++)
		{
			activityIncentives.get(i).setIncentiveParticipants((ArrayList<IncentiveParticipant>)
					getIncentiveParticipants(activityIncentives.get(i).getActivityIncentiveID()));
		}

		return activityIncentives;
	}
	

	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<ActivityIncentive> getActivityIncentives(Integer pBusinessProgramID
			, Integer pIncentiveOptionID
			, Integer pRequirementID)
	throws DataAccessException
	{	
		StringBuffer lQuery = new StringBuffer();
		
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { pBusinessProgramID, pIncentiveOptionID, pRequirementID };
		int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.INTEGER };

		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setBizPgmId(pBusinessProgramID);
		namedParameter.setIncentiveId(pIncentiveOptionID);
		namedParameter.setIncentiveReqGroupId(pRequirementID);
				
		lQuery.append(selectActivityIncentive);

		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);
		
		List<ActivityIncentive> activityIncentives = namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters, new activityIncentiveMapper());
		
		for(int i = 0; i < activityIncentives.size(); i++)
		{
			activityIncentives.get(i).setIncentiveParticipants((ArrayList<IncentiveParticipant>)
					getIncentiveParticipants(activityIncentives.get(i).getActivityIncentiveID()));
		}

		return activityIncentives;
	}
	
	/**
	 * 
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<PersonActivityIncentive> getPersonActivityIncentives(Integer pPersonDemographicsID			
			, Integer pBusinessProgramID
			, Integer pActivityIncentiveID
			, Integer pActivityID,
			  String pContractNo)
    throws DataAccessException			
	{
		StringBuffer lQuery = new StringBuffer();
        
        lQuery.append(selectPersonActivityIncentive);

		Map<String, Integer> parameters = new HashMap<String, Integer>();

		parameters.put("bizPgmId", pBusinessProgramID);

        if(pContractNo != null && pContractNo.length() > 0)
		{//get all related activity incentives given contract no
			parameters.put("contractId", Integer.valueOf(pContractNo));
			lQuery.append(" AND baseline.contract_no = :contractId");
		}

		parameters.put("personId", pPersonDemographicsID);
		lQuery.append(" AND pers_inctv.PRSN_DMGRPHCS_ID != :personId");
		
		if(pActivityIncentiveID != null && pActivityIncentiveID.intValue() > 0)
		{
			parameters.put("incentiveId", pActivityIncentiveID);
			lQuery.append(" AND pers_inctv.ACTV_INCNTV_ID = :incentiveId");
	}
		
		if(pActivityID != null && pActivityID.intValue() > 0)
		{
			parameters.put("actvId", pActivityID);
			lQuery.append(" AND pers_inctv.ACTV_ID = :actvId");
		}


		List<PersonActivityIncentive> PersonActivityIncentives = namedParameterJdbcTemplate.query(lQuery.toString(), parameters, new RowMapper()
		{
			@Override
			public PersonActivityIncentive mapRow(ResultSet rs, int i) throws SQLException {
				PersonActivityIncentive lPersonActivityIncentive = new PersonActivityIncentive();

				lPersonActivityIncentive.setBusinessProgramID(rs.getInt("BIZ_PGM_ID"));
				lPersonActivityIncentive.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
				lPersonActivityIncentive.setContractNo(rs.getInt("CONTRACT_NO"));
				lPersonActivityIncentive.setActivityID(rs.getInt("ACTV_ID"));
				lPersonActivityIncentive.setActivityIncentiveID(rs.getInt("ACTV_INCNTV_ID"));
				lPersonActivityIncentive.setActivityStatusCodeID(rs.getInt("ACTV_STAT_CD_ID"));
				lPersonActivityIncentive.setActivityStatusCode(rs.getString("ACTV_STAT_CD"));
				lPersonActivityIncentive.setRegistrationID(rs.getString("REGISTRATION_ID"));
				lPersonActivityIncentive.setIncentiveStatusDate(rs.getDate("ACTV_STAT_INCNTV_DT"));
				lPersonActivityIncentive.setIncentiveQuantity(rs.getInt("INCNTV_QTY"));
				lPersonActivityIncentive.setRelationshipCode(rs.getInt("rel_cd"));
				lPersonActivityIncentive.setIncentiveOptionID(rs.getInt("INCNTV_OPTN_ID"));
				lPersonActivityIncentive.setIncentiveOptionGroupID(rs.getInt("ACTV_INCNTV_GRP_ID"));
				lPersonActivityIncentive.setIncentiveOptionRequirementID(rs.getInt("ACTV_INCNTV_GRP_REQ_ID"));
				lPersonActivityIncentive.setProgramIncentiveOptionID(rs.getInt("BIZ_PGM_INCNTV_OPTN_ID"));
				return lPersonActivityIncentive;
			}

		});
		
		return PersonActivityIncentives;
	}
	
	/**
	 * 
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int updatePersonActivityIncentive(PersonActivityIncentive pPersonActivityIncentive, String pUserID)
	throws DataAccessException 
	{
		ArrayList<PersonActivityIncentive> lPersonActivityIncentives = (ArrayList<PersonActivityIncentive>)
		    getPersonActivityIncentives(pPersonActivityIncentive.getPersonDemographicsID(),			
		    		pPersonActivityIncentive.getBusinessProgramID(),
		    		pPersonActivityIncentive.getActivityIncentiveID(),
		    		pPersonActivityIncentive.getActivityID(),
		    		null);
		
		// If exists update.
		if(lPersonActivityIncentives.size() > 0)
		{
			JdbcTemplate templateUpdate = getJdbcTemplate();
			Object paramsUpdate[] = new Object[] {pPersonActivityIncentive.getActivityStatusCode()
					, pPersonActivityIncentive.getIncentiveStatusDate()					
					, pPersonActivityIncentive.getRegistrationID()					
					, pUserID
					, pPersonActivityIncentive.getBenefitContractType()
					, pPersonActivityIncentive.getPersonDemographicsID()
					, pPersonActivityIncentive.getBusinessProgramID()					
					, pPersonActivityIncentive.getActivityID()
					, pPersonActivityIncentive.getActivityIncentiveID()
					
					};
			int typesUpdate[] = new int[] { Types.VARCHAR, Types.DATE, Types.VARCHAR, Types.VARCHAR,  
					Types.VARCHAR, Types.INTEGER,
					Types.INTEGER, Types.INTEGER, Types.VARCHAR};
			
			return templateUpdate.update(updatePersonActivityIncentive, paramsUpdate, typesUpdate);						
		}
				
		// Otherwise insert.
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { pPersonActivityIncentive.getBusinessProgramID()
				, pPersonActivityIncentive.getPersonDemographicsID()
				, pPersonActivityIncentive.getActivityID()
				, pPersonActivityIncentive.getActivityIncentiveID()
				, pPersonActivityIncentive.getActivityStatusCode()
				, pPersonActivityIncentive.getRegistrationID()	
				, pPersonActivityIncentive.getIncentiveStatusDate()
				, pUserID
				, pPersonActivityIncentive.getBenefitContractType()};
		int types[] = new int[] { Types.INTEGER, Types.INTEGER, 
				Types.INTEGER, Types.INTEGER, 
				Types.VARCHAR, 
				Types.VARCHAR, 
				Types.DATE,
				Types.VARCHAR,
				Types.VARCHAR};

		int rowInserted = template.update(insertIntoPersonActivityIncentive, params, types);
		
		return rowInserted;					
	}
	
	/**
	 * 
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int updatePersonActivityIncentiveWithContributionAmt(ActivityEvent lActivityEvent, String pUserID)
	throws DataAccessException 
	{
		
			JdbcTemplate templateUpdate = getJdbcTemplate();
			Object paramsUpdate[] = new Object[] {lActivityEvent.getMemberActivity().getContributionAmt(),	
					pUserID,
		    		lActivityEvent.getPersonDemographicsID(),
		    		lActivityEvent.getMemberActivity().getBusinessProgramID(),
		    		lActivityEvent.getMemberActivity().getActivity().getActivityID(),
		    		lActivityEvent.getMemberActivity().getRegistrationID()
					};
			int typesUpdate[] = new int[] { Types.INTEGER, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.VARCHAR };  
					
			
		return templateUpdate.update(updatePersonActivityIncentiveWithContributionAmt, paramsUpdate, typesUpdate);						
	}
	
	/**
	 * 
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int updatePersonActivityIncentiveWithModificationDate(PersonActivityIncentToFulfillReconcile lPersonActivityIncentToFulfillReconcileDifference, String pUserID)
	throws DataAccessException 
	{
		
			JdbcTemplate templateUpdate = getJdbcTemplate();
			Object paramsUpdate[] = new Object[] {	
					pUserID,
					lPersonActivityIncentToFulfillReconcileDifference.getPersonDemographicsID(),
					lPersonActivityIncentToFulfillReconcileDifference.getProgramID(),
					lPersonActivityIncentToFulfillReconcileDifference.getActivityID(),
					lPersonActivityIncentToFulfillReconcileDifference.getRegistrationID()
					};
			int typesUpdate[] = new int[] { Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.VARCHAR };  
					
			
		return templateUpdate.update(updatePersonActivityIncentiveWithModificationDate, paramsUpdate, typesUpdate);						
	}
	
	/**
	 * 
	 * @param pActivityIncentiveID
	 * @return
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<IncentiveParticipant> getIncentiveParticipants(Integer pActivityIncentiveID)
	throws DataAccessException
	{
		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setActvId(pActivityIncentiveID);
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<IncentiveParticipant> lIncentiveParticipants = namedParameterJdbcTemplate.query(selectIncentiveParticipant, namedParameters, new RowMapper()
		{
			@Override
			public IncentiveParticipant mapRow(ResultSet rs, int i) throws SQLException {
				IncentiveParticipant lIncentiveParticipant = new IncentiveParticipant();

				lIncentiveParticipant.setActivityIncentiveID(rs.getInt("ACTV_INCNTV_ID"));
				lIncentiveParticipant.setRelationshipCode(rs.getInt("REL_CD"));
				lIncentiveParticipant.setMaximumQuantity(rs.getInt("MAX_QTY"));
				return lIncentiveParticipant;
			}

		});
		
		return lIncentiveParticipants;
	}
	
	/**
	 * 
	 * @return
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<IncentiveRequirement> getIncentiveOptionRequirements(Integer pProgramID, Integer pIncentiveOptionID)
	throws DataAccessException
	{

		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setBizPgmId(pProgramID);
		namedParameter.setIncentiveId(pIncentiveOptionID);
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);


		List<IncentiveRequirement> lIncentiveRequirements = namedParameterJdbcTemplate.query(selectIncentiveRequirements, namedParameters, new RowMapper()
		{
			@Override
			public IncentiveRequirement mapRow(ResultSet rs, int i) throws SQLException {
				IncentiveRequirement lIncentiveRequirement = new IncentiveRequirement();

				lIncentiveRequirement.setProgramID(rs.getInt("BIZ_PGM_ID"));
				lIncentiveRequirement.setIncentiveOptionID(rs.getInt("INCNTV_OPTN_ID"));
				lIncentiveRequirement.setActivityIncentiveGroupID(rs.getInt("ACTV_INCNTV_GRP_ID"));
				lIncentiveRequirement.setActivityIncentiveGroupReqID(rs.getInt("ACTV_INCNTV_GRP_REQ_ID"));
				lIncentiveRequirement.setRequiredQuantity(rs.getInt("REQRD_QTY"));
				return lIncentiveRequirement;
			}


		});
		
		for(int i = 0; i < lIncentiveRequirements.size(); i++)
		{
			lIncentiveRequirements.get(i).setActivityIncentives((ArrayList<ActivityIncentive>)
			getActivityIncentives(lIncentiveRequirements.get(i).getProgramID()
					, lIncentiveRequirements.get(i).getIncentiveOptionID()
					, lIncentiveRequirements.get(i).getActivityIncentiveGroupReqID()));

			ArrayList<ActivityIncentive> lActivityIncentives = lIncentiveRequirements.get(i).getActivityIncentives();
			
			for(ActivityIncentive lActivityIncentive : lActivityIncentives)
			{
				lActivityIncentive.getActivityCollection()
				    .setCollectionActivities(getCollectionActivities(lActivityIncentive.getActivityCollection().getCollectionID()));
			}
		}
		
		return lIncentiveRequirements;
	}
	
	/**transactionManager = "DataSourceTransactionManager",
	 * 
	 * @param pCollectionID
	 * @return
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public List<ActivityDefinition> getCollectionActivities(Integer pCollectionID)
	{
		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setCollectionId(pCollectionID);

		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<ActivityDefinition> lCollectionActivities = namedParameterJdbcTemplate.query(selectCollectionActivities, namedParameters, new RowMapper()
		{
			@Override
			public ActivityDefinition mapRow(ResultSet rs, int i) throws SQLException {
				ActivityDefinition lActivityDefinition = new ActivityDefinition();

				lActivityDefinition.setActivityID(rs.getInt("ACTV_ID"));
				lActivityDefinition.setSourceActivityID(rs.getString("srce_actv_id"));
				return lActivityDefinition;
			}

		});
		
		return lCollectionActivities;
	}
	
	/**
	 * 
	 * @param pIncentiveRequirement
	 * @param pUserID
	 * @return
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int insertIncentiveRequirement(IncentiveRequirement pIncentiveRequirement, String pUserID)
	throws DataAccessException
	{
		JdbcTemplate template = getJdbcTemplate();
		
		int incentiveRequirementID = incentiveRequirementIdIncrementer.nextIntValue();
		
		Object params[] = new Object[] { incentiveRequirementID  
				, pIncentiveRequirement.getActivityIncentiveGroupReqID() 
				, pIncentiveRequirement.getIncentiveOptionID()
				, pIncentiveRequirement.getProgramID()
				, pIncentiveRequirement.getRequiredQuantity()				
				, pUserID};
		int types[] = new int[] { Types.INTEGER, Types.INTEGER, 
				Types.INTEGER, Types.INTEGER, Types.INTEGER,
				Types.VARCHAR};

		int rowInserted = template.update(insertIncentiveRequirement, params, types);
		
		return incentiveRequirementID;
	}
	
	/**
	 * 
	 * @param pActivityIncentive
	 * @param pUserID
	 * @return
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int insertActivityIncentive(ActivityIncentive pActivityIncentive, String pUserID)
	throws DataAccessException
	{
        JdbcTemplate template = getJdbcTemplate();
		
		int activityIncentiveID = activityIncentiveIdIncrementer.nextIntValue();
		
		Object params[] = new Object[] { activityIncentiveID
				, pActivityIncentive.getActivityIncentiveGroupID()
				, pActivityIncentive.getActivityIncentiveGroupReqID() 
				, pActivityIncentive.getIncentiveOptionID()
				, pActivityIncentive.getBusinessProgramID()
				, pActivityIncentive.getActivityID()
				, pActivityIncentive.getActivityTypeID()
				, pActivityIncentive.getActivityIncentiveTypeID()
				, pActivityIncentive.getIncentedStatusTypeID()
				, pActivityIncentive.getIncentiveQuantity()
				, pUserID};
		int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, 
				Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, 
				Types.VARCHAR};

		int rowInserted = template.update(insertActivityIncentive, params, types);
		
		return activityIncentiveID;
	}
	
	/**
	 * 
	 * @param pIncentiveParticipant
	 * @param pUserID
	 * @return
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int insertIncentiveParticipant(IncentiveParticipant pIncentiveParticipant, String pUserID)
	throws DataAccessException
	{
		JdbcTemplate template = getJdbcTemplate();
		
		Object params[] = new Object[] { pIncentiveParticipant.getActivityIncentiveID()
				, pIncentiveParticipant.getRelationshipCode()
				, pIncentiveParticipant.getMaximumQuantity()
				, pUserID};
		int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.INTEGER,  
				Types.VARCHAR};
		
        int rowInserted = template.update(insertIncentiveParticipant, params, types);
		
		return rowInserted;
	}
	
	
	
	
	private static final class activityIncentiveMapper implements RowMapper 
	{
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException 
		{
			ActivityIncentive lActivityIncentive = new ActivityIncentive();
			
			lActivityIncentive.setActivityIncentiveID(rs.getInt("ACTV_INCNTV_ID"));
			lActivityIncentive.setActivityIncentiveGroupID(rs.getInt("ACTV_INCNTV_GRP_ID"));
			lActivityIncentive.setActivityIncentiveGroupReqID(rs.getInt("ACTV_INCNTV_GRP_REQ_ID"));
			lActivityIncentive.setIncentiveOptionID(rs.getInt("INCNTV_OPTN_ID"));
			lActivityIncentive.setBusinessProgramID(rs.getInt("BIZ_PGM_ID"));
			lActivityIncentive.setActivityID(rs.getInt("ACTV_ID"));
			lActivityIncentive.setActivityTypeID(rs.getInt("ACTV_TP_CD_ID"));
			lActivityIncentive.setActivityIncentiveTypeID(rs.getInt("ACTV_INCNTV_TP_CD_ID"));
			lActivityIncentive.setIncentedStatusTypeID(rs.getInt("INCNTD_STS_TP_CD_ID"));
			lActivityIncentive.setIncentedStatusTypeCode(rs.getString("INCNTD_STS_TP_CD"));
			lActivityIncentive.setIncentiveQuantity(rs.getInt("INCNTV_QTY"));
			lActivityIncentive.setParticipantCap(rs.getInt("particip_cap"));
			lActivityIncentive.setFamilyCap(rs.getInt("family_cap"));
			lActivityIncentive.setCompleteByDeadlineDate(rs.getDate("compl_deadline_dt"));
			lActivityIncentive.setEnrollByDeadlineDate(rs.getDate("enroll_deadline_dt"));
			lActivityIncentive.setIncentiveRuleTypeCode(rs.getString("incentive_rule_type_code"));
			lActivityIncentive.setEffectiveDate(rs.getDate("incntv_optn_eff_dt"));
			lActivityIncentive.setEndDate(rs.getDate("incntv_optn_end_dt"));
			
			ActivityCollection lActivityCollection = new ActivityCollection();
			
			lActivityCollection.setCollectionID(rs.getInt("COLLECTION_ID"));
			lActivityCollection.setRequiredQuantity(rs.getInt("REQRD_QTY"));
			
			lActivityIncentive.setActivityCollection(lActivityCollection);
			
			
			return lActivityIncentive;
		}
	}
	
	private static final class incentiveForActivityMapper implements RowMapper 
	{
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException 
		{
			ActivityIncentive lActivityIncentive = new ActivityIncentive();
			
			lActivityIncentive.setActivityIncentiveID(rs.getInt("ACTV_INCNTV_ID"));
			lActivityIncentive.setActivityIncentiveGroupID(rs.getInt("ACTV_INCNTV_GRP_ID"));
			lActivityIncentive.setActivityIncentiveGroupReqID(rs.getInt("ACTV_INCNTV_GRP_REQ_ID"));
			lActivityIncentive.setIncentiveOptionID(rs.getInt("INCNTV_OPTN_ID"));
			lActivityIncentive.setBusinessProgramID(rs.getInt("BIZ_PGM_ID"));
			lActivityIncentive.setActivityID(rs.getInt("ACTV_ID"));
			lActivityIncentive.setActivityTypeID(rs.getInt("ACTV_TP_CD_ID"));
			lActivityIncentive.setActivityIncentiveTypeID(rs.getInt("ACTV_INCNTV_TP_CD_ID"));
			lActivityIncentive.setIncentedStatusTypeID(rs.getInt("INCNTD_STS_TP_CD_ID"));
			lActivityIncentive.setIncentedStatusTypeCode(rs.getString("INCNTD_STS_TP_CD"));
			lActivityIncentive.setIncentiveQuantity(rs.getInt("INCNTV_QTY"));
			lActivityIncentive.setParticipantCap(rs.getInt("particip_cap"));
			lActivityIncentive.setFamilyCap(rs.getInt("family_cap"));
			lActivityIncentive.setEnrollByDeadlineDate(rs.getDate("enroll_deadline_dt"));
			lActivityIncentive.setCompleteByDeadlineDate(rs.getDate("compl_deadline_dt"));
			lActivityIncentive.setIncentiveRuleTypeCode(rs.getString("rule_type_code"));
			lActivityIncentive.setIncentedStatusTypeCodeDesc(rs.getString("incented_status_type_code"));
			
			
			
			return lActivityIncentive;
		}
	}
	
	/**
	 * 
	 * @param pBusinessProgramID
	 * @param pIncentiveOptionID
	 * @param pContractNo
	 * @return
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<ContractProgramIncentiveTO> getContractProgramIncentive(Integer pBusinessProgramID
			, Integer pIncentiveOptionID, Integer pContractNo)
	throws DataAccessException
	{

		ArrayList<Object> lParameters = new ArrayList<Object>();
	    ArrayList<Integer> lTypes = new ArrayList<Integer>();
		
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectContractProgramIncentive);
		NamedParameter namedParameter = new NamedParameter();

		
		if(pBusinessProgramID != null && pBusinessProgramID > 0)
		{
			namedParameter.setBizPgmId(pBusinessProgramID);
		    lQuery.append(" AND BIZ_PGM_ID = :bizPgmId ");
		    lParameters.add(pBusinessProgramID);
	    	lTypes.add(new Integer(Types.INTEGER));
		}
		if(pIncentiveOptionID != null && pIncentiveOptionID > 0)
		{
			namedParameter.setIncentiveId(pIncentiveOptionID);
			lQuery.append(" AND INCNTV_OPTN_ID = :incentiveId ");
			lParameters.add(pIncentiveOptionID);
	    	lTypes.add(new Integer(Types.INTEGER));
		}
		if(pContractNo != null && pContractNo > 0)
		{
			namedParameter.setContractId(pContractNo);
			lQuery.append(" AND CONTRACT_NO = :contractId ");
			lParameters.add(pContractNo);
	    	lTypes.add(new Integer(Types.INTEGER));
		}


		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<ContractProgramIncentiveTO> lContractProgramIncentives = namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters, new RowMapper()
		{
			@Override
			public ContractProgramIncentiveTO mapRow(ResultSet rs, int i) throws SQLException {
				ContractProgramIncentiveTO lContractProgramIncentiveTO = new ContractProgramIncentiveTO();

				lContractProgramIncentiveTO.setContractProgramStatusID(rs.getInt("CNTR_PGM_STAT_ID"));
				lContractProgramIncentiveTO.setBusinessProgramID(rs.getInt("BIZ_PGM_ID"));
				lContractProgramIncentiveTO.setIncentiveOptionID(rs.getInt("INCNTV_OPTN_ID"));
				lContractProgramIncentiveTO.setContractNo(rs.getInt("CONTRACT_NO"));
				lContractProgramIncentiveTO.setContractIncentiveStatusDate(rs.getDate("CNTR_STAT_INCNTV_DT"));
				lContractProgramIncentiveTO.setContractIncentiveStatusCode(rs.getString("lu_val"));
				lContractProgramIncentiveTO.setProgramIncentiveOptionID(rs.getInt("BIZ_PGM_INCNTV_OPTN_ID"));
				return lContractProgramIncentiveTO;
			}

		});
	    
	    if (lContractProgramIncentives != null && lContractProgramIncentives.size() > 0) {
	    	for (ContractProgramIncentiveTO lContractProgramIncentive : lContractProgramIncentives) {
	    		Integer contractProgramStatusID = lContractProgramIncentive.getContractProgramStatusID();
	    		List<IncentiveStatusActivityDetail> lIncentiveStatusActivityDetails = getIncentiveStatusActivityDetails(contractProgramStatusID, null, null);
	    		lContractProgramIncentive.setIncentiveStatusActivityDetails(lIncentiveStatusActivityDetails);
	    	}
	    }
	    
	    return lContractProgramIncentives;
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	
	public List<IncentiveStatusActivityDetail> getIncentiveStatusActivityDetails(Integer contractProgramIncentiveStatusID,
			Integer personProgramActivityStatusID, Integer memberProgramIncentiveStatusID) throws DataAccessException 
	
	{
		
		ArrayList<Object> lParameters = new ArrayList<Object>();
	    ArrayList<Integer> lTypes = new ArrayList<Integer>();
		
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectIncentiveStatusActivityDetails);
		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setContractId(contractProgramIncentiveStatusID);
		
		if(contractProgramIncentiveStatusID != null && contractProgramIncentiveStatusID > 0)
		{
			// contract_pgm_incntv_sts table unique ID.		    		    
		    lQuery.append(" WHERE isad.CNTR_PGM_STAT_ID = :contractId ");
		    lParameters.add(contractProgramIncentiveStatusID);	    	
		    lTypes.add(new Integer(Types.INTEGER));			    		    
		} 
		
		if(memberProgramIncentiveStatusID != null && memberProgramIncentiveStatusID > 0)
		{	
			// pgm_mem_incntv_status table unique ID
			namedParameter.setIncentiveId(memberProgramIncentiveStatusID);
		    lQuery.append(" WHERE isad.PGM_MEM_INCTV_STAT_ID = :incentiveId ");
		    lParameters.add(memberProgramIncentiveStatusID);
	    	lTypes.add(new Integer(Types.INTEGER));	    	
		}
		
		if(personProgramActivityStatusID != null && personProgramActivityStatusID > 0)
		{
			namedParameter.setActvId(personProgramActivityStatusID);
		    lQuery.append("WHERE PRSN_PGM_ACTV_STS_ID = :actvId ");
		    lParameters.add(personProgramActivityStatusID);
	    	lTypes.add(new Integer(Types.INTEGER));	    	
		}
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<IncentiveStatusActivityDetail> lIncentiveStatusActivityDetails = namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters, new RowMapper()
		{
			@Override
			public IncentiveStatusActivityDetail mapRow(ResultSet rs, int i) throws SQLException {
				IncentiveStatusActivityDetail lIncentiveStatusActivityDetail = new IncentiveStatusActivityDetail();

				lIncentiveStatusActivityDetail.setIncentiveStatusActivityDetailID(rs.getInt("INCTV_STS_ACTV_DTL_ID"));
				lIncentiveStatusActivityDetail.setContractProgramIncentiveStatusID(rs.getInt("CNTR_PGM_STAT_ID"));
				lIncentiveStatusActivityDetail.setProgramMemberIncentiveStatusID(rs.getInt("PGM_MEM_INCTV_STAT_ID"));
				lIncentiveStatusActivityDetail.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
				lIncentiveStatusActivityDetail.setActivityStatusIncentiveDate(rs.getDate("ACTV_STAT_INCTV_DT"));
				lIncentiveStatusActivityDetail.setPersonProgramActivityStatusID(rs.getInt("PRSN_PGM_ACTV_STS_ID"));
				lIncentiveStatusActivityDetail.setProgramIncentiveOptionID(rs.getInt("BIZ_PGM_INCNTV_OPTN_ID"));
				return lIncentiveStatusActivityDetail;
			}

		});
	    	    	    
	    
	    if (lIncentiveStatusActivityDetails != null && lIncentiveStatusActivityDetails.size() > 0) {
	    	for (IncentiveStatusActivityDetail lIncentiveStatusActivityDetail : lIncentiveStatusActivityDetails) {
	    		Integer incentiveStatusActivityDetailID = lIncentiveStatusActivityDetail.getIncentiveStatusActivityDetailID();	    			    		
	    		List<IncentiveStatusActivityDetailContribution> lIncentiveStatusActivityDetailContributions = getIncentiveStatusActivityDetailContributions(incentiveStatusActivityDetailID);
	    		lIncentiveStatusActivityDetail.setIncentiveStatusActivityDetailContributions(lIncentiveStatusActivityDetailContributions);
	    		//EV90008 - get PersonProgramActivityIncentiveStatus for corresponding activity detail.
	    		personProgramActivityStatusID = lIncentiveStatusActivityDetail.getPersonProgramActivityStatusID();
	    		PersonProgramActivityStatus lPersonProgramActivityStatus = getPersonProgramActivityStatusByID(personProgramActivityStatusID);
	    		lIncentiveStatusActivityDetail.setPersonProgramActivityStatus(lPersonProgramActivityStatus);
	    	}
	    }
	    
	    
	    
	    return lIncentiveStatusActivityDetails;
		
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
public List<IncentiveStatusActivityDetailContribution> getIncentiveStatusActivityDetailContributions(Integer incentiveStatusActivityDetailID) {

		JdbcTemplate template = getJdbcTemplate();
		ArrayList<Object> lParameters = new ArrayList<Object>();
	    ArrayList<Integer> lTypes = new ArrayList<Integer>();
		
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectIncentiveStatusActivityDetailContributions);					
		
		lParameters.add(incentiveStatusActivityDetailID);
	    lTypes.add(new Integer(Types.INTEGER));

	    NamedParameter namedParameter = new NamedParameter();
	    namedParameter.setIncentiveId(incentiveStatusActivityDetailID);

		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<IncentiveStatusActivityDetailContribution> lIncentiveStatusActivityDetailContributions = namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters, new RowMapper()
		{
			@Override
			public IncentiveStatusActivityDetailContribution mapRow(ResultSet rs, int i) throws SQLException {

				IncentiveStatusActivityDetailContribution lIncentiveStatusActivityDetailContribution = new IncentiveStatusActivityDetailContribution();

				lIncentiveStatusActivityDetailContribution.setIncentiveStatusActivityDetailContribID(rs.getInt("INCTV_STS_ACTV_DTL_CNTRB_ID"));
				lIncentiveStatusActivityDetailContribution.setIncentiveStatusActivityDetailID(rs.getInt("INCTV_STS_ACTV_DTL_ID"));
				lIncentiveStatusActivityDetailContribution.setBenefitContractTypeID(rs.getInt("BEN_CONTR_TP_LU_ID"));
				lIncentiveStatusActivityDetailContribution.setContributionAmount(rs.getInt("CONTRIB_AMT"));
				lIncentiveStatusActivityDetailContribution.setContributionGridID(rs.getInt("CONTRIB_GRID_ID"));

				return lIncentiveStatusActivityDetailContribution;
			}

		});
	    
	    return lIncentiveStatusActivityDetailContributions;
		
	}

	/**
	 * 
	 * @param personProgramActivityStatusID
	 * @return
	 * @throws DataAccessException
	 */
	private PersonProgramActivityStatus getPersonProgramActivityStatusByID(Integer personProgramActivityStatusID)
			throws DataAccessException {

		StringBuffer lQuery = new StringBuffer();
		Object params[] = null;
		int types[] = null;
		lQuery.append(selectPersonProgramActivityStatusByID);

		
		JdbcTemplate template = getJdbcTemplate();
		
		params = new Object[] { personProgramActivityStatusID};
		types = new int[] { Types.INTEGER};
		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setPersonId(personProgramActivityStatusID);
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<PersonProgramActivityStatus> lPersonProgramActivityStatuses = namedParameterJdbcTemplate.query(lQuery
				.toString(), namedParameters, new PersonProgramActivityStatusRowMapper());
		
		
		PersonProgramActivityStatus dto = null;
		if (lPersonProgramActivityStatuses.size() > 0) {
			dto = (PersonProgramActivityStatus) lPersonProgramActivityStatuses.get(0);
		}
		
		return dto;
	}
	
	private static final class PersonProgramActivityStatusRowMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			PersonProgramActivityStatus lPersonProgramActivityStatus = new PersonProgramActivityStatus();
			lPersonProgramActivityStatus.setActivityID(rs.getInt("prsn_id")); 
			lPersonProgramActivityStatus.setActivityStatusCodeID(rs.getInt("actv_stat_cd_id"));
			lPersonProgramActivityStatus.setActivityStatusDate(rs.getDate("actv_stat_dt"));
			lPersonProgramActivityStatus.setActivityID(rs.getInt("actv_id"));
			lPersonProgramActivityStatus.setAuthCode(rs.getString("auth_cd"));
			lPersonProgramActivityStatus.setActivityStatusOutcomeID(rs.getInt("actv_stat_outcm_id"));
			lPersonProgramActivityStatus.setProgramID(rs.getInt("biz_pgm_id"));
			lPersonProgramActivityStatus.setStatusOutcome(rs.getString("stat_outcm"));
			lPersonProgramActivityStatus.setRegistrationID(rs.getString("registration_id"));
			lPersonProgramActivityStatus.setPersonDemographicsID(rs.getInt("prsn_dmgrphcs_id"));
			lPersonProgramActivityStatus.setCollectionID(rs.getInt("collection_id"));
			return lPersonProgramActivityStatus;

		}
		
	}

	
	/**
	 * 
	 * @return
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public long updateContractProgramIncentive(ContractProgramIncentiveTO pContractProgramIncentiveTO)
	throws DataAccessException
	{
		ArrayList<ContractProgramIncentiveTO> lContractProgramIncentives = (ArrayList<ContractProgramIncentiveTO>) 
		getContractProgramIncentive(pContractProgramIncentiveTO.getBusinessProgramID(),
				pContractProgramIncentiveTO.getIncentiveOptionID(), pContractProgramIncentiveTO.getContractNo());

		if(lContractProgramIncentives.size() <= 0)
		{
			return insertContractProgramIncentive(pContractProgramIncentiveTO);
		}
		
		JdbcTemplate template = getJdbcTemplate();

		Object params[] = new Object[] { 
				pContractProgramIncentiveTO.getContractIncentiveStatusCode(),
				BPMConstants.BPM_USER_SYSTEM,
				pContractProgramIncentiveTO.getActivationStatusCode(),
				pContractProgramIncentiveTO.getBusinessProgramID(),
				pContractProgramIncentiveTO.getIncentiveOptionID(),
				pContractProgramIncentiveTO.getContractNo()
				, pContractProgramIncentiveTO.getProgramIncentiveOptionID()
				 };
		int types[] = new int[] { Types.VARCHAR,  Types.VARCHAR, Types.VARCHAR, 
				Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER
				};	
		
		int rowCt = template.update(updateContractProgramIncentive, params, types);		
		
		//EV84334
		if (rowCt > 0 
				&& pContractProgramIncentiveTO.getContractIncentiveStatusCode().equals(BPMConstants.BPM_CONTRACT_INCENTIVE_ACHIEVED)
				//EV101935
					&& pContractProgramIncentiveTO.getActivationStatusCode().equals(BPMConstants.BPM_MEMBER_ACTIVATION_INCENTIVE_STATUS)) {
			Integer contractProgramIncentiveID = pContractProgramIncentiveTO.getContractProgramStatusID();
			List<IncentiveStatusActivityDetail> lIncentiveStatusActivityDetails  = pContractProgramIncentiveTO.getIncentiveStatusActivityDetails();
			for (IncentiveStatusActivityDetail lIncentiveStatusActivityDetail : lIncentiveStatusActivityDetails) {
				if (lIncentiveStatusActivityDetail != null) {
					Integer personProgramActivityStatusID = lIncentiveStatusActivityDetail.getPersonProgramActivityStatusID();
					List<IncentiveStatusActivityDetail> llIncentiveStatusActivityDetails =  getIncentiveStatusActivityDetails(null, personProgramActivityStatusID, null);
					if (llIncentiveStatusActivityDetails == null || llIncentiveStatusActivityDetails.size() == 0) {
						lIncentiveStatusActivityDetail.setContractProgramIncentiveStatusID(contractProgramIncentiveID);
						insertIncentiveStatusActivityDetail(lIncentiveStatusActivityDetail);
					}
				}
			}
		}
		
		return rowCt;
	}
	
	/**
	 * 
	 * @param pContractProgramIncentiveTO
	 * @return
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public long insertContractProgramIncentive(ContractProgramIncentiveTO pContractProgramIncentiveTO)
	throws DataAccessException
	{
		JdbcTemplate template = getJdbcTemplate();
		int contractIncentiveID = contractIncentiveIdIncrementer.nextIntValue();
		
		Object params[] = new Object[] {
				contractIncentiveID,
				pContractProgramIncentiveTO.getBusinessProgramID(),
				pContractProgramIncentiveTO.getIncentiveOptionID(),
				pContractProgramIncentiveTO.getContractNo(),
				pContractProgramIncentiveTO.getContractIncentiveStatusCode(),
				BPMConstants.BPM_USER_SYSTEM,
				pContractProgramIncentiveTO.getProgramIncentiveOptionID()
				, pContractProgramIncentiveTO.getActivationStatusCode() 
				 };
		int types[] = new int[] { 
				Types.INTEGER, 
				Types.INTEGER, 
				Types.INTEGER,
				Types.VARCHAR,
				Types.VARCHAR, 
				Types.VARCHAR,
				Types.INTEGER, 
				Types.VARCHAR
				};	
		int rowCt =  template.update(insertContractProgramIncentive, params, types);
		
		return rowCt;
	}
	
	/**
	 * 
	 * @param pMemberProgramIncentiveTO
	 * @return
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public long insertMemberProgramIncentive(MemberProgramIncentiveTO pMemberProgramIncentiveTO)
	throws DataAccessException
	{
		JdbcTemplate template = getJdbcTemplate();
		
		int memberIncentiveID = memberIncentiveIdIncrementer.nextIntValue();

		Object params[] = new Object[] {
				memberIncentiveID,
				pMemberProgramIncentiveTO.getBusinessProgramID(),
				pMemberProgramIncentiveTO.getIncentiveOptionID(),
				pMemberProgramIncentiveTO.getPersonDemographicsID(),
				pMemberProgramIncentiveTO.getContractNo(),				
				pMemberProgramIncentiveTO.getQualificationCheckmarkID(),
				pMemberProgramIncentiveTO.getMemberIncentiveStatusCode(),				
				BPMConstants.BPM_USER_SYSTEM, 
				pMemberProgramIncentiveTO.getProgramIncentiveOptionID()
				, pMemberProgramIncentiveTO.getActivationStatusCode()
				 };
		int types[] = new int[] {Types.INTEGER,  
				Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER,
				Types.VARCHAR,  
				Types.VARCHAR,  
				Types.INTEGER,
				Types.VARCHAR
				};	
		
		return template.update(insertMemberProgramIncentive, params, types);
	
	}
	
	/**
	 * 
	 * @param lIncentiveStatusActivityDetail
	 * @return
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public long insertIncentiveStatusActivityDetail(IncentiveStatusActivityDetail lIncentiveStatusActivityDetail)
	throws DataAccessException
	{
		JdbcTemplate template = getJdbcTemplate();
		
		int incentiveStatusActivityDetailID = incentiveStatusActivityDetailIdIncrementer.nextIntValue();

		Object params[] = new Object[] {
				incentiveStatusActivityDetailID,
				lIncentiveStatusActivityDetail.getContractProgramIncentiveStatusID(),
				lIncentiveStatusActivityDetail.getProgramMemberIncentiveStatusID(),
				lIncentiveStatusActivityDetail.getPersonDemographicsID(),
				BPMConstants.BPM_USER_SYSTEM,
				lIncentiveStatusActivityDetail.getPersonProgramActivityStatusID()
				 };
		int types[] = new int[] {
				Types.INTEGER, // incentiveStatusActivityDetailID
				Types.INTEGER, // ContractProgramIncentiveStatusID 
				Types.INTEGER, // ProgramMemberIncentiveStatusID 
				Types.INTEGER, // PersonDemographicsID
				Types.VARCHAR, // BPM_USER_SYSTEM
				Types.INTEGER  // PersonProgramActivityStatusID
				};	
		
		System.out.println("insertIncentiveStatusActivityDetail " + " " +
				incentiveStatusActivityDetailID + " " + 
				lIncentiveStatusActivityDetail.getContractProgramIncentiveStatusID() + " " +
				lIncentiveStatusActivityDetail.getProgramMemberIncentiveStatusID() + " " +
				lIncentiveStatusActivityDetail.getPersonDemographicsID() + " " +				
				lIncentiveStatusActivityDetail.getPersonProgramActivityStatusID()
				);
		
		int rowCt = template.update(insertIncentiveStatusActivityDetail, params, types);
		
		//EV84334
		if (rowCt > 0) {
			List<IncentiveStatusActivityDetailContribution> lIncentiveStatusActivityDetailContributions = lIncentiveStatusActivityDetail.getIncentiveStatusActivityDetailContributions();
			for (IncentiveStatusActivityDetailContribution lIncentiveStatusActivityDetailContribution : lIncentiveStatusActivityDetailContributions)
			{
				lIncentiveStatusActivityDetailContribution.setIncentiveStatusActivityDetailID(incentiveStatusActivityDetailID);
				insertIncentiveStatusActivityDetailContribution(lIncentiveStatusActivityDetailContribution);
			}
		}
		
		return rowCt;
	}

	/**
	 * 
	 * @param lIncentiveStatusActivityDetailContribution
	 * @return
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public long insertIncentiveStatusActivityDetailContribution(IncentiveStatusActivityDetailContribution lIncentiveStatusActivityDetailContribution)
	throws DataAccessException
	{
		JdbcTemplate template = getJdbcTemplate();
	
		Object params[] = new Object[] {
				lIncentiveStatusActivityDetailContribution.getIncentiveStatusActivityDetailID(),
				lIncentiveStatusActivityDetailContribution.getBenefitContractTypeID(),
				lIncentiveStatusActivityDetailContribution.getContributionAmount(),
				lIncentiveStatusActivityDetailContribution.getContributionGridID(),								
				BPMConstants.BPM_USER_SYSTEM
				 };
		int types[] = new int[] {
				Types.INTEGER,  
				Types.INTEGER,  
				Types.INTEGER,  
				Types.INTEGER,
				Types.VARCHAR
				};	
		
		return template.update(insertIncentiveStatusActivityDetailContribution, params, types);
		
}
	

	/**
	 * 
	 * @param pMemberProgramIncentiveTO
	 * @return
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public long updateMemberProgramIncentive(MemberProgramIncentiveTO pMemberProgramIncentiveTO)
	throws DataAccessException
	{
		ArrayList<MemberProgramIncentiveTO> lMemberProgramIncentives = (ArrayList<MemberProgramIncentiveTO>) 
		getMemberProgramIncentive(pMemberProgramIncentiveTO.getBusinessProgramID()
				, pMemberProgramIncentiveTO.getIncentiveOptionID()
				, pMemberProgramIncentiveTO.getContractNo()
				, pMemberProgramIncentiveTO.getPersonDemographicsID());
		

		if(lMemberProgramIncentives.size() <= 0)
		{
			return insertMemberProgramIncentive(pMemberProgramIncentiveTO);
		}
		
		JdbcTemplate template = getJdbcTemplate();

		Object params[] = new Object[] { pMemberProgramIncentiveTO.getMemberIncentiveStatusCode(),
				pMemberProgramIncentiveTO.getQualificationCheckmarkID(),
				BPMConstants.BPM_USER_SYSTEM,
				pMemberProgramIncentiveTO.getActivationStatusCode(),
				pMemberProgramIncentiveTO.getBusinessProgramID(),
				pMemberProgramIncentiveTO.getIncentiveOptionID(),
				pMemberProgramIncentiveTO.getContractNo(),
				pMemberProgramIncentiveTO.getPersonDemographicsID(),				
				 };
		int types[] = new int[] { Types.VARCHAR, Types.INTEGER, Types.VARCHAR, Types.VARCHAR,
				Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER
				};	
		
		int rowCt = template.update(updateMemberProgramIncentive, params, types);	
		
		//EV84334
		if (rowCt > 0 
				&& pMemberProgramIncentiveTO.getMemberIncentiveStatusCode().equals(BPMConstants.BPM_CONTRACT_INCENTIVE_ACHIEVED) 
				//EV101935
					&& pMemberProgramIncentiveTO.getActivationStatusCode().equals(BPMConstants.BPM_MEMBER_ACTIVATION_INCENTIVE_STATUS)) {
			Collection<IncentiveStatusActivityDetail> lIncentiveStatusActivityDetails = pMemberProgramIncentiveTO.getIncentiveStatusActivityDetails();
			Integer memberProgramIncentiveID = pMemberProgramIncentiveTO.getMemberProgramIncentiveID();
			if (lIncentiveStatusActivityDetails != null) {
				for (IncentiveStatusActivityDetail lIncentiveStatusActivityDetail : lIncentiveStatusActivityDetails) {
					if (lIncentiveStatusActivityDetail != null) {
						Integer personProgramActivityStatusID = lIncentiveStatusActivityDetail.getPersonProgramActivityStatusID();
						List<IncentiveStatusActivityDetail> llIncentiveStatusActivityDetails =  getIncentiveStatusActivityDetails(null, personProgramActivityStatusID, null);
						if (llIncentiveStatusActivityDetails == null || llIncentiveStatusActivityDetails.size() == 0) {
							lIncentiveStatusActivityDetail.setProgramMemberIncentiveStatusID(memberProgramIncentiveID);
							insertIncentiveStatusActivityDetail(lIncentiveStatusActivityDetail);
						}
					}
				}
			}
		}
		
		return rowCt;
	}
	
	
	/**
	 * 
	 * @param pMemberProgramIncentiveTO
	 * @return
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public long deleteMemberProgramIncentive(MemberProgramIncentiveTO pMemberProgramIncentiveTO)
	throws DataAccessException
	{		
		JdbcTemplate template = getJdbcTemplate();

		Object params[] = new Object[] {
				pMemberProgramIncentiveTO.getPersonDemographicsID(),
				pMemberProgramIncentiveTO.getBusinessProgramID(),								
				 };
		int types[] = new int[] { Types.INTEGER, Types.INTEGER };	
		
		return template.update(deleteMemberProgramIncentive, params, types);				
	}
	
	/**
	 * 
	 * @param pPersonDemographicsID
	 * @param pProgramID
	 * @return
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public long deleteMemberProgramIncentive(Integer pPersonDemographicsID, Integer pProgramID)
	throws DataAccessException
	{		
		JdbcTemplate template = getJdbcTemplate();

		Object params[] = new Object[] {
				pPersonDemographicsID,
				pProgramID,							
				 };
		int types[] = new int[] { Types.INTEGER, Types.INTEGER };	
		
		return template.update(deleteMemberProgramIncentive, params, types);				
	}
	
	/**
	 * 
	 * @param pContractNo
	 * @param pProgramID
	 * @return
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public long deleteContractProgramIncentive(Integer pContractNo, Integer pProgramID)
	throws DataAccessException
	{		
		JdbcTemplate template = getJdbcTemplate();

		Object params[] = new Object[] {
				pContractNo,
				pProgramID,							
				 };
		int types[] = new int[] { Types.INTEGER, Types.INTEGER };	
		
		return template.update(deleteContractProgramIncentive, params, types);				
	}
	
	/**
	 * 
	 * @param pBusinessProgramID
	 * @param pIncentiveOptionID
	 * @param pContractNo
	 * @param pPersonDemographicsID
	 * @return
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<MemberProgramIncentiveTO> getMemberProgramIncentive(Integer pBusinessProgramID
			, Integer pIncentiveOptionID
			, Integer pContractNo
			, Integer pPersonDemographicsID)
	throws DataAccessException
	{

		ArrayList<Object> lParameters = new ArrayList<Object>();
	    ArrayList<Integer> lTypes = new ArrayList<Integer>();
		
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectMemberProgramIncentive);					

		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setBizPgmId(pBusinessProgramID);
		namedParameter.setContractId(pContractNo);
		
	    lParameters.add(pBusinessProgramID);
	    lParameters.add(pContractNo);
	    	    
    	lTypes.add(new Integer(Types.INTEGER));
    	lTypes.add(new Integer(Types.INTEGER));
    	
		if (pIncentiveOptionID != null) {
			namedParameter.setIncentiveId(pIncentiveOptionID);
    		lQuery.append(" AND INCNTV_OPTN_ID = :incentiveId");
    		lParameters.add(pIncentiveOptionID);
    		lTypes.add(new Integer(Types.INTEGER));	
    		
    	}
    	if (pPersonDemographicsID != null) {
    		namedParameter.setPersonId(pPersonDemographicsID);
    		lQuery.append(" AND PRSN_DMGRPHCS_ID = :personId");
    		lParameters.add(pPersonDemographicsID);
    		lTypes.add(new Integer(Types.INTEGER));	
    		
    	}
    	
    	

		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);


		List<MemberProgramIncentiveTO> lMemberProgramIncentives = namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters, new RowMapper()
		{
			@Override
			public MemberProgramIncentiveTO mapRow(ResultSet rs, int i) throws SQLException {
				MemberProgramIncentiveTO lMemberProgramIncentiveTO = new MemberProgramIncentiveTO();

				lMemberProgramIncentiveTO.setMemberProgramIncentiveID(rs.getInt("PGM_MEM_INCNTV_STAT_ID"));
				lMemberProgramIncentiveTO.setBusinessProgramID(rs.getInt("BIZ_PGM_ID"));
				lMemberProgramIncentiveTO.setIncentiveOptionID(rs.getInt("INCNTV_OPTN_ID"));
				lMemberProgramIncentiveTO.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
				lMemberProgramIncentiveTO.setContractNo(rs.getInt("CONTRACT_NO"));
				lMemberProgramIncentiveTO.setQualificationCheckmarkID(rs.getInt("QUALFCTN_CHKMRK_ID"));
				lMemberProgramIncentiveTO.setMemberIncentiveStatusCode(rs.getString("MBR_STAT_CD"));
				lMemberProgramIncentiveTO.setMemberIncentiveStatusDate(rs.getDate("MBR_STAT_INCNTV_DT"));
				lMemberProgramIncentiveTO.setProgramIncentiveOptionID(rs.getInt("BIZ_PGM_INCNTV_OPTN_ID"));
				return lMemberProgramIncentiveTO;
			}

		});
	    
	    if (lMemberProgramIncentives != null && lMemberProgramIncentives.size() > 0) {
	    	for (MemberProgramIncentiveTO lMemberProgramIncentive : lMemberProgramIncentives) {
	    		Integer memberProgramIncentiveID = lMemberProgramIncentive.getMemberProgramIncentiveID();
	    		List<IncentiveStatusActivityDetail> lIncentiveStatusActivityDetails = getIncentiveStatusActivityDetails(null, null, memberProgramIncentiveID);
	    		lMemberProgramIncentive.setIncentiveStatusActivityDetails(lIncentiveStatusActivityDetails);
	    	}
	    }
	    
	    return lMemberProgramIncentives;
	}


	/*
	 * Determine if business program has an incentive option where an activity completion period was configured.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public boolean isActivityCompletionPeriodEnabled(Integer programID) throws DataAccessException {
		
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { programID };
		int types[] = new int[] { Types.INTEGER };
		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setBizPgmId(programID);
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<Boolean> results = namedParameterJdbcTemplate.query(isActivityCompletionPeriodEnabled, namedParameters,
				new RowMapper() {
					@Override
					public Boolean mapRow(ResultSet rs, int i) throws SQLException {
						if (rs.getInt(1) > 0) {
							Boolean.valueOf(true);
						}
						return Boolean.valueOf(false);
					}

				});


		return results.size() > 0;
	}
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public IncentiveOption getIncentiveOptionDefinitionByName(String incentiveOptionName) throws DataAccessException
	{
	
		final IncentiveOption lIncentiveOption = new IncentiveOption();
		
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { incentiveOptionName };
		int types[] = new int[] { Types.VARCHAR };
		
		
		template.query(selectIncentiveOptionDefinitionByName, params, types, new RowCallbackHandler() 
		{
			public void processRow(ResultSet rs) throws SQLException 
			{					
				
				lIncentiveOption.setIncentiveOptionID(rs.getInt("INCNTV_OPTN_ID"));
				lIncentiveOption.setIncentiveOptionName(rs.getString("INCNTV_OPTN_NM"));
				lIncentiveOption.setIncentiveOptionDesc(rs.getString("INCNTV_OPTN_DESC"));
				lIncentiveOption.setIncentiveOptionTypeCodeID(rs.getInt("INCNTV_OPTN_TP_CD_ID"));
				lIncentiveOption.setIncentiveUnitTypeCodeID(rs.getInt("incntv_unit_tp_cd_id"));
				
			}
		});
		
		return lIncentiveOption;
	}
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<IncentivesAchievedSummaryByIncentiveOption> getContractIncentivesAchievedByProgramIncentiveOptionSummary(String groupNo) throws DataAccessException
	{
	
		final ArrayList<IncentivesAchievedSummaryByIncentiveOption> lContractIncentivesAchievedSummaryByIncentiveOptions = new ArrayList<IncentivesAchievedSummaryByIncentiveOption>();
		
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { groupNo };
		int types[] = new int[] { Types.VARCHAR };
		
		
		template.query(selectContractIncentivesAchievedByProgramIncentiveOptionSummary, params, types, new RowCallbackHandler() 
		{
			public void processRow(ResultSet rs) throws SQLException 
			{					
				IncentivesAchievedSummaryByIncentiveOption lContractIncentivesAchievedSummary = new IncentivesAchievedSummaryByIncentiveOption();
				lContractIncentivesAchievedSummary.setGroupNo(rs.getString("empl_grp_no"));
				lContractIncentivesAchievedSummary.setGroupName(rs.getString("empl_grp_nm"));
				lContractIncentivesAchievedSummary.setEffectiveDate(rs.getDate("eff_dt"));
				lContractIncentivesAchievedSummary.setIncentiveOptionName(rs.getString("incntv_optn_nm"));
				lContractIncentivesAchievedSummary.setContractStatusCodeName(rs.getString("cntr_stat_cd_nm"));
				lContractIncentivesAchievedSummary.setSumTotal(rs.getInt("sumTotal"));
				
				lContractIncentivesAchievedSummaryByIncentiveOptions.add(lContractIncentivesAchievedSummary);
			}
			});
		
		
		
		return lContractIncentivesAchievedSummaryByIncentiveOptions;
	}
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<IncentivesAchievedSummaryByIncentiveOption> getMemberIncentivesAchievedByProgramIncentiveOptionSummary(String groupNo) throws DataAccessException
	{

		final ArrayList<IncentivesAchievedSummaryByIncentiveOption> lMemberIncentivesAchievedSummaryByIncentiveOptions = new ArrayList<IncentivesAchievedSummaryByIncentiveOption>();

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { groupNo };
		int types[] = new int[] { Types.VARCHAR };


		template.query(selectMemberIncentivesAchievedByProgramIncentiveOptionSummary, params, types, new RowCallbackHandler()
		{
			public void processRow(ResultSet rs) throws SQLException
			{
				IncentivesAchievedSummaryByIncentiveOption lMemberIncentivesAchievedSummary = new IncentivesAchievedSummaryByIncentiveOption();
				lMemberIncentivesAchievedSummary.setGroupNo(rs.getString("empl_grp_no"));
				lMemberIncentivesAchievedSummary.setGroupName(rs.getString("empl_grp_nm"));
				lMemberIncentivesAchievedSummary.setEffectiveDate(rs.getDate("eff_dt"));
				lMemberIncentivesAchievedSummary.setIncentiveOptionName(rs.getString("incntv_optn_nm"));
				lMemberIncentivesAchievedSummary.setMemberStatusCodeName(rs.getString("mbr_stat_cd_nm"));
				lMemberIncentivesAchievedSummary.setSumTotal(rs.getInt("sumTotal"));

				lMemberIncentivesAchievedSummaryByIncentiveOptions.add(lMemberIncentivesAchievedSummary);
			}
		});



		return lMemberIncentivesAchievedSummaryByIncentiveOptions;
	}

	
	
	/**
	 * 
	 * @param pProgramID
	 * @param pIncentiveOptionID
	 * @param pContractID
	 * @return
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	
	public int setContractIncentiveAchievedDate(Integer pProgramID, Integer pIncentiveOptionID, Integer pContractID, boolean pSetToNull)
	throws DataAccessException
	{		
		JdbcTemplate template = getJdbcTemplate();

		java.sql.Date lDate = BPMUtils.calendarToSqlDate(Calendar.getInstance());				
		
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(updateContractIncentiveAchievedDate);
		
		if(pSetToNull == true)
		{
			lDate = null;
		}
		else
		{
		    lQuery.append(" AND CNTR_STS_ACHV_DT IS NULL ");
		}
		
		Object params[] = new Object[] { lDate, pProgramID, pIncentiveOptionID, pContractID };
		int types[] = new int[] { Types.DATE, Types.INTEGER, Types.INTEGER, Types.INTEGER };
		
		return template.update(lQuery.toString(), params, types);
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	
	public int setMemberIncentiveAchievedDate(Integer pPersonDemographicsID, Integer pProgramIncentiveOptionID, boolean pSetToNull)  
	throws DataAccessException
	{		
		JdbcTemplate template = getJdbcTemplate();

		java.sql.Date lDate = BPMUtils.calendarToSqlDate(Calendar.getInstance());				
		
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(updateMemberIncentiveAchievedDate);
		
		if(pSetToNull == true)
		{
			lDate = null;
		}
		else
		{
		    lQuery.append(" AND MBR_STAT_ACHV_DT IS NULL ");
		}
				
		Object params[] = new Object[] { lDate, pPersonDemographicsID, pProgramIncentiveOptionID };
		int types[] = new int[] { Types.DATE, Types.INTEGER, Types.INTEGER };
		
		return template.update(lQuery.toString(), params, types);
	}
			
	
	public final String getSelectProgramIncentiveOptions() {
		return selectProgramIncentiveOptions;
	}

	public final void setSelectProgramIncentiveOptions(
			String selectProgramIncentiveOptions) {
		this.selectProgramIncentiveOptions = selectProgramIncentiveOptions;
	}

	public String getInsertProgramIncentiveOption() {
		return insertProgramIncentiveOption;
	}

	public void setInsertProgramIncentiveOption(String insertProgramIncentiveOption) {
		this.insertProgramIncentiveOption = insertProgramIncentiveOption;
	}

	public String getSelectIncentiveForActivity() {
		return selectIncentiveForActivity;
	}

	public void setSelectIncentiveForActivity(String selectIncentiveForActivity) {
		this.selectIncentiveForActivity = selectIncentiveForActivity;
	}
	
	

	public String getSelectIncentiveForActivityOutsideEnrollment() {
		return selectIncentiveForActivityOutsideEnrollment;
	}

	public void setSelectIncentiveForActivityOutsideEnrollment(
			String selectIncentiveForActivityOutsideEnrollment) {
		this.selectIncentiveForActivityOutsideEnrollment = selectIncentiveForActivityOutsideEnrollment;
	}

	public String getSelectPersonActivityIncentive() {
		return selectPersonActivityIncentive;
	}

	public void setSelectPersonActivityIncentive(
			String selectPersonActivityIncentive) {
		this.selectPersonActivityIncentive = selectPersonActivityIncentive;
	}

	public String getInsertIntoPersonActivityIncentive() {
		return insertIntoPersonActivityIncentive;
	}

	public void setInsertIntoPersonActivityIncentive(
			String insertIntoPersonActivityIncentive) {
		this.insertIntoPersonActivityIncentive = insertIntoPersonActivityIncentive;
	}

	public String getSelectIncentiveParticipant() {
		return selectIncentiveParticipant;
	}

	public void setSelectIncentiveParticipant(String selectIncentiveParticipant) {
		this.selectIncentiveParticipant = selectIncentiveParticipant;
	}

	public String getSelectIncentiveRequirements() {
		return selectIncentiveRequirements;
	}

	public void setSelectIncentiveRequirements(String selectIncentiveRequirements) {
		this.selectIncentiveRequirements = selectIncentiveRequirements;
	}

	public String getSelectActivityIncentive() {
		return selectActivityIncentive;
	}

	public void setSelectActivityIncentive(String selectActivityIncentive) {
		this.selectActivityIncentive = selectActivityIncentive;
	}

	public String getSelectContractProgramIncentive() {
		return selectContractProgramIncentive;
	}

	public void setSelectContractProgramIncentive(
			String selectContractProgramIncentive) {
		this.selectContractProgramIncentive = selectContractProgramIncentive;
	}

	public String getInsertContractProgramIncentive() {
		return insertContractProgramIncentive;
	}

	public void setInsertContractProgramIncentive(
			String insertContractProgramIncentive) {
		this.insertContractProgramIncentive = insertContractProgramIncentive;
	}

	public String getUpdateContractProgramIncentive() {
		return updateContractProgramIncentive;
	}

	public void setUpdateContractProgramIncentive(
			String updateContractProgramIncentive) {
		this.updateContractProgramIncentive = updateContractProgramIncentive;
	}
	
	

	public String getUpdatePersonActivityIncentiveWithContributionAmt() {
		return updatePersonActivityIncentiveWithContributionAmt;
	}

	public void setUpdatePersonActivityIncentiveWithContributionAmt(
			String updatePersonActivityIncentiveWithContributionAmt) {
		this.updatePersonActivityIncentiveWithContributionAmt = updatePersonActivityIncentiveWithContributionAmt;
	}
	
	

	public String getUpdatePersonActivityIncentiveWithModificationDate() {
		return updatePersonActivityIncentiveWithModificationDate;
	}

	public void setUpdatePersonActivityIncentiveWithModificationDate(
			String updatePersonActivityIncentiveWithModificationDate) {
		this.updatePersonActivityIncentiveWithModificationDate = updatePersonActivityIncentiveWithModificationDate;
	}
	
	

	public String getSelectIncentiveStatusActivityDetails() {
		return selectIncentiveStatusActivityDetails;
	}

	public void setSelectIncentiveStatusActivityDetails(
			String selectIncentiveStatusActivityDetails) {
		this.selectIncentiveStatusActivityDetails = selectIncentiveStatusActivityDetails;
	}

	public String getSelectIncentiveStatusActivityDetailContributions() {
		return selectIncentiveStatusActivityDetailContributions;
	}

	public void setSelectIncentiveStatusActivityDetailContributions(
			String selectIncentiveStatusActivityDetailContributions) {
		this.selectIncentiveStatusActivityDetailContributions = selectIncentiveStatusActivityDetailContributions;
	}

	public String getInsertIncentiveRequirement() {
		return insertIncentiveRequirement;
	}

	public void setInsertIncentiveRequirement(String insertIncentiveRequirement) {
		this.insertIncentiveRequirement = insertIncentiveRequirement;
	}

	public DataFieldMaxValueIncrementer getIncentiveRequirementIdIncrementer() {
		return incentiveRequirementIdIncrementer;
	}

	public void setIncentiveRequirementIdIncrementer(
			DataFieldMaxValueIncrementer incentiveRequirementIdIncrementer) {
		this.incentiveRequirementIdIncrementer = incentiveRequirementIdIncrementer;
	}

	public DataFieldMaxValueIncrementer getActivityIncentiveIdIncrementer() {
		return activityIncentiveIdIncrementer;
	}

	public void setActivityIncentiveIdIncrementer(
			DataFieldMaxValueIncrementer activityIncentiveIdIncrementer) {
		this.activityIncentiveIdIncrementer = activityIncentiveIdIncrementer;
	}

	public String getInsertActivityIncentive() {
		return insertActivityIncentive;
	}

	public void setInsertActivityIncentive(String insertActivityIncentive) {
		this.insertActivityIncentive = insertActivityIncentive;
	}

	public String getInsertIncentiveParticipant() {
		return insertIncentiveParticipant;
	}

	public void setInsertIncentiveParticipant(String insertIncentiveParticipant) {
		this.insertIncentiveParticipant = insertIncentiveParticipant;
	}

	public String getUpdatePersonActivityIncentive() {
		return updatePersonActivityIncentive;
	}

	public void setUpdatePersonActivityIncentive(
			String updatePersonActivityIncentive) {
		this.updatePersonActivityIncentive = updatePersonActivityIncentive;
	}

	public final String getSelectCollectionActivities() {
		return selectCollectionActivities;
	}

	public final void setSelectCollectionActivities(
			String selectCollectionActivities) {
		this.selectCollectionActivities = selectCollectionActivities;
	}

	public String getSelectMemberProgramIncentive() {
		return selectMemberProgramIncentive;
	}

	public void setSelectMemberProgramIncentive(String selectMemberProgramIncentive) {
		this.selectMemberProgramIncentive = selectMemberProgramIncentive;
	}

	public String getInsertMemberProgramIncentive() {
		return insertMemberProgramIncentive;
	}

	public void setInsertMemberProgramIncentive(String insertMemberProgramIncentive) {
		this.insertMemberProgramIncentive = insertMemberProgramIncentive;
	}

	public String getUpdateMemberProgramIncentive() {
		return updateMemberProgramIncentive;
	}

	public void setUpdateMemberProgramIncentive(String updateMemberProgramIncentive) {
		this.updateMemberProgramIncentive = updateMemberProgramIncentive;
	}
	
	

	public DataFieldMaxValueIncrementer getContractIncentiveIdIncrementer() {
		return contractIncentiveIdIncrementer;
	}

	public void setContractIncentiveIdIncrementer(
			DataFieldMaxValueIncrementer contractIncentiveIdIncrementer) {
		this.contractIncentiveIdIncrementer = contractIncentiveIdIncrementer;
	}

	public DataFieldMaxValueIncrementer getMemberIncentiveIdIncrementer() {
		return memberIncentiveIdIncrementer;
	}

	public void setMemberIncentiveIdIncrementer(
			DataFieldMaxValueIncrementer memberIncentiveIdIncrementer) {
		this.memberIncentiveIdIncrementer = memberIncentiveIdIncrementer;
	}
	
	

	public DataFieldMaxValueIncrementer getIncentiveStatusActivityDetailIdIncrementer() {
		return incentiveStatusActivityDetailIdIncrementer;
	}

	public void setIncentiveStatusActivityDetailIdIncrementer(
			DataFieldMaxValueIncrementer incentiveStatusActivityDetailIdIncrementer) {
		this.incentiveStatusActivityDetailIdIncrementer = incentiveStatusActivityDetailIdIncrementer;
	}

	public String getDeleteMemberProgramIncentive() {
		return deleteMemberProgramIncentive;
	}

	public void setDeleteMemberProgramIncentive(String deleteMemberProgramIncentive) {
		this.deleteMemberProgramIncentive = deleteMemberProgramIncentive;
	}

	public String getUpdateContractIncentiveAchievedDate() {
		return updateContractIncentiveAchievedDate;
	}

	public void setUpdateContractIncentiveAchievedDate(
			String updateContractIncentiveAchievedDate) {
		this.updateContractIncentiveAchievedDate = updateContractIncentiveAchievedDate;
	}

	public String getIsActivityCompletionPeriodEnabled() {
		return isActivityCompletionPeriodEnabled;
	}

	public void setIsActivityCompletionPeriodEnabled(
			String isActivityCompletionPeriodEnabled) {
		this.isActivityCompletionPeriodEnabled = isActivityCompletionPeriodEnabled;
	}

	public String getSelectIncentiveCheckmarkForActivity() {
		return selectIncentiveCheckmarkForActivity;
	}

	public void setSelectIncentiveCheckmarkForActivity(
			String selectIncentiveCheckmarkForActivity) {
		this.selectIncentiveCheckmarkForActivity = selectIncentiveCheckmarkForActivity;
	}

	public String getDeleteContractProgramIncentive() {
		return deleteContractProgramIncentive;
	}

	public void setDeleteContractProgramIncentive(
			String deleteContractProgramIncentive) {
		this.deleteContractProgramIncentive = deleteContractProgramIncentive;
	}

	public String getInsertIncentiveStatusActivityDetail() {
		return insertIncentiveStatusActivityDetail;
	}

	public void setInsertIncentiveStatusActivityDetail(
			String insertIncentiveStatusActivityDetail) {
		this.insertIncentiveStatusActivityDetail = insertIncentiveStatusActivityDetail;
	}

	public String getInsertIncentiveStatusActivityDetailContribution() {
		return insertIncentiveStatusActivityDetailContribution;
	}

	public void setInsertIncentiveStatusActivityDetailContribution(
			String insertIncentiveStatusActivityDetailContribution) {
		this.insertIncentiveStatusActivityDetailContribution = insertIncentiveStatusActivityDetailContribution;
	}

	public String getUpdateMemberIncentiveAchievedDate() {
		return updateMemberIncentiveAchievedDate;
	}

	public void setUpdateMemberIncentiveAchievedDate(
			String updateMemberIncentiveAchievedDate) {
		this.updateMemberIncentiveAchievedDate = updateMemberIncentiveAchievedDate;
	}

	public String getSelectPersonProgramActivityStatusByID() {
		return selectPersonProgramActivityStatusByID;
	}

	public void setSelectPersonProgramActivityStatusByID(
			String selectPersonProgramActivityStatusByID) {
		this.selectPersonProgramActivityStatusByID = selectPersonProgramActivityStatusByID;
	}

	public String getSelectIncentiveOptionDefinitionByName() {
		return selectIncentiveOptionDefinitionByName;
	}

	public void setSelectIncentiveOptionDefinitionByName(String selectIncentiveOptionDefinitionByName) {
		this.selectIncentiveOptionDefinitionByName = selectIncentiveOptionDefinitionByName;
	}

	public String getSelectContractIncentivesAchievedByProgramIncentiveOptionSummary() {
		return selectContractIncentivesAchievedByProgramIncentiveOptionSummary;
	}

	public void setSelectContractIncentivesAchievedByProgramIncentiveOptionSummary(
			String selectContractIncentivesAchievedByProgramIncentiveOptionSummary) {
		this.selectContractIncentivesAchievedByProgramIncentiveOptionSummary = selectContractIncentivesAchievedByProgramIncentiveOptionSummary;
	}

	public String getSelectMemberIncentivesAchievedByProgramIncentiveOptionSummary() {
		return selectMemberIncentivesAchievedByProgramIncentiveOptionSummary;
	}

	public void setSelectMemberIncentivesAchievedByProgramIncentiveOptionSummary(String selectMemberIncentivesAchievedByProgramIncentiveOptionSummary) {
		this.selectMemberIncentivesAchievedByProgramIncentiveOptionSummary = selectMemberIncentivesAchievedByProgramIncentiveOptionSummary;
	}
}

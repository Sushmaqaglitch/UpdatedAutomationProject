package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ActivityCollection implements Serializable
{	
	static final long serialVersionUID = 0L;
		
	private Integer collectionID;
	private String collectionName;
	private String collectionDesc;
	private Integer requiredQuantity;
		
	private Integer collectionTypeCodeID;
	private String collectionTypeCode;
	private String collectionTypeDesc;
	
	private java.sql.Date effectiveDate;
	private java.sql.Date endDate;
	
	private List<ActivityDefinition> collectionActivities;
	
	
	public ActivityCollection()
	{
		super();
	}


	public Integer getCollectionID() {
		return collectionID;
	}


	public void setCollectionID(Integer collectionID) {
		this.collectionID = collectionID;
	}


	public String getCollectionName() {
		return collectionName;
	}


	public void setCollectionName(String collectionName) {
		this.collectionName = collectionName;
	}


	public String getCollectionDesc() {
		return collectionDesc;
	}


	public void setCollectionDesc(String collectionDesc) {
		this.collectionDesc = collectionDesc;
	}


	public Integer getRequiredQuantity() {
		return requiredQuantity;
	}


	public void setRequiredQuantity(Integer requiredQuantity) {
		this.requiredQuantity = requiredQuantity;
	}


	public Integer getCollectionTypeCodeID() {
		return collectionTypeCodeID;
	}


	public void setCollectionTypeCodeID(Integer collectionTypeCodeID) {
		this.collectionTypeCodeID = collectionTypeCodeID;
	}


	public String getCollectionTypeCode() {
		return collectionTypeCode;
	}


	public void setCollectionTypeCode(String collectionTypeCode) {
		this.collectionTypeCode = collectionTypeCode;
	}


	public String getCollectionTypeDesc() {
		return collectionTypeDesc;
	}


	public void setCollectionTypeDesc(String collectionTypeDesc) {
		this.collectionTypeDesc = collectionTypeDesc;
	}


	public java.sql.Date getEffectiveDate() {
		return effectiveDate;
	}


	public void setEffectiveDate(java.sql.Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}


	public java.sql.Date getEndDate() {
		return endDate;
	}


	public void setEndDate(java.sql.Date endDate) {
		this.endDate = endDate;
	}


	public List<ActivityDefinition> getCollectionActivities() {
		return collectionActivities;
	}


	public void setCollectionActivities(
			List<ActivityDefinition> collectionActivities) {
		this.collectionActivities = collectionActivities;
	}
	
	
	
}

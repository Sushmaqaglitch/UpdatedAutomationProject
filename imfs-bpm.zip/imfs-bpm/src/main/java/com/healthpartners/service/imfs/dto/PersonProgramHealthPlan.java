package com.healthpartners.service.imfs.dto;

import java.io.Serializable;

/**
 * 
 * @author jxbourbour
 *
 */
public class PersonProgramHealthPlan implements Serializable
{
	static final long serialVersionUID = 0L;
	
	private Integer personDemographicsID;
	private Integer businessProgramID;
	private String healthPlanCode;
	
	public PersonProgramHealthPlan()
	{
		super();
	}

	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}

	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}

	public Integer getBusinessProgramID() {
		return businessProgramID;
	}

	public void setBusinessProgramID(Integer businessProgramID) {
		this.businessProgramID = businessProgramID;
	}

	public String getHealthPlanCode() {
		return healthPlanCode;
	}

	public void setHealthPlanCode(String healthPlanCode) {
		this.healthPlanCode = healthPlanCode;
	}
	
	
}

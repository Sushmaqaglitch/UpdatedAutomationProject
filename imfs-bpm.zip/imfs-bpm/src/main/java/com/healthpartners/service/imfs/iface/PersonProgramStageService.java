/**
 * 
 */
package com.healthpartners.service.imfs.iface;

import java.util.Collection;

import com.healthpartners.service.imfs.dto.PersonProgramStage;
import org.springframework.dao.DataAccessException;
import com.healthpartners.service.imfs.exception.BPMException;


/**
 * @author tjquist.
 * 
 */





public interface PersonProgramStageService {

	/**
	 * gets person program count.
	 * 
	 * @return count
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public int getPersonProgramCount()
			throws BPMException, DataAccessException;


	/**
	 * write a collection of person program records to cache projection table.
	 * 
	 * @param personPrograms
	 * @return number of records inserted
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public int insertPersonPrograms(Collection<PersonProgramStage> personPrograms)
			throws BPMException, DataAccessException;

	/**
	 * delete person program records contained in collection object
	 * 
	 * @param personPrograms
	 * @return count of records deleted
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public int deletePersonPrograms(Collection<PersonProgramStage> personPrograms) 
			throws BPMException, DataAccessException;

	/**
	 * gets all rules contract, member, exemption, gold pass
	 * 
	 * @param personNumber
	 * @return PersonProgramStage
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public PersonProgramStage getPersonProgram(int personNumber)
			throws BPMException, DataAccessException;
	
	/**
	 * gets all rules contract, member, exemption, gold pass
	 * 
	 * @return Collection<PersonProgramStage>
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public Collection<PersonProgramStage> getPersonPrograms()
	throws BPMException, DataAccessException;
	
	
}




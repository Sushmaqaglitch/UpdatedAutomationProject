package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;

public class IncentiveStatusActivityDetailContribution implements Serializable
{	
	static final long serialVersionUID = 0L;
	
	private Integer incentiveStatusActivityDetailContribID;
	
	private Integer incentiveStatusActivityDetailID;
	
	private Integer benefitContractTypeID;
	
	private Integer contributionAmount;
	
	private Integer  contributionGridID;
	
	
	public IncentiveStatusActivityDetailContribution()
	{
		super();
	}


	public Integer getIncentiveStatusActivityDetailContribID() {
		return incentiveStatusActivityDetailContribID;
	}


	public void setIncentiveStatusActivityDetailContribID(
			Integer incentiveStatusActivityDetailContribID) {
		this.incentiveStatusActivityDetailContribID = incentiveStatusActivityDetailContribID;
	}


	public Integer getIncentiveStatusActivityDetailID() {
		return incentiveStatusActivityDetailID;
	}


	public void setIncentiveStatusActivityDetailID(
			Integer incentiveStatusActivityDetailID) {
		this.incentiveStatusActivityDetailID = incentiveStatusActivityDetailID;
	}


	public Integer getBenefitContractTypeID() {
		return benefitContractTypeID;
	}


	public void setBenefitContractTypeID(Integer benefitContractTypeID) {
		this.benefitContractTypeID = benefitContractTypeID;
	}


	public Integer getContributionAmount() {
		return contributionAmount;
	}


	public void setContributionAmount(Integer contributionAmount) {
		this.contributionAmount = contributionAmount;
	}


	public Integer getContributionGridID() {
		return contributionGridID;
	}


	public void setContributionGridID(Integer contributionGridID) {
		this.contributionGridID = contributionGridID;
	}

	
	
	
}

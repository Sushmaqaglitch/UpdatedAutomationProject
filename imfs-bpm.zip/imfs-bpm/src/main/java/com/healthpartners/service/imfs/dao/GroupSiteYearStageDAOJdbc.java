package com.healthpartners.service.imfs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.dto.GroupSiteYearStage;
import com.healthpartners.service.imfs.exception.BPMException;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;

@Configuration
public class GroupSiteYearStageDAOJdbc extends JdbcDaoSupport implements GroupSiteYearStageDAO {
	
	private String getGroupSiteYearStage;
	
	private String selectGroupSiteYearsStage;
	
	private String selectGroupSiteYearStage;
	
	private String selectGroupSiteYearCount;

	private String countGroupSiteYearStageRows;

	private String deleteGroupSiteYearsStage;

	private String insertGroupSiteYearsStage;
	
	public GroupSiteYearStageDAOJdbc() {
		super();
	}

	@Qualifier("cacheDataSource")
	@Autowired
	DataSource cacheDataSource;


	@PostConstruct
	private void initialize() {

		setDataSource(cacheDataSource);
	}
	
	//Create implementation methods for person program stage beginning here - Start
	/**
	 * Select a GroupSiteYearStage record given the counterNumID.
	 * 
	 * @return GroupSiteYearStage object.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<GroupSiteYearStage> getGroupSiteYears()
			throws DataAccessException {
		final ArrayList<GroupSiteYearStage> lGroupSiteYearsStage = new ArrayList<GroupSiteYearStage>();
		StringBuffer query = new StringBuffer();
		query.append(selectGroupSiteYearsStage);
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {  };
		int types[] = new int[] {  };

		template.query(query.toString(), params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						GroupSiteYearStage lGroupSiteYearStage = new GroupSiteYearStage();
						lGroupSiteYearStage.setGroupNumber(rs
								.getInt("GrpNum"));
						lGroupSiteYearStage.setNewHireDate(rs
								.getDate("NewHireDate"));
						lGroupSiteYearStage.setParticipationRequiredDesc(rs
								.getString("PartReqCd"));
						lGroupSiteYearStage.setProgramType(rs
								.getString("ProgramType"));
						lGroupSiteYearStage.setQualificationEndDate(rs
								.getDate("QualEndDate"));
						lGroupSiteYearStage.setQualificationStartDate(rs
								.getDate("QualStartDate"));
						java.sql.Date runDate = rs.getDate("RunDate");
						lGroupSiteYearStage.setRunDate(runDate);
						lGroupSiteYearStage.setRunTime(rs.getTime("RunTime"));
						lGroupSiteYearStage.setSiteNumber(rs
								.getInt("SiteNum"));
						lGroupSiteYearsStage
								.add(lGroupSiteYearStage);
						lGroupSiteYearStage.setMembershipProcessFlag(rs.getString("ReadyForMbrshp"));
					}
				});

		

		return lGroupSiteYearsStage;
	}
	
	/**
	 * Select a GroupSiteYearStage record given the counterNumID.
	 * 
	 * @return GroupSiteYearStage object.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public GroupSiteYearStage getGroupSiteYear(int pGroupNumber, int pSiteNumber, Date pQualStartDate)
			throws DataAccessException {
		final ArrayList<GroupSiteYearStage> lGroupSiteYearsStage = new ArrayList<GroupSiteYearStage>();
		StringBuffer query = new StringBuffer();
		query.append(selectGroupSiteYearStage);
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { pGroupNumber, pSiteNumber, pQualStartDate };
		int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.DATE };

		template.query(query.toString(), params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						GroupSiteYearStage lGroupSiteYearStage = new GroupSiteYearStage();
						lGroupSiteYearStage.setGroupNumber(rs
								.getInt("GrpNum"));
						lGroupSiteYearStage.setNewHireDate(rs
								.getDate("NewHireDate"));
						lGroupSiteYearStage.setParticipationRequiredDesc(rs
								.getString("PartReqCd"));
						lGroupSiteYearStage.setProgramType(rs
								.getString("ProgramType"));
						lGroupSiteYearStage.setQualificationEndDate(rs
								.getDate("QualEndDate"));
						lGroupSiteYearStage.setQualificationStartDate(rs
								.getDate("QualStartDate"));
						java.sql.Date runDate = rs.getDate("RunDate");
						lGroupSiteYearStage.setRunDate(runDate);
						lGroupSiteYearStage.setRunTime(rs.getTime("RunTime"));
						lGroupSiteYearStage.setSiteNumber(rs
								.getInt("SiteNum"));
						lGroupSiteYearStage.setMembershipProcessFlag(rs.getString("ReadyForMbrshp"));

						lGroupSiteYearsStage
								.add(lGroupSiteYearStage);
					}
				});

		GroupSiteYearStage groupSiteYearStage = null;
		if (lGroupSiteYearsStage.size() > 0) {
			groupSiteYearStage = lGroupSiteYearsStage.get(0);
		}

		return groupSiteYearStage;
	}
	
	
	/**
	 * Select a GroupSiteYearStage record given the counterNumID.
	 * 
	 * @return GroupSiteYearStage object.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int getGroupSiteYearCount()
	 			throws DataAccessException {
		 
		final ArrayList count = new ArrayList();
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {  };
		int types[] = new int[] { };
		template.query(countGroupSiteYearStageRows, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						count.add(rs.getInt(1));
					}
		});
		
		
		Integer countInt = (Integer)count.get(0);
		
		return countInt.intValue();
	}


	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int insertGroupSiteYears(Collection<GroupSiteYearStage> groupSiteYearsStage)
			throws DataAccessException {
		
		
		Iterator<GroupSiteYearStage> iter = groupSiteYearsStage.iterator();
		
		Integer contractNumber = null;
		
		Integer groupNumber = null;
		Date newHireDate = null;
		String participationRequiredCode = null;
		String programType = null;
		Date qualEndDate = null;
		Date qualStartDate = null;
		Date progEndDate = null;
		Date progStartDate = null;
		Date runDate = null;
		Time runTime = null;
		Integer siteNumber = null;
		Date statusDate = null;
		String readyForMbrshp = null;
		int rowsInserted = 0;
		
		while (iter.hasNext()) {
			GroupSiteYearStage groupSiteYear = iter.next();
			
			groupNumber = (groupSiteYear.getGroupNumber() != null) ? groupSiteYear.getGroupNumber() : null;
			newHireDate = (groupSiteYear.getNewHireDate() != null) ? groupSiteYear.getNewHireDate() : null;
			participationRequiredCode = (groupSiteYear.getParticipationRequiredDesc() != null) ? groupSiteYear.getParticipationRequiredDesc() : null;
			programType = (groupSiteYear.getProgramType() != null) ? groupSiteYear.getProgramType() : null;
			qualEndDate = (groupSiteYear.getQualificationEndDate() != null) ? groupSiteYear.getQualificationEndDate() : null;
			qualStartDate = (groupSiteYear.getQualificationStartDate() != null) ? groupSiteYear.getQualificationStartDate() : null;
			progEndDate = (groupSiteYear.getProgramEndDate() != null) ? groupSiteYear.getProgramEndDate() : null;
			progStartDate = (groupSiteYear.getProgramStartDate() != null) ? groupSiteYear.getProgramStartDate() : null;
			siteNumber = (groupSiteYear.getSiteNumber() != null) ? groupSiteYear.getSiteNumber() : null;
			readyForMbrshp = (groupSiteYear.getMembershipProcessFlag() != null) ? groupSiteYear.getMembershipProcessFlag() : null;
			
			runDate = new Date(new java.util.Date().getTime());
			long time = runDate.getTime();
			runTime = new Time(time);
			
	
			// Persist.
			JdbcTemplate template = getJdbcTemplate();
			Object params[] = new Object[] { groupNumber, newHireDate,
					participationRequiredCode, programType,
					qualEndDate, qualStartDate,
					progEndDate, progStartDate, runDate,
					runTime, siteNumber, readyForMbrshp};
			int types[] = new int[] { Types.INTEGER, Types.DATE, 
					Types.VARCHAR, Types.VARCHAR,
					Types.DATE, Types.DATE,  
					Types.DATE, Types.DATE, Types.DATE, 
					Types.TIME, Types.INTEGER, Types.CHAR};
			int rowInserted = template.update(insertGroupSiteYearsStage, params, types);
			if (rowInserted > 0) {
				rowsInserted++;		
			}
		}
		return rowsInserted;
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int deleteGroupSiteYears(Collection<GroupSiteYearStage> groupSiteYearsStage)
	throws DataAccessException {
		int deleteCount = 0;
		Iterator iter = groupSiteYearsStage.iterator();
		while (iter.hasNext()) {
			JdbcTemplate template = getJdbcTemplate();
			GroupSiteYearStage groupSiteYear = (GroupSiteYearStage)iter.next();
			Integer groupNumber = groupSiteYear.getGroupNumber();
			Integer siteNumber = groupSiteYear.getSiteNumber();
			Date qaulStartDate = groupSiteYear.getQualificationStartDate();
			Object params[] = new Object[] { groupNumber, siteNumber, qaulStartDate.toString() };
			int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.VARCHAR };
			int returnCount = template.update(deleteGroupSiteYearsStage, params, types);
			if (returnCount > 0) {
				deleteCount++;
			}
			template.update(deleteGroupSiteYearsStage, params, types);
		}
		
		return deleteCount;
	}




	public String getGetGroupSiteYearStage() {
		return getGroupSiteYearStage;
	}




	public void setGetGroupSiteYearStage(String getGroupSiteYearStage) {
		this.getGroupSiteYearStage = getGroupSiteYearStage;
	}




	public String getSelectGroupSiteYearsStage() {
		return selectGroupSiteYearsStage;
	}




	public void setSelectGroupSiteYearsStage(String selectGroupSiteYearsStage) {
		this.selectGroupSiteYearsStage = selectGroupSiteYearsStage;
	}




	public String getSelectGroupSiteYearCount() {
		return selectGroupSiteYearCount;
	}




	public void setSelectGroupSiteYearCount(String selectGroupSiteYearCount) {
		this.selectGroupSiteYearCount = selectGroupSiteYearCount;
	}




	public String getCountGroupSiteYearStageRows() {
		return countGroupSiteYearStageRows;
	}




	public void setCountGroupSiteYearStageRows(String countGroupSiteYearStageRows) {
		this.countGroupSiteYearStageRows = countGroupSiteYearStageRows;
	}




	public String getDeleteGroupSiteYearsStage() {
		return deleteGroupSiteYearsStage;
	}




	public void setDeleteGroupSiteYearsStage(String deleteGroupSiteYearsStage) {
		this.deleteGroupSiteYearsStage = deleteGroupSiteYearsStage;
	}




	public String getInsertGroupSiteYearsStage() {
		return insertGroupSiteYearsStage;
	}




	public void setInsertGroupSiteYearsStage(String insertGroupSiteYearsStage) {
		this.insertGroupSiteYearsStage = insertGroupSiteYearsStage;
	}




	public String getSelectGroupSiteYearStage() {
		return selectGroupSiteYearStage;
	}




	public void setSelectGroupSiteYearStage(String selectGroupSiteYearStage) {
		this.selectGroupSiteYearStage = selectGroupSiteYearStage;
	}
	
	
	//Create implementation methods for person program stage beginning here - End
	
	


}
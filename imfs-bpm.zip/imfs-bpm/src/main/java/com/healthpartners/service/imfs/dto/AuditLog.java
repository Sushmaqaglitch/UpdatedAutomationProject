/**
 * 
 */
package com.healthpartners.service.imfs.dto;

/**
 * @author jxbourbour
 * 
 */
public class AuditLog extends BaseDTO {

	static final long serialVersionUID = 0L;
	
	/**
	 * 
	 */
	public AuditLog() {
		super();
	}

	

}

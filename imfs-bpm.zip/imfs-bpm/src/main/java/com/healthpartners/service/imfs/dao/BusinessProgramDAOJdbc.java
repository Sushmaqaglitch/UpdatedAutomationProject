package com.healthpartners.service.imfs.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.*;
import com.healthpartners.service.imfs.exception.BPMException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.exception.BPMException;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;

@Configuration
@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
public class BusinessProgramDAOJdbc extends JdbcDaoSupport implements BusinessProgramDAO
{
	private static final Calendar Calendar = null;
	private String selectGroups;
	private String selectBusinessPrograms;
	private String selectAllBusinessPrograms;
	private String selectQualificationYears;
	private String selectGroupPrograms;
	private String selectAllQualificationYears;
	private String selectBPMGroupSiteYear;
	private String selectBPMBusinessProgram;
	private String selectBPMBusinessProgramWTermedContract;
	private String selectBusinessProgramsForMembership;
	private String updateMembershipProcessFlag;
	private String selectActivityAvailable;
	private String insertBusinessProgram;
	private String selectProgramTemplate;
	private String selectBusinessProgramDetail;
	private String selectBusinessProgramsFromMemberTermedSite;
	
	private String selectSmallGroupTypeIDs;
	private String selectMarketIndicatorRequirements;
	private String selectMarketRequirementDetails;
	private String selectNewSmartStepsGroupBaseline;
	private String selectProgramAuthPromoCode;
	private String selectAutoPopulateOverlaps;
	
	private String selectTemplateBusinessProgramID;
	private String selectTemplateActivitiesCount;
	private String selectTemplateAuthCodesCount;
	private String selectTemplateIncentivesCount;
	private String selectTemplateCheckmarkCount;
	private String insertBusinessProgramChangeLog;

	@Autowired
	private DataFieldMaxValueIncrementer programChangeLogIDIncrementer;
	
	
	@Autowired
	private DataFieldMaxValueIncrementer businessProgramIdIncrementer;

	protected final Log logger = LogFactory.getLog(getClass());
	
	public BusinessProgramDAOJdbc()
	{
		super();
	}

	@Autowired
	DataSource bpmDataSource;
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}

	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<BusinessProgramTO> getBusinessProgramTO(Integer pPersonID,
															  Integer pTargetQualificationYear)
	{	
		return getBusinessProgramTO(pPersonID, 
				"", 
				pTargetQualificationYear,
				"",
				0);
	}
	
	/**
	 * 
	 * @param pGroupNumber
	 * @return
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<EmployerGroup> getGroups(String pGroupNumber)
	{

	    StringBuffer lQuery = new StringBuffer();	    

	    NamedParameter namedParameter = new NamedParameter();
	    lQuery.append(selectGroups);
	    namedParameter.setGroupNo(pGroupNumber);
	    lQuery.append(" AND empl_grp_no = :groupNo");
	    lQuery.append(" ORDER BY empl_grp_no ");
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);


		List<EmployerGroup> lGroups = namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters, new RowMapper() {
			@Override
			public EmployerGroup mapRow(ResultSet rs, int i) throws SQLException {
				EmployerGroup lEmployerGroup = new EmployerGroup();

				lEmployerGroup.setGroupID(rs.getInt("grp_id"));
				lEmployerGroup.setGroupNumber(rs.getString("grp_no"));
				lEmployerGroup.setGroupName(rs.getString("grp_nm"));

				return lEmployerGroup;
			}

		});
        
        return lGroups;
	}
	
	/**
	 * 
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public BPMBusinessProgram getBusinessProgramDetail(Integer programId) throws DataAccessException {
		
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { programId };
		int types[] = new int[] { Types.INTEGER };
		final ArrayList<BPMBusinessProgram> lBusinessPrograms = new ArrayList<BPMBusinessProgram>();
		
		template.query(selectBusinessProgramDetail, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						BPMBusinessProgram lBPMBusinessProgram = new BPMBusinessProgram();
						
						lBPMBusinessProgram.setProgramID(rs.getInt("biz_pgm_id"));
						lBPMBusinessProgram.setProgramTypeCodeID(String.valueOf(rs.getInt("biz_pgm_tp_cd")));
						lBPMBusinessProgram.setEffectiveDate(BPMUtils.dateToCalendar(rs.getDate("eff_dt")));
						lBPMBusinessProgram.setEndDate(BPMUtils.dateToCalendar(rs.getDate("pgm_end_dt")));
						lBPMBusinessProgram.setQualificationWindowStartDate(BPMUtils.dateToCalendar(rs.getDate("qualfctn_start_dt")));
						lBPMBusinessProgram.setQualificationWindowEndDate(BPMUtils.dateToCalendar(rs.getDate("qualfctn_end_dt")));
						lBPMBusinessProgram.setStatusCalcEndDate(BPMUtils.dateToCalendar(rs.getDate("stat_calc_end_dt")));
						lBPMBusinessProgram.setGroupID(rs.getInt("grp_id"));
						lBPMBusinessProgram.setSubgroupID(rs.getInt("subgrp_id"));
						lBPMBusinessProgram.setGroupNumber(rs.getString("empl_grp_no"));	
						lBPMBusinessProgram.setGroupName(rs.getString("empl_grp_nm"));	
						lBPMBusinessProgram.setSiteName(rs.getString("empl_grp_site_nm"));
						lBPMBusinessProgram.setSiteNumber(rs.getString("empl_grp_site_id_no"));	
						lBPMBusinessProgram.setFamilyParticipationValue(rs.getString("part_req_desc"));	
						lBusinessPrograms.add(lBPMBusinessProgram);
					}
		});
		
		return lBusinessPrograms.get(0);
			
		}

	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<BusinessProgramTO> getAllBusinessPrograms(Integer pPersonID, boolean pCalledFromWebPortal)
	{
		final ArrayList<BusinessProgramTO> lBusinessProgramTOs;
		Object params[] = new Object[] { pPersonID};
		int types[] = new int[] { Types.INTEGER};
        
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectAllBusinessPrograms);
			
		lQuery.append(" AND prog_stat.PRSN_DMGRPHCS_ID = ? ");        
        
        if(pCalledFromWebPortal)
        {
        	lQuery.append(" AND (prog_stat.PARTICIPATION_END_DT IS NULL OR trunc(prog_stat.PARTICIPATION_END_DT) > trunc(SYSDATE)) ");
        	lQuery.append(" AND trunc(biz.eff_dt) < baseline.CONTRACT_END_DT ");
			lQuery.append(" AND trunc(biz.eff_dt) < baseline.SUBGRP_END_DT");
			lQuery.append(" AND trunc(biz.eff_dt) < baseline.BEN_PKG_END_DT");
			lQuery.append(" AND (SYSDATE < baseline.CONTRACT_END_DT OR trunc(biz.pgm_end_dt) <= baseline.CONTRACT_END_DT)");
			lQuery.append(" AND (SYSDATE < baseline.SUBGRP_END_DT   OR trunc(biz.pgm_end_dt) <= baseline.SUBGRP_END_DT)");
			lQuery.append(" AND (SYSDATE < baseline.BEN_PKG_END_DT  OR trunc(biz.pgm_end_dt) <= baseline.BEN_PKG_END_DT)");
			lQuery.append(" AND baseline.contract_eff_dt < trunc(biz.pgm_end_dt)");
			lQuery.append(" AND baseline.subgrp_eff_dt < trunc(biz.pgm_end_dt)");
			lQuery.append(" AND baseline.ben_pkg_eff_dt < trunc(biz.pgm_end_dt)");
        }
        
        JdbcTemplate template = getJdbcTemplate();               
		
		lBusinessProgramTOs = (ArrayList<BusinessProgramTO>)
		    template.query(lQuery.toString(), params, types, new AllBusinessProgramTORowMapper());
				
		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
		
		return lBusinessProgramTOs;
	}
	
	/**
	 * Get a list of Business Programs in which the given person is participating in the
	 * given year.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<BusinessProgramTO> getParticipatingBusinessProgramTO(Integer pPersonID, 			
			Integer pTargetQualificationYear)
	{	
        final ArrayList<BusinessProgramTO> lBusinessProgramTOs;
		
        Object params[] = new Object[] { pTargetQualificationYear, pPersonID};
		int types[] = new int[] { Types.INTEGER, Types.INTEGER};
        
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectBusinessPrograms);
		
		lQuery.append(" AND prog_stat.PRSN_DMGRPHCS_ID = ? ");               
        lQuery.append(" AND (prog_stat.PARTICIPATION_END_DT IS NULL OR trunc(prog_stat.PARTICIPATION_END_DT) > trunc(SYSDATE)) ");
        
        JdbcTemplate template = getJdbcTemplate();               
		
		lBusinessProgramTOs = (ArrayList<BusinessProgramTO>)
		    template.query(lQuery.toString(), params, types, new BusinessProgramTORowMapper());
				
		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
		
		return lBusinessProgramTOs;
	}
	
	
	/**
	 * Returns a BusinessProgramTO object representing the Business Program specified by the
	 * program ID, the person ID, and the target benefit year for the person participating 
	 * in that program.
	 * Group (Employer Group) is optional, if provided it will retrieve program info for that group only.
	 * 
	 * @param pPersonID
	 * @param pProgramID
	 * @param pTargetQualificationYear
	 * @param pGroupNo
	 * @param pProgramID
	 *  
     * @return BusinessProgramTO
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<BusinessProgramTO> getBusinessProgramTO(Integer pPersonID, 
			String pProgramCode, 
			Integer pTargetQualificationYear,
			String pGroupNo,
			Integer pProgramID)
	{				
		final ArrayList<BusinessProgramTO> lBusinessProgramTOs;
		
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectBusinessPrograms);
		
	    ArrayList<Object> lParameters = new ArrayList<Object>();
	    ArrayList<Integer> lTypes = new ArrayList<Integer>();	    	    
	    
	    if(pTargetQualificationYear != null && pTargetQualificationYear.intValue() > 0)
	    {	    	
	    	lParameters.add(Integer.valueOf(pTargetQualificationYear));
		    lTypes.add(new Integer(Types.INTEGER));
		    lQuery.append(" AND EXTRACT(YEAR FROM biz.eff_dt) = ? ");
	    }
	    	    	    
        // If this method is called from the getGroupProgram web service PersonID will not
	    // be provided. getGroupProgram will send in a Group No.
	    // getMemberStatus, and isRequiredParticipant will send in a PersonID.
	    // So, Person ID and Group No can NOT both be null. (this was causing an Out-of-Memory Dec. 2008)
	    if((pPersonID == null || pPersonID.intValue() == 0) &&
	       (pGroupNo == null || pGroupNo.trim().length() <= 0 || Integer.valueOf(pGroupNo) <= 0))
	    {
	    	return new ArrayList<BusinessProgramTO>();
	    }
	    
	    // If this method is called from the getGroupProgram web service PersonID will not
	    // be provided.
	    if(pPersonID != null && pPersonID > 0)
	    {
	        lParameters.add(pPersonID);
	        lTypes.add(new Integer(Types.INTEGER));
	        lQuery.append(" AND prog_stat.PRSN_DMGRPHCS_ID = ? ");	        
	    }	    	     
	    
	    // Group ID is optional.
	    if(pGroupNo != null && pGroupNo.length() > 0 && Integer.valueOf(pGroupNo) > 0)
	    {
	    	lParameters.add(pGroupNo);
	    	lTypes.add(new Integer(Types.CHAR));
	    	lQuery.append(" AND GROUP_DS.EMPL_GRP_NO = ? ");
	    }
	    
	    if(pProgramCode != null && pProgramCode.length() >0 && Integer.parseInt(pProgramCode) > 0)
	    {
	       lParameters.add(pProgramCode);
	       lTypes.add(new Integer(Types.CHAR));
	       lQuery.append(" AND biz.BIZ_PGM_TP_CD= ? ");   
	    }
	    
	    if(pProgramID != null && pProgramID > 0)
	    {
	        lParameters.add(pProgramID);
	        lTypes.add(new Integer(Types.INTEGER));
	        lQuery.append(" AND biz.biz_pgm_id = ? ");	        
	    }
	    
	    // Convert the parameter and types ArrayLists to arrays of primitive types. 
	    Object params[] = new Object[lParameters.size()];
	    lParameters.toArray(params);

	    int types[] = new int[lTypes.size()];
	    for(int j = 0; j < lTypes.size(); j++)
	    {
	    	types[j] = ((Integer)lTypes.get(j)).intValue();
	    }
		
	    logger.debug("getBusinessProgramTO query= "+lQuery.toString());
	    logger.debug("with Parameters  = " + pPersonID + ", " + pProgramCode + ", " + pTargetQualificationYear + ", -->" + pGroupNo + "<--");
	    	    
		JdbcTemplate template = getJdbcTemplate();		
				
		lBusinessProgramTOs = (ArrayList<BusinessProgramTO>)
		    template.query(lQuery.toString(), params, types, new BusinessProgramTORowMapper());
				
		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
		
		return lBusinessProgramTOs;														
	}
	
	/**
	 * Returns a BusinessProgramTO object representing the Business Program specified by the
	 * program ID, the person ID, and the target benefit year for the person participating 
	 * in that program.  Only looking to return the business program involved
	 * in the site transfer (termed sites only).
	 * 
	 * @param pPersonID
	 * @param pTargetQualificationYear
	 * @param pGroupNo
	 *  
     * @return BusinessProgramTO
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<BusinessProgramTO> getBusinessProgramTOFromMemberTermedSite(Integer pPersonID, 
			Integer pTargetQualificationYear,
			String pGroupNo)
	{				
		final ArrayList<BusinessProgramTO> lBusinessProgramTOs;
		
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectBusinessProgramsFromMemberTermedSite);
		
	    ArrayList<Object> lParameters = new ArrayList<Object>();
	    ArrayList<Integer> lTypes = new ArrayList<Integer>();	    	    
	    
	    if(pTargetQualificationYear != null && pTargetQualificationYear.intValue() > 0)
	    {	    	
	    	lParameters.add(Integer.valueOf(pTargetQualificationYear));
		    lTypes.add(new Integer(Types.INTEGER));
		    lQuery.append(" AND EXTRACT(YEAR FROM biz.eff_dt) = ? ");
	    }
	    	    	    
        // If this method is called from the getGroupProgram web service PersonID will not
	    // be provided. getGroupProgram will send in a Group No.
	    // getMemberStatus, and isRequiredParticipant will send in a PersonID.
	    // So, Person ID and Group No can NOT both be null. (this was causing an Out-of-Memory Dec. 2008)
	    if((pPersonID == null || pPersonID.intValue() == 0) &&
	       (pGroupNo == null || pGroupNo.trim().length() <= 0 || Integer.valueOf(pGroupNo) <= 0))
	    {
	    	return new ArrayList<BusinessProgramTO>();
	    }
	    
	    // If this method is called from the getGroupProgram web service PersonID will not
	    // be provided.
	    if(pPersonID != null && pPersonID > 0)
	    {
	        lParameters.add(pPersonID);
	        lTypes.add(new Integer(Types.INTEGER));
	        lQuery.append(" AND prog_stat.PRSN_DMGRPHCS_ID = ? ");	        
	    }	    	     
	    
	    // Group ID is optional.
	    if(pGroupNo != null && pGroupNo.length() > 0 && Integer.valueOf(pGroupNo) > 0)
	    {
	    	lParameters.add(pGroupNo);
	    	lTypes.add(new Integer(Types.CHAR));
	    	lQuery.append(" AND GROUP_DS.EMPL_GRP_NO = ? ");
	    }
	    
	    
	    // Convert the parameter and types ArrayLists to arrays of primitive types. 
	    Object params[] = new Object[lParameters.size()];
	    lParameters.toArray(params);

	    int types[] = new int[lTypes.size()];
	    for(int j = 0; j < lTypes.size(); j++)
	    {
	    	types[j] = ((Integer)lTypes.get(j)).intValue();
	    }
		
	    logger.debug("getBusinessProgramTO query= "+lQuery.toString());
	    logger.debug("with Parameters  = " + pPersonID + ", " + pTargetQualificationYear + ", -->" + pGroupNo + "<--");
	    	    
		JdbcTemplate template = getJdbcTemplate();		
				
		lBusinessProgramTOs = (ArrayList<BusinessProgramTO>)
		    template.query(lQuery.toString(), params, types, new BusinessProgramTORowMapper());
				
		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
		
		return lBusinessProgramTOs;														
	}
	
	/**
	 * Returns a BusinessProgramTO object representing the Business Program specified by the
	 * program ID, Employer Group, Group Site, and the target benefit year for  
	 * that program.
	 * 
	 * @param pProgramID
	 * @param pTargetQualificationYear
	 * @param pGroupID
	 * @param pSiteID
	 *  
     * @return BusinessProgramTO
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<BusinessProgramTO> getGroupBusinessProgramTO(String pProgramCode, 
			Integer pTargetQualificationYear,
			String pGroupNo,
			String pSiteNo)
	{				
		ArrayList<BusinessProgramTO> lBusinessProgramTOs;		
								
		lBusinessProgramTOs = (ArrayList<BusinessProgramTO>)
		    getBusinessProgramTOs(pProgramCode, 
			pTargetQualificationYear,
			pGroupNo,
			pSiteNo);			
		
		return lBusinessProgramTOs;
	}
	
	/**
	 * This method returns a list of BusinessProgramTOs for the target benefit year.
	 * The other paratmers are optional. They can be set to 0 to broaden the result set.
	 * 
	 * @param pProgramCode
	 * @param pTargetQualificationYear
	 * @param pGroupNo
	 * @param pSiteNo
	 * @return
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<BusinessProgramTO> getBusinessProgramTOs(String pProgramCode, 
			Integer pTargetQualificationYear,
			String pGroupNo,
			String pSiteNo)
	{
		final ArrayList<BusinessProgramTO> lBusinessProgramTOs;
		
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectGroupPrograms);
		
	    ArrayList<Object> lParameters = new ArrayList<Object>();
	    ArrayList<Integer> lTypes = new ArrayList<Integer>();	    	    
	    	    
	    lParameters.add(Integer.valueOf(pTargetQualificationYear));
	    lTypes.add(new Integer(Types.INTEGER));
	    
	    if(pProgramCode != null && pProgramCode.length() >0 && Integer.parseInt(pProgramCode) > 0)
	    {
	        lParameters.add(pProgramCode);
	        lTypes.add(new Integer(Types.CHAR));
	        lQuery.append(" AND BIZ.biz_pgm_tp_cd = ?");
	    }
	    
	    if(pGroupNo != null && pGroupNo.length() > 0 && Integer.valueOf(pGroupNo) > 0)
	    {
	    	lParameters.add(pGroupNo);
	    	lTypes.add(new Integer(Types.CHAR));
	    	lQuery.append(" AND GROUP_DS.EMPL_GRP_NO = ? ");
	    }
	    
	    if(pSiteNo != null && pSiteNo.length() > 0 )
	    {
	    	lParameters.add(pSiteNo);
	    	lTypes.add(new Integer(Types.CHAR));
	    	lQuery.append(" AND GROUP_DS.EMPL_GRP_SITE_ID_NO = ? ");	    	
	    }
	    
	    logger.debug("getBusinessProgramTOs query="+lQuery.toString());
	    logger.debug("with Parameters  = "+pTargetQualificationYear + ", " + pProgramCode + ", " + pGroupNo + ", " + pSiteNo );
		
        //	Convert the parameter and types ArrayLists to arrays of primitive types. 
	    Object params[] = new Object[lParameters.size()];
	    lParameters.toArray(params);

	    int types[] = new int[lTypes.size()];
	    for(int j = 0; j < lTypes.size(); j++)
	    {
	    	types[j] = ((Integer)lTypes.get(j)).intValue();
	    }
		
		JdbcTemplate template = getJdbcTemplate();		
		
		lBusinessProgramTOs = (ArrayList<BusinessProgramTO>)
		    template.query(lQuery.toString(), params, types, new GroupProgramTORowMapper());
		
		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
		
		return lBusinessProgramTOs;
	}
	
	/**
	 * Fetch a list of business programs who have two days left to set their membership process flag.
	 * 
	 * @return
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<BusinessProgramTO> getBusinessProgramsForMembership(boolean pReadyForMembership)
	{
		final ArrayList<BusinessProgramTO> lBusinessProgramTOs;
		
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectBusinessProgramsForMembership);
		
		// Send an email if membership process date is within 1 or 2 days.
		if(pReadyForMembership == false)
		{
		    lQuery.append(" AND trunc(SYSDATE) BETWEEN trunc(biz.eff_dt) AND trunc(biz.pgm_end_dt)");
		    lQuery.append(" AND (trunc(SYSDATE) + interval '1' DAY = trunc(biz.MBRSHP_PRCS_DT) ");
		    lQuery.append("  OR  trunc(SYSDATE) + interval '2' DAY = trunc(biz.MBRSHP_PRCS_DT) ");
		    lQuery.append("     )");
		}
		else
		{
			// For the ones that are already set, send ones that have been set within the past two days.
			lQuery.append(" AND biz.MBRSHP_PRCS_FLG = 'Y' ");
			lQuery.append(" AND biz.MBRSHP_PRCS_DT > (SYSDATE - 2) ");
		}
		
		lQuery.append(" order by biz.mbrshp_prcs_dt asc, GROUP_DS.EMPL_GRP_NO asc, GROUP_DS.EMPL_GRP_NM, GROUP_DS.EMPL_GRP_SITE_ID_NO asc, GROUP_DS.EMPL_GRP_SITE_NM asc");
		

	    Object params[] = new Object[] { };
		int types[] = new int[] { };
		
		JdbcTemplate template = getJdbcTemplate();		
		
		lBusinessProgramTOs = (ArrayList<BusinessProgramTO>)
		    template.query(lQuery.toString(), params, types, new GroupProgramTORowMapper());
	
		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
		
		return lBusinessProgramTOs;
	}		
	
	/**
	 * Updates the membership status flag if the current date is the membership status date.
	 * 
	 * @return
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public long updateMembershipStatusFlag()
	throws DataAccessException
	{				
		JdbcTemplate template = getJdbcTemplate();

		Object params[] = new Object[] { };
		int types[] = new int[] { };
		
		return template.update(updateMembershipProcessFlag, params, types);				
	}
	
	/**
	 * Returns a Collection of Integers containing distinct Benefit Years for the given
	 * program ID and person ID.
	 *
	 * @return
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<Integer> getQualificationYears(String pProgramCode)
	{
	    final ArrayList<Integer> lQualificationYears = new ArrayList<Integer>();
	    
	    StringBuffer lQuery = new StringBuffer();
	    lQuery.append(selectAllQualificationYears);
	    
	    ArrayList<Object> lParameters = new ArrayList<Object>();
	    ArrayList<Integer> lTypes = new ArrayList<Integer>();
	    
		JdbcTemplate template = getJdbcTemplate();		
		
		if(pProgramCode != null && pProgramCode.length() >0 && Integer.parseInt(pProgramCode) > 0)
	    {
	       lParameters.add(pProgramCode);
	       lTypes.add(new Integer(Types.CHAR));
	       lQuery.append(" WHERE BIZ_PGM_TP_CD= ? ");   
	    }
		
		
		Object params[] = new Object[lParameters.size()];
	    lParameters.toArray(params);

	    int types[] = new int[lTypes.size()];
	    for(int j = 0; j < lTypes.size(); j++)
	    {
	    	types[j] = ((Integer)lTypes.get(j)).intValue();
	    }
		
		template.query(lQuery.toString(), params, types, new RowCallbackHandler() 
		{
			public void processRow(ResultSet rs) throws SQLException 
			{
				Integer lQualificationYear = rs.getInt("qualification_year");
				lQualificationYears.add(lQualificationYear);				
		    }
		});
		
		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
		
		return lQualificationYears;
	}
	
	/**
	 * Returns a Collection of business program records as they relate to Group, Site, Year
	 * to be sent on to the GrpSiteYrStage cache projection table.
	 * 
	 * 
	 * @return
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<GroupSiteYearStage> getBPMGroupSiteYear()
	{
	    final ArrayList<GroupSiteYearStage> lGroupSiteYears = new ArrayList<GroupSiteYearStage>();
	    
		JdbcTemplate template = getJdbcTemplate();		
		Object params[] = new Object[] { };
		int types[] = new int[] { };
		
		template.query(selectBPMGroupSiteYear, params, types, new RowCallbackHandler() 
		{
			public void processRow(ResultSet rs) throws SQLException 
			{	
				GroupSiteYearStage lGroupSiteYear = new GroupSiteYearStage();
				lGroupSiteYear.setGroupNumber(rs.getInt("grp_id"));
				lGroupSiteYear.setNewHireDate(rs.getDate("new_hire_dt"));
				lGroupSiteYear.setParticipationRequiredDesc(rs.getString("part_req_desc"));
				lGroupSiteYear.setProgramType(rs.getString("program_type"));
				lGroupSiteYear.setQualificationStartDate(rs.getDate("qualfctn_start_dt"));
				lGroupSiteYear.setQualificationEndDate(rs.getDate("qualfctn_end_dt"));
				lGroupSiteYear.setProgramStartDate(rs.getDate("eff_dt"));
				lGroupSiteYear.setProgramEndDate(rs.getDate("pgm_end_dt"));
				lGroupSiteYear.setSiteNumber(rs.getInt("subgrp_id"));
				lGroupSiteYear.setMembershipProcessFlag(rs.getString("MBRSHIP_PROCESS_FLAG"));
				lGroupSiteYears.add(lGroupSiteYear);				
		    }
		});
		
		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
		
		return lGroupSiteYears;
	}
	
	/**
	 * Get all qualification years. 
	 * The boolean indicates whether or not to limit the number of previous years member 
	 * status is calculated.
	 *
	 * @return
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<Integer> getAllQualificationYears()
	{
	    final ArrayList<Integer> lQualificationYears = new ArrayList<Integer>();
	    
		JdbcTemplate template = getJdbcTemplate();		
		Object params[] = new Object[] {};
		int types[] = new int[] {};
		
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectAllQualificationYears);				
		
		template.query(lQuery.toString(), params, types, new RowCallbackHandler() 
		{
			public void processRow(ResultSet rs) throws SQLException 
			{
				Integer lQualificationYear = rs.getInt("qualification_year");
				lQualificationYears.add(lQualificationYear);				
		    }
		});
		
		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
		
		return lQualificationYears;
	}			

	/**
	 * Retrieve a list of BPMBusinessPrograms given the personID and qualification year.
	 * @param pPersonID
	 * @param pTargetQualificationYear
	 * @param limitForStatusCalculation to limit the number of previous years member status is calculated.
	 * @return
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<BPMBusinessProgram> getBPMBusinessPrograms(Integer pPersonID, 			
			Integer pTargetQualificationYear, boolean limitForStatusCalculation)
	{	
        final ArrayList<BPMBusinessProgram> lBusinessPrograms;
		
        Object params[] = new Object[] { pPersonID, pPersonID};
		int types[] = new int[] { Types.INTEGER, Types.INTEGER};
        
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectBPMBusinessProgram);
		        
		if(limitForStatusCalculation)
		{
            lQuery.append(" AND trunc(SYSDATE) <= nvl(trunc(biz.stat_calc_end_dt), '01-JAN-9999') ");		 
		}
				
        JdbcTemplate template = getJdbcTemplate();               
		
		lBusinessPrograms = (ArrayList<BPMBusinessProgram>)
		    template.query(lQuery.toString(), params, types, new BPMBusinessProgramRowMapper());

		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
		
		return lBusinessPrograms;
	}
	
	/**
	 * Retrieve a list of BPMBusinessPrograms given the personID and qualification year.
	 * @param pPersonID
	 * @param pTargetQualificationYear
	 * @param limitForStatusCalculation to limit the number of previous years member status is calculated.
	 * @return
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<BPMBusinessProgram> getBPMBusinessProgramsWTermedContract(Integer pPersonID, 			
			Integer pTargetQualificationYear, boolean limitForStatusCalculation)
	{	
        final ArrayList<BPMBusinessProgram> lBusinessPrograms;
		
        Object params[] = new Object[] { pPersonID, pPersonID};
		int types[] = new int[] { Types.INTEGER, Types.INTEGER};
        
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectBPMBusinessProgramWTermedContract);
		        
		if(limitForStatusCalculation)
		{
            lQuery.append(" AND trunc(SYSDATE) <= nvl(trunc(biz.stat_calc_end_dt), '01-JAN-9999') ");		 
		}
				
        JdbcTemplate template = getJdbcTemplate();               
		
		lBusinessPrograms = (ArrayList<BPMBusinessProgram>)
		    template.query(lQuery.toString(), params, types, new BPMBusinessProgramRowMapper());

		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
		
		return lBusinessPrograms;
	}
	
	/**
	 * Fetch a business program given the group ID.
	 *
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<BPMBusinessProgram> selectProgramTemplate(String pProgramType)
	{
	    final ArrayList<BPMBusinessProgram> lBPMBusinessPrograms = new ArrayList<BPMBusinessProgram>();
	    
		JdbcTemplate template = getJdbcTemplate();		
		Object params[] = new Object[] { pProgramType };
		int types[] = new int[] { Types.VARCHAR };
		
		template.query(selectProgramTemplate, params, types, new RowCallbackHandler() 
		{
			public void processRow(ResultSet rs) throws SQLException 
			{
				BPMBusinessProgram lBPMBusinessProgram = new BPMBusinessProgram();
				lBPMBusinessProgram.setProgramID(rs.getInt("biz_pgm_id"));
				lBPMBusinessProgram.setEffectiveDate(BPMUtils.dateToCalendar(rs.getDate("eff_dt")));
				lBPMBusinessProgram.setFamilyParticipationCodeID(rs.getInt("part_requirement_cd_id"));	
				lBPMBusinessProgram.setFamilyParticipationValue(rs.getString("lu_val"));
				lBPMBusinessProgram.setQualificationCheckmarkID(rs.getInt("QUALFCTN_CHKMRK_ID"));
				lBPMBusinessProgram.setEligiblePackageID(rs.getInt("ELIG_PGM_PKG_ID"));				
								
				lBPMBusinessPrograms.add(lBPMBusinessProgram);				
		    }
		});
		
		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
		
		return lBPMBusinessPrograms;
	}
	
	public String getSelectBusinessPrograms() {
		return selectBusinessPrograms;
	}

	public void setSelectBusinessPrograms(String selectBusinessPrograms) {
		this.selectBusinessPrograms = selectBusinessPrograms;
	}

	public String getSelectQualificationYears() {
		return selectQualificationYears;
	}

	public void setSelectQualificationYears(String selectQualificationYears) {
		this.selectQualificationYears = selectQualificationYears;
	}
	
	// Spring rowMapper class for BusinessProgramTO.
	// Retrieves the columns values from the resultSet and populates a BusinessProgramTO
	// object.
	private static final class BusinessProgramTORowMapper implements RowMapper
	{
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException 
		{
			BusinessProgramTO lBusinessProgramTO = new BusinessProgramTO();
			BusinessProgram lBusinessProgram = new BusinessProgram();
			
			lBusinessProgramTO.setProgramID(rs.getInt("biz_pgm_id"));
			
			lBusinessProgram.setProgramTypeCodeID(rs.getString("biz_pgm_tp_cd"));
			lBusinessProgram.setProgramName(rs.getString("biz_pgm_nm"));
			lBusinessProgram.setProgramDescription(rs.getString("biz_pgm_desc"));
			lBusinessProgram.setFamilyParticipationRequirement(rs.getInt("part_requirement_cd_id"));
			lBusinessProgram.setFamilyParticipationDesc(rs.getString("part_requirement_desc"));
			lBusinessProgram.setFamilyParticipationValue(rs.getString("part_requirement_value"));
			lBusinessProgram.setReleaseDate(BPMUtils.dateToCalendar(rs.getDate("pgm_release_dt")));
			lBusinessProgram.setEffectiveDate(BPMUtils.dateToCalendar(rs.getDate("eff_dt")));
			lBusinessProgram.setEndDate(BPMUtils.dateToCalendar(rs.getDate("pgm_end_dt")));
			
			lBusinessProgram.setQualificationWindowStartDate(BPMUtils.dateToCalendar(rs.getDate("qualfctn_start_dt")));
			lBusinessProgram.setQualificationWindowEndDate(BPMUtils.dateToCalendar(rs.getDate("qualfctn_end_dt")));
			
			lBusinessProgram.setAdditionalGroupProgramInfo(rs.getString("additional_info_txt"));
			
			lBusinessProgram.setBenefitYearStartDate(BPMUtils.dateToCalendar(rs.getDate("bnft_yr_start_dt")));				
			lBusinessProgram.setBenefitLevelCodeID(rs.getInt("bnft_level_cd"));
			lBusinessProgram.setBenefitLevelDesc(rs.getString("bnft_level_desc"));
			
			lBusinessProgram.setContractNumber(rs.getInt("CONTRACT_NO"));
			lBusinessProgram.setProgramAvailableDate(BPMUtils.dateToCalendar(rs.getDate("program_available_dt")));
			lBusinessProgram.setProgramAvailableEndDate(BPMUtils.dateToCalendar(rs.getDate("program_available_end_dt")));
						
			EmployerGroup lEmployerGroup = new EmployerGroup();
			lEmployerGroup.setGroupName(rs.getString("GRP_NM"));  
			lEmployerGroup.setGroupNumber(rs.getString("GRP_NO"));
			lEmployerGroup.setSiteName(rs.getString("SUBGRP_NM"));
			lEmployerGroup.setSiteNumber(rs.getString("SITE_ID_NO"));
			lEmployerGroup.setNewHireDate(BPMUtils.dateToCalendar(rs.getDate("new_hire_dt")));
			lBusinessProgram.setEmployerGroup(lEmployerGroup);							
			
			lBusinessProgramTO.setBusinessProgram(lBusinessProgram);
			
			return lBusinessProgramTO;
		}
	}
	
	private static final class AllBusinessProgramTORowMapper implements RowMapper
	{
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException 
		{
			BusinessProgramTO lBusinessProgramTO = new BusinessProgramTO();
			BusinessProgram lBusinessProgram = new BusinessProgram();
			
			lBusinessProgramTO.setProgramID(rs.getInt("biz_pgm_id"));
			
			lBusinessProgram.setProgramTypeCodeID(rs.getString("biz_pgm_tp_cd"));
			lBusinessProgram.setProgramName(rs.getString("biz_pgm_nm"));
			lBusinessProgram.setProgramDescription(rs.getString("biz_pgm_desc"));
			lBusinessProgram.setFamilyParticipationRequirement(rs.getInt("part_requirement_cd_id"));
			lBusinessProgram.setFamilyParticipationDesc(rs.getString("part_requirement_desc"));
			lBusinessProgram.setFamilyParticipationValue(rs.getString("part_requirement_value"));
			lBusinessProgram.setReleaseDate(BPMUtils.dateToCalendar(rs.getDate("pgm_release_dt")));
			lBusinessProgram.setEffectiveDate(BPMUtils.dateToCalendar(rs.getDate("eff_dt")));
			lBusinessProgram.setEndDate(BPMUtils.dateToCalendar(rs.getDate("pgm_end_dt")));
			
			lBusinessProgram.setQualificationWindowStartDate(BPMUtils.dateToCalendar(rs.getDate("qualfctn_start_dt")));
			lBusinessProgram.setQualificationWindowEndDate(BPMUtils.dateToCalendar(rs.getDate("qualfctn_end_dt")));
			
			lBusinessProgram.setAdditionalGroupProgramInfo(rs.getString("additional_info_txt"));
			
			lBusinessProgram.setBenefitYearStartDate(BPMUtils.dateToCalendar(rs.getDate("bnft_yr_start_dt")));				
			lBusinessProgram.setBenefitLevelCodeID(rs.getInt("bnft_level_cd"));
			lBusinessProgram.setBenefitLevelDesc(rs.getString("bnft_level_desc"));
			
			lBusinessProgram.setContractNumber(rs.getInt("CONTRACT_NO"));			
						
			EmployerGroup lEmployerGroup = new EmployerGroup();
			lEmployerGroup.setGroupName(rs.getString("GRP_NM"));  
			lEmployerGroup.setGroupNumber(rs.getString("GRP_NO"));
			lEmployerGroup.setSiteName(rs.getString("SUBGRP_NM"));
			lEmployerGroup.setSiteNumber(rs.getString("SITE_ID_NO"));
			lEmployerGroup.setNewHireDate(BPMUtils.dateToCalendar(rs.getDate("new_hire_dt")));
			lBusinessProgram.setEmployerGroup(lEmployerGroup);							
			
			lBusinessProgramTO.setBusinessProgram(lBusinessProgram);
			
			return lBusinessProgramTO;
		}
	}
	
	private static final class BPMBusinessProgramRowMapper implements RowMapper
	{
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException 
		{			
			BPMBusinessProgram lBusinessProgram = new BPMBusinessProgram();
			
			lBusinessProgram.setProgramID(rs.getInt("biz_pgm_id"));
			
			lBusinessProgram.setProgramTypeCodeID(rs.getString("biz_pgm_tp_cd"));
			
			lBusinessProgram.setFamilyParticipationValue(rs.getString("part_requirement_value"));
			lBusinessProgram.setSmallGroupType(rs.getString("small_group_tp"));
			
			lBusinessProgram.setEffectiveDate(BPMUtils.dateToCalendar(rs.getDate("eff_dt")));
			lBusinessProgram.setEndDate(BPMUtils.dateToCalendar(rs.getDate("pgm_end_dt")));
			lBusinessProgram.setNewHireDate(BPMUtils.dateToCalendar(rs.getDate("new_hire_dt")));
			
			lBusinessProgram.setQualificationWindowStartDate(BPMUtils.dateToCalendar(rs.getDate("qualfctn_start_dt")));
			lBusinessProgram.setQualificationWindowEndDate(BPMUtils.dateToCalendar(rs.getDate("qualfctn_end_dt")));	
			
			lBusinessProgram.setContractEffDate(BPMUtils.dateToCalendar(rs.getDate("contract_eff_dt")));
			lBusinessProgram.setContractEndDate(BPMUtils.dateToCalendar(rs.getDate("contract_end_dt")));					
			
			lBusinessProgram.setContractNumber(rs.getInt("CONTRACT_NO"));
			lBusinessProgram.setGroupID(rs.getInt("grp_id"));
			lBusinessProgram.setSubgroupID(rs.getInt("subgrp_id"));	
			
			lBusinessProgram.setGroupNumber(rs.getString("empl_grp_no"));
			lBusinessProgram.setSiteNumber(rs.getString("empl_grp_site_id_no"));	
			
			if (lBusinessProgram.getContractEndDate() != null) {
			    if (lBusinessProgram.getContractEndDate().after(lBusinessProgram.getQualificationWindowEndDate())) {
			    	lBusinessProgram.setEvaluateTermedContract(false);
			    } else {
			    	lBusinessProgram.setEvaluateTermedContract(true);
			    }
			}
			
			return lBusinessProgram;
		}
	}
	
	
	
	private static final class GroupProgramTORowMapper implements RowMapper
	{
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException 
		{
			BusinessProgramTO lBusinessProgramTO = new BusinessProgramTO();
			BusinessProgram lBusinessProgram = new BusinessProgram();
			
			lBusinessProgramTO.setProgramID(rs.getInt("biz_pgm_id"));
			
			if(rs.getDate("MBRSHP_PRCS_DT") != null)
			{
				lBusinessProgramTO.setMembershipProcessDate(BPMUtils.dateToCalendar(rs.getDate("MBRSHP_PRCS_DT")));
			}
						
			lBusinessProgram.setProgramTypeCodeID(rs.getString("biz_pgm_tp_cd"));
			lBusinessProgram.setProgramName(rs.getString("biz_pgm_nm"));
			lBusinessProgram.setProgramDescription(rs.getString("biz_pgm_desc"));
			lBusinessProgram.setBenefitYearStartDate(BPMUtils.dateToCalendar(rs.getDate("bnft_yr_start_dt")));
			
			lBusinessProgram.setQualificationWindowStartDate(BPMUtils.dateToCalendar(rs.getDate("qualfctn_start_dt")));
			lBusinessProgram.setQualificationWindowEndDate(BPMUtils.dateToCalendar(rs.getDate("qualfctn_end_dt")));
												 
			lBusinessProgram.setFamilyParticipationRequirement(rs.getInt("part_requirement_cd_id"));
			lBusinessProgram.setFamilyParticipationValue(rs.getString("part_requirement_value"));
			lBusinessProgram.setFamilyParticipationDesc(rs.getString("part_requirement_desc"));  
			
			lBusinessProgram.setReleaseDate(BPMUtils.dateToCalendar(rs.getDate("pgm_release_dt")));
			lBusinessProgram.setEffectiveDate(BPMUtils.dateToCalendar(rs.getDate("eff_dt")));
			lBusinessProgram.setEndDate(BPMUtils.dateToCalendar(rs.getDate("pgm_end_dt")));
			
			lBusinessProgram.setAdditionalGroupProgramInfo(rs.getString("additional_info_txt"));			
			lBusinessProgram.setBenefitLevelDesc(rs.getString("benefit_level_desc"));
			
			EmployerGroup lEmployerGroup = new EmployerGroup();
			lEmployerGroup.setGroupName(rs.getString("GRP_NM"));
			lEmployerGroup.setGroupNumber(rs.getString("GRP_NO"));
			lEmployerGroup.setSiteName(rs.getString("SUBGRP_NM"));
			lEmployerGroup.setSiteNumber(rs.getString("SITE_ID_NO"));
			lEmployerGroup.setNewHireDate(BPMUtils.dateToCalendar(rs.getDate("new_hire_dt")));
			lBusinessProgram.setEmployerGroup(lEmployerGroup);
			
            lBusinessProgramTO.setBusinessProgram(lBusinessProgram);
			
			return lBusinessProgramTO;
		}
	}
	
	/**
	 * Indicates whether the Healthy Benefits HA is currently (as of date of
	 * service call) available for this member. This will be True if today
	 * date is on or after the start date of the HA Completion Window and on or
	 * before the end date of the Qualification Window.
	 * 
	 * @param programID
	 * @param pTargetQualificationYear
	 * @return
	 * @throws DataAccessException
	 */
	public Collection<Integer> getHAAvailable(Integer programID,
			String pTargetQualificationYear, Calendar pCurrentDate)
			throws DataAccessException {
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectActivityAvailable);
		Object params[] = null;
		int types[] = null;
		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setBizPgmId(programID);
		namedParameter.setActivityNum(BPMConstants.ACTIVITY_HEALTHY_BENEFITS_HA);
		if (pTargetQualificationYear.equalsIgnoreCase(BPMConstants.ALL_BENEFIT_YEARS))
		{
			params = new Object[] { programID,
					BPMConstants.ACTIVITY_HEALTHY_BENEFITS_HA};
			types = new int[] { Types.INTEGER, Types.VARCHAR};

		} 
		else 
		{
			params = new Object[] { programID,
					BPMConstants.ACTIVITY_HEALTHY_BENEFITS_HA, pCurrentDate,
					};
		    types = new int[] { Types.INTEGER, Types.VARCHAR, Types.TIMESTAMP};
		    namedParameter.setpCurrentDate(pCurrentDate);
		    lQuery.append(" AND :pCurrentDate BETWEEN elig.qualfctn_early_start_dt AND biz.pgm_end_dt ");
		}

		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);


		List<Integer> lProgramIDs = namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
				new RowMapper() {
					@Override
					public Integer mapRow(ResultSet rs, int i) throws SQLException {
						return rs.getInt("biz_pgm_id");
					}

				});

		return lProgramIDs;
	}
	
	public int insertBusinessProgram(BPMBusinessProgram pBusinessProgramTO, String lUserID) throws DataAccessException
	{		
		JdbcTemplate template = getJdbcTemplate();	
			
		pBusinessProgramTO.setProgramID(businessProgramIdIncrementer.nextIntValue());
		
	    Object params[] = new Object[] 
	    {		    	
	    	pBusinessProgramTO.getProgramID(), 	
			pBusinessProgramTO.getProgramTypeCodeID(),
			pBusinessProgramTO.getFamilyParticipationValue(),
			pBusinessProgramTO.getReleaseDate(),
			pBusinessProgramTO.getEffectiveDate(),
			pBusinessProgramTO.getEndDate(),
			pBusinessProgramTO.getQualificationWindowStartDate(),
			pBusinessProgramTO.getQualificationWindowEndDate(),
			null,			
			"",
			pBusinessProgramTO.getGroupID(),
			pBusinessProgramTO.getSubgroupID(),
			pBusinessProgramTO.getNewHireDate(),
			pBusinessProgramTO.getProgramStatusCodeValue(),
			pBusinessProgramTO.getStatusCalcEndDate(),
			pBusinessProgramTO.getQualificationCheckmarkID(),
			pBusinessProgramTO.getEligiblePackageID(),
			lUserID, 
			lUserID
		};
	    
	    int types[] = new int[] { Types.INTEGER, Types.VARCHAR, Types.VARCHAR,   
	        	                      Types.DATE, Types.DATE, Types.DATE,
			                          Types.DATE, Types.DATE,
			                          Types.DATE, 
			    Types.VARCHAR, Types.INTEGER, Types.INTEGER, 
			    Types.DATE, Types.VARCHAR,
			    Types.DATE, // Status Calc End Date
			    Types.INTEGER, Types.INTEGER, // Qual checkmark, and Elig Package ID
			    Types.VARCHAR, Types.VARCHAR};
	    
	        
	    int recordCount = template.update(insertBusinessProgram, params, types);	
	    
	    if (recordCount > 0) {
	    	insertProgramChangeLog(pBusinessProgramTO.getProgramID(), lUserID);
	    }
	    
	    return recordCount;
	}
	
	
	/**
	 * Inserts an array of Business Programs at once.
	 * 
	 * @param pBusinessPrograms
	 * @return
	 * @throws DataAccessException
	 */
	public int[] insertBusinessPrograms(final ArrayList<BPMBusinessProgram> pBusinessPrograms)
	throws DataAccessException 
	{		
		int[] numberOfRowsUpdated;

		final Object objs[] = pBusinessPrograms.toArray();
		JdbcTemplate template = getJdbcTemplate();
		BatchPreparedStatementSetter setter = null;
		setter = new BatchPreparedStatementSetter() 
		{
			public int getBatchSize() 
			{
				return objs.length;
			}

			public void setValues(PreparedStatement ps, int index)
					throws SQLException {
				BPMBusinessProgram lBPMBusinessProgram = (BPMBusinessProgram) objs[index];				
				
				ps.setLong(1, new Long(businessProgramIdIncrementer.nextIntValue())); 
				ps.setString(2, lBPMBusinessProgram.getProgramTypeCodeID());
				ps.setString(3, lBPMBusinessProgram.getFamilyParticipationValue());
				ps.setDate(4, new java.sql.Date(lBPMBusinessProgram.getReleaseDate().getTimeInMillis()));
				ps.setDate(5, new java.sql.Date(lBPMBusinessProgram.getEffectiveDate().getTimeInMillis()));
				ps.setDate(6, new java.sql.Date(lBPMBusinessProgram.getEndDate().getTimeInMillis()));
				ps.setDate(7, new java.sql.Date(lBPMBusinessProgram.getQualificationWindowStartDate().getTimeInMillis()));
				ps.setDate(8, new java.sql.Date(lBPMBusinessProgram.getQualificationWindowEndDate().getTimeInMillis()));
				ps.setDate(9 ,null); // Membership Update
				ps.setString(10, ""); // Additional Info
				ps.setLong(11, lBPMBusinessProgram.getGroupID());
				ps.setLong(12, lBPMBusinessProgram.getSubgroupID());
				ps.setDate(13, new java.sql.Date(lBPMBusinessProgram.getNewHireDate().getTimeInMillis()));				
			}
		};
		numberOfRowsUpdated = template.batchUpdate(insertBusinessProgram, setter);
		
		
		return numberOfRowsUpdated;
	}
	

	private int insertProgramChangeLog(Integer programId, String pUserID)
	throws DataAccessException
	{				
		JdbcTemplate template = getJdbcTemplate();
		
		String currentDate = BPMUtils.formatDateMMddyyyy(Calendar.getInstance()); 
		String changeText = "Business Program created on  " + currentDate;
	    Object params[] = new Object[] 
	    {
    		  programChangeLogIDIncrementer.nextIntValue()	    		  
    		, programId
    		, changeText
    		, pUserID	    		  			
        };

        int types[] = new int[] { 
        		Types.INTEGER, Types.INTEGER, Types.VARCHAR, Types.VARCHAR
		};
	        
	    return template.update(insertBusinessProgramChangeLog, params, types);
	}

	/**
	 * 
	 * @return
	 */
	public Collection<BusinessProgramType> getSmallGroupTypeIDs()
	{		
		final ArrayList<BusinessProgramType> lBPMBusinessProgramTypes = new ArrayList<BusinessProgramType>();
	    
		JdbcTemplate template = getJdbcTemplate();		
		Object params[] = new Object[] { };
		int types[] = new int[] { };
		
		template.query(selectSmallGroupTypeIDs, params, types, new RowCallbackHandler() 
		{
			public void processRow(ResultSet rs) throws SQLException 
			{
				BusinessProgramType lBusinessProgramType = new BusinessProgramType();
				
				lBusinessProgramType.setProgramID(rs.getInt("biz_pgm_id"));
				lBusinessProgramType.setBusinessProgramType(rs.getString("biz_pgm_tp_cd"));
				lBusinessProgramType.setBusinessProgramTypeName(rs.getString("BIZ_PGM_NM"));
				lBusinessProgramType.setMarketIndicatorID(rs.getInt("mrkt_indctr_id"));
				lBusinessProgramType.setAuthPromoTypeCodeID(rs.getInt("auth_promo_tp_cd_id"));
				lBusinessProgramType.setAuthPromoTypeCode(rs.getString("auth_promo_tp_cd"));
				lBusinessProgramType.setRenewalDate(rs.getDate("renewal_dt"));
				lBusinessProgramType.setSetupDate(rs.getDate("setup_dt"));				
				
				lBPMBusinessProgramTypes.add(lBusinessProgramType);				
		    }
		});
		
		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
		
		return lBPMBusinessProgramTypes;	
	}
	
	/**
	 * 
	 * @return
	 */
	public Collection<MarketRequirement> gMarketIndicatorRequirements(Integer pMarketIndicatorID)
	{
        final ArrayList<MarketRequirement> lMarketIndicatorRequirements = new ArrayList<MarketRequirement>();
	    
		JdbcTemplate template = getJdbcTemplate();		
		Object params[] = new Object[] { pMarketIndicatorID };
		int types[] = new int[] { Types.INTEGER };
		
		template.query(selectMarketIndicatorRequirements, params, types, new RowCallbackHandler() 
		{
			public void processRow(ResultSet rs) throws SQLException 
			{
				MarketRequirement lMarketRequirement = new MarketRequirement(); 
				
				lMarketRequirement.setMarketIndicatorID(rs.getInt("mrkt_indctr_id"));
				lMarketRequirement.setMarketIndicatorReqID(rs.getInt("mrkt_indctr_grp_req_id"));								
				
				lMarketIndicatorRequirements.add(lMarketRequirement);				
		    }
		});
		
		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
				
		return lMarketIndicatorRequirements;
	}
	
	/**
	 * 
	 * @param pMarketIndicatorID
	 * @param lMarketIndicatorReqID
	 * @return
	 */
	public Collection<MarketRequirementDetail> getMarketRequirementDetails(Integer pMarketIndicatorID, Integer lMarketIndicatorReqID)
	{
		final ArrayList<MarketRequirementDetail> lMarketRequirementDetails = new ArrayList<MarketRequirementDetail>();
		
		JdbcTemplate template = getJdbcTemplate();		
		Object params[] = new Object[] { pMarketIndicatorID, lMarketIndicatorReqID };
		int types[] = new int[] { Types.INTEGER, Types.INTEGER };
		
		template.query(selectMarketRequirementDetails, params, types, new RowCallbackHandler() 
		{
			public void processRow(ResultSet rs) throws SQLException 
			{
				MarketRequirementDetail lMarketRequirementDetail = new MarketRequirementDetail();									
				
				lMarketRequirementDetail.setMarketIndicatorID(rs.getInt("MRKT_INDCTR_ID"));
				lMarketRequirementDetail.setMarketIndicatorReqID(rs.getInt("MRKT_INDCTR_GRP_REQ_ID"));
				lMarketRequirementDetail.setMarketIndicatorDefinitionCodeID(rs.getInt("MRKT_INDCTR_DEF_CD_ID"));
				
				lMarketRequirementDetail.setGroupBaselineColumnName(rs.getString("column_nm"));				
				lMarketRequirementDetail.setMarketIndicatorCodeValue(rs.getString("MRKT_INDCTR_DEF_SRCE_CD"));
				lMarketRequirementDetail.setLogicalOperator(rs.getString("LOGIC_OPRTR_CD"));

				lMarketRequirementDetails.add(lMarketRequirementDetail);
		    }
		});
		
		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;				
		
		return lMarketRequirementDetails;
	}
	
	/**
	 * 
	 */
	public Collection<GroupBaseline> getNewSmartStepsGroupBaseline(Collection<MarketRequirement> pMarketRequirements, Integer batchCount)
	{
		final ArrayList<GroupBaseline> lGroupBaselineGroups = new ArrayList<GroupBaseline>();
		JdbcTemplate template = getJdbcTemplate();		
		Object params[] = new Object[] { batchCount };
		int types[] = new int[] { Types.INTEGER };
		
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectNewSmartStepsGroupBaseline);
		
		if(pMarketRequirements != null && pMarketRequirements.size() > 0)
		{			
			for(MarketRequirement lMarketRequirement : pMarketRequirements)
			{
				lQuery.append(" AND ( ");
				boolean lFirstOne = true;
				for(MarketRequirementDetail lMarketRequirementDetail : lMarketRequirement.getMarketRequirementDetails())
				{
					if(lFirstOne == true)
					{
					    lQuery.append(" egbl.");
					    lQuery.append(lMarketRequirementDetail.getGroupBaselineColumnName() + " " +
					    		lMarketRequirementDetail.getLogicalOperator() +
					    		   " UPPER('" + lMarketRequirementDetail.getMarketIndicatorCodeValue() +"')");
					    lFirstOne = false;
					}
					else
					{
						lQuery.append(" OR egbl.");
					    lQuery.append(lMarketRequirementDetail.getGroupBaselineColumnName() +  " " +
					    		lMarketRequirementDetail.getLogicalOperator() + 
					    		   " UPPER('" + lMarketRequirementDetail.getMarketIndicatorCodeValue() +"')");
					}
				}
				lQuery.append(" ) ");
			}						
		}				
		
		template.query(lQuery.toString(), params, types, new RowCallbackHandler() 
		{
			public void processRow(ResultSet rs) throws SQLException 
			{
				GroupBaseline lGroupBaseline = new GroupBaseline();									
				
				lGroupBaseline.setGroupID(rs.getInt("GRP_ID"));
				lGroupBaseline.setSubGroupID(rs.getInt("SUBGRP_ID"));
				lGroupBaseline.setEffectiveDate(rs.getDate("renewal_dt"));				
				
				lGroupBaselineGroups.add(lGroupBaseline);
		    }
		});
		
		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;				
		
		return lGroupBaselineGroups;
	}
	
	  
	
	/**
	 * Finds Small Groups whose renewal dates overlap existing business programs.
	 *  
	 * @param pMarketRequirements
	 * @return
	 */
	public Collection<GroupBaseline> getAutoPopulateOverlaps(Collection<MarketRequirement> pMarketRequirements)
	{
		final ArrayList<GroupBaseline> lGroupBaselineGroups = new ArrayList<GroupBaseline>();
		JdbcTemplate template = getJdbcTemplate();		
		Object params[] = new Object[] {  };
		int types[] = new int[] {  };
		
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectAutoPopulateOverlaps);		
		
		if(pMarketRequirements != null && pMarketRequirements.size() > 0)
		{			
			for(MarketRequirement lMarketRequirement : pMarketRequirements)
			{
				lQuery.append(" AND ( ");
				boolean lFirstOne = true;
				for(MarketRequirementDetail lMarketRequirementDetail : lMarketRequirement.getMarketRequirementDetails())
				{
					if(lFirstOne == true)
					{
					    lQuery.append(" egbl_in_range.");
					    lQuery.append(lMarketRequirementDetail.getGroupBaselineColumnName() + " " +
					    		lMarketRequirementDetail.getLogicalOperator() +
					    		   " UPPER('" + lMarketRequirementDetail.getMarketIndicatorCodeValue() +"')");
					    lFirstOne = false;
					}
					else
					{
						lQuery.append(" OR egbl_in_range.");
					    lQuery.append(lMarketRequirementDetail.getGroupBaselineColumnName() +  " " +
					    		lMarketRequirementDetail.getLogicalOperator() + 
					    		   " UPPER('" + lMarketRequirementDetail.getMarketIndicatorCodeValue() +"')");
					}
				}
				lQuery.append(" ) ");				
			}						
		}
		
		lQuery.append(" ORDER BY pgm_name, empl_grp_nm ");
		
		try
		{
			template.query(lQuery.toString(), params, types, new RowCallbackHandler() 
			{
				public void processRow(ResultSet rs) throws SQLException 
				{
					GroupBaseline lGroupBaseline = new GroupBaseline();									
					
					lGroupBaseline.setGroupID(rs.getInt("GRP_ID"));
					lGroupBaseline.setSubGroupID(rs.getInt("SUBGRP_ID"));					
					lGroupBaseline.setGroupNo(rs.getString("GRP_NO"));
					lGroupBaseline.setSiteNo(rs.getString("SITE_ID_NO"));
					lGroupBaseline.setEffectiveDate(rs.getDate("renewal_dt"));
					lGroupBaseline.setProgramEffectiveDate(rs.getDate("eff_dt"));
					lGroupBaseline.setProgramEndDate(rs.getDate("pgm_end_dt"));
					lGroupBaseline.setProgramTypeName(rs.getString("pgm_name"));
					lGroupBaseline.setGroupName(rs.getString("empl_grp_nm"));
					
					lGroupBaselineGroups.add(lGroupBaseline);
			    }
			});
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
		}
		
		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;				
		
		return lGroupBaselineGroups;
	}
	

	/**
	 * 
	 */
	public Collection<AuthCode> getNewSmartStepsProgramAuthPromoCode(Integer pProgramID)
	{
        final ArrayList<AuthCode> lAuthCodes = new ArrayList<AuthCode>();
	    
		JdbcTemplate template = getJdbcTemplate();		
		Object params[] = new Object[] { pProgramID };
		int types[] = new int[] { Types.INTEGER };
		
		template.query(selectProgramAuthPromoCode, params, types, new RowCallbackHandler() 
		{
			public void processRow(ResultSet rs) throws SQLException 
			{
				AuthCode lAuthCode = new AuthCode();
				lAuthCode.setAuthCode(rs.getString("auth_cd"));
				lAuthCode.setAuthCodeTypeCode(rs.getString("auth_cd_tp"));
								
				lAuthCodes.add(lAuthCode);				
		    }
		});
		
		for(int i = 0; i < params.length; i++)
		{
		    params[i] = null;
		}
		types = null;
		
		return lAuthCodes;
	}
	

	/**
	 * Get the business program ID of the template indicated by the
	 * program type code.
	 * 
	 * @param pProgramTypeCode
	 * @return
	 */
	public Integer getTemplateBusinessProgramID(String pProgramTypeCode) 
	{		
        final ArrayList<Integer> lProgramIDs = new ArrayList<Integer>();
	    
		JdbcTemplate template = getJdbcTemplate();		
		Object params[] = new Object[] { pProgramTypeCode };
		int types[] = new int[] { Types.VARCHAR };
		
		template.query(selectTemplateBusinessProgramID, params, types, new RowCallbackHandler() 
		{
			public void processRow(ResultSet rs) throws SQLException 
			{
				Integer lProgramID = rs.getInt("biz_pgm_id");									
				
				lProgramIDs.add(lProgramID);				
		    }
		});
		
		return lProgramIDs.get(0);		
	}
	
	/**
	 * Number of template activities.
	 * 
	 * @param pProgramID
	 * @return
	 */
	public Integer getTemplateActivitiesCount(Integer pProgramID) 
	{		
        final ArrayList<Integer> lRecordCounts = new ArrayList<Integer>();
	    
		JdbcTemplate template = getJdbcTemplate();		
		Object params[] = new Object[] { pProgramID };
		int types[] = new int[] { Types.INTEGER };
		
		template.query(selectTemplateActivitiesCount, params, types, new RowCallbackHandler() 
		{
			public void processRow(ResultSet rs) throws SQLException 
			{
				Integer lRecordCount = rs.getInt("record_count");									
				
				lRecordCounts.add(lRecordCount);				
		    }
		});
		
		return lRecordCounts.get(0);		
	}
	
	/**
	 * 
	 */
	public Integer getTemplateAuthCodesCount(Integer pProgramID) 
	{		
        final ArrayList<Integer> lRecordCounts = new ArrayList<Integer>();
	    
		JdbcTemplate template = getJdbcTemplate();		
		Object params[] = new Object[] { pProgramID };
		int types[] = new int[] { Types.INTEGER };
		
		template.query(selectTemplateAuthCodesCount, params, types, new RowCallbackHandler() 
		{
			public void processRow(ResultSet rs) throws SQLException 
			{
				Integer lRecordCount = rs.getInt("record_count");									
				
				lRecordCounts.add(lRecordCount);				
		    }
		});
		
		return lRecordCounts.get(0);		
	}
	
	/**
	 * 
	 * @param pProgramID
	 * @return
	 */
	public Integer getTemplateIncentivesCount(Integer pProgramID) 
	{		
        final ArrayList<Integer> lRecordCounts = new ArrayList<Integer>();
	    
		JdbcTemplate template = getJdbcTemplate();		
		Object params[] = new Object[] { pProgramID };
		int types[] = new int[] { Types.INTEGER };
		
		template.query(selectTemplateIncentivesCount, params, types, new RowCallbackHandler() 
		{
			public void processRow(ResultSet rs) throws SQLException 
			{
				Integer lRecordCount = rs.getInt("record_count");									
				
				lRecordCounts.add(lRecordCount);				
		    }
		});
		
		return lRecordCounts.get(0);		
	}
	
	/**
	 * 
	 * @param pProgramID
	 * @return
	 */
	public Integer getTemplateCheckmarkCount(Integer pProgramID) 
	{		
        final ArrayList<Integer> lRecordCounts = new ArrayList<Integer>();
	    
		JdbcTemplate template = getJdbcTemplate();		
		Object params[] = new Object[] { pProgramID };
		int types[] = new int[] { Types.INTEGER };
		
		template.query(selectTemplateCheckmarkCount, params, types, new RowCallbackHandler() 
		{
			public void processRow(ResultSet rs) throws SQLException 
			{
				Integer lRecordCount = rs.getInt("record_count");									
				
				lRecordCounts.add(lRecordCount);				
		    }
		});
		
		return lRecordCounts.get(0);		
	}
	
	
	
	
	public String getSelectGroups() {
		return selectGroups;
	}

	public void setSelectGroups(String selectGroups) {
		this.selectGroups = selectGroups;
	}

	public String getSelectGroupPrograms() {
		return selectGroupPrograms;
	}

	public void setSelectGroupPrograms(String selectGroupPrograms) {
		this.selectGroupPrograms = selectGroupPrograms;
	}

	public String getSelectAllQualificationYears() {
		return selectAllQualificationYears;
	}

	public void setSelectAllQualificationYears(String selectAllQualificationYears) {
		this.selectAllQualificationYears = selectAllQualificationYears;
	}

	public String getSelectBPMGroupSiteYear() {
		return selectBPMGroupSiteYear;
	}

	
	public final String getSelectBPMBusinessProgram() {
		return selectBPMBusinessProgram;
	}

	public final void setSelectBPMBusinessProgram(String selectBPMBusinessProgram) {
		this.selectBPMBusinessProgram = selectBPMBusinessProgram;
	}

	
	
	public String getSelectBPMBusinessProgramWTermedContract() {
		return selectBPMBusinessProgramWTermedContract;
	}

	public void setSelectBPMBusinessProgramWTermedContract(
			String selectBPMBusinessProgramWTermedContract) {
		this.selectBPMBusinessProgramWTermedContract = selectBPMBusinessProgramWTermedContract;
	}

	public void setSelectBPMGroupSiteYear(String selectBPMGroupSiteYear) {
		this.selectBPMGroupSiteYear = selectBPMGroupSiteYear;
	}

	public final String getUpdateMembershipProcessFlag() {
		return updateMembershipProcessFlag;
	}

	public final void setUpdateMembershipProcessFlag(
			String updateMembershipProcessFlag) {
		this.updateMembershipProcessFlag = updateMembershipProcessFlag;
	}

	public final String getSelectBusinessProgramsForMembership() {
		return selectBusinessProgramsForMembership;
	}

	public final void setSelectBusinessProgramsForMembership(
			String selectBusinessProgramsForMembership) {
		this.selectBusinessProgramsForMembership = selectBusinessProgramsForMembership;
	}

	public final String getSelectActivityAvailable() {
		return selectActivityAvailable;
	}

	public final void setSelectActivityAvailable(String selectActivityAvailable) {
		this.selectActivityAvailable = selectActivityAvailable;
	}

	public DataFieldMaxValueIncrementer getBusinessProgramIdIncrementer() {
		return businessProgramIdIncrementer;
	}

	public void setBusinessProgramIdIncrementer(
			DataFieldMaxValueIncrementer businessProgramIdIncrementer) {
		this.businessProgramIdIncrementer = businessProgramIdIncrementer;
	}

	public String getInsertBusinessProgram() {
		return insertBusinessProgram;
	}

	public void setInsertBusinessProgram(String insertBusinessProgram) {
		this.insertBusinessProgram = insertBusinessProgram;
	}

	public String getSelectProgramTemplate() {
		return selectProgramTemplate;
	}

	public void setSelectProgramTemplate(String selectProgramTemplate) {
		this.selectProgramTemplate = selectProgramTemplate;
	}

	public final String getSelectAllBusinessPrograms() {
		return selectAllBusinessPrograms;
	}

	public final void setSelectAllBusinessPrograms(String selectAllBusinessPrograms) {
		this.selectAllBusinessPrograms = selectAllBusinessPrograms;
	}

	public String getSelectBusinessProgramDetail() {
		return selectBusinessProgramDetail;
	}

	public void setSelectBusinessProgramDetail(String selectBusinessProgramDetail) {
		this.selectBusinessProgramDetail = selectBusinessProgramDetail;
	}

	public String getSelectBusinessProgramsFromMemberTermedSite() {
		return selectBusinessProgramsFromMemberTermedSite;
	}

	public void setSelectBusinessProgramsFromMemberTermedSite(
			String selectBusinessProgramsFromMemberTermedSite) {
		this.selectBusinessProgramsFromMemberTermedSite = selectBusinessProgramsFromMemberTermedSite;
	}

	public String getSelectSmallGroupTypeIDs() {
		return selectSmallGroupTypeIDs;
	}

	public void setSelectSmallGroupTypeIDs(String selectSmallGroupTypeIDs) {
		this.selectSmallGroupTypeIDs = selectSmallGroupTypeIDs;
	}


	public String getSelectMarketIndicatorRequirements() {
		return selectMarketIndicatorRequirements;
	}

	public void setSelectMarketIndicatorRequirements(
			String selectMarketIndicatorRequirements) {
		this.selectMarketIndicatorRequirements = selectMarketIndicatorRequirements;
	}

	public String getSelectMarketRequirementDetails() {
		return selectMarketRequirementDetails;
	}

	public void setSelectMarketRequirementDetails(
			String selectMarketRequirementDetails) {
		this.selectMarketRequirementDetails = selectMarketRequirementDetails;
	}

	public String getSelectNewSmartStepsGroupBaseline() {
		return selectNewSmartStepsGroupBaseline;
	}

	public void setSelectNewSmartStepsGroupBaseline(
			String selectNewSmartStepsGroupBaseline) {
		this.selectNewSmartStepsGroupBaseline = selectNewSmartStepsGroupBaseline;
	}

	public String getSelectProgramAuthPromoCode() {
		return selectProgramAuthPromoCode;
	}

	public void setSelectProgramAuthPromoCode(String selectProgramAuthPromoCode) {
		this.selectProgramAuthPromoCode = selectProgramAuthPromoCode;
	}

	
	public String getSelectAutoPopulateOverlaps() {
		return selectAutoPopulateOverlaps;
	}

	public void setSelectAutoPopulateOverlaps(String selectAutoPopulateOverlaps) {
		this.selectAutoPopulateOverlaps = selectAutoPopulateOverlaps;
	}

	public String getSelectTemplateBusinessProgramID() {
		return selectTemplateBusinessProgramID;
	}

	public void setSelectTemplateBusinessProgramID(
			String selectTemplateBusinessProgramID) {
		this.selectTemplateBusinessProgramID = selectTemplateBusinessProgramID;
	}

	public String getSelectTemplateActivitiesCount() {
		return selectTemplateActivitiesCount;
	}

	public void setSelectTemplateActivitiesCount(
			String selectTemplateActivitiesCount) {
		this.selectTemplateActivitiesCount = selectTemplateActivitiesCount;
	}

	public String getSelectTemplateAuthCodesCount() {
		return selectTemplateAuthCodesCount;
	}

	public void setSelectTemplateAuthCodesCount(String selectTemplateAuthCodesCount) {
		this.selectTemplateAuthCodesCount = selectTemplateAuthCodesCount;
	}

	public String getSelectTemplateIncentivesCount() {
		return selectTemplateIncentivesCount;
	}

	public void setSelectTemplateIncentivesCount(
			String selectTemplateIncentivesCount) {
		this.selectTemplateIncentivesCount = selectTemplateIncentivesCount;
	}

	public String getSelectTemplateCheckmarkCount() {
		return selectTemplateCheckmarkCount;
	}

	public void setSelectTemplateCheckmarkCount(String selectTemplateCheckmarkCount) {
		this.selectTemplateCheckmarkCount = selectTemplateCheckmarkCount;
	}

	public void setInsertBusinessProgramChangeLog(String insertBusinessProgramChangeLog) {
		this.insertBusinessProgramChangeLog = insertBusinessProgramChangeLog;
	}

	public void setProgramChangeLogIDIncrementer(DataFieldMaxValueIncrementer programChangeLogIDIncrementer) {
		this.programChangeLogIDIncrementer = programChangeLogIDIncrementer;
	}

	
	
	
				
}
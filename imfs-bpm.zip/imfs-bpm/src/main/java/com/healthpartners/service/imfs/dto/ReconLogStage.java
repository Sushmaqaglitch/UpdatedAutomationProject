package com.healthpartners.service.imfs.dto;

import java.sql.Date;
import java.sql.Time;






public class ReconLogStage extends BaseDTO
{
	static final long serialVersionUID = 0L;
	private Integer auditLogId;
	private String appId;
	private String appEventId;
	private String appEventResultId;
	private String param1Id;
	private String param2Id;
	private String param3Id;
	private String param4Id;
	private Date runDate;
	private Time runTime;

    public ReconLogStage()
    {
    }

    public Integer getAuditLogId()
    {
        return auditLogId;
    }

    public void setAuditLogId(Integer auditLogId)
    {
        this.auditLogId = auditLogId;
    }

    public String getAppEventId()
    {
        return appEventId;
    }

    public void setAppEventId(String appEventId)
    {
        this.appEventId = appEventId;
    }

    public String getAppEventResultId()
    {
        return appEventResultId;
    }

    public void setAppEventResultId(String appEventResultId)
    {
        this.appEventResultId = appEventResultId;
    }

    public String getParam1Id()
    {
        return param1Id;
    }

    public void setParam1Id(String param1Id)
    {
        this.param1Id = param1Id;
    }

    public String getParam2Id()
    {
        return param2Id;
    }

    public void setParam2Id(String param2Id)
    {
        this.param2Id = param2Id;
    }

    public String getParam3Id()
    {
        return param3Id;
    }

    public void setParam3Id(String param3Id)
    {
        this.param3Id = param3Id;
    }

    public String getParam4Id()
    {
        return param4Id;
    }

    public void setParam4Id(String param4Id)
    {
        this.param4Id = param4Id;
    }

    public Date getRunDate()
    {
        return runDate;
    }

    public void setRunDate(Date runDate)
    {
        this.runDate = runDate;
    }

    public Time getRunTime()
    {
        return runTime;
    }

    public void setRunTime(Time runTime)
    {
        this.runTime = runTime;
    }

    public String getAppId()
    {
        return appId;
    }

    public void setAppId(String appId)
    {
        this.appId = appId;
    }
}
package com.healthpartners.service.imfs;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;

import javax.sql.DataSource;

import static java.util.Objects.requireNonNull;

@Configuration
public class BPMDatabaseConfig {


    // bpm database
    @Autowired
    private Environment env;

    @Primary
    @Bean(name = "bpmDataSource")
    public DataSource getDataSource() {
        String url = requireNonNull(env.getProperty("spring.datasource.bpm.url"));
        String username = requireNonNull(env.getProperty("spring.datasource.bpm.username"));
        String password = requireNonNull(env.getProperty("spring.datasource.bpm.password"));
        String driverClassName = requireNonNull(env.getProperty("spring.datasource.bpm.driver-class-name"));
        return DataSourceBuilder.create()
                .url(url)
                .username(username)
                .password(password)
                .driverClassName(driverClassName).build();

    }

    public static void main(String[] args) {
        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(BPMDatabaseConfig.class);
    }
}

package com.healthpartners.service.imfs.dao;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;


import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.StoredProcedureResults;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;


/**
 * Calls the Stored Procedure createSmallGroupBizPgm.
 * 
 * @author jxbourbour
 *
 */
@Configuration
public class CallDeleteTermedByGroup extends StoredProcedure 
{

    protected final Log logger = LogFactory.getLog(getClass());

    @Autowired
    DataSource bpmDataSource;


    @PostConstruct
    private void initialize() {

        setDataSource(bpmDataSource);
    }

    private static final String STORED_PROC_NAME = "deleteTermedPersonForGroup";

    public CallDeleteTermedByGroup(DataSource bpmDataSource)
    {
        super(bpmDataSource, STORED_PROC_NAME);
        
        // Input Parameter
        declareParameter(new SqlParameter("in_empl_grp_no", Types.VARCHAR));
        declareParameter(new SqlParameter("in_contract_end_dt", Types.DATE));
        
        // Output Parameters           
        declareParameter(new SqlOutParameter("out_DeletedPersons", Types.INTEGER));
        declareParameter(new SqlOutParameter("out_DeletedContracts", Types.INTEGER));
        
        compile();
    }

    /**
     * 
     * @return
     */
    public StoredProcedureResults execute(String pGroupNo, String pContractEndedAfterDate)
    {    	    	
        Map<String, Object> lInputParams = new HashMap<String, Object>(0);
        
        java.sql.Date lContractEndDate = BPMUtils.formatDateMMddyyyy(pContractEndedAfterDate);
              
        // Input        
        lInputParams.put("in_empl_grp_no", pGroupNo);
        lInputParams.put("in_contract_end_dt", lContractEndDate);
        
        Map<String, Object> lOutputParams = execute(lInputParams);
        
        StoredProcedureResults lStoredProcedureResults = new StoredProcedureResults();
                        
        if(lOutputParams.size() > 0) 
        {        	 	
        	lStoredProcedureResults.setCountDeletedPersons((Integer)lOutputParams.get("out_DeletedPersons"));
        	lStoredProcedureResults.setCountDeletedContracts((Integer)lOutputParams.get("out_DeletedContracts"));
        }                
        
        return lStoredProcedureResults;
    }

		        
}

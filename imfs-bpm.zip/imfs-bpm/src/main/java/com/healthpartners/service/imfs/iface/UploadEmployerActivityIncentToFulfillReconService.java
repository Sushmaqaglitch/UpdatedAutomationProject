package com.healthpartners.service.imfs.iface;

import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.rules.StatusCalculationCommand;


public interface UploadEmployerActivityIncentToFulfillReconService {
	
	public void processUploadEmployerActivityIncentToFulfillReconCommand(StatusCalculationCommand statusCalculationCommand) throws BPMException;

}

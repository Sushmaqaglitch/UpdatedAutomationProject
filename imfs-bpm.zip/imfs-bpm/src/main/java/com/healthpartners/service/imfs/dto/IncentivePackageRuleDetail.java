package com.healthpartners.service.imfs.dto;

import java.io.Serializable;

/**
 * 
 * @author jxbourbour
 * 
 */
public class IncentivePackageRuleDetail implements Serializable {
	static final long serialVersionUID = 0L;

	private Integer incentivePackageRuleDetailID;
	private Integer incentivePackageRuleGroupID;
	private Integer incentivePackageRuleRequirementID;
	private Integer incentivePackageRuleCodeID;
	private String  incentivePackageRuleCodeValue;
	private String	sourceCode;
	private Integer	logicOperatorCodeID;
	private String	logicOperatorCodeValue;
	

	public IncentivePackageRuleDetail() {
		super();
	}

	public Integer getIncentivePackageRuleDetailID() {
		return incentivePackageRuleDetailID;
	}

	public void setIncentivePackageRuleDetailID(Integer incentivePackageRuleDetailID) {
		this.incentivePackageRuleDetailID = incentivePackageRuleDetailID;
	}

	public Integer getIncentivePackageRuleGroupID() {
		return incentivePackageRuleGroupID;
	}

	public void setIncentivePackageRuleGroupID(Integer incentivePackageRuleGroupID) {
		this.incentivePackageRuleGroupID = incentivePackageRuleGroupID;
	}

	public Integer getIncentivePackageRuleRequirementID() {
		return incentivePackageRuleRequirementID;
	}

	public void setIncentivePackageRuleRequirementID(
			Integer incentivePackageRuleRequirementID) {
		this.incentivePackageRuleRequirementID = incentivePackageRuleRequirementID;
	}

	public Integer getIncentivePackageRuleCodeID() {
		return incentivePackageRuleCodeID;
	}

	public void setIncentivePackageRuleCodeID(Integer incentivePackageRuleCodeID) {
		this.incentivePackageRuleCodeID = incentivePackageRuleCodeID;
	}

	public String getSourceCode() {
		return sourceCode;
	}

	public void setSourceCode(String sourceCode) {
		this.sourceCode = sourceCode;
	}

	public Integer getLogicOperatorCodeID() {
		return logicOperatorCodeID;
	}

	public void setLogicOperatorCodeID(Integer logicOperatorCodeID) {
		this.logicOperatorCodeID = logicOperatorCodeID;
	}

	public String getLogicOperatorCodeValue() {
		return logicOperatorCodeValue;
	}

	public void setLogicOperatorCodeValue(String logicOperatorCodeValue) {
		this.logicOperatorCodeValue = logicOperatorCodeValue;
	}

	public final String getIncentivePackageRuleCodeValue() {
		return incentivePackageRuleCodeValue;
	}

	public final void setIncentivePackageRuleCodeValue(
			String incentivePackageRuleCodeValue) {
		this.incentivePackageRuleCodeValue = incentivePackageRuleCodeValue;
	}

			
		
}

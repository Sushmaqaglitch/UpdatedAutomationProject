package com.healthpartners.service.imfs.dto;

import com.healthpartners.service.imfs.common.BPMConstants;
import java.io.Serializable;
import java.sql.Date;

public class MemberProgramActivityIncentive  implements Serializable {

	static final long serialVersionUID = 0L;
	
	public MemberProgramActivityIncentive() {
		super();
	}

	private Integer programID;
	
	private Integer personDemographicsID;
	
	private Integer activityID;
	
	private Integer  activityIncentiveID;
	
	private Integer statusCodeID;
	
	private java.sql.Date statusDate;
	
	private String registrationID;
	
	private String insertUserId;
	
	private String modifyUserId;
	
	private java.sql.Date modifyDate;
	
	private java.sql.Date insertDate;

	public Integer getProgramID() {
		return programID;
	}

	public void setProgramID(Integer programID) {
		this.programID = programID;
	}

	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}

	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}

	public Integer getActivityID() {
		return activityID;
	}

	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}

	public Integer getActivityIncentiveID() {
		return activityIncentiveID;
	}

	public void setActivityIncentiveID(Integer activityIncentiveID) {
		this.activityIncentiveID = activityIncentiveID;
	}

	public Integer getStatusCodeID() {
		return statusCodeID;
	}

	public void setStatusCodeID(Integer statusCodeID) {
		this.statusCodeID = statusCodeID;
	}

	public java.sql.Date getStatusDate() {
		return statusDate;
	}

	public void setStatusDate(java.sql.Date statusDate) {
		this.statusDate = statusDate;
	}

	public String getRegistrationID() {
		return registrationID;
	}

	public void setRegistrationID(String registrationID) {
		this.registrationID = registrationID;
	}

	public String getInsertUserId() {
		return insertUserId;
	}

	public void setInsertUserId(String insertUserId) {
		this.insertUserId = insertUserId;
	}

	public String getModifyUserId() {
		return modifyUserId;
	}

	public void setModifyUserId(String modifyUserId) {
		this.modifyUserId = modifyUserId;
	}

	public java.sql.Date getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(java.sql.Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	public java.sql.Date getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(java.sql.Date insertDate) {
		this.insertDate = insertDate;
	}


	
	
}

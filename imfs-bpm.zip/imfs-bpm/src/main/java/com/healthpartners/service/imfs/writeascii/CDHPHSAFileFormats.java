

package com.healthpartners.service.imfs.writeascii;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.DetailHSA;
import com.healthpartners.service.imfs.dto.HeaderHSA;
import com.healthpartners.service.imfs.dto.TrailerHSA;
 
public class CDHPHSAFileFormats
{

	protected final Log logger = LogFactory.getLog(getClass());
   
   private FileWriter writer;
   
   private HeaderHSA headerHSA;
   private Collection<DetailHSA> detailHSAs;
   private TrailerHSA trailerHSA;
   
   private int recsWritten = 0;
   
  
   public void CDHPHSAFileFormats() {
	   
   }
   
  /*
   * No header and trailer record will be written for this format type.
   */
   public void processFileFormatA() {
	   Iterator iter = detailHSAs.iterator();
		
	   try {
			writeHSAHeaderFormatA(headerHSA);
			while (iter.hasNext()) {
				Object transObject = iter.next();
				
				DetailHSA detailHSA = (DetailHSA) transObject;
				writeHSADetailFormatA(detailHSA);
			}
			//writeHSATrailerFormatA(trailerHSA);
	  } catch(IOException e)
		{
		     e.printStackTrace();
	    } 
   }
   
 private void writeHSAHeaderFormatA(HeaderHSA headerHSA) throws IOException {
	 String delimiter = ",";
	
	 writer.append(BPMUtils.rightPadString("TXN_ID", 10));
	 writer.append(delimiter);
	 
	 writer.append(BPMUtils.rightPadString("FILE_SENT_DT", 12));
	 writer.append(delimiter);
	 
	 writer.append(BPMUtils.rightPadString("GROUP_NAME", 100));
	 writer.append(delimiter);
	 
	 writer.append(BPMUtils.rightPadString("HSA", 3));
	 writer.append(delimiter);
	 
	 writer.append(BPMUtils.rightPadString("CONTRACT_NO", 11));
	 writer.append(delimiter);
	 
	 writer.append(BPMUtils.rightPadString("PH_LAST_NAME", 20));
	 writer.append(delimiter);
	
	 writer.append(BPMUtils.rightPadString("PH_FIRST_NAME", 20));
	 writer.append(delimiter);
	 
	 writer.append(BPMUtils.rightPadString("PH_MI", 5));
	 writer.append(delimiter);
	 
	 writer.append(BPMUtils.rightPadString("PH_SSN", 9));
	 writer.append(delimiter);
	 
	 writer.append(BPMUtils.rightPadString("ACTIVITY_TYPE", 20));
	 writer.append(delimiter);
	 
	 writer.append(BPMUtils.rightPadString("ACTIVITY_DT", 11));
	 writer.append(delimiter);
	
	 writer.append(BPMUtils.rightPadString("CONTRIB_AMT", 11));
	 
	 writer.append('\n');
   }
 
 private void writeHSADetailFormatA(DetailHSA detailHSA) throws IOException {
	 String delimiter = ",";
	 String recordID = "";
	 
	 if (detailHSA.getRecordID() != null) {
		 recordID = BPMUtils.rightPadString(detailHSA.getRecordID(), 10);
	 } else {
		 recordID = BPMUtils.rightPadString(recordID, 10);
	 }
	 writer.append(recordID);
	 writer.append(delimiter);
	 
	 String fileDate = "";
	 if (detailHSA.getFileDate() != null) {
		 fileDate = BPMUtils.rightPadString(detailHSA.getFileDate(), 8);
	 } else {
		 fileDate = BPMUtils.rightPadString(fileDate, 8);
	 }
	 writer.append(fileDate);
	 writer.append(delimiter);
	 
	 String employerGroupName = "";
	 if (detailHSA.getEmployerGroupName() != null) {
		 employerGroupName = BPMUtils.rightPadString(detailHSA.getEmployerGroupName(), 100);
	 } else {
		 employerGroupName = BPMUtils.rightPadString(employerGroupName, 100);
	 }
	 writer.append(employerGroupName);
	 writer.append(delimiter);
	 
	 String contributionType = "";
	 if (detailHSA.getContributionType() != null) {
		 contributionType = BPMUtils.rightPadString(detailHSA.getContributionType(), 3);
	 } else {
		 contributionType = BPMUtils.rightPadString(contributionType, 3);
	 }
	 writer.append(contributionType);
	 writer.append(delimiter);
	 
	 String contractNo = "";
	 if (detailHSA.getPolicyHolderHPContractID() != null) {
		 contractNo = BPMUtils.rightPadString(detailHSA.getPolicyHolderHPContractID(), 10);
	 } else {
		 contractNo = BPMUtils.rightPadString(contractNo, 10);
	 }
	 writer.append(contractNo);
	 writer.append(delimiter);
	 
	 String lastName = "";
	 if (detailHSA.getPolicyHolderLastName() != null) {
		 lastName = BPMUtils.rightPadString(detailHSA.getPolicyHolderLastName(), 20);
	 } else {
		 lastName = BPMUtils.rightPadString(lastName, 20);
	 }
	 writer.append(lastName);
	 writer.append(delimiter);
	 
	 String firstName = "";
	 if (detailHSA.getPolicyHolderFirstName() != null) {
	     firstName = BPMUtils.rightPadString(detailHSA.getPolicyHolderFirstName(), 20);
	 } else {
		 firstName = BPMUtils.rightPadString(firstName, 20);
	 }
	 writer.append(firstName);
	 writer.append(delimiter);
	 
	 String middleInit = "";
	 if (detailHSA.getPolicyHolderMiddleInit() != null) {
		 middleInit = BPMUtils.rightPadString(detailHSA.getPolicyHolderMiddleInit(), 1);
	 } else {
		 middleInit = BPMUtils.rightPadString(middleInit, 1);
	 }
	 writer.append(middleInit);
	 writer.append(delimiter);
	 
	 String ssn = "";
	 if (detailHSA.getPolicyHolderSocialSecurityNumber() != null) {
		 ssn = BPMUtils.leftPadWZeros(detailHSA.getPolicyHolderSocialSecurityNumber(), 9);
	 } else {
		 ssn = BPMUtils.leftPadWZeros(ssn, 9);
	 }
	 
	 ssn = BPMUtils.formatSSNWHyphens(ssn);
	 
	 writer.append(ssn);
	 writer.append(delimiter);
	 
	 String activityType = "";
	 if (detailHSA.getActivityType() != null) {
		 activityType = BPMUtils.rightPadString(detailHSA.getActivityType(), 20);
	 } else {
		 activityType = BPMUtils.rightPadString(activityType, 20);
	 }
	 writer.append(activityType);
	 writer.append(delimiter);
	 
	 String activityDate = "";
	 if (detailHSA.getActivityDate() != null) {
		 activityDate = BPMUtils.rightPadString(detailHSA.getActivityDate(), 10);
	 } else {
		 activityDate = BPMUtils.rightPadString(activityDate, 10);
	 }
	 writer.append(activityDate);
	 writer.append(delimiter);
	 
	 String contributionAmount = "";
	 if (detailHSA.getContributionAmount() != null) {
		 contributionAmount = BPMUtils.rightPadString(Integer.toString(detailHSA.getContributionAmount().intValue()), 4);
	 } else {
		 contributionAmount = BPMUtils.rightPadString(contributionAmount, 4);
	 }
	 writer.append(contributionAmount);
	 
	 
	 /*String filler = "";
	 filler = rightPadString(filler, 5);
	 
	 writer.append(filler);*/
	 
	 writer.append('\n');
	 
	 recsWritten++;
	 
   }
 
 
 
 private void writeHSATrailerFormatA(TrailerHSA trailerHSA) throws IOException {
	   
	 writer.append(trailerHSA.getRecordType());
	 
	 String totalRecords = BPMUtils.rightPadString(trailerHSA.getTotalRecords(), 10);
	 writer.append(totalRecords);
	 
	 writer.append('\n');
	 
	 recsWritten++;
	 
   }
 
 
 
 
	public void setFileWriter(FileWriter writer) {
		this.writer = writer;
	}


	public void setHeaderHSA(HeaderHSA headerHSA) {
		this.headerHSA = headerHSA;
	}


	public void setDetailHSAs(Collection<DetailHSA> detailHSAs) {
		this.detailHSAs = detailHSAs;
	}


	public void setTrailerHSA(TrailerHSA trailerHSA) {
		this.trailerHSA = trailerHSA;
	}


	public int getRecsWritten() {
		return recsWritten;
	}


	public void setRecsWritten(int recsWritten) {
		this.recsWritten = recsWritten;
	}
	
	

	
	
  
}
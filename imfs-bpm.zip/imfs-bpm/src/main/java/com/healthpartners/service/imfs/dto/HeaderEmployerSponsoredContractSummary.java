package com.healthpartners.service.imfs.dto;



public class HeaderEmployerSponsoredContractSummary
{	

    public HeaderEmployerSponsoredContractSummary()
    {
    	super();
    }

    private String groupNo;    
    private String siteNo;
    private String contractNo;
    private String sumOfContributionAmount;
	public String getGroupNo() {
		return groupNo;
	}
	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}
	public String getSiteNo() {
		return siteNo;
	}
	public void setSiteNo(String siteNo) {
		this.siteNo = siteNo;
	}
	public String getContractNo() {
		return contractNo;
	}
	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}
	public String getSumOfContributionAmount() {
		return sumOfContributionAmount;
	}
	public void setSumOfContributionAmount(String sumOfContributionAmount) {
		this.sumOfContributionAmount = sumOfContributionAmount;
	}
    
    
    
}

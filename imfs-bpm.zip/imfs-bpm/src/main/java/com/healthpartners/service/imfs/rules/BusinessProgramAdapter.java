/* $Id$ */

package com.healthpartners.service.imfs.rules;

import java.util.Calendar;
import java.util.Collection;

import com.healthpartners.service.imfs.dto.AuthCode;
import com.healthpartners.service.imfs.dto.BPMBusinessProgram;
import com.healthpartners.service.imfs.dto.EligibleProgramActivity;
import com.healthpartners.service.imfs.dto.ProgramIncentiveOption;
import com.healthpartners.service.imfs.dto.QualificationCheckmark;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;



/**
 * Adapter for a <code>BusinessProgram</code> object that provides a view of
 * the data that is easier to integrate with rules decision table.
 * 
 * @author pbhenninger
 */
public class BusinessProgramAdapter {

	protected final Log logger = LogFactory.getLog(getClass());

	/*
	 * Adapted classes
	 */

	private BPMBusinessProgram businessProgram;

	private Integer businessProgramId;

	private String businessProgramTypeCodeId;
	
	private Collection<QualificationCheckmark> qualificationCheckmarks;
	
	private Collection<ProgramIncentiveOption> programIncentiveOptions;
		
	private Collection<AuthCode> extendedAuthCodes;
	private Collection<AuthCode> eligibleAuthCodes;
	
	private Collection<EligibleProgramActivity> eligibleProgramActivities;

	public BusinessProgramAdapter() {
		super();
	}

	/**
	 * contructor
	 * @param pBPMBusinessProgram
	 */
	public BusinessProgramAdapter(BPMBusinessProgram pBPMBusinessProgram) {
		super();
		
		this.businessProgram = pBPMBusinessProgram;
		this.businessProgramId = new Integer(pBPMBusinessProgram.getProgramID());
		this.businessProgramTypeCodeId = pBPMBusinessProgram.getProgramTypeCodeID();
		
	}

	/**
	 * Retrieves the business program identifier.
	 * 
	 * @return the business program identifier
	 */
	public int getId() {
		int result = businessProgramId.intValue();
		return result;
	}

	/**
	 * Returns the business program identifier.
	 * 
	 * @return the business program identifier
	 */
	public Integer getBusinessProgramId() {
		return businessProgramId;
	}

	/**
	 * Returns the family participation value (PH_ONLY, PH_AND_SPOUSE, etc.)
	 * 
	 * @return the family participation value
	 */
	public String getFamilyParticipationValue() {
		String result = null;

		if (businessProgram != null) {
			result = businessProgram.getFamilyParticipationValue();
		}

		return result;
	}



	/**
	 * Returns the new hire date for the business program's employer group.
	 * 
	 * @return the new hire date
	 */
	public Calendar getNewHireDate() {
		Calendar newHireDate = null;

		if (businessProgram != null) {			
				newHireDate = businessProgram.getNewHireDate();			
		}

		return newHireDate;
	}

	/**
	 * @return the businessProgram
	 */
	public BPMBusinessProgram getBusinessProgram() {
		return businessProgram;
	}

	public String getBusinessProgramTypeCodeId() {
		return businessProgramTypeCodeId;
	}

	public void setBusinessProgramTypeCodeId(String businessProgramTypeCodeId) {
		this.businessProgramTypeCodeId = businessProgramTypeCodeId;
	}

	public final Collection<QualificationCheckmark> getQualificationCheckmarks() {
		return qualificationCheckmarks;
	}

	public final void setQualificationCheckmarks(
			Collection<QualificationCheckmark> qualificationCheckmarks) {
		this.qualificationCheckmarks = qualificationCheckmarks;
	}

	public Collection<ProgramIncentiveOption> getProgramIncentiveOptions() {
		return programIncentiveOptions;
	}

	public void setProgramIncentiveOptions(
			Collection<ProgramIncentiveOption> programIncentiveOptions) {
		this.programIncentiveOptions = programIncentiveOptions;
	}

	

	public Collection<AuthCode> getExtendedAuthCodes() {
		return extendedAuthCodes;
	}

	public void setExtendedAuthCodes(Collection<AuthCode> extendedAuthCodes) {
		this.extendedAuthCodes = extendedAuthCodes;
	}

	public Collection<AuthCode> getEligibleAuthCodes() {
		return eligibleAuthCodes;
	}

	public void setEligibleAuthCodes(Collection<AuthCode> eligibleAuthCodes) {
		this.eligibleAuthCodes = eligibleAuthCodes;
	}

	public Collection<EligibleProgramActivity> getEligibleProgramActivities() {
		return eligibleProgramActivities;
	}

	public void setEligibleProgramActivities(
			Collection<EligibleProgramActivity> eligibleProgramActivities) {
		this.eligibleProgramActivities = eligibleProgramActivities;
	}
	
	public boolean isEligibleProgramActivityOverrideExist() {
		boolean overrideExists = false;
		for (EligibleProgramActivity eligibleProgramActivity : eligibleProgramActivities) {
			if (eligibleProgramActivity.getIncentiveOverrideCodeID() != null && eligibleProgramActivity.getIncentiveOverrideCodeID() > 0) {
				overrideExists = true;
				break;
			}
		}
		
		return overrideExists;
	}	
	
}

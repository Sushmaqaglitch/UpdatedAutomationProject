package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.util.Calendar;

/**
 * Represents an Employer Group. 
 */
public class EmployerGroup implements Serializable
{	
	static final long serialVersionUID = 0L;

	private String groupNumber;
	private String groupName;
	
	private String siteNumber;
	private String siteName;
	
	private String packageNumber;
	private String packageName;		
	private Calendar newHireDate;
	
	private Integer groupID;

	public EmployerGroup() 
	{
		super();
	}

	public String getGroupName() {
		return groupName;
	}


	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}


	public String getGroupNumber() {
		return groupNumber;
	}


	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}


	public String getPackageName() {
		return packageName;
	}


	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}


	public String getPackageNumber() {
		return packageNumber;
	}


	public void setPackageNumber(String packageNumber) {
		this.packageNumber = packageNumber;
	}


	public String getSiteName() {
		return siteName;
	}


	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}


	public String getSiteNumber() {
		return siteNumber;
	}


	public void setSiteNumber(String siteNumber) {
		this.siteNumber = siteNumber;
	}

	public Calendar getNewHireDate() {
		return newHireDate;
	}

	public void setNewHireDate(Calendar newHireDate) {
		this.newHireDate = newHireDate;
	}

	public Integer getGroupID() {
		return groupID;
	}

	public void setGroupID(Integer groupID) {
		this.groupID = groupID;
	}

	
		
}

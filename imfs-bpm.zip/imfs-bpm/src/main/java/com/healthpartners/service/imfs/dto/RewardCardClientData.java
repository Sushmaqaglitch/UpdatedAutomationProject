package com.healthpartners.service.imfs.dto;

public class RewardCardClientData extends BaseDTO
{
	static final long serialVersionUID = 0L;

	private Integer rewardCardClientContactID;
	private String companyName;
	private String contactName;
	private String addressLine1;
	private String addressLine2;
	private String city;
	private String state;
	private String zip;
	private String taxID;
	
	public RewardCardClientData()
	{
		super();
	}

	public final String getCompanyName() {
		return companyName;
	}

	public final void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public final String getContactName() {
		return contactName;
	}

	public final void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public final String getAddressLine1() {
		return addressLine1;
	}

	public final void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public final String getAddressLine2() {
		return addressLine2;
	}

	public final void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public final String getCity() {
		return city;
	}

	public final void setCity(String city) {
		this.city = city;
	}

	public final String getState() {
		return state;
	}

	public final void setState(String state) {
		this.state = state;
	}

	public final String getZip() {
		return zip;
	}

	public final void setZip(String zip) {
		this.zip = zip;
	}

	public final String getTaxID() {
		return taxID;
	}

	public final void setTaxID(String taxID) {
		this.taxID = taxID;
	}

	public final Integer getRewardCardClientContactID() {
		return rewardCardClientContactID;
	}

	public final void setRewardCardClientContactID(Integer rewardCardClientContactID) {
		this.rewardCardClientContactID = rewardCardClientContactID;
	}

	@Override
	public String toString()
	{
		return companyName + ", " +
		contactName + ", " +
		addressLine1 + ", " +
		addressLine2 + ", " +
		city + ", " +
		state + ", " +
		zip + ", " +
		taxID;
	}
	
	
}

package com.healthpartners.service.imfs.dto;

public class StoredProcedureResults extends BaseDTO 
{	
	static final long serialVersionUID = 0L;
	
	private Integer countBefore;
	private Integer countAfter;
	private Integer countUpdate;
	
	private Integer countDeletedPersons;
	private Integer countDeletedContracts;
	
	public StoredProcedureResults()
	{
		super();
	}

	public Integer getCountBefore() {
		return countBefore;
	}

	public void setCountBefore(Integer pCountBefore) {
		this.countBefore = pCountBefore;
	}

	public Integer getCountAfter() {
		return countAfter;
	}

	public void setCountAfter(Integer countAfter) {
		this.countAfter = countAfter;
	}

	public Integer getCountUpdate() {
		return countUpdate;
	}

	public void setCountUpdate(Integer countUpdate) {
		this.countUpdate = countUpdate;
	}

	public Integer getCountDeletedPersons() {
		return countDeletedPersons;
	}

	public void setCountDeletedPersons(Integer countDeletedPersons) {
		this.countDeletedPersons = countDeletedPersons;
	}

	public Integer getCountDeletedContracts() {
		return countDeletedContracts;
	}

	public void setCountDeletedContracts(Integer countDeletedContracts) {
		this.countDeletedContracts = countDeletedContracts;
	}

	
	
		
}

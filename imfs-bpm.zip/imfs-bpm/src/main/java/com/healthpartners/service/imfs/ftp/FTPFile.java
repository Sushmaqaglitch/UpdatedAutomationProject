

package com.healthpartners.service.imfs.ftp;

import java.io.File;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.healthpartners.service.imfs.dto.LookUpValueCode;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.iface.LookUpValueService;


 
public class FTPFile 
{
    protected final Log logger = LogFactory.getLog(getClass());
   
	private String inputDir;
	
	private String processedDir;
	
	private String outputFTPDir;

	
	private String user;
	private String password;
	private String ftpServerDomain;
	private boolean enterRemotePassiveMode = false;
	private boolean enterLocalPassiveMode = false;
	
	//LookUpValueService lookUpValueService;
 
   public void sendFTPFile() throws BPMException 
   {
	   String failureReason;
	   FTPClient ftp = new FTPClient();
      
       
	  logger.info("FTPFile.sendFTPFile called ");       
       try {
	       if(ftpServerDomain == null || ftpServerDomain.isEmpty()) {
	           failureReason = "FTP domain not set.";
	           logger.error(failureReason);
				   throw new BPMException(failureReason);
	                   
	       }
	     
	       else {
	        
	               // get each file
	              
	               File originalFile = new File(inputDir);
	               String[] files = originalFile.list();
	               
	               if(files == null || files.length == 0) {
	                   failureReason = "No files exist.";
	                   logger.error(failureReason);
	       			   throw new BPMException(failureReason);
	               }
	               else {
	                       boolean filesSent = false;                		                        
	                       for(String file : files) {
	                    	   logger.info("FTPFile.sendFTPFile: file to be processed " + file);     
	                           FileInputStream in = new FileInputStream(originalFile.getPath() + "/" + file);
	                           logger.info("FTPFile.sendFTPFile: file input stream established"); 
	                       try {
	                           if(!ftp.isConnected()) {
	                               ftp.connect(ftpServerDomain);
	                               ftp.login(user, password);
	                               if (isEnterRemotePassiveMode()) {
	                            	   ftp.enterRemotePassiveMode();
	                            	   logger.info("FTPFile.sendFTPFile: remote passive mode set."); 
	                               } else if (isEnterLocalPassiveMode()) {
	                            	   ftp.enterLocalPassiveMode();
	                            	   logger.info("FTPFile.sendFTPFile: local passive mode set."); 
	                               } else {
	                            	   logger.info("FTPFile.sendFTPFile: passive mode not set."); 
	                               }
	                               
	                               logger.info("Connected to: " + ftpServerDomain);
	                               logger.info(ftp.getReplyString());
	                           }
	                           
	                           if(!FTPReply.isPositiveCompletion(ftp.getReplyCode())) {
	                               ftp.disconnect();
	                               failureReason = "WINFTP closed FTP connection with reply code: " + ftp.getReplyCode();
	                               logger.error(failureReason);
	                   			   throw new BPMException(failureReason);
	                           }
	                           else {
	                               	                               
	                               logger.info("Ftping : " + file);
	                               ftp.setFileType(FTP.BINARY_FILE_TYPE); 
	                               if (outputFTPDir != null) {
	                            	   ftp.changeWorkingDirectory(outputFTPDir);
	                            	   ftp.storeFile(file, in);  
	                               } else {
	                            	   ftp.storeFile(file, in);
	                               }
	                               
	                               DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
	                               Date date = Calendar.getInstance().getTime();
                                   String today = formatter.format(date);
	                               String renamedFileDir = processedDir + "processed-" + today + "/";
	                               File renamedFile = new File(renamedFileDir, file);
	                               if((new File(renamedFileDir).mkdirs())) {
                                       logger.info("Created directory: " + renamedFile.getPath());
                                   }
	                               if(originalFile.renameTo(renamedFile)) {
                                       logger.info("Moved " + originalFile.getPath() + " to " + renamedFile.getPath());
                                   } else {
                                       logger.error("Can not move file " + originalFile.getPath() + " to " + renamedFile.getPath());
                                   }
                                }
	                                                              
	                           
	                       } catch (IOException e) {
	                        	    e.printStackTrace();
	                       } 
	              }
	                       
	                       
           }
           if(ftp.isConnected()) {
               ftp.disconnect();
     
           }
          
           
           logger.info("File ftped.....");
        
		} 
       }catch (Exception e) {
			  logger.error(e.getMessage(), e);
			  failureReason = e.getMessage();
   
			   throw new BPMException(failureReason);
		}
       }

	public void setUser(String user) {
		this.user = user;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}

	public void setFtpServerDomain(String ftpServerDomain) {
		this.ftpServerDomain = ftpServerDomain;
	}

	public String getInputDir() {
		return inputDir;
	}

	public String getProcessedDir() {
		return processedDir;
	}

	public String getFtpServerDomain() {
		return ftpServerDomain;
	}

	public String getOutputFTPDir() {
		return outputFTPDir;
	}

	public void setOutputFTPDir(String outputFTPDir) {
		this.outputFTPDir = outputFTPDir;
	}

	public void setInputDir(String inputDir) {
		this.inputDir = inputDir;
	}

	public void setProcessedDir(String processedDir) {
		this.processedDir = processedDir;
	}

	public boolean isEnterRemotePassiveMode() {
		return enterRemotePassiveMode;
	}

	public void setEnterRemotePassiveMode(boolean enterRemotePassiveMode) {
		this.enterRemotePassiveMode = enterRemotePassiveMode;
	}

	public boolean isEnterLocalPassiveMode() {
		return enterLocalPassiveMode;
	}

	public void setEnterLocalPassiveMode(boolean enterLocalPassiveMode) {
		this.enterLocalPassiveMode = enterLocalPassiveMode;
	}

	
	
	
	
	
	
	
		       
  /* public void setLookUpValueService(LookUpValueService service) {
	    this.lookUpValueService = service;
	}*/	
   
   
		
	
   }  
	   
  
package com.healthpartners.service.imfs.dao;

import java.util.Collection;

import com.healthpartners.service.imfs.dto.TaskEvent;
import org.springframework.dao.DataAccessException;


/**
 * @author tjquist
 * 
 */
public interface TaskEventLogDAO {

	/**
	 * inserts TaskEvent
	 *
	 * @return long activityEventLogID
	 * @throws DataAccessException
	 */
	public Long insertTaskEventLog(TaskEvent taskEvent)
			throws DataAccessException;

	/**
	 * updates TaskEvent Log for processing status
	 * 
	 * @param taskEvent
	 * @return number of rows updated
	 * @throws DataAccessException
	 */
	public int updateTaskEventLogProcessingStatus(TaskEvent taskEvent)
			throws DataAccessException;

	/**
	 * getTaskEvents
	 * 
	 * @param personId
	 * @param programID
	 * @return Collection<TaskEvent>
	 * @throws DataAccessException
	 */
	public Collection<TaskEvent> getTaskEvents(Integer personId,
			Integer programID) throws DataAccessException;

	/**
	 * pendinging Task Events Log IDs
	 * 
	 * @return Collection<Long> ID
	 * @throws DataAccessException
	 */
	public Collection<Long> getPendingTaskEventLogIDs(int batchSize)
			throws DataAccessException;

	public int getNumberOfPendingTaskEvents() throws DataAccessException;

	/**
	 * getTaskEvent
	 * 
	 * @param taskEventLogID
	 * @return TaskEvent
	 * @throws DataAccessException
	 */
	public TaskEvent getTaskEvent(Long taskEventLogID)
			throws DataAccessException;

	/**
	 * deletes TaskEvent log
	 * 
	 * @param taskEventLogID
	 * @return number of rows deleted
	 * @throws DataAccessException
	 */
	public int deleteTaskEventLog(Long taskEventLogID)
			throws DataAccessException;
}

package com.healthpartners.service.imfs.impl;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.dao.ActivityEventLogDAO;
import com.healthpartners.service.imfs.dao.IncentiveOptionDAO;
import com.healthpartners.service.imfs.dto.*;
import com.healthpartners.service.imfs.iface.ActivityEventCreationBasedOnPreconditionService;
import com.healthpartners.service.imfs.iface.ActivityEventService;
import com.healthpartners.service.imfs.iface.EmailService;
import com.healthpartners.service.imfs.rules.StatusCalculationCommand;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.exception.BPMBusinessValidationException;
import com.healthpartners.service.imfs.exception.BPMException;




/**
 * @author tjquist
 * 
 */
@Component
@Service
public class ActivityEventCreationBasedOnPreconditionServiceImpl implements ActivityEventCreationBasedOnPreconditionService {

	 final Log logger = LogFactory.getLog(getClass());



	/**
	 * dao's references
	 */
	private ActivityEventService activityEventService;
	
	private ActivityEventLogDAO activityEventLogDAO;
	
	private IncentiveOptionDAO incentiveOptionDAO;
	
	private EmailService emailService;

	
	/**
	 * 
	 */
	public ActivityEventCreationBasedOnPreconditionServiceImpl() {
		super();
	}


	@Transactional(timeout = 300, rollbackFor = {
			DataAccessException.class,
			BPMBusinessValidationException.class, BPMException.class })
	public void processActivityEventCreationBasedOnPrecondition(StatusCalculationCommand statusCalculationCommand)
			throws BPMException, DataAccessException {
		
		
	
			// text/label
			statusCalculationCommand.setCurrentCommandText("Create Activity Event Based On Precondition");

		
			
		logger.info("@@Start - Create Activity Event Based On Precondition for group " + statusCalculationCommand.getGroupNo());	
		
		
		if (statusCalculationCommand.getGroupNo().equals(BPMConstants.GROUPNO_VERMEER)) {

			// determineGroupMembersEligibleToAcheiveForContractBased(statusCalculationCommand);
			//HCEREWARD-293 Vermeer switched to use member based incentives.
			determineGroupMembersEligibleToAcheiveForMemberBased(statusCalculationCommand);
		}
		
		
		
		
	}
	
	/* This method determines if Vermeer participants have completed their first incentive option (Complete HA and HS) to award them the ESP021 activity which is a
	 requirement to complete and receive the second incentive.  Contract based incentives is the driver for this method.
	*/
	
	private void determineGroupMembersEligibleToAcheiveForContractBased(StatusCalculationCommand statusCalculationCommand) {
		
		int activityEventsCreatedCount = 0;
		String failureReason = null;
		
		IncentiveOption lIncentiveOption = incentiveOptionDAO.getIncentiveOptionDefinitionByName(BPMConstants.INCENTIVE_OPTION_TYPE_NAME_DESC_NAME_PREMIUM_DISCOUNT_I);
		
		
		Collection<IncentivesAchievedSummaryByIncentiveOption> lContractIncentivesAchievedSummaryByIncentiveOption = incentiveOptionDAO.getContractIncentivesAchievedByProgramIncentiveOptionSummary(BPMConstants.GROUPNO_VERMEER);
		
		
		try {
			activityEventsCreatedCount = activityEventService.insertMemberActivityBasedOnPreconditionByGroup(BPMConstants.GROUPNO_VERMEER, BPMConstants.SITENO_VERMEER, lIncentiveOption, BPMConstants.ACTIVITY_SOURCE_ID_ESP021);
		} catch (DataAccessException de) {
			failureReason = "DataException detected: " + de;
			logger.error("DataException error thrown in method determineVermeerMembersEligibleToAcheive: " + de);
		} catch (Exception e) {
			failureReason = "Exception detected: " + e;
			logger.error("Exception error thrown in method determineVermeerMembersEligibleToAcheive: " + e);
		} 
	
		try {
			generateSummaryReportWithEmail(statusCalculationCommand, lContractIncentivesAchievedSummaryByIncentiveOption, activityEventsCreatedCount, failureReason);
		} catch (BPMException be) {
			failureReason = "BPMException detected: " + be;
			logger.error("BPMException error thrown in method generateSummaryReportWithEmail: " + be);
		} catch (Exception e) {
			failureReason = "Exception detected: + e";
			logger.error("Exception error thrown in method generateSummaryReportWithEmail: " + e);
		} 
	
		logger.info("determineVermeerMembersEligibleToAcheive: number of Vermeer Member Activities created: " + activityEventsCreatedCount);
	}

	/* This method determines if Vermeer participants have completed their first incentive option (Complete HA and HS) to award them the ESP021 activity which is a
	 requirement to complete and receive the second incentive.  Member based incentives is the driver for this method.
	*/

	private void determineGroupMembersEligibleToAcheiveForMemberBased(StatusCalculationCommand statusCalculationCommand) {

		int activityEventsCreatedCount = 0;
		String failureReason = null;

		IncentiveOption lIncentiveOption = incentiveOptionDAO.getIncentiveOptionDefinitionByName(BPMConstants.INCENTIVE_OPTION_TYPE_NAME_DESC_NAME_PREMIUM_DISCOUNT_I);


		Collection<IncentivesAchievedSummaryByIncentiveOption> lMemberIncentivesAchievedSummaryByIncentiveOption = incentiveOptionDAO.getMemberIncentivesAchievedByProgramIncentiveOptionSummary(BPMConstants.GROUPNO_VERMEER);


		try {
			activityEventsCreatedCount = activityEventService.insertMemberActivityBasedOnPreconditionByGroup(BPMConstants.GROUPNO_VERMEER, BPMConstants.SITENO_VERMEER, lIncentiveOption, BPMConstants.ACTIVITY_SOURCE_ID_ESP021);
		} catch (DataAccessException de) {
			failureReason = "DataException detected: " + de;
			logger.error("DataException error thrown in method determineVermeerMembersEligibleToAcheive: " + de);
		} catch (Exception e) {
			failureReason = "Exception detected: " + e;
			logger.error("Exception error thrown in method determineVermeerMembersEligibleToAcheive: " + e);
		}

		try {
			generateSummaryReportWithEmail(statusCalculationCommand, lMemberIncentivesAchievedSummaryByIncentiveOption, activityEventsCreatedCount, failureReason);
		} catch (BPMException be) {
			failureReason = "BPMException detected: " + be;
			logger.error("BPMException error thrown in method generateSummaryReportWithEmail: " + be);
		} catch (Exception e) {
			failureReason = "Exception detected: + e";
			logger.error("Exception error thrown in method generateSummaryReportWithEmail: " + e);
		}

		logger.info("determineVermeerMembersEligibleToAcheive: number of Vermeer Member Activities created: " + activityEventsCreatedCount);
	}
	
	/*
	 * Produce email notification with summary of activities created based on the precondition that a program incentive option was acheived.
	 *  
	 */
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	private void generateSummaryReportWithEmail(StatusCalculationCommand statusCalculationCommand, Collection<IncentivesAchievedSummaryByIncentiveOption> lIncentivesAchievedSummaryByIncentiveOption,  int activityEventsCreatedCount, String failureReason) throws BPMException
		{
			logger.info("@Start - processActivityEventBasedOnPreconditions. ");
			
			
			StringBuffer batchMailSubject = new StringBuffer();
			StringBuffer batchMailContent = new StringBuffer();
			
			if (statusCalculationCommand.getGroupNo().equals(BPMConstants.GROUPNO_VERMEER)) {
				batchMailSubject
				.append("BPM Batch - Create Activity Event ESP021 Based On Met Preconditions For Employer Group Vermeer - " + statusCalculationCommand.getGroupNo());
				batchMailSubject.append(" / Status");
				batchMailContent
				.append("<table>");
				batchMailContent.append("<tr><td>BPM Batch Name: Automate Activity Event Creation Based On Preconditons Met For Employer Group Vermeer</td></tr>");
			}
			
			
			
			batchMailContent.append("<tr><td>Initiated User: "
					+ statusCalculationCommand.getUserID());
			
			if (failureReason != null) {
				batchMailSubject.append("- FAILED");
				batchMailContent.append("<tr><td>Result: FAILED</td></tr>");
				batchMailContent.append("<tr></td>Reason: \n");
				batchMailContent.append(failureReason + "</td></tr>");
			} else {
				batchMailSubject.append("- SUCCESS");
				batchMailContent.append("<tr></td>Result: SUCCESS</td></tr>");
			}
			
			batchMailContent
			.append("</table>");
			
			batchMailContent
			.append("<table>");
			if (statusCalculationCommand.getGroupNo().equals(BPMConstants.GROUPNO_VERMEER)) {
				batchMailContent
				.append("<tr><td>Number of " + BPMConstants.ACTIVITY_SOURCE_ID_ESP021 + " activity event records created: " +  activityEventsCreatedCount + " </td></tr> ");
				batchMailContent
				.append("<tr><td>To date:</td></tr> ");
				if (lIncentivesAchievedSummaryByIncentiveOption.size() > 0) {
					String whichIncentiveType = null;
					for (IncentivesAchievedSummaryByIncentiveOption lIncentivesAchievedSummary : lIncentivesAchievedSummaryByIncentiveOption) {
						if (lIncentivesAchievedSummary.getContractStatusCodeName() != null) {
							whichIncentiveType = "contracts";
						} else {
							whichIncentiveType = "members";
						}

						batchMailContent
								.append("<tr>");
						batchMailContent
								.append("<ul>");
						batchMailContent
								.append("<li>" + lIncentivesAchievedSummary.getSumTotal() + " " + whichIncentiveType + " have incented for " + lIncentivesAchievedSummary.getIncentiveOptionName() + "</li>");
						batchMailContent
								.append("</ul>");
						batchMailContent
								.append("</tr>");

					}
				} else {
					batchMailContent
					.append("<tr>");
						batchMailContent
						.append("<ul>");
							batchMailContent
							.append("<li> 0 contracts/members have incented</li>");
						batchMailContent
						.append("</ul>");
					batchMailContent
					.append("</tr>");
				}
			}
			
			batchMailContent
			.append("</table>");
			
			
	    	emailService.setEmailDestination(BPMConstants.BPM_EMAIL_TO_ADDR);
	    	emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
			emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
					batchMailContent.toString());
		}
		


	public void setActivityEventService(ActivityEventService activityEventService) {
		this.activityEventService = activityEventService;
	}


	public void setIncentiveOptionDAO(IncentiveOptionDAO incentiveOptionDAO) {
		this.incentiveOptionDAO = incentiveOptionDAO;
	}


	public void setActivityEventLogDAO(ActivityEventLogDAO activityEventLogDAO) {
		this.activityEventLogDAO = activityEventLogDAO;
	}


	public void setEmailService(EmailService emailService) {
		this.emailService = emailService;
	}
	
	

}

package com.healthpartners.service.imfs.dto;

import java.util.Collection;

/**
 * @author tjquist
 * 
 */
public class MemberContractProgramTO extends BaseDTO {

	static final long serialVersionUID = 0L;

	private Integer businessProgramID;
	private Integer programIncentiveOptionID;

	private String businessProgramTypeCodeID;

	private ContractTO memberContract;

	private GenericStatusType memberStatus;
	

	private Collection<MemberActivity> memberActivities;

	private Collection<TaskEvent> memberTasks;

	/**
	 * 
	 */
	public MemberContractProgramTO() {
		super();
	}

	/**
	 * @return the businessProgramID
	 */
	public Integer getBusinessProgramID() {
		return businessProgramID;
	}
	
	

	/**
	 * @param businessProgramID
	 *            the businessProgramID to set
	 */
	public void setBusinessProgramID(Integer businessProgramID) {
		this.businessProgramID = businessProgramID;
	}

	/**
	 * @return the memberContract
	 */
	public ContractTO getMemberContract() {
		return memberContract;
	}

	/**
	 * @param memberContract
	 *            the memberContract to set
	 */
	public void setMemberContract(ContractTO memberContract) {
		this.memberContract = memberContract;
	}

	/**
	 * @return the memberStatus
	 */
	public GenericStatusType getMemberStatus() {
		return memberStatus;
	}

	/**
	 * @param memberStatus
	 *            the memberStatus to set
	 */
	public void setMemberStatus(GenericStatusType memberStatus) {
		this.memberStatus = memberStatus;
	}

	
	public String getBusinessProgramTypeCodeID() {
		return businessProgramTypeCodeID;
	}

	public void setBusinessProgramTypeCodeID(String businessProgramTypeCodeID) {
		this.businessProgramTypeCodeID = businessProgramTypeCodeID;
	}

	public Collection<MemberActivity> getMemberActivities() {
		return memberActivities;
	}

	public void setMemberActivities(Collection<MemberActivity> memberActivities) {
		this.memberActivities = memberActivities;
	}

	public Collection<TaskEvent> getMemberTasks() {
		return memberTasks;
	}

	public void setMemberTasks(Collection<TaskEvent> memberTasks) {
		this.memberTasks = memberTasks;
	}

	public Integer getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}

	public void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}

	
}

package com.healthpartners.service.imfs.dto;

/**
 * 
 * @author jxbourbour
 *
 */
public class Risk extends BaseDTO {
	
	static final long serialVersionUID = 0L;
	
	private Integer riskID;
	private String riskName;
	private String riskDesc;
	private Integer riskHoldDuration;
	private Integer riskGroupCodeID;
    private String riskGroupCodeVal;
	
    public Risk()
    {
    	super();
    }
    
    public String getRiskDesc() {
		return riskDesc;
	}
	public void setRiskDesc(String riskDesc) {
		this.riskDesc = riskDesc;
	}
	public Integer getRiskGroupCodeID() {
		return riskGroupCodeID;
	}
	public void setRiskGroupCodeID(Integer riskGroupCodeID) {
		this.riskGroupCodeID = riskGroupCodeID;
	}
	public String getRiskGroupCodeVal() {
		return riskGroupCodeVal;
	}
	public void setRiskGroupCodeVal(String riskGroupCodeVal) {
		this.riskGroupCodeVal = riskGroupCodeVal;
	}
	public Integer getRiskHoldDuration() {
		return riskHoldDuration;
	}
	public void setRiskHoldDuration(Integer riskHoldDuration) {
		this.riskHoldDuration = riskHoldDuration;
	}
	public Integer getRiskID() {
		return riskID;
	}
	public void setRiskID(Integer riskID) {
		this.riskID = riskID;
	}
	public String getRiskName() {
		return riskName;
	}
	public void setRiskName(String riskName) {
		this.riskName = riskName;
	}
    
    
}

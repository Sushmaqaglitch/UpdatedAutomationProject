package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.text.DecimalFormat;

public class Activity implements Serializable
{	
	static final long serialVersionUID = 0L;

	 // Database table ID.
	private Integer activityID;
	
	private Integer precursorID;
	private String sourceActivityID; //external system sends/recognises
	
	private Integer activityTypeCodeID;
	private String activityTypeValue;
	private String activityTypeDesc;
    private String name;
    private String precursorName;
    private String description;
    private String source;
    private Integer duration;
    private String cost;
    private String webLink;
    private String userId;
    private Integer used;
    private java.sql.Date effectiveDate;
	private java.sql.Date endDate;
	private java.sql.Date insertDate;
	private java.sql.Date modifyDate;
	private String insertUser;
	private String modifyUser;
    
        
    public Integer getUsed() {
		return used;
	}


	public void setUsed(Integer used) {
		this.used = used;
	}


	public Activity()
    {
    	super();
    }
	

	public String getCost() {
		return cost;
	}

	public void setCost(String cost) {
		
		this.cost = cost;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}	

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getWebLink() {
		return webLink;
	}

	public void setWebLink(String webLink) {
		this.webLink = webLink;
	}

	public String getPrecursorName() {
		return precursorName;
	}

	public void setPrecursorName(String precursorName) {
		this.precursorName = precursorName;
	}

	/**
	 * @return the sourceActivityID
	 */
	public String getSourceActivityID() {
		return sourceActivityID;
	}

	/**
	 * @param sourceActivityID the sourceActivityID to set
	 */
	public void setSourceActivityID(String sourceActivityID) {
		this.sourceActivityID = sourceActivityID;
	}

	public String getActivityTypeDesc() {
		return activityTypeDesc;
	}

	public void setActivityTypeDesc(String activityTypeDesc) {
		this.activityTypeDesc = activityTypeDesc;
	}

	public String getActivityTypeValue() {
		return activityTypeValue;
	}

	public void setActivityTypeValue(String activityTypeValue) {
		this.activityTypeValue = activityTypeValue;
	}
	
	public Integer getActivityID() {
		return activityID;
	}
	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}


	public Integer getActivityTypeCodeID() {
		return activityTypeCodeID;
	}


	public void setActivityTypeCodeID(Integer activityTypeCodeID) {
		this.activityTypeCodeID = activityTypeCodeID;
	}


	public Integer getPrecursorID() {
		return precursorID;
	}


	public void setPrecursorID(Integer precursorID) {
		this.precursorID = precursorID;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public java.sql.Date getEffectiveDate() {
		return effectiveDate;
	}


	public void setEffectiveDate(java.sql.Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}


	public java.sql.Date getEndDate() {
		return endDate;
	}


	public void setEndDate(java.sql.Date endDate) {
		this.endDate = endDate;
	}


	public java.sql.Date getInsertDate() {
		return insertDate;
	}


	public void setInsertDate(java.sql.Date insertDate) {
		this.insertDate = insertDate;
	}


	public java.sql.Date getModifyDate() {
		return modifyDate;
	}


	public void setModifyDate(java.sql.Date modifyDate) {
		this.modifyDate = modifyDate;
	}


	public String getInsertUser() {
		return insertUser;
	}


	public void setInsertUser(String insertUser) {
		this.insertUser = insertUser;
	}


	public String getModifyUser() {
		return modifyUser;
	}


	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}
	
	
	
}

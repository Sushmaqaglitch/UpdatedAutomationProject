package com.healthpartners.service.imfs.dto;

public class WebServiceRequest extends BaseDTO 
{	
	static final long serialVersionUID = 0L;
	
	private String memberID;
	private String programCode;
	private String targetQualificationYear;
	private int touchPointID;
	private String sourceSystemID;
	private String groupNumber;
	private String siteID;
	
	public WebServiceRequest()
	{
		super();
	}

	public String getGroupNumber() {
		return groupNumber;
	}

	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}

	public String getMemberID() {
		return memberID;
	}

	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}

	public String getProgramCode() {
		return programCode;
	}

	public void setProgramCode(String programCode) {
		this.programCode = programCode;
	}

	public String getSiteID() {
		return siteID;
	}

	public void setSiteID(String siteID) {
		this.siteID = siteID;
	}

	public String getSourceSystemID() {
		return sourceSystemID;
	}

	public void setSourceSystemID(String sourceSystemID) {
		this.sourceSystemID = sourceSystemID;
	}	
	public String getTargetQualificationYear() {
		return targetQualificationYear;
	}

	public void setTargetQualificationYear(String targetQualificationYear) {
		this.targetQualificationYear = targetQualificationYear;
	}

	public int getTouchPointID() {
		return touchPointID;
	}

	public void setTouchPointID(int touchPointID) {
		this.touchPointID = touchPointID;
	}	
}


package com.healthpartners.service.imfs.impl;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import com.healthpartners.service.imfs.factory.BPMAuditRecordFactory;
import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dao.*;
import com.healthpartners.service.imfs.dto.*;
import com.healthpartners.service.imfs.iface.ActivityEventService;
import com.healthpartners.service.imfs.iface.AuditLogService;
import com.healthpartners.service.imfs.iface.ProgramStatusCalculationService;
import com.healthpartners.service.imfs.rules.StatusCalculationCommand;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.exception.BPMBusinessValidationException;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.filter.ActivityEventFilterImpl;


@Component
@Service
public class ActivityEventServiceImpl implements
		ActivityEventService {

	protected final Logger logger = Logger.getLogger(this.getClass());

	/**
	 * services references
	 */
	private ProgramStatusCalculationService programStatusCalculationService;

	private ActivityEventFilterImpl activityEventFilter;

	/**
	 * dao's references
	 */
	@Autowired
	private ActivityEventLogDAO activityEventLogDAO;
	@Autowired
	private ActivityDAO activityDAO;
	@Autowired
	private IncentiveOptionDAO incentiveOptionDAO;
	@Autowired
	private PersonDAO personDAO;
	@Autowired
	private LookUpValueDAOJdbc lookUpValueDAO;
	@Autowired
	private AuditLogService auditLogService;
	

	/**
	 * messaging references
	 */
//	private ActivityEventGenerator activityEventGenerator;


	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public long recieveActivityEvent(ActivityEvent activityEvent)
			throws BPMBusinessValidationException, BPMException,
			DataAccessException {

		Long activityEventLogID = Long.valueOf(0);
		//DefaultTransactionDefinition def = new DefaultTransactionDefinition();
		//def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		//TransactionStatus status = txManager.getTransaction(def);
		try {


			// 1. validate,
			boolean lActivityValid = validateActivityEvent(activityEvent);

			if(lActivityValid == true)
			{
                if (isActivityEventOlderThanSpanInMonths(activityEvent)) {
                    return activityEventLogID;
                }
				// 2.log activityevent
				activityEvent
						.setProcessingStatusValue(BPMConstants.PROCESSING_STATUS_PENDING);
				activityEventLogID = activityEventLogDAO
						.insertActivityEventLog(activityEvent);
				
				// 3. generate message
//				activityEventGenerator.sendJMS(activityEventLogID);
			}
			else
			{
				activityEvent
				.setProcessingStatusValue(BPMConstants.PROCESSING_STATUS_FILTERD_OUT);				
		        activityEventLogID = activityEventLogDAO.insertActivityEventLog(activityEvent);
			}
		} catch (DataAccessException dae) {
			//txManager.rollback(status);
			logger.error("DataAccessException: " + BPMUtils.getStakTraceAsString(dae), dae);
		} catch (BPMBusinessValidationException ve) {
			//txManager.rollback(status);
			logger.error("BPMBusinessValidationException: " + BPMUtils.getStakTraceAsString(ve),
					ve);			
		} catch (BPMException ve) {
			//txManager.rollback(status);
			logger.error("BPMException: " + BPMUtils.getStakTraceAsString(ve), ve);
		} catch (NullPointerException ne) {
			logger.error("Possible bad effective status date sent: " + activityEvent.getMemberActivity().getActivityStatus().getStatusEffectiveDate().toString());
			logger.error("NullPointerException: " + BPMUtils.getStakTraceAsString(ne), ne);
		} catch (Exception e) {
			//txManager.rollback(status);
			logger.error("BPMException: " + BPMUtils.getStakTraceAsString(e), e);
		}

		return activityEventLogID.longValue();
	}

	/**
	 * 
	 */
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public void processActivityEvent(Long activityEventLogID)
			throws BPMBusinessValidationException, BPMException,
			DataAccessException {

		ActivityEvent activityEvent = null;
		String filterdIN = null;
		//DefaultTransactionDefinition def = new DefaultTransactionDefinition();
		//def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		//TransactionStatus status = txManager.getTransaction(def);
		try {

			activityEvent = activityEventLogDAO
					.getActivityEventLog(activityEventLogID);
			
			if (activityEvent == null) {
				activityEvent = new ActivityEvent();
				activityEvent.setActivityEventLogID(activityEventLogID);
				activityEvent.setModifyUserId(BPMConstants.BPM_USER_SYSTEM);
				filterdIN = BPMConstants.BPM_FILTERD_OUT_RSN_CD12_ACTIVITY_ID_NOT_FD;
			} else if (activityEvent.getMemberActivity().getRegistrationID() == null || activityEvent.getMemberActivity().getRegistrationID().length() <= 0) {
						filterdIN = BPMConstants.BPM_FILTERD_OUT_RSN_CD13_REGISTRATION_ID_MISSING;
			}
			
			
			
			// 30.update processing status
			activityEvent
					.setProcessingStatusValue(BPMConstants.PROCESSING_STATUS_INPROCESS);
			activityEventLogDAO
					.updateActivityLogProcessingStatus(activityEvent);

			// 40.Filter:activityEventFilterService.doFilter(activityEvent),
			if (filterdIN == null) { 
				filterdIN = activityEventFilter.doFilter(activityEvent);
			}

			//filterdIn of zero indicates all filtered edits were met.
			if (filterdIN.equals(BPMConstants.BPM_FILTERD_OUT_RSN_CD0_OK)) {
				// update Member Activity - into table
				// PERSON_PROGRAM_ACTIVITY_STATUS
				this.updatePersonProgramActivityStatus(activityEvent);						

				// 60. update processing statuses
				activityEvent.setProcessingStatusValue(BPMConstants.PROCESSING_STATUS_COMPLETED);
				activityEventLogDAO.updateActivityLogProcessingStatus(activityEvent);
				
				// EV 38778
				// If this is an ACTIVE, check if there is a COMPLETE that is Filtered Out.
				// If there is, send that COMPLETE to the queue to re-process.
				processFiltereOutCompletes(activityEvent);
				
				// Now that all the activities have been processed, calculate member status.
				StatusCalculationCommand statusCalculationCommand = new StatusCalculationCommand();
				statusCalculationCommand.setActivityEventCommand(activityEvent);
				programStatusCalculationService
						.updateProgramStatus(statusCalculationCommand);	
				
				// processEmployerSponsored method call will check activity for a esp contribution amount.
				// if it exists, update the incented activity with the contribution after
				// it has been added during status calcultation in the updateProgramStatus call.
				processEmployerSponsored(activityEvent);
				
			} else {
				// filterd out
				activityEvent
						.setProcessingStatusValue(BPMConstants.PROCESSING_STATUS_FILTERD_OUT);
				activityEvent
						.setReasonDescription(filterdIN);
				activityEventLogDAO
						.updateActivityLogProcessingStatus(activityEvent);
			}

			// Commit the transaction.
			//txManager.commit(status);

		} catch (DataAccessException dae) {
			//txManager.rollback(status);
			logger.error("DataAccessException: " + BPMUtils.getStakTraceAsString(dae), dae);
		} catch (Exception e) {
			//txManager.rollback(status);
			logger.error("BPMException: " + BPMUtils.getStakTraceAsString(e), e);
		}
	}

	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public void processActivityEventRealtime(ActivityEvent activityEvent) throws BPMBusinessValidationException, BPMException,
	DataAccessException {
		Long activityEventLogID = Long.valueOf(0);
		//DefaultTransactionDefinition def = new DefaultTransactionDefinition();
		//def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		//TransactionStatus status = txManager.getTransaction(def);
		try {
			// 1. validate,
			boolean lActivityEventValid = validateActivityEvent(activityEvent);
			
			if(lActivityEventValid == true)
			{
				// 2.log activityevent
				activityEvent
						.setProcessingStatusValue(BPMConstants.PROCESSING_STATUS_PENDING);
				activityEventLogID = activityEventLogDAO
						.insertActivityEventLog(activityEvent);
				
				processActivityEvent(activityEventLogID);
			}
			else
			{
				activityEvent
				.setProcessingStatusValue(BPMConstants.PROCESSING_STATUS_FILTERD_OUT);				
		        activityEventLogID = activityEventLogDAO.insertActivityEventLog(activityEvent);
			}
		} catch (DataAccessException dae) {
			//txManager.rollback(status);
			logger.error("DataAccessException: " + BPMUtils.getStakTraceAsString(dae), dae);
		} catch (BPMBusinessValidationException ve) {
			//txManager.rollback(status);
			logger.error("BPMBusinessValidationException: " + BPMUtils.getStakTraceAsString(ve),
					ve);
		} catch (BPMException ve) {
			//txManager.rollback(status);
			logger.error("BPMException: " + BPMUtils.getStakTraceAsString(ve), ve);
		} catch (Exception e) {
			//txManager.rollback(status);
			logger.error("BPMException: " + BPMUtils.getStakTraceAsString(e), e);
		}
		
	}

	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public void updatePersonProgramActivityStatus(ActivityEvent activityEvent)
			throws BPMBusinessValidationException, BPMException,
			DataAccessException {
		
		//DefaultTransactionDefinition def = new DefaultTransactionDefinition();
			//def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
			//TransactionStatus status = txManager.getTransaction(def);
			
			try {								
				// get all eligible programs from memberId, source activity id, auth
				// code.
				Collection<EligibleProgramActivity> lEligibleProgramActivities = activityDAO
						.getBusinessProgramsForActivity(activityEvent
								.getMemberActivity().getActivity()
								.getSourceActivityID(),
								activityEvent.getMemberID(), activityEvent
										.getMemberActivity().getAuthPromoCode(), 
										activityEvent.getMemberActivity().getActivityStatus().getStatusEffectiveDate());

				// update activity status for each program
				if (lEligibleProgramActivities.size() > 0) {
					Iterator<EligibleProgramActivity> itr = lEligibleProgramActivities
							.iterator();
					while (itr.hasNext()) {
						boolean isAlreadyAcheived = false;
						EligibleProgramActivity lEligibleProgramActivity = itr
								.next();
						Integer programID = lEligibleProgramActivity.getBusinessProgramID();
						
						//EV73557 - bypass if person has already achieved the list of status's found in the "if condition".
						java.sql.Date activityStatusEffectiveDate = BPMUtils.calendarToSqlDate(activityEvent.getMemberActivity().getActivityStatus().getStatusEffectiveDate());
						String sourceActivityID = activityEvent.getMemberActivity().getActivity().getSourceActivityID();
						PersonProgramActivityStatus lPersonProgramActivityStatus =
								activityDAO.getPersonProgramActivityStatus(activityEvent.getMemberID(), lEligibleProgramActivity.getBusinessProgramID(), sourceActivityID, activityStatusEffectiveDate);
						if(lPersonProgramActivityStatus != null && lPersonProgramActivityStatus.getActivityStatusCodeID() !=null)
						{
							LookUpValueCode lLookUpValueCode = lookUpValueDAO.getLUVCodeByID(lPersonProgramActivityStatus.getActivityStatusCodeID());
							
							if (lLookUpValueCode.getLuvVal().equals(BPMConstants.ACTIVITY_STATUS_COMPLETE) ||
									lLookUpValueCode.getLuvVal().equals(BPMConstants.ACTIVITY_STATUS_WAIVE) ||
									lLookUpValueCode.getLuvVal().equals(BPMConstants.ACTIVITY_STATUS_PENDING) ||
									lLookUpValueCode.getLuvVal().equals(BPMConstants.ACTIVITY_STATUS_EXEMPT)) {
								activityEvent.getMemberActivity().setBusinessProgramID(lEligibleProgramActivity.getBusinessProgramID());
								isAlreadyAcheived = true;
							}
							
						}
						
						if (isAlreadyAcheived) {
							//bypass activity updates.
						
						} else if (BPMConstants.ACTIVITY_HEALTHY_BENEFITS_HA
								.equals(lEligibleProgramActivity.getActivityName())) {
							// Count Health Assessment as a member activity for the
							// business program only if
							// a correct auth code was sent to us.
							if (activityEvent.getMemberActivity()
									.getAuthPromoCode() != null
									&& activityEvent.getMemberActivity()
											.getAuthPromoCode().equals(
													lEligibleProgramActivity
															.getAuthCode())) {
								activityEvent.getMemberActivity()
										.setBusinessProgramID(programID);							
								activityDAO.updateMemberActivity(activityEvent);
								
								// If the HA Has risk, create another participant activity for the risk outcome.
								if(activityEvent.getMemberActivity().getActivityStatus().getOutCome() != null &&
										activityEvent.getMemberActivity().getActivityStatus().getOutCome().contains(BPMConstants.MEMBER_STATUS_RSN_HIGH_RISK))
								{
									ActivityEvent lRiskActivityEvent  = createActivityEventFromHARisk(activityEvent, BPMConstants.ACTIVITY_STATUS_MET);
									activityDAO.updateMemberActivity(lRiskActivityEvent);
								}
								else if(activityEvent.getMemberActivity().getActivityStatus().getOutCome() == null ||
										activityEvent.getMemberActivity().getActivityStatus().getOutCome().length() < 1)
								{
									ActivityEvent lRiskActivityEvent  = createActivityEventFromHARisk(activityEvent, BPMConstants.ACTIVITY_STATUS_NOT_MET);
									activityDAO.updateMemberActivity(lRiskActivityEvent);
								}
							}
						}
						// COMPLETE AND WAIVE DM only counts in the program year.
						else if(activityEvent.getMemberActivity().getActivity().getActivityTypeValue().equals(BPMConstants.ACTIVITY_TYPE_DISEASE_MGMT))
						{						
							if(activityEvent.getMemberActivity().getActivityStatus().getStatusCodeValue().equals(BPMConstants.ACTIVITY_STATUS_COMPLETE) ||
							   activityEvent.getMemberActivity().getActivityStatus().getStatusCodeValue().equals(BPMConstants.ACTIVITY_STATUS_WAIVE) ||
							   activityEvent.getMemberActivity().getActivityStatus().getStatusCodeValue().equals(BPMConstants.ACTIVITY_STATUS_EXEMPT))
							{
								BPMUtils.setTimeToZero(activityEvent.getMemberActivity().getActivityStatus().getStatusEffectiveDate());
								
								if(activityEvent.getMemberActivity().getActivityStatus().getStatusEffectiveDate().after(lEligibleProgramActivity.getBusinessProgramEffectiveDate()) 
							      && activityEvent.getMemberActivity().getActivityStatus().getStatusEffectiveDate().before(lEligibleProgramActivity.getBusinessProgramEndDate()))
								{
								    activityEvent.getMemberActivity().setBusinessProgramID(lEligibleProgramActivity.getBusinessProgramID());
								    
								    activityDAO.updateMemberActivity(activityEvent);								
								}
							}
							else
							{
								activityEvent.getMemberActivity().setBusinessProgramID(lEligibleProgramActivity.getBusinessProgramID());														
							    activityDAO.updateMemberActivity(activityEvent);							
							}
						}						
						else 
						{
							// All other activities count for other business
							// programs.
							// TODO Star Tribune on-line seminar.												
							activityEvent.getMemberActivity().setBusinessProgramID(lEligibleProgramActivity.getBusinessProgramID());						
							activityDAO.updateMemberActivity(activityEvent);						
						}
					}
				}
				// Commit the transaction.
				//txManager.commit(status);		
			} catch (DataAccessException dae) {
				//txManager.rollback(status);
				logPKInfo(activityEvent);
				logger.error("DataAccessException: " + BPMUtils.getStakTraceAsString(dae), dae);
			} catch (Exception e) {
				//txManager.rollback(status);
				logger.error("BPMException: " + BPMUtils.getStakTraceAsString(e), e);
			}
	}
	
	
	/**
	 * This block of code was implemented for employer sponsored contributions.  All employer sponsored contribution activities sent into bpm
     * are considered activities that were completed by the member and are allowed their HRA/HSA contribution.  Also, passed in is 
	 * the employee's external person id.  If not already captured in the person program status table, check to see if it exits and then
	 * update the table.
	 *   
	 * @param activityEvent
	 * @throws BPMBusinessValidationException
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public void processEmployerSponsored(ActivityEvent activityEvent) throws BPMBusinessValidationException, BPMException,
	DataAccessException 
	{
		if(BPMConstants.ACTIVITY_STATUS_COMPLETE.equals(activityEvent.getMemberActivity().getActivityStatus().getStatusCodeValue())) {
			if (activityEvent.getMemberActivity().getContributionAmt() != null) {
				PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus = personDAO.getPersonPgmActivityIncentiveStatus(activityEvent);
				if (lPersonProgramActivityIncentiveStatus != null && lPersonProgramActivityIncentiveStatus.getContributionAmt() != null) {
					incentiveOptionDAO.updatePersonActivityIncentiveWithContributionAmt(activityEvent, BPMConstants.BPM_USER_SYSTEM);
				}
				Integer programID = activityEvent.getMemberActivity().getBusinessProgramID();
				Integer personDemographicsID = activityEvent.getPersonDemographicsID();
				
				MemberProgramUpdateTO lMemberProgramUpdateTO = personDAO.getMemberProgramStatusDetail(personDemographicsID, programID);
				
				if (lMemberProgramUpdateTO != null && lMemberProgramUpdateTO.getExternalPersonID() == null
						 && activityEvent.getExternalPersonID() != null) {
					personDAO.updateMemberProgramStatusExternalPersonID(personDemographicsID, programID, activityEvent.getExternalPersonID());
				}
			}
		}
	}
	
	/**
	 * Update the modification timestamp with system
	 *
	 * @throws BPMBusinessValidationException
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public void updatePersonActivityIncentiveWithModificationDate(Collection<PersonActivityIncentToFulfillReconcile> lPersonActivityIncentToFulfillReconcileDifferences) throws BPMBusinessValidationException, BPMException,
	DataAccessException 
	{
		  for (PersonActivityIncentToFulfillReconcile lPersonActivityIncentToFulfillReconcileDifference : lPersonActivityIncentToFulfillReconcileDifferences) {
			  incentiveOptionDAO.updatePersonActivityIncentiveWithModificationDate(lPersonActivityIncentToFulfillReconcileDifference, BPMConstants.BPM_USER_SYSTEM);
		  }
				
	}
	
	/**
	 * EV 38778
	 * If this is an ACTIVE, check if there is a COMPLETE that is Filtered Out.
	 * If there is, send that COMPLETE to the queue to re-process.
	 * 
	 * @param activityEvent
	 * @throws BPMBusinessValidationException
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public void processFiltereOutCompletes(ActivityEvent activityEvent) throws BPMBusinessValidationException, BPMException,
	DataAccessException 
	{
		if(BPMConstants.ACTIVITY_STATUS_ACTIVE.equals(activityEvent.getMemberActivity().getActivityStatus().getStatusCodeValue()))
		{
			ArrayList<ActivityEvent> lMemberActivityEvents = (ArrayList<ActivityEvent>)
			    activityEventLogDAO.getMemberActivityEventLogActivity(activityEvent.getMemberID()
			    		, activityEvent.getMemberActivity().getActivity().getSourceActivityID()
			    		, activityEvent.getMemberActivity().getRegistrationID());

			for(int actv = 0; actv < lMemberActivityEvents.size(); actv++)
			{
				if(activityEvent.getMemberActivity().getActivity().getSourceActivityID().equals(
						lMemberActivityEvents.get(actv).getMemberActivity().getActivity().getSourceActivityID())
				      && activityEvent.getMemberActivity().getRegistrationID().equals(lMemberActivityEvents.get(actv).getMemberActivity().getRegistrationID())
				      && (BPMConstants.PROCESSING_STATUS_FILTERD_OUT.equals(lMemberActivityEvents.get(actv).getProcessingStatusValue())
				    		  || (BPMConstants.ACTIVITY_TYPE_EMPLOYER_PGM.equals(activityEvent.getMemberActivity().getActivity().getActivityTypeValue())
				    				  && BPMConstants.ACTIVITY_STATUS_COMPLETE.equals(activityEvent.getMemberActivity().getActivityStatus().getStatusCodeValue()))
				  ))
				{
					lMemberActivityEvents.get(actv).setProcessingStatusValue(BPMConstants.PROCESSING_STATUS_PENDING);
			        activityEventLogDAO.updateActivityLogProcessingStatus(lMemberActivityEvents.get(actv));					        					        

			        processActivityEvent(lMemberActivityEvents.get(actv).getActivityEventLogID());
				}
			}
		}
	}
	
	public int insertMemberActivityBasedOnPreconditionByGroup(String groupNo, String siteNo, IncentiveOption lIncentiveOption, String sourceActivityID) throws DataAccessException
	{
		
		int activityInsertedCt = activityEventLogDAO.insertMemberActivityBasedOnPreconditionByGroup(groupNo, siteNo, lIncentiveOption.getIncentiveOptionID(), sourceActivityID);
					
		return activityInsertedCt;	
	}
	
	/*
	 * Validate that employer sponsored activity made it to the activity event log and the processing status log is in a
	 * completed status.
	 */
	public Collection<ActivityEvent> getMemberActivityEventLogActivity(String pMemberID, String pSourceActivityID, Date pActivityDate) throws BPMException {
		
		
		Collection<ActivityEvent> lActivityEvents = activityEventLogDAO.getMemberActivityEventLogActivity(pMemberID, pSourceActivityID, pActivityDate);
		
		
		return lActivityEvents;
	}
	
	public Collection<ActivityEvent> getActivityEventLogsByGroup(String groupNo, String siteNo, String memberNo, String startDateStr, String sourceSystemID) 
			throws DataAccessException {

		java.sql.Date startDate =  BPMUtils.convertStringToSqlDate(startDateStr, BPMConstants.HP_BPM_COMMON_DATE_FORMAT);
		Collection<ActivityEvent> lActivityEvents = activityEventLogDAO.getActivityEventLogsByGroup(groupNo, siteNo, memberNo, startDate, sourceSystemID);
		
		
		return lActivityEvents;
	}
	
	
	public Collection<ActivityEvent> getActivityEventLogsByProcessingStatus(String processingStatus, java.sql.Date activityEventCutoffDate, boolean twoDaysNolderFlag, String sourceSystemID) 
			throws DataAccessException {
		return activityEventLogDAO.getActivityEventLogsByProcessingStatus(processingStatus, activityEventCutoffDate, twoDaysNolderFlag, sourceSystemID);
	}
	
	/**
	 * Create a Risk activity event, using the Risk outcome from the HA.
	 * 
	 * @param pHAActivityEvent
	 * @return
	 */
	ActivityEvent createActivityEventFromHARisk(ActivityEvent pHAActivityEvent, String pStatusCodeValue)
	{
		ActivityEvent lRiskActivityEvent = new ActivityEvent();
		MemberActivity lRiskMemberActivity = new MemberActivity();
		ActivityDefinition lActivityDefinition = new ActivityDefinition();
		lRiskMemberActivity.setActivity(lActivityDefinition);
		GenericStatusType lRiskActivityStatus = new GenericStatusType();
		lRiskMemberActivity.setActivityStatus(lRiskActivityStatus);
		lRiskActivityEvent.setMemberActivity(lRiskMemberActivity);
		
		lRiskActivityEvent.setMemberID(pHAActivityEvent.getMemberID());
		lRiskActivityEvent.getMemberActivity().getActivity().setSourceActivityID(pHAActivityEvent.getMemberActivity().getActivityStatus().getOutCome());
		
		if(lRiskActivityEvent.getMemberActivity().getActivity().getSourceActivityID() == null ||
				lRiskActivityEvent.getMemberActivity().getActivity().getSourceActivityID().length() < 1)
		{
			lRiskActivityEvent.getMemberActivity().getActivity().setSourceActivityID(BPMConstants.ACTIVITY_STATUS_OUTCOME_GENERIC_RISK);
		}
		
		lRiskMemberActivity.setBusinessProgramID(pHAActivityEvent.getMemberActivity().getBusinessProgramID());
		lRiskMemberActivity.setRegistrationID(pHAActivityEvent.getMemberActivity().getRegistrationID());		
		lRiskMemberActivity.setAuthPromoCode(pHAActivityEvent.getMemberActivity().getAuthPromoCode());		
		
		lRiskActivityStatus.setStatusCodeValue(pStatusCodeValue);
		lRiskActivityStatus.setStatusEffectiveDate(pHAActivityEvent.getMemberActivity().getActivityStatus().getStatusEffectiveDate());
		
		return lRiskActivityEvent;
	}
	
	
	/*
	 * This method helps resolve an issue where multiple activity event transactions for the same activity are
	 * being processed across more that one managed server.  Since there is no control over the order in which
	 * activities can be processed, the method checks to see if a COMPLETE activity is exists.    If the COMPLETE exists, 
	 * then the person program status cannot be updated.  The activity with the COMPLETE will
	 * eventually get processed.  
	 */
	private boolean isMemberActivityWOComplete(Integer activityID, Integer programID, ActivityEvent lActivityEvent) {
			boolean isMemberActivityWOComplete = false;
			
			String activityTypeCodeValue = lActivityEvent.getMemberActivity().getActivityStatus().getStatusCodeValue();
			//want activity to be processed if it is the activity representing the COMPLETE.
			if (BPMConstants.ACTIVITY_STATUS_COMPLETE.equals(activityTypeCodeValue)) {
				isMemberActivityWOComplete = true;
				return isMemberActivityWOComplete;
			}
			
			/*ArrayList<MemberActivity> lExistingComplete = (ArrayList<MemberActivity>)
				activityDAO.getExistingActivity(lActivityEvent.getMemberID(), lActivityEvent
							.getMemberActivity().getActivity().getSourceActivityID(),
							new java.sql.Date(lActivityEvent.getMemberActivity().getActivityStatus().getStatusEffectiveDate().getTime().getTime()),
							lActivityEvent.getMemberActivity().getAuthPromoCode(),
							lActivityEvent.getMemberActivity().getRegistrationID(),
							BPMConstants.ACTIVITY_STATUS_COMPLETE);								
			
			if(lExistingComplete.size() == 0) {
				isMemberActivityWOComplete = true;
			}*/
			
			
			String registrationID = lActivityEvent.getMemberActivity().getRegistrationID();
			Integer personID = lActivityEvent.getPersonDemographicsID();
			if (activityDAO.isPersonProgramActivityHistoryComplete(activityID, personID, programID, registrationID)) {
				isMemberActivityWOComplete = false;
			} else {
				isMemberActivityWOComplete = true;
			}
			
			return isMemberActivityWOComplete;
	}
	private void logPKInfo(ActivityEvent activityEvent) {
		String sourceActivityID = (activityEvent.getMemberActivity() != null && activityEvent
				.getMemberActivity().getActivity() != null) ? activityEvent
				.getMemberActivity().getActivity().getSourceActivityID() : null;
		Integer businessProgramID = (activityEvent.getMemberActivity() != null) ? activityEvent
				.getMemberActivity().getBusinessProgramID()
				: null;
				
		String registrationID = (activityEvent.getMemberActivity() != null && activityEvent
				.getMemberActivity().getRegistrationID() != null) ? activityEvent
				.getMemberActivity().getRegistrationID()
				: null;
	
		String authPromoCode = activityEvent.getMemberActivity() != null ? activityEvent
				.getMemberActivity().getAuthPromoCode()
				: null;
	
		if(BPMConstants.ACTIVITY_HEALTHY_BENEFITS_HA_ID.equals(sourceActivityID) &&
				(registrationID == null || registrationID.trim().length() < 1))
		{
			logger.error("Activity Id is for HA.  Assign promo code to registration id. ");
			logger.error("Reg id is:     " + registrationID);
			logger.error("Auth promo is: " + authPromoCode);
			registrationID = authPromoCode;
		}
		logger.error("  ");
		logger.error("PK to activity event record follows: ");
		logger.error("Member Id:           " + activityEvent.getMemberID());
		logger.error("Source Activity Id : " + sourceActivityID);
		logger.error("Business Program Id: " + businessProgramID);
		logger.error("Registration Id:     " + registrationID);
		logger.error("AuthPromotion Code:  " + authPromoCode);
		logger.error("  ");
	
	}




	/**
	 * Determines if ActivityEvent is older than set LUV parameter
	 * which stores a span of months cutoff for what should not be
	 * allowed to be written to the activity event log table.
	 * This addresses an issue where a flood of oder activities dating as far back
	 * as 2012 have been sent into BPM from HPD for recalculation. No one
	 * in HPD can get to the root cause.  Long term solution will be to
	 * move the bpm-upd-ws to the BUS.
	 *
	 * @return boolean
	 *
	 */
	private boolean isActivityEventOlderThanSpanInMonths(ActivityEvent activityEvent)
			throws BPMBusinessValidationException, BPMException,
			DataAccessException
	{
		boolean isOlder = false;

		LookUpValueCode lookUpValueCode = lookUpValueDAO.getLUVCodesByGroup(BPMConstants.BPM_ACTIVITY_EVENT_CUTOFF).iterator().next();
		String monthSpan = lookUpValueCode.getLuvDesc();
		monthSpan = "-" + monthSpan;  //Append minus sign.
		java.sql.Date cutOffDateSql = BPMUtils.determineCutOffDate(monthSpan);

		java.sql.Date statusEffectiveDate = BPMUtils.calendarToSqlDate(activityEvent.getMemberActivity().getActivityStatus().getStatusEffectiveDate());

		if(statusEffectiveDate.before(cutOffDateSql))
		{
			String memberID = activityEvent.getMemberID();
			String sourceActivityID = activityEvent.getMemberActivity().getActivity().getSourceActivityID();
			String registrationID = activityEvent.getMemberActivity().getRegistrationID();
			String userID = activityEvent.getMemberActivity().getActivity().getUserId();
			java.sql.Date activityStatusDateSql = BPMUtils.calendarToSqlDate(activityEvent.getMemberActivity().getActivityStatus().getStatusEffectiveDate());
			String statusEffectiveDateStr =	BPMUtils.convertSqlDateToString(activityStatusDateSql);

			BPMAuditRecord bpmAuditRecord = BPMAuditRecordFactory
					.createGenericEventRecord(BPMConstants.BPM_USER_SYSTEM,  "isActivityEventOlderThanSpanInMonths",
							"Old Activity Sent", memberID, sourceActivityID,
							registrationID, statusEffectiveDateStr);
			createAuditEventLogEntry(bpmAuditRecord);

			isOlder = true;
		}

		return isOlder;
	}

	public Integer createAuditEventLogEntry(BPMAuditRecord bpmAuditRecord) {

		Integer auditLogId = null;

		try {
			auditLogId = auditLogService.insertAuditLog(bpmAuditRecord);
		} catch (Exception e) {
			logger.error("Error writing AuditEventLogEntry " + e);
		}

		return auditLogId;
	}



	/**
	 * Validates ActivityEvent
	 * 
	 * @return void
	 * @throws BPMBusinessValidationException
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	private boolean validateActivityEvent(ActivityEvent activityEvent)
			throws BPMBusinessValidationException, BPMException,
			DataAccessException 
	{
	    boolean lActivityValid = true;
	    
		if(activityEvent.getMemberActivity().getActivityStatus().getStatusEffectiveDate() == null)
		{
			activityEvent.setReasonDescription(BPMConstants.BPM_FILTERD_OUT_RSN_CD14_ACTIVITY_DATE_MISSING);
			Calendar lPlaceHolderDate = Calendar.getInstance();
			lPlaceHolderDate.set(Calendar.DAY_OF_MONTH, 1);
			lPlaceHolderDate.set(Calendar.MONTH, 0);
			lPlaceHolderDate.set(Calendar.YEAR, 9999);
			
			activityEvent.getMemberActivity().getActivityStatus().setStatusEffectiveDate(lPlaceHolderDate);
			lActivityValid = false;
		}
		else if(activityEvent.getMemberActivity().getAuthPromoCode() == null
				|| activityEvent.getMemberActivity().getAuthPromoCode().length() < 1)
		{
			activityEvent.setReasonDescription(BPMConstants.BPM_FILTERD_OUT_RSN_CD9_NO_AUTH_CD);
			lActivityValid = false;
		}
		
		return lActivityValid;
	}
	
	
	public int updateActivityLogProcessingStatus(Collection<ActivityEvent> activityEvents, String processingStatus) throws BPMException {
		int updateRecCt = 0;
		for (ActivityEvent activityEvent : activityEvents) {
			activityEvent.setProcessingStatusValue(processingStatus);
			activityEventLogDAO.updateActivityLogProcessingStatus(activityEvent);
			updateRecCt++;
		}
		
		return updateRecCt;	
	}
	
	/**
	 * 
	 * @param pActivityIncentive
	 * @param pActivityEvent
	 * @param pPersonDemographicsID
	 * @return
	 */
	private int insertPersonActivityIncentive(ActivityIncentive pActivityIncentive
			, ActivityEvent pActivityEvent
			, Integer pPersonDemographicsID)
	{
		PersonActivityIncentive lPersonActivityIncentive = new PersonActivityIncentive();
		
		lPersonActivityIncentive.setBusinessProgramID(pActivityIncentive.getBusinessProgramID());
		lPersonActivityIncentive.setPersonDemographicsID(pPersonDemographicsID);
		lPersonActivityIncentive.setActivityID(pActivityEvent.getMemberActivity().getActivity().getActivityID());
		lPersonActivityIncentive.setActivityIncentiveID(pActivityIncentive.getActivityIncentiveID());
		lPersonActivityIncentive.setActivityStatusCode(pActivityEvent.getMemberActivity().getActivityStatus().getStatusCodeValue());
		lPersonActivityIncentive.setRegistrationID(pActivityEvent.getMemberActivity().getRegistrationID());
		
		return incentiveOptionDAO.updatePersonActivityIncentive(lPersonActivityIncentive, BPMConstants.BPM_USER_SYSTEM);		 
	}

	/**
	 * Sets the ActivityEventLogDAO. Should only be called by Spring.
	 *
	 */
	public void setActivityEventLogDAO(ActivityEventLogDAO dao) {
		this.activityEventLogDAO = dao;
	}

	/**
	 * Sets the ActivityDAO. Should only be called by Spring.
	 *
	 */
	public void setActivityDAO(ActivityDAO dao) {
		this.activityDAO = dao;
	}

	/**
	 * Sets the ActivityEventGenerator. Should only be called by Spring.
	 *
	 */
//	public void setActivityEventGenerator(ActivityEventGenerator jmsSender) {
//		this.activityEventGenerator = jmsSender;
//	}

	/**
	 * Sets the ProgramStatusCalculationService. Should only be called by
	 * Spring.
	 * 
	 * @param service
	 *            the ProgramStatusCalculationService service
	 */
	public void setProgramStatusCalculationService(
			ProgramStatusCalculationService service) {
		this.programStatusCalculationService = service;
	}


	public ActivityEventFilterImpl getActivityEventFilter() {
		return activityEventFilter;
	}

	public void setActivityEventFilter(
			ActivityEventFilterImpl activityEventFilter) {
		this.activityEventFilter = activityEventFilter;
	}

	public IncentiveOptionDAO getIncentiveOptionDAO() {
		return incentiveOptionDAO;
	}

	public void setIncentiveOptionDAO(IncentiveOptionDAO incentiveOptionDAO) {
		this.incentiveOptionDAO = incentiveOptionDAO;
	}

	public PersonDAO getPersonDAO() {

	    return personDAO;
	}

	public void setPersonDAO(PersonDAO personDAO) {
		this.personDAO = personDAO;
	}

	public void setLookUpValueDAO(LookUpValueDAOJdbc lookUpValueDAO) {

	    this.lookUpValueDAO = lookUpValueDAO;
	}


	public void setAuditLogService(AuditLogService auditLogService) {

	    this.auditLogService = auditLogService;
	}
}
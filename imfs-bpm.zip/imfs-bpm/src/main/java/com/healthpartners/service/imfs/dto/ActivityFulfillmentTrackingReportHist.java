package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.sql.Date;
import java.util.Calendar;

public class ActivityFulfillmentTrackingReportHist implements Serializable
{	
	static final long serialVersionUID = 0L;
	
	private Integer activityTransID;
	private Integer programID;
	private Integer  incentiveOptionID;
	private String  memberNo;
	private Integer personID;
	private Integer personDemographicsID;
	private Integer packageID;
	private Date    coverageEffectiveDate;
	private Integer contractNo;
	private Integer activityID;
	private String  activityName;
	private Date 	activityIncentiveStatusDate;
	private Date    insertDate;
	private String  insertUser;
	
	public Integer getActivityTransID() {
		return activityTransID;
	}
	public void setActivityTransID(Integer activityTransID) {
		this.activityTransID = activityTransID;
	}
	public Integer getProgramID() {
		return programID;
	}
	public void setProgramID(Integer programID) {
		this.programID = programID;
	}
	public Integer getIncentiveOptionID() {
		return incentiveOptionID;
	}
	public void setIncentiveOptionID(Integer incentiveOptionID) {
		this.incentiveOptionID = incentiveOptionID;
	}
	public String getMemberNo() {
		return memberNo;
	}
	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}
	public Integer getPersonID() {
		return personID;
	}
	public void setPersonID(Integer personID) {
		this.personID = personID;
	}
	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}
	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}
	public Integer getPackageID() {
		return packageID;
	}
	public void setPackageID(Integer packageID) {
		this.packageID = packageID;
	}
	public Date getCoverageEffectiveDate() {
		return coverageEffectiveDate;
	}
	public void setCoverageEffectiveDate(Date coverageEffectiveDate) {
		this.coverageEffectiveDate = coverageEffectiveDate;
	}
	public Integer getContractNo() {
		return contractNo;
	}
	public void setContractNo(Integer contractNo) {
		this.contractNo = contractNo;
	}
	public Integer getActivityID() {
		return activityID;
	}
	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}
	public String getActivityName() {
		return activityName;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public Date getActivityIncentiveStatusDate() {
		return activityIncentiveStatusDate;
	}
	public void setActivityIncentiveStatusDate(Date activityIncentiveStatusDate) {
		this.activityIncentiveStatusDate = activityIncentiveStatusDate;
	}
	public Date getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}
	public String getInsertUser() {
		return insertUser;
	}
	public void setInsertUser(String insertUser) {
		this.insertUser = insertUser;
	}
	
	
	
	
}

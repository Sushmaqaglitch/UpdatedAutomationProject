package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.sql.Date;

import com.healthpartners.service.imfs.common.BPMConstants;

public class PersonActivityAchievedContribution implements Serializable
{	
	static final long serialVersionUID = 0L;
		
	private Integer personID;
	private Integer personDemographicsID;
	private Integer  contractNo;
	private String  memberNo;
	private String firstName;
	private String lastName;
	private String middleName;
	private Integer groupID;
	private Integer subgroupID;
	private String  groupNo;
	private String  siteNo;
	private Date    activityStatDate;
	private Date    contributionDate;
	private String  activityIncentiveStatus;
	private String  programType;
	private Integer programID;
	private Integer packageID;
	private Integer businessProgramTypeCode;
	private Integer participantCap;
	private Integer familyCap;
	private Integer contributionAmt;
	private Integer combinedContributionAmt;
	private Integer contribTypeCodeID;
	private String  packageSubType;
	private Integer activityID;
	private String  sourceActivityID;
	private String  benefitContractType;
	private Integer participantCount;
	private Integer incentiveOptionID;
	private Integer unitTypeCodeID;
	private String  unitTypeCode;
	private Integer contribGridID;
	private Integer contractIncentiveStatID;
	private Integer memberIncentiveStatID;
	private Integer incentiveStatusActivityDetailID;
	
	
	public Integer getPersonID() {
		return personID;
	}
	public void setPersonID(Integer personID) {
		this.personID = personID;
	}
	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}
	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}
	
	public Integer getContractNo() {
		return contractNo;
	}
	public void setContractNo(Integer contractNo) {
		this.contractNo = contractNo;
	}
	public String getMemberNo() {
		return memberNo;
	}
	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public Integer getGroupID() {
		return groupID;
	}
	public void setGroupID(Integer groupID) {
		this.groupID = groupID;
	}
	public Integer getSubgroupID() {
		return subgroupID;
	}
	public void setSubgroupID(Integer subgroupID) {
		this.subgroupID = subgroupID;
	}
	public String getGroupNo() {
		return groupNo;
	}
	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}
	
	public String getSiteNo() {
		return siteNo;
	}
	public void setSiteNo(String siteNo) {
		this.siteNo = siteNo;
	}
	public Date getActivityStatDate() {
		return activityStatDate;
	}
	public void setActivityStatDate(Date activityStatDate) {
		this.activityStatDate = activityStatDate;
	}
	
	
	public Date getContributionDate() {
		return contributionDate;
	}
	public void setContributionDate(Date contributionDate) {
		this.contributionDate = contributionDate;
	}
	public String getActivityIncentiveStatus() {
		return activityIncentiveStatus;
	}
	public void setActivityIncentiveStatus(String activityIncentiveStatus) {
		this.activityIncentiveStatus = activityIncentiveStatus;
	}
	public String getProgramType() {
		return programType;
	}
	public void setProgramType(String programType) {
		this.programType = programType;
	}
	
	public Integer getProgramID() {
		return programID;
	}
	public void setProgramID(Integer programID) {
		this.programID = programID;
	}
	
	public Integer getPackageID() {
		return packageID;
	}
	public void setPackageID(Integer packageID) {
		this.packageID = packageID;
	}
	public Integer getBusinessProgramTypeCode() {
		return businessProgramTypeCode;
	}
	public void setBusinessProgramTypeCode(Integer businessProgramTypeCode) {
		this.businessProgramTypeCode = businessProgramTypeCode;
	}
	
	public Integer getParticipantCap() {
		return participantCap;
	}
	public void setParticipantCap(Integer participantCap) {
		this.participantCap = participantCap;
	}
	
	
	public Integer getFamilyCap() {
		return familyCap;
	}
	public void setFamilyCap(Integer familyCap) {
		this.familyCap = familyCap;
	}
	public Integer getContributionAmt() {
		return contributionAmt;
	}
	public void setContributionAmt(Integer contributionAmt) {
		this.contributionAmt = contributionAmt;
	}
	
	public Integer getCombinedContributionAmt() {
		return combinedContributionAmt;
	}
	public void setCombinedContributionAmt(Integer combinedContributionAmt) {
		this.combinedContributionAmt = combinedContributionAmt;
	}
	

	public Integer getContribTypeCodeID() {
		return contribTypeCodeID;
	}
	public void setContribTypeCodeID(Integer contribTypeCodeID) {
		this.contribTypeCodeID = contribTypeCodeID;
	}
	public String getPackageSubType() {
		return packageSubType;
	}
	public void setPackageSubType(String packageSubType) {
		this.packageSubType = packageSubType;
	}
	public Integer getActivityID() {
		return activityID;
	}
	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}
	
	public String getSourceActivityID() {
		return sourceActivityID;
	}
	public void setSourceActivityID(String sourceActivityID) {
		this.sourceActivityID = sourceActivityID;
	}
	
	public String getBenefitContractType() {
		return benefitContractType;
	}
	public void setBenefitContractType(String benefitContractType) {
		this.benefitContractType = benefitContractType;
	}
	public Integer getParticipantCount() {
		return participantCount;
	}
	public void setParticipantCount(Integer participantCount) {
		this.participantCount = participantCount;
	}
	public Integer getIncentiveOptionID() {
		return incentiveOptionID;
	}
	public void setIncentiveOptionID(Integer incentiveOptionID) {
		this.incentiveOptionID = incentiveOptionID;
	}
	public Integer getUnitTypeCodeID() {
		return unitTypeCodeID;
	}
	public void setUnitTypeCodeID(Integer unitTypeCodeID) {
		this.unitTypeCodeID = unitTypeCodeID;
	}
	public String getUnitTypeCode() {
		return unitTypeCode;
	}
	public void setUnitTypeCode(String unitTypeCode) {
		this.unitTypeCode = unitTypeCode;
	}
	
	public boolean isUnitTypeCodeUnits() {
		if (unitTypeCode != null) {
			return unitTypeCode.equals(BPMConstants.BPM_IO_UNIT_TYPE_UNITS);
		} else {
			return false;
		}
	}
	public Integer getContribGridID() {
		return contribGridID;
	}
	public void setContribGridID(Integer contribGridID) {
		this.contribGridID = contribGridID;
	}
	public Integer getContractIncentiveStatID() {
		return contractIncentiveStatID;
	}
	public void setContractIncentiveStatID(Integer contractIncentiveStatID) {
		this.contractIncentiveStatID = contractIncentiveStatID;
	}
	public Integer getMemberIncentiveStatID() {
		return memberIncentiveStatID;
	}
	public void setMemberIncentiveStatID(Integer memberIncentiveStatID) {
		this.memberIncentiveStatID = memberIncentiveStatID;
	}
	public Integer getIncentiveStatusActivityDetailID() {
		return incentiveStatusActivityDetailID;
	}
	public void setIncentiveStatusActivityDetailID(
			Integer incentiveStatusActivityDetailID) {
		this.incentiveStatusActivityDetailID = incentiveStatusActivityDetailID;
	}
	
	
	
	
}

package com.healthpartners.service.imfs.helper;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLTimeoutException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.QueryTimeoutException;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.Activity;
import com.healthpartners.service.imfs.dto.ActivityExternalEmployerXref;
import com.healthpartners.service.imfs.dto.CSVTokens;
import com.healthpartners.service.imfs.dto.EmployerActivityContributionsFileData;
import com.healthpartners.service.imfs.dto.EmployerSponsoredActivity;
import com.healthpartners.service.imfs.dto.EmployerSponsoredActivityTrailer;
import com.healthpartners.service.imfs.dto.EmployerSponsoredFile;
import com.healthpartners.service.imfs.dto.RejectedPerson;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.iface.BusinessProgramService;
import com.healthpartners.service.imfs.iface.MemberService;

/**
 * This class parses data file(text) for employer activities
 * 
 * @author tjquist
 * 
 */
public class UploadEmployerActivityDataFileHelper {

	protected final Log logger = LogFactory.getLog(getClass());
	
	private String sourceSystemIDWellsFargo = "30";
	private String sourceSystemIDTarget = "31";
	private String sourceSystemIDDaikin = "32";
	
	MemberService memberService;
	
	BusinessProgramService businessProgramService;
	
	Collection<ActivityExternalEmployerXref> activitiesExternalEmployerXref;
	
	public boolean isTarget = false;
	public boolean isDaikin = false;
	public boolean isWellsFargo = false;
	
	
	public Collection<EmployerSponsoredFile> getEmployerSponsoredFiles(String inPath) throws IOException, Exception {
		
		Collection<EmployerSponsoredFile> lEmployerSponsoredFiles = null;
		
		try {
			lEmployerSponsoredFiles  = readEmployerActivitiesFromDataFile(inPath);
		} catch (Exception e) {
			//logger.error("Exception in UploadEmployerActivityDataFileHelper.getEmployerSponsoredFiles caught: " + e);
			//logger.error("Possible path to file could not be found or does not exist");
			//logger.error("path to file is " + inPath);
			throw e;
		}
		
		return lEmployerSponsoredFiles;
	}
	
	/**
	 * read and format csv employer sponsored data file
	 * 
	 * @param is
	 * @throws IOException
	 */
    
	public EmployerActivityContributionsFileData validateNFormatEmployerActivityContributions(Collection<EmployerSponsoredActivity> generatedActivities, String groupNo) throws Exception {
		
		EmployerActivityContributionsFileData employerActivitiesFileData = null;
	
		String groupName = memberService.getGroupName(groupNo);
		employerActivitiesFileData = generateValidEmployerActivityContributions(generatedActivities, groupName, groupNo);
			
		return employerActivitiesFileData;
		
	}
	
	private  Collection<EmployerSponsoredFile> readEmployerActivitiesFromDataFile(String inPath) throws IOException, Exception {
		Collection<EmployerSponsoredFile> lEmployerSponsoredFiles = null;
	   
        Collection<CSVTokens> csvTokenRecs = BPMUtils.readNParseCommaDelimitedCSVFile(inPath);
        
        if (isTarget || isWellsFargo) {
        	lEmployerSponsoredFiles = tokenMapperForWellsNTarget(csvTokenRecs);
        } if (isDaikin) {
        	lEmployerSponsoredFiles = tokenMapperForDaikin(csvTokenRecs);
        }
		
		return lEmployerSponsoredFiles;
	}
	
	
	
	private Collection<EmployerSponsoredFile> tokenMapperForWellsNTarget( Collection<CSVTokens> csvTokenRecs) throws Exception {
		
		ArrayList<EmployerSponsoredActivity> lEmployerSponsoredActivityArray = new ArrayList<EmployerSponsoredActivity>();
		ArrayList<EmployerSponsoredFile> lEmployerSponsoredFileArray = new ArrayList<EmployerSponsoredFile>();
		
		EmployerSponsoredActivityTrailer lEmployerSponsoredActivityTrailer = new EmployerSponsoredActivityTrailer();
		
		int detailCountTotal = 0;
		Integer detailAmountTotal = 0;
		
		boolean processTrailer = false;
		
		Iterator<CSVTokens> iter = csvTokenRecs.iterator();
		
		//iterate through block of raw data.
		while (iter.hasNext()) {
			CSVTokens csvTokenColumns =  iter.next();
			
			Collection<String> columns = csvTokenColumns.getCsvTokenColumns();


			
			EmployerSponsoredActivity lEmployerSponsoredActivity = new EmployerSponsoredActivity();

			boolean tooManyColumns = false;
			int columNo = 0;
			String column = null;
			Iterator<String> iter2 = columns.iterator();
			
			int columnSize  = columns.size();	
			//iterate through the columns (tokens) while mapping to the DTO
		 	while (iter2.hasNext()) {
				
		 		
				column = iter2.next();
				
				if (column.toLowerCase().trim().equals("total records sent:")) {
					processTrailer = true;
				}
				
				if (processTrailer)
						switch (columNo) {
							case 0: lEmployerSponsoredActivityTrailer.setColumnLabel(column);
									break;
							case 1: lEmployerSponsoredActivityTrailer.setRecordCount(column);
							 		break;
							case 2: lEmployerSponsoredActivityTrailer.setDateSent(column);
							 		break;
							case 3: lEmployerSponsoredActivityTrailer.setGroupFileSourceName(column);
					 				break;
							default:
									if (columNo > columnSize) 
										tooManyColumns = true;
									break;
				}
				
				if (tooManyColumns) {
					throw new Exception("UploadEmployerActivityDataFileHelper.tokenMapperForWellsNTarget: too many columns(nodes) being sent by Optum for the trailer record.  File will not be processed.");
				}
				//if not processing trailer but detail.
				if (!processTrailer) {
						switch (columNo) {
							case 0: lEmployerSponsoredActivity.setFirstName(column);
									break;
							case 1: lEmployerSponsoredActivity.setLastName(column.replaceAll("'", ""));
							 		break;
							case 2: lEmployerSponsoredActivity.setActivityName(column.replaceAll("'", ""));
							 		break;
							case 3: lEmployerSponsoredActivity.setAmountEarned(column);
							 		break;
							case 4: lEmployerSponsoredActivity.setPostingDate(column);
					 				break;
							case 5: lEmployerSponsoredActivity.setMiddleName(column);
							 		break;
							case 6: lEmployerSponsoredActivity.setProcessDate(column);
					 				break;
							case 7: lEmployerSponsoredActivity.setActivityDate(column);
							 		break;
							case 8: lEmployerSponsoredActivity.setPublishDate(column);
					 				break;
							case 9: lEmployerSponsoredActivity.setPersonID(column);
			 						break;
							case 10: lEmployerSponsoredActivity.setAddress1(column);
							 		break;
							case 11: lEmployerSponsoredActivity.setAddress2(column);
							 		break;
							case 12: lEmployerSponsoredActivity.setCity(column);
					 				break; 
							case 13: lEmployerSponsoredActivity.setStateOrProvince(column);
			 						break; 
							case 14: lEmployerSponsoredActivity.setPostalCode(column);
									break; 
							case 15: lEmployerSponsoredActivity.setCountryName(column);
									break; 
							case 16: lEmployerSponsoredActivity.setMemberSSN(column);
									break; 
							 		
							case 17: lEmployerSponsoredActivity.setPrimaryMemberSSN(column);
							 		break;
							case 18: lEmployerSponsoredActivity.setMaritalStatus(column);
							 		break;
							case 19: lEmployerSponsoredActivity.setGender(column);
							 		break;
							case 20: lEmployerSponsoredActivity.setDaytimePhoneNumber(column);
							 		break;
							case 21: lEmployerSponsoredActivity.setEveningPhoneNumber(column);
							 		break;
							case 22: lEmployerSponsoredActivity.setEmailFromEligibility(column);
					 				break;
							case 23: lEmployerSponsoredActivity.setEmailFromRegisProfile(column);
			 						break;
							case 24: lEmployerSponsoredActivity.setDateOfBirth(column);
								break;
							case 25: lEmployerSponsoredActivity.setRelationship(column);
								break;
							case 26: lEmployerSponsoredActivity.setFamilysUniqueIdentifier(column);
								break;
							case 27: lEmployerSponsoredActivity.setAlternateMemberID(column);
								break;
							case 28: lEmployerSponsoredActivity.setAccountID(column);
								break;
							case 29: lEmployerSponsoredActivity.setPopulation(column);
								break;
							case 30: lEmployerSponsoredActivity.setDivision(column);
								break;
							case 31: lEmployerSponsoredActivity.setHealthPlanProduct(column);
								break;
							case 32: lEmployerSponsoredActivity.setRelationshipID(column);
								break;
							case 33: lEmployerSponsoredActivity.setUnionStatus(column);
								break;
							case 34: lEmployerSponsoredActivity.setEmployeeStatus(column);
								break;
							case 35: lEmployerSponsoredActivity.setPVRC(column);
								break;
							case 36: lEmployerSponsoredActivity.setWorkLocation(column);
								break;
							case 37: lEmployerSponsoredActivity.setDependentID(column);
								break;
							case 38: lEmployerSponsoredActivity.setGroupFileSourceName(column);
								break;
							
							
							default: tooManyColumns = true;
		                    		break;
						}
					}
				
				columNo++;
			}
			
			if (tooManyColumns) {
				throw new Exception("UploadEmployerActivityDataFileHelper.tokenMapperForWellsNTarget: too many columns(nodes) being sent by Optum.  File will not be processed.");
			}
			
			if (isTarget) {
				//Target passing garbage for dependent id so set to null.
				lEmployerSponsoredActivity.setDependentID(null);
			}
			
			if (processTrailer) {
				if (lEmployerSponsoredActivityTrailer.getRecordCount() == null) {
					throw new Exception("UploadEmployerActivityDataFileHelper.tokenMapperForWellsNTarget: record count in trailer record is null.  Count should be one or more.");
				}
				
				lEmployerSponsoredActivityTrailer.setTotalAmount(detailAmountTotal);
				
				int trailerCountTotal = Integer.parseInt(lEmployerSponsoredActivityTrailer.getRecordCount());
				if (trailerCountTotal == detailCountTotal ) {
					lEmployerSponsoredActivity.setEmployerSponsoredActivityTrailer(lEmployerSponsoredActivityTrailer);
					lEmployerSponsoredActivityArray.add(lEmployerSponsoredActivity);
					EmployerSponsoredFile lEmployerSponsoredFile = new EmployerSponsoredFile();
					lEmployerSponsoredFile.setGroupFileSourceName(lEmployerSponsoredActivityTrailer.getGroupFileSourceName());
					lEmployerSponsoredFile.setEmployerSponsoredActivities(lEmployerSponsoredActivityArray);
					lEmployerSponsoredFileArray.add(lEmployerSponsoredFile);
					lEmployerSponsoredActivityArray = new ArrayList<EmployerSponsoredActivity>();
					lEmployerSponsoredActivityTrailer = new EmployerSponsoredActivityTrailer();
					detailCountTotal = 0;
					detailAmountTotal = 0;
					
				} else {
					throw new Exception("UploadEmployerActivityDataFileHelper.tokenMapperForWellsNTarget: record count from trailer does not match detail record count sent from Vendor.");
				}
				//set back to false since there could be more than one file.
				processTrailer = false;
				
			} else if (lEmployerSponsoredActivity.getFirstName() == null || lEmployerSponsoredActivity.getFirstName().equals("FIRST_NAME")) {
				//bypass headers from file
			} else {
				if (isWellsFargo()) {
					lEmployerSponsoredActivity.setSourceSystemID(sourceSystemIDWellsFargo);
				} else if (isTarget()) {
							lEmployerSponsoredActivity.setSourceSystemID(sourceSystemIDTarget);
				} 

				lEmployerSponsoredActivityArray.add(lEmployerSponsoredActivity);
				
				if (lEmployerSponsoredActivity.getAmountEarned() != null && BPMUtils.isValueInteger(lEmployerSponsoredActivity.getAmountEarned())) {
					detailAmountTotal = detailAmountTotal + Integer.valueOf(lEmployerSponsoredActivity.getAmountEarned());
				}
				
				detailCountTotal++;
			}
		}
		
		return lEmployerSponsoredFileArray;
	}
	
private Collection<EmployerSponsoredFile> tokenMapperForDaikin( Collection<CSVTokens> csvTokenRecs) throws Exception {
		
		ArrayList<EmployerSponsoredActivity> lEmployerSponsoredActivityArray = new ArrayList<EmployerSponsoredActivity>();
		ArrayList<EmployerSponsoredFile> lEmployerSponsoredFileArray = new ArrayList<EmployerSponsoredFile>();
		
		EmployerSponsoredActivityTrailer lEmployerSponsoredActivityTrailer = new EmployerSponsoredActivityTrailer();
		
		int detailCountTotal = 0;
		Integer detailAmountTotal = 0;

		String trailerGroupFileSourceNameTemp = null;
		
		boolean processTrailer = false;
		
		Iterator<CSVTokens> iter = csvTokenRecs.iterator();
		
		//iterate through block of raw data.
		while (iter.hasNext()) {
			CSVTokens csvTokenColumns =  iter.next();
			
			Collection<String> columns = csvTokenColumns.getCsvTokenColumns();
			
			
			
			EmployerSponsoredActivity lEmployerSponsoredActivity = new EmployerSponsoredActivity();
			
			boolean tooManyColumns = false;
			int columNo = 0;
			String column = null;
			Iterator<String> iter2 = columns.iterator();
			
			int columnSize  = columns.size();	
			//iterate through the columns (tokens) while mapping to the DTO
		 	while (iter2.hasNext()) {
				
		 		
				column = iter2.next();
				
				if (column.toLowerCase().trim().equals("total records sent:")) {
					processTrailer = true;
				}
				
				if (processTrailer)
						switch (columNo) {
							case 0: lEmployerSponsoredActivityTrailer.setColumnLabel(column);
									break;
							case 1: lEmployerSponsoredActivityTrailer.setRecordCount(column);
							 		break;
							case 2: lEmployerSponsoredActivityTrailer.setDateSent(column);
							 		break;
							case 3: lEmployerSponsoredActivityTrailer.setGroupFileSourceName(trailerGroupFileSourceNameTemp);
					 				break;
							default:
									if (columNo > columnSize) 
										tooManyColumns = true;
									break;
				}
				
				if (tooManyColumns) {
					throw new Exception("UploadEmployerActivityDataFileHelper.tokenMapperForDaikin: too many columns(nodes) being sent by Interactive Health for the trailer record.  File will not be processed.");
				}
				//if not processing trailer but detail.
				if (!processTrailer) {
						switch (columNo) {
							//ignore row number
							case 0: break;
							case 1: lEmployerSponsoredActivity.setMemberSSN(column);
							 		break;
							case 2: lEmployerSponsoredActivity.setAlternateMemberID(column);
									break;
							//ignore Card Group ID
							case 3: break;
							case 4: lEmployerSponsoredActivity.setDateOfBirth(column);
					 				break;
							case 5: lEmployerSponsoredActivity.setFirstName(column);
							 		break;
							case 6: lEmployerSponsoredActivity.setLastName(column);
					 				break;
							case 7: lEmployerSponsoredActivity.setGender(column);
							 		break;
							case 8: lEmployerSponsoredActivity.setAddress1(column);
					 				break;
							case 9: lEmployerSponsoredActivity.setAddress2(column);
			 						break;
							case 10: lEmployerSponsoredActivity.setCity(column);
					 				break; 
							case 11: lEmployerSponsoredActivity.setStateOrProvince(column);
			 						break; 
							case 12: lEmployerSponsoredActivity.setPostalCode(column);
									break; 
							case 13: lEmployerSponsoredActivity.setActivityDate(column);
							 		break;
							case 14: lEmployerSponsoredActivity.setAmountEarned(column);
			 						break;
							case 15: lEmployerSponsoredActivity.setActivityName(column);
	 								break;
							case 16: lEmployerSponsoredActivity.setEffectiveDate(column);
									break;
							//Ignore HRA_Adjustment_Reason
							case 17: break;
							case 18: lEmployerSponsoredActivity.setGroupFileSourceName(column);
								break;
							
							
							default: tooManyColumns = true;
		                    		break;
						}
					}
				
				columNo++;
			}
			
			if (tooManyColumns) {
				throw new Exception("UploadEmployerActivityDataFileHelper.tokenMapperForDaikin: too many columns(nodes) being sent by Interactive Health.  File will not be processed.");
			}
		
			
			if (processTrailer) {
				if (lEmployerSponsoredActivityTrailer.getRecordCount() == null) {
					throw new Exception("UploadEmployerActivityDataFileHelper.tokenMapperForDaikin: record count in trailer record is null.  Count should be one or more.");
				}
				
				lEmployerSponsoredActivityTrailer.setTotalAmount(detailAmountTotal);
				
				int trailerCountTotal = Integer.parseInt(lEmployerSponsoredActivityTrailer.getRecordCount());
				if (trailerCountTotal == detailCountTotal ) {
					lEmployerSponsoredActivity.setEmployerSponsoredActivityTrailer(lEmployerSponsoredActivityTrailer);
					lEmployerSponsoredActivityArray.add(lEmployerSponsoredActivity);
					EmployerSponsoredFile lEmployerSponsoredFile = new EmployerSponsoredFile();
					lEmployerSponsoredFile.setGroupFileSourceName(lEmployerSponsoredActivityTrailer.getGroupFileSourceName());
					lEmployerSponsoredFile.setEmployerSponsoredActivities(lEmployerSponsoredActivityArray);
					lEmployerSponsoredFileArray.add(lEmployerSponsoredFile);
					lEmployerSponsoredActivityArray = new ArrayList<EmployerSponsoredActivity>();
					lEmployerSponsoredActivityTrailer = new EmployerSponsoredActivityTrailer();
					detailCountTotal = 0;
					detailAmountTotal = 0;
					
				} else {
					throw new Exception("UploadEmployerActivityDataFileHelper.tokenMapperForDaikin: record count from trailer does not match detail record count sent from Vendor.");
				}
				//set back to false since there could be more than one file.
				processTrailer = false;
				
			} else  if (lEmployerSponsoredActivity.getFirstName() == null || lEmployerSponsoredActivity.getFirstName().equals("Fname")) {
						//bypass headers from file 
			} else {
				
				lEmployerSponsoredActivity.setSourceSystemID(sourceSystemIDDaikin);

				if (lEmployerSponsoredActivity.getGroupFileSourceName() != null && trailerGroupFileSourceNameTemp == null) {
					trailerGroupFileSourceNameTemp = lEmployerSponsoredActivity.getGroupFileSourceName();
				}
				
				lEmployerSponsoredActivityArray.add(lEmployerSponsoredActivity);
				
				if (lEmployerSponsoredActivity.getAmountEarned() != null && BPMUtils.isValueInteger(lEmployerSponsoredActivity.getAmountEarned())) {
					detailAmountTotal = detailAmountTotal + Integer.valueOf(lEmployerSponsoredActivity.getAmountEarned());
				}
				detailCountTotal++;
			}
		}
		
		return lEmployerSponsoredFileArray;
	}
	
	/**
	 * Validates member information and generate valid activities with incented contribution amounts
	 *
	 * @return
	 * @throws IOException
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	private EmployerActivityContributionsFileData generateValidEmployerActivityContributions(
			Collection<EmployerSponsoredActivity> lEmployerSponsoredActivities, String groupName, String groupNo)
			throws IOException, DataAccessException, BPMException {
		
		EmployerActivityContributionsFileData activityFileData = new EmployerActivityContributionsFileData();
		HashMap<String, Activity> activityFromExternalActivityHM = new HashMap<String, Activity>();
		
		activityFileData.setRejectWholeFile(false);
		
		Collection<EmployerSponsoredActivity> validMemberActivities = new ArrayList<EmployerSponsoredActivity>();
		Collection<EmployerSponsoredActivity> errorRecycleMemberActivities = new ArrayList<EmployerSponsoredActivity>();
		Collection<EmployerSponsoredActivity> fatalErrorMemberActivities = new ArrayList<EmployerSponsoredActivity>();
		Collection<EmployerSponsoredActivity> previousYearActivitiesOverriddenMemberActivities = new ArrayList<EmployerSponsoredActivity>();
		
		
		Integer validTotalAmounts = 0;
		Integer errorRecycleTotalAmounts = 0;
		
		
		activityFileData.setGroupName(groupName);
		activityFileData.setGroupNo(groupNo);
		int recordCt = 0;
		for (EmployerSponsoredActivity lEmployerSponsoredActivity : lEmployerSponsoredActivities) {
			boolean isValidLine = true;
			
			logger.info("lEmployerSponsoredActivity read: " + recordCt++);
			
			if (lEmployerSponsoredActivity.getEmployerSponsoredActivityTrailer() != null && Integer.valueOf(lEmployerSponsoredActivity.getEmployerSponsoredActivityTrailer().getRecordCount()) >= 0) {
				//at the end of the collection indicating the trailer record is present.  Break out of the loop.
				activityFileData.setEmployerSponsoredActivityTrailer(lEmployerSponsoredActivity.getEmployerSponsoredActivityTrailer());
				break;
			}
			
			if (isDateNotExist(lEmployerSponsoredActivity.getActivityDate())) {
				lEmployerSponsoredActivity.setActivityDate(lEmployerSponsoredActivity.getActivityDate2());
			} else if (isDateNotExist(lEmployerSponsoredActivity.getActivityDate2())) {
				//ignore
			} else if (lEmployerSponsoredActivity.getActivityName().toLowerCase(Locale.ENGLISH).equals("combination")) {
					Date activityDate = BPMUtils.getDateFromStringMMddyyyy(lEmployerSponsoredActivity.getActivityDate());
					Date activityDate2 = BPMUtils.getDateFromStringMMddyyyy(lEmployerSponsoredActivity.getActivityDate2());
					Calendar activityDateCal = BPMUtils.dateToCalendar(activityDate);
					Calendar activityDate2Cal = BPMUtils.dateToCalendar(activityDate2);
					Calendar activityDateCalMax = BPMUtils.getMaximumDate(activityDateCal, activityDate2Cal);
					activityDate = BPMUtils.calendarToSqlDate(activityDateCalMax);
					String dateString = BPMUtils.convertSqlDateToString(activityDate);
					lEmployerSponsoredActivity.setActivityDate(dateString);
			}
			
			if (isDateNotExist(lEmployerSponsoredActivity.getActivityDate())) {
				isValidLine = false;
				activityFileData.setRejectWholeFile(true);
				EmployerSponsoredActivity employerSponsoredActivity = cloneEmployerSponsoredActivity(lEmployerSponsoredActivity);
				employerSponsoredActivity.setReasonDesc("Activity Date is missing.");
				fatalErrorMemberActivities.add(employerSponsoredActivity);
			} else	if (isActivityWithinExternalActivityEffectiveDates(groupNo, lEmployerSponsoredActivity)) {
				//accept activity date
			} else {
				//EV83824
				lEmployerSponsoredActivity.setActivityDate(lEmployerSponsoredActivity.getProcessDate());
			}
			
			//EV83824 - disable the validation message to report that an activity was take outside of the program period.
			//          now defaulting to using the processing date.
			/*else {
				isValidLine = false;
				activityFileData.setRejectWholeFile(true);
				EmployerSponsoredActivity employerSponsoredActivity = cloneEmployerSponsoredActivity(lEmployerSponsoredActivity);
				employerSponsoredActivity.setReasonDesc("Activity Date from ESP is not within external activity setup in the external employer activity xref table.  Activity date is " + lEmployerSponsoredActivity.getActivityDate());
				fatalErrorMemberActivities.add(employerSponsoredActivity);
			}*/
			
			
			//validate date of birth
			if (lEmployerSponsoredActivity.getDateOfBirth() == null || lEmployerSponsoredActivity.getDateOfBirth().isEmpty() || lEmployerSponsoredActivity.getDateOfBirth().startsWith(" ")) {
				// invalid data - add to invalid
				isValidLine = false;
				activityFileData.setRejectWholeFile(true);
				EmployerSponsoredActivity employerSponsoredActivity = cloneEmployerSponsoredActivity(lEmployerSponsoredActivity);
				employerSponsoredActivity.setReasonDesc("Date Of Birth missing.");
				fatalErrorMemberActivities.add(employerSponsoredActivity);
			}
			
			//validate gender. 
			if (lEmployerSponsoredActivity.getGender() == null || lEmployerSponsoredActivity.getGender().isEmpty() || lEmployerSponsoredActivity.getGender().startsWith(" ")) {
				isValidLine = false;
				activityFileData.setRejectWholeFile(true);
				EmployerSponsoredActivity employerSponsoredActivity = cloneEmployerSponsoredActivity(lEmployerSponsoredActivity);
				employerSponsoredActivity.setReasonDesc("Gender is missing.");
				fatalErrorMemberActivities.add(employerSponsoredActivity);
			
			
			} else	if (lEmployerSponsoredActivity.getGender().toUpperCase(Locale.ENGLISH).equals("M") || lEmployerSponsoredActivity.getGender().toUpperCase(Locale.ENGLISH).equals("F")) {
						//valid values
		    } else {
					isValidLine = false;
					activityFileData.setRejectWholeFile(true);
					EmployerSponsoredActivity employerSponsoredActivity = cloneEmployerSponsoredActivity(lEmployerSponsoredActivity);
					employerSponsoredActivity.setReasonDesc("Gender " + lEmployerSponsoredActivity.getGender() + " is Invalid.");
					fatalErrorMemberActivities.add(employerSponsoredActivity);
			}
			
			//validate amount earned.
			if (lEmployerSponsoredActivity.getAmountEarned() == null || lEmployerSponsoredActivity.getAmountEarned().isEmpty() || lEmployerSponsoredActivity.getAmountEarned().startsWith(" ")) {
				isValidLine = false;
				activityFileData.setRejectWholeFile(true);
				EmployerSponsoredActivity employerSponsoredActivity = cloneEmployerSponsoredActivity(lEmployerSponsoredActivity);
				employerSponsoredActivity.setReasonDesc("Amount earned is missing.");
				fatalErrorMemberActivities.add(employerSponsoredActivity);
			} else if (BPMUtils.isValueInteger(lEmployerSponsoredActivity.getAmountEarned())) {
					//valid values
			} else {
				isValidLine = false;
				activityFileData.setRejectWholeFile(true);
				EmployerSponsoredActivity employerSponsoredActivity = cloneEmployerSponsoredActivity(lEmployerSponsoredActivity);
				employerSponsoredActivity.setReasonDesc("Amount earned " + lEmployerSponsoredActivity.getAmountEarned() + " is not numeric.");
				fatalErrorMemberActivities.add(employerSponsoredActivity);
			}
			
			if (lEmployerSponsoredActivity.getActivityName() == null || lEmployerSponsoredActivity.getActivityName().isEmpty() || lEmployerSponsoredActivity.getActivityName().startsWith(" ")) {
				
				isValidLine = false;
				activityFileData.setRejectWholeFile(true);
				EmployerSponsoredActivity employerSponsoredActivity = cloneEmployerSponsoredActivity(lEmployerSponsoredActivity);
				employerSponsoredActivity.setReasonDesc("Activity name is missing.");
				fatalErrorMemberActivities.add(employerSponsoredActivity);
				
				
			
			} else {
				
				//get internal activity name using external activity name from employer.
				Activity lActivity = null;
				try {
					String key = concatenateToFormKey(groupNo, lEmployerSponsoredActivity.getActivityName());
					if (activityFromExternalActivityHM.containsKey(key)) {
						lActivity = activityFromExternalActivityHM.get(key);
					} else {
						lActivity = fetchActivityFromExternalActivity(groupNo, lEmployerSponsoredActivity.getActivityName());
						activityFromExternalActivityHM.put(key, lActivity);
					}
				
				} catch (DataAccessException e) {
					logger.error("DataException thrown.  Error is " + e.getMessage());
					throw e;
				} catch (Exception ex) {
					logger.error("Exception thrown out of fetchActivityFromExternalActivity.  Error is " + ex.getMessage());
					throw new BPMException(ex);
				}
				
				if (lActivity != null) {
					
					lEmployerSponsoredActivity.setActivityName(lActivity.getName());
					lEmployerSponsoredActivity.setActivityID(lActivity.getActivityID());
					lEmployerSponsoredActivity.setSourceActivityID(lActivity.getSourceActivityID());
				} else {
					
					EmployerSponsoredActivity employerSponsoredActivity = cloneEmployerSponsoredActivity(lEmployerSponsoredActivity);
					isValidLine = false;
					//reject whole file
					activityFileData.setRejectWholeFile(true);
					employerSponsoredActivity.setReasonDesc("External activity name " + lEmployerSponsoredActivity.getActivityName() + " does not match to internal activity name.");
					fatalErrorMemberActivities.add(employerSponsoredActivity);
					
				}
			}
			
			if (isValidLine) {
				
				String firstName = lEmployerSponsoredActivity.getFirstName();
				String middleName = lEmployerSponsoredActivity.getMiddleName();
				String lastName = lEmployerSponsoredActivity.getLastName();
				String gender = lEmployerSponsoredActivity.getGender();
				String dependentID = lEmployerSponsoredActivity.getDependentID();
				Date dob = BPMUtils.convertStringToSqlDate(lEmployerSponsoredActivity.getDateOfBirth(), BPMConstants.HP_BPM_COMMON_DATE_FORMAT);
				
				boolean writeToErrorRecycle = false;
				
				ArrayList<String> memberIDs = new ArrayList<String>();
				Collection<String> activeMemberIDs;
				
				//EV82742 - Add dependent id (external person id) search.  If dependent id
				//          exists in the file, will speed up the eligibility look up.
				if (dependentID != null && dependentID.length() < 10) {
					logger.info("Dependent id is less than 10 digits.  Pad with zeros.  Dependent id is " + dependentID);
					dependentID = BPMUtils.leftPadWZeros(dependentID, 10);
				}
				
				String memberNoMODS = null;
				if (dependentID !=null) {
					try {
						logger.error("call to  getMemberNoUsingMODS(dependentID) " + dependentID);
						memberNoMODS = memberService.getMemberNoUsingMODS(dependentID);
					} catch (DataAccessException e) {
						logger.error("DataException thrown.  Error is " + e.getMessage());
						throw e;
					} catch (Exception ex) {
						logger.error("Exception thrown out of memberService.getMemberNoUsingMODS.  Error is " + ex.getMessage());
						throw new BPMException(ex);
					}
				}
				
				if (memberNoMODS != null) {
						lEmployerSponsoredActivity.setMemberID(memberNoMODS);
						validTotalAmounts = validTotalAmounts + Integer.valueOf(lEmployerSponsoredActivity.getAmountEarned());
						// add as valid
						validMemberActivities.add(lEmployerSponsoredActivity);
						logger.info(" member id resolved from MODS =" + memberNoMODS + " " + firstName + " " + lastName + " " + dob);
				} else {
						//Send through expensive eligibility lookup algorithms.
						memberIDs = (ArrayList<String>)memberService
								.getMemberIDFromPersonDetails(firstName, middleName, lastName, gender, dob);
						
						
						if (memberIDs != null && memberIDs.size() > 0) {
							activeMemberIDs = determineActiveMember(memberIDs);
						} else{
							activeMemberIDs = null;
						}
						
						logger.info(" activeMemberIDs=" + activeMemberIDs + " " + firstName + " " + lastName + " " + dob);
						
						Collection<RejectedPerson> possibleMatches = new ArrayList<RejectedPerson>();
						try {
							if (activeMemberIDs == null || activeMemberIDs.size() == 0) {
								logger.info("*** perform lookup of person employer possible matches");
								possibleMatches = businessProgramService.getPersonEmployerPossibleMatches(firstName, lastName, dob, groupNo);
							}
						} catch (SQLTimeoutException to) {
							logger.error("SQLTimeoutException error while calling method getPersonEmployerPossibleMatches. ");
							logger.error("Search targets are firstName: " + firstName + " lastName: " + lastName + " Date of Birth: " + dob + " groupNo: " + groupNo);
							logger.error("Write to error recycle.");
							lEmployerSponsoredActivity.setReasonDesc("SQLTimeoutException error thrown on " + lastName + ", " + firstName + " " + dob);
							writeToErrorRecycle = true;
							continue;
						} catch (QueryTimeoutException qte) {
							logger.error("QueryTimeoutException error while calling method getPersonEmployerPossibleMatches. ");
							logger.error("Search targets are firstName: " + firstName + " lastName: " + lastName + " Date of Birth: " + dob + " groupNo: " + groupNo);
							logger.error("Write to error recycle.");
							lEmployerSponsoredActivity.setReasonDesc("QueryTimeoutException error thrown on " + lastName + ", " + firstName + " " + dob);
							writeToErrorRecycle = true;
							continue;
						}
						
						boolean matchUsingBothSearches = false;
						if (possibleMatches != null && possibleMatches.size() == 1 && 
								activeMemberIDs != null && activeMemberIDs.size() == 1) {
							String memberNoFromPossibleMatch = possibleMatches.iterator().next().getMemberNo();
							String memberIDFromPersonDemographic = activeMemberIDs.iterator().next();
							if (memberNoFromPossibleMatch.trim().equals(memberIDFromPersonDemographic.trim())) {
								matchUsingBothSearches = true;
							}
						}
				
						if (matchUsingBothSearches) {
							String memberID = activeMemberIDs.iterator().next();
							if(lEmployerSponsoredActivity.getMemberID() == null || memberID.equals(lEmployerSponsoredActivity.getMemberID()))
							{
								lEmployerSponsoredActivity.setMemberID(memberID);
								validTotalAmounts = validTotalAmounts + Integer.valueOf(lEmployerSponsoredActivity.getAmountEarned());
								// add as valid
								validMemberActivities.add(lEmployerSponsoredActivity);
							} else {
								//if member id exists from Optum but doesn't match to what participant resolved to within BPM then reject
								//to error recycle.
								writeToErrorRecycle = true;
							}
							
						} else 
							if (activeMemberIDs != null && activeMemberIDs.size() == 1) 
							{
								// single matched member - valid
								// assign memberid
								String memberID = activeMemberIDs.iterator().next();
								
								if(lEmployerSponsoredActivity.getMemberID() == null || memberID.equals(lEmployerSponsoredActivity.getMemberID()))
								{
									lEmployerSponsoredActivity.setMemberID(memberID);
									validTotalAmounts = validTotalAmounts + Integer.valueOf(lEmployerSponsoredActivity.getAmountEarned());
									// add as valid
									validMemberActivities.add(lEmployerSponsoredActivity);
								}
								else 
								{	
									if (possibleMatches.size() == 1) {
										String memberNo = possibleMatches.iterator().next().getMemberNo();
										if(memberNo.equals(lEmployerSponsoredActivity.getMemberID())) {
											lEmployerSponsoredActivity.setMemberID(memberNo);
											validTotalAmounts = validTotalAmounts + Integer.valueOf(lEmployerSponsoredActivity.getAmountEarned());
											// add as valid
											validMemberActivities.add(lEmployerSponsoredActivity);
										} else {
											lEmployerSponsoredActivity.setReasonDesc("No member match for " + lastName + ", " + firstName + " " + dob);
											writeToErrorRecycle = true;
										}
									} else {
										lEmployerSponsoredActivity.setReasonDesc("Multiple member matches for " + lastName + ", " + firstName + " " + dob);
										writeToErrorRecycle = true;
									}
								}
																		
						} else if (activeMemberIDs == null || activeMemberIDs.isEmpty()) {
							
									if (possibleMatches.size() == 1) {
										String memberNo = possibleMatches.iterator().next().getMemberNo();
										if(lEmployerSponsoredActivity.getMemberID() == null || memberNo.equals(lEmployerSponsoredActivity.getMemberID())) {
											lEmployerSponsoredActivity.setMemberID(memberNo);
											validTotalAmounts = validTotalAmounts + Integer.valueOf(lEmployerSponsoredActivity.getAmountEarned());
											validMemberActivities.add(lEmployerSponsoredActivity);
										} else {
											lEmployerSponsoredActivity.setReasonDesc("No member match for " + lastName + ", " + firstName + " " + dob);
											writeToErrorRecycle = true;
										}
									} else {
										//if more than one possible match returned, send to error recycle.
										lEmployerSponsoredActivity.setReasonDesc("No member match for " + lastName + ", " + firstName + " " + dob);
										writeToErrorRecycle = true;
									}
						} else if (activeMemberIDs != null && activeMemberIDs.size() > 1) {
								lEmployerSponsoredActivity.setReasonDesc("Multiple member matches for " + lastName + ", " + firstName + " " + dob);
								writeToErrorRecycle = true;
						} 
					}
				if (writeToErrorRecycle) {
					logger.error("Write to error recycle.  Reason: " + lEmployerSponsoredActivity.getReasonDesc());
					errorRecycleTotalAmounts = errorRecycleTotalAmounts + Integer.valueOf(lEmployerSponsoredActivity.getAmountEarned());
					errorRecycleMemberActivities.add(lEmployerSponsoredActivity);
				}
			}
		
		} //end for loop
		
		
		activityFileData.setEmployerSponsoredActivitiesInput(lEmployerSponsoredActivities);
		activityFileData.setValidMemberActivities(validMemberActivities);
		activityFileData.setFatalErrorMemberActivities(fatalErrorMemberActivities);
		activityFileData.setErrorRecycleMemberActivities(errorRecycleMemberActivities);
		activityFileData.setPreviousYearActivitiesOverriddenMemberActivities(previousYearActivitiesOverriddenMemberActivities);
		
		activityFileData.setValidTotalAmounts(validTotalAmounts);
		activityFileData.setErrorRecycleTotalAmounts(errorRecycleTotalAmounts);

		return activityFileData;

	}
	
	/*
	 * Instantiate a new EmployerSponsoredActivity object which will create a new address in memory
	 * so that when object is written to arraylist, it won't overwrite the error reason for the same
	 * ESP activity already stored in the fatalErrorMemberActivities arraylist.
	 */
	private EmployerSponsoredActivity cloneEmployerSponsoredActivity(EmployerSponsoredActivity lEmployerSponsoredActivity) {
		EmployerSponsoredActivity newEmployerSponsoredActivity = new EmployerSponsoredActivity();
		
		newEmployerSponsoredActivity.setAccountID(lEmployerSponsoredActivity.getAccountID());
		newEmployerSponsoredActivity.setActivityDate(lEmployerSponsoredActivity.getActivityDate());
		newEmployerSponsoredActivity.setActivityID(lEmployerSponsoredActivity.getActivityID());
		newEmployerSponsoredActivity.setActivityName(lEmployerSponsoredActivity.getActivityName());
		newEmployerSponsoredActivity.setActivityNameInternal(lEmployerSponsoredActivity.getActivityNameInternal());
		newEmployerSponsoredActivity.setAddress1(lEmployerSponsoredActivity.getAddress1());
		newEmployerSponsoredActivity.setAddress2(lEmployerSponsoredActivity.getAddress2());
		newEmployerSponsoredActivity.setAlternateMemberID(lEmployerSponsoredActivity.getAlternateMemberID());
		newEmployerSponsoredActivity.setAmountEarned(lEmployerSponsoredActivity.getAmountEarned());
		newEmployerSponsoredActivity.setAuthCode(lEmployerSponsoredActivity.getAuthCode());
		newEmployerSponsoredActivity.setCity(lEmployerSponsoredActivity.getCity());
		newEmployerSponsoredActivity.setCountryName(lEmployerSponsoredActivity.getCountryName());
		newEmployerSponsoredActivity.setDateOfBirth(lEmployerSponsoredActivity.getDateOfBirth());
		newEmployerSponsoredActivity.setDaytimePhoneNumber(lEmployerSponsoredActivity.getDaytimePhoneNumber());
		newEmployerSponsoredActivity.setFirstName(lEmployerSponsoredActivity.getFirstName());
		newEmployerSponsoredActivity.setGender(lEmployerSponsoredActivity.getGender());
		newEmployerSponsoredActivity.setGroupFileSourceName(lEmployerSponsoredActivity.getGroupFileSourceName());
		newEmployerSponsoredActivity.setHealthPlanProduct(lEmployerSponsoredActivity.getHealthPlanProduct());
		newEmployerSponsoredActivity.setLastName(lEmployerSponsoredActivity.getLastName());
		newEmployerSponsoredActivity.setMemberID(lEmployerSponsoredActivity.getMemberID());
		newEmployerSponsoredActivity.setPersonID(lEmployerSponsoredActivity.getPersonID());
		newEmployerSponsoredActivity.setMiddleName(lEmployerSponsoredActivity.getMiddleName());
		
		
		return newEmployerSponsoredActivity;
	}
	
	private boolean isDateNotExist(String activityDate) {
		boolean dateNotExist = false;
		if (activityDate == null || activityDate.isEmpty() || activityDate.startsWith(" ")) {
			dateNotExist = true;
		}
		
		return dateNotExist;
	}
	
	private static String concatenateToFormKey(String value1, String value2) {
		   StringBuilder sb = new StringBuilder();
		   
		   sb.append(value1);
		   sb.append(value2);
		  
		   return sb.toString();
	}
	
	/*
	 * Determine of the multiple member id's which member id is participating in Health and Wellness programs.  There should
	 * only be one member id found.
	 */
	private Collection<String> determineActiveMember(Collection<String> memberIDs) {
		Collection<String> participatingMembers = new ArrayList<String> ();
		Iterator<String> iterMemberIds = memberIDs.iterator();
		while (iterMemberIds.hasNext()) {
			String memberID = iterMemberIds.next();
			boolean isParticipatingMember = memberService.validateParticipatingMember(memberID);
			if (isParticipatingMember) {
				participatingMembers.add(memberID);
			}
		}
		return participatingMembers;
		
	}
	
	private boolean isActivityWithinExternalActivityEffectiveDates(String groupNo, EmployerSponsoredActivity lEmployerSponsoredActivity) {
		
		boolean isActivityAllowed = false;
		Date activityDateSql = BPMUtils.convertStringToSqlDate(lEmployerSponsoredActivity.getActivityDate(), BPMConstants.HP_BPM_COMMON_DATE_FORMAT);
		
		for (ActivityExternalEmployerXref activityExternalEmployerXref : activitiesExternalEmployerXref) {
			if (groupNo.equals(activityExternalEmployerXref.getGroupNo()) && lEmployerSponsoredActivity.getActivityName().equals(activityExternalEmployerXref.getActivityName())) {
				isActivityAllowed = BPMUtils.isBetweenDates(activityDateSql, activityExternalEmployerXref.getEffectiveDate(), activityExternalEmployerXref.getEndDate()); 
				break;
			}
		}
		
		return isActivityAllowed;
	}
	

	/**
	 * Find activity name from source activityID
	 * 
	 * @param sourceActivityID
	 * @return
	 * @throws DataAccessException
	 * @throws BPMException
	 */
	private String fetchActivityNameFromSourceActivityID(
			String sourceActivityID)
			throws DataAccessException, BPMException {
		String activityName = null;

		Collection<Activity> employerActivities = memberService
				.getEmployerAdminsterdActivities();

		Iterator<Activity> itrAct = employerActivities.iterator();
		while (itrAct.hasNext()) {
			Activity empActivity = itrAct.next();
			if (empActivity.getSourceActivityID().equalsIgnoreCase(
					sourceActivityID)) {
				// matched the activity
				activityName = empActivity.getName();
				break;
			}
		}
		return activityName;
	}
	
	/**
	 * Find activity name from source activityID
	 * 
	 * @param groupNo, externalActivityName
	 * @return
	 * @throws DataAccessException
	 * @throws BPMException
	 */
	private Activity fetchActivityFromExternalActivity(String groupNo, String externalActivityName) throws Exception, DataAccessException {
		
		
		Activity activity = memberService.getActivityFromExternalActivity(groupNo, externalActivityName);

		
		return activity;
	}

	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}

	public void setBusinessProgramService(
			BusinessProgramService businessProgramService) {
		this.businessProgramService = businessProgramService;
	}
	
	

	public void setActivitiesExternalEmployerXref(
			Collection<ActivityExternalEmployerXref> activitiesExternalEmployerXref) {
		this.activitiesExternalEmployerXref = activitiesExternalEmployerXref;
	}

	public boolean isTarget() {
		return isTarget;
	}

	public void setTarget(boolean isTarget) {
		this.isTarget = isTarget;
	}

	public boolean isDaikin() {
		return isDaikin;
	}

	public void setDaikin(boolean isDaikin) {
		this.isDaikin = isDaikin;
	}

	public boolean isWellsFargo() {
		return isWellsFargo;
	}

	public void setWellsFargo(boolean isWellsFargo) {
		this.isWellsFargo = isWellsFargo;
	}

	
	
	
}

package com.healthpartners.service.imfs.dto;

import java.io.Serializable;

/**
 * 
 * @author jxbourbour
 *
 */
public class PersonPackage implements Serializable 
{
	static final long serialVersionUID = 0L;
	
	Integer personDemographicsID;
	Integer programID;
	Integer packageID;
	String packageCode;
	String packageType;
	String packageName;
	String packageSubTypeName;
	java.sql.Date packageEffectiveDate;
	java.sql.Date packageEndDate;
	Integer contractNo;
	
	
	public PersonPackage()
	{
		super();
	}


	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}
	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}
	public Integer getPackageID() {
		return packageID;
	}
	public void setPackageID(Integer packageID) {
		this.packageID = packageID;
	}
	public String getPackageCode() {
		return packageCode;
	}
	public void setPackageCode(String packageCode) {
		this.packageCode = packageCode;
	}
	public String getPackageType() {
		return packageType;
	}
	public void setPackageType(String packageType) {
		this.packageType = packageType;
	}
	public java.sql.Date getPackageEffectiveDate() {
		return packageEffectiveDate;
	}
	public void setPackageEffectiveDate(java.sql.Date packageEffectiveDate) {
		this.packageEffectiveDate = packageEffectiveDate;
	}
	public java.sql.Date getPackageEndDate() {
		return packageEndDate;
	}
	public void setPackageEndDate(java.sql.Date packageEndDate) {
		this.packageEndDate = packageEndDate;
	}
	public String getPackageName() {
		return packageName;
	}
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	public String getPackageSubTypeName() {
		return packageSubTypeName;
	}
	public void setPackageSubTypeName(String packageSubTypeName) {
		this.packageSubTypeName = packageSubTypeName;
	}
	public Integer getProgramID() {
		return programID;
	}
	public void setProgramID(Integer programID) {
		this.programID = programID;
	}
	public Integer getContractNo() {
		return contractNo;
	}
	public void setContractNo(Integer contractNo) {
		this.contractNo = contractNo;
	}
	
	
}

/* $Id$ */

package com.healthpartners.service.imfs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.healthpartners.service.imfs.dto.NamedParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.dto.BaseDTO;
import com.healthpartners.service.imfs.dto.LookUpValueCode;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;


/**
 * JDBC implementation of the LookUpValueDAO interface.
 * 
 * @author tjquist
 */
@Configuration
public class LookUpValueDAOJdbc extends JdbcDaoSupport implements
		LookUpValueDAO {

	/*
	 * Generic Code SQL statements
	 */

	
	

	private String getLUVCodeByID;
	
	private String getAllLUVCodes;

	private String getActiveLUVCodes;

	private String getLUVCodeByValue;

	private String getLUVCodesByGroup;
	
	private String getLUVCodeByGroupNValue;


	public LookUpValueDAOJdbc() {
		super();
	}

	@Autowired
	DataSource bpmDataSource;


	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;


	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}

	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, com.healthpartners.service.imfs.exception.BPMException.class })
	public Collection<LookUpValueCode> getAllLUVCodes()
			throws DataAccessException {
		final ArrayList<LookUpValueCode> results = new ArrayList<LookUpValueCode>();
		JdbcTemplate template = getJdbcTemplate();
		template.query(getAllLUVCodes, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				LookUpValueCode code = new LookUpValueCode();
				code.setLuvId(Integer.valueOf(rs.getInt(1)));
				code.setLuvGroup(rs.getString(2));
				code.setLuvVal(rs.getString(3));
				code.setLuvDesc(rs.getString(4));
				code.setLuvStatus(rs.getString(5));
				code.setLuvNum(rs.getObject(6) == null ? null : new Integer(rs
						.getInt(6)));
				code.setLuvSortOrder(rs.getObject(7) == null ? null
						: new Integer(rs.getInt(7)));
				code.setLuvText(rs.getString(8));
				results.add(code);
			}
		});
		return results;
	}

	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, com.healthpartners.service.imfs.exception.BPMException.class })
	
	public LookUpValueCode getLUVCodeByID(Integer luvID)
			throws DataAccessException {

		Object params[] = new Object[] { luvID };
		int types[] = new int[] { Types.INTEGER };
		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setLuId(luvID);
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<LookUpValueCode> results = namedParameterJdbcTemplate.query(getLUVCodeByID, namedParameters,
				new RowMapper() {
					@Override
					public LookUpValueCode mapRow(ResultSet rs, int i) throws SQLException {
						LookUpValueCode code = new LookUpValueCode();
						code.setLuvId(rs.getInt(1));
						code.setLuvGroup(rs.getString(2));
						code.setLuvVal(rs.getString(3));
						code.setLuvDesc(rs.getString(4));
						code.setLuvStatus(rs.getString(5));
						code.setLuvNum(rs.getObject(6) == null ? null
								: new Integer(rs.getInt(6)));
						code.setLuvSortOrder(rs.getObject(7) == null ? null
								: new Integer(rs.getInt(7)));
						code.setLuvText(rs.getString(8));
						return code;
					}

				});

		LookUpValueCode dto = null;
		if (results.size() > 0) {
			dto = (LookUpValueCode) results.get(0);
		}
		return dto;
	}


	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, com.healthpartners.service.imfs.exception.BPMException.class })
	public Collection<LookUpValueCode> getActiveLUVCodes()
			throws DataAccessException {
		final ArrayList<LookUpValueCode> results = new ArrayList<LookUpValueCode>();
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { BaseDTO.ACTIVATE_STATUS };
		int types[] = new int[] { Types.VARCHAR };
		template.query(getActiveLUVCodes, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						LookUpValueCode code = new LookUpValueCode();
						code.setLuvId(Integer.valueOf(rs.getInt(1)));
						code.setLuvGroup(rs.getString(2));
						code.setLuvVal(rs.getString(3));
						code.setLuvDesc(rs.getString(4));
						code.setLuvStatus(rs.getString(5));
						code.setLuvNum(rs.getObject(6) == null ? null
								: new Integer(rs.getInt(6)));
						code.setLuvSortOrder(rs.getObject(7) == null ? null
								: new Integer(rs.getInt(7)));
						code.setLuvText(rs.getString(8));
						results.add(code);
					}
				});
		return results;
	}


	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, com.healthpartners.service.imfs.exception.BPMException.class })
	public LookUpValueCode getLUVCodeByValue(String value)
			throws DataAccessException {
		final ArrayList<LookUpValueCode> results = new ArrayList<LookUpValueCode>();

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { value };
		int types[] = new int[] { Types.VARCHAR };
		template.query(getLUVCodeByValue, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						LookUpValueCode code = new LookUpValueCode();
						code.setLuvId(rs.getInt(1));
						code.setLuvGroup(rs.getString(2));
						code.setLuvVal(rs.getString(3));
						code.setLuvDesc(rs.getString(4));
						code.setLuvStatus(rs.getString(5));
						code.setLuvNum(rs.getObject(6) == null ? null
								: new Integer(rs.getInt(6)));
						code.setLuvSortOrder(rs.getObject(7) == null ? null
								: new Integer(rs.getInt(7)));
						code.setLuvText(rs.getString(8));						
						results.add(code);
					}
				});

		LookUpValueCode dto = null;
		if (results.size() > 0) {
			dto = (LookUpValueCode) results.get(0);
		}
		return dto;
	}

	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, com.healthpartners.service.imfs.exception.BPMException.class })
	
	public Collection<LookUpValueCode> getLUVCodesByGroup(String group)
			throws DataAccessException {
		final ArrayList<LookUpValueCode> results = new ArrayList<LookUpValueCode>();

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { group };
		int types[] = new int[] { Types.VARCHAR };
		template.query(getLUVCodesByGroup, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						LookUpValueCode code = new LookUpValueCode();
						code.setLuvId(rs.getInt(1));
						code.setLuvGroup(rs.getString(2));
						code.setLuvVal(rs.getString(3));
						code.setLuvDesc(rs.getString(4));
						code.setLuvStatus(rs.getString(5));
						code.setLuvNum(rs.getObject(6) == null ? null
								: new Integer(rs.getInt(6)));
						code.setLuvSortOrder(rs.getObject(7) == null ? null
								: new Integer(rs.getInt(7)));
						code.setLuvText(rs.getString(8));						
						results.add(code);
					}
				});

		return results;
	}

	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, com.healthpartners.service.imfs.exception.BPMException.class })
	
	public LookUpValueCode getLUVCodeByGroupNValue(String group, String value)
			throws DataAccessException {
		final ArrayList<LookUpValueCode> results = new ArrayList<LookUpValueCode>();

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { group, value };
		int types[] = new int[] { Types.VARCHAR, Types.VARCHAR };
		template.query(getLUVCodeByGroupNValue, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						LookUpValueCode code = new LookUpValueCode();
						code.setLuvId(rs.getInt(1));
						code.setLuvGroup(rs.getString(2));
						code.setLuvVal(rs.getString(3));
						code.setLuvDesc(rs.getString(4));
						code.setLuvStatus(rs.getString(5));
						code.setLuvNum(rs.getObject(6) == null ? null
								: new Integer(rs.getInt(6)));
						code.setLuvSortOrder(rs.getObject(7) == null ? null
								: new Integer(rs.getInt(7)));
						code.setLuvText(rs.getString(8));						
						results.add(code);
					}
				});

		LookUpValueCode dto = null;
		if (results.size() > 0) {
			dto = (LookUpValueCode) results.get(0);
		}
		return dto;
	}

	

	

	/**
	 * Sets the getAllLUVCodes SQL statement. Should only be called by Spring.
	 *
	 */
	public void setGetAllLUVCodes(String sql) {
		this.getAllLUVCodes = sql;
	}
	
	

	public void setGetLUVCodeByID(String getLUVCodeByID) {
		this.getLUVCodeByID = getLUVCodeByID;
	}

	/**
	 * Sets the getAllActiveCodes SQL statement. Should only be called by
	 * Spring.
	 *
	 */
	public void setGetActiveLUVCodes(String sql) {
		this.getActiveLUVCodes = sql;
	}


	/**
	 * Sets the getLUVCodeByValue SQL statement. Should only be called by
	 * Spring.
	 *
	 */
	public void setGetLUVCodeByValue(String sql) {
		this.getLUVCodeByValue = sql;
	}

	/**
	 * Sets the getLUVCodeByGroup SQL statement. Should only be called by
	 * Spring.
	 *
	 */
	public void setGetLUVCodesByGroup(String sql) {
		this.getLUVCodesByGroup = sql;
	}

	public void setGetLUVCodeByGroupNValue(String getLUVCodeByGroupNValue) {
		this.getLUVCodeByGroupNValue = getLUVCodeByGroupNValue;
	}
}
package com.healthpartners.service.imfs.dto;

import java.util.Collection;

public class MarketRequirement extends BaseDTO
{
    static final long serialVersionUID = 0L;
        
    private Integer marketIndicatorID;
    private Integer marketIndicatorReqID;

    Collection<MarketRequirementDetail> marketRequirementDetails;
    
    public MarketRequirement()
    {
    	super();
    }

	public Integer getMarketIndicatorID() {
		return marketIndicatorID;
	}

	public void setMarketIndicatorID(Integer marketIndicatorID) {
		this.marketIndicatorID = marketIndicatorID;
	}

	public Integer getMarketIndicatorReqID() {
		return marketIndicatorReqID;
	}

	public void setMarketIndicatorReqID(Integer marketIndicatorReqID) {
		this.marketIndicatorReqID = marketIndicatorReqID;
	}

	public Collection<MarketRequirementDetail> getMarketRequirementDetails() {
		return marketRequirementDetails;
	}

	public void setMarketRequirementDetails(
			Collection<MarketRequirementDetail> marketRequirementDetails) {
		this.marketRequirementDetails = marketRequirementDetails;
	}

	
    
    
}

package com.healthpartners.service.imfs.dto;

import java.io.Serializable;

public class RewardControlProgramProcessTracker implements Serializable
{	
	static final long serialVersionUID = 0L;

	private Integer controlProgramID;
	private Integer rewardCardID;
	private java.sql.Date dateLastProcessed;
	private String processStatus;
	private Integer processStatusID;
	private Integer recordsSent;
	
       
    public RewardControlProgramProcessTracker()
    {
    	super();
    }


	

	public Integer getControlProgramID() {
		return controlProgramID;
	}




	public void setControlProgramID(Integer controlProgramID) {
		this.controlProgramID = controlProgramID;
	}


	


	public Integer getRewardCardID() {
		return rewardCardID;
	}




	public void setRewardCardID(Integer rewardCardID) {
		this.rewardCardID = rewardCardID;
	}




	public java.sql.Date getDateLastProcessed() {
		return dateLastProcessed;
	}


	public void setDateLastProcessed(java.sql.Date dateLastProcessed) {
		this.dateLastProcessed = dateLastProcessed;
	}


	public String getProcessStatus() {
		return processStatus;
	}


	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	public Integer getProcessStatusID() {
		return processStatusID;
	}


	public void setProcessStatusID(Integer processStatusID) {
		this.processStatusID = processStatusID;
	}


	public Integer getRecordsSent() {
		return recordsSent;
	}


	public void setRecordsSent(Integer recordsSent) {
		this.recordsSent = recordsSent;
	}



	
    
	
}

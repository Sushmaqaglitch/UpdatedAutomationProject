/* $Id$ */

package com.healthpartners.service.imfs.iface;

import java.util.ArrayList;
import java.util.Collection;

import com.healthpartners.service.imfs.dto.BusinessProgramTO;
import com.healthpartners.service.imfs.dto.PersonProgramStage;
import com.healthpartners.service.imfs.rules.StatusCalculationCommand;
import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.exception.BPMBusinessValidationException;
import com.healthpartners.service.imfs.exception.BPMException;

/**
 * This interface provides methods for member/program/contract status
 * caluculation. For For further documentation, refer its implementaion class -
 * ProgramStatusCalculationServiceImpl
 * 
 * @author tjquist
 * 
 */
public interface ProgramStatusCalculationService {

	/**
	 * Updates Program, Member and Contract status. This single public method is
	 * resposible for all types of calculations. ie activity and task updates,
	 * batch calculations- etl membership updates, elapsed times(hold for
	 * contact), pending activities, tasks. The parameter class
	 * StatusCalculationCommand - intended to specify the type of process to
	 * run. For further documentation, refer its implementaion class -
	 * ProgramStatusCalculationServiceImpl
	 * 
	 * @param statusCalculationCommand
	 * @throws BPMBusinessValidationException
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public void updateProgramStatus(
			StatusCalculationCommand statusCalculationCommand)
			throws BPMBusinessValidationException, BPMException,
			DataAccessException;
	
	public void updateProgramStatusBasedOnMember(Integer personID)
			throws BPMBusinessValidationException, BPMException,
			DataAccessException;
	
	public void processCDHPHRAContributionsCommand(
			StatusCalculationCommand statusCalculationCommand)
			throws BPMException;
	
	public void processCDHPHSAContributionsCommand(
			StatusCalculationCommand statusCalculationCommand)
			throws BPMException;

	
	public void processReconcilePersonContractHistoryCommand(
			StatusCalculationCommand statusCalculationCommand)
			throws BPMException;
	
	public void processBatchMembersForCommand(
			StatusCalculationCommand statusCalculationCommand)
			throws BPMException;
	
	public void processPendingActivityEventsCommand(
			StatusCalculationCommand statusCalculationCommand) throws BPMException;
	
	public void processRewardFilesFromIntelispendCommand(
			StatusCalculationCommand statusCalculationCommand)
			throws BPMException;
	
	public void processPendingTaskEventsCommand(
			StatusCalculationCommand statusCalculationCommand) throws BPMException;
	
	public void prepareAndSendMembershipDateEmail(ArrayList<BusinessProgramTO> lBusinessProgramsForMembershipList
			, boolean pReadyForMembership);

	public void processEtlMembershipUpdate(Integer pPersonID,
											StatusCalculationCommand statusCalculationCommand)
			throws DataAccessException, BPMException;

	public void createPersonContractOnHoldReport(StatusCalculationCommand statusCalculationCommand) throws BPMException;

	public Collection<PersonProgramStage> membershipFeedTollgate(Collection<PersonProgramStage> personProgramsStage) throws BPMException;


}

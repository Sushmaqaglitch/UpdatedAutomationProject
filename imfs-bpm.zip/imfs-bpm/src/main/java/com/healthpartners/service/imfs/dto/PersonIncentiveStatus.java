package com.healthpartners.service.imfs.dto;

import java.io.Serializable;

/**
 * 
 * @author jxbourbour
 *
 */
public class PersonIncentiveStatus implements Serializable
{	
	static final long serialVersionUID = 0L;
	
	private Integer personDemographicsID;
	private Integer programID;	
	private String personStatus;		
	private Integer relationshipCode;
	
	private Integer programIncentiveOptionID;
	private Integer qualificationCheckmarkID;
	private String activationStatus;
	
		
	public PersonIncentiveStatus()
	{
		super();
	}


	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}


	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}


	public Integer getProgramID() {
		return programID;
	}


	public void setProgramID(Integer programID) {
		this.programID = programID;
	}


	public String getPersonStatus() {
		return personStatus;
	}


	public void setPersonStatus(String personStatus) {
		this.personStatus = personStatus;
	}


	public Integer getRelationshipCode() {
		return relationshipCode;
	}


	public void setRelationshipCode(Integer relationshipCode) {
		this.relationshipCode = relationshipCode;
	}


	public Integer getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}


	public void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}


	public Integer getQualificationCheckmarkID() {
		return qualificationCheckmarkID;
	}


	public void setQualificationCheckmarkID(Integer qualificationCheckmarkID) {
		this.qualificationCheckmarkID = qualificationCheckmarkID;
	}


	public final String getActivationStatus() {
		return activationStatus;
	}


	public final void setActivationStatus(String activationStatus) {
		this.activationStatus = activationStatus;
	}


	
		
}

/* $Id$ */

package com.healthpartners.service.imfs.dto;

public class PersonRelationship extends BaseDTO {

	public static final String REL_SOURCE_POLICY_HOLDER = "POLICY_HOLDER";

	public static final String REL_SOURCE_CONTRACT_RELATED = "CONTRACT_RELATED";

	public static final String REL_SOURCE_COHABITANT = "COHABITANT";

	public static final String REL_TYPE_DOMESTIC_PARTNER = "DOMESTIC PARTNER";
	
	public static final String REL_TYPE_SELF = "SELF";

	public static final String REL_TYPE_SPOUSE = "SPOUSE";

	static final long serialVersionUID = 0L;

	private Integer id;

	private Integer relatedPersonId;

	private String relationshipType;

	private Integer relationshipConfidence;

	private String relationshipSource;

	private Integer relationshipCode;

	private Integer relatedPersonRelationshipCode;
	
	private Integer contractNumber;

	public PersonRelationship() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getRelatedPersonId() {
		return relatedPersonId;
	}

	public void setRelatedPersonId(Integer relatedPersonId) {
		this.relatedPersonId = relatedPersonId;
	}

	public Integer getRelatedPersonRelationshipCode() {
		return relatedPersonRelationshipCode;
	}

	public void setRelatedPersonRelationshipCode(
			Integer relatedPersonRelationshipCode) {
		this.relatedPersonRelationshipCode = relatedPersonRelationshipCode;
	}

	public Integer getRelationshipCode() {
		return relationshipCode;
	}

	public void setRelationshipCode(Integer relationshipCode) {
		this.relationshipCode = relationshipCode;
	}

	public Integer getRelationshipConfidence() {
		return relationshipConfidence;
	}

	public void setRelationshipConfidence(Integer relationshipConfidence) {
		this.relationshipConfidence = relationshipConfidence;
	}

	public String getRelationshipSource() {
		return relationshipSource;
	}

	public void setRelationshipSource(String relationshipSource) {
		this.relationshipSource = relationshipSource;
	}

	public String getRelationshipType() {
		return relationshipType;
	}

	public void setRelationshipType(String relationshipType) {
		this.relationshipType = relationshipType;
	}

	public Integer getContractNumber() {
		return contractNumber;
	}

	public void setContractNumber(Integer contractNumber) {
		this.contractNumber = contractNumber;
	}		
}

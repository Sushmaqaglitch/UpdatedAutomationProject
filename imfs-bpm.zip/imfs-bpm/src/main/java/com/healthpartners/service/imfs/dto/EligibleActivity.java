package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.util.Calendar;

public class EligibleActivity implements Serializable
{	
	static final long serialVersionUID = 0L;
	   
	private ActivityDefinition activityDefinition;
	
	private Integer activityGroupID;
	
	// Eligible ActivityDefinition attributes.
	private String activityCostDescription;
	private String authorizationCode;
	private String qualificationWindowStartDate;
	private String qualificationWindowEndDate;
	private String qualificationWindowEarlyStartDate;
	private String qualificationWindowLateEndDate;
	private Integer activityScore;
	
	// The date the activity needs to be completed by to qualify for the program incentive.
	// Derived using biz qualification window end date.
	private String completionDate;
	
	// The last day a member can enroll into the activity to complete and qualify for the 
	// program year qualification period.
	// Derived field = biz.QualificationWindowEndDate - Duration.
	private String enrollmentEndDate;
	
	// Derived using Activity Enrollment End Date and default warning period.
	private String enrollmentWarningDate;
	 		
	private GenericStatusType eligibleActivityStatus;
	
	public EligibleActivity()
	{
		super();		
	}


	public ActivityDefinition getActivity() {
		return activityDefinition;
	}


	public void setActivity(ActivityDefinition activityDefinition) {
		this.activityDefinition = activityDefinition;
	}


	public String getActivityCostDescription() {
		return activityCostDescription;
	}


	public void setActivityCostDescription(String activityCostDescription) {
		this.activityCostDescription = activityCostDescription;
	}


	public Integer getActivityGroupID() {
		return activityGroupID;
	}


	public void setActivityGroupID(Integer activityGroupID) {
		this.activityGroupID = activityGroupID;
	}


	public Integer getActivityScore() {
		return activityScore;
	}


	public void setActivityScore(Integer activityScore) {
		this.activityScore = activityScore;
	}


	public String getAuthorizationCode() {
		return authorizationCode;
	}


	public void setAuthorizationCode(String authorizationCode) {
		this.authorizationCode = authorizationCode;
	}


	public ActivityDefinition getActivityDefinition() {
		return activityDefinition;
	}


	public void setActivityDefinition(ActivityDefinition activityDefinition) {
		this.activityDefinition = activityDefinition;
	}


	public GenericStatusType getEligibleActivityStatus() {
		return eligibleActivityStatus;
	}


	public void setEligibleActivityStatus(GenericStatusType eligibleActivityStatus) {
		this.eligibleActivityStatus = eligibleActivityStatus;
	}


	public String getCompletionDate() {
		return completionDate;
	}


	public void setCompletionDate(String completionDate) {
		this.completionDate = completionDate;
	}


	public String getEnrollmentEndDate() {
		return enrollmentEndDate;
	}


	public void setEnrollmentEndDate(String enrollmentEndDate) {
		this.enrollmentEndDate = enrollmentEndDate;
	}


	public String getEnrollmentWarningDate() {
		return enrollmentWarningDate;
	}


	public void setEnrollmentWarningDate(String enrollmentWarningDate) {
		this.enrollmentWarningDate = enrollmentWarningDate;
	}


	public String getQualificationWindowEarlyStartDate() {
		return qualificationWindowEarlyStartDate;
	}


	public void setQualificationWindowEarlyStartDate(
			String qualificationWindowEarlyStartDate) {
		this.qualificationWindowEarlyStartDate = qualificationWindowEarlyStartDate;
	}


	public String getQualificationWindowEndDate() {
		return qualificationWindowEndDate;
	}


	public void setQualificationWindowEndDate(String qualificationWindowEndDate) {
		this.qualificationWindowEndDate = qualificationWindowEndDate;
	}


	public String getQualificationWindowLateEndDate() {
		return qualificationWindowLateEndDate;
	}


	public void setQualificationWindowLateEndDate(
			String qualificationWindowLateEndDate) {
		this.qualificationWindowLateEndDate = qualificationWindowLateEndDate;
	}


	public String getQualificationWindowStartDate() {
		return qualificationWindowStartDate;
	}


	public void setQualificationWindowStartDate(String qualificationWindowStartDate) {
		this.qualificationWindowStartDate = qualificationWindowStartDate;
	}
			
}

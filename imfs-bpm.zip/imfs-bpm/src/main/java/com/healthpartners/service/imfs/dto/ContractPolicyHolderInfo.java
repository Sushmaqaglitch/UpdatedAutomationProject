package com.healthpartners.service.imfs.dto;

import java.util.Calendar;

public class ContractPolicyHolderInfo 
{
	private String firstName;
	private String lastName;
	private String middleName;
	private String memberNo;
	private Integer personID;
	private Integer personDemographicsID;

	
	
	public ContractPolicyHolderInfo()
	{
		super();
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getMiddleName() {
		return middleName;
	}


	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}


	public String getMemberNo() {
		return memberNo;
	}


	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}


	public Integer getPersonID() {
		return personID;
	}


	public void setPersonID(Integer personID) {
		this.personID = personID;
	}

	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}

	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}
}

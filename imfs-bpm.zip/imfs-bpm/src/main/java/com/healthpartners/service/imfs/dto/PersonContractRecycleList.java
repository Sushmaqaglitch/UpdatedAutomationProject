package com.healthpartners.service.imfs.dto;

import java.sql.Date;
import java.sql.Time;
/**
 * 
 * @author tjquist
 *
 */
public class PersonContractRecycleList extends BaseDTO {
	
	static final long serialVersionUID = 0L;
	
	private String memberNo;
	private String firstName;
	private String lastName;
	private Date recycleStatusDate;
	private String recycleStatus;
	private Integer contractNo;
	private String groupNo;
	private String groupName;
	private String reasonDescription;
	public String getMemberNo() {
		return memberNo;
	}
	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Date getRecycleStatusDate() {
		return recycleStatusDate;
	}
	public void setRecycleStatusDate(Date recycleStatusDate) {
		this.recycleStatusDate = recycleStatusDate;
	}
	public String getRecycleStatus() {
		return recycleStatus;
	}
	public void setRecycleStatus(String recycleStatus) {
		this.recycleStatus = recycleStatus;
	}
	public Integer getContractNo() {
		return contractNo;
	}
	public void setContractNo(Integer contractNo) {
		this.contractNo = contractNo;
	}

	public String getGroupNo() {
		return groupNo;
	}

	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getReasonDescription() {
		return reasonDescription;
	}

	public void setReasonDescription(String reasonDescription) {
		this.reasonDescription = reasonDescription;
	}
}

/* $Id$ */

package com.healthpartners.service.imfs.impl;

import java.util.ArrayList;
import java.util.Collection;

import com.healthpartners.service.imfs.dao.RuleGroupDAO;
import com.healthpartners.service.imfs.dto.BusinessProgramTO;
import com.healthpartners.service.imfs.iface.RuleGroupService;
import com.healthpartners.service.imfs.rules.RuleAdapter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import com.healthpartners.service.imfs.exception.BPMException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;


/**
 * @author tjquist
 * 
 */
@Component
@Service
public class RuleGroupServiceImpl implements RuleGroupService {
	@Autowired
	private RuleGroupDAO ruleGroupDAO;

	private DataSourceTransactionManager txManager;

	// Cache - since only 1 rule grp TODO:remove later
	Collection<RuleAdapter> cacheRuleGroups = new ArrayList<RuleAdapter>();

	/*
	 * @see com.healthpartners.service.bpm.iface.RuleGroupService#getContractStatusRules(com.healthpartners.service.bpm.dto.BusinessProgramTO)
	 */
	public RuleAdapter getContractStatusRules(BusinessProgramTO businessProgram)
			throws BPMException, DataAccessException {
		return ruleGroupDAO.getContractStatusRules(businessProgram);
	}

	/*
	 * @see com.healthpartners.service.bpm.iface.RuleGroupService#getMemberExemptionRules(com.healthpartners.service.bpm.dto.BusinessProgramTO)
	 */
	public RuleAdapter getMemberExemptionRules(BusinessProgramTO businessProgram)
			throws BPMException, DataAccessException {
		return ruleGroupDAO.getMemberExemptionRules(businessProgram);
	}


	/*
	 * @see com.healthpartners.service.bpm.iface.RuleGroupService#getMemberStatusRules(com.healthpartners.service.bpm.dto.BusinessProgramTO)
	 */
	public RuleAdapter getMemberStatusRules(BusinessProgramTO businessProgram)
			throws BPMException, DataAccessException {
		return ruleGroupDAO.getMemberStatusRules(businessProgram);
	}

	/*
	 * @see com.healthpartners.service.bpm.iface.RuleGroupService#getAllRulesForStatusCalculation(com.healthpartners.service.bpm.dto.BusinessProgram)
	 */
	public Collection<RuleAdapter> getAllRulesForStatusCalculation(
			BusinessProgramTO businessProgram) throws BPMException,
			DataAccessException {

		// Collection<RuleAdapter> ruleGroups = new ArrayList<RuleAdapter>();

		if (cacheRuleGroups.size() < 1) {

			// Retrieve the exemption rule for the program.
			RuleAdapter exemptionRuleAdapter = getMemberExemptionRules(businessProgram);
			cacheRuleGroups.add(exemptionRuleAdapter);

			// Retrieve the member status rule for the program.
			RuleAdapter memberstatusRuleAdapter = getMemberStatusRules(businessProgram);
			cacheRuleGroups.add(memberstatusRuleAdapter);

			// Retrieve the contract status rule for the program.
			RuleAdapter contractstatusRuleAdapter = getContractStatusRules(businessProgram);
			cacheRuleGroups.add(contractstatusRuleAdapter);
		}

		return cacheRuleGroups;
	}

	/**
	 * Gets the <code>dao</code> instance variable (injected by Spring).
	 * 
	 * @return RuleGroupDAO
	 */
	public RuleGroupDAO getRuleGroupDAO() {
		return ruleGroupDAO;
	}

	/**
	 * Set the <code>dao</code> instance variable (injected by Spring).
	 *
	 */
	public void setRuleGroupDAO(RuleGroupDAO ruleGroupDAO) {
		this.ruleGroupDAO = ruleGroupDAO;
	}

	public DataSourceTransactionManager getTxManager() {
		return txManager;
	}

	public void setTxManager(DataSourceTransactionManager txManager) {
		this.txManager = txManager;
	}

}

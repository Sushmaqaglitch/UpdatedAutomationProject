/**
 * 
 */
package com.healthpartners.service.imfs.dto;

/**
 * @author tjquist
 * 
 */
public class TaskEvent extends BaseAuditableDTO {

	static final long serialVersionUID = 0L;

	private String memberID;

	private String taskID; // FOLUP_HBG, FOLUP_BHIO

	private GenericStatusType taskStatus;

	private String sourceSystemID;

	private Long taskEventLogID;

	private String processingStatusValue;
	
	/**
	 * 
	 */
	public TaskEvent() {
		super();
	}

	/**
	 * @return the sourceSystemID
	 */
	public String getSourceSystemID() {
		return sourceSystemID;
	}

	/**
	 * @param sourceSystemID
	 *            the sourceSystemID to set
	 */
	public void setSourceSystemID(String sourceSystemID) {
		this.sourceSystemID = sourceSystemID;
	}

	/**
	 * @return the taskID
	 */
	public String getTaskID() {
		return taskID;
	}

	/**
	 * @param taskID
	 *            the taskID to set
	 */
	public void setTaskID(String taskID) {
		this.taskID = taskID;
	}

	/**
	 * @return the taskStatus
	 */
	public GenericStatusType getTaskStatus() {
		return taskStatus;
	}

	/**
	 * @param taskStatus
	 *            the taskStatus to set
	 */
	public void setTaskStatus(GenericStatusType taskStatus) {
		this.taskStatus = taskStatus;
	}

	/**
	 * @return the memberID
	 */
	public String getMemberID() {
		return memberID;
	}

	/**
	 * @param memberID
	 *            the memberID to set
	 */
	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}

	/**
	 * @return the taskEventLogID
	 */
	public Long getTaskEventLogID() {
		return taskEventLogID;
	}

	/**
	 * @param taskEventLogID
	 *            the taskEventLogID to set
	 */
	public void setTaskEventLogID(Long taskEventLogID) {
		this.taskEventLogID = taskEventLogID;
	}

	/**
	 * @return the processingStatusValue
	 */
	public String getProcessingStatusValue() {
		return processingStatusValue;
	}

	/**
	 * @param processingStatusValue
	 *            the processingStatusValue to set
	 */
	public void setProcessingStatusValue(String processingStatusValue) {
		this.processingStatusValue = processingStatusValue;
	}
}

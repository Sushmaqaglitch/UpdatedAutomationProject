package com.healthpartners.service.imfs.dao;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.ActivityDefinition;
import com.healthpartners.service.imfs.dto.ActivityEvent;
import com.healthpartners.service.imfs.dto.ActivityFulfillmentTrackingReportHist;
import com.healthpartners.service.imfs.dto.BPMBusinessProgram;
import com.healthpartners.service.imfs.dto.CDHPFulfillmentTrackingRecycle;
import com.healthpartners.service.imfs.dto.CDHPFulfillmentTrackingReportHist;
import com.healthpartners.service.imfs.dto.Contract;
import com.healthpartners.service.imfs.dto.ContractPolicyHolderInfo;
import com.healthpartners.service.imfs.dto.EmployerFulfillmentMemberActivity;
import com.healthpartners.service.imfs.dto.GenericStatusType;
import com.healthpartners.service.imfs.dto.Member;
import com.healthpartners.service.imfs.dto.MemberActivity;
import com.healthpartners.service.imfs.dto.MemberProgramUpdateTO;
import com.healthpartners.service.imfs.dto.MemberStatus;
import com.healthpartners.service.imfs.dto.MemberUpdate;
import com.healthpartners.service.imfs.dto.NamedParameter;
import com.healthpartners.service.imfs.dto.Person;
import com.healthpartners.service.imfs.dto.PersonActivityAchievedContribution;
import com.healthpartners.service.imfs.dto.PersonActivityAchievedReward;
import com.healthpartners.service.imfs.dto.PersonActivityIncentToFulfillReconcile;
import com.healthpartners.service.imfs.dto.PersonActivityToContribGridReport;
import com.healthpartners.service.imfs.dto.PersonContractHist;
import com.healthpartners.service.imfs.dto.PersonContractRecycle;
import com.healthpartners.service.imfs.dto.PersonContractRecycleList;
import com.healthpartners.service.imfs.dto.PersonPackage;
import com.healthpartners.service.imfs.dto.PersonProgramActivityIncentiveStatus;
import com.healthpartners.service.imfs.dto.PersonProgramHealthPlan;
import com.healthpartners.service.imfs.dto.PersonProgramStage;
import com.healthpartners.service.imfs.dto.PersonRelationship;
import com.healthpartners.service.imfs.dto.RelationshipEndDate;
import com.healthpartners.service.imfs.dto.RequiredParticipant;
import com.healthpartners.service.imfs.dto.RewardFulfillmentTrackingReportHist;
import com.healthpartners.service.imfs.dto.RewardIntelispendShipped;
import com.healthpartners.service.imfs.exception.BPMException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.dao.DuplicateKeyException;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;
import java.sql.*;
import java.sql.Date;
import java.util.*;

/**
 * @author tjquist
 */
@Configuration
public class PersonDAOJdbc extends JdbcDaoSupport implements PersonDAO {
    private String getPersonByMemberId;

    private String getPersonByPersonId;

    private String selectMemberStatus;

    private String selectPersonRelationship;

    private String selectParticipant;

    private String selectParticipantRetroactive;

    private String selectUpdatedParticipant;

    // sql insert/update memberprogram status
    private String updateMemberProgramStatus;

    private String updateMemberProgramStatusPartEndDate;

    private String updateMemberProgramStatusContractStatusDate;

    private String updateMemberProgramStatusExternalPersonID;

    private String insertMemberProgramStatus;

    private String insertEmployerFulfillmentMemberActivityCompletions;

    private String insertPersonActivityFulfillmentHistory;

    private String getMemberProgramStatus;

    private String selectMemberProgramStatusDetail;

    private String countMemberProgramStatusRows;

    private String countMultiActivityRewardFulfilled;

    private String findLatestRewardFulfillStatus;

    private String selectMemberContractStatus;

    private String selectMembershipStatusUpdateFeed;

    private String selectPersonProgramActivityStatusAchieved;

    private String selectOffHoldForContact;

    private String getMemberIDFromPersonID;

    private String getPersonIDFromPersonDemographicsID;

    private String getPersonIDFromMemberID;

    private String getPersonDemographicsIDFromPersonID;

    private String selectNightlyUpdateMembers;

    private String deleteMemberProgramStatus;

    private String endMemberParticipation;
    private String selectWhichEndDate;

    private String insertPersonProgramStatus18YearOldsForIncentiveOptionByProgramType;
    private String insertPersonProgramStatus18YearOldsForIncentiveOptionByProgramTypeContract;

    private String selectPersonContractHistForPersonMax;

    private String selectPersonContractRecycleForPerson;

    private String selectPersonContractRecycleOnHolds;

    private String selectPersonContractRecycleByRecycleStatus;

    private String selectCDHPRecycleForPerson;


    private String selectPersonContractHistForContractStatus;

    private String selectPersonContractsRecycle;


    private String selectEmployerFulfillmentMemberActivityCompletions;

    private String insertPersonContractHist;

    private String insertPersonContractHistArchive;

    private String insertPersonContractRecycle;

    private String insertPersonContractRecyclePerTollgateRules;

    private String selectPersonContractsRecycleForStatus;

    private String updatePersonContractRecycleStatus;

    private String updatePersonContractRecycleStatusWithReasonDesc;

    private String insertCDHPFulfillRecycle;

    private String selectPersonPgmActivityIncentiveStatus;

    private String selectPersonPgmActivityIncentiveStatusEnhanced;
    private String selectMemberPgmActivityIncentiveStatusEnhanced;

    private String updateCDHPFulfillRecycleStatus;

    private String selectPersonContractsHist;

    private String selectPersonContractsHistForArchive;

    private String countPersonContractHistRows;

    private String countPersonContractRecycleRows;

    private String deletePersonContractsHist;

    private String deletePersonContractsRecycle;

    private String selectIfContractEndDate;
    private String selectIfSubgroupEndDate;
    private String selectIfPackageEndDate;

    private String endContractParticipation;

    private String selectFirstContractStatusDate;
    private String insertProcessingStatusLogForPastContractEndDates;

    private String selectPersonContractHistoryReconciled;

    private String selectPersonActivityIncentToFulfillReconciled;
    private String selectMemberActivityIncentToFulfillReconciled;

    private String selectHRAPersonActivityAchievedContribution;
    private String selectHRAContractActivityAchievedContribution;
    private String selectHRAMemberActivityAchievedContribution;

    private String selectHRAContractActivityAchievedContributionWithContribGrid;
    private String selectHRAMemberActivityAchievedContributionWithContribGrid;

    private String selectHSAPersonActivityAchievedContribution;
    private String selectHSAContractActivityAchievedContribution;
    private String selectHSAContractActivityAchievedContributionWithContribGrid;
    private String selectHSAMemberActivityAchievedContribution;
    private String selectHSAMemberActivityAchievedContributionWithContribGrid;

    private String selectPersonActivityAchievedReward;

    private String selectCDHPFulfillmentTrackingReportHist;
    private String selectCDHPFulfillmentTrackingReportHistByGroup;

    private String selectRewardFulfillmentTrackingReportHistByProgram;

    private String selectProgramByRewardFulfillTransHistID;

    private String selectEmployerSponsoredPersonActivityAchievedContribution;

    private String selectEmployerSponsoredPersonActivityAchievedContributionRecycleApprovals;

    private String selectPersonCDHPContributionAlreadySent;

    private String insertCDHPCompletion;

    private String insertCDHPCompletionHistory;

    private String insertRewardFulfillHistory;

    private String selectPersonContributions;

    private String selectUnresolvedPersonPgmActivityIncentiveStatus;


    private String selectPersonSocialSecurityNo;

    private String selectMemberNoUsingMODS;

    private String selectPersonHealthPlanCode;
    private String updatePersonHealthPlanCode;

    private String selectPersonPgmActivityIncentives;

    private String selectPersonRewardAlreadySent;


    private String insertRewardFulfillmentStatus;

    private String insertRewardCompletionHistory;

    private String updateRewardFulfillmentHistWTodaysDate;

    private String updateRewardFulfillRptTrackHist;

    private String updateRewardFulfillmentStatus;
    private String updateRewardFulfillHistoryStatus;

    private String selectPersonPackages;

    private String selectPersonPackagesRetroTerms;

    private String updateRewardFulfillmentHistWOrderNumber;

    private String matchIncomingOrderNoToFulfillOrderNo;

    private String matchIncomingManualOrderToRewardFulfillHist;

    private String selectRewardFulfillHistIDByExternalTransID;

    private String selectContractActivityAchievedReward;
    private String selectMemberActivityAchievedReward;
    private String selectContractActivityAchievedRewardWithContribGrid;
    private String selectMemberActivityAchievedRewardWithContribGrid;

    private String selectActivityFulfillmentTrackingReportHist;

    private String isPersonActivityFulfillmentHistoryNotExist;

    private String selectMemberIDFromPersonDetails;

    private String determineIfMemberIsParticipating;

    private String updatePersonProgramIncentiveCheckmarkID;
    private String updatePersonQualificationCheckmark;

    private String selectPersonActivityIncentiveUnresolvedBenefitContractTypes;

    private String selectPersonActivityToContribGrid;
    private String selectPersonContractActivityToContribGrid;
    private String isContractIncentedForActivity;

    private String selectMemberPgmActivityIncentiveStatus;

    private String selectPersonsEligibleBeyondQualificationPeriod;

    private String isCDHPPersonActivityIncentToFulfillReconcile;
    private String isRewardPersonActivityIncentToFulfillReconcile;
    private String selectContractPgmActivityIncentiveStatus;

    private String isPersonContractProgramHistExist;

    private String selectPersonBusinessPrograms;


    /*
     * SQL sequences
     */
    @Autowired
    private DataFieldMaxValueIncrementer personContractHistIdIncrementer;
    @Autowired
    private DataFieldMaxValueIncrementer personContractHistArchiveIdIncrementer;
    @Autowired
    private DataFieldMaxValueIncrementer personContractRecycleIdIncrementer;
    @Autowired
    private DataFieldMaxValueIncrementer cdhpRecycleIdIncrementer;
    @Autowired
    private DataFieldMaxValueIncrementer cdhpTransIdIncrementer;
    @Autowired
    private DataFieldMaxValueIncrementer rewardTransIdIncrementer;

    @Autowired
    private DataFieldMaxValueIncrementer rewardStatusTransIdIncrementer;
    @Autowired
    private ContractDAO contractDAO;


    @Autowired
    DataSource bpmDataSource;

    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @PostConstruct
    private void initialize() {

        setDataSource(bpmDataSource);
    }


    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Person getPersonByMemberId(String memberNo)
            throws DataAccessException {

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("memberNo", memberNo, Types.VARCHAR);


        List<Person> results = namedParameterJdbcTemplate.query(getPersonByMemberId, namedParameters,
                new RowMapper() {
                    @Override
                    public Person mapRow(ResultSet rs, int i) throws SQLException {
                        Person person = new Person();
                            person.setId(new Integer(rs.getInt("PRSN_DMGRPHCS_ID")));
                            person.setMemberId(rs.getString("HP_MEM_ID"));
                            person.setFirstName(rs.getString("FIRST_NM"));
                            person.setMiddleName(rs.getString("MIDDLE_NM"));
                            person.setLastName(rs.getString("LAST_NM"));
                            person.setGenderDescription(rs
                                    .getString("GENDER_CD"));

                            person.setDateOfBirth(rs.getTimestamp("DOB_DT"));
                       return person;
                    }



                        /*
                         * String attributeName = rs.getString(18); if
                         * (attributeName != null) { String attributeValue =
                         * rs.getString(19); PersonAttribute attribute = person
                         * .getAttribute(attributeName); if (attribute == null) {
                         * attribute = new PersonAttribute(attributeName,
                         * attributeValue); } else {
                         * attribute.addAttributeValue(attributeValue); }
                         * person.setAttribute(attribute); }
                         */

                });

        Person dto = null;
        if (results.size() > 0) {
            dto = (Person) results.get(0);
        }

        return dto;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Person getPersonByPersonId(Integer personId)
            throws DataAccessException {

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("personId", personId, Types.INTEGER);

        List<Person> results = namedParameterJdbcTemplate.query(getPersonByPersonId, namedParameters,
                new RowMapper() {
                    @Override
                    public Person mapRow(ResultSet rs, int i) throws SQLException {
                        Person person =  new Person();
                            person.setId(new Integer(rs.getInt("PRSN_DMGRPHCS_ID")));
                            person.setMemberId(rs.getString("HP_MEM_ID"));
                            person.setFirstName(rs.getString("FIRST_NM"));
                            person.setMiddleName(rs.getString("MIDDLE_NM"));
                            person.setLastName(rs.getString("LAST_NM"));
                            person.setGenderDescription(rs
                                    .getString("GENDER_CD"));

                            person.setDateOfBirth(rs.getTimestamp("DOB_DT"));


                        return person;
                    }

                });

        Person dto = null;
        if (results.size() > 0) {
            dto = (Person) results.get(0);
        }


        return dto;
    }

    /**
     * used by web service call
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Member getMemberStatus(int personID, int pProgramID, boolean pCalledFromWebPortal)
            throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();
        Object params[] = null;
        lQuery.append(selectMemberStatus);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();


        if (pProgramID > 0) {
            namedParameters.addValue("personID", personID, Types.INTEGER);
            namedParameters.addValue("pProgramID", pProgramID, Types.INTEGER);
            lQuery.append(" AND biz.biz_pgm_id = :pProgramID");
        } else {
            namedParameters.addValue("personID", personID, Types.INTEGER);
        }

        if (pCalledFromWebPortal) {
            lQuery.append(" AND trunc(SYSDATE) BETWEEN biz.eff_dt AND biz.pgm_end_dt ");
            lQuery.append(" AND (stat.PARTICIPATION_END_DT IS NULL OR trunc(stat.PARTICIPATION_END_DT) > trunc(SYSDATE)) ");
            lQuery.append(" AND (con_stat.PARTICIPATION_END_DT IS NULL OR trunc(con_stat.PARTICIPATION_END_DT) > trunc(SYSDATE)) ");
        }


        List<Member> lMembers = namedParameterJdbcTemplate.query(lQuery
                .toString(), namedParameters, new MemberRowMapper());

        Member dto = null;
        if (lMembers.size() > 0) {
            dto = (Member) lMembers.get(0);
        }

        return dto;
    }

    /**
     * Keep the getPersonRelationship signature to avoid changing the callers.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<PersonRelationship> getPersonRelationship(Integer personId)
            throws DataAccessException {
        return getPersonRelationship(personId, 0);
    }

    /**
     * @param personId
     * @param pBusinessProgramID
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<PersonRelationship> getPersonRelationship(Integer personID, Integer pBusinessProgramID)
            throws DataAccessException {
        final ArrayList<PersonRelationship> results = new ArrayList<PersonRelationship>();

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectPersonRelationship);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();

        if (pBusinessProgramID > 0) {
            namedParameters.addValue("personId", personID, Types.INTEGER);
            namedParameters.addValue("bizPgmId", pBusinessProgramID, Types.INTEGER);
        }


        namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public PersonRelationship mapRow(ResultSet rs, int i) throws SQLException {
                        PersonRelationship personRelationship = new PersonRelationship();
                        personRelationship.setId(rs.getInt("PRSN_DMGRPHCS_ID"));
                        personRelationship.setRelatedPersonId(rs.getInt("PRSN_DMGRPHCS_ID"));
                        personRelationship.setRelationshipType(rs
                                .getString("rlshp_txt"));
                        personRelationship.setRelationshipCode(rs
                                .getObject("rel_cd") == null ? null
                                : new Integer(rs.getInt("rel_cd")));
                        personRelationship.setContractNumber(rs
                                .getInt("contract_no"));
                        results.add(personRelationship);
                        return personRelationship;
                    }

                });

        return results;
    }

    /**
     * @param lActivityEvent
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public PersonProgramActivityIncentiveStatus getPersonPgmActivityIncentiveStatus(ActivityEvent lActivityEvent)
            throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectPersonPgmActivityIncentiveStatus);


        Integer programID = lActivityEvent.getMemberActivity().getBusinessProgramID();
        Integer personDemographicsID = lActivityEvent.getPersonDemographicsID();
        Integer activityID = lActivityEvent.getMemberActivity().getActivity().getActivityID();
        String registrationID = lActivityEvent.getMemberActivity().getRegistrationID();

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();

        namedParameters.addValue("programID", programID, Types.INTEGER);
        namedParameters.addValue("personId", personDemographicsID, Types.INTEGER);
        namedParameters.addValue("actvId", activityID, Types.INTEGER);
        namedParameters.addValue("registrationId", registrationID, Types.VARCHAR);

        List<PersonProgramActivityIncentiveStatus> results =  namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public PersonProgramActivityIncentiveStatus mapRow(ResultSet rs, int i) throws SQLException {
                        PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus = new PersonProgramActivityIncentiveStatus();

                        lPersonProgramActivityIncentiveStatus.setProgramID(rs
                                .getInt("BIZ_PGM_ID"));
                        lPersonProgramActivityIncentiveStatus.setPersonDemographicsID(rs
                                .getInt("PRSN_DMGRPHCS_ID"));
                        lPersonProgramActivityIncentiveStatus.setActivityID(rs
                                .getInt("ACTV_ID"));
                        lPersonProgramActivityIncentiveStatus.setActivityIncentiveID(rs
                                .getInt("ACTV_INCNTV_ID"));
                        lPersonProgramActivityIncentiveStatus.setActivityStatusCodeID(rs
                                .getInt("ACTV_STAT_CD_ID"));
                        lPersonProgramActivityIncentiveStatus.setRegistrationID(rs
                                .getString("REGISTRATION_ID"));
                        lPersonProgramActivityIncentiveStatus.setActivityStatusIncentiveDate(rs
                                .getDate("ACTV_STAT_INCNTV_DT"));
                        lPersonProgramActivityIncentiveStatus.setBeneftiContractTypeLuID(rs
                                .getInt("BEN_CONTR_TP_LU_ID"));
                        lPersonProgramActivityIncentiveStatus.setContributionAmt(rs
                                .getInt("CONTRIB_AMT"));
                        return lPersonProgramActivityIncentiveStatus;
                    }

                });

        PersonProgramActivityIncentiveStatus dto = null;
        if (results.size() > 0) {
            dto = (PersonProgramActivityIncentiveStatus) results.get(0);
        }

        return dto;
    }

    /**
     * @param lActivityEvent
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public PersonProgramActivityIncentiveStatus getPersonPgmActivityIncentiveStatusEnhanced(Integer programID, Integer personDemographicsID, Integer activityID, Date activityStatusDate, Integer contributionAmt)
            throws DataAccessException {
        final ArrayList<PersonProgramActivityIncentiveStatus> results = new ArrayList<PersonProgramActivityIncentiveStatus>();

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectPersonPgmActivityIncentiveStatusEnhanced);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();

        namedParameters.addValue("personDemographicsID", personDemographicsID, Types.INTEGER);
        namedParameters.addValue("actvId", activityID, Types.INTEGER);

        if (programID != null && programID > 0) {
            namedParameters.addValue("bizPgmId", programID, Types.INTEGER);
            lQuery.append(" AND bp.biz_pgm_id = :bizPgmId ");
        }

        if (activityStatusDate != null) {
            namedParameters.addValue("startDate", activityStatusDate, Types.DATE);
            lQuery.append(" AND ppais.actv_stat_incntv_dt = :startDate ");
        }

        if (contributionAmt != null && contributionAmt > 0) {
            namedParameters.addValue("contribAmt", contributionAmt, Types.INTEGER);
            lQuery.append(" AND ppais.contrib_amt = :contribAmt ");
        }


        namedParameters.addValue("personDemographicsID", personDemographicsID, Types.INTEGER);
        namedParameters.addValue("activityID", activityID, Types.INTEGER);
        namedParameters.addValue("activityStatusDate", activityStatusDate, Types.DATE);

        if (programID != null && programID > 0) {
            namedParameters.addValue("bizPgmId", programID, Types.INTEGER);
            lQuery.append(" AND bp.biz_pgm_id = :bizPgmId ");
        }
        if (activityStatusDate != null) {
            namedParameters.addValue("startDate", activityStatusDate, Types.DATE);
            lQuery.append(" AND ppais.actv_stat_incntv_dt = :startDate ");
        }


        namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public PersonProgramActivityIncentiveStatus mapRow(ResultSet rs, int i) throws SQLException {
                        PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus = new PersonProgramActivityIncentiveStatus();

                        lPersonProgramActivityIncentiveStatus.setProgramID(rs
                                .getInt("BIZ_PGM_ID"));
                        lPersonProgramActivityIncentiveStatus.setPersonDemographicsID(rs
                                .getInt("PRSN_DMGRPHCS_ID"));
                        lPersonProgramActivityIncentiveStatus.setActivityID(rs
                                .getInt("ACTV_ID"));
                        lPersonProgramActivityIncentiveStatus.setActivityIncentiveID(rs
                                .getInt("ACTV_INCNTV_ID"));
                        lPersonProgramActivityIncentiveStatus.setActivityStatusCodeID(rs
                                .getInt("ACTV_STAT_CD_ID"));
                        lPersonProgramActivityIncentiveStatus.setRegistrationID(rs
                                .getString("REGISTRATION_ID"));
                        lPersonProgramActivityIncentiveStatus.setActivityStatusIncentiveDate(rs
                                .getDate("ACTV_STAT_INCNTV_DT"));
                        lPersonProgramActivityIncentiveStatus.setBeneftiContractTypeLuID(rs
                                .getInt("BEN_CONTR_TP_LU_ID"));
                        lPersonProgramActivityIncentiveStatus.setContributionAmt(rs
                                .getInt("CONTRIB_AMT"));
                        lPersonProgramActivityIncentiveStatus.setGroupNo(rs
                                .getString("empl_grp_no"));
                        lPersonProgramActivityIncentiveStatus.setSiteNo(rs
                                .getString("empl_grp_site_id_no"));
                        lPersonProgramActivityIncentiveStatus.setMemberNo(rs
                                .getString("hp_mem_id"));
                        lPersonProgramActivityIncentiveStatus.setLastName(rs
                                .getString("last_nm"));
                        lPersonProgramActivityIncentiveStatus.setFirstName(rs
                                .getString("first_nm"));
                        lPersonProgramActivityIncentiveStatus.setSourceActivityID(rs
                                .getString("srce_actv_id"));
                        lPersonProgramActivityIncentiveStatus.setActivityName(rs
                                .getString("actv_nm"));
                        lPersonProgramActivityIncentiveStatus.setInsertDate(rs
                                .getDate("insert_ts"));
                        results.add(lPersonProgramActivityIncentiveStatus);
                        return lPersonProgramActivityIncentiveStatus;
                    }

                });

        PersonProgramActivityIncentiveStatus dto = null;
        if (results.size() > 0) {
            dto = (PersonProgramActivityIncentiveStatus) results.get(0);
        }


        return dto;
    }


    /**
     * @param programID
     * @param contractNo
     * @param activityID
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public List<PersonProgramActivityIncentiveStatus> getContractPgmActivityIncentiveStatus(Integer programID, Integer contractNo, Integer incentiveOptionID, Integer activityID)
            throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectContractPgmActivityIncentiveStatus);


        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("bizPgmId", programID, Types.INTEGER);
        namedParameters.addValue("contractId", contractNo, Types.VARCHAR);

        if (activityID != null) {
            namedParameters.addValue("actvId", activityID, Types.INTEGER);
            lQuery.append(" AND ppas.actv_id = :actvId");
        }

        if (incentiveOptionID != null) {
            namedParameters.addValue("incentiveOptionID", incentiveOptionID, Types.INTEGER);
            lQuery.append(" AND cpis.incntv_optn_id = :incentiveOptionID");
        }
        lQuery.append("order by cpis.cntr_sts_achv_dt asc");


        List<PersonProgramActivityIncentiveStatus> results = namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public PersonProgramActivityIncentiveStatus mapRow(ResultSet rs, int i) throws SQLException {
                        PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus = new PersonProgramActivityIncentiveStatus();

                        lPersonProgramActivityIncentiveStatus.setProgramID(rs
                                .getInt("BIZ_PGM_ID"));
                        lPersonProgramActivityIncentiveStatus.setPersonDemographicsID(rs
                                .getInt("PRSN_DMGRPHCS_ID"));
                        lPersonProgramActivityIncentiveStatus.setActivityID(rs
                                .getInt("ACTV_ID"));
                        lPersonProgramActivityIncentiveStatus.setActivityStatusCodeID(rs
                                .getInt("ACTV_STAT_CD_ID"));
                        lPersonProgramActivityIncentiveStatus.setActivityStatusIncentiveDate(rs
                                .getDate("ACTV_STAT_INCNTV_DT"));
                        lPersonProgramActivityIncentiveStatus.setBeneftiContractTypeLuID(rs
                                .getInt("BEN_CONTR_TP_LU_ID"));
                        lPersonProgramActivityIncentiveStatus.setContributionAmt(rs
                                .getInt("CONTRIB_AMT"));
                        lPersonProgramActivityIncentiveStatus.setGroupNo(rs
                                .getString("empl_grp_no"));
                        lPersonProgramActivityIncentiveStatus.setSiteNo(rs
                                .getString("empl_grp_site_id_no"));
                        lPersonProgramActivityIncentiveStatus.setMemberNo(rs
                                .getString("hp_mem_id"));
                        lPersonProgramActivityIncentiveStatus.setLastName(rs
                                .getString("last_nm"));
                        lPersonProgramActivityIncentiveStatus.setFirstName(rs
                                .getString("first_nm"));
                        lPersonProgramActivityIncentiveStatus.setSourceActivityID(rs
                                .getString("srce_actv_id"));
                        lPersonProgramActivityIncentiveStatus.setActivityName(rs
                                .getString("actv_nm"));
                        lPersonProgramActivityIncentiveStatus.setProgramMemberIncentiveStatusID(rs
                                .getInt("cntr_pgm_stat_id"));
                        lPersonProgramActivityIncentiveStatus.setInsertDate(rs
                                .getDate("insert_ts"));
                        lPersonProgramActivityIncentiveStatus.setPersonProgramActivityStatusID(rs
                                .getInt("prsn_pgm_actv_sts_id"));
                        lPersonProgramActivityIncentiveStatus.setProgramEffectiveDate(rs
                                .getDate("eff_dt"));
                        lPersonProgramActivityIncentiveStatus.setProgramEndDate(rs
                                .getDate("pgm_end_dt"));
                        return lPersonProgramActivityIncentiveStatus;
                    }


                });


        return results;
    }

    /**
     * @param programID
     * @param personDemographicsID
     * @param activityID
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public PersonProgramActivityIncentiveStatus getMemberPgmActivityIncentiveStatus(Integer programID, Integer personDemographicsID, Integer incentiveOptionID, Integer activityID)
            throws DataAccessException {
        StringBuffer lQuery = new StringBuffer();
        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();


        lQuery.append(selectMemberPgmActivityIncentiveStatus);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("bizPgmId", programID, Types.INTEGER);
        namedParameters.addValue("personDemographicsID", personDemographicsID, Types.INTEGER);

        if (activityID != null) {
            namedParameters.addValue("actvId", activityID, Types.INTEGER);
            lQuery.append(" AND ppas.actv_id = :actvId");
            lParameters.add(activityID);
            lTypes.add(new Integer(Types.INTEGER));
        }

        if (incentiveOptionID != null) {
            namedParameters.addValue("incentiveId", incentiveOptionID, Types.INTEGER);
            lQuery.append(" AND pmis.incntv_optn_id = :incentiveId");
        }

        lQuery.append(" order by pmis.mbr_stat_achv_dt asc");

        List<PersonProgramActivityIncentiveStatus> results = namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new MemberPgmActivityIncentiveStatusRowMapper());


        PersonProgramActivityIncentiveStatus dto = null;
        if (results.size() > 0) {
            dto = (PersonProgramActivityIncentiveStatus) results.get(0);
        }


        return dto;
    }

    /**
     * @param programID
     * @param personDemographicsID
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public List<PersonProgramActivityIncentiveStatus> getMemberPgmActivityIncentiveStatuses(Integer programID, Integer personDemographicsID, String activityStatusCode, String memberStatusCode)
            throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();

        lQuery.append(selectMemberPgmActivityIncentiveStatus);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("bizPgmId", programID, Types.INTEGER);
        namedParameters.addValue("personId", personDemographicsID, Types.INTEGER);

        if (activityStatusCode != null) {

            namedParameters.addValue("luVal", activityStatusCode, Types.VARCHAR);

            lQuery.append(" AND ppas.actv_stat_cd_id = (select l.lu_id from luv l where l.lu_grp = 'BPM_ACTIVITY_STATUS' and l.lu_val = :luVal) ");
        }

        if (memberStatusCode != null) {
            namedParameters.addValue("luValNo", memberStatusCode, Types.VARCHAR);
            lQuery.append(" and pmis.mbr_stat_cd_id = (select luv.lu_id from luv luv where luv.lu_grp = 'BPM_MBR_INCNTV_STS' and luv.lu_val = :luValNo) ");
        }

        lQuery.append("order by pmis.mbr_stat_achv_dt asc");



        List<PersonProgramActivityIncentiveStatus> results = namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new MemberPgmActivityIncentiveStatusRowMapper());

        return results;
    }

    /**
     * @param programID
     * @param personDemographicsID
     * @param activityID
     * @param activityStatusDate
     * @param contributionAmt
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public PersonProgramActivityIncentiveStatus getMemberPgmActivityIncentiveStatusEnhanced(Integer programID, Integer personDemographicsID, Integer activityID, Date activityStatusDate, Integer contributionAmt)
            throws DataAccessException {
        final ArrayList<PersonProgramActivityIncentiveStatus> results = new ArrayList<PersonProgramActivityIncentiveStatus>();

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectMemberPgmActivityIncentiveStatusEnhanced);



        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("personId", personDemographicsID, Types.INTEGER);
        namedParameters.addValue("actvId", activityID, Types.INTEGER);


        if (programID != null && programID > 0) {
            namedParameters.addValue("bizPgmId", programID, Types.INTEGER);
            lQuery.append(" AND ppas.biz_pgm_id = :bizPgmId ");
        }

        if (activityStatusDate != null) {
            namedParameters.addValue("startDate", activityStatusDate, Types.DATE);
            lQuery.append(" AND ppas.actv_stat_dt = :startDate ");
        }

        if (contributionAmt != null && contributionAmt > 0) {
            namedParameters.addValue("contribAmt", contributionAmt, Types.INTEGER);
            lQuery.append(" AND pmis.contrib_amt = :contribAmt ");
        }



        namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public PersonProgramActivityIncentiveStatus mapRow(ResultSet rs, int i) throws SQLException {
                        PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus = new PersonProgramActivityIncentiveStatus();

                        lPersonProgramActivityIncentiveStatus.setProgramID(rs
                                .getInt("BIZ_PGM_ID"));
                        lPersonProgramActivityIncentiveStatus.setPersonDemographicsID(rs
                                .getInt("PRSN_DMGRPHCS_ID"));
                        lPersonProgramActivityIncentiveStatus.setActivityID(rs
                                .getInt("ACTV_ID"));
                        lPersonProgramActivityIncentiveStatus.setActivityStatusCodeID(rs
                                .getInt("ACTV_STAT_CD_ID"));
                        lPersonProgramActivityIncentiveStatus.setActivityStatusIncentiveDate(rs
                                .getDate("ACTV_STAT_INCNTV_DT"));
                        lPersonProgramActivityIncentiveStatus.setBeneftiContractTypeLuID(rs
                                .getInt("BEN_CONTR_TP_LU_ID"));
                        lPersonProgramActivityIncentiveStatus.setContributionAmt(rs
                                .getInt("CONTRIB_AMT"));
                        lPersonProgramActivityIncentiveStatus.setGroupNo(rs
                                .getString("empl_grp_no"));
                        lPersonProgramActivityIncentiveStatus.setSiteNo(rs
                                .getString("empl_grp_site_id_no"));
                        lPersonProgramActivityIncentiveStatus.setMemberNo(rs
                                .getString("hp_mem_id"));
                        lPersonProgramActivityIncentiveStatus.setLastName(rs
                                .getString("last_nm"));
                        lPersonProgramActivityIncentiveStatus.setFirstName(rs
                                .getString("first_nm"));
                        lPersonProgramActivityIncentiveStatus.setSourceActivityID(rs
                                .getString("srce_actv_id"));
                        lPersonProgramActivityIncentiveStatus.setActivityName(rs
                                .getString("actv_nm"));
                        lPersonProgramActivityIncentiveStatus.setInsertDate(rs
                                .getDate("insert_ts"));
                        results.add(lPersonProgramActivityIncentiveStatus);
                        return lPersonProgramActivityIncentiveStatus;
                    }
                });

        PersonProgramActivityIncentiveStatus dto = null;
        if (results.size() > 0) {
            dto = (PersonProgramActivityIncentiveStatus) results.get(0);
        }


        return dto;
    }


    /**
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public PersonProgramActivityIncentiveStatus getPersonPgmActivityIncentives(Integer programID, Integer personDemograhicsID)
            throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectPersonPgmActivityIncentives);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("bizPgmId", programID, Types.INTEGER);
        namedParameters.addValue("personId", personDemograhicsID, Types.INTEGER);

        List<PersonProgramActivityIncentiveStatus> results = namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public PersonProgramActivityIncentiveStatus mapRow(ResultSet rs, int i) throws SQLException {
                        PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus = new PersonProgramActivityIncentiveStatus();

                        lPersonProgramActivityIncentiveStatus.setProgramID(rs
                                .getInt("BIZ_PGM_ID"));
                        lPersonProgramActivityIncentiveStatus.setPersonDemographicsID(rs
                                .getInt("PRSN_DMGRPHCS_ID"));
                        lPersonProgramActivityIncentiveStatus.setActivityID(rs
                                .getInt("ACTV_ID"));
                        lPersonProgramActivityIncentiveStatus.setActivityIncentiveID(rs
                                .getInt("ACTV_INCNTV_ID"));
                        lPersonProgramActivityIncentiveStatus.setActivityStatusCodeID(rs
                                .getInt("ACTV_STAT_CD_ID"));
                        lPersonProgramActivityIncentiveStatus.setRegistrationID(rs
                                .getString("REGISTRATION_ID"));
                        lPersonProgramActivityIncentiveStatus.setActivityStatusIncentiveDate(rs
                                .getDate("ACTV_STAT_INCNTV_DT"));
                        lPersonProgramActivityIncentiveStatus.setBeneftiContractTypeLuID(rs
                                .getInt("BEN_CONTR_TP_LU_ID"));
                        lPersonProgramActivityIncentiveStatus.setContributionAmt(rs
                                .getInt("CONTRIB_AMT"));
                        return lPersonProgramActivityIncentiveStatus;
                    }

                });

        PersonProgramActivityIncentiveStatus dto = null;
        if (results.size() > 0) {
            dto = (PersonProgramActivityIncentiveStatus) results.get(0);
        }


        return dto;
    }

    /**
     * @return Integer personSSN
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Integer getPersonSoicalSecurityNo(Integer lPersonID)
            throws DataAccessException {

        final ArrayList<Integer> results = new ArrayList<Integer>();

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();

        Object params[] = new Object[]{lPersonID};
        int types[] = new int[]{Types.INTEGER};
        namedParameters.addValue("personID", lPersonID, Types.INTEGER);
        namedParameterJdbcTemplate.query(selectPersonSocialSecurityNo, namedParameters,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        results.add((rs.getObject(1) != null) ? new Integer(rs
                                .getInt(1)) : null);
                    }
                });

        Integer personSSN = null;
        if (results.size() > 0) {
            personSSN = (Integer) results.get(0);
        }

        for (int i = 0; i < params.length; i++) {
            params[i] = null;
        }

        return personSSN;
    }

    /**
     * @return Integer personSSN
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public String getMemberNoUsingMODS(String lExternalPersonID)
            throws Exception, DataAccessException {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectMemberNoUsingMODS);


        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("externalPersonID", lExternalPersonID.trim(), Types.VARCHAR);

        ArrayList<String> results = (ArrayList<String>) namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new MemberNoUsingMODSRowMapper());

        String modsMemberNo = null;
        if (results.size() > 0) {
            modsMemberNo = results.get(0);

        }


        return modsMemberNo;
    }


    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public List<PersonActivityAchievedReward> getAllParticipantRewards(Integer programID, java.sql.Date lastSuccessfulRunDate)
            throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectPersonActivityAchievedReward);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("lastSuccessRunDate", lastSuccessfulRunDate, Types.DATE);
        namedParameters.addValue("bizPgmId", programID, Types.INTEGER);

        List<PersonActivityAchievedReward> results = namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new PersonActivityAchievedRewardRowMapper());


        Collection<PersonActivityAchievedReward> contractRewardContributions = getContractRewards(programID, lastSuccessfulRunDate);
        if (contractRewardContributions.size() > 0) {
            results.addAll(contractRewardContributions);
        }

        List<PersonActivityAchievedReward> memberRewardContributions = getMemberRewards(programID, lastSuccessfulRunDate);
        if (memberRewardContributions.size() > 0) {
            results.addAll(memberRewardContributions);
        }

        //EV84334 - added for contrib grid enhancement.
        Collection<PersonActivityAchievedReward> contractRewardContributionsWithContribGrid = getContractRewardsWithContribGrid(programID, lastSuccessfulRunDate);
        //evaluate and replace dependent with policy holder to ensure PH is sent.
        // lookup policy holder here and compare to see if a change is necessary.  tjq

        contractRewardContributionsWithContribGrid = evaluateDependentToPolicyHolderForContractBasedRewardCards(contractRewardContributionsWithContribGrid);

        if (contractRewardContributionsWithContribGrid.size() > 0) {
            results.addAll(contractRewardContributionsWithContribGrid);
        }

        //EV84334 - added for contrib grid enhancement.
        List<PersonActivityAchievedReward> memberRewardContributionsWithContribGrid = getMemberRewardsWithContribGrid(programID, lastSuccessfulRunDate);
        if (memberRewardContributionsWithContribGrid.size() > 0) {
            results.addAll(memberRewardContributionsWithContribGrid);
        }

        return results;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<PersonActivityAchievedReward> getContractRewards(Integer programID, java.sql.Date lastSuccessfulRunDate)
            throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectContractActivityAchievedReward);


        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("bizPgmId", programID, Types.INTEGER);
        namedParameters.addValue("lastSuccessfulRunDate", lastSuccessfulRunDate, Types.DATE);

        List<PersonActivityAchievedReward> results = namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new PersonActivityAchievedRewardRowMapper());

        //EV 93850 - address extra reward card going out for contract based incentives.
        //Hashmap only allows for one activity per contract to be fulfilled.
        HashMap<String, PersonActivityAchievedReward> lPersonActivityAchievedRewardForContractHM = new HashMap<String, PersonActivityAchievedReward>();
        if (results != null && results.size() > 0) {
            for (PersonActivityAchievedReward result : results) {
                String key = concatenateDigits(result.getProgramIncentiveOptionID(), result.getPersonDemographicsID());
                if (!lPersonActivityAchievedRewardForContractHM.containsKey(key)) {
                    lPersonActivityAchievedRewardForContractHM.put(key, result);
                }
            }
        }
        return lPersonActivityAchievedRewardForContractHM.values();
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<PersonActivityAchievedReward> getContractRewardsWithContribGrid(Integer programID, java.sql.Date lastSuccessfulRunDate)
            throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectContractActivityAchievedRewardWithContribGrid);


        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("bizPgmId", programID, Types.INTEGER);
        namedParameters.addValue("lastSuccessRunDate", lastSuccessfulRunDate, Types.DATE);


        List<PersonActivityAchievedReward> results = namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new PersonActivityAchievedRewardWithContribGridRowMapper());

        //EV 93850 - address extra reward card going out for contract based incentives.
        //Hashmap only allows for one activity per contract to be fulfilled.
        HashMap<String, PersonActivityAchievedReward> lPersonActivityAchievedRewardForContractHM = new HashMap<String, PersonActivityAchievedReward>();
        if (results != null && results.size() > 0) {
            for (PersonActivityAchievedReward result : results) {
                String key = concatenateDigits(result.getProgramIncentiveOptionID(), result.getPersonDemographicsID());
                if (!lPersonActivityAchievedRewardForContractHM.containsKey(key)) {
                    lPersonActivityAchievedRewardForContractHM.put(key, result);
                }
            }
        }

        return lPersonActivityAchievedRewardForContractHM.values();
    }

    private static String concatenateDigits(Integer programIncentiveOptionID, Integer personDemographicsID) {
        StringBuilder sb = new StringBuilder();

        sb.append(programIncentiveOptionID);
        sb.append(personDemographicsID);

        return sb.toString();
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public List<PersonActivityAchievedReward> getMemberRewards(Integer programID, java.sql.Date lastSuccessfulRunDate)
            throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectMemberActivityAchievedReward);


        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("bizPgmId", programID, Types.INTEGER);
        namedParameters.addValue("lastSuccessfulRunDate", lastSuccessfulRunDate, Types.DATE);

        List<PersonActivityAchievedReward> results = namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new PersonActivityAchievedRewardRowMapper());


        return results;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public ArrayList<PersonActivityAchievedReward> getMemberRewardsWithContribGrid(Integer programID, java.sql.Date lastSuccessfulRunDate)
            throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectMemberActivityAchievedRewardWithContribGrid);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("lastSuccessfulRunDate", lastSuccessfulRunDate, Types.DATE);
        namedParameters.addValue("bizPgmID", programID, Types.INTEGER);

        ArrayList<PersonActivityAchievedReward> results = (ArrayList<PersonActivityAchievedReward>) namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new PersonActivityAchievedRewardWithContribGridRowMapper());


        return results;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public ArrayList<PersonActivityAchievedContribution> getAllCDHPHRAParticipantContributions()
            throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectHRAPersonActivityAchievedContribution);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();

        ArrayList<PersonActivityAchievedContribution> results = (ArrayList<PersonActivityAchievedContribution>) namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new PersonActivityAchievedHRARowMapper());


        ArrayList<PersonActivityAchievedContribution> hraEmployerSponsoredParticipantContributions = getCDHPHRAEmployerSponsoredParticipantContributions();
        if (hraEmployerSponsoredParticipantContributions.size() > 0) {
            results.addAll(hraEmployerSponsoredParticipantContributions);
        }

        //EV93147 - Determine if HRA Activities in cdhp error recycle were approved to be fulfilled.
        ArrayList<PersonActivityAchievedContribution> hraEmployerSponsoredParticipantContributionRecycleApprovals = getCDHPHRAEmployerSponsoredParticipantContributionRecycleApprovals();

        if (hraEmployerSponsoredParticipantContributionRecycleApprovals.size() > 0) {
            results.addAll(hraEmployerSponsoredParticipantContributionRecycleApprovals);
        }

        ArrayList<PersonActivityAchievedContribution> hraContractParticipantContributions = getCDHPHRAContractParticipantContributions();
        if (hraContractParticipantContributions.size() > 0) {
            results.addAll(hraContractParticipantContributions);
        }

        ArrayList<PersonActivityAchievedContribution> hraMemberParticipantContributions = getCDHPHRAMemberParticipantContributions();
        if (hraMemberParticipantContributions.size() > 0) {
            results.addAll(hraMemberParticipantContributions);
        }

        //EV84334 - added for contrib grid enhancement.
        ArrayList<PersonActivityAchievedContribution> hraContractParticipantContributionsWithContribGrid = getCDHPHRAContractParticipantContributionsWithContribGrid();
        if (hraContractParticipantContributionsWithContribGrid.size() > 0) {
            results.addAll(hraContractParticipantContributionsWithContribGrid);
        }
        //EV84334 - added for contrib grid enhancement.
        ArrayList<PersonActivityAchievedContribution> hraMemberParticipantContributionsWithContribGrid = getCDHPHRAMemberParticipantContributionsWithContribGrid();
        if (hraMemberParticipantContributionsWithContribGrid.size() > 0) {
            results.addAll(hraMemberParticipantContributionsWithContribGrid);
        }


        return results;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public ArrayList<PersonActivityAchievedContribution> getAllCDHPHSAParticipantContributions()
            throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectHSAPersonActivityAchievedContribution);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();

        ArrayList<PersonActivityAchievedContribution> results = (ArrayList<PersonActivityAchievedContribution>) namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new PersonActivityAchievedHSARowMapper());


        ArrayList<PersonActivityAchievedContribution> hsaContractParticipantContributions = getCDHPHSAContractParticipantContributions();
        if (hsaContractParticipantContributions.size() > 0) {
            results.addAll(hsaContractParticipantContributions);
        }
        ArrayList<PersonActivityAchievedContribution> hsaMemberParticipantContributions = getCDHPHSAMemberParticipantContributions();
        if (hsaMemberParticipantContributions.size() > 0) {
            results.addAll(hsaMemberParticipantContributions);
        }

        //EV84334 - added for contrib grid enhancement.
        ArrayList<PersonActivityAchievedContribution> hsaContractParticipantContributionsWithContribGrid = getCDHPHSAContractParticipantContributionsWithContribGrid();
        if (hsaContractParticipantContributionsWithContribGrid.size() > 0) {
            results.addAll(hsaContractParticipantContributionsWithContribGrid);
        }


        //EV84334 - added for contrib grid enhancement.
        ArrayList<PersonActivityAchievedContribution> hsaMemberParticipantContributionsWithContribGrid = getCDHPHSAMemberParticipantContributionsWithContribGrid();
        if (hsaMemberParticipantContributionsWithContribGrid.size() > 0) {
            results.addAll(hsaMemberParticipantContributionsWithContribGrid);
        }


        return results;
    }


    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public ArrayList<PersonActivityAchievedContribution> getCDHPHRAContractParticipantContributions()
            throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectHRAContractActivityAchievedContribution);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();

        ArrayList<PersonActivityAchievedContribution> results = (ArrayList<PersonActivityAchievedContribution>) namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new PersonActivityAchievedHRARowMapper());


        return results;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public ArrayList<PersonActivityAchievedContribution> getCDHPHRAContractParticipantContributionsWithContribGrid()
            throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectHRAContractActivityAchievedContributionWithContribGrid);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();

        ArrayList<PersonActivityAchievedContribution> results = (ArrayList<PersonActivityAchievedContribution>) namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new PersonActivityAchievedHRARowMapper());


        return results;
    }

    /*
     * Contributions are assigned through the contribution grid tiering model imbedded within
     * the sql. The table that drives it is the activity incentive table.
     * (non-Javadoc)
     * @see com.healthpartners.service.bpm.dao.PersonDAO#getCDHPHRAMemberParticipantContributions()
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public ArrayList<PersonActivityAchievedContribution> getCDHPHRAMemberParticipantContributions()
            throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectHRAMemberActivityAchievedContribution);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();


        ArrayList<PersonActivityAchievedContribution> results = (ArrayList<PersonActivityAchievedContribution>) namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new PersonActivityAchievedHRARowMapper());


        return results;
    }

    /*
     * Contributions are assigned at the business program incentive option level and the contribution grid.  The member
     * incented table drives this sql.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public ArrayList<PersonActivityAchievedContribution> getCDHPHRAMemberParticipantContributionsWithContribGrid()
            throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectHRAMemberActivityAchievedContributionWithContribGrid);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();


        ArrayList<PersonActivityAchievedContribution> results = (ArrayList<PersonActivityAchievedContribution>) namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new PersonActivityAchievedHRARowMapper());


        return results;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public ArrayList<PersonActivityAchievedContribution> getCDHPHRAEmployerSponsoredParticipantContributions()
            throws DataAccessException {
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectEmployerSponsoredPersonActivityAchievedContribution);
        MapSqlParameterSource namedParameters = new MapSqlParameterSource();

        ArrayList<PersonActivityAchievedContribution> results = (ArrayList<PersonActivityAchievedContribution>) namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new EmployerSponsorPersonActivityContributionRowMapper());


        return results;
    }

    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public ArrayList<PersonActivityAchievedContribution> getCDHPHRAEmployerSponsoredParticipantContributionRecycleApprovals()
            throws DataAccessException {
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectEmployerSponsoredPersonActivityAchievedContributionRecycleApprovals);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();


        ArrayList<PersonActivityAchievedContribution> results = (ArrayList<PersonActivityAchievedContribution>) namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new EmployerSponsorPersonActivityContributionRowMapper());


        return results;
    }

    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public ArrayList<PersonActivityAchievedContribution> getCDHPHSAContractParticipantContributions()
            throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectHSAContractActivityAchievedContribution);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();

        ArrayList<PersonActivityAchievedContribution> results = (ArrayList<PersonActivityAchievedContribution>) namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new PersonActivityAchievedHSARowMapper());


        return results;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public ArrayList<PersonActivityAchievedContribution> getCDHPHSAContractParticipantContributionsWithContribGrid()
            throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectHSAContractActivityAchievedContributionWithContribGrid);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();

        ArrayList<PersonActivityAchievedContribution> results = (ArrayList<PersonActivityAchievedContribution>) namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new PersonActivityAchievedHSARowMapper());


        return results;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public ArrayList<PersonActivityAchievedContribution> getCDHPHSAMemberParticipantContributions()
            throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectHSAMemberActivityAchievedContribution);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();

        ArrayList<PersonActivityAchievedContribution> results = (ArrayList<PersonActivityAchievedContribution>) namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new PersonActivityAchievedHSARowMapper());


        return results;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public ArrayList<PersonActivityAchievedContribution> getCDHPHSAMemberParticipantContributionsWithContribGrid()
            throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectHSAMemberActivityAchievedContributionWithContribGrid);
        MapSqlParameterSource namedParameters = new MapSqlParameterSource();

        ArrayList<PersonActivityAchievedContribution> results = (ArrayList<PersonActivityAchievedContribution>) namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new PersonActivityAchievedHSARowMapper());


        return results;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<CDHPFulfillmentTrackingReportHist> getCDHPFulfillmentTrackingReportHist(String productType, Integer programID, Integer personDemographicsID, Integer activityID)
            throws DataAccessException {


        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectCDHPFulfillmentTrackingReportHist);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();

        if (productType != null) {

            namedParameters.addValue("productType", productType, Types.VARCHAR);
            lQuery.append(" AND t.purch_sub_tp_nm = :productType ");
        }

        if (programID != null) {
            namedParameters.addValue("programID", programID, Types.INTEGER);
            lQuery.append(" AND t.biz_pgm_id = :programID ");
        }

        if (personDemographicsID != null) {
            namedParameters.addValue("personDemographicsID", personDemographicsID, Types.INTEGER);
            lQuery.append(" AND t.prsn_dmgrphcs_id = :personDemographicsID ");
        }

        if (activityID != null) {

            namedParameters.addValue("activityID", activityID, Types.INTEGER);
            lQuery.append(" AND t.actv_id = :activityID ");
        }


        ArrayList<CDHPFulfillmentTrackingReportHist> results = (ArrayList<CDHPFulfillmentTrackingReportHist>) namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new CDHPFulfillRptTrackingHistRowMapper());

        return results;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<ActivityFulfillmentTrackingReportHist> getActivityFulfillmentTrackingReportHist(String fulfillmentRoutingType, java.sql.Date transactionDate)
            throws DataAccessException {


        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectActivityFulfillmentTrackingReportHist);

        Object params[] = new Object[]{fulfillmentRoutingType, transactionDate};
        int types[] = new int[]{Types.VARCHAR, Types.DATE};

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("fulfillmentRoutingType", fulfillmentRoutingType, Types.VARCHAR);
        namedParameters.addValue("transactionDate", transactionDate, Types.DATE);

        ArrayList<ActivityFulfillmentTrackingReportHist> results = (ArrayList<ActivityFulfillmentTrackingReportHist>) namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new ActivityFulfillRptTrackingHistRowMapper());

        return results;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<CDHPFulfillmentTrackingReportHist> getCDHPFulfillmentTrackingReportHistByGroup(String groupNo, String productType, java.sql.Date transactionDate)
            throws DataAccessException {


        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectCDHPFulfillmentTrackingReportHistByGroup);


        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("productType", productType, Types.VARCHAR);
        namedParameters.addValue("transactionDate", transactionDate, Types.DATE);
        namedParameters.addValue("groupNo", groupNo, Types.VARCHAR);


        ArrayList<CDHPFulfillmentTrackingReportHist> lCDHPFulfillmentTrackingReportsHist = (ArrayList<CDHPFulfillmentTrackingReportHist>) namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new CDHPFulfillRptTrackingHistRowMapper());


        return lCDHPFulfillmentTrackingReportsHist;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<RewardFulfillmentTrackingReportHist> getRewardFulfillmentTrackingReportHistByProgram(Integer programID, Integer incentiveOptionID, String quoteID, java.sql.Date transactionDate)
            throws DataAccessException {


        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectRewardFulfillmentTrackingReportHistByProgram);


        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("bizPgmID", programID, Types.INTEGER);
        namedParameters.addValue("incentiveOptionID", incentiveOptionID, Types.INTEGER);
        namedParameters.addValue("quoteID", quoteID, Types.VARCHAR);
        namedParameters.addValue("transactionDate", transactionDate, Types.DATE);


        ArrayList<RewardFulfillmentTrackingReportHist> lCDHPFulfillmentTrackingReportsHist = (ArrayList<RewardFulfillmentTrackingReportHist>) namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new RewardFulfillRptTrackingHistRowMapper());


        return lCDHPFulfillmentTrackingReportsHist;
    }


    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public boolean isMultiActivityRewardFulfilled(
            PersonActivityAchievedReward lPersonActivityAchievedReward) throws DataAccessException {

        Integer programID = lPersonActivityAchievedReward.getProgramID();
        Integer programIncentiveOptionID = lPersonActivityAchievedReward.getIncentiveOptionID();
        Integer contractNo = lPersonActivityAchievedReward.getContractNo();
        Integer personDemographicsID = lPersonActivityAchievedReward.getPersonDemographicsID();

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("bizPgmId", programID, Types.INTEGER);
        namedParameters.addValue("programIncentiveOptionID", programIncentiveOptionID);
        namedParameters.addValue("contractNo", contractNo, Types.VARCHAR);
        namedParameters.addValue("personDemographicsID", personDemographicsID);



        List<Boolean> results = namedParameterJdbcTemplate.query(countMultiActivityRewardFulfilled, namedParameters,
                new RowMapper() {
                    @Override
                    public Boolean mapRow(ResultSet rs, int i) throws SQLException {
                        if (rs.getInt(1) > 0) {
                            return Boolean.valueOf(true);
                        }
                        return Boolean.valueOf(false);
                    }

                });


        return results.size() > 0;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public CDHPFulfillmentTrackingReportHist findPersonCDHPContributionAlreadySent(PersonActivityAchievedContribution lPersonActivityAchievedContribution)
            throws DataAccessException {

        final ArrayList<CDHPFulfillmentTrackingReportHist> results = new ArrayList<CDHPFulfillmentTrackingReportHist>();


        Integer pProgramId = lPersonActivityAchievedContribution.getProgramID();
        Integer pPersonDemographicsID = lPersonActivityAchievedContribution.getPersonDemographicsID();
        Integer pActivityID = lPersonActivityAchievedContribution.getActivityID();
        String pPackageSubType = lPersonActivityAchievedContribution.getPackageSubType();


        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("bizPgmId", pProgramId, Types.INTEGER);
        namedParameters.addValue("personDemographicsID", pPersonDemographicsID, Types.INTEGER);
        namedParameters.addValue("actvId", pActivityID, Types.INTEGER);
        namedParameters.addValue("purchSubTpNm", pPackageSubType, Types.VARCHAR);


        namedParameterJdbcTemplate.query(selectPersonCDHPContributionAlreadySent, namedParameters,
                new RowMapper() {
                    @Override
                    public CDHPFulfillmentTrackingReportHist mapRow(ResultSet rs, int i) throws SQLException {
                        CDHPFulfillmentTrackingReportHist lCDHPFulfillmentTrackingReportHist = new CDHPFulfillmentTrackingReportHist();
                        lCDHPFulfillmentTrackingReportHist.setProgramID(new Integer(rs
                                .getInt("BIZ_PGM_ID")));
                        lCDHPFulfillmentTrackingReportHist.setContractNo(new Integer(rs
                                .getInt("CONTRACT_NO")));
                        lCDHPFulfillmentTrackingReportHist.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
                        lCDHPFulfillmentTrackingReportHist.setContributionAmount(rs.getInt("CONTRIB_AMT"));
                        lCDHPFulfillmentTrackingReportHist.setContributionTypeCodeId(rs.getInt("TIER_CONTRIB_ID"));
                        lCDHPFulfillmentTrackingReportHist.setContributionDate(rs.getDate("CONTRIB_DT"));
                        lCDHPFulfillmentTrackingReportHist.setFileSentDate(rs.getDate("FILE_SENT_DT"));
                        lCDHPFulfillmentTrackingReportHist.setActivityID(rs.getInt("PKG_ID"));
                        lCDHPFulfillmentTrackingReportHist.setPackageSubTypeName(rs.getString("PURCH_SUB_TP_NM"));

				/*personHRAContribution.setPackageSubType(rs
						.getString("purch_sub_tp_nm"));
			    */

                        results.add(lCDHPFulfillmentTrackingReportHist);
                        return lCDHPFulfillmentTrackingReportHist;
                    }

                });


        CDHPFulfillmentTrackingReportHist lCDHPFulfillmentTrackingReportHist = null;
        if (results.size() > 0) {
            lCDHPFulfillmentTrackingReportHist = (CDHPFulfillmentTrackingReportHist) results.get(0);
        }

        return lCDHPFulfillmentTrackingReportHist;
    }


    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<CDHPFulfillmentTrackingReportHist> getPersonContributions(Integer programID, Integer contractNo, Integer personDemographicsID, Integer incentiveOptionID)
            throws DataAccessException {

        final ArrayList<CDHPFulfillmentTrackingReportHist> lCDHPFulfillmentTrackingReportsHist = new ArrayList<CDHPFulfillmentTrackingReportHist>();
        StringBuffer lQuery = new StringBuffer();

        lQuery.append(selectPersonContributions);


        MapSqlParameterSource namedParameters = new MapSqlParameterSource();

        namedParameters.addValue("bizPgmId", programID, Types.INTEGER );
        namedParameters.addValue("contractNo", contractNo, Types.VARCHAR);
        namedParameters.addValue("incentiveOptionID", incentiveOptionID, Types.INTEGER);


        if (personDemographicsID != null) {
            namedParameters.addValue("personDemographicsID", personDemographicsID, Types.INTEGER);
            lQuery.append(" AND t.prsn_dmgrphcs_id = :personDemographicsID ");
        }



        namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public CDHPFulfillmentTrackingReportHist mapRow(ResultSet rs, int i) throws SQLException {
                        CDHPFulfillmentTrackingReportHist lCDHPFulfillmentTrackingReportHist = new CDHPFulfillmentTrackingReportHist();
                        lCDHPFulfillmentTrackingReportHist.setProgramID(rs.getInt("biz_pgm_id"));
                        lCDHPFulfillmentTrackingReportHist.setContractNo(rs.getInt("contract_no"));
                        lCDHPFulfillmentTrackingReportHist.setPersonDemographicsID(rs.getInt("prsn_dmgrphcs_id"));
                        lCDHPFulfillmentTrackingReportHist.setContributionAmount(rs.getInt("contrib_amt"));

                        lCDHPFulfillmentTrackingReportsHist.add(lCDHPFulfillmentTrackingReportHist);
                        return lCDHPFulfillmentTrackingReportHist;
                    }

                });

        return lCDHPFulfillmentTrackingReportsHist;
    }


    /*
     * @see com.healthpartners.service.bpm.dao.PersonDAO#insertCDHPCompletions(group)
     * Return number of records written.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int insertCDHPCompletion(PersonActivityAchievedContribution hraParticipantCompletion)
            throws DataAccessException {


        Integer cdhpTransId = cdhpTransIdIncrementer
                .nextIntValue();

        Integer programID = hraParticipantCompletion.getProgramID();
        Integer contractNo = hraParticipantCompletion.getContractNo();
        Integer combinedContribAmount = hraParticipantCompletion.getCombinedContributionAmt();
        String packageSubTypeName = hraParticipantCompletion.getPackageSubType();
        java.sql.Date contributionDate = hraParticipantCompletion.getContributionDate();
        Integer contribTypeCodeID = hraParticipantCompletion.getContribTypeCodeID();
        Integer incentiveOptionID = hraParticipantCompletion.getIncentiveOptionID();

        Integer sameDayContrMemCount = hraParticipantCompletion.getParticipantCount();

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("cdhpTransId", cdhpTransId, Types.INTEGER);
        namedParameters.addValue("programID", programID, Types.INTEGER);
        namedParameters.addValue("contractNo", contractNo, Types.INTEGER);
        namedParameters.addValue("packageSubTypeName", packageSubTypeName, Types.VARCHAR);
        namedParameters.addValue("combinedContribAmount", combinedContribAmount, Types.INTEGER);
        namedParameters.addValue("contributionDate", contributionDate, Types.DATE);
        namedParameters.addValue("sameDayContrMemCount", sameDayContrMemCount, Types.INTEGER);
        namedParameters.addValue("contribTypeCodeID", contribTypeCodeID, Types.INTEGER);
        namedParameters.addValue("incentiveOptionID", incentiveOptionID, Types.INTEGER);

        int rowInserted = namedParameterJdbcTemplate.update(insertCDHPCompletion, namedParameters);


        return rowInserted;
    }

    /*
     * @see com.healthpartners.service.bpm.dao.PersonDAO#insertCDHPCompletions(group)
     * Return number of records written.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int insertCDHPCompletionHistory(PersonActivityAchievedContribution lPersonActivityAchievedContribution)
            throws DataAccessException {

        Integer cdhpTransId = cdhpTransIdIncrementer
                .nextIntValue();

        Integer programID = lPersonActivityAchievedContribution.getProgramID();
        Integer contractNo = lPersonActivityAchievedContribution.getContractNo();
        Integer demographicsID = lPersonActivityAchievedContribution.getPersonDemographicsID();
        Integer contribAmount = lPersonActivityAchievedContribution.getContributionAmt();
        Integer packageID = lPersonActivityAchievedContribution.getPackageID();
        String packageSubTypeName = lPersonActivityAchievedContribution.getPackageSubType();
        Integer contribTypeCodeID = lPersonActivityAchievedContribution.getContribTypeCodeID();
        java.sql.Date contributionDate = lPersonActivityAchievedContribution.getContributionDate();
        Integer incentiveOptionID = lPersonActivityAchievedContribution.getIncentiveOptionID();


        Integer incentiveStatusActivityDetailID = lPersonActivityAchievedContribution.getIncentiveStatusActivityDetailID();
        Integer activityID = lPersonActivityAchievedContribution.getActivityID();


        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("cdhpTransId", cdhpTransId, Types.INTEGER);
        namedParameters.addValue("programID", programID, Types.INTEGER);
        namedParameters.addValue("packageID", packageID, Types.INTEGER);
        namedParameters.addValue("contractNo", contractNo, Types.INTEGER);
        namedParameters.addValue("demographicsID", demographicsID, Types.INTEGER);
        namedParameters.addValue("packageSubTypeName", packageSubTypeName, Types.VARCHAR);
        namedParameters.addValue("contribAmount", contribAmount, Types.INTEGER);
        namedParameters.addValue("contributionDate", contributionDate, Types.DATE);
        namedParameters.addValue("activityID", activityID, Types.INTEGER);
        namedParameters.addValue("contribTypeCodeID", contribTypeCodeID, Types.INTEGER);
        namedParameters.addValue("incentiveOptionID", incentiveOptionID, Types.INTEGER);
        namedParameters.addValue("incentiveStatusActivityDetailID", incentiveStatusActivityDetailID, Types.INTEGER);


        int rowInserted = namedParameterJdbcTemplate.update(insertCDHPCompletionHistory, namedParameters);


        return rowInserted;
    }

    /*
     * @see com.healthpartners.service.bpm.dao.PersonDAO#insertRewardCompletions(group)
     * Return number of records written.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int insertRewardFulfillHistory(PersonActivityAchievedReward participantCompletion)
            throws DataAccessException {


        Integer rewardTransId = rewardTransIdIncrementer
                .nextIntValue();

        Integer programID = participantCompletion.getProgramID();
        Integer contractNo = participantCompletion.getContractNo();
        Integer demographicsID = participantCompletion.getPersonDemographicsID();
        Integer contribAmount = participantCompletion.getContributionAmt();
        Integer contribTypeCodeID = participantCompletion.getContribTypeCodeID();
        java.sql.Date contributionDate = participantCompletion.getContributionDate();
        Integer incentiveOptionID = participantCompletion.getIncentiveOptionID();

        Integer activityID = participantCompletion.getActivityID();
        String orderID = participantCompletion.getOrderID();
        String externalTransactionID = participantCompletion.getExternalTransactionID();
        String cardNumberMasked = participantCompletion.getRewardCardNoMask();
        String systemID = participantCompletion.getSystemID();
        Integer incentiveStatusActivityDetailID = participantCompletion.getIncentiveStatusActivityDetailID();

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("rewardTransId", rewardTransId, Types.INTEGER);
        namedParameters.addValue("programID", programID, Types.INTEGER);
        namedParameters.addValue("contractNo", contractNo, Types.INTEGER);
        namedParameters.addValue("demographicsID", demographicsID, Types.INTEGER);
        namedParameters.addValue("contribAmount", contribAmount, Types.INTEGER);
        namedParameters.addValue("contribTypeCodeID", contribTypeCodeID, Types.INTEGER);
        namedParameters.addValue("contributionDate", contributionDate, Types.DATE);
        namedParameters.addValue("activityID", activityID, Types.INTEGER);
        namedParameters.addValue("incentiveOptionID", incentiveOptionID, Types.INTEGER);
        namedParameters.addValue("systemID", systemID, Types.VARCHAR);
        namedParameters.addValue("orderID", orderID, Types.VARCHAR);
        namedParameters.addValue("externalTransactionID", externalTransactionID, Types.VARCHAR);
        namedParameters.addValue("cardNumberMasked", cardNumberMasked, Types.VARCHAR);
        namedParameters.addValue("incentiveStatusActivityDetailID", incentiveStatusActivityDetailID, Types.INTEGER);

        int rowInserted = namedParameterJdbcTemplate.update(insertRewardFulfillHistory, namedParameters);


        return rowInserted;
    }

    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<PersonProgramStage> getMembershipStatusFeed(String processName)
            throws DataAccessException {
        final ArrayList<PersonProgramStage> results = new ArrayList<PersonProgramStage>();


        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("processName", processName, Types.VARCHAR);

        namedParameterJdbcTemplate.query(selectMembershipStatusUpdateFeed, namedParameters,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        PersonProgramStage personProgramStage = new PersonProgramStage();
                        personProgramStage.setPersonNumber(new Integer(rs
                                .getInt("PRSN_ID")));
                        personProgramStage.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
                        personProgramStage.setContractNumber(new Integer(rs
                                .getInt("CONTRACT_NO")));
                        personProgramStage.setGroupNumber(new Integer(rs
                                .getInt("GRP_ID")));
                        personProgramStage.setSiteNumber(new Integer(rs
                                .getInt("SUBGRP_ID")));
                        personProgramStage.setQualificationStartDate((rs
                                .getDate("QUALFCTN_START_DT")));
                        personProgramStage.setQualificationEndDate((rs
                                .getDate("QUALFCTN_END_DT")));
                        personProgramStage.setProgramStartDate((rs
                                .getDate("PROGRAM_START_DT")));
                        personProgramStage.setProgramEndDate((rs
                                .getDate("PROGRAM_END_DT")));
                        personProgramStage.setStatusDate(rs
                                .getDate("STAT_DT"));
                        personProgramStage.setMemberStatus((rs
                                .getString("member_status")));
                        personProgramStage.setContractStatus((rs
                                .getString("contract_status")));
                        personProgramStage.setProgramType((rs
                                .getString("program_type")));
                        personProgramStage.setProgramID(new Integer(rs
                                .getInt("biz_pgm_id")));
                        personProgramStage.setProgramTypeCode(rs
                                .getInt("biz_pgm_tp_cd"));
                        personProgramStage.setProgramIncentiveOptionID(rs.getInt("biz_pgm_incntv_optn_ID"));
                        personProgramStage.setActivationStatusCode(rs.getString("actvn_sts_tp_cd"));

                        results.add(personProgramStage);
                    }
                });


        return results;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<MemberActivity> getPersonProgramActivityStatusAchieved(String activityOutcome) {
        ArrayList<MemberActivity> lMemberActivitiesAchieved = new ArrayList<MemberActivity>();

        StringBuffer lQuery = new StringBuffer();


        lQuery.append(selectPersonProgramActivityStatusAchieved);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("activityOutcome", activityOutcome, Types.VARCHAR);


        lMemberActivitiesAchieved = (ArrayList<MemberActivity>) namedParameterJdbcTemplate.query(lQuery
                .toString(), namedParameters, new activityAchievedMapper());


        return lMemberActivitiesAchieved;
    }


    /**
     * Returns the Member Contract and its status with regards to the Business
     * Program.
     *
     * @param pPersonID
     * @param pBusinessProgramID
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Contract getMemberContractStatus(int pPersonID,
                                            int pBusinessProgramID, int pRelationshipCode, int pContractNumber, boolean pCalledFromWebPortal)
            throws DataAccessException {
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectMemberContractStatus);

        if (pCalledFromWebPortal) {
            lQuery.append(" AND trunc(SYSDATE) BETWEEN biz.eff_dt AND biz.pgm_end_dt ");
            lQuery.append(" AND (prog_con.PARTICIPATION_END_DT IS NULL OR trunc(prog_con.PARTICIPATION_END_DT) > trunc(SYSDATE)) ");
            lQuery.append(" AND trunc(biz.eff_dt) < baseline.CONTRACT_END_DT ");
            lQuery.append(" AND trunc(biz.eff_dt) < baseline.SUBGRP_END_DT");
            lQuery.append(" AND trunc(biz.eff_dt) < baseline.BEN_PKG_END_DT");
            lQuery.append(" AND (SYSDATE < baseline.CONTRACT_END_DT OR trunc(biz.pgm_end_dt) <= baseline.CONTRACT_END_DT)");
            lQuery.append(" AND (SYSDATE < baseline.SUBGRP_END_DT   OR trunc(biz.pgm_end_dt) <= baseline.SUBGRP_END_DT)");
            lQuery.append(" AND (SYSDATE < baseline.BEN_PKG_END_DT  OR trunc(biz.pgm_end_dt) <= baseline.BEN_PKG_END_DT)");
            lQuery.append(" AND baseline.contract_eff_dt < trunc(biz.pgm_end_dt)");
            lQuery.append(" AND baseline.subgrp_eff_dt < trunc(biz.pgm_end_dt)");
            lQuery.append(" AND baseline.ben_pkg_eff_dt < trunc(biz.pgm_end_dt)");
        }


        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("prsnDemographicsID", pPersonID, Types.INTEGER);
        namedParameters.addValue("bizPgmId", pBusinessProgramID, Types.INTEGER);
        namedParameters.addValue("relationShipCode", pRelationshipCode, Types.INTEGER);
        namedParameters.addValue("contractNo", pContractNumber, Types.INTEGER);


        List<Contract> results  = namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new ContractRowMapper());

        Contract dto = null;
        if (results.size() > 0) {
            dto = (Contract) results.get(0);
        }

        /*
         * Get the first contract status calculation date for this person and program.
         */
        java.sql.Date lContractStatusDate = getFirstContractStatusDate(pPersonID, pBusinessProgramID);

        if (dto != null && lContractStatusDate != null) {
            Calendar lContractStatusDateCalendar = Calendar.getInstance();
            lContractStatusDateCalendar.setTime(lContractStatusDate);

            dto.getContractStatus().setStatusEffectiveDate(lContractStatusDateCalendar);
        }


        return dto;
    }

    /**
     * Retrieve the program id from the fulfillment transaction history record using fulfillTransHistID.
     *
     * @param fulfillTransHistID
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Integer getProgramByRewardFulfillTransHistID(Integer fulfillTransHistID) {

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("rewardTxnHistId", fulfillTransHistID, Types.INTEGER);

        List<Integer> lProgramIDs = namedParameterJdbcTemplate.query(selectProgramByRewardFulfillTransHistID, namedParameters,
                new RowMapper() {
                    @Override
                    public Integer mapRow(ResultSet rs, int i) throws SQLException {
                        return rs.getInt("BIZ_PGM_ID");
                    }

                    public void processRow(ResultSet rs) throws SQLException {

                    }
                });

        return lProgramIDs.get(0);
    }

    /**
     * Retrieve the first date the contract status was set for this person,
     * give the person demographics ID, and business program ID.
     *
     * @param pPersonID
     * @param pProgramID
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public java.sql.Date getFirstContractStatusDate(Integer pPersonID, Integer pProgramID) {
        final List<java.sql.Date> lContractStatusDates = new ArrayList<java.sql.Date>();

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("prsnDmgrphcsId", pPersonID, Types.INTEGER);
        namedParameters.addValue("bizPgmId", pProgramID, Types.INTEGER);


        namedParameterJdbcTemplate.query(selectFirstContractStatusDate, namedParameters,
                new RowMapper() {
                    @Override
                    public Object mapRow(ResultSet rs, int i) throws SQLException {
                       return lContractStatusDates.add(rs.getDate("contract_status_dt"));
                    }
                });

        return lContractStatusDates.get(0);
    }

    /**
     * Returns the member id if the member participates in any business program
     * for the given year, or ALL years.
     *
     * @param pMemberID
     * @param pTargetQualificationYear
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<Member> getParticipatingMember(String pMemberID,
                                                     String pTargetQualificationYear, Calendar pCurrentDate) throws DataAccessException {
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectParticipant);

        final ArrayList<Member> lMembers = new ArrayList<Member>();


        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("memberNo", pMemberID, Types.VARCHAR);
        namedParameters.addValue("currentDate", pCurrentDate, Types.DATE);

        namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        Member lMember = new Member();
                        lMember.setMemberID(rs.getString("HP_MEM_ID"));
                        lMembers.add(lMember);
                    }
                });

        return lMembers;
    }

    /*
     * (non-Javadoc)
     * @see com.healthpartners.service.bpm.dao.PersonDAO#getParticipatingMemberRetroactive(java.lang.String, java.lang.String, java.util.Calendar)
     * This method addresses an issue where member experiences a package change at the beginning or middle of a program year.  See EV109752.
     */
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<Member> getParticipatingMemberRetroactive(String pMemberID,
                                                                String pTargetQualificationYear, Calendar activityStatusDate) throws DataAccessException {
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectParticipantRetroactive);

        final ArrayList<Member> lMembers = new ArrayList<Member>();

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("memberNo", pMemberID, Types.VARCHAR);
        namedParameters.addValue("activityStatusDate", activityStatusDate, Types.DATE);


        namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        Member lMember = new Member();
                        lMember.setMemberID(rs.getString("HP_MEM_ID"));
                        lMembers.add(lMember);
                    }
                });

        return lMembers;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<RequiredParticipant> getParticipant(String pMemberID, String pTargetQualificationYear, Calendar pCurrentDate)
            throws DataAccessException {
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectParticipant);

        final ArrayList<RequiredParticipant> lRequiredParticipants = new ArrayList<RequiredParticipant>();


        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("memberNo", pMemberID, Types.VARCHAR);
        namedParameters.addValue("currentDate", pCurrentDate, Types.DATE);

        namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        RequiredParticipant lRequiredParticipant = new RequiredParticipant();
                        lRequiredParticipant.setMemberID(rs.getString("HP_MEM_ID"));
                        lRequiredParticipant.setProgramID(rs.getInt("BIZ_PGM_ID"));
                        lRequiredParticipant.setProgramTypeCode(rs.getString("BIZ_PGM_TP_CD"));
                        lRequiredParticipant.setCurrentBusinessProgramEffectiveDate(BPMUtils.dateToCalendar(rs.getDate("eff_dt")));
                        lRequiredParticipants.add(lRequiredParticipant);

                    }
                });


        return lRequiredParticipants;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<MemberUpdate> getParticipatingUpdatedMember(Integer personID)
            throws DataAccessException {
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectUpdatedParticipant);

        final ArrayList<MemberUpdate> lMembers = new ArrayList<MemberUpdate>();

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("personID", personID, Types.INTEGER);


        namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        MemberUpdate lMemberUpdate = new MemberUpdate();
                        lMemberUpdate.setPersonID(rs.getInt("PRSN_DMGRPHCS_ID"));
                        lMemberUpdate.setContractNumber(rs
                                .getInt("contract_no"));
                        lMemberUpdate.setBusinessProgramID(rs
                                .getInt("biz_pgm_id"));
                        lMemberUpdate.setMemberID(rs.getString("HP_MEM_ID"));
                        lMemberUpdate.setRelationshipID(rs.getInt("RLSHP_CD"));
                        lMemberUpdate
                                .setRelationship(rs.getString("rlshp_txt"));
                        lMemberUpdate.setDateOfBirth(rs.getDate("DOB_DT"));
                        lMemberUpdate.setProgramIncentiveOptionID(rs.getInt("biz_pgm_incntv_optn_ID"));

                        lMembers.add(lMemberUpdate);
                    }
                });


        return lMembers;
    }

    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int updateMemberProgramStatus(
            MemberProgramUpdateTO memberProgramUpdate)
            throws DataAccessException {

        if (!hasMemberProgramStatusRow(memberProgramUpdate.getPersonID(), memberProgramUpdate.getProgramID(), memberProgramUpdate.getRelationshipCodeID(),
                memberProgramUpdate.getProgramIncentiveOptionID())) {
            insertMemberProgramStatus(memberProgramUpdate);
            return 1;
        } else {

            MapSqlParameterSource namedParameters = new MapSqlParameterSource();
            namedParameters.addValue("bpmType", BPMConstants.BPM_TYPE_MEMBER_STATUS, Types.VARCHAR);
            namedParameters.addValue("statusCode", memberProgramUpdate.getStatusCodeValue(), Types.VARCHAR);
            namedParameters.addValue("healthPlanCode", memberProgramUpdate.getHealthPlanCode(), Types.VARCHAR);
            namedParameters.addValue("qualificationCheckmarkID", memberProgramUpdate.getQualificationCheckmarkID(), Types.INTEGER);
            namedParameters.addValue("issueDate", memberProgramUpdate.getIssueDate(), Types.DATE);
            namedParameters.addValue("modifyUserId", memberProgramUpdate.getModifyUserId(), Types.VARCHAR);
            namedParameters.addValue("coverageEffectiveDate", memberProgramUpdate.getCoverageEffectiveDate(), Types.DATE);
            namedParameters.addValue("personDemographicsID", memberProgramUpdate.getPersonID(), Types.INTEGER);
            namedParameters.addValue("programID", memberProgramUpdate.getProgramID(), Types.INTEGER);
            namedParameters.addValue("programIncentiveOptionID", memberProgramUpdate.getProgramIncentiveOptionID(), Types.INTEGER);
            namedParameters.addValue("relationshipCodeID", memberProgramUpdate.getRelationshipCodeID(), Types.INTEGER);

            return namedParameterJdbcTemplate.update(updateMemberProgramStatus, namedParameters);
        }
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int updateMemberProgramStatus(Integer pPersonID, Integer pProgramID,
                                         String pMemberStatus,
                                         String lPersonHealthPlanCode
            , Integer pRelationshipCodeID
            , Integer lQualificationCheckmarkID
            , String pUserID
            , Date coverageEffectiveDate
            , Integer pProgramIncentiveOptionID) throws DataAccessException {
        if (!hasMemberProgramStatusRow(pPersonID, pProgramID, pRelationshipCodeID, pProgramIncentiveOptionID)) {
            return insertMemberProgramStatus(pPersonID, pProgramID,
                    pMemberStatus, lPersonHealthPlanCode, pRelationshipCodeID, pUserID, coverageEffectiveDate, pProgramIncentiveOptionID);
        } else {
            // update

            MapSqlParameterSource namedParameters = new MapSqlParameterSource();
            namedParameters.addValue("bpmType", BPMConstants.BPM_TYPE_MEMBER_STATUS, Types.VARCHAR);
            namedParameters.addValue("statusCode", pMemberStatus, Types.VARCHAR);
            namedParameters.addValue("healthPlanCode", lPersonHealthPlanCode, Types.VARCHAR);
            namedParameters.addValue("qualificationCheckmarkID", lQualificationCheckmarkID, Types.INTEGER);
            namedParameters.addValue("issueDate", Calendar.getInstance(), Types.DATE);
            namedParameters.addValue("modifyUserId", pUserID, Types.VARCHAR);
            namedParameters.addValue("coverageEffectiveDate", coverageEffectiveDate, Types.DATE);
            namedParameters.addValue("personDemographicsID", pPersonID, Types.INTEGER);
            namedParameters.addValue("programID", pProgramID, Types.INTEGER);
            namedParameters.addValue("programIncentiveOptionID", pProgramIncentiveOptionID, Types.INTEGER);
            namedParameters.addValue("relationshipCodeID", pRelationshipCodeID, Types.INTEGER);
            return namedParameterJdbcTemplate.update(updateMemberProgramStatus, namedParameters);
        }
    }


    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int[] updateMemberProgramStatus(Collection<MemberProgramUpdateTO> memberProgramUpdates)
            throws DataAccessException {
        int[] numberOfRowsUpdated = new int[1];
        Iterator itrStats = memberProgramUpdates.iterator();
        while (itrStats.hasNext()) {
            MemberProgramUpdateTO memberProgramUpdate = (MemberProgramUpdateTO) itrStats.next();

            // If the prod_tp_cd or codes, contain an M, this is a member.
            // If there is no M in this person's prod_tp_cd, this is a non-member.
            List<PersonProgramHealthPlan> lPersonProgramHealthPlans =
                    getPersonHealthPlanCodeByRelationship(memberProgramUpdate.getPersonID()
                            , memberProgramUpdate.getProgramID()
                            , memberProgramUpdate.getRelationshipCodeID());

            memberProgramUpdate.setHealthPlanCode(null);
            for (PersonProgramHealthPlan lPersonProgramHealthPlan : lPersonProgramHealthPlans) {
                if (BPMConstants.BPM_MEMBER_WITH_MEDICAL_PLAN.equals(lPersonProgramHealthPlan.getHealthPlanCode())) {
                    memberProgramUpdate.setHealthPlanCode(BPMConstants.BPM_MEMBER_WITH_MEDICAL_PLAN);
                    break;
                }
            }

            if (memberProgramUpdate.getHealthPlanCode() == null) {
                memberProgramUpdate.setHealthPlanCode(BPMConstants.BPM_NON_MEMBER_WITHOUT_PLAN);
            }

            // updateMemberProgramStatus checks for existing row. If there is none, it will call insert.
            numberOfRowsUpdated[0] += updateMemberProgramStatus(memberProgramUpdate);
        }

        return numberOfRowsUpdated;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int updateMemberProgramStatusContractStatusDate(Integer pPersonID, Integer pProgramID) throws DataAccessException {

        // update
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{
                pPersonID, pProgramID};
        int types[] = new int[]{Types.INTEGER, Types.INTEGER};
        return template.update(updateMemberProgramStatusContractStatusDate, params, types);

    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int updateMemberProgramStatusPartEndDate(Integer pPersonID, Integer pProgramID, java.sql.Date pParticipationEndDate) throws DataAccessException {

        // update
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{
                pParticipationEndDate, pPersonID, pProgramID};
        int types[] = new int[]{Types.DATE, Types.INTEGER, Types.INTEGER};
        return template.update(updateMemberProgramStatusPartEndDate, params, types);

    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int updateMemberProgramStatusExternalPersonID(Integer pPersonDemographicsID, Integer pProgramID, String pExternalPersonID) throws DataAccessException {

        // update
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{
                pExternalPersonID, pPersonDemographicsID, pProgramID};
        int types[] = new int[]{Types.VARCHAR, Types.INTEGER, Types.INTEGER};
        return template.update(updateMemberProgramStatusExternalPersonID, params, types);

    }

    /*
     * @see com.healthpartners.service.bpm.dao.ContractDAO#insertMemberProgramStatus(com.healthpartners.service.bpm.dto.MemberProgramUpdateTO)
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int insertMemberProgramStatus(
            MemberProgramUpdateTO memberProgramUpdate)
            throws DataAccessException, DuplicateKeyException {


        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("programID", memberProgramUpdate.getProgramID(), Types.INTEGER);
        namedParameters.addValue("personDemographicsID", memberProgramUpdate.getPersonID(), Types.INTEGER);
        namedParameters.addValue("bpmType", BPMConstants.BPM_TYPE_MEMBER_STATUS, Types.VARCHAR);
        namedParameters.addValue("statusCodeValue", memberProgramUpdate.getStatusCodeValue(), Types.VARCHAR);
        namedParameters.addValue("healthPlanCode", memberProgramUpdate.getHealthPlanCode(), Types.VARCHAR);
        namedParameters.addValue("relationshipCodeID", memberProgramUpdate.getRelationshipCodeID(), Types.INTEGER);
        namedParameters.addValue("issueDate", memberProgramUpdate.getIssueDate(), Types.TIMESTAMP);
        namedParameters.addValue("userID", memberProgramUpdate.getInsertUserId(), Types.VARCHAR);
        namedParameters.addValue("coverageEffectiveDate", memberProgramUpdate.getCoverageEffectiveDate(), Types.TIMESTAMP);
        namedParameters.addValue("programIncentiveOptionID", memberProgramUpdate.getProgramIncentiveOptionID(), Types.INTEGER);


        int rowsInserted = namedParameterJdbcTemplate.update(insertMemberProgramStatus, namedParameters);

        return rowsInserted;
    }


    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int insertMemberProgramStatus(Integer pPersonID, Integer pProgramID,
                                         String pMemberStatus
            , String pPersonHealthPlanCode
            , Integer pRelationshipCodeID
            , String pUserID
            , Date coverageEffectiveDate
            , Integer pProgramIncentiveOptionID) throws DataAccessException {

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("programID", pProgramID, Types.INTEGER);
        namedParameters.addValue("personDemographicsID", pPersonID, Types.INTEGER);
        namedParameters.addValue("bpmType", BPMConstants.BPM_TYPE_MEMBER_STATUS, Types.VARCHAR);
        namedParameters.addValue("statusCodeValue", pMemberStatus, Types.VARCHAR);
        namedParameters.addValue("healthPlanCode", pPersonHealthPlanCode, Types.VARCHAR);
        namedParameters.addValue("relationshipCodeID", pRelationshipCodeID, Types.INTEGER);
        namedParameters.addValue("issueDate", Calendar.getInstance(), Types.TIMESTAMP);
        namedParameters.addValue("userID", pUserID, Types.VARCHAR);
        namedParameters.addValue("personID", pPersonID, Types.INTEGER);
        namedParameters.addValue("coverageEffectiveDate", coverageEffectiveDate, Types.DATE);
        namedParameters.addValue("programIncentiveOptionID", pProgramIncentiveOptionID, Types.INTEGER);

        int rowsInserted = namedParameterJdbcTemplate.update(insertMemberProgramStatus, namedParameters);


        return rowsInserted;
    }

    /*
     * @see com.healthpartners.service.bpm.dao.ContractDAO#getMemberProgramStatus(java.lang.Integer,java.lang.Integer)
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public MemberProgramUpdateTO getMemberProgramStatus(Integer personID,
                                                        Integer businessProgramID) throws DataAccessException {
        final ArrayList<MemberProgramUpdateTO> results = new ArrayList<MemberProgramUpdateTO>();

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("personDemographicsID", personID, Types.INTEGER);
        namedParameters.addValue("businessProgramID", businessProgramID, Types.INTEGER);


        namedParameterJdbcTemplate.query(getMemberProgramStatus, namedParameters,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        MemberProgramUpdateTO memberProgramUpdate = new MemberProgramUpdateTO();
                        memberProgramUpdate
                                .setProgramID(rs.getObject(1) != null ? Integer
                                        .valueOf(rs.getInt(1)) : null);
                        memberProgramUpdate
                                .setPersonID(rs.getObject(2) != null ? Integer
                                        .valueOf(rs.getInt(2)) : null);
                        memberProgramUpdate.setStatusCodeValue(rs.getString(3));
                        memberProgramUpdate
                                .setIssueDate(rs.getObject(4) != null ? BPMUtils
                                        .dateToCalendar(rs.getDate(4))
                                        : null);
                        memberProgramUpdate.setInsertUserId(rs.getString(5));
                        memberProgramUpdate.setModifyUserId(rs.getString(6));

                        results.add(memberProgramUpdate);
                    }
                });

        MemberProgramUpdateTO dto = null;
        if (results.size() > 0) {
            dto = (MemberProgramUpdateTO) results.get(0);
        }


        return dto;
    }

    /*
     * @see com.healthpartners.service.bpm.dao.ContractDAO#getMemberProgramStatusDetail(java.lang.Integer,java.lang.Integer)
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public MemberProgramUpdateTO getMemberProgramStatusDetail(Integer personID,
                                                              Integer businessProgramID) throws DataAccessException {
        final ArrayList<MemberProgramUpdateTO> results = new ArrayList<MemberProgramUpdateTO>();

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("personDemographicsID", personID, Types.INTEGER);
        namedParameters.addValue("programID", businessProgramID, Types.INTEGER);

        namedParameterJdbcTemplate.query(selectMemberProgramStatusDetail, namedParameters,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        MemberProgramUpdateTO memberProgramUpdate = new MemberProgramUpdateTO();
                        memberProgramUpdate
                                .setProgramID(rs.getObject(1) != null ? Integer
                                        .valueOf(rs.getInt(1)) : null);
                        memberProgramUpdate
                                .setPersonID(rs.getObject(2) != null ? Integer
                                        .valueOf(rs.getInt(2)) : null);
                        memberProgramUpdate.setStatusCodeValue(rs.getString(3));
                        memberProgramUpdate
                                .setIssueDate(rs.getObject(4) != null ? BPMUtils
                                        .dateToCalendar(rs.getDate(4))
                                        : null);
                        memberProgramUpdate
                                .setParticipationEndDate(rs.getObject(5) != null ? BPMUtils
                                        .dateToCalendar(rs.getDate(5))
                                        : null);
                        memberProgramUpdate.setInsertUserId(rs.getString(6));
                        memberProgramUpdate.setModifyUserId(rs.getString(7));
                        memberProgramUpdate.setExternalPersonID(rs.getString(8));
                        memberProgramUpdate
                                .setCoverageEffectiveDate(rs.getObject(9) != null ? BPMUtils
                                        .dateToCalendar(rs.getDate(9))
                                        : null);

                        results.add(memberProgramUpdate);
                    }
                });

        MemberProgramUpdateTO dto = null;
        if (results.size() > 0) {
            dto = (MemberProgramUpdateTO) results.get(0);
        }


        return dto;
    }


    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Integer getRewardFulfillHistIDByExternalTransID(String externalTransactionID) throws DataAccessException {
        final ArrayList<Integer> results = new ArrayList<Integer>();

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("externalTransactionID", externalTransactionID, Types.VARCHAR);

        namedParameterJdbcTemplate.query(selectRewardFulfillHistIDByExternalTransID, namedParameters,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        results.add((rs.getObject(1) != null) ? new Integer(rs
                                .getInt(1)) : null);
                    }
                });

        Integer rewardTransHistID = null;
        if (results.size() > 0) {
            rewardTransHistID = (Integer) results.get(0);
        }


        return rewardTransHistID;
    }


    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int updateRewardFulfillRptTrackHist(
            RewardIntelispendShipped lRewardIntelispendShipped)
            throws DataAccessException {

        String externalTransID = lRewardIntelispendShipped.getRewardFulfillHistIDIndicativeData4();
        Integer rewardTransHistID = Integer.valueOf(lRewardIntelispendShipped.getPidNumber());
        String cardNumber = lRewardIntelispendShipped.getCardNumberMasked();

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("externalTransID", externalTransID, Types.VARCHAR);
        namedParameters.addValue("cardNumber", cardNumber, Types.INTEGER);
        namedParameters.addValue("userSystem", BPMConstants.INTELISPEND_USER_SYSTEM, Types.VARCHAR);
        namedParameters.addValue("rewardTransHistID", rewardTransHistID, Types.INTEGER);

        return namedParameterJdbcTemplate.update(updateRewardFulfillRptTrackHist, namedParameters);

    }

    /**
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int updateRewardFulfillmentHistWOrderNumber(Integer rewardTransHistID, String orderNumber)
            throws DataAccessException {

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("orderNumber", orderNumber, Types.VARCHAR);
        namedParameters.addValue("rewardTransHistID", rewardTransHistID, Types.INTEGER);

        return namedParameterJdbcTemplate.update(updateRewardFulfillmentHistWOrderNumber, namedParameters);

    }


    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int updateRewardFulfillmentHistWTodaysDate(
            Integer rewardTransHistID)
            throws DataAccessException {

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("systemUser", BPMConstants.BPM_USER_SYSTEM, Types.VARCHAR);
        namedParameters.addValue("rewardTransHistID", rewardTransHistID, Types.INTEGER);

        return namedParameterJdbcTemplate.update(updateRewardFulfillmentHistWTodaysDate, namedParameters);

    }


    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int insertRewardFulfillmentStatus(
            Integer rewardTransHistID, Integer reasonCodeID, Date statusDate, String systemID)
            throws DataAccessException {

        Integer rewardTransHistStatusID = rewardStatusTransIdIncrementer
                .nextIntValue();

        if (statusDate == null) {
            statusDate = BPMUtils.calendarToSqlDate(Calendar.getInstance());
        }

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("rewardTransHistStatusID", rewardTransHistStatusID, Types.INTEGER);
        namedParameters.addValue("rewardTransHistID", rewardTransHistID, Types.INTEGER);
        namedParameters.addValue("reasonCodeID", reasonCodeID, Types.INTEGER);
        namedParameters.addValue("statusDate", statusDate, Types.DATE);
        namedParameters.addValue("systemID", systemID, Types.VARCHAR);


        int rowsInserted = namedParameterJdbcTemplate.update(insertRewardFulfillmentStatus, namedParameters);


        return rowsInserted;
    }


//    //Produces warnings during compile time to quickly identify typos or API changes
//    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
//    public boolean hasMemberProgramStatusRow(Integer pPersonID,
//                                             Integer pProgramID, Integer pRelationshipCodeID
//            , Integer pProgramIncentiveOptionID) throws DataAccessException {
//
//        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
//        namedParameters.addValue("prsnDemographicsID", pPersonID);
//        namedParameters.addValue("bizPgmId", pProgramID, Types.INTEGER);
//        namedParameters.addValue("relationshipCodeID", pRelationshipCodeID, Types.INTEGER);
//        namedParameters.addValue("programIncentiveOptionID", pProgramIncentiveOptionID, Types.INTEGER);
//
//        Boolean results = namedParameterJdbcTemplate.query(countMemberProgramStatusRows, namedParameters,
//                new RowMapper() {
//                    @Override
//                    public void mapRow(ResultSet rs, int i) throws SQLException {
//                        rs.add(Boolean.valueOf(false));
//                        if (rs.getInt(1) > 0) {
//                            rs.add(Boolean.valueOf(true));
//                        }
//
//                        return boolean;
//                    }
//                });
//
//
//
//
//        return (results.size() > 0 && results.get(0).booleanValue() == true);
//    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class })
    public boolean hasMemberProgramStatusRow(Integer pPersonID,
                                             Integer pProgramID, Integer pRelationshipCodeID
            , Integer pProgramIncentiveOptionID) throws DataAccessException {
        final ArrayList<Boolean> results = new ArrayList<Boolean>();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[] { pPersonID, pProgramID, pRelationshipCodeID, pProgramIncentiveOptionID };
        int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER };
        template.query(countMemberProgramStatusRows, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {

                        if (rs.getInt(1) > 0) {
                            results.add(Boolean.valueOf(true));
                        }
                    }
                });

        for(int i = 0; i < params.length; i++)
        {
            params[i] = null;
        }
        types = null;

        return (results.size() > 0 && results.get(0).booleanValue() == true);
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public boolean matchIncomingManualOrderToRewardFulfillHist(String external_txn_id)
            throws DataAccessException {
        final ArrayList<Boolean> results = new ArrayList<Boolean>();


        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("external_txn_id", external_txn_id, Types.VARCHAR);

        namedParameterJdbcTemplate.query(matchIncomingManualOrderToRewardFulfillHist, namedParameters,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {

                        if (rs.getInt(1) > 0) {
                            results.add(Boolean.valueOf(true));
                        }
                    }
                });

        return results.size() > 0;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public boolean matchIncomingOrderNoToFulfillOrderNo(Integer fulfillHistID, String orderNumber)
            throws DataAccessException {
        final ArrayList<Boolean> results = new ArrayList<Boolean>();

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("fulfillHistID", fulfillHistID, Types.INTEGER);
        namedParameters.addValue("orderNumber", orderNumber, Types.VARCHAR);

        namedParameterJdbcTemplate.query(matchIncomingOrderNoToFulfillOrderNo, namedParameters,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {

                        if (rs.getInt(1) > 0) {
                            results.add(Boolean.valueOf(true));
                        }
                    }
                });


        return results.size() > 0;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public String findLatestRewardFulfillStatus(Integer rewardTransHistID, Integer rewardStatusID) throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(findLatestRewardFulfillStatus);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("rewardTxnHistId", rewardTransHistID, Types.INTEGER);

        if (rewardStatusID != null) {
            namedParameters.addValue("rewardStatusId", rewardStatusID, Types.INTEGER);
            lQuery.append("and t.reward_card_sts_id = :rewardStatusId");
        }

        lQuery.append("GROUP BY t.reward_txn_hist_id, t.reward_card_sts_id");


        List<String> results = namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public String mapRow(ResultSet rs, int i) throws SQLException {

                        if (rs.getInt(1) > 0) {
                            return rs.getString("reward_fulfill_status");
                        }
                        return null;
                    }


                });


        String status = "NOT AVAILABLE";
        if (results.size() > 0) {
            status = results.iterator().next();
        }

        return status;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<String> getOffHoldForContactMemberList()
            throws DataAccessException {
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectOffHoldForContact);

        final ArrayList<String> lMemberIDs = new ArrayList<String>();

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();


        namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        lMemberIDs.add(rs.getString("HP_MEM_ID"));
                    }
                });

        return lMemberIDs;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int deleteMemberProgramStatus(Integer personID, Integer programID)
            throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("personDemographicsID", personID, Types.INTEGER);
        namedParameters.addValue("programID", programID, Types.INTEGER);

        return namedParameterJdbcTemplate.update(deleteMemberProgramStatus, namedParameters);
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public String getMemberID(Integer personID) throws DataAccessException {
        final ArrayList<String> results = new ArrayList<String>();

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("personDemographicsID", personID, Types.INTEGER);

        namedParameterJdbcTemplate.query(getMemberIDFromPersonID, namedParameters,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        results.add(rs.getString(1));
                    }
                });

        String memberID = null;
        if (results.size() > 0) {
            memberID = (String) results.get(0);
        }


        return memberID;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Integer getPersonID(String memberID) throws DataAccessException {
        final ArrayList<Integer> results = new ArrayList<Integer>();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{memberID};
        int types[] = new int[]{Types.VARCHAR};
        template.query(getPersonIDFromMemberID, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        results.add((rs.getObject(1) != null) ? new Integer(rs
                                .getInt(1)) : null);
                    }
                });

        Integer personID = null;
        if (results.size() > 0) {
            personID = (Integer) results.get(0);
        }

        for (int i = 0; i < params.length; i++) {
            params[i] = null;
        }
        types = null;

        return personID;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Integer getPersonDemographicsIDFromPersonID(String personID) throws DataAccessException {
        final ArrayList<Integer> results = new ArrayList<Integer>();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{personID};
        int types[] = new int[]{Types.VARCHAR};
        template.query(getPersonDemographicsIDFromPersonID, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        results.add((rs.getObject(1) != null) ? new Integer(rs
                                .getInt(1)) : null);
                    }
                });

        Integer personDemographicsID = null;
        if (results.size() > 0) {
            personDemographicsID = (Integer) results.get(0);
        }

        for (int i = 0; i < params.length; i++) {
            params[i] = null;
        }
        types = null;

        return personDemographicsID;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Integer getPersonIDFromPersonDemographicsID(Integer personDemographicsID) throws DataAccessException {
        final ArrayList<Integer> results = new ArrayList<Integer>();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{personDemographicsID};
        int types[] = new int[]{Types.INTEGER};
        template.query(getPersonIDFromPersonDemographicsID, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        results.add((rs.getObject(1) != null) ? new Integer(rs
                                .getInt(1)) : null);
                    }
                });

        Integer personID = null;
        if (results.size() > 0) {
            personID = (Integer) results.get(0);
        }

        for (int i = 0; i < params.length; i++) {
            params[i] = null;
        }
        types = null;

        return personID;
    }


    /**
     * Gets personIds still eligible after qualification period
     *
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<Integer> getPersonsEligibleBeyondQualificationPeriod()
            throws DataAccessException {
        final ArrayList<Integer> results = new ArrayList<Integer>();
        JdbcTemplate template = getJdbcTemplate();
        template.query(selectPersonsEligibleBeyondQualificationPeriod, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                Integer personId = new Integer(rs.getInt(1));
                results.add(personId);
            }
        });
        return results;
    }


    /**
     * Sets the participation_end_dt on the person_program_status to indicate that member is not
     * participating in BPM anymore.
     *
     * @param pPersonID
     * @param pProgramID
     * @param pUserID
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int endMemberParticipation(Integer pPersonID, Integer pProgramID, String pUserID)
            throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        int lNumberOfRowsUpdated = 0;
        final ArrayList<RelationshipEndDate> results = new ArrayList<RelationshipEndDate>();

        // Find which one of contract, subgroup, or Package End Dates ended the Participation.
        Object params1[] = new Object[]{pPersonID, pPersonID, pProgramID};
        int types1[] = new int[]{Types.INTEGER, Types.INTEGER, Types.INTEGER};

        template.query(selectWhichEndDate, params1, types1,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {

                        RelationshipEndDate lRelationshipEndDate = new RelationshipEndDate();

                        lRelationshipEndDate.setEndDate(rs.getDate("the_end_date"));
                        lRelationshipEndDate.setRelationshipCodeID(rs.getInt("rel_cd"));
                        results.add(lRelationshipEndDate);
                    }
                });

        for (RelationshipEndDate lRelationshipEndDate : results) {
            // Update the participation end date to the value found.
            Object params[] = new Object[]{lRelationshipEndDate.getEndDate(),
                    lRelationshipEndDate.getEndDate(),
                    pUserID,
                    pPersonID, pProgramID, lRelationshipEndDate.getRelationshipCodeID()};
            int types[] = new int[]{Types.DATE, Types.DATE,
                    Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER};
            lNumberOfRowsUpdated += template.update(endMemberParticipation, params, types);
        }

        return lNumberOfRowsUpdated;
    }

    /**
     * @param pPersonID
     * @param pProgramID
     * @param pEndDate
     * @param pRelationshipCodeID
     * @param pUserID
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int updateParticipationEndDate(Integer pPersonID, Integer pProgramID, java.sql.Date pEndDate, Integer pRelationshipCodeID, String pUserID) {
        JdbcTemplate template = getJdbcTemplate();

        Object params[] = new Object[]{pEndDate,
                pEndDate,
                pUserID,
                pPersonID, pProgramID, pRelationshipCodeID};
        int types[] = new int[]{Types.DATE, Types.DATE,
                Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER};

        return template.update(endMemberParticipation, params, types);
    }


    /**
     * If the contract has ended, update the contract_program_status table with the
     * contract participation end date.
     *
     * @param pPersonID
     * @param pProgramID
     * @param pContractNo
     * @param pUserID
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int setContractParticipationEndDate(Integer pPersonID, Integer pProgramID, Integer pContractNo, String pUserID)
            throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        java.sql.Date lContractEndDate = null;
        final ArrayList<java.sql.Date> contractEndDates = new ArrayList<java.sql.Date>();

        // Find out if the contract has ended, and if so, contract end date.
        Object params2[] = new Object[]{pPersonID, pContractNo, pPersonID, pProgramID};
        int types2[] = new int[]{Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER};

        template.query(selectIfContractEndDate, params2, types2,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        contractEndDates.add(rs.getDate("the_end_date"));
                    }
                });

        if (contractEndDates.size() > 0) {
            lContractEndDate = contractEndDates.get(0);

            if (lContractEndDate != null) {
                // Update the contract participation end date to the value found.
                Object params[] = new Object[]{lContractEndDate,
                        pUserID,
                        pContractNo, pProgramID};
                int types[] = new int[]{Types.DATE, Types.VARCHAR, Types.INTEGER, Types.INTEGER};
                template.update(endContractParticipation, params, types);

                // When contract ends, also set the person program status participation end date.
                //return endMemberParticipation(pPersonID,
                //		pProgramID, BPMConstants.BPM_USER_SYSTEM);
            }
        }

        return 0;
    }

    /**
     * Find out if the contract has ended.
     *
     * @param pPersonDemographicsID
     * @param pProgramID
     * @param pContractNo
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public List<java.sql.Date> selectContractEndDates(Integer pPersonDemographicsID, Integer pProgramID, Integer pContractNo)
            throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();

        // Find out if the contract has ended.
        Object params2[] = new Object[]{pPersonDemographicsID, pContractNo, pPersonDemographicsID, pProgramID};
        int types2[] = new int[]{Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER};

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("personDemographicsID", pPersonDemographicsID, Types.INTEGER);
        namedParameters.addValue("contractNo", pContractNo, Types.INTEGER);
        namedParameters.addValue("bizPgmId", pProgramID, Types.INTEGER);


        List<java.sql.Date> contractEndDates = namedParameterJdbcTemplate.query(selectIfContractEndDate, namedParameters,
                new RowMapper() {
                    @Override
                    public Date mapRow(ResultSet rs, int i) throws SQLException {
                        return rs.getDate("the_end_date");

                    }
                });

        return contractEndDates;

    }

    /**
     * Find out if the subgroup (site) has ended.
     *
     * @param pPersonDemographicsID
     * @param pProgramID
     * @param pContractNo
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public List<java.sql.Date> selectSubgroupEndDates(Integer pPersonDemographicsID, Integer pProgramID, Integer pContractNo)
            throws DataAccessException {

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("personDemographicsID", pPersonDemographicsID, Types.INTEGER);
        namedParameters.addValue("contractNo", pContractNo, Types.INTEGER);
        namedParameters.addValue("bizPgmId", pProgramID, Types.INTEGER);


        List<java.sql.Date> contractEndDates =  namedParameterJdbcTemplate.query(selectIfSubgroupEndDate, namedParameters,
                new RowMapper() {
                    @Override
                    public Date mapRow(ResultSet rs, int i) throws SQLException {
                        return rs.getDate("the_end_date");
                    }

                });

        return contractEndDates;

    }

    /**
     * Find out if the package has ended.
     *
     * @param pPersonDemographicsID
     * @param pProgramID
     * @param pContractNo
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public ArrayList<java.sql.Date> selectPackageEndDates(Integer pPersonDemographicsID, Integer pProgramID, Integer pContractNo)
            throws DataAccessException
    {
        JdbcTemplate template = getJdbcTemplate();
        final ArrayList<java.sql.Date> contractEndDates = new ArrayList<java.sql.Date>();

        // Find out if the contract has ended.
        Object params2[] = new Object[] { pPersonDemographicsID, pContractNo, pPersonDemographicsID, pProgramID };
        int types2[] = new int[] { Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER };

        template.query(selectIfPackageEndDate, params2, types2,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        contractEndDates.add(rs.getDate("the_end_date"));
                    }
                });

        return contractEndDates;

    }

    /**
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int insertPersonProgramStatus18YearOldsForIncentiveOptionByProgramType(String programType, String incentiveOptionName)
            throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{programType, incentiveOptionName, programType};
        int types[] = new int[]{Types.VARCHAR, Types.VARCHAR, Types.VARCHAR};
        int lNumberOfMembers = template.update(insertPersonProgramStatus18YearOldsForIncentiveOptionByProgramType, params, types);
        logger.info("Number of New 18 Year Olds by program type " + programType + " = " + lNumberOfMembers);
        int lNumberOfMembersContract = template.update(insertPersonProgramStatus18YearOldsForIncentiveOptionByProgramTypeContract, params, types);
        logger.info("Number of New 18 Year Olds by program type " + programType + " = " + lNumberOfMembers + " Set contract status to NOT_APPLICABLE.");

        return lNumberOfMembers;
    }

    //Create implementation methods for person program history stage beginning here - Start

    /**
     * Select a PersonContractHist record given the counterNumID.
     *
     * @return PersonContractHist object.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public PersonContractHist getPersonContractHist(Integer programID, Integer personDemographicsID, Integer programIncentiveOptionID)
            throws DataAccessException {
        StringBuffer query = new StringBuffer();
        query.append(selectPersonContractsHist);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("personDemographicsID", personDemographicsID, Types.INTEGER);
        namedParameters.addValue("programIncentiveOptionID", programIncentiveOptionID, Types.INTEGER);
        namedParameters.addValue("bizPgmId", programID, Types.INTEGER);

        List<PersonContractHist> lPersonContractsHist =  namedParameterJdbcTemplate.query(query.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public PersonContractHist mapRow(ResultSet rs, int i) throws SQLException {
                        PersonContractHist lPersonContractHist = new PersonContractHist();
                        lPersonContractHist.setProgramID(rs.getInt("biz_pgm_id"));
                        lPersonContractHist.setBusinessProgramIncentiveOptionID(rs.getInt("biz_pgm_incntv_optn_id"));
                        lPersonContractHist.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
                        lPersonContractHist.setContractNumber(rs
                                .getInt("CONTRACT_NO"));
                        lPersonContractHist.setContractStatus(rs
                                .getString("CONTRACT_STATUS"));
                        lPersonContractHist.setMemberStatus(rs
                                .getString("MEMBER_STATUS"));
                        lPersonContractHist.setGroupID(rs
                                .getInt("GROUP_ID"));
                        lPersonContractHist.setSiteID(rs
                                .getInt("SUBGROUP_ID"));
                        lPersonContractHist.setQualificationEndDate(rs
                                .getDate("QUALFCTN_END_DT"));
                        lPersonContractHist.setQualificationStartDate(rs
                                .getDate("QUALFCTN_START_DT"));
                        lPersonContractHist.setRunDate(rs
                                .getDate("RUN_DT"));
                        return lPersonContractHist;
                    }


                });

        PersonContractHist lPersonContractHist = null;
        if (lPersonContractsHist.size() > 0) {
            lPersonContractHist = lPersonContractsHist.get(0);
        }


        return lPersonContractHist;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<PersonContractHist> getPersonContractsHistForArchive(Date archiveCutoffDate)
            throws DataAccessException {

        StringBuffer query = new StringBuffer();
        query.append(selectPersonContractsHistForArchive);


        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("startDate", archiveCutoffDate, Types.DATE);


        List<PersonContractHist> personContractHistCurrent = namedParameterJdbcTemplate.query(query.toString(), namedParameters, new personProgramContractHistoryArchiveMapper());

        return personContractHistCurrent;
    }

    //Create implementation methods for person program recycle beginning here - Start

    /**
     * Select all PersonContractRecycle records.
     *
     * @return PersonContractRecycle object.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<PersonContractRecycle> getPersonContractsRecycle()
            throws DataAccessException {
        StringBuffer query = new StringBuffer();
        query.append(selectPersonContractsRecycle);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();


        List<PersonContractRecycle> lPersonContractsRecycle = namedParameterJdbcTemplate.query(query.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public PersonContractRecycle mapRow(ResultSet rs, int i) throws SQLException {
                        PersonContractRecycle lPersonContractRecycle = new PersonContractRecycle();
                        lPersonContractRecycle.setPersonContractRecycleId(rs
                                .getInt("PRSN_CNTR_PGM_RECYCLE_SEQ_ID"));
                        lPersonContractRecycle.setContractNumber(rs
                                .getInt("CONTRACT_NO"));
                        lPersonContractRecycle.setPersonNumber(rs
                                .getInt("PRSN_ID"));
                        lPersonContractRecycle.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
                        lPersonContractRecycle.setProgramId(rs
                                .getInt("BIZ_PGM_ID"));
                        lPersonContractRecycle.setContractStatusCurrentId(rs
                                .getInt("CUR_ELIG_CNTR_STAT_ID"));
                        lPersonContractRecycle.setContractStatusCurrent(rs
                                .getString("CONTRACT_STATUS_CUR"));
                        lPersonContractRecycle.setContractStatusPrevId(rs
                                .getInt("PREV_ELIG_CNTR_STAT_ID"));
                        lPersonContractRecycle.setContractStatusPrev(rs
                                .getString("CONTRACT_STATUS_PREV"));
                        lPersonContractRecycle.setRecycleStatusId(rs
                                .getInt("RECYCLE_STAT_ID"));
                        lPersonContractRecycle.setRecycleStatus(rs
                                .getString("RECYCLE_STATUS"));
                        return lPersonContractRecycle;
                    }

                });


        return lPersonContractsRecycle;
    }

    /**
     * @return PersonContractHist object.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public PersonContractHist getPersonContractHistForPersonContractMax(Integer pPersonDemographicsID, Integer pContractNo, Integer pProgramId, Integer programIncentiveOptionID)
            throws DataAccessException {

        StringBuffer query = new StringBuffer();
        query.append(selectPersonContractHistForPersonMax);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("personDemographicsID", pPersonDemographicsID, Types.INTEGER);
        namedParameters.addValue("bizPgmId", pProgramId, Types.INTEGER);

        if (pContractNo != null) {
            namedParameters.addValue("contractNo", pContractNo, Types.INTEGER);
            query.append(" AND ELIG_CNTR_NO = :contractNo");
        }

        if (programIncentiveOptionID != null) {
            namedParameters.addValue("programIncentiveOptionID", programIncentiveOptionID, Types.INTEGER);
            query.append(" AND biz_pgm_incntv_optn_id = :programIncentiveOptionID");
        }


        List<PersonContractHist> lPersonContractsHist = namedParameterJdbcTemplate.query(query.toString(), namedParameters, new personProgramContractHistoryMapper());

        PersonContractHist personContractHist = null;
        if (lPersonContractsHist.size() > 0) {
            personContractHist = lPersonContractsHist.get(0);
        }

        return personContractHist;
    }


    /**
     * Select a PersonContractHist record given groupNo, siteNo, personNo, contractNo, qualification Start date.
     *
     * @return PersonContractHist object.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public PersonContractHist getPersonContractHistForContractStatus(int pGroupNo, int pSiteNo, int pPersonDemographicsID, int pContractNo, Date pQualStartDate)
            throws DataAccessException {
        StringBuffer query = new StringBuffer();
        query.append(selectPersonContractHistForContractStatus);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("groupNo", pGroupNo, Types.INTEGER);
        namedParameters.addValue("siteNo", pSiteNo, Types.INTEGER);
        namedParameters.addValue("contractNo", pContractNo, Types.INTEGER);
        namedParameters.addValue("personDemographicsID", pPersonDemographicsID, Types.INTEGER);
        namedParameters.addValue("startDate", pQualStartDate, Types.DATE);


        List<PersonContractHist> lPersonContractsHist = namedParameterJdbcTemplate.query(query.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public PersonContractHist mapRow(ResultSet rs, int i) throws SQLException {
                        PersonContractHist lPersonContractHist = new PersonContractHist();
                        lPersonContractHist.setPersonContractSeqId(rs
                                .getInt("PERSON_CONTRACT_ID_SEQ"));
                        lPersonContractHist.setContractNumber(rs
                                .getInt("CONTRACT_NO"));
                        lPersonContractHist.setContractStatus(rs
                                .getString("CONTRACT_STATUS"));
                        lPersonContractHist.setMemberStatus(rs
                                .getString("MEMBER_STATUS"));
                        lPersonContractHist.setGroupID(rs
                                .getInt("GROUP_NO"));
                        lPersonContractHist.setPersonNumber(rs
                                .getInt("PRSN_ID"));
                        lPersonContractHist.setPersonDemographicsID(rs
                                .getInt("PRSN_DMGRPHCS_ID"));
                        lPersonContractHist.setProgramTypeCode(rs
                                .getString("BIZ_PGM_TP_CD"));
                        lPersonContractHist.setQualificationEndDate(rs
                                .getDate("QUALFCTN_END_DT"));
                        lPersonContractHist.setQualificationStartDate(rs
                                .getDate("QUALFCTN_START_DT"));
                        lPersonContractHist.setRunDate(rs
                                .getDate("RUN_DT"));
                        lPersonContractHist.setSiteID(rs
                                .getInt("SUBGRP_ID"));
                        lPersonContractHist.setStatusDate(rs
                                .getDate("STAT_DT"));

                        return lPersonContractHist;
                    }


                });

        PersonContractHist personProgramHist = null;
        if (lPersonContractsHist.size() > 0) {
            personProgramHist = lPersonContractsHist.get(0);
        }

        return personProgramHist;
    }

    /**
     * Select a PersonContractRecycle record given contract number, person number and biz program id.
     *
     * @return PersonContractRecycle object.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public PersonContractRecycle getPersonContractRecycleForPersonContract(Integer pContractNumber, Integer pPersonDemographicsID, Integer pBizProgId, Integer pProgramIncentiveOptionID)
            throws DataAccessException {

        final ArrayList<Integer> lParameters = new ArrayList<Integer>();
        StringBuffer query = new StringBuffer();

        query.append(selectPersonContractRecycleForPerson);


        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("personDemographicsID", pPersonDemographicsID, Types.INTEGER);
        namedParameters.addValue("bizPgmId", pBizProgId, Types.INTEGER);

        if (pContractNumber != null) {
            namedParameters.addValue("contractNo", pContractNumber, Types.INTEGER);
            query.append(" AND ELIG_CNTR_NO = :contractNo");
        }

        if (pProgramIncentiveOptionID != null) {
            lParameters.add(pProgramIncentiveOptionID);
            namedParameters.addValue("programIncentiveOptionID", pProgramIncentiveOptionID, Types.INTEGER);
            query.append(" AND biz_pgm_incntv_optn_id = :programIncentiveOptionID");
        }




        List<PersonContractRecycle> lPersonContractsRecycle = namedParameterJdbcTemplate.query(query.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public PersonContractRecycle mapRow(ResultSet rs, int i) throws SQLException {
                        PersonContractRecycle lPersonContractRecycle = new PersonContractRecycle();
                        lPersonContractRecycle.setPersonContractRecycleId(rs
                                .getInt("PRSN_CNTR_PGM_RECYCLE_SEQ_ID"));
                        lPersonContractRecycle.setContractNumber(rs
                                .getInt("CONTRACT_NO"));
                        lPersonContractRecycle.setPersonNumber(rs
                                .getInt("PRSN_ID"));
                        lPersonContractRecycle.setPersonDemographicsID(rs
                                .getInt("PRSN_DMGRPHCS_ID"));
                        lPersonContractRecycle.setProgramId(rs
                                .getInt("BIZ_PGM_ID"));
                        lPersonContractRecycle.setContractStatusPrevId(rs
                                .getInt("PREV_ELIG_CNTR_STAT_ID"));
                        lPersonContractRecycle.setContractStatusCurrentId(rs
                                .getInt("CUR_ELIG_CNTR_STAT_ID"));
                        lPersonContractRecycle.setRecycleStatusId(rs
                                .getInt("RECYCLE_STAT_ID"));
                        lPersonContractRecycle.setContractStatusPrev(rs
                                .getString("CONTRACT_STATUS_PREV"));
                        lPersonContractRecycle.setContractStatusCurrent(rs
                                .getString("CONTRACT_STATUS_CUR"));
                        lPersonContractRecycle.setRecycleStatus(rs
                                .getString("RECYCLE_STATUS"));
                        lPersonContractRecycle.setRecycleStatDate(rs
                                .getDate("RECYCLE_STAT_DT"));
                        lPersonContractRecycle.setReasonDesc(rs
                                .getString("RSN_DESC"));
                        lPersonContractRecycle.setApproverUserId(rs
                                .getString("APRV_USR_ID"));
                        lPersonContractRecycle.setQualificationStartDate(rs
                                .getDate("QUAL_START_DT"));
                        lPersonContractRecycle.setQualificationEndDate(rs
                                .getDate("QUAL_END_DT"));
                        lPersonContractRecycle.setProgramStartDate(rs
                                .getDate("PROG_START_DT"));
                        lPersonContractRecycle.setProgramEndDate(rs
                                .getDate("PROG_END_DT"));
                        lPersonContractRecycle.setLuvOnHoldQualifiedReviewWindowInDays(rs
                                .getString("ONHOLD_QUALIFIED_REV_IN_DAYS").trim());
                        lPersonContractRecycle.setInsertDate(rs
                                .getDate("INSERT_TS"));

                        return lPersonContractRecycle;
                    }


                });

        PersonContractRecycle lPersonContractRecycle = null;
        if (lPersonContractsRecycle.size() > 0) {
            lPersonContractRecycle = lPersonContractsRecycle.get(0);
        }

        return lPersonContractRecycle;
    }

    /**
     * Select PersonContractRecycle records given recycle status.
     *
     * @return PersonContractRecycle object.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<PersonContractRecycle> getPersonContractsRecycleForStatus(Integer pRecycleStatusId)
            throws DataAccessException {
        final ArrayList<PersonContractRecycle> lPersonContractsRecycle = new ArrayList<PersonContractRecycle>();
        StringBuffer query = new StringBuffer();
        query.append(selectPersonContractsRecycleForStatus);
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pRecycleStatusId};
        int types[] = new int[]{Types.INTEGER};

        template.query(query.toString(), params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        PersonContractRecycle lPersonContractRecycle = new PersonContractRecycle();
                        lPersonContractRecycle.setContractNumber(rs
                                .getInt("CONTRACT_NO"));
                        lPersonContractRecycle.setPersonNumber(rs
                                .getInt("PRSN_ID"));
                        lPersonContractRecycle.setPersonDemographicsID(rs
                                .getInt("PRSN_DMGRPHCS_ID"));
                        lPersonContractRecycle.setProgramId(rs
                                .getInt("BIZ_PGM_ID"));
                        lPersonContractRecycle.setRecycleStatus(rs
                                .getString("RECYCLE_STATUS"));

                        lPersonContractsRecycle
                                .add(lPersonContractRecycle);
                    }
                });

        return lPersonContractsRecycle;
    }

    /**
     * Select PersonContractRecycle records considered ON HOLD.
     *
     * @return PersonContractRecycle object.
     */
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<PersonContractRecycle> getPersonContractRecycleOnHolds()
            throws DataAccessException {
        StringBuffer query = new StringBuffer();
        query.append(selectPersonContractRecycleOnHolds);


        MapSqlParameterSource namedParameters = new MapSqlParameterSource();


        List<PersonContractRecycle> lPersonContractsRecycle = namedParameterJdbcTemplate.query(query.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public PersonContractRecycle mapRow(ResultSet rs, int i) throws SQLException {
                        PersonContractRecycle lPersonContractRecycle = new PersonContractRecycle();
                        lPersonContractRecycle.setContractNumber(rs
                                .getInt("CONTRACT_NO"));
                        lPersonContractRecycle.setPersonNumber(rs
                                .getInt("PRSN_ID"));
                        lPersonContractRecycle.setPersonDemographicsID(rs
                                .getInt("PRSN_DMGRPHCS_ID"));
                        lPersonContractRecycle.setProgramId(rs
                                .getInt("BIZ_PGM_ID"));
                        lPersonContractRecycle.setRecycleStatus(rs
                                .getString("RECYCLE_STATUS"));
                        lPersonContractRecycle.setQualificationStartDate(rs
                                .getDate("QUAL_START_DT"));
                        lPersonContractRecycle.setQualificationEndDate(rs
                                .getDate("QUAL_END_DT"));
                        lPersonContractRecycle.setProgramStartDate(rs
                                .getDate("PROG_START_DT"));
                        lPersonContractRecycle.setProgramEndDate(rs
                                .getDate("PROG_END_DT"));
                        return lPersonContractRecycle;
                    }

                });

        return lPersonContractsRecycle;
    }

    /**
     * Select PersonContractRecycleList records considered ON HOLD.
     *
     * @return PersonContractRecycleList object.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<PersonContractRecycleList> getPersonContractRecycleByRecycleStatus(String recycleStatus)
            throws DataAccessException {
        StringBuffer query = new StringBuffer();
        query.append(selectPersonContractRecycleByRecycleStatus);


        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("luVal", recycleStatus, Types.VARCHAR);


        List<PersonContractRecycleList> lPersonContractsRecycleList =namedParameterJdbcTemplate.query(query.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public PersonContractRecycleList mapRow(ResultSet rs, int i) throws SQLException {
                        PersonContractRecycleList lPersonContractRecycleList = new PersonContractRecycleList();
                        lPersonContractRecycleList.setMemberNo(rs
                                .getString("hp_mem_id"));
                        lPersonContractRecycleList.setFirstName(rs
                                .getString("first_nm"));
                        lPersonContractRecycleList.setLastName(rs
                                .getString("last_nm"));
                        lPersonContractRecycleList.setRecycleStatusDate(rs
                                .getDate("recycle_stat_dt"));
                        lPersonContractRecycleList.setRecycleStatus(rs
                                .getString("recycle_status"));
                        lPersonContractRecycleList.setRecycleStatus(rs
                                .getString("recycle_status"));
                        lPersonContractRecycleList.setContractNo(rs
                                .getInt("elig_cntr_no"));
                        lPersonContractRecycleList.setGroupNo(rs
                                .getString("EMPL_GRP_NO"));
                        lPersonContractRecycleList.setGroupName(rs
                                .getString("EMPL_GRP_NM"));
                        lPersonContractRecycleList.setReasonDescription(rs
                                .getString("RSN_DESC"));
                        return lPersonContractRecycleList;
                    }


                });

        return lPersonContractsRecycleList;
    }

    /**
     * Select a CDHPRecycle record given contract number, person number and biz program id.
     *
     * @return PersonContractRecycle object.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public CDHPFulfillmentTrackingRecycle getCDHPFulfillRecycleForPerson(int programID, int pPersonDemographicsID, int activityID)
            throws DataAccessException {
        StringBuffer query = new StringBuffer();
        query.append(selectCDHPRecycleForPerson);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("bizPgmId", programID, Types.INTEGER);
        namedParameters.addValue("personDemographicsID", pPersonDemographicsID, Types.INTEGER);
        namedParameters.addValue("actvId", activityID, Types.INTEGER);


        List<CDHPFulfillmentTrackingRecycle> lCDHPFulfillmentTrackingRecycles = namedParameterJdbcTemplate.query(query.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public Object mapRow(ResultSet rs, int i) throws SQLException {
                        CDHPFulfillmentTrackingRecycle lCDHPFulfillmentTrackingRecycle = new CDHPFulfillmentTrackingRecycle();
                        lCDHPFulfillmentTrackingRecycle.setCdhpRecycleId(rs
                                .getInt("CDHP_RECYC_ID"));
                        lCDHPFulfillmentTrackingRecycle.setProgramId(rs
                                .getInt("BIZ_PGM_ID"));
                        lCDHPFulfillmentTrackingRecycle.setPersonDemographicsID(rs
                                .getInt("PRSN_DMGRPHCS_ID"));
                        lCDHPFulfillmentTrackingRecycle.setContractNumber(rs
                                .getInt("CONTRACT_NO"));
                        lCDHPFulfillmentTrackingRecycle.setRecycleStatusId(rs
                                .getInt("RECYCLE_STAT_ID"));
                        lCDHPFulfillmentTrackingRecycle.setRecycleStatus(rs
                                .getString("RECYCLE_STATUS"));
                        lCDHPFulfillmentTrackingRecycle.setRecycleStatDate(rs
                                .getDate("RECYCLE_STAT_DT"));
                        lCDHPFulfillmentTrackingRecycle.setActivityId(rs
                                .getInt("ACTV_ID"));
                        lCDHPFulfillmentTrackingRecycle.setActivityName(rs
                                .getInt("ACTIVITY_NM"));
                        lCDHPFulfillmentTrackingRecycle.setActivityStatusIncentiveDate(rs
                                .getDate("ACTV_STAT_INCNTV_DT"));
                        lCDHPFulfillmentTrackingRecycle.setPackageSubTypeName(rs
                                .getString("PACKAGE_SUB_TYPE_NM"));
                        lCDHPFulfillmentTrackingRecycle.setReasonDesc(rs
                                .getString("RSN_DESC"));
                        lCDHPFulfillmentTrackingRecycle.setApproverUserId(rs
                                .getString("APRV_USER_ID"));
                        return lCDHPFulfillmentTrackingRecycle;
                    }


                });

        CDHPFulfillmentTrackingRecycle lCDHPFulfillmentTrackingRecycle = null;
        if (lCDHPFulfillmentTrackingRecycles.size() > 0) {
            lCDHPFulfillmentTrackingRecycle = lCDHPFulfillmentTrackingRecycles.get(0);
        }

        return lCDHPFulfillmentTrackingRecycle;
    }


    /**
     * Select count of PersonContractHist table.
     *
     * @return PersonContractHist object.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int getPersonContractHistCount()
            throws DataAccessException {

        final ArrayList count = new ArrayList();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{};
        int types[] = new int[]{};
        template.query(countPersonContractHistRows, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        count.add(rs.getInt(1));
                    }
                });


        Integer countInt = (Integer) count.get(0);

        return countInt.intValue();
    }

    /**
     * get PersonContractRecycleHistoryReconciled records if they exist.
     *
     * @return PersonContractRecycle object.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<PersonContractHist> getPersonContractHistoryReconciled(java.sql.Date pCutoffDateToReconcile)
            throws DataAccessException {
        StringBuffer query = new StringBuffer();
        query.append(selectPersonContractHistoryReconciled);


        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("startDate", pCutoffDateToReconcile, Types.DATE);


        List<PersonContractHist> lPersonContractsHist =  namedParameterJdbcTemplate.query(query.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public PersonContractHist mapRow(ResultSet rs, int i) throws SQLException {
                        PersonContractHist lPersonContractHist = new PersonContractHist();

                        lPersonContractHist.setContractNumber(rs
                                .getInt("ELIG_CNTR_NO"));
                        lPersonContractHist.setPersonNumber(rs
                                .getInt("PRSN_ID"));
                        lPersonContractHist.setPersonDemographicsID(rs
                                .getInt("PRSN_DMGRPHCS_ID"));
                        lPersonContractHist.setProgramID(rs
                                .getInt("BIZ_PGM_ID"));
                        lPersonContractHist.setMemberNumber(rs
                                .getString("HP_MEM_ID"));
                        lPersonContractHist.setFirstName(rs
                                .getString("FIRST_NM"));
                        lPersonContractHist.setLastName(rs
                                .getString("LAST_NM"));
                        lPersonContractHist.setGroupID(Integer.valueOf((rs
                                .getString("EMPL_GRP_NO"))));
                        lPersonContractHist.setSiteID(Integer.valueOf(rs
                                .getString("EMPL_GRP_SITE_ID_NO")));
                        lPersonContractHist.setHistoryContractStatus(rs.getString("HIST_CONTRACT_STATUS"));
                        lPersonContractHist.setHistoryContractInsertDate(rs.getDate("INSERT_TS"));
                        lPersonContractHist.setContractStatus(rs.getString("CONTRACT_STATUS"));
                        lPersonContractHist.setContractStatusDate(rs.getDate("CNTR_STAT_DT"));
                        lPersonContractHist.setContractLastChangedDate(rs.getDate("MODIFY_TS"));
                        return lPersonContractHist;
                    }


                });


        return lPersonContractsHist;
    }


    /**
     * get PersonContractRecycleHistoryReconciled records if they exist.
     *
     * @return PersonContractRecycle object.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<PersonActivityIncentToFulfillReconcile> getPersonActivityIncentToFulfillReconciled(String sourceSystemCode, String productSubType)
            throws DataAccessException {
        StringBuffer query = new StringBuffer();
        query.append(selectPersonActivityIncentToFulfillReconciled);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("sourceSystemId", sourceSystemCode, Types.VARCHAR);
        namedParameters.addValue("purchSubTpNm", productSubType, Types.VARCHAR);


        List<PersonActivityIncentToFulfillReconcile> lPersonActivitysIncentToFulfillReconcile = namedParameterJdbcTemplate.query(query.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public PersonActivityIncentToFulfillReconcile mapRow(ResultSet rs, int i) throws SQLException {
                        PersonActivityIncentToFulfillReconcile lPersonActivityIncentToFulfillReconcile = new PersonActivityIncentToFulfillReconcile();

                        lPersonActivityIncentToFulfillReconcile.setProgramID(rs
                                .getInt("biz_pgm_id"));
                        lPersonActivityIncentToFulfillReconcile.setGroupNo(rs
                                .getString("empl_grp_no"));
                        lPersonActivityIncentToFulfillReconcile.setSiteNo(rs
                                .getString("empl_grp_site_id_no"));
                        lPersonActivityIncentToFulfillReconcile.setPersonDemographicsID(rs
                                .getInt("prsn_dmgrphcs_id"));
                        lPersonActivityIncentToFulfillReconcile.setRegistrationID(rs
                                .getString("registration_id"));
                        lPersonActivityIncentToFulfillReconcile.setActivityID(rs
                                .getInt("actv_id"));
                        lPersonActivityIncentToFulfillReconcile.setMemberNumber(rs
                                .getString("HP_MEM_ID"));
                        lPersonActivityIncentToFulfillReconcile.setFirstName(rs
                                .getString("FIRST_NM"));
                        lPersonActivityIncentToFulfillReconcile.setLastName(rs
                                .getString("LAST_NM"));
                        lPersonActivityIncentToFulfillReconcile.setActivityName(rs
                                .getString("actv_nm"));
                        lPersonActivityIncentToFulfillReconcile.setSourceSystem(rs
                                .getString("source_system"));

                        lPersonActivityIncentToFulfillReconcile.setProgramEffectiveDate(rs.getDate("eff_dt"));
                        lPersonActivityIncentToFulfillReconcile.setProgramEndDate(rs.getDate("pgm_end_dt"));


                        lPersonActivityIncentToFulfillReconcile.setIncentedDate(rs
                                .getDate("incented_date"));

                        lPersonActivityIncentToFulfillReconcile.setContributionAmount(rs
                                .getString("contrib_amt"));

                        lPersonActivityIncentToFulfillReconcile.setContractNo(rs
                                .getString("contract_no"));
                        return lPersonActivityIncentToFulfillReconcile;
                    }


                });


        return lPersonActivitysIncentToFulfillReconcile;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public boolean isRewardPersonActivityIncentToFulfillReconcile(
            PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus) throws DataAccessException {

        Integer programID = lPersonProgramActivityIncentiveStatus.getProgramID();
        Integer personDemographicsID = lPersonProgramActivityIncentiveStatus.getPersonDemographicsID();
        Integer activityID = lPersonProgramActivityIncentiveStatus.getActivityID();

        final List<Boolean> results = new ArrayList<Boolean>();

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("bizPgmId", programID, Types.INTEGER);
        namedParameters.addValue("personDemographicsID", personDemographicsID, Types.INTEGER);
        namedParameters.addValue("actvId", activityID);


        namedParameterJdbcTemplate.query(isRewardPersonActivityIncentToFulfillReconcile, namedParameters,
                new RowMapper() {
                    @Override
                    public Boolean mapRow(ResultSet rs, int i) throws SQLException {
                        if (rs.getInt(1) > 0) {
                            results.add(Boolean.valueOf(true));
                            return true;
                        }
                        return false;
                    }


                });


        return results.size() > 0;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public boolean isCDHPPersonActivityIncentToFulfillReconcile(
            PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus) throws DataAccessException {

        Integer programID = lPersonProgramActivityIncentiveStatus.getProgramID();
        Integer personDemographicsID = lPersonProgramActivityIncentiveStatus.getPersonDemographicsID();
        Integer activityID = lPersonProgramActivityIncentiveStatus.getActivityID();
        String purchaserSubtypeName = lPersonProgramActivityIncentiveStatus.getPurchaserSubtypeName();


        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("bizPgmId", programID, Types.INTEGER);
        namedParameters.addValue("personDemographicsID", personDemographicsID, Types.INTEGER);
        namedParameters.addValue("actvId", activityID, Types.INTEGER);
        namedParameters.addValue("purchSubTpNm", purchaserSubtypeName, Types.VARCHAR);


        List<Boolean> results = namedParameterJdbcTemplate.query(isCDHPPersonActivityIncentToFulfillReconcile, namedParameters,
                new RowMapper() {
                    @Override
                    public Boolean mapRow(ResultSet rs, int i) throws SQLException {
                        if (rs.getInt(1) > 0) {
                            return Boolean.valueOf(true);
                        }
                        return Boolean.valueOf(false);
                    }

                });


        return results.size() > 0;
    }

    /**
     * get PersonContractRecycleHistoryReconciled records if they exist.
     *
     * @return PersonContractRecycle object.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<PersonActivityIncentToFulfillReconcile> getMemberActivityIncentToFulfillReconciled(String sourceSystemCode, String productSubType)
            throws DataAccessException {
        StringBuffer query = new StringBuffer();

        query.append(selectMemberActivityIncentToFulfillReconciled);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("sourceSystemId", sourceSystemCode, Types.VARCHAR);
        namedParameters.addValue("purchaseSubTpNm", productSubType, Types.VARCHAR);


        List<PersonActivityIncentToFulfillReconcile> lPersonActivitysIncentToFulfillReconcile = namedParameterJdbcTemplate.query(query.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public Object mapRow(ResultSet rs, int i) throws SQLException {
                        PersonActivityIncentToFulfillReconcile lPersonActivityIncentToFulfillReconcile = new PersonActivityIncentToFulfillReconcile();

                        lPersonActivityIncentToFulfillReconcile.setProgramID(rs
                                .getInt("biz_pgm_id"));
                        lPersonActivityIncentToFulfillReconcile.setGroupNo(rs
                                .getString("empl_grp_no"));
                        lPersonActivityIncentToFulfillReconcile.setSiteNo(rs
                                .getString("empl_grp_site_id_no"));
                        lPersonActivityIncentToFulfillReconcile.setPersonDemographicsID(rs
                                .getInt("prsn_dmgrphcs_id"));
                        lPersonActivityIncentToFulfillReconcile.setRegistrationID(rs
                                .getString("registration_id"));
                        lPersonActivityIncentToFulfillReconcile.setActivityID(rs
                                .getInt("actv_id"));
                        lPersonActivityIncentToFulfillReconcile.setMemberNumber(rs
                                .getString("HP_MEM_ID"));
                        lPersonActivityIncentToFulfillReconcile.setFirstName(rs
                                .getString("FIRST_NM"));
                        lPersonActivityIncentToFulfillReconcile.setLastName(rs
                                .getString("LAST_NM"));
                        lPersonActivityIncentToFulfillReconcile.setActivityName(rs
                                .getString("actv_nm"));
                        lPersonActivityIncentToFulfillReconcile.setSourceSystem(rs
                                .getString("source_system"));

                        lPersonActivityIncentToFulfillReconcile.setProgramEffectiveDate(rs.getDate("eff_dt"));
                        lPersonActivityIncentToFulfillReconcile.setProgramEndDate(rs.getDate("pgm_end_dt"));


                        lPersonActivityIncentToFulfillReconcile.setIncentedDate(rs
                                .getDate("incented_date"));

                        lPersonActivityIncentToFulfillReconcile.setContributionAmount(rs
                                .getString("contrib_amt"));

                        lPersonActivityIncentToFulfillReconcile.setContractNo(rs
                                .getString("contract_no"));

                        return lPersonActivityIncentToFulfillReconcile;
                    }


                });


        return lPersonActivitysIncentToFulfillReconcile;
    }


    /**
     * Select count of PersonContractRecycle table.
     *
     * @return PersonContractRecycle object.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int getPersonContractRecycleCount()
            throws DataAccessException {

        final ArrayList count = new ArrayList();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{};
        int types[] = new int[]{};
        template.query(countPersonContractRecycleRows, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        count.add(rs.getInt(1));
                    }
                });


        Integer countInt = (Integer) count.get(0);

        return countInt.intValue();
    }

    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public boolean isPersonContractProgramHistExist(Integer programID, Integer personID, Integer programIncentiveOptionID) {

        final ArrayList<Boolean> results = new ArrayList<Boolean>();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{programID, programIncentiveOptionID, personID};
        int types[] = new int[]{Types.INTEGER, Types.INTEGER, Types.INTEGER};
        template.query(isPersonContractProgramHistExist, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        if (rs.getInt(1) > 0) {
                            results.add(Boolean.valueOf(true));
                        }
                    }
                });

        for (int i = 0; i < params.length; i++) {
            params[i] = null;
        }
        types = null;

        return results.size() > 0;

    }


    /**
     * @see com.healthpartners.service.bpm.dao.PersonDAO#insertPersonContractsHist(com.healthpartners.service.bpm.dto.PersonContractHist)
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int insertPersonContractsHist(Collection<PersonContractHist> personProgramsHist)
            throws DataAccessException {

        // Retrieve the next sequence number for the Person Contracts Hist Log.


        Iterator<PersonContractHist> iter = personProgramsHist.iterator();

        Integer personContractHistId = null;
        Integer programID = null;
        Integer contractNumber = null;
        String memberStatus = null;
        String contractStatus = null;
        String programTypeCode = null;
        Integer groupNumber = null;
        Integer personNumber = null;
        Integer personDemographicsID = null;
        Date qualEndDate = null;
        Date qualStartDate = null;
        Date programEndDate = null;
        Date programStartDate = null;
        Date runDate = null;
        Integer siteNumber = null;
        Date contractStatusDate = null;
        Integer businessProgramIncentiveOptionID = null;
        Date memberStatusDate = null;
        int rowsInserted = 0;

        runDate = new Date(new java.util.Date().getTime());


        while (iter.hasNext()) {
            PersonContractHist personProgramHist = iter.next();
            personContractHistId = personContractHistIdIncrementer
                    .nextIntValue();
            programID = (personProgramHist.getProgramID() != null) ? personProgramHist.getProgramID() : null;
            personDemographicsID = (personProgramHist.getPersonDemographicsID() != null) ? personProgramHist.getPersonDemographicsID() : null;
            contractNumber = (personProgramHist.getContractNumber() != null) ? personProgramHist.getContractNumber() : null;
            contractStatus = (personProgramHist.getContractStatus() != null) ? personProgramHist.getContractStatus() : null;
            memberStatus = (personProgramHist.getMemberStatus() != null) ? personProgramHist.getMemberStatus() : null;
            groupNumber = (personProgramHist.getGroupID() != null) ? personProgramHist.getGroupID() : null;
            personNumber = (personProgramHist.getPersonNumber() != null) ? personProgramHist.getPersonNumber() : null;
            qualEndDate = (personProgramHist.getQualificationEndDate() != null) ? personProgramHist.getQualificationEndDate() : null;
            qualStartDate = (personProgramHist.getQualificationStartDate() != null) ? personProgramHist.getQualificationStartDate() : null;
            programTypeCode = (personProgramHist.getProgramTypeCode() != null) ? personProgramHist.getProgramTypeCode() : null;
            siteNumber = (personProgramHist.getSiteID() != null) ? personProgramHist.getSiteID() : null;
            contractStatusDate = (personProgramHist.getStatusDate() != null) ? personProgramHist.getStatusDate() : null;
            programEndDate = (personProgramHist.getProgramEndDate() != null) ? personProgramHist.getProgramEndDate() : null;
            programStartDate = (personProgramHist.getProgramStartDate() != null) ? personProgramHist.getProgramStartDate() : null;
            businessProgramIncentiveOptionID = (personProgramHist.getBusinessProgramIncentiveOptionID() != null) ? personProgramHist.getBusinessProgramIncentiveOptionID() : null;
            memberStatusDate = (personProgramHist.getMemberStatusDate() != null) ? personProgramHist.getMemberStatusDate() : null;


            // Persist.
            JdbcTemplate template = getJdbcTemplate();
            Object params[] = new Object[]{personContractHistId, programID, programTypeCode, personDemographicsID,
                    personNumber,
                    contractNumber, groupNumber, siteNumber,
                    memberStatus, contractStatus, contractStatusDate,
                    qualStartDate, qualEndDate,
                    programStartDate, programEndDate, businessProgramIncentiveOptionID, memberStatusDate
                    , contractNumber, businessProgramIncentiveOptionID
                    , personDemographicsID, businessProgramIncentiveOptionID
            };
            int types[] = new int[]{Types.INTEGER, Types.INTEGER, Types.VARCHAR, Types.INTEGER, Types.INTEGER,
                    Types.INTEGER, Types.INTEGER, Types.INTEGER,
                    Types.VARCHAR, Types.VARCHAR, Types.DATE,
                    Types.DATE, Types.DATE,
                    Types.DATE, Types.DATE, Types.INTEGER, Types.DATE
                    , Types.INTEGER, Types.INTEGER
                    , Types.INTEGER, Types.INTEGER
            };
            try {
                int rowInserted = template.update(insertPersonContractHist, params, types);
                if (rowInserted > 0) {
                    rowsInserted++;
                }
            } catch (Exception ex) {
                System.out.print("Error method insertPersonContractsHist possible attempt to insert duplicates: " + ex);
                logger.error("Error method insertPersonContractsHist possible attempt to insert duplicates: " + ex);
                logger.error("");
                logger.error("contractNumber: " + contractNumber);
                logger.error("contractStatus: " + contractStatus);
                logger.error("memberStatus: " + memberStatus);
                logger.error("groupNumber: " + groupNumber);
                logger.error("personNumber: " + personNumber);
                logger.error("personDemographicsID: " + personDemographicsID);
                logger.error("programTypeCode: " + programTypeCode);
                logger.error("siteNumber: " + siteNumber);
                logger.error("businessProgramIncentiveOptionID: " + businessProgramIncentiveOptionID);
                logger.error("memberStatusDate: " + memberStatusDate);
            }
        }
        return rowsInserted;
    }


    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int insertPersonContractHist(PersonContractHist personProgramHist)
            throws DataAccessException, BPMException {

        // Retrieve the next sequence number for the Person Contracts Hist Log.
        Integer personContractHistId = null;
        Integer programId = null;
        Integer contractNumber = null;
        String memberStatus = null;
        String contractStatus = null;
        String programTypeCode = null;
        Integer groupNumber = null;
        Integer personNumber = null;
        Integer personDemographicsID = null;
        Date qualEndDate = null;
        Date qualStartDate = null;
        Date programEndDate = null;
        Date programStartDate = null;

        Integer siteNumber = null;
        Date contractStatusDate = null;
        Integer businessProgramIncentiveOptionID = null;
        Date memberStatusDate = null;
        String lIncentiveActivationStatusCode = null;
        int rowsInserted = 0;

        personContractHistId = personContractHistIdIncrementer
                .nextIntValue();
        programId = (personProgramHist.getProgramID() != null) ? personProgramHist.getProgramID() : null;
        contractNumber = (personProgramHist.getContractNumber() != null) ? personProgramHist.getContractNumber() : null;
        contractStatus = (personProgramHist.getContractStatus() != null) ? personProgramHist.getContractStatus() : null;
        memberStatus = (personProgramHist.getMemberStatus() != null) ? personProgramHist.getMemberStatus() : null;
        groupNumber = (personProgramHist.getGroupID() != null) ? personProgramHist.getGroupID() : null;
        personNumber = (personProgramHist.getPersonNumber() != null) ? personProgramHist.getPersonNumber() : null;
        personDemographicsID = (personProgramHist.getPersonDemographicsID() != null) ? personProgramHist.getPersonDemographicsID() : null;
        qualEndDate = (personProgramHist.getQualificationEndDate() != null) ? personProgramHist.getQualificationEndDate() : null;
        qualStartDate = (personProgramHist.getQualificationStartDate() != null) ? personProgramHist.getQualificationStartDate() : null;
        programTypeCode = (personProgramHist.getProgramTypeCode() != null) ? personProgramHist.getProgramTypeCode() : null;
        siteNumber = (personProgramHist.getSiteID() != null) ? personProgramHist.getSiteID() : null;
        contractStatusDate = (personProgramHist.getContractStatusDate() != null) ? personProgramHist.getContractStatusDate() : null;
        programEndDate = (personProgramHist.getProgramEndDate() != null) ? personProgramHist.getProgramEndDate() : null;
        programStartDate = (personProgramHist.getProgramStartDate() != null) ? personProgramHist.getProgramStartDate() : null;
        businessProgramIncentiveOptionID = (personProgramHist.getBusinessProgramIncentiveOptionID() != null) ? personProgramHist.getBusinessProgramIncentiveOptionID() : null;
        memberStatusDate = (personProgramHist.getMemberStatusDate() != null) ? personProgramHist.getMemberStatusDate() : null;
        lIncentiveActivationStatusCode = personProgramHist.getActivationStatusCode();

        // Persist.
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{personContractHistId, programId, programTypeCode, personDemographicsID
                , personNumber, contractNumber, groupNumber,
                siteNumber, memberStatus, contractStatus,
                contractStatusDate, qualStartDate, qualEndDate,
                programStartDate, programEndDate, businessProgramIncentiveOptionID, memberStatusDate
                , lIncentiveActivationStatusCode
        };
        int types[] = new int[]{Types.INTEGER, Types.INTEGER, Types.VARCHAR, Types.INTEGER,
                Types.INTEGER, Types.INTEGER, Types.INTEGER,
                Types.INTEGER, Types.VARCHAR, Types.VARCHAR,
                Types.DATE, Types.DATE, Types.DATE,
                Types.DATE, Types.DATE, Types.INTEGER, Types.DATE
                , Types.VARCHAR
        };
        try {
            int rowInserted = template.update(insertPersonContractHist, params, types);
            if (rowInserted > 0) {
                rowsInserted++;
            }
        } catch (Exception ex) {
            System.out.println("Error method insertPersonContractHist possible attempt to insert duplicates: " + ex);
            logger.error("Error method insertPersonContractHist possible attempt to insert duplicates: " + ex);
            logger.error("");
            logger.error("personContractHistId: " + personContractHistId);
            logger.error("contractNumber: " + contractNumber);
            logger.error("contractStatus: " + contractStatus);
            logger.error("memberStatus: " + memberStatus);
            logger.error("groupNumber: " + groupNumber);
            logger.error("personNumber: " + personNumber);
            logger.error("programTypeCode: " + programTypeCode);
            logger.error("siteNumber: " + siteNumber);
            logger.error("businessProgramIncentiveOptionID: " + businessProgramIncentiveOptionID);
            logger.error("memberStatusDate: " + memberStatusDate);
            throw new BPMException(ex);
        }

        return rowsInserted;
    }


    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int insertPersonContractRecycle(PersonContractRecycle personProgramRecycle)
            throws DataAccessException, BPMException {

        Integer personContractRecycleId = personContractRecycleIdIncrementer
                .nextIntValue();
        Integer contractNumber = (personProgramRecycle.getContractNumber() != null) ? personProgramRecycle.getContractNumber() : null;
        Integer personNumber = (personProgramRecycle.getPersonNumber() != null) ? personProgramRecycle.getPersonNumber() : null;
        Integer personDemographicsID = (personProgramRecycle.getPersonDemographicsID() != null) ? personProgramRecycle.getPersonDemographicsID() : null;
        Integer programId = (personProgramRecycle.getProgramId() != null) ? personProgramRecycle.getProgramId() : null;
        Integer contractStatusPrevId = (personProgramRecycle.getContractStatusPrevId() != null) ? personProgramRecycle.getContractStatusPrevId() : null;
        Integer contractStatusCurrentId = (personProgramRecycle.getContractStatusCurrentId() != null) ? personProgramRecycle.getContractStatusCurrentId() : null;
        Integer recycleStatusId = (personProgramRecycle.getRecycleStatusId() != null) ? personProgramRecycle.getRecycleStatusId() : null;
        String approverUserId = (personProgramRecycle.getApproverUserId() != null) ? personProgramRecycle.getApproverUserId() : null;
        String reasonDesc = (personProgramRecycle.getReasonDesc() != null) ? personProgramRecycle.getReasonDesc() : null;

        // Persist.
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{personContractRecycleId, programId, personNumber, personDemographicsID,
                contractStatusPrevId, contractStatusCurrentId, recycleStatusId,
                contractNumber, approverUserId, reasonDesc
        };

        int types[] = new int[]{Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER,
                Types.INTEGER, Types.INTEGER, Types.INTEGER,
                Types.VARCHAR, Types.VARCHAR};
        int rowInserted = 0;
        try {
            rowInserted = template.update(insertPersonContractRecycle, params, types);
        } catch (Exception ex) {
            System.out.print("Error method insertPersonContractRecycle possible attempt to insert duplicates: " + ex);
            logger.error("Error method insertPersonContractRecycle possible attempt to insert duplicates: " + ex);
            logger.error("");
            logger.error("contractNumber: " + contractNumber);
            logger.error("personNumber: " + personNumber);
            logger.error("bizProgramId: " + programId);
            throw new BPMException("Failed to insert PersonContractRecycle record.", ex);

        }

        return rowInserted;
    }


    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int insertCDHPFulfillmentRecycle(CDHPFulfillmentTrackingRecycle newCDHPFulfillmentTrackingRecycle)
            throws DataAccessException, BPMException {

        Integer personContractRecycleId = cdhpRecycleIdIncrementer
                .nextIntValue();
        Integer programId = (newCDHPFulfillmentTrackingRecycle.getProgramId() != null) ? newCDHPFulfillmentTrackingRecycle.getProgramId() : null;
        Integer contractNumber = (newCDHPFulfillmentTrackingRecycle.getContractNumber() != null) ? newCDHPFulfillmentTrackingRecycle.getContractNumber() : null;
        Integer personDemographicsID = (newCDHPFulfillmentTrackingRecycle.getPersonDemographicsID() != null) ? newCDHPFulfillmentTrackingRecycle.getPersonDemographicsID() : null;
        Integer recycleStatusId = (newCDHPFulfillmentTrackingRecycle.getRecycleStatusId() != null) ? newCDHPFulfillmentTrackingRecycle.getRecycleStatusId() : null;
        Integer activityId = (newCDHPFulfillmentTrackingRecycle.getActivityId() != null) ? newCDHPFulfillmentTrackingRecycle.getActivityId() : null;
        java.sql.Date activityIncentiveDate = (newCDHPFulfillmentTrackingRecycle.getActivityStatusIncentiveDate() != null) ? newCDHPFulfillmentTrackingRecycle.getActivityStatusIncentiveDate() : null;
        String packageSubTypeName = (newCDHPFulfillmentTrackingRecycle.getPackageSubTypeName() != null) ? newCDHPFulfillmentTrackingRecycle.getPackageSubTypeName() : null;
        String reasonDesc = (newCDHPFulfillmentTrackingRecycle.getReasonDesc() != null) ? newCDHPFulfillmentTrackingRecycle.getReasonDesc() : null;
        String reasonTollgateRuleDesc = (newCDHPFulfillmentTrackingRecycle.getReasonTollgateRule() != null) ? newCDHPFulfillmentTrackingRecycle.getReasonTollgateRule() : null;
        String approverUserId = (newCDHPFulfillmentTrackingRecycle.getApproverUserId() != null) ? newCDHPFulfillmentTrackingRecycle.getApproverUserId() : null;


        // Persist.
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{personContractRecycleId, programId, personDemographicsID, contractNumber,
                recycleStatusId, activityId, activityIncentiveDate, packageSubTypeName,
                approverUserId, reasonDesc, reasonTollgateRuleDesc
        };

        int types[] = new int[]{Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER,
                Types.INTEGER, Types.DATE, Types.VARCHAR,
                Types.VARCHAR, Types.VARCHAR, Types.VARCHAR};
        int rowInserted = 0;
        try {
            rowInserted = template.update(insertCDHPFulfillRecycle, params, types);
        } catch (Exception ex) {
            System.out.print("Error method cdhpRecycleIdIncrementer possible attempt to insert duplicates: " + ex);
            logger.error("Error method cdhpRecycleIdIncrementer possible attempt to insert duplicates: " + ex);
            logger.error("");
            logger.error("bizProgramId: " + programId);
            logger.error("contractNumber: " + contractNumber);
            logger.error("personNumber: " + personDemographicsID);

            throw new BPMException("Failed to insert PersonContractRecycle record.", ex);

        }

        return rowInserted;
    }


    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int updateCDHPFulfillRecycleStatus(CDHPFulfillmentTrackingRecycle lCDHPFulfillmentTrackingRecycle) throws DataAccessException, BPMException {

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{
                lCDHPFulfillmentTrackingRecycle.getRecycleStatusId(), BPMConstants.BPM_USER_SYSTEM, lCDHPFulfillmentTrackingRecycle.getCdhpRecycleId()
        };
        int types[] = new int[]{Types.INTEGER, Types.VARCHAR, Types.INTEGER};

        return template.update(updateCDHPFulfillRecycleStatus, params, types);

    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int updatePersonContractRecycleStatus(PersonContractRecycle personContractRecycle) throws DataAccessException, BPMException {

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{
                personContractRecycle.getRecycleStatusId(), BPMConstants.BPM_USER_SYSTEM, personContractRecycle.getPersonContractRecycleId()
        };
        int types[] = new int[]{Types.INTEGER, Types.VARCHAR, Types.INTEGER};

        return template.update(updatePersonContractRecycleStatus, params, types);

    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int updatePersonContractRecycleStatusWithReasonDesc(PersonContractRecycle personContractRecycle) throws DataAccessException, BPMException {

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{
                personContractRecycle.getRecycleStatusId(), BPMConstants.BPM_USER_SYSTEM,
                personContractRecycle.getApproverUserId(), personContractRecycle.getReasonDesc(),
                personContractRecycle.getPersonContractRecycleId()
        };
        int types[] = new int[]{Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER};

        return template.update(updatePersonContractRecycleStatusWithReasonDesc, params, types);

    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int updatePersonContractRecycleStatusPerTollgateRules(PersonContractRecycle personContractRecycle) throws DataAccessException, BPMException {
        if (personContractRecycle.getPersonContractRecycleId() == null) {
            insertPersonContractRecyclePerTollgateRules(personContractRecycle);
            return 1;
        } else {
            JdbcTemplate template = getJdbcTemplate();
            Object params[] = new Object[]{
                    personContractRecycle.getRecycleStatusId(), BPMConstants.BPM_USER_SYSTEM,
                    personContractRecycle.getApproverUserId(), personContractRecycle.getReasonDesc(),
                    personContractRecycle.getPersonContractRecycleId()
            };
            int types[] = new int[]{Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER};

            return template.update(updatePersonContractRecycleStatusWithReasonDesc, params, types);
        }
    }

    /**
     *
     */
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    private int insertPersonContractRecyclePerTollgateRules(PersonContractRecycle personProgramRecycle)
            throws DataAccessException, BPMException {

        Integer personContractRecycleId = personContractRecycleIdIncrementer
                .nextIntValue();
        Integer contractNumber = (personProgramRecycle.getContractNumber() != null) ? personProgramRecycle.getContractNumber() : null;
        Integer personNumber = (personProgramRecycle.getPersonNumber() != null) ? personProgramRecycle.getPersonNumber() : null;
        Integer personDemographicsID = (personProgramRecycle.getPersonDemographicsID() != null) ? personProgramRecycle.getPersonDemographicsID() : null;
        Integer programId = (personProgramRecycle.getProgramId() != null) ? personProgramRecycle.getProgramId() : null;
        Integer programIncentiveOptionID = (personProgramRecycle.getProgramIncentiveOptionID() != null) ? personProgramRecycle.getProgramIncentiveOptionID() : null;
        Integer contractStatusPrevId = (personProgramRecycle.getContractStatusPrevId() != null) ? personProgramRecycle.getContractStatusPrevId() : null;
        Integer contractStatusCurrentId = (personProgramRecycle.getContractStatusCurrentId() != null) ? personProgramRecycle.getContractStatusCurrentId() : null;
        Integer memberStatusPrevId = (personProgramRecycle.getMemberStatusPrevId() != null) ? personProgramRecycle.getMemberStatusPrevId() : null;
        Integer memberStatusCurrentId = (personProgramRecycle.getMemberStatusCurrentId() != null) ? personProgramRecycle.getMemberStatusCurrentId() : null;
        Integer recycleStatusId = (personProgramRecycle.getRecycleStatusId() != null) ? personProgramRecycle.getRecycleStatusId() : null;
        String approverUserId = (personProgramRecycle.getApproverUserId() != null) ? personProgramRecycle.getApproverUserId() : null;
        String reasonDesc = (personProgramRecycle.getReasonDesc() != null) ? personProgramRecycle.getReasonDesc() : null;

        // Persist.
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{personContractRecycleId, programId, programIncentiveOptionID, personNumber, personDemographicsID,
                contractStatusPrevId, contractStatusCurrentId, memberStatusPrevId, memberStatusCurrentId, recycleStatusId,
                contractNumber, approverUserId, reasonDesc
        };

        int types[] = new int[]{Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER,
                Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER,
                Types.VARCHAR, Types.VARCHAR};
        int rowInserted = 0;
        try {
            rowInserted = template.update(insertPersonContractRecyclePerTollgateRules, params, types);
        } catch (Exception ex) {
            System.out.print("Error method insertPersonContractRecyclePerTollgateRules possible attempt to insert duplicates: " + ex);
            logger.error("Error method insertPersonContractRecyclePerTollgateRules possible attempt to insert duplicates: " + ex);
            logger.error("");
            logger.error("contractNumber: " + contractNumber);
            logger.error("personNumber: " + personNumber);
            logger.error("bizProgramId: " + programId);
            throw new BPMException("Failed to insert PersonContractRecycle record.", ex);

        }

        return rowInserted;
    }


    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int deletePersonContractHist(Date purgeDate)
            throws DataAccessException {
        int deleteCount = 0;


        JdbcTemplate template = getJdbcTemplate();

        Object params[] = new Object[]{purgeDate};
        int types[] = new int[]{Types.DATE};
        int returnCount = template.update(deletePersonContractsHist, params, types);
        if (returnCount > 0) {
            deleteCount++;
        }


        return deleteCount;
    }


    /**
     * @throws Exception
     * @see com.healthpartners.service.bpm.dao.PersonDAO#insertPersonContractsHistArchive(com.healthpartners.service.bpm.dto.PersonContractHist)
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int insertPersonContractsHistArchive(Collection<PersonContractHist> personContractsHistArchive) {

        // Retrieve the next sequence number for the Person Contracts Hist Archive.

        Integer personContractHistId = null;
        Integer programID = null;
        Integer contractNumber = null;
        String memberStatus = null;
        String contractStatus = null;
        String programTypeCode = null;
        Integer groupNumber = null;
        Integer personNumber = null;
        Integer personDemographicsID = null;
        Date qualEndDate = null;
        Date qualStartDate = null;

        Integer siteNumber = null;
        Date contractStatusDate = null;
        Integer businessProgramIncentiveOptionID = null;
        Date memberStatusDate;

        int rowsInserted = 0;


        for (PersonContractHist personContractHistArchive : personContractsHistArchive) {

            personContractHistId = personContractHistArchiveIdIncrementer
                    .nextIntValue();
            programID = (personContractHistArchive.getProgramID() != null) ? personContractHistArchive.getProgramID() : null;
            personDemographicsID = (personContractHistArchive.getPersonDemographicsID() != null) ? personContractHistArchive.getPersonDemographicsID() : null;
            contractNumber = (personContractHistArchive.getContractNumber() != null) ? personContractHistArchive.getContractNumber() : null;
            contractStatus = (personContractHistArchive.getContractStatus() != null) ? personContractHistArchive.getContractStatus() : null;
            memberStatus = (personContractHistArchive.getMemberStatus() != null) ? personContractHistArchive.getMemberStatus() : null;
            groupNumber = (personContractHistArchive.getGroupID() != null) ? personContractHistArchive.getGroupID() : null;
            personNumber = (personContractHistArchive.getPersonNumber() != null) ? personContractHistArchive.getPersonNumber() : null;
            qualEndDate = (personContractHistArchive.getQualificationEndDate() != null) ? personContractHistArchive.getQualificationEndDate() : null;
            qualStartDate = (personContractHistArchive.getQualificationStartDate() != null) ? personContractHistArchive.getQualificationStartDate() : null;
            programTypeCode = (personContractHistArchive.getProgramTypeCode() != null) ? personContractHistArchive.getProgramTypeCode() : null;
            siteNumber = (personContractHistArchive.getSiteID() != null) ? personContractHistArchive.getSiteID() : null;
            contractStatusDate = (personContractHistArchive.getContractStatusDate() != null) ? personContractHistArchive.getContractStatusDate() : null;
            businessProgramIncentiveOptionID = (personContractHistArchive.getBusinessProgramIncentiveOptionID() != null) ? personContractHistArchive.getBusinessProgramIncentiveOptionID() : null;
            memberStatusDate = (personContractHistArchive.getMemberStatusDate() != null) ? personContractHistArchive.getMemberStatusDate() : null;


            // Persist.
            JdbcTemplate template = getJdbcTemplate();
            Object params[] = new Object[]{personContractHistId, programID, programTypeCode, personDemographicsID,
                    personNumber, contractNumber, groupNumber, siteNumber,
                    memberStatus, contractStatus, contractStatusDate,
                    qualStartDate, qualEndDate,
                    businessProgramIncentiveOptionID, memberStatusDate
                    , contractNumber, businessProgramIncentiveOptionID
                    , personDemographicsID, businessProgramIncentiveOptionID
            };
            int types[] = new int[]{Types.INTEGER, Types.INTEGER, Types.VARCHAR, Types.INTEGER,
                    Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER,
                    Types.VARCHAR, Types.VARCHAR, Types.DATE,
                    Types.DATE, Types.DATE,
                    Types.INTEGER, Types.DATE
                    , Types.INTEGER, Types.INTEGER
                    , Types.INTEGER, Types.INTEGER
            };
            try {
                int rowInserted = template.update(insertPersonContractHistArchive, params, types);
                if (rowInserted > 0) {
                    rowsInserted++;
                }
            } catch (Exception ex) {
                System.out.print("Error method insertPersonContractsHistArchive possible attempt to insert duplicates: " + ex);
                logger.error("Error method insertPersonContractsHist possible attempt to insert duplicates: " + ex);
                logger.error("");
                logger.error("contractNumber: " + contractNumber);
                logger.error("contractStatus: " + contractStatus);
                logger.error("memberStatus: " + memberStatus);
                logger.error("groupNumber: " + groupNumber);
                logger.error("personNumber: " + personNumber);
                logger.error("personDemographicsID: " + personDemographicsID);
                logger.error("programTypeCode: " + programTypeCode);
                logger.error("siteNumber: " + siteNumber);
                logger.error("businessProgramIncentiveOptionID: " + businessProgramIncentiveOptionID);
                logger.error("memberStatusDate: " + memberStatusDate);
            }
        }
        return rowsInserted;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int deletePersonContractsRecycle(Collection<PersonContractRecycle> personProgramsRecycle)
            throws DataAccessException {
        int deleteCount = 0;
        Iterator iter = personProgramsRecycle.iterator();
        while (iter.hasNext()) {
            JdbcTemplate template = getJdbcTemplate();
            PersonContractRecycle personProgramRecycle = (PersonContractRecycle) iter.next();
            Integer personContractRecycleId = personProgramRecycle.getPersonContractRecycleId();

            Object params[] = new Object[]{personContractRecycleId};
            int types[] = new int[]{Types.INTEGER};
            int returnCount = template.update(deletePersonContractsRecycle, params, types);
            if (returnCount > 0) {
                deleteCount++;
            }
        }

        return deleteCount;
    }

    /*
     * @see com.healthpartners.service.bpm.dao.PersonDAO#insertEmployerFulfillmentMemberActivityCompletions(group)
     * find and write member non HA member activity completions to tracking table.  Return number of records written.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int insertEmployerFulfillmentMemberActivityCompletions(String groupNo, String weekNDayOfMonthFrequence)
            throws DataAccessException {

        // Persist
        JdbcTemplate template = getJdbcTemplate();

        Object params[] = new Object[]{groupNo, weekNDayOfMonthFrequence};
        int types[] = new int[]{Types.VARCHAR, Types.VARCHAR};

        int rowsInserted = template.update(insertEmployerFulfillmentMemberActivityCompletions, params,
                types);

        for (int i = 0; i < params.length; i++) {
            params[i] = null;
        }
        types = null;

        return rowsInserted;
    }


    /**
     * getEmployerFulfillmentMemberActivityCompletions records if they exist.
     *
     * @return Collection<EmployerFulfillmentMemberActivity> collection object.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<EmployerFulfillmentMemberActivity> getEmployerFulfillmentMemberActivityCompletions(String pGroupNo, java.sql.Date pSnapShotEmplTrackDate, java.sql.Date pStartEmplTrackDate)
            throws DataAccessException {
        StringBuffer lQuery = new StringBuffer();

        lQuery.append(selectEmployerFulfillmentMemberActivityCompletions);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();

        namedParameters.addValue("emplGrpNo", pGroupNo, Types.VARCHAR);

        if (pSnapShotEmplTrackDate != null) {

            namedParameters.addValue("startDate", pSnapShotEmplTrackDate, Types.DATE);
            lQuery.append(" AND trunc(efrt.rpt_load) = trunc(:startDate)");
        } else {
            namedParameters.addValue("startDate", pSnapShotEmplTrackDate, Types.DATE);

            lQuery.append(" AND trunc(efrt.rpt_load) >= trunc(:startDate)");
        }



        List<EmployerFulfillmentMemberActivity> lEmployerFulfillmentMemberActivitys = namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public Object mapRow(ResultSet rs, int i) throws SQLException {
                        EmployerFulfillmentMemberActivity lEmployerFulfillmentMemberActivity = new EmployerFulfillmentMemberActivity();

                        lEmployerFulfillmentMemberActivity.setActivityCode(rs
                                .getString("activity_code"));
                        lEmployerFulfillmentMemberActivity.setEmployeeID(rs
                                .getString("employee_id"));
                        lEmployerFulfillmentMemberActivity.setActivityCompletionDate(rs
                                .getDate("activity_completed_date"));
                        return lEmployerFulfillmentMemberActivity;
                    }


                });


        return lEmployerFulfillmentMemberActivitys;
    }

    /**
     * Find all Business Programs for a given person.
     *
     * @param pPersonDemographicsID
     * @param pOnlyCurrentBusinessPrograms
     * @param pAllowBusinessProgramSiteTransfers
     * @return
     * @throws BPMException
     * @throws DataAccessException
     */
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<BPMBusinessProgram> getPersonBusinessPrograms(Integer pPersonDemographicsID, boolean pOnlyCurrentBusinessPrograms, boolean pAllowBusinessProgramSiteTransfers)
            throws BPMException, DataAccessException {
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectPersonBusinessPrograms);


        if (pOnlyCurrentBusinessPrograms) {
            //uncomment after unit test tjq -lQuery.append(" AND SYSDATE BETWEEN biz.eff_dt AND biz.pgm_end_dt ");
            lQuery.append(" AND SYSDATE BETWEEN biz.eff_dt AND biz.pgm_end_dt ");
        }

        if (pAllowBusinessProgramSiteTransfers) {
        } else {
            //do not allow site transfers from being returned.
            lQuery.append(" AND (SYSDATE &lt; baseline.SUBGRP_END_DT   OR trunc(biz.pgm_end_dt) &lt;= baseline.SUBGRP_END_DT) ");
        }



        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("personDemographicsID", pPersonDemographicsID, Types.INTEGER);


        List<BPMBusinessProgram> lBPMBusinessPrograms =  namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public Object mapRow(ResultSet rs, int i) throws SQLException {
                        BPMBusinessProgram lBPMBusinessProgram = new BPMBusinessProgram();

                        lBPMBusinessProgram.setProgramID(rs.getInt("biz_pgm_id"));

                        Calendar lEffDate = Calendar.getInstance();
                        lEffDate.setTime(rs.getDate("eff_dt"));
                        lBPMBusinessProgram.setEffectiveDate(lEffDate);

                        Calendar lEndDate = Calendar.getInstance();
                        lEndDate.setTime(rs.getDate("pgm_end_dt"));
                        lBPMBusinessProgram.setEndDate(lEndDate);

                        Calendar lSiteEffDate = Calendar.getInstance();
                        lSiteEffDate.setTime(rs.getDate("subgrp_eff_dt"));
                        lBPMBusinessProgram.setSiteEffectiveDate(lSiteEffDate);

                        Calendar lSiteEndDate = Calendar.getInstance();
                        lSiteEndDate.setTime(rs.getDate("subgrp_end_dt"));
                        lBPMBusinessProgram.setSiteEndDate(lSiteEndDate);

                        Calendar lQualStartDate = Calendar.getInstance();
                        lQualStartDate.setTime(rs.getDate("qualfctn_start_dt"));
                        lBPMBusinessProgram.setQualificationWindowStartDate(lQualStartDate);

                        Calendar lQualEndDate = Calendar.getInstance();
                        lQualEndDate.setTime(rs.getDate("qualfctn_end_dt"));
                        lBPMBusinessProgram.setQualificationWindowEndDate(lQualEndDate);

                        lBPMBusinessProgram.setGroupNumber(rs.getString("GRP_NO"));
                        lBPMBusinessProgram.setSiteNumber(rs.getString("SITE_ID_NO"));
                        return lBPMBusinessProgram;
                    }


                });

        return lBPMBusinessPrograms;
    }


    /**
     * Select and Insert for Membership Update, all the contracts that have ended
     * but the contract_program_status participation end date does not reflect that.
     *
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int insertProcessingStatusLogForPastContractEndDates()
            throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{};
        int types[] = new int[]{};

        return template.update(insertProcessingStatusLogForPastContractEndDates, params, types);
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public Collection<PersonProgramActivityIncentiveStatus> getUnresolvedPersonPgmActivityIncentiveStatus() throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();


        lQuery.append(selectUnresolvedPersonPgmActivityIncentiveStatus);
        MapSqlParameterSource namedParameters = new MapSqlParameterSource();


        List<PersonProgramActivityIncentiveStatus> lPersonProgramActivityIncentiveStatuses = namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public PersonProgramActivityIncentiveStatus mapRow(ResultSet rs, int i) throws SQLException {
                        PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus = new PersonProgramActivityIncentiveStatus();

                        lPersonProgramActivityIncentiveStatus.setProgramID(rs
                                .getInt("BIZ_PGM_ID"));
                        lPersonProgramActivityIncentiveStatus.setPersonDemographicsID(rs
                                .getInt("PRSN_DMGRPHCS_ID"));
                        lPersonProgramActivityIncentiveStatus.setActivityID(rs
                                .getInt("ACTV_ID"));
                        lPersonProgramActivityIncentiveStatus.setActivityIncentiveID(rs
                                .getInt("ACTV_INCNTV_ID"));
                        lPersonProgramActivityIncentiveStatus.setActivityStatusCodeID(rs
                                .getInt("ACTV_STAT_CD_ID"));
                        lPersonProgramActivityIncentiveStatus.setRegistrationID(rs
                                .getString("REGISTRATION_ID"));
                        lPersonProgramActivityIncentiveStatus.setActivityStatusIncentiveDate(rs
                                .getDate("ACTV_STAT_INCNTV_DT"));
                        lPersonProgramActivityIncentiveStatus.setBeneftiContractTypeLuID(rs
                                .getInt("BEN_CONTR_TP_LU_ID"));
                        lPersonProgramActivityIncentiveStatus.setMemberNo(rs
                                .getString("hp_mem_id"));
                        lPersonProgramActivityIncentiveStatus.setActivityName(rs
                                .getString("activity_name"));
                        return lPersonProgramActivityIncentiveStatus;
                    }

                });


        return lPersonProgramActivityIncentiveStatuses;
    }

    /*
     * Determine if person activity has already been fulfilled.  If activity has not been fulfilled, a new record
     * will be allowed which is called from the service method.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public boolean isPersonActivityFulfillmentHistoryNotExist(
            MemberActivity pMemberActivity) throws DataAccessException {

        Integer programID = pMemberActivity.getBusinessProgramID();
        Integer programIncentiveOptionID = pMemberActivity.getBusinessProgramIncentiveOptionID();
        Integer benefitPackageID = pMemberActivity.getBenefitPackageID();
        Integer contractNo = pMemberActivity.getContractNumber();
        Integer personDemographicsID = pMemberActivity.getPersonDemographicsID();
        Integer activityID = pMemberActivity.getActivity().getActivityID();


        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("bizPgmId", programID, Types.INTEGER);
        namedParameters.addValue("programIncentiveOptionID", programIncentiveOptionID, Types.INTEGER);
        namedParameters.addValue("benPkgId", benefitPackageID, Types.INTEGER);
        namedParameters.addValue("contractNo", contractNo, Types.INTEGER);
        namedParameters.addValue("personDemographicsID", personDemographicsID, Types.INTEGER);
        namedParameters.addValue("actvId", activityID, Types.INTEGER);


        List<Boolean> results =namedParameterJdbcTemplate.query(isPersonActivityFulfillmentHistoryNotExist, namedParameters,
                new RowMapper() {
                    @Override
                    public Boolean mapRow(ResultSet rs, int i) throws SQLException {
                        if (rs.getInt(1) <= 0) {
                            return Boolean.valueOf(true);
                        }
                        return Boolean.valueOf(false);
                    }

                });


        return results.size() > 0;
    }

    /**
     * Add new records where source comes from person program activity status table of person activities achieved and
     * by adding records to the fulfillment table acknowledges this and it's the last stop before fulfilled records
     * get sent off to source system.  Currently as of 01/20/2014, tobacco cessation fulfilled activities are routed to
     * Cache membership.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {DataAccessException.class})
    public int insertPersonActivityFulfillmentHistory(MemberActivity lMemberActivity)
            throws DataAccessException, BPMException {


        Integer programID = (lMemberActivity.getBusinessProgramID() != null) ? lMemberActivity.getBusinessProgramID() : null;
        Integer incentiveOptionID = (lMemberActivity.getBusinessProgramIncentiveOptionID() != null) ? lMemberActivity.getBusinessProgramIncentiveOptionID() : null;
        Integer benefitPackageID = (lMemberActivity.getBenefitPackageID() != null) ? lMemberActivity.getBenefitPackageID() : null;
        Integer contractNumber = (lMemberActivity.getContractNumber() != null) ? lMemberActivity.getContractNumber() : null;
        Integer personDemographicID = (lMemberActivity.getPersonDemographicsID() != null) ? lMemberActivity.getPersonDemographicsID() : null;

        java.sql.Date coverageEffectiveDate = null;
        if (lMemberActivity.getCoverageEffectiveDate() != null) {
            coverageEffectiveDate = BPMUtils.calendarToSqlDate(lMemberActivity.getCoverageEffectiveDate());
        }

        Integer activityID = (lMemberActivity.getActivity().getActivityID() != null) ? lMemberActivity.getActivity().getActivityID() : null;

        java.sql.Date activityIncentiveStatDate = null;
        if (lMemberActivity.getCoverageEffectiveDate() != null) {
            activityIncentiveStatDate = BPMUtils.calendarToSqlDate(lMemberActivity.getActivityStatus().getStatusEffectiveDate());
        }

        // Persist.
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{programID,
                incentiveOptionID,
                benefitPackageID,
                contractNumber,
                personDemographicID,
                coverageEffectiveDate,
                activityID,
                activityIncentiveStatDate

        };

        int types[] = new int[]{Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER,
                Types.DATE, Types.INTEGER, Types.DATE};

        int rowInserted = 0;
        try {
            rowInserted = template.update(insertPersonActivityFulfillmentHistory, params, types);
        } catch (Exception ex) {

            logger.error("bizProgramId: " + programID);
            logger.error("contractNumber: " + contractNumber);
            logger.error("personNumber: " + personDemographicID);

            throw new BPMException("Failed to insert to Activity Fulfillment Report Track History table.", ex);

        }

        return rowInserted;
    }


    public String getGetPersonByMemberId() {
        return getPersonByMemberId;
    }

    public void setGetPersonByMemberId(String getPersonByMemberId) {
        this.getPersonByMemberId = getPersonByMemberId;
    }


    public void setGetPersonByPersonId(String getPersonByPersonId) {
        this.getPersonByPersonId = getPersonByPersonId;
    }

    public String getSelectMemberStatus() {
        return selectMemberStatus;
    }

    public void setSelectMemberStatus(String selectMemberStatus) {
        this.selectMemberStatus = selectMemberStatus;
    }

    public String getSelectPersonRelationship() {
        return selectPersonRelationship;
    }

    public void setSelectPersonRelationship(String selectPersonRelationship) {
        this.selectPersonRelationship = selectPersonRelationship;
    }

    public String getSelectParticipant() {
        return selectParticipant;
    }

    public void setSelectParticipant(String selectParticipant) {
        this.selectParticipant = selectParticipant;
    }


    public String getSelectParticipantRetroactive() {
        return selectParticipantRetroactive;
    }

    public void setSelectParticipantRetroactive(String selectParticipantRetroactive) {
        this.selectParticipantRetroactive = selectParticipantRetroactive;
    }

    /**
     * Sets the updateMemberProgramStatus SQL statement. Should only be called
     * by Spring.
     *
     * @param sql the updateMemberProgramStatus to set
     */
    public void setUpdateMemberProgramStatus(String sql) {
        this.updateMemberProgramStatus = sql;
    }

    /**
     * Sets the insertMemberProgramStatus SQL statement. Should only be called
     * by Spring.
     *
     * @param sql the insertMemberProgramStatus to set
     */
    public void setInsertMemberProgramStatus(String sql) {
        this.insertMemberProgramStatus = sql;
    }

    /**
     * Sets the getMemberProgramStatus SQL statement. Should only be called by
     * Spring.
     *
     * @param sql the getMemberProgramStatus to set
     */
    public void setGetMemberProgramStatus(String sql) {
        this.getMemberProgramStatus = sql;
    }

    /**
     * Sets the countMemberProgramStatusRows SQL statement. Should only be
     * called by Spring.
     *
     * @param sql the countMemberProgramStatusRows to set
     */
    public void setCountMemberProgramStatusRows(String sql) {
        this.countMemberProgramStatusRows = sql;
    }


    public void setCountMultiActivityRewardFulfilled(
            String countMultiActivityRewardFulfilled) {
        this.countMultiActivityRewardFulfilled = countMultiActivityRewardFulfilled;
    }

    public void setFindLatestRewardFulfillStatus(
            String findLatestRewardFulfillStatus) {
        this.findLatestRewardFulfillStatus = findLatestRewardFulfillStatus;
    }


    private static final class personProgramContractHistoryMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            PersonContractHist lPersonContractHist = new PersonContractHist();
            lPersonContractHist.setPersonContractSeqId(rs
                    .getInt("PERSON_CONTRACT_ID_SEQ"));
            lPersonContractHist.setContractNumber(rs
                    .getInt("CONTRACT_NO"));
            lPersonContractHist.setContractStatus(rs
                    .getString("CONTRACT_STATUS"));
            lPersonContractHist.setMemberStatus(rs
                    .getString("MEMBER_STATUS"));
            lPersonContractHist.setGroupID(rs
                    .getInt("GROUP_NO"));
            lPersonContractHist.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
            lPersonContractHist.setPersonNumber(rs
                    .getInt("PRSN_ID"));
            lPersonContractHist.setProgramTypeCode(rs
                    .getString("BIZ_PGM_TP_CD"));
            lPersonContractHist.setQualificationEndDate(rs
                    .getDate("QUALFCTN_END_DT"));
            lPersonContractHist.setQualificationStartDate(rs
                    .getDate("QUALFCTN_START_DT"));
            lPersonContractHist.setRunDate(rs
                    .getDate("RUN_DT"));
            lPersonContractHist.setSiteID(rs
                    .getInt("SUBGRP_ID"));
            lPersonContractHist.setStatusDate(rs
                    .getDate("STAT_DT"));
            lPersonContractHist.setProgramID(rs.getInt("biz_pgm_id"));
            lPersonContractHist.setBusinessProgramIncentiveOptionID(rs.getInt("biz_pgm_incntv_optn_id"));


            return lPersonContractHist;
        }
    }


    private static final class personProgramContractHistoryArchiveMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            PersonContractHist lPersonContractHist = new PersonContractHist();
            lPersonContractHist.setPersonContractSeqId(rs
                    .getInt("PRSN_CNTR_PGM_HIST_SEQ_ID"));
            lPersonContractHist.setProgramID(rs.getInt("BIZ_PGM_ID"));
            lPersonContractHist.setPersonNumber(rs.getInt("PRSN_ID"));
            lPersonContractHist.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
            lPersonContractHist.setProgramTypeCode(rs
                    .getString("PROGRAM_TYPE_CODE"));
            lPersonContractHist.setContractNumber(rs
                    .getInt("CONTRACT_NO"));
            lPersonContractHist.setContractStatus(rs
                    .getString("ELIG_CNTR_STAT"));
            lPersonContractHist.setContractStatusDate(rs
                    .getDate("ELIG_CNTR_STAT_DT"));
            lPersonContractHist.setMemberStatus(rs
                    .getString("MEM_QUALFCTN_STAT"));
            lPersonContractHist.setMemberStatusDate(rs
                    .getDate("MEM_QUALFCTN_STAT_DT"));
            lPersonContractHist.setGroupID(rs
                    .getInt("GRP_ID"));
            lPersonContractHist.setSiteID(rs
                    .getInt("SUBGRP_ID"));
            lPersonContractHist.setQualificationEndDate(rs
                    .getDate("QUALFCTN_END_DT"));
            lPersonContractHist.setQualificationStartDate(rs
                    .getDate("QUALFCTN_START_DT"));
            lPersonContractHist.setProgramEndDate(rs
                    .getDate("pgm_end_dt"));
            lPersonContractHist.setProgramStartDate(rs
                    .getDate("pgm_eff_dt"));
            lPersonContractHist.setRunDate(rs.getDate("RUN_DT"));
            lPersonContractHist.setInsertUserID(rs.getString("INSERT_USR_ID"));
            lPersonContractHist.setBusinessProgramIncentiveOptionID(rs.getInt("BIZ_PGM_INCNTV_OPTN_ID"));

            return lPersonContractHist;
        }
    }

    private static final class activityAchievedMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            MemberActivity lMemberActivity = new MemberActivity();
            ActivityDefinition lActivity = new ActivityDefinition();
            lActivity
                    .setActivityID(rs.getObject("actv_id") != null ? new Integer(
                            rs.getInt("actv_id"))
                            : null);
            lMemberActivity.setActivity(lActivity);

            lMemberActivity.setBusinessProgramID(rs.getInt("biz_pgm_id"));
            lMemberActivity.setPersonID(rs.getInt("prsn_id"));
            lMemberActivity.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
            lMemberActivity.setBenefitPackageID(rs.getInt("ben_pkg_id"));
            lMemberActivity.setRegistrationID(rs.getString("registration_id"));
            lMemberActivity.setAuthPromoCode(rs.getString("auth_cd"));
            lMemberActivity.setBusinessProgramIncentiveOptionID(rs.getInt("incntv_optn_id"));
            lMemberActivity.setContractNumber(rs.getInt("contract_no"));
            lMemberActivity.setCollectionID(rs.getInt("collection_id"));
            lMemberActivity.setCoverageEffectiveDate(BPMUtils.dateToCalendar(rs.getDate("cvrge_eff_dt")));

            GenericStatusType lStatusType = new GenericStatusType();
            lStatusType.setStatusCodeID((rs.getInt("actv_stat_cd_id")));
            lStatusType.setStatusEffectiveDate((BPMUtils.dateToCalendar(rs
                    .getDate("actv_stat_dt"))));
            lStatusType.setOutCome(rs.getString("stat_outcm"));
            lMemberActivity.setActivityStatus(lStatusType);
            return lMemberActivity;
        }
    }


    private static final class MemberRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            Member lMember = new Member();
            GenericStatusType lStatus = new GenericStatusType();
            MemberStatus lMemberStatus = new MemberStatus();

            lMember.setMemberID(rs.getString("hp_mem_id"));
            lMember.setFirstName(rs.getString("first_nm"));
            lMember.setMiddleName(rs.getString("middle_nm"));
            lMember.setLastName(rs.getString("last_nm"));

            lMemberStatus.setBenefitLevel(rs.getString("bnft_level_desc"));
            lMemberStatus.setBenefitYearStartDate(BPMUtils.dateToCalendar(rs
                    .getDate("bnft_yr_start_dt")));

            lStatus.setStatusCodeDesc(rs.getString("stat_desc"));
            lStatus.setStatusCodeID(rs.getInt("stat_cd_id"));
            lStatus.setStatusCodeValue(rs.getString("stat_val"));
            lStatus.setStatusEffectiveDate(BPMUtils.dateToCalendar(rs
                    .getDate("stat_dt")));
            lStatus.setStatusApprover(rs.getString("aprvr_user_id"));

            lMemberStatus.setStatus(lStatus);
            lMember.setMemberStatus(lMemberStatus);
            return lMember;
        }
    }

    private static final class ContractRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            Contract lContract = new Contract();
            lContract.setContractEffectiveDate(BPMUtils.dateToCalendar(rs
                    .getDate("contract_eff_dt")));
            lContract.setContractEndDate(BPMUtils.dateToCalendar(rs
                    .getDate("contract_end_dt")));
            lContract.setContractNumber(rs.getInt("CONTRACT_NO"));
            //lContract.setPolicyHolderNumber(rs.getInt("policy_holder_no"));

            GenericStatusType lStatusType = new GenericStatusType();
            lStatusType.setStatusCodeID(rs.getInt("cntr_stat_cd_id"));
            lStatusType.setStatusCodeValue(rs.getString("cntr_stat_val"));
            lStatusType.setStatusCodeDesc(rs.getString("cntr_stat_desc"));
            lStatusType.setStatusEffectiveDate(BPMUtils.dateToCalendar(rs
                    .getDate("cntr_stat_dt")));
            lContract.setContractStatus(lStatusType);

            return lContract;
        }
    }

    private static final class ActivityFulfillRptTrackingHistRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

            ActivityFulfillmentTrackingReportHist lActivityFulfillmentTrackingReportHist = new ActivityFulfillmentTrackingReportHist();
            lActivityFulfillmentTrackingReportHist.setActivityTransID(rs.getInt("actv_txn_hist_id"));
            lActivityFulfillmentTrackingReportHist.setProgramID(rs.getInt("biz_pgm_id"));
            lActivityFulfillmentTrackingReportHist.setIncentiveOptionID(rs.getInt("incntv_optn_id"));
            lActivityFulfillmentTrackingReportHist.setContractNo(rs.getInt("contract_no"));
            lActivityFulfillmentTrackingReportHist.setPersonID(rs.getInt("prsn_id"));
            lActivityFulfillmentTrackingReportHist.setPersonDemographicsID(rs.getInt("prsn_dmgrphcs_id"));
            lActivityFulfillmentTrackingReportHist.setMemberNo(rs.getString("hp_mem_id"));
            lActivityFulfillmentTrackingReportHist.setPackageID(rs.getInt("ben_pkg_id"));
            lActivityFulfillmentTrackingReportHist.setCoverageEffectiveDate(rs.getDate("cvrge_eff_dt"));
            lActivityFulfillmentTrackingReportHist.setActivityID(rs.getInt("actv_id"));
            lActivityFulfillmentTrackingReportHist.setActivityName(rs.getString("actv_nm"));
            lActivityFulfillmentTrackingReportHist.setActivityIncentiveStatusDate(rs.getDate("actv_incntv_stat_dt"));
            lActivityFulfillmentTrackingReportHist.setInsertDate(rs.getDate("insert_ts"));
            lActivityFulfillmentTrackingReportHist.setInsertUser(rs.getString("insert_usr"));

            return lActivityFulfillmentTrackingReportHist;
        }
    }

    private static final class CDHPFulfillRptTrackingHistRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

            CDHPFulfillmentTrackingReportHist lCDHPFulfillmentTrackingReportHist = new CDHPFulfillmentTrackingReportHist();
            lCDHPFulfillmentTrackingReportHist.setCdhpTransID(rs.getInt("cdhp_txn_hist_id"));
            lCDHPFulfillmentTrackingReportHist.setProgramID(rs.getInt("biz_pgm_id"));
            lCDHPFulfillmentTrackingReportHist.setGroupID(rs.getInt("grp_id"));
            lCDHPFulfillmentTrackingReportHist.setGroupNo(rs.getString("empl_grp_no"));
            lCDHPFulfillmentTrackingReportHist.setContractNo(rs.getInt("contract_no"));
            lCDHPFulfillmentTrackingReportHist.setPersonDemographicsID(rs.getInt("prsn_dmgrphcs_id"));
            lCDHPFulfillmentTrackingReportHist.setMemberNo(rs.getString("hp_mem_id"));
            lCDHPFulfillmentTrackingReportHist.setContributionStartDate(rs.getDate("contribution_start_dt"));
            lCDHPFulfillmentTrackingReportHist.setContributionEndDate(rs.getDate("contribution_end_dt"));
            lCDHPFulfillmentTrackingReportHist.setContributionAmount(rs.getInt("contrib_amt"));
            lCDHPFulfillmentTrackingReportHist.setContributionTypeCodeId(rs.getInt("tier_contrib_id"));
            lCDHPFulfillmentTrackingReportHist.setContributionDate(rs.getDate("contrib_dt"));
            lCDHPFulfillmentTrackingReportHist.setFileSentDate(rs.getDate("file_sent_dt"));
            lCDHPFulfillmentTrackingReportHist.setActivityID(rs.getInt("actv_id"));
            lCDHPFulfillmentTrackingReportHist.setSourceActivityID(rs.getString("srce_actv_id"));
            lCDHPFulfillmentTrackingReportHist.setIncentiveReportName(rs.getString("incntv_rpt_name"));
            lCDHPFulfillmentTrackingReportHist.setIncentiveOptionID(rs.getInt("incntv_optn_id"));
            lCDHPFulfillmentTrackingReportHist.setPackageSubTypeName(rs.getString("purch_sub_tp_nm"));

            return lCDHPFulfillmentTrackingReportHist;
        }
    }

    private static final class RewardFulfillRptTrackingHistRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

            RewardFulfillmentTrackingReportHist lRewardFulfillmentTrackingReportHist = new RewardFulfillmentTrackingReportHist();
            lRewardFulfillmentTrackingReportHist.setRewardTransHistID(rs.getInt("reward_txn_hist_id"));
            lRewardFulfillmentTrackingReportHist.setProgramID(rs.getInt("biz_pgm_id"));
            lRewardFulfillmentTrackingReportHist.setGroupID(rs.getInt("grp_id"));
            lRewardFulfillmentTrackingReportHist.setGroupNo(rs.getString("empl_grp_no"));
            lRewardFulfillmentTrackingReportHist.setGroupName(rs.getString("empl_grp_nm"));
            lRewardFulfillmentTrackingReportHist.setContractNo(rs.getInt("contract_no"));
            lRewardFulfillmentTrackingReportHist.setPersonDemographicsID(rs.getInt("prsn_dmgrphcs_id"));
            lRewardFulfillmentTrackingReportHist.setMemberNo(rs.getString("hp_mem_id"));
            lRewardFulfillmentTrackingReportHist.setRewardStartDate(rs.getDate("contribution_start_dt"));
            lRewardFulfillmentTrackingReportHist.setRewardEndDate(rs.getDate("contribution_end_dt"));
            lRewardFulfillmentTrackingReportHist.setContributionAmount(rs.getInt("reward_amt"));
            lRewardFulfillmentTrackingReportHist.setFeeAmount(rs.getInt("card_fee_amt"));
            lRewardFulfillmentTrackingReportHist.setEmbossName(rs.getString("emboss_name"));
            lRewardFulfillmentTrackingReportHist.setEmbossDesc(rs.getString("embossed_desc"));
            lRewardFulfillmentTrackingReportHist.setContributionTypeCodeId(rs.getInt("tier_contrib_id"));
            lRewardFulfillmentTrackingReportHist.setRewardDate(rs.getDate("reward_dt"));
            lRewardFulfillmentTrackingReportHist.setActivityID(rs.getInt("actv_id"));
            lRewardFulfillmentTrackingReportHist.setSourceActivityID(rs.getString("srce_actv_id"));
            lRewardFulfillmentTrackingReportHist.setIncentiveOptionID(rs.getInt("incntv_optn_id"));
            lRewardFulfillmentTrackingReportHist.setCarrierMessageName(rs.getString("reward_carrier_msg_nm"));
            lRewardFulfillmentTrackingReportHist.setCarrierMessageDesc(rs.getString("reward_carrier_msg_desc"));
            lRewardFulfillmentTrackingReportHist.setCarrierMessageDesc2(rs.getString("reward_carrier_msg_desc_2"));
            lRewardFulfillmentTrackingReportHist.setTransactionMessageName(rs.getString("reward_trnsctn_msg_nm"));
            lRewardFulfillmentTrackingReportHist.setTransactionMessageDesc(rs.getString("reward_trnsctn_msg_desc"));
            lRewardFulfillmentTrackingReportHist.setPersonID(rs.getInt("prsn_id"));

            return lRewardFulfillmentTrackingReportHist;
        }
    }

    private static final class PersonActivityAchievedHRARowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

            PersonActivityAchievedContribution personCDHPContribution = new PersonActivityAchievedContribution();
            personCDHPContribution.setPersonID(new Integer(rs
                    .getInt("PRSN_ID")));
            personCDHPContribution.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
            personCDHPContribution.setContractNo(new Integer(rs
                    .getInt("CONTRACT_NO")));
            personCDHPContribution.setMemberNo(rs
                    .getString("HP_MEM_ID"));
            personCDHPContribution.setGroupID(new Integer(rs
                    .getInt("GRP_ID")));
            personCDHPContribution.setSubgroupID(new Integer(rs
                    .getInt("SUBGRP_ID")));
            personCDHPContribution.setPackageID(new Integer(rs
                    .getInt("ben_pkg_id")));

            personCDHPContribution.setGroupNo(rs
                    .getString("empl_grp_no"));
            personCDHPContribution.setSiteNo(rs
                    .getString("empl_grp_site_id_no"));
            personCDHPContribution.setPackageSubType(rs
                    .getString("purch_sub_tp_nm"));
            personCDHPContribution.setActivityID(new Integer(rs
                    .getInt("ACTV_ID")));
            personCDHPContribution.setSourceActivityID(rs
                    .getString("SRCE_ACTV_ID"));
            personCDHPContribution.setActivityStatDate(rs
                    .getDate("activity_stat_dt"));

            personCDHPContribution.setActivityIncentiveStatus((rs
                    .getString("activity_incntv_status")));
            personCDHPContribution.setProgramType((rs
                    .getString("program_type")));
            personCDHPContribution.setProgramID(new Integer(rs
                    .getInt("biz_pgm_id")));
            personCDHPContribution.setBusinessProgramTypeCode(new Integer(rs
                    .getInt("biz_pgm_tp_cd")));
            personCDHPContribution.setParticipantCap(new Integer(rs
                    .getInt("particip_cap")));
            personCDHPContribution.setFamilyCap(new Integer(rs
                    .getInt("family_cap")));
            personCDHPContribution.setContributionAmt(new Integer(rs
                    .getInt("amount_achieved")));
            personCDHPContribution.setContributionDate(rs
                    .getDate("contribution_date"));
            personCDHPContribution.setContribTypeCodeID(new Integer(rs
                    .getInt("tier_contrib_id")));
            personCDHPContribution.setBenefitContractType(rs
                    .getString("benefit_contract_type"));
            personCDHPContribution.setIncentiveOptionID(rs
                    .getInt("incntv_optn_id"));
            personCDHPContribution.setUnitTypeCodeID(rs
                    .getInt("incntv_unit_tp_cd_id"));
            personCDHPContribution.setUnitTypeCode(rs
                    .getString("INCNTV_UNIT_TYPE_CODE"));
            personCDHPContribution.setContribGridID(new Integer(rs
                    .getInt("contrib_grid_id")));
            personCDHPContribution.setMemberIncentiveStatID(new Integer(rs
                    .getInt("pgm_mem_incntv_stat_id")));
            personCDHPContribution.setContractIncentiveStatID(new Integer(rs
                    .getInt("cntr_pgm_stat_id")));
            personCDHPContribution.setIncentiveStatusActivityDetailID(rs
                    .getInt("inctv_sts_actv_dtl_id"));


            return personCDHPContribution;
        }
    }

    private static final class EmployerSponsorPersonActivityContributionRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

            PersonActivityAchievedContribution personCDHPContribution = new PersonActivityAchievedContribution();
            personCDHPContribution.setPersonID(new Integer(rs
                    .getInt("PRSN_ID")));
            personCDHPContribution.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
            personCDHPContribution.setContractNo(new Integer(rs
                    .getInt("CONTRACT_NO")));
            personCDHPContribution.setMemberNo(rs
                    .getString("HP_MEM_ID"));
            personCDHPContribution.setGroupID(new Integer(rs
                    .getInt("GRP_ID")));
            personCDHPContribution.setSubgroupID(new Integer(rs
                    .getInt("SUBGRP_ID")));
            personCDHPContribution.setPackageID(new Integer(rs
                    .getInt("ben_pkg_id")));

            personCDHPContribution.setGroupNo(rs
                    .getString("empl_grp_no"));
            personCDHPContribution.setSiteNo(rs
                    .getString("empl_grp_site_id_no"));
            personCDHPContribution.setPackageSubType(rs
                    .getString("purch_sub_tp_nm"));
            personCDHPContribution.setActivityID(new Integer(rs
                    .getInt("ACTV_ID")));
            personCDHPContribution.setSourceActivityID(rs
                    .getString("SRCE_ACTV_ID"));
            personCDHPContribution.setActivityStatDate(rs
                    .getDate("activity_stat_dt"));

            personCDHPContribution.setActivityIncentiveStatus((rs
                    .getString("activity_incntv_status")));
            personCDHPContribution.setProgramType((rs
                    .getString("program_type")));
            personCDHPContribution.setProgramID(new Integer(rs
                    .getInt("biz_pgm_id")));
            personCDHPContribution.setBusinessProgramTypeCode(new Integer(rs
                    .getInt("biz_pgm_tp_cd")));
            personCDHPContribution.setParticipantCap(new Integer(rs
                    .getInt("particip_cap")));
            personCDHPContribution.setFamilyCap(new Integer(rs
                    .getInt("family_cap")));
            personCDHPContribution.setContributionAmt(new Integer(rs
                    .getInt("amount_achieved")));
            personCDHPContribution.setContributionDate(rs
                    .getDate("contribution_date"));
            personCDHPContribution.setBenefitContractType(rs
                    .getString("benefit_contract_type"));
            personCDHPContribution.setIncentiveOptionID(rs
                    .getInt("incntv_optn_id"));
            personCDHPContribution.setUnitTypeCodeID(rs
                    .getInt("incntv_unit_tp_cd_id"));
            personCDHPContribution.setUnitTypeCode(rs
                    .getString("INCNTV_UNIT_TYPE_CODE"));


            return personCDHPContribution;
        }
    }


    private static final class PersonActivityAchievedHSARowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

            PersonActivityAchievedContribution personCDHPContribution = new PersonActivityAchievedContribution();
            personCDHPContribution.setPersonID(new Integer(rs
                    .getInt("PRSN_ID")));
            personCDHPContribution.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
            personCDHPContribution.setContractNo(new Integer(rs
                    .getInt("CONTRACT_NO")));
            personCDHPContribution.setMemberNo(rs
                    .getString("HP_MEM_ID"));
            personCDHPContribution.setGroupID(new Integer(rs
                    .getInt("GRP_ID")));
            personCDHPContribution.setSubgroupID(new Integer(rs
                    .getInt("SUBGRP_ID")));
            personCDHPContribution.setPackageID(new Integer(rs
                    .getInt("ben_pkg_id")));

            personCDHPContribution.setGroupNo(rs
                    .getString("empl_grp_no"));
            personCDHPContribution.setSiteNo(rs
                    .getString("empl_grp_site_id_no"));
            personCDHPContribution.setPackageSubType(rs
                    .getString("purch_sub_tp_nm"));
            personCDHPContribution.setActivityID(new Integer(rs
                    .getInt("ACTV_ID")));
            personCDHPContribution.setSourceActivityID(rs
                    .getString("SRCE_ACTV_ID"));
            personCDHPContribution.setActivityStatDate(rs
                    .getDate("activity_stat_dt"));

            personCDHPContribution.setActivityIncentiveStatus((rs
                    .getString("activity_incntv_status")));
            personCDHPContribution.setProgramType((rs
                    .getString("program_type")));
            personCDHPContribution.setProgramID(new Integer(rs
                    .getInt("biz_pgm_id")));
            personCDHPContribution.setBusinessProgramTypeCode(new Integer(rs
                    .getInt("biz_pgm_tp_cd")));
            personCDHPContribution.setParticipantCap(new Integer(rs
                    .getInt("particip_cap")));
            personCDHPContribution.setFamilyCap(new Integer(rs
                    .getInt("family_cap")));
            personCDHPContribution.setContributionAmt(new Integer(rs
                    .getInt("amount_achieved")));
            personCDHPContribution.setContributionDate(rs
                    .getDate("contribution_date"));
            personCDHPContribution.setContribTypeCodeID(new Integer(rs
                    .getInt("tier_contrib_id")));
            personCDHPContribution.setBenefitContractType(rs
                    .getString("benefit_contract_type"));
            personCDHPContribution.setIncentiveOptionID(rs
                    .getInt("incntv_optn_id"));
            personCDHPContribution.setUnitTypeCodeID(rs
                    .getInt("incntv_unit_tp_cd_id"));
            personCDHPContribution.setUnitTypeCode(rs
                    .getString("INCNTV_UNIT_TYPE_CODE"));
            personCDHPContribution.setContribGridID(new Integer(rs
                    .getInt("contrib_grid_id")));
            personCDHPContribution.setMemberIncentiveStatID(new Integer(rs
                    .getInt("pgm_mem_incntv_stat_id")));
            personCDHPContribution.setContractIncentiveStatID(new Integer(rs
                    .getInt("cntr_pgm_stat_id")));

            personCDHPContribution.setMemberIncentiveStatID(rs
                    .getInt("pgm_mem_incntv_stat_id"));
            personCDHPContribution.setContractIncentiveStatID(rs
                    .getInt("cntr_pgm_stat_id"));
            personCDHPContribution.setIncentiveStatusActivityDetailID(rs
                    .getInt("inctv_sts_actv_dtl_id"));

            return personCDHPContribution;
        }
    }

    private static final class MemberNoUsingMODSRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

            String memberNo = rs.getString("hp_mem_id");
            return memberNo;
        }
    }

    private static final class PersonActivityAchievedRewardRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

            PersonActivityAchievedReward lPersonActivityAchievedReward = new PersonActivityAchievedReward();
            lPersonActivityAchievedReward.setPersonID(new Integer(rs
                    .getInt("PRSN_ID")));
            lPersonActivityAchievedReward.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
            lPersonActivityAchievedReward.setContractNo(new Integer(rs
                    .getInt("CONTRACT_NO")));
            lPersonActivityAchievedReward.setMemberNo(rs
                    .getString("HP_MEM_ID"));
            lPersonActivityAchievedReward.setGroupID(new Integer(rs
                    .getInt("GRP_ID")));
            lPersonActivityAchievedReward.setSubgroupID(new Integer(rs
                    .getInt("SUBGRP_ID")));

            lPersonActivityAchievedReward.setGroupNo(rs
                    .getString("empl_grp_no"));
            lPersonActivityAchievedReward.setSiteNo(rs
                    .getString("empl_grp_site_id_no"));
            lPersonActivityAchievedReward.setActivityID(new Integer(rs
                    .getInt("ACTV_ID")));
            lPersonActivityAchievedReward.setSourceActivityID(rs
                    .getString("SRCE_ACTV_ID"));
            lPersonActivityAchievedReward.setActivityStatDate(rs
                    .getDate("activity_stat_dt"));

            lPersonActivityAchievedReward.setActivityIncentiveStatus((rs
                    .getString("activity_incntv_status")));
            lPersonActivityAchievedReward.setProgramType((rs
                    .getString("program_type")));
            lPersonActivityAchievedReward.setProgramID(new Integer(rs
                    .getInt("biz_pgm_id")));
            lPersonActivityAchievedReward.setProgramIncentiveOptionID(new Integer(rs
                    .getInt("biz_pgm_incntv_optn_id")));
            lPersonActivityAchievedReward.setBusinessProgramTypeCode(new Integer(rs
                    .getInt("biz_pgm_tp_cd")));
            lPersonActivityAchievedReward.setIncentedStatusTypeCodeID(rs
                    .getInt("incntd_sts_tp_cd_id"));
            lPersonActivityAchievedReward.setParticipantCap(new Integer(rs
                    .getInt("particip_cap")));
            lPersonActivityAchievedReward.setFamilyCap(new Integer(rs
                    .getInt("family_cap")));
            lPersonActivityAchievedReward.setContributionAmt(new Integer(rs
                    .getInt("amount_achieved")));
            lPersonActivityAchievedReward.setContributionDate(rs
                    .getDate("contribution_date"));
            lPersonActivityAchievedReward.setContribTypeCodeID(new Integer(rs
                    .getInt("tier_contrib_id")));
            lPersonActivityAchievedReward.setBenefitContractType(rs
                    .getString("benefit_contract_type"));
            lPersonActivityAchievedReward.setIncentiveOptionID(rs
                    .getInt("incntv_optn_id"));

            return lPersonActivityAchievedReward;
        }
    }

    private static final class MemberPgmActivityIncentiveStatusRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

            PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus = new PersonProgramActivityIncentiveStatus();

            lPersonProgramActivityIncentiveStatus.setProgramID(rs
                    .getInt("BIZ_PGM_ID"));
            lPersonProgramActivityIncentiveStatus.setPersonDemographicsID(rs
                    .getInt("PRSN_DMGRPHCS_ID"));
            lPersonProgramActivityIncentiveStatus.setActivityID(rs
                    .getInt("ACTV_ID"));
            lPersonProgramActivityIncentiveStatus.setActivityStatusCodeID(rs
                    .getInt("ACTV_STAT_CD_ID"));
            lPersonProgramActivityIncentiveStatus.setActivityStatusIncentiveDate(rs
                    .getDate("ACTV_STAT_INCNTV_DT"));
            lPersonProgramActivityIncentiveStatus.setBeneftiContractTypeLuID(rs
                    .getInt("BEN_CONTR_TP_LU_ID"));
            lPersonProgramActivityIncentiveStatus.setProgramIncentiveOptionID(rs
                    .getInt("biz_pgm_incntv_optn_id"));
            lPersonProgramActivityIncentiveStatus.setIncentiveOptionID(rs
                    .getInt("incntv_optn_id"));
            lPersonProgramActivityIncentiveStatus.setContributionAmt(rs
                    .getInt("CONTRIB_AMT"));
            lPersonProgramActivityIncentiveStatus.setGroupNo(rs
                    .getString("empl_grp_no"));
            lPersonProgramActivityIncentiveStatus.setSiteNo(rs
                    .getString("empl_grp_site_id_no"));
            lPersonProgramActivityIncentiveStatus.setMemberNo(rs
                    .getString("hp_mem_id"));
            lPersonProgramActivityIncentiveStatus.setLastName(rs
                    .getString("last_nm"));
            lPersonProgramActivityIncentiveStatus.setFirstName(rs
                    .getString("first_nm"));
            lPersonProgramActivityIncentiveStatus.setSourceActivityID(rs
                    .getString("srce_actv_id"));
            lPersonProgramActivityIncentiveStatus.setActivityName(rs
                    .getString("actv_nm"));
            lPersonProgramActivityIncentiveStatus.setProgramMemberIncentiveStatusID(rs
                    .getInt("pgm_mem_incntv_stat_id"));
            lPersonProgramActivityIncentiveStatus.setInsertDate(rs
                    .getDate("insert_ts"));
            lPersonProgramActivityIncentiveStatus.setPersonProgramActivityStatusID(rs
                    .getInt("prsn_pgm_actv_sts_id"));
            lPersonProgramActivityIncentiveStatus.setProgramEffectiveDate(rs
                    .getDate("eff_dt"));
            lPersonProgramActivityIncentiveStatus.setProgramEndDate(rs
                    .getDate("pgm_end_dt"));
            return lPersonProgramActivityIncentiveStatus;
        }
    }

    private static final class PersonActivityAchievedRewardWithContribGridRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

            PersonActivityAchievedReward lPersonActivityAchievedReward = new PersonActivityAchievedReward();
            lPersonActivityAchievedReward.setPersonID(new Integer(rs
                    .getInt("PRSN_ID")));
            lPersonActivityAchievedReward.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
            lPersonActivityAchievedReward.setContractNo(new Integer(rs
                    .getInt("CONTRACT_NO")));
            lPersonActivityAchievedReward.setMemberNo(rs
                    .getString("HP_MEM_ID"));
            lPersonActivityAchievedReward.setGroupID(new Integer(rs
                    .getInt("GRP_ID")));
            lPersonActivityAchievedReward.setSubgroupID(new Integer(rs
                    .getInt("SUBGRP_ID")));

            lPersonActivityAchievedReward.setGroupNo(rs
                    .getString("empl_grp_no"));
            lPersonActivityAchievedReward.setSiteNo(rs
                    .getString("empl_grp_site_id_no"));
            lPersonActivityAchievedReward.setActivityID(new Integer(rs
                    .getInt("ACTV_ID")));
            lPersonActivityAchievedReward.setSourceActivityID(rs
                    .getString("SRCE_ACTV_ID"));
            lPersonActivityAchievedReward.setActivityStatDate(rs
                    .getDate("activity_stat_dt"));

            lPersonActivityAchievedReward.setActivityIncentiveStatus((rs
                    .getString("activity_incntv_status")));
            lPersonActivityAchievedReward.setProgramType((rs
                    .getString("program_type")));
            lPersonActivityAchievedReward.setProgramID(new Integer(rs
                    .getInt("biz_pgm_id")));
            lPersonActivityAchievedReward.setProgramIncentiveOptionID(new Integer(rs
                    .getInt("biz_pgm_incntv_optn_id")));
            lPersonActivityAchievedReward.setBusinessProgramTypeCode(new Integer(rs
                    .getInt("biz_pgm_tp_cd")));
            lPersonActivityAchievedReward.setIncentedStatusTypeCodeID(rs
                    .getInt("incntd_sts_tp_cd_id"));
            lPersonActivityAchievedReward.setParticipantCap(new Integer(rs
                    .getInt("particip_cap")));
            lPersonActivityAchievedReward.setFamilyCap(new Integer(rs
                    .getInt("family_cap")));
            lPersonActivityAchievedReward.setContributionAmt(new Integer(rs
                    .getInt("amount_achieved")));
            lPersonActivityAchievedReward.setContributionDate(rs
                    .getDate("contribution_date"));
            lPersonActivityAchievedReward.setContribGridID(new Integer(rs
                    .getInt("contrib_grid_id")));
            lPersonActivityAchievedReward.setBenefitContractType(rs
                    .getString("benefit_contract_type"));
            lPersonActivityAchievedReward.setIncentiveOptionID(rs
                    .getInt("incntv_optn_id"));
            lPersonActivityAchievedReward.setContractIncentiveStatID(rs
                    .getInt("cntr_pgm_stat_id"));
            lPersonActivityAchievedReward.setMemberIncentiveStatID(rs
                    .getInt("pgm_mem_incntv_stat_id"));
            lPersonActivityAchievedReward.setContractIncentiveStatID(rs
                    .getInt("cntr_pgm_stat_id"));
            lPersonActivityAchievedReward.setIncentiveStatusActivityDetailID(rs
                    .getInt("inctv_sts_actv_dtl_id"));


            return lPersonActivityAchievedReward;
        }
    }

    private static final class PersonActivityToContribGridReportRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

            PersonActivityToContribGridReport lPersonActivityToContribGridReport = new PersonActivityToContribGridReport();
            lPersonActivityToContribGridReport.setProgramID(rs.getInt("biz_pgm_id"));
            lPersonActivityToContribGridReport.setGroupNumber(rs.getString("empl_grp_no"));
            lPersonActivityToContribGridReport.setSiteNumber(rs.getString("empl_grp_site_id_no"));
            lPersonActivityToContribGridReport.setIncentiveStatusType(rs.getString("incentive_status_type"));
            lPersonActivityToContribGridReport.setIncentiveOptionName(rs.getString("incentive_option_name"));
            lPersonActivityToContribGridReport.setIncentiveRuleTypeDesc(rs.getString("rule_type_desc"));
            lPersonActivityToContribGridReport.setMemberNumber(rs.getString("hp_mem_id"));
            lPersonActivityToContribGridReport.setContractNumber(rs.getInt("contract_no"));
            lPersonActivityToContribGridReport.setRelationshipName(rs.getString("rel_name"));
            lPersonActivityToContribGridReport.setActivityName(rs.getString("actv_nm"));


            return lPersonActivityToContribGridReport;
        }
    }

    /**
     * Update person program status Health Plan Code ID based on the M or J coverage type
     * in the prsn baseline ds table.
     *
     * @param pPersonDemographicsID
     * @param pBusinessProgramID
     * @return
     */
    public List<PersonProgramHealthPlan> getPersonHealthPlanCode(Integer pPersonDemographicsID, Integer pBusinessProgramID, Integer pContractNo)
            throws DataAccessException {


        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectPersonHealthPlanCode);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("personDemographicsID", pPersonDemographicsID, Types.INTEGER);
        namedParameters.addValue("bizPgmId", pBusinessProgramID, Types.INTEGER);
        namedParameters.addValue("contractNo", pContractNo, Types.INTEGER);
        lQuery.append(" AND baseline.contract_no = :contractNo ");

        List<PersonProgramHealthPlan> lPersonProgramHealthPlans = namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public PersonProgramHealthPlan mapRow(ResultSet rs, int i) throws SQLException {
                        PersonProgramHealthPlan lPersonProgramHealthPlan = new PersonProgramHealthPlan();

                        lPersonProgramHealthPlan.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
                        lPersonProgramHealthPlan.setBusinessProgramID(rs.getInt("BIZ_PGM_ID"));
                        lPersonProgramHealthPlan.setHealthPlanCode(rs.getString("PROD_TP_CD"));
                        return lPersonProgramHealthPlan;
                    }


                });

        return lPersonProgramHealthPlans;
    }

    public List<PersonProgramHealthPlan> getPersonHealthPlanCodeByRelationship(Integer pPersonDemographicsID, Integer pBusinessProgramID, Integer pRelationshipID)
            throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectPersonHealthPlanCode);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("personDemographicsID", pPersonDemographicsID, Types.INTEGER);
        namedParameters.addValue("bizPgmId", pBusinessProgramID, Types.INTEGER);
        namedParameters.addValue("relationId", pRelationshipID, Types.INTEGER);
        lQuery.append(" AND baseline.REL_CD = :relationId ");


        List<PersonProgramHealthPlan> lPersonProgramHealthPlans = namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public Object mapRow(ResultSet rs, int i) throws SQLException {
                        PersonProgramHealthPlan lPersonProgramHealthPlan = new PersonProgramHealthPlan();

                        lPersonProgramHealthPlan.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
                        lPersonProgramHealthPlan.setBusinessProgramID(rs.getInt("BIZ_PGM_ID"));
                        lPersonProgramHealthPlan.setHealthPlanCode(rs.getString("PROD_TP_CD"));
                        return lPersonProgramHealthPlan;
                    }

                });

        return lPersonProgramHealthPlans;
    }


    /**
     * Get person activity incentives that are not matching up to the program contribution grid.  In addition,
     * get the contract incentives of activities that do not match up to the program contribution grid.
     *
     * @param fulfillmentRoutingTypeCode
     * @return
     */
    public List<PersonActivityToContribGridReport> getPersonActivityToContribGridReport(String fulfillmentRoutingTypeCode)
            throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectPersonActivityToContribGrid);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("luVal", fulfillmentRoutingTypeCode, Types.VARCHAR);




        List<PersonActivityToContribGridReport> results = namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters, new PersonActivityToContribGridReportRowMapper());

        return results;
    }

    /**
     * get the contract incentives of activities that do not match up to the program contribution grid.
     *
     * @param fulfillmentRoutingTypeCode
     * @return
     */
    public List<PersonActivityToContribGridReport> getPersonContractActivityToContribGridReport(String fulfillmentRoutingTypeCode)
            throws DataAccessException {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectPersonContractActivityToContribGrid);

        MapSqlParameterSource namedParameter = new MapSqlParameterSource();
        namedParameter.addValue("luVal", fulfillmentRoutingTypeCode, Types.VARCHAR);

        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);


        List<PersonActivityToContribGridReport> results = namedParameterJdbcTemplate.query(lQuery.toString(),
                namedParameters, new PersonActivityToContribGridReportRowMapper());


        return results;
    }

    /*
     * Determine if person activity has already been fulfilled.  If activity has not been fulfilled, a new record
     * will be allowed which is called from the service method.
     */
    public boolean isContractIncentedForActivity(
            Integer programID, Integer contractNumber) throws DataAccessException {

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("bizPgmId", programID, Types.INTEGER);
        namedParameters.addValue("contractNo", contractNumber, Types.VARCHAR);

        List<Boolean> results =  namedParameterJdbcTemplate.query(isContractIncentedForActivity, namedParameters,
                new RowMapper() {
                    @Override
                    public Boolean mapRow(ResultSet rs, int i) throws SQLException {
                        if (rs.getInt(1) > 0) {
                           return Boolean.valueOf(true);
                        }
                        return Boolean.valueOf(false);
                    }
                });


        return results.size() > 0;
    }


    /**
     * @param pPersonDemographicsID
     * @param pBusinessProgramID
     * @param pHealthPlanCode
     * @return
     */
    public int updatePersonHealthPlanCode(Integer pPersonDemographicsID
            , Integer pBusinessProgramID
            , Integer pProgramIncentiveOptionID
            , Integer pRelationshipID
            , String pHealthPlanCode)
            throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();

        Object params[] = new Object[]{pHealthPlanCode, pPersonDemographicsID, pBusinessProgramID, pProgramIncentiveOptionID, pRelationshipID};
        int types[] = new int[]{Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER};

        int rowsInserted = template.update(updatePersonHealthPlanCode, params, types);

        for (int i = 0; i < params.length; i++) {
            params[i] = null;
        }
        types = null;

        return rowsInserted;
    }

    /**
     * @param pPersonDemographicsID
     * @param pProgramID
     * @return
     */
    public Collection<PersonPackage> getPersonPackages(Integer pPersonDemographicsID, Integer pProgramID)
            throws DataAccessException {
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectPersonPackages);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("pPersonDemographicsID", pPersonDemographicsID, Types.INTEGER);
        namedParameters.addValue("bizPgmId", pProgramID, Types.INTEGER);


        List<PersonPackage> lPersonPackages =  namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public PersonPackage mapRow(ResultSet rs, int i) throws SQLException {
                        PersonPackage lPersonPackage = new PersonPackage();

                        lPersonPackage.setPersonDemographicsID(rs.getInt("prsn_dmgrphcs_id"));
                        lPersonPackage.setProgramID(rs.getInt("BIZ_PGM_ID"));
                        lPersonPackage.setPackageID(rs.getInt("BEN_PKG_ID"));
                        lPersonPackage.setPackageName(rs.getString("BEN_PKG_NM"));
                        lPersonPackage.setPackageCode(rs.getString("BEN_PKG_CD"));
                        lPersonPackage.setPackageType(rs.getString("BEN_PKG_TP"));
                        lPersonPackage.setPackageSubTypeName(rs.getString("PURCH_SUB_TP_NM"));
                        lPersonPackage.setPackageEffectiveDate(rs.getDate("EFF_DT"));
                        lPersonPackage.setPackageEndDate(rs.getDate("END_DT"));
                        lPersonPackage.setContractNo(rs.getInt("contract_no"));

                        return lPersonPackage;
                    }


                });

        return lPersonPackages;
    }

    /**
     * @param pPersonDemographicsID
     * @param pProgramID
     * @return
     */
    public Collection<PersonPackage> getPersonPackagesRetroTerms(Integer pPersonDemographicsID, Integer pProgramID)
            throws DataAccessException {
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectPersonPackagesRetroTerms);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("pPersonDemographicsID", pPersonDemographicsID, Types.INTEGER);
        namedParameters.addValue("bizPgm", pProgramID, Types.INTEGER);


        List<PersonPackage> lPersonPackages = namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public PersonPackage mapRow(ResultSet rs, int i) throws SQLException {
                        PersonPackage lPersonPackage = new PersonPackage();

                        lPersonPackage.setPersonDemographicsID(rs.getInt("prsn_dmgrphcs_id"));
                        lPersonPackage.setProgramID(rs.getInt("BIZ_PGM_ID"));
                        lPersonPackage.setPackageID(rs.getInt("BEN_PKG_ID"));
                        lPersonPackage.setPackageName(rs.getString("BEN_PKG_NM"));
                        lPersonPackage.setPackageCode(rs.getString("BEN_PKG_CD"));
                        lPersonPackage.setPackageType(rs.getString("BEN_PKG_TP"));
                        lPersonPackage.setPackageSubTypeName(rs.getString("PURCH_SUB_TP_NM"));
                        lPersonPackage.setPackageEffectiveDate(rs.getDate("EFF_DT"));
                        lPersonPackage.setPackageEndDate(rs.getDate("END_DT"));
                        return lPersonPackage;

                    }
                });

        return lPersonPackages;
    }

    public Collection<String> getMemberIDFromPersonDetails(String firstName, String middleInitial,
                                                           String lastName, String gender, java.sql.Date dateOfBirth)
            throws DataAccessException {

        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();

        JdbcTemplate template = getJdbcTemplate();
        StringBuffer lQuery = new StringBuffer();

        lQuery.append(selectMemberIDFromPersonDetails);

        MapSqlParameterSource namedParameters = new MapSqlParameterSource();

        if (firstName != null && firstName.trim().length() > 0) {
            namedParameters.addValue("firstName", firstName, Types.VARCHAR);
            lQuery.append(" AND upper(first_nm) = upper(:firstName)");
        }

        if (middleInitial != null && middleInitial.trim().length() > 0) {
            namedParameters.addValue("middleInitial", middleInitial, Types.VARCHAR);
            lQuery.append(" AND upper(middle_nm) = upper(:middleInitial)");
        }

        if (lastName != null && lastName.trim().length() > 0) {
            namedParameters.addValue("lastName", lastName, Types.VARCHAR);
            lQuery.append(" AND upper(last_nm) like upper('");
            lQuery.append(":lastName");
            lQuery.append("%')");
        }

        if (gender != null && gender.trim().length() > 0) {
            namedParameters.addValue("gender", gender, Types.VARCHAR);
            lQuery.append(" and upper(GENDER_CD) = upper(:gender)");
        }

        if (dateOfBirth != null) {
            namedParameters.addValue("dateOfBirth", dateOfBirth, Types.VARCHAR);
            lQuery.append(" AND trunc(dob_dt) = trunc(:dateOfBirth)");
        }

        lQuery.append(" ORDER BY last_nm, first_nm, middle_nm ");


        List<String> results = namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public String mapRow(ResultSet rs, int i) throws SQLException {
                        return rs.getString(1);
                    }

                });

        return results;
    }

    public boolean validateParticipatingMember(String memberID) throws DataAccessException {


        MapSqlParameterSource namedParameters = new MapSqlParameterSource();
        namedParameters.addValue("memberId", memberID, Types.VARCHAR);


       List<String> results =  namedParameterJdbcTemplate.query(determineIfMemberIsParticipating, namedParameters,
                new RowMapper() {
                    @Override
                    public String mapRow(ResultSet rs, int i) throws SQLException {
                        return rs.getString("hp_mem_id");
                    }

                });

        boolean isParticipating = false;
        if (results.size() > 0) {
            isParticipating = true;

        }

        return isParticipating;

    }


    /**
     * @param pPersonDemographicsID
     * @param pBusinessProgramID
     * @param pProgramIncentiveOptionID
     * @param pQualificationCheckmarkID
     * @return
     * @throws DataAccessException
     */
    public int updatePersonQualificationCheckmark(Integer pPersonDemographicsID
            , Integer pBusinessProgramID
            , Integer pProgramIncentiveOptionID
            , Integer pQualificationCheckmarkID)
            throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();

        Object params[] = new Object[]{pQualificationCheckmarkID, pPersonDemographicsID, pBusinessProgramID, pProgramIncentiveOptionID};
        int types[] = new int[]{Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER};

        int rowsInserted = template.update(updatePersonQualificationCheckmark, params, types);

        for (int i = 0; i < params.length; i++) {
            params[i] = null;
        }
        types = null;

        return rowsInserted;
    }

    private Collection<PersonActivityAchievedReward> evaluateDependentToPolicyHolderForContractBasedRewardCards
            (Collection<PersonActivityAchievedReward> contractRewardContributionsWithContribGrid) {
        HashMap nameOfPHMap = new HashMap();
        ContractPolicyHolderInfo contractPolicyHolderInfo = null;

        Iterator<PersonActivityAchievedReward> iter = contractRewardContributionsWithContribGrid.iterator();

        while (iter.hasNext()) {
            PersonActivityAchievedReward lPersonActivityAchievedReward = (PersonActivityAchievedReward) iter.next();
            Integer contractNo = lPersonActivityAchievedReward.getContractNo();
            if (nameOfPHMap.containsKey(contractNo)) {
                contractPolicyHolderInfo = (ContractPolicyHolderInfo) nameOfPHMap.get(contractNo);
            } else {
                contractPolicyHolderInfo = contractDAO.getNameOfPHByContract(lPersonActivityAchievedReward.getContractNo());
                nameOfPHMap.put(contractNo, contractPolicyHolderInfo);
            }
            //determine if transaction already represents policy holder.  If not replace dependent with policy holder.
            //The policy holder is what needs to be represented on the reward card.
            if (!lPersonActivityAchievedReward.getPersonDemographicsID().equals(contractPolicyHolderInfo.getPersonDemographicsID())) {
                lPersonActivityAchievedReward.setPersonDemographicsID(contractPolicyHolderInfo.getPersonDemographicsID());
                lPersonActivityAchievedReward.setPersonID(contractPolicyHolderInfo.getPersonID());
                lPersonActivityAchievedReward.setFirstName(contractPolicyHolderInfo.getFirstName());
                lPersonActivityAchievedReward.setLastName(contractPolicyHolderInfo.getLastName());
                lPersonActivityAchievedReward.setMiddleName(contractPolicyHolderInfo.getMiddleName());
                lPersonActivityAchievedReward.setMemberNo(contractPolicyHolderInfo.getMemberNo());
            }
            ;
        }

        return contractRewardContributionsWithContribGrid;
    }

    public String getSelectMemberContractStatus() {
        return selectMemberContractStatus;
    }

    public void setSelectMemberContractStatus(String selectMemberContractStatus) {
        this.selectMemberContractStatus = selectMemberContractStatus;
    }

    public String getCountMemberProgramStatusRows() {
        return countMemberProgramStatusRows;
    }

    public String getGetMemberProgramStatus() {
        return getMemberProgramStatus;
    }

    public String getInsertMemberProgramStatus() {
        return insertMemberProgramStatus;
    }

    public String getUpdateMemberProgramStatus() {
        return updateMemberProgramStatus;
    }

    public String getSelectOffHoldForContact() {
        return selectOffHoldForContact;
    }

    public void setSelectOffHoldForContact(String selectOffHoldForContact) {
        this.selectOffHoldForContact = selectOffHoldForContact;
    }

    public String getGetMemberIDFromPersonID() {
        return getMemberIDFromPersonID;
    }

    public void setGetMemberIDFromPersonID(String getMemberIDFromPersonID) {
        this.getMemberIDFromPersonID = getMemberIDFromPersonID;
    }


    public String getGetPersonIDFromPersonDemographicsID() {
        return getPersonIDFromPersonDemographicsID;
    }

    public void setGetPersonIDFromPersonDemographicsID(String getPersonIDFromPersonDemographicsID) {
        this.getPersonIDFromPersonDemographicsID = getPersonIDFromPersonDemographicsID;
    }

    public String getGetPersonIDFromMemberID() {
        return getPersonIDFromMemberID;
    }

    public void setGetPersonIDFromMemberID(String getPersonIDFromMemberID) {
        this.getPersonIDFromMemberID = getPersonIDFromMemberID;
    }

    public String getSelectNightlyUpdateMembers() {
        return selectNightlyUpdateMembers;
    }

    public void setSelectNightlyUpdateMembers(String selectNightlyUpdateMembers) {
        this.selectNightlyUpdateMembers = selectNightlyUpdateMembers;
    }

    public String getDeleteMemberProgramStatus() {
        return deleteMemberProgramStatus;
    }

    public void setDeleteMemberProgramStatus(String deleteMemberProgramStatus) {
        this.deleteMemberProgramStatus = deleteMemberProgramStatus;
    }

    public String getSelectUpdatedParticipant() {
        return selectUpdatedParticipant;
    }

    public void setSelectUpdatedParticipant(String selectUpdatedParticipant) {
        this.selectUpdatedParticipant = selectUpdatedParticipant;
    }

    public String getSelectMembershipStatusUpdateFeed() {
        return selectMembershipStatusUpdateFeed;
    }

    public void setSelectMembershipStatusUpdateFeed(
            String selectMembershipStatusUpdateFeed) {
        this.selectMembershipStatusUpdateFeed = selectMembershipStatusUpdateFeed;
    }


    public void setSelectPersonProgramActivityStatusAchieved(
            String selectPersonProgramActivityStatusAchieved) {
        this.selectPersonProgramActivityStatusAchieved = selectPersonProgramActivityStatusAchieved;
    }

    public final String getEndMemberParticipation() {
        return endMemberParticipation;
    }

    public final void setEndMemberParticipation(String endMemberParticipation) {
        this.endMemberParticipation = endMemberParticipation;
    }

    public final String getSelectWhichEndDate() {
        return selectWhichEndDate;
    }

    public final void setSelectWhichEndDate(String selectWhichEndDate) {
        this.selectWhichEndDate = selectWhichEndDate;
    }

    public void setSelectPersonContractsHist(String selectPersonContractsHist) {
        this.selectPersonContractsHist = selectPersonContractsHist;
    }


    public void setSelectPersonContractsHistForArchive(String selectPersonContractsHistForArchive) {
        this.selectPersonContractsHistForArchive = selectPersonContractsHistForArchive;
    }

    public void setSelectPersonContractsRecycle(String selectPersonContractsRecycle) {
        this.selectPersonContractsRecycle = selectPersonContractsRecycle;
    }

    public void setSelectPersonContractsRecycleForStatus(
            String selectPersonContractsRecycleForStatus) {
        this.selectPersonContractsRecycleForStatus = selectPersonContractsRecycleForStatus;
    }


    public void setSelectPersonContractHistForPersonMax(String selectPersonContractHistForPersonMax) {
        this.selectPersonContractHistForPersonMax = selectPersonContractHistForPersonMax;
    }

    public void setSelectPersonContractHistForContractStatus(String selectPersonContractHistForContractStatus) {
        this.selectPersonContractHistForContractStatus = selectPersonContractHistForContractStatus;
    }


    public void setInsertPersonContractHist(String insertPersonContractHist) {
        this.insertPersonContractHist = insertPersonContractHist;
    }


    public void setInsertPersonContractHistArchive(String insertPersonContractHistArchive) {
        this.insertPersonContractHistArchive = insertPersonContractHistArchive;
    }

    public void setInsertPersonContractRecycle(String insertPersonContractRecycle) {
        this.insertPersonContractRecycle = insertPersonContractRecycle;
    }


    public void setInsertPersonContractRecyclePerTollgateRules(String insertPersonContractRecyclePerTollgateRules) {
        this.insertPersonContractRecyclePerTollgateRules = insertPersonContractRecyclePerTollgateRules;
    }

    public void setUpdatePersonContractRecycleStatus(
            String updatePersonContractRecycleStatus) {
        this.updatePersonContractRecycleStatus = updatePersonContractRecycleStatus;
    }

    public void setCountPersonContractHistRows(String countPersonContractHistRows) {
        this.countPersonContractHistRows = countPersonContractHistRows;
    }

    public void setCountPersonContractRecycleRows(
            String countPersonContractRecycleRows) {
        this.countPersonContractRecycleRows = countPersonContractRecycleRows;
    }


    public void setDeletePersonContractsHist(String deletePersonContractsHist) {
        this.deletePersonContractsHist = deletePersonContractsHist;
    }

    public void setDeletePersonContractsRecycle(String deletePersonContractsRecycle) {
        this.deletePersonContractsRecycle = deletePersonContractsRecycle;
    }

    public void setPersonContractHistIdIncrementer(
            DataFieldMaxValueIncrementer personContractHistIdIncrementer) {
        this.personContractHistIdIncrementer = personContractHistIdIncrementer;
    }


    public void setPersonContractHistArchiveIdIncrementer(
            DataFieldMaxValueIncrementer personContractHistArchiveIdIncrementer) {
        this.personContractHistArchiveIdIncrementer = personContractHistArchiveIdIncrementer;
    }

    public void setCdhpTransIdIncrementer(
            DataFieldMaxValueIncrementer cdhpTransIdIncrementer) {
        this.cdhpTransIdIncrementer = cdhpTransIdIncrementer;
    }


    public void setRewardTransIdIncrementer(
            DataFieldMaxValueIncrementer rewardTransIdIncrementer) {
        this.rewardTransIdIncrementer = rewardTransIdIncrementer;
    }

    public void setPersonContractRecycleIdIncrementer(
            DataFieldMaxValueIncrementer personContractRecycleIdIncrementer) {
        this.personContractRecycleIdIncrementer = personContractRecycleIdIncrementer;
    }

    public void setSelectPersonContractRecycleForPerson(
            String selectPersonContractRecycleForPerson) {
        this.selectPersonContractRecycleForPerson = selectPersonContractRecycleForPerson;
    }

    public void setUpdateMemberProgramStatusContractStatusDate(
            String updateMemberProgramStatusContractStatusDate) {
        this.updateMemberProgramStatusContractStatusDate = updateMemberProgramStatusContractStatusDate;
    }


    public void setUpdateMemberProgramStatusExternalPersonID(
            String updateMemberProgramStatusExternalPersonID) {
        this.updateMemberProgramStatusExternalPersonID = updateMemberProgramStatusExternalPersonID;
    }


    public void setInsertPersonProgramStatus18YearOldsForIncentiveOptionByProgramTypeContract(
            String insertPersonProgramStatus18YearOldsForIncentiveOptionByProgramTypeContract) {
        this.insertPersonProgramStatus18YearOldsForIncentiveOptionByProgramTypeContract = insertPersonProgramStatus18YearOldsForIncentiveOptionByProgramTypeContract;
    }

    public void setInsertPersonProgramStatus18YearOldsForIncentiveOptionByProgramType(
            String insertPersonProgramStatus18YearOldsForIncentiveOptionByProgramType) {
        this.insertPersonProgramStatus18YearOldsForIncentiveOptionByProgramType = insertPersonProgramStatus18YearOldsForIncentiveOptionByProgramType;
    }

    public final String getEndContractParticipation() {
        return endContractParticipation;
    }

    public final void setEndContractParticipation(String endContractParticipation) {
        this.endContractParticipation = endContractParticipation;
    }

    public final String getSelectIfContractEndDate() {
        return selectIfContractEndDate;
    }

    public final void setSelectIfContractEndDate(String selectIfContractEndDate) {
        this.selectIfContractEndDate = selectIfContractEndDate;
    }

    public String getUpdatePersonContractRecycleStatusWithReasonDesc() {
        return updatePersonContractRecycleStatusWithReasonDesc;
    }

    public void setUpdatePersonContractRecycleStatusWithReasonDesc(
            String updatePersonContractRecycleStatusWithReasonDesc) {
        this.updatePersonContractRecycleStatusWithReasonDesc = updatePersonContractRecycleStatusWithReasonDesc;
    }

    public String getSelectPersonContractRecycleOnHolds() {
        return selectPersonContractRecycleOnHolds;
    }

    public void setSelectPersonContractRecycleOnHolds(
            String selectPersonContractRecycleOnHolds) {
        this.selectPersonContractRecycleOnHolds = selectPersonContractRecycleOnHolds;
    }


    public String getSelectPersonContractRecycleByRecycleStatus() {
        return selectPersonContractRecycleByRecycleStatus;
    }

    public void setSelectPersonContractRecycleByRecycleStatus(String selectPersonContractRecycleByRecycleStatus) {
        this.selectPersonContractRecycleByRecycleStatus = selectPersonContractRecycleByRecycleStatus;
    }

    public final String getSelectFirstContractStatusDate() {
        return selectFirstContractStatusDate;
    }

    public final void setSelectFirstContractStatusDate(
            String selectFirstContractStatusDate) {
        this.selectFirstContractStatusDate = selectFirstContractStatusDate;
    }


    public String getInsertProcessingStatusLogForPastContractEndDates() {
        return insertProcessingStatusLogForPastContractEndDates;
    }

    public void setInsertProcessingStatusLogForPastContractEndDates(
            String insertProcessingStatusLogForPastContractEndDates) {
        this.insertProcessingStatusLogForPastContractEndDates = insertProcessingStatusLogForPastContractEndDates;
    }

    public String getSelectPersonContractHistoryReconciled() {
        return selectPersonContractHistoryReconciled;
    }

    public void setSelectPersonContractHistoryReconciled(
            String selectPersonContractHistoryReconciled) {
        this.selectPersonContractHistoryReconciled = selectPersonContractHistoryReconciled;
    }


    public void setSelectPersonActivityIncentToFulfillReconciled(
            String selectPersonActivityIncentToFulfillReconciled) {
        this.selectPersonActivityIncentToFulfillReconciled = selectPersonActivityIncentToFulfillReconciled;
    }


    public void setSelectMemberActivityIncentToFulfillReconciled(
            String selectMemberActivityIncentToFulfillReconciled) {
        this.selectMemberActivityIncentToFulfillReconciled = selectMemberActivityIncentToFulfillReconciled;
    }

    public void setInsertEmployerFulfillmentMemberActivityCompletions(
            String insertEmployerFulfillmentMemberActivityCompletions) {
        this.insertEmployerFulfillmentMemberActivityCompletions = insertEmployerFulfillmentMemberActivityCompletions;
    }

    public void setSelectEmployerFulfillmentMemberActivityCompletions(
            String selectEmployerFulfillmentMemberActivityCompletions) {
        this.selectEmployerFulfillmentMemberActivityCompletions = selectEmployerFulfillmentMemberActivityCompletions;
    }


    public void setInsertPersonActivityFulfillmentHistory(
            String insertPersonActivityFulfillmentHistory) {
        this.insertPersonActivityFulfillmentHistory = insertPersonActivityFulfillmentHistory;
    }

    public void setUpdateMemberProgramStatusPartEndDate(
            String updateMemberProgramStatusPartEndDate) {
        this.updateMemberProgramStatusPartEndDate = updateMemberProgramStatusPartEndDate;
    }

    public void setSelectMemberProgramStatusDetail(
            String selectMemberProgramStatusDetail) {
        this.selectMemberProgramStatusDetail = selectMemberProgramStatusDetail;
    }


    public void setInsertCDHPCompletion(String insertCDHPCompletion) {
        this.insertCDHPCompletion = insertCDHPCompletion;
    }


    public void setInsertCDHPCompletionHistory(String insertCDHPCompletionHistory) {
        this.insertCDHPCompletionHistory = insertCDHPCompletionHistory;
    }


    public void setCdhpRecycleIdIncrementer(
            DataFieldMaxValueIncrementer cdhpRecycleIdIncrementer) {
        this.cdhpRecycleIdIncrementer = cdhpRecycleIdIncrementer;
    }


    public void setSelectPersonPgmActivityIncentiveStatus(
            String selectPersonPgmActivityIncentiveStatus) {
        this.selectPersonPgmActivityIncentiveStatus = selectPersonPgmActivityIncentiveStatus;
    }


    public void setSelectPersonPgmActivityIncentiveStatusEnhanced(
            String selectPersonPgmActivityIncentiveStatusEnhanced) {
        this.selectPersonPgmActivityIncentiveStatusEnhanced = selectPersonPgmActivityIncentiveStatusEnhanced;
    }


    public void setSelectMemberPgmActivityIncentiveStatusEnhanced(
            String selectMemberPgmActivityIncentiveStatusEnhanced) {
        this.selectMemberPgmActivityIncentiveStatusEnhanced = selectMemberPgmActivityIncentiveStatusEnhanced;
    }


    public void setSelectPersonsEligibleBeyondQualificationPeriod(String selectPersonsEligibleBeyondQualificationPeriod) {
        this.selectPersonsEligibleBeyondQualificationPeriod = selectPersonsEligibleBeyondQualificationPeriod;
    }

    public void setSelectHRAPersonActivityAchievedContribution(
            String selectHRAPersonActivityAchievedContribution) {
        this.selectHRAPersonActivityAchievedContribution = selectHRAPersonActivityAchievedContribution;
    }

    public void setSelectHSAPersonActivityAchievedContribution(
            String selectHSAPersonActivityAchievedContribution) {
        this.selectHSAPersonActivityAchievedContribution = selectHSAPersonActivityAchievedContribution;
    }


    public void setSelectHRAContractActivityAchievedContribution(
            String selectHRAContractActivityAchievedContribution) {
        this.selectHRAContractActivityAchievedContribution = selectHRAContractActivityAchievedContribution;
    }

    public void setSelectHRAMemberActivityAchievedContribution(
            String selectHRAMemberActivityAchievedContribution) {
        this.selectHRAMemberActivityAchievedContribution = selectHRAMemberActivityAchievedContribution;
    }


    public void setSelectHRAContractActivityAchievedContributionWithContribGrid(
            String selectHRAContractActivityAchievedContributionWithContribGrid) {
        this.selectHRAContractActivityAchievedContributionWithContribGrid = selectHRAContractActivityAchievedContributionWithContribGrid;
    }

    public void setSelectHRAMemberActivityAchievedContributionWithContribGrid(
            String selectHRAMemberActivityAchievedContributionWithContribGrid) {
        this.selectHRAMemberActivityAchievedContributionWithContribGrid = selectHRAMemberActivityAchievedContributionWithContribGrid;
    }

    public void setSelectHSAContractActivityAchievedContribution(
            String selectHSAContractActivityAchievedContribution) {
        this.selectHSAContractActivityAchievedContribution = selectHSAContractActivityAchievedContribution;
    }


    public void setSelectHSAContractActivityAchievedContributionWithContribGrid(
            String selectHSAContractActivityAchievedContributionWithContribGrid) {
        this.selectHSAContractActivityAchievedContributionWithContribGrid = selectHSAContractActivityAchievedContributionWithContribGrid;
    }

    public void setSelectHSAMemberActivityAchievedContribution(
            String selectHSAMemberActivityAchievedContribution) {
        this.selectHSAMemberActivityAchievedContribution = selectHSAMemberActivityAchievedContribution;
    }


    public void setSelectHSAMemberActivityAchievedContributionWithContribGrid(
            String selectHSAMemberActivityAchievedContributionWithContribGrid) {
        this.selectHSAMemberActivityAchievedContributionWithContribGrid = selectHSAMemberActivityAchievedContributionWithContribGrid;
    }

    public void setSelectCDHPFulfillmentTrackingReportHist(
            String selectCDHPFulfillmentTrackingReportHist) {
        this.selectCDHPFulfillmentTrackingReportHist = selectCDHPFulfillmentTrackingReportHist;
    }


    public void setSelectCDHPFulfillmentTrackingReportHistByGroup(
            String selectCDHPFulfillmentTrackingReportHistByGroup) {
        this.selectCDHPFulfillmentTrackingReportHistByGroup = selectCDHPFulfillmentTrackingReportHistByGroup;
    }

    public void setSelectEmployerSponsoredPersonActivityAchievedContribution(
            String selectEmployerSponsoredPersonActivityAchievedContribution) {
        this.selectEmployerSponsoredPersonActivityAchievedContribution = selectEmployerSponsoredPersonActivityAchievedContribution;
    }


    public void setSelectEmployerSponsoredPersonActivityAchievedContributionRecycleApprovals(
            String selectEmployerSponsoredPersonActivityAchievedContributionRecycleApprovals) {
        this.selectEmployerSponsoredPersonActivityAchievedContributionRecycleApprovals = selectEmployerSponsoredPersonActivityAchievedContributionRecycleApprovals;
    }

    public void setSelectPersonCDHPContributionAlreadySent(
            String selectPersonCDHPContributionAlreadySent) {
        this.selectPersonCDHPContributionAlreadySent = selectPersonCDHPContributionAlreadySent;
    }

    public void setSelectCDHPRecycleForPerson(String selectCDHPRecycleForPerson) {
        this.selectCDHPRecycleForPerson = selectCDHPRecycleForPerson;
    }

    public void setUpdateCDHPFulfillRecycleStatus(
            String updateCDHPFulfillRecycleStatus) {
        this.updateCDHPFulfillRecycleStatus = updateCDHPFulfillRecycleStatus;
    }

    public void setInsertCDHPFulfillRecycle(String insertCDHPFulfillRecycle) {
        this.insertCDHPFulfillRecycle = insertCDHPFulfillRecycle;
    }

    public void setSelectPersonContributions(String selectPersonContributions) {
        this.selectPersonContributions = selectPersonContributions;
    }

    public void setSelectUnresolvedPersonPgmActivityIncentiveStatus(
            String selectUnresolvedPersonPgmActivityIncentiveStatus) {
        this.selectUnresolvedPersonPgmActivityIncentiveStatus = selectUnresolvedPersonPgmActivityIncentiveStatus;
    }

    public void setSelectPersonSocialSecurityNo(String selectPersonSocialSecurityNo) {
        this.selectPersonSocialSecurityNo = selectPersonSocialSecurityNo;
    }


    public void setSelectMemberNoUsingMODS(String selectMemberNoUsingMODS) {
        this.selectMemberNoUsingMODS = selectMemberNoUsingMODS;
    }

    public String getSelectPersonHealthPlanCode() {
        return selectPersonHealthPlanCode;
    }

    public void setSelectPersonHealthPlanCode(String selectPersonHealthPlanCode) {
        this.selectPersonHealthPlanCode = selectPersonHealthPlanCode;
    }

    public String getUpdatePersonHealthPlanCode() {
        return updatePersonHealthPlanCode;
    }

    public void setUpdatePersonHealthPlanCode(String updatePersonHealthPlanCode) {
        this.updatePersonHealthPlanCode = updatePersonHealthPlanCode;
    }

    public void setSelectPersonPgmActivityIncentives(
            String selectPersonPgmActivityIncentives) {
        this.selectPersonPgmActivityIncentives = selectPersonPgmActivityIncentives;
    }


    public void setSelectPersonActivityAchievedReward(
            String selectPersonActivityAchievedReward) {
        this.selectPersonActivityAchievedReward = selectPersonActivityAchievedReward;
    }

    public String getSelectPersonRewardAlreadySent() {
        return selectPersonRewardAlreadySent;
    }

    public void setSelectPersonRewardAlreadySent(
            String selectPersonRewardAlreadySent) {
        this.selectPersonRewardAlreadySent = selectPersonRewardAlreadySent;
    }

    public void setSelectRewardFulfillmentTrackingReportHistByProgram(
            String selectRewardFulfillmentTrackingReportHistByProgram) {
        this.selectRewardFulfillmentTrackingReportHistByProgram = selectRewardFulfillmentTrackingReportHistByProgram;
    }

    public void setInsertRewardFulfillHistory(String insertRewardFulfillHistory) {
        this.insertRewardFulfillHistory = insertRewardFulfillHistory;
    }

    public String getInsertRewardCompletionHistory() {
        return insertRewardCompletionHistory;
    }

    public void setInsertRewardCompletionHistory(
            String insertRewardCompletionHistory) {
        this.insertRewardCompletionHistory = insertRewardCompletionHistory;
    }


    public void setUpdateRewardFulfillRptTrackHist(
            String updateRewardFulfillRptTrackHist) {
        this.updateRewardFulfillRptTrackHist = updateRewardFulfillRptTrackHist;
    }

    public void setInsertRewardFulfillmentStatus(
            String insertRewardFulfillmentStatus) {
        this.insertRewardFulfillmentStatus = insertRewardFulfillmentStatus;
    }

    public void setRewardStatusTransIdIncrementer(
            DataFieldMaxValueIncrementer rewardStatusTransIdIncrementer) {
        this.rewardStatusTransIdIncrementer = rewardStatusTransIdIncrementer;
    }

    public String getUpdateRewardFulfillmentStatus() {
        return updateRewardFulfillmentStatus;
    }

    public void setUpdateRewardFulfillmentStatus(
            String updateRewardFulfillmentStatus) {
        this.updateRewardFulfillmentStatus = updateRewardFulfillmentStatus;
    }

    public String getUpdateRewardFulfillHistoryStatus() {
        return updateRewardFulfillHistoryStatus;
    }

    public void setUpdateRewardFulfillHistoryStatus(
            String updateRewardFulfillHistoryStatus) {
        this.updateRewardFulfillHistoryStatus = updateRewardFulfillHistoryStatus;
    }

    public void setSelectProgramByRewardFulfillTransHistID(
            String selectProgramByRewardFulfillTransHistID) {
        this.selectProgramByRewardFulfillTransHistID = selectProgramByRewardFulfillTransHistID;
    }

    public String getUpdateRewardFulfillmentHistWTodaysDate() {
        return updateRewardFulfillmentHistWTodaysDate;
    }

    public void setUpdateRewardFulfillmentHistWTodaysDate(
            String updateRewardFulfillmentHistWTodaysDate) {
        this.updateRewardFulfillmentHistWTodaysDate = updateRewardFulfillmentHistWTodaysDate;
    }

    public String getSelectPersonPackages() {
        return selectPersonPackages;
    }

    public void setSelectPersonPackages(String selectPersonPackages) {
        this.selectPersonPackages = selectPersonPackages;
    }


    public void setSelectPersonPackagesRetroTerms(
            String selectPersonPackagesRetroTerms) {
        this.selectPersonPackagesRetroTerms = selectPersonPackagesRetroTerms;
    }

    public void setUpdateRewardFulfillmentHistWOrderNumber(
            String updateRewardFulfillmentHistWOrderNumber) {
        this.updateRewardFulfillmentHistWOrderNumber = updateRewardFulfillmentHistWOrderNumber;
    }

    public void setMatchIncomingOrderNoToFulfillOrderNo(
            String matchIncomingOrderNoToFulfillOrderNo) {
        this.matchIncomingOrderNoToFulfillOrderNo = matchIncomingOrderNoToFulfillOrderNo;
    }


    public void setMatchIncomingManualOrderToRewardFulfillHist(
            String matchIncomingManualOrderToRewardFulfillHist) {
        this.matchIncomingManualOrderToRewardFulfillHist = matchIncomingManualOrderToRewardFulfillHist;
    }

    public void setGetPersonDemographicsIDFromPersonID(
            String getPersonDemographicsIDFromPersonID) {
        this.getPersonDemographicsIDFromPersonID = getPersonDemographicsIDFromPersonID;
    }

    public void setSelectRewardFulfillHistIDByExternalTransID(
            String selectRewardFulfillHistIDByExternalTransID) {
        this.selectRewardFulfillHistIDByExternalTransID = selectRewardFulfillHistIDByExternalTransID;
    }

    public String getSelectIfSubgroupEndDate() {
        return selectIfSubgroupEndDate;
    }

    public void setSelectIfSubgroupEndDate(String selectIfSubgroupEndDate) {
        this.selectIfSubgroupEndDate = selectIfSubgroupEndDate;
    }

    public String getSelectIfPackageEndDate() {
        return selectIfPackageEndDate;
    }

    public void setSelectIfPackageEndDate(String selectIfPackageEndDate) {
        this.selectIfPackageEndDate = selectIfPackageEndDate;
    }

    public void setSelectContractActivityAchievedReward(
            String selectContractActivityAchievedReward) {
        this.selectContractActivityAchievedReward = selectContractActivityAchievedReward;
    }

    public void setSelectMemberActivityAchievedReward(
            String selectMemberActivityAchievedReward) {
        this.selectMemberActivityAchievedReward = selectMemberActivityAchievedReward;
    }


    public void setSelectContractActivityAchievedRewardWithContribGrid(
            String selectContractActivityAchievedRewardWithContribGrid) {
        this.selectContractActivityAchievedRewardWithContribGrid = selectContractActivityAchievedRewardWithContribGrid;
    }

    public void setSelectMemberActivityAchievedRewardWithContribGrid(
            String selectMemberActivityAchievedRewardWithContribGrid) {
        this.selectMemberActivityAchievedRewardWithContribGrid = selectMemberActivityAchievedRewardWithContribGrid;
    }

    public void setSelectActivityFulfillmentTrackingReportHist(
            String selectActivityFulfillmentTrackingReportHist) {
        this.selectActivityFulfillmentTrackingReportHist = selectActivityFulfillmentTrackingReportHist;
    }

    public void setIsPersonActivityFulfillmentHistoryNotExist(
            String isPersonActivityFulfillmentHistoryNotExist) {
        this.isPersonActivityFulfillmentHistoryNotExist = isPersonActivityFulfillmentHistoryNotExist;
    }

    public void setSelectMemberIDFromPersonDetails(
            String selectMemberIDFromPersonDetails) {
        this.selectMemberIDFromPersonDetails = selectMemberIDFromPersonDetails;
    }


    public void setDetermineIfMemberIsParticipating(
            String determineIfMemberIsParticipating) {
        this.determineIfMemberIsParticipating = determineIfMemberIsParticipating;
    }

    public String getUpdatePersonProgramIncentiveCheckmarkID() {
        return updatePersonProgramIncentiveCheckmarkID;
    }

    public void setUpdatePersonProgramIncentiveCheckmarkID(
            String updatePersonProgramIncentiveCheckmarkID) {
        this.updatePersonProgramIncentiveCheckmarkID = updatePersonProgramIncentiveCheckmarkID;
    }

    public String getUpdatePersonQualificationCheckmark() {
        return updatePersonQualificationCheckmark;
    }

    public void setUpdatePersonQualificationCheckmark(
            String updatePersonQualificationCheckmark) {
        this.updatePersonQualificationCheckmark = updatePersonQualificationCheckmark;
    }

    public void setSelectPersonActivityToContribGrid(
            String selectPersonActivityToContribGrid) {
        this.selectPersonActivityToContribGrid = selectPersonActivityToContribGrid;
    }

    public void setSelectPersonContractActivityToContribGrid(
            String selectPersonContractActivityToContribGrid) {
        this.selectPersonContractActivityToContribGrid = selectPersonContractActivityToContribGrid;
    }

    public void setIsContractIncentedForActivity(
            String isContractIncentedForActivity) {
        this.isContractIncentedForActivity = isContractIncentedForActivity;
    }

    public void setSelectMemberPgmActivityIncentiveStatus(
            String selectMemberPgmActivityIncentiveStatus) {
        this.selectMemberPgmActivityIncentiveStatus = selectMemberPgmActivityIncentiveStatus;
    }

    public void setIsCDHPPersonActivityIncentToFulfillReconcile(
            String isCDHPPersonActivityIncentToFulfillReconcile) {
        this.isCDHPPersonActivityIncentToFulfillReconcile = isCDHPPersonActivityIncentToFulfillReconcile;
    }

    public void setIsRewardPersonActivityIncentToFulfillReconcile(
            String isRewardPersonActivityIncentToFulfillReconcile) {
        this.isRewardPersonActivityIncentToFulfillReconcile = isRewardPersonActivityIncentToFulfillReconcile;
    }

    public void setSelectContractPgmActivityIncentiveStatus(
            String selectContractPgmActivityIncentiveStatus) {
        this.selectContractPgmActivityIncentiveStatus = selectContractPgmActivityIncentiveStatus;
    }

    public void setIsPersonContractProgramHistExist(String isPersonContractProgramHistExist) {
        this.isPersonContractProgramHistExist = isPersonContractProgramHistExist;
    }

    public void setSelectPersonBusinessPrograms(String selectPersonBusinessPrograms) {
        this.selectPersonBusinessPrograms = selectPersonBusinessPrograms;
    }

    public void setContractDAO(ContractDAO contractDAO) {
        this.contractDAO = contractDAO;
    }


}
package com.healthpartners.service.imfs.dto;

import java.io.Serializable;

/**
 * 
 * @author jxbourbour
 *
 */
public class ParticipationGroupDetail implements Serializable
{	
	static final long serialVersionUID = 0L;
		
	private Integer participationGroupID;
	private Integer participationGroupRequirementID;
	private Integer participationGroupDetailID;
	private String participationGroupDetailCode;
	
	private Integer participationCodeID;    // lu_id from the luv table where lu_grp=BPM_INCNTV_PART_GRP
	
	// source code
	// is used to identify the value(s) used within the person baseline table 
	// to segment participants for the identified field.
	private String sourceCode; 
	
	public ParticipationGroupDetail()
	{
		super();
	}

	public final Integer getParticipationGroupRequirementID() {
		return participationGroupRequirementID;
	}

	public final void setParticipationGroupRequirementID(
			Integer participationGroupRequirementID) {
		this.participationGroupRequirementID = participationGroupRequirementID;
	}

	public final Integer getParticipationGroupDetailID() {
		return participationGroupDetailID;
	}

	public final void setParticipationGroupDetailID(
			Integer participationGroupDetailID) {
		this.participationGroupDetailID = participationGroupDetailID;
	}

	public final Integer getParticipationCodeID() {
		return participationCodeID;
	}

	public final void setParticipationCodeID(Integer participationCodeID) {
		this.participationCodeID = participationCodeID;
	}

	public final String getSourceCode() {
		return sourceCode;
	}

	public final void setSourceCode(String sourceCode) {
		this.sourceCode = sourceCode;
	}
	
	public boolean isPersistent() {
		return participationGroupDetailID != null && participationGroupDetailID > 0;
	}

	public Integer getParticipationGroupID() {
		return participationGroupID;
	}

	public void setParticipationGroupID(Integer participationGroupID) {
		this.participationGroupID = participationGroupID;
	}

	public String getParticipationGroupDetailCode() {
		return participationGroupDetailCode;
	}

	public void setParticipationGroupDetailCode(String participationGroupDetailCode) {
		this.participationGroupDetailCode = participationGroupDetailCode;
	}
	
}

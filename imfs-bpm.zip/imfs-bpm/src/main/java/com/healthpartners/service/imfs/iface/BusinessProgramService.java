package com.healthpartners.service.imfs.iface;

import java.sql.Date;
import java.sql.SQLTimeoutException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.healthpartners.service.imfs.dto.*;
import com.healthpartners.service.imfs.rules.StatusCalculationCommand;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.QueryTimeoutException;


public interface BusinessProgramService {
	public Collection<BusinessProgram> getBusinessPrograms(String pMemberID,
														   int pProgramID, String targetBenefitYear, String groupNumber);

	public Collection<BusinessProgram> getBusinessPrograms(String pMemberID);

	public Collection<MemberProgramStatus> getGroupProgram(WebServiceRequest pWebServiceRequest);
	
	public Collection<BusinessProgramTO> getAllBusinessPrograms(Integer pPersonID, boolean pCalledFromWebPortal)
	throws DataAccessException;
	

	/**
	 * gets all active Business programs for current targetBenefitYear.
	 * 
	 * @return collection of <code>BusinessProgram</code>
	 * @throws DataAccessException
	 */
	public Collection<BusinessProgramTO> getActiveBusinessPrograms()
			throws com.healthpartners.service.imfs.exception.BPMBusinessValidationException, com.healthpartners.service.imfs.exception.BPMException,
			DataAccessException;
	
	/**
	 * This method returns a list of Business Programs based on group, site, year which is
	 * part of the feed to the membership cache system.
	 *  
	 */
	public Collection<GroupSiteYearStage> getBPMGroupSiteYear()
			throws com.healthpartners.service.imfs.exception.BPMBusinessValidationException, com.healthpartners.service.imfs.exception.BPMException,
			DataAccessException;
	
	public void autoPopulateBusinessPrograms(Integer batchCount)
	throws com.healthpartners.service.imfs.exception.BPMException;
	
	public Collection<QualificationCheckmark> getQualificationCheckmarks(int pBusinessProgramID)
	throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
	
	public Collection<CheckmarkRequirement> getCheckmarkRequirements(Integer pQualificationCheckmarkID)
	throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
	
	public Collection<ProgramIncentiveOption> getProgramIncentiveOptions(Integer programID)
	throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
	
	public Collection<IncentiveRequirement> getIncentiveRequirements(int pBusinessProgramID, int pIncentiveOptionID)
	throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
	
	public long updateContractProgramIncentive(ContractProgramIncentiveTO pContractProgramIncentiveTO)
	throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
	
	public long insertContractProgramIncentive(ContractProgramIncentiveTO pContractProgramIncentiveTO)
	throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
	
	public Collection<ContractProgramIncentiveTO> getContractProgramIncentive(Integer pBusinessProgramID
			, Integer pIncentiveOptionID, Integer pContractNo)
	throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
	
	public long updatePersonActivityIncentive(PersonActivityIncentive pPersonActivityIncentive, String pUserID)
	throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
	
	public Collection<AuthCode> getExtendedAuthCodes(Integer programID);
	public Collection<AuthCode> getEligibleAuthCodes(Integer programID);
	
	public ParticipationGroup getParticipationGroup(Integer pParticipationGroupID)
	throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
	
	public long insertMemberProgramIncentive(MemberProgramIncentiveTO pMemberProgramIncentiveTO)
	throws DataAccessException;
	
	public Collection<MemberProgramIncentiveTO> getMemberProgramIncentive(Integer pBusinessProgramID
			, Integer pIncentiveOptionID
			, Integer pContractNo
			, Integer pPersonDemographicsID)
	throws DataAccessException;
		
	public long updateMemberProgramIncentive(MemberProgramIncentiveTO pMemberProgramIncentiveTO)
	throws DataAccessException;
	
	public long deleteMemberProgramIncentive(MemberProgramIncentiveTO pMemberProgramIncentiveTO)
	throws DataAccessException;
	
	public int setContractIncentiveAchievedDate(Integer pProgramID, Integer pIncentiveOptionID, Integer pContractID, boolean pSetToNull)
	throws DataAccessException;
	
	public Collection<EligibleProgramActivity> getEligibleProgramActivities(Integer programID)
	throws DataAccessException;
	
	public void processMemberIncentivesForMembershipPremiumBillingCommand(StatusCalculationCommand statusCalculationCommand);
	
	public void autoPopulateNewSmartSteps(Integer batchCount)
	throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
	
	public Integer createAuditEventLogEntry(BPMAuditRecord bpmAuditRecord);
	
	public void writeToAuditLog(StatusCalculationCommand statusCalculationCommand, String batchMailSubject, String startDate, String endDate,
			String elapsedTime, String counts);
	
	public Collection<RejectedPerson> getEmployerRecycle(Integer activityId,
			String firstName, String lastName, Date dateOfBirth, Date activityDate, Date recycleStatusDate, Integer recycleStatusId, Integer personDemographicsID, Integer contributionAmt)
			throws DataAccessException;
	
	public Collection<RejectedPerson> getPersonEmployerPossibleMatches(String firstName, String lastName, Date birthDate, String groupNo)
			throws DataAccessException, SQLTimeoutException, QueryTimeoutException;
	
	public void insertEmployerRecycle(RejectedPerson pRejectedPerson, String pUserID)
			throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
			
			
	public void insertEmployerRecycleWithContribution(RejectedPerson pRejectedPerson, String pUserID)
	throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;

	public long deleteContractProgramIncentives(Collection<MemberProgramUpdateTO> lContractStatuses, Collection<BPMBusinessProgram> businessPrograms)
	throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
	
	public long deleteMemberProgramIncentives(Integer pPersonDemographicsID, Collection<BPMBusinessProgram> businessPrograms)
	throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
	
	public List<ProgramContributionGrid> getProgramContributionGrids(Integer programIncentiveOptionID)
			throws com.healthpartners.service.imfs.exception.BPMBusinessValidationException, com.healthpartners.service.imfs.exception.BPMException,
			DataAccessException;
	
	public IncentivePackageRuleGroup getPackageRuleGroup(Integer pIncentivePackageRuleGroupID)
	       throws com.healthpartners.service.imfs.exception.BPMException, DataAccessException;
}

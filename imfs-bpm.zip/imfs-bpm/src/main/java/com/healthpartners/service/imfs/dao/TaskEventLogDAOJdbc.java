package com.healthpartners.service.imfs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;

import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.GenericStatusType;
import com.healthpartners.service.imfs.dto.TaskEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.exception.BPMException;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;

/**
 * @author tjquist
 * 
 */
@Configuration
public class TaskEventLogDAOJdbc extends JdbcDaoSupport implements
		TaskEventLogDAO {

	/*
	 * SQL statements
	 */
	private String insertTaskEventLog;

	private String updateTaskEventLogProcessingStatus;

	private String getTaskEventsByMember;

	private String deleteTaskEventLog;

	private String getTaskEventLog;

	private String selectPendingTaskEvents;
	
	private String selectNumberOfPendingTasks;

	/*
	 * SQL sequences
	 */
	private DataFieldMaxValueIncrementer taskEventLogIdIncrementer;

	/**
	 * 
	 */
	public TaskEventLogDAOJdbc() {
		super();
	}

	@Autowired
	DataSource bpmDataSource;


	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}


	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 60, rollbackFor = { BPMException.class})
	public Long insertTaskEventLog(TaskEvent taskEvent)
			throws DataAccessException {
		// Retrieve the next sequence number
		Long taskEventLogId = new Long(taskEventLogIdIncrementer
				.nextLongValue());

		// Persist
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {
				taskEventLogId,
				taskEvent.getProcessingStatusValue(),
				taskEvent.getMemberID(),
				taskEvent.getTaskID(),
				taskEvent.getSourceSystemID(),
				(taskEvent.getTaskStatus() != null) ? taskEvent.getTaskStatus()
						.getStatusCodeValue() : null,
				(taskEvent.getTaskStatus() != null) ? taskEvent.getTaskStatus()
						.getStatusEffectiveDate() : null,
				(taskEvent.getTaskStatus() != null) ? taskEvent.getTaskStatus()
						.getOutCome() : null, taskEvent.getInsertUserId() };
		int types[] = new int[] { Types.BIGINT, Types.VARCHAR, Types.VARCHAR,
				Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP,
				Types.VARCHAR, Types.VARCHAR };
		template.update(insertTaskEventLog, params, types);

		return taskEventLogId;
	}


	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 60, rollbackFor = { BPMException.class})
	public int updateTaskEventLogProcessingStatus(TaskEvent taskEvent)
			throws DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { taskEvent.getProcessingStatusValue(),
				taskEvent.getModifyUserId(), taskEvent.getTaskEventLogID() };
		int types[] = new int[] { Types.VARCHAR, Types.VARCHAR, Types.BIGINT };
		return template.update(updateTaskEventLogProcessingStatus, params,
				types);
	}


	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 60, rollbackFor = { BPMException.class})
	public Collection<TaskEvent> getTaskEvents(Integer personId,
			Integer programID) throws DataAccessException {
		final ArrayList<TaskEvent> results = new ArrayList<TaskEvent>();
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = null;
		int types[] = null;

		StringBuffer lQuery = new StringBuffer();

		lQuery.append(getTaskEventsByMember);		

		if (programID != null && programID.intValue() > 0) {
			lQuery
					.append(" , prsn_demographics person , business_program biz WHERE person.prsn_dmgrphcs_id  = ? AND person.hp_mem_id = event.hp_mem_id ");
			lQuery
					.append(" AND biz.biz_pgm_id = ? AND event.STAT_EFF_DT BETWEEN biz.qualfctn_start_dt AND  biz.qualfctn_end_dt ");
			params = new Object[] { personId, programID };
			types = new int[] { Types.INTEGER, Types.INTEGER };
		} else {
			lQuery
					.append(" , prsn_demographics person WHERE person.prsn_dmgrphcs_id  = ? AND person.hp_mem_id = event.hp_mem_id ");
			params = new Object[] { personId };
			types = new int[] { Types.INTEGER };
		}
		
		// Ignore tasks for the same task ID if there is a more recent DELETE for that task.
		// If the delete is before the other tasks, retrieve the row.
        // The less-than sign wasn't working in the applicationContext.xml
		lQuery.append(" AND event.stat_cd <> 'DELETE' ");
		lQuery.append(" AND NOT EXISTS ");
		lQuery.append(" (SELECT 1 FROM ");
		lQuery.append(" TASK_EVENT_LOG deletes ");
		lQuery.append(" WHERE ");
		lQuery.append(" deletes.stat_cd = 'DELETE' ");
		lQuery.append(" AND event.hp_mem_id = deletes.hp_mem_id ");
		lQuery.append(" AND event.task_id = deletes.task_id "); 
		lQuery.append(" AND event.TASK_EVNT_LOG_ID < deletes.TASK_EVNT_LOG_ID ");
	    lQuery.append(" ) ");    	
		
		lQuery.append(" ORDER BY STAT_EFF_DT ASC "); 
		template.query(lQuery.toString(), params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						TaskEvent taskEvent = new TaskEvent();
						taskEvent
								.setTaskEventLogID(Long.valueOf(rs.getLong(1)));
						taskEvent.setProcessingStatusValue(rs.getString(2));
						taskEvent.setMemberID(rs.getString(3));
						taskEvent.setTaskID(rs.getString(4));
						taskEvent.setSourceSystemID(rs.getString(5));
						GenericStatusType taskStatus = new GenericStatusType();
						taskStatus.setStatusCodeValue(rs.getString(6));
						taskStatus
								.setStatusEffectiveDate(rs.getObject(7) != null ? BPMUtils
										.dateToCalendar(rs.getDate(7))
										: null);
						taskStatus.setOutCome(rs.getString(8));
						taskEvent.setTaskStatus(taskStatus);

						results.add(taskEvent);
					}
				});

		return results;
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 60, rollbackFor = { BPMException.class})
	public Collection<Long> getPendingTaskEventLogIDs(int batchSize)
			throws DataAccessException {
		final ArrayList<Long> results = new ArrayList<Long>();
		JdbcTemplate template = getJdbcTemplate();
		StringBuffer lQuery = new StringBuffer();

		lQuery.append(selectPendingTaskEvents);
		if (batchSize > 0) {
			lQuery.append(" AND ROWNUM <= " + batchSize + "");
		}

		template.query(lQuery.toString(), new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				results.add(Long.valueOf(rs.getLong(1)));
			}
		});

		return results;
	}

	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 60, rollbackFor = { BPMException.class})
	public int getNumberOfPendingTaskEvents() throws DataAccessException {
		final ArrayList<Integer> results = new ArrayList<Integer>();
		JdbcTemplate template = getJdbcTemplate();
		template.query(selectNumberOfPendingTasks,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						results.add(new Integer(rs.getInt(1)));
					}
				});

		int numberOfPendingTasks = 0;
		if (results.size() > 0) {
			numberOfPendingTasks = results.get(0).intValue();
		}

		return numberOfPendingTasks;
	}

	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 60, rollbackFor = { BPMException.class})
	public TaskEvent getTaskEvent(Long taskEventLogID)
			throws DataAccessException {
		final ArrayList<TaskEvent> results = new ArrayList<TaskEvent>();
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { taskEventLogID };
		int types[] = new int[] { Types.BIGINT };
		template.query(getTaskEventLog, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						TaskEvent taskEvent = new TaskEvent();
						taskEvent
								.setTaskEventLogID(Long.valueOf(rs.getLong(1)));
						taskEvent.setProcessingStatusValue(rs.getString(2));
						taskEvent.setMemberID(rs.getString(3));
						taskEvent.setTaskID(rs.getString(4));
						taskEvent.setSourceSystemID(rs.getString(5));
						GenericStatusType taskStatus = new GenericStatusType();
						taskStatus.setStatusCodeValue(rs.getString(6));
						taskStatus
								.setStatusEffectiveDate(rs.getObject(7) != null ? BPMUtils
										.dateToCalendar(rs.getDate(7))
										: null);
						taskStatus.setOutCome(rs.getString(8));
						taskEvent.setTaskStatus(taskStatus);

						results.add(taskEvent);
					}
				});

		TaskEvent dto = null;
		if (results.size() > 0) {
			dto = (TaskEvent) results.get(0);
		}
		return dto;
	}


	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 60, rollbackFor = { BPMException.class})
	public int deleteTaskEventLog(Long taskEventLogID)
			throws DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { taskEventLogID };
		int types[] = new int[] { Types.BIGINT };
		return template.update(deleteTaskEventLog, params, types);
	}

	/**
	 * @param deleteTaskEventLog
	 *            the deleteTaskEventLog to set
	 */
	public void setDeleteTaskEventLog(String deleteTaskEventLog) {
		this.deleteTaskEventLog = deleteTaskEventLog;
	}

	/**
	 * @param getTaskEventLog
	 *            the getTaskEventLog to set
	 */
	public void setGetTaskEventLog(String getTaskEventLog) {
		this.getTaskEventLog = getTaskEventLog;
	}

	/**
	 * @param getTaskEventsByMember
	 *            the getTaskEventsByMember to set
	 */
	public void setGetTaskEventsByMember(String getTaskEventsByMember) {
		this.getTaskEventsByMember = getTaskEventsByMember;
	}

	/**
	 * @param insertTaskEventLog
	 *            the insertTaskEventLog to set
	 */
	public void setInsertTaskEventLog(String insertTaskEventLog) {
		this.insertTaskEventLog = insertTaskEventLog;
	}

	/**
	 * @param taskEventLogIdIncrementer
	 *            the taskEventLogIdIncrementer to set
	 */
	public void setTaskEventLogIdIncrementer(
			DataFieldMaxValueIncrementer taskEventLogIdIncrementer) {
		this.taskEventLogIdIncrementer = taskEventLogIdIncrementer;
	}

	/**
	 * @param updateTaskEventLogProcessingStatus
	 *            the updateTaskEventLogProcessingStatus to set
	 */
	public void setUpdateTaskEventLogProcessingStatus(
			String updateTaskEventLogProcessingStatus) {
		this.updateTaskEventLogProcessingStatus = updateTaskEventLogProcessingStatus;
	}

	public String getSelectPendingTaskEvents() {
		return selectPendingTaskEvents;
	}

	public void setSelectPendingTaskEvents(String sql) {
		this.selectPendingTaskEvents = sql;
	}

	public String getSelectNumberOfPendingTasks() {
		return selectNumberOfPendingTasks;
	}

	public void setSelectNumberOfPendingTasks(String selectNumberOfPendingTasks) {
		this.selectNumberOfPendingTasks = selectNumberOfPendingTasks;
	}

}

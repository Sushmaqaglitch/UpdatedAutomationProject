package com.healthpartners.service.imfs.dto;

import java.util.ArrayList;

public class BPMRequiredParticipantResponse 
{
	ArrayList<RequiredParticipant> requiredParticipants;
	
    public BPMRequiredParticipantResponse()
    {    	
    }

	public ArrayList<RequiredParticipant> getRequiredParticipants() {
		return requiredParticipants;
	}

	public void setRequiredParticipants(
			ArrayList<RequiredParticipant> requiredParticipants) {
		this.requiredParticipants = requiredParticipants;
	}
    	
	
}

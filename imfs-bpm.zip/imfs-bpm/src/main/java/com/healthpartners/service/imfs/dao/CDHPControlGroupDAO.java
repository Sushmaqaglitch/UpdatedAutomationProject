package com.healthpartners.service.imfs.dao;

import java.util.Collection;

import com.healthpartners.service.imfs.dto.CDHPControlGroup;
import com.healthpartners.service.imfs.dto.CDHPControlGroupProcessTracker;
import org.springframework.dao.DataAccessException;


public interface CDHPControlGroupDAO 
{

	public Collection<CDHPControlGroup> getCDHPControlGroups();
	
	public int insertCDHPControlGroupProcessTracker(Integer controlGroupID, String processStatus, Integer recordsSent)
	throws DataAccessException;
	
	public CDHPControlGroupProcessTracker getCDHPControlGroupProcessTracker(Integer controlGroupID);
	
}

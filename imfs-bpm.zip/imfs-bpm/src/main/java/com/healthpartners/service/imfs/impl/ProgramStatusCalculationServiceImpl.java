
package com.healthpartners.service.imfs.impl;


import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dao.ActivityDAO;
import com.healthpartners.service.imfs.dao.ActivityEventLogDAO;
import com.healthpartners.service.imfs.dao.BatchLogDAOJdbc;
import com.healthpartners.service.imfs.dao.BusinessProgramDAO;
import com.healthpartners.service.imfs.dao.CDHPControlGroupDAO;
import com.healthpartners.service.imfs.dao.CallChangedMarketEZ;
import com.healthpartners.service.imfs.dao.CallChangedMarketNonEZ;
import com.healthpartners.service.imfs.dao.CallCorrectPurchaserSubtype;
import com.healthpartners.service.imfs.dao.CallDeleteTermedByGroup;
import com.healthpartners.service.imfs.dao.CallDeleteTermedParticipants;
import com.healthpartners.service.imfs.dao.CallEmployerGroupBaselineSetup;
import com.healthpartners.service.imfs.dao.CallEmployerGroupSiteSetup;
import com.healthpartners.service.imfs.dao.CallEndedGroups;
import com.healthpartners.service.imfs.dao.CallEndedGroupsBizSetup;
import com.healthpartners.service.imfs.dao.CallEndedMedical;
import com.healthpartners.service.imfs.dao.CallFilteredOutActivity;
import com.healthpartners.service.imfs.dao.CallPopulateMissingPeople;
import com.healthpartners.service.imfs.dao.CallPopulateMissingPersonProgramActivities;
import com.healthpartners.service.imfs.dao.CallPopulatePackageBaseline;
import com.healthpartners.service.imfs.dao.CallRecalcDualCoveredPersons;
import com.healthpartners.service.imfs.dao.ContractDAO;
import com.healthpartners.service.imfs.dao.GroupBaselineDAO;
import com.healthpartners.service.imfs.dao.IncentiveOptionDAO;
import com.healthpartners.service.imfs.dao.IncentivePackageRuleDAO;
import com.healthpartners.service.imfs.dao.LookUpValueDAOJdbc;
import com.healthpartners.service.imfs.dao.PersonDAO;
import com.healthpartners.service.imfs.dao.ProcessingStatusLogDAO;
import com.healthpartners.service.imfs.dao.RiskDAOJdbc;
import com.healthpartners.service.imfs.dao.TaskEventLogDAO;
import com.healthpartners.service.imfs.dto.ActivityEvent;
import com.healthpartners.service.imfs.dto.AuthCode;
import com.healthpartners.service.imfs.dto.BPMAuditRecord;
import com.healthpartners.service.imfs.dto.BPMBusinessProgram;
import com.healthpartners.service.imfs.dto.BusinessProgramTO;
import com.healthpartners.service.imfs.dto.CDHPBatchLog;
import com.healthpartners.service.imfs.dto.CDHPControlGroup;
import com.healthpartners.service.imfs.dto.CDHPControlGroupProcessTracker;
import com.healthpartners.service.imfs.dto.CDHPFulfillmentTrackingRecycle;
import com.healthpartners.service.imfs.dto.CDHPFulfillmentTrackingReport;
import com.healthpartners.service.imfs.dto.CDHPFulfillmentTrackingReportHist;
import com.healthpartners.service.imfs.dto.CheckmarkRequirement;
import com.healthpartners.service.imfs.dto.ContractContributionTO;
import com.healthpartners.service.imfs.dto.ContractHistory;
import com.healthpartners.service.imfs.dto.ContractPolicyHolderInfo;
import com.healthpartners.service.imfs.dto.ContractProgramIncentiveTO;
import com.healthpartners.service.imfs.dto.ContractTO;
import com.healthpartners.service.imfs.dto.EligibleProgramActivity;
import com.healthpartners.service.imfs.dto.EmployerFulfillmentMemberActivity;
import com.healthpartners.service.imfs.dto.GroupSiteYearStage;
import com.healthpartners.service.imfs.dto.IncentiveRequirement;
import com.healthpartners.service.imfs.dto.LookUpValueCode;
import com.healthpartners.service.imfs.dto.MemberContractProgramTO;
import com.healthpartners.service.imfs.dto.MemberProgramIncentiveTO;
import com.healthpartners.service.imfs.dto.MemberProgramUpdateTO;
import com.healthpartners.service.imfs.dto.MemberTO;
import com.healthpartners.service.imfs.dto.MemberUpdate;
import com.healthpartners.service.imfs.dto.PackageHistory;
import com.healthpartners.service.imfs.dto.PersonActivityAchievedContribution;
import com.healthpartners.service.imfs.dto.PersonActivityAchievedReward;
import com.healthpartners.service.imfs.dto.PersonActivityIncentive;
import com.healthpartners.service.imfs.dto.PersonContractHist;
import com.healthpartners.service.imfs.dto.PersonContractRecycle;
import com.healthpartners.service.imfs.dto.PersonContractRecycleList;
import com.healthpartners.service.imfs.dto.PersonPackage;
import com.healthpartners.service.imfs.dto.PersonProgramActivityIncentiveStatus;
import com.healthpartners.service.imfs.dto.PersonProgramStage;
import com.healthpartners.service.imfs.dto.ProgramIncentiveOption;
import com.healthpartners.service.imfs.dto.QualificationCheckmark;
import com.healthpartners.service.imfs.dto.QualificationOverride;
import com.healthpartners.service.imfs.dto.ReconLogStage;
import com.healthpartners.service.imfs.dto.RewardBatchLog;
import com.healthpartners.service.imfs.dto.RewardCardClientData;
import com.healthpartners.service.imfs.dto.RewardCardError;
import com.healthpartners.service.imfs.dto.RewardCardQuote;
import com.healthpartners.service.imfs.dto.RewardCardQuoteByProgramSummary;
import com.healthpartners.service.imfs.dto.RewardCardRecycleDetail;
import com.healthpartners.service.imfs.dto.RewardControlProgram;
import com.healthpartners.service.imfs.dto.RewardControlProgramProcessTracker;
import com.healthpartners.service.imfs.dto.RewardFulfillmentTrackingRecycle;
import com.healthpartners.service.imfs.dto.RewardFulfillmentTrackingReportHist;
import com.healthpartners.service.imfs.dto.RewardIntelispendOrdered;
import com.healthpartners.service.imfs.dto.RewardIntelispendResponse;
import com.healthpartners.service.imfs.dto.RewardIntelispendShipped;
import com.healthpartners.service.imfs.dto.Risk;
import com.healthpartners.service.imfs.dto.StoredProcedureResults;
import com.healthpartners.service.imfs.dto.SubgroupHistory;
import com.healthpartners.service.imfs.dto.TaskEvent;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.exception.BPMParserException;
import com.healthpartners.service.imfs.factory.BPMTransformerFactoryFinder;
import com.healthpartners.service.imfs.ftp.FTPFile;
import com.healthpartners.service.imfs.helper.RewardIntelispendDataFileHelper;
import com.healthpartners.service.imfs.iface.ActivityEventCreationBasedOnPreconditionService;
import com.healthpartners.service.imfs.iface.ActivityEventService;
import com.healthpartners.service.imfs.iface.ArchivePersonContractProgramHistoryService;
import com.healthpartners.service.imfs.iface.AuditLogService;
import com.healthpartners.service.imfs.iface.BusinessProgramService;
import com.healthpartners.service.imfs.iface.EmailService;
import com.healthpartners.service.imfs.iface.EmployerActivityReconciliationService;
import com.healthpartners.service.imfs.iface.GroupSiteYearStageService;
import com.healthpartners.service.imfs.iface.LookUpValueService;
import com.healthpartners.service.imfs.iface.MemberService;
import com.healthpartners.service.imfs.iface.MembershipFeedStageService;
import com.healthpartners.service.imfs.iface.PersonContractActivityToContribGridReconService;
import com.healthpartners.service.imfs.iface.PersonContractRecycleReportService;
import com.healthpartners.service.imfs.iface.ProgramStatusCalculationService;
import com.healthpartners.service.imfs.iface.QualificationOverrideService;
import com.healthpartners.service.imfs.iface.QualificationTimeService;
import com.healthpartners.service.imfs.iface.ReprocessUnresolvedBenefitContractTypeForActivityIncentivesService;
import com.healthpartners.service.imfs.iface.ResetActivityEventsFromInprocessToPendingService;
import com.healthpartners.service.imfs.iface.RewardCardService;
import com.healthpartners.service.imfs.iface.RuleGroupService;
import com.healthpartners.service.imfs.iface.TaskEventService;
import com.healthpartners.service.imfs.iface.UploadEmployerActivityIncentToFulfillReconService;
import com.healthpartners.service.imfs.iface.UploadEmployerActivityPostprocessService;
import com.healthpartners.service.imfs.iface.UploadEmployerActivityPreprocessService;
import com.healthpartners.service.imfs.outbound.OutboundFileProcessing;
import com.healthpartners.service.imfs.rules.BusinessProgramAdapter;
import com.healthpartners.service.imfs.rules.MemberAdapter;
import com.healthpartners.service.imfs.rules.RulesResultHelper;
import com.healthpartners.service.imfs.rules.StatusCalculationCommand;
import com.healthpartners.service.imfs.writecsv.GenerateEmplTrackingCsv;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

//import com.healthpartners.service.imfs.jms.ActivityEventGenerator;
//import com.healthpartners.service.imfs.jms.TaskEventGenerator;


/**
 * Implementation of service ProgramStatusCalculationService. provides
 * implementaion of methods for member/program/contract status caluculation.
 * processAgainstRewardRecycle
 * @author pbhenninger
 * 
 */
@Component
public class ProgramStatusCalculationServiceImpl implements
		ProgramStatusCalculationService {

	private static final int DEFAULT_BATCH_SIZE = 200;
	private static final int DEFAULT_BATCH_SIZE_ACTIVITY = 500;

    protected final Log logger = LogFactory.getLog(getClass());

	// Service references.
	private MemberService memberService;

	private RuleGroupService ruleGroupService;

	private QualificationOverrideService qualificationOverrideService;

	private QualificationTimeService qualificationTimeService;

//	private ActivityEventGenerator activityEventGenerator;
//
//	private TaskEventGenerator taskEventGenerator;

	private TaskEventService taskEventService;
	
	private GroupSiteYearStageService groupSiteYearStageService;
	
	private BusinessProgramService businessProgramService;
	
	private MembershipFeedStageService membershipFeedStageService;

	private ActivityEventLogDAO activityEventLogDAO;

	private TaskEventLogDAO taskEventLogDAO;

	private ContractDAO contractDAO;

	private PersonDAO personDAO;

	private AuditLogService auditLogService;
	
	private BusinessProgramDAO businessProgramDAO;
	
	private ProcessingStatusLogDAO processingStatusLogDAO;
	
	private LookUpValueService lookUpValueService;
	
	private IncentiveOptionDAO incentiveOptionDAO;

	// used spring transction
	// private DataSourceTransactionManager txManager;

	@Autowired
	private EmailService emailService;
	@Autowired
	private LookUpValueDAOJdbc lookUpValueDAO;
	@Autowired
	private RiskDAOJdbc riskDAO;
	@Autowired
	private BatchLogDAOJdbc batchLogDAO;
	@Autowired
	private ActivityDAO activityDAO;
	@Autowired
	private GroupBaselineDAO groupBaselineDAO;
	@Autowired
	private CDHPControlGroupDAO cdhpControlGroupDAO;
	@Autowired
	private RewardCardService rewardCardService;
	@Autowired
	private ActivityEventService activityEventService;
/*	@Autowired
	private ClientCallToIntelispendService clientCallToIntelispendService;*/
	@Autowired
	private UploadEmployerActivityPreprocessService uploadEmployerActivityPreprocessService;
	@Autowired
	private UploadEmployerActivityPostprocessService uploadEmployerActivityPostprocessService;
	@Autowired
	private UploadEmployerActivityIncentToFulfillReconService uploadEmployerActivityIncentToFulfillReconService;
	@Autowired
	private ResetActivityEventsFromInprocessToPendingService resetActivityEventsFromInprocessToPendingService;
	@Autowired
	private ReprocessUnresolvedBenefitContractTypeForActivityIncentivesService reprocessUnresolvedBenefitContractTypeForActivityIncentivesService;
	@Autowired
	private PersonContractActivityToContribGridReconService personContractActivityToContribGridReconService;
	@Autowired
	private EmployerActivityReconciliationService employerActivityReconciliationService;
	@Autowired
	private ArchivePersonContractProgramHistoryService archivePersonContractProgramHistoryService;
	@Autowired
	private PersonContractRecycleReportService personContractRecycleReportService;
	@Autowired
	private ActivityEventCreationBasedOnPreconditionService activityEventCreationBasedOnPreconditionService;

	@Autowired
	private CallEmployerGroupSiteSetup callEmployerGroupSiteSetup;
	@Autowired
	private CallEmployerGroupBaselineSetup callEmployerGroupBaselineSetup;
	@Autowired
	private CallPopulateMissingPeople callPopulateMissingPeople;
	@Autowired
	private CallPopulateMissingPersonProgramActivities callPopulateMissingPersonProgramActivities;
	@Autowired
    private CallRecalcDualCoveredPersons callRecalcDualCoveredPersons;
	@Autowired
	private CallDeleteTermedParticipants callDeleteTermedParticipants;
	@Autowired
	private CallDeleteTermedByGroup callDeleteTermedByGroup;
	@Autowired
	private CallPopulatePackageBaseline callPopulatePackageBaseline;
	@Autowired
	private CallFilteredOutActivity callFilteredOutActivity;
	@Autowired
	private CallEndedGroups callEndedGroups;
	@Autowired
	private CallEndedGroupsBizSetup callEndedGroupsBizSetup;
	@Autowired
	private CallChangedMarketEZ callChangedMarketEZ;
	@Autowired
	private CallChangedMarketNonEZ callChangedMarketNonEZ;
	@Autowired
	private CallEndedMedical callEndedMedical;
	@Autowired
	private CallCorrectPurchaserSubtype callCorrectPurchaserSubtype;
	@Autowired
    private IncentivePackageRuleDAO incentivePackageRuleDAO;	
	
	private int recycleRecordsOnHoldR1 = 0;
	private int recycleRecordsOnHoldR2 = 0;
	private int recycleRecordsOnHoldR3 = 0;
	private int recycleRecordsApprovedToReleased = 0; 
	private int recycleRecordsOnHoldToReleased = 0;
	private int recycleRecordsDeniedNNowQaulified = 0;
    private int recycleRecordsOnHoldToBeReleased = 0;
    private int recycleRecordsOnHoldWaitingToBeReviewed = 0;

	private String errorMessageFromVendorWebservice = null;

	@Autowired
	private String hostName;

	/**
	 * This sigle public method takes all types of status caluculation requests
	 * and routes to specific type of calculation.ie activity and task updates,
	 * batch calculations- etl membership updates, elapsed times(hold for
	 * contact), pending activities, tasks. The parameter class
	 * StatusCalculationCommand - intended to specify the type of process to
	 * run.
	 * 
	 */
	public void updateProgramStatus(
			StatusCalculationCommand statusCalculationCommand)
			throws com.healthpartners.service.imfs.exception.BPMBusinessValidationException, BPMException,
			DataAccessException
	{

			if (statusCalculationCommand == null) {
				logger.info("updateProgramStatus(), StatusCalculationCommand is null!!! returning..");
			} else {

				logger.info("Current Processing Command is " + statusCalculationCommand.getCurrentProcessingCommand());
				logger.info("Process Name is " + statusCalculationCommand.getProcessName());
				// Check if it is not a Batch job
				if (statusCalculationCommand.isNotABatchCommand()) {
					// 1.activity command
					if (statusCalculationCommand.isActivityEventCommand()) {
						// by this time, ActivityEvent has been updated in
						// program-activity table. Just need to re calcuate
						// member/contract status based on all activities
						ActivityEvent activityEvent = statusCalculationCommand
								.getActivityEvent();
						Integer personID = memberService.getPersonID(activityEvent
								.getMemberID());
						// caluculate and update member/program/contract status
						this.updateProgramStatusBasedOnMember(personID);
					}

					// 2.task command
					if (statusCalculationCommand.isTaskEventCommand()) {
						// by this time, TaskEvent has been updated.
						// Just need to re-calcuate
						// member/contract status based on all activities
						TaskEvent taskEvent = statusCalculationCommand
								.getTaskEvent();
						Integer personID = memberService.getPersonID(taskEvent
								.getMemberID());
						// caluculate and update member/program/contract status
						this.updateProgramStatusBasedOnMember(personID);
					}

					// 3. one meber update
					if (statusCalculationCommand.isOnePersonCommand()) {
						// This command is to just re-calcuate member/contract
						// status
						Integer personID = statusCalculationCommand
								.getOnePersonID();
						// caluculate and update member/program/contract status
						this.updateProgramStatusBasedOnMember(personID);
					}
				} else {
					// you are here, to run batch Jobs

					// 1 ETL membership update
                    //BPM-736
//					if (statusCalculationCommand.isEtlMembershipUpdateCommand()) {
//						processEtlMembershipUpdateCommand(statusCalculationCommand);
//					}

//					if (statusCalculationCommand.isTopicEtlMembershipUpdateCommand()) {
//						processEtlMembershipUpdateCommand(statusCalculationCommand);
//						setTopicMessageToKickstartETLMembershipUpdateMultiProcessing();
//					}
					//BPM Story 343
//					if (statusCalculationCommand.isEtlMembershipUpdateOnlyCommand()) {
//						processEtlMembershipUpdateOnlyCommand(statusCalculationCommand);
//					}

					// 2 elapsed time
					if (statusCalculationCommand.isMemberElapsedTimeCommand()) {
						processElapsedTimeCommand(statusCalculationCommand);
					}

					// 3 members re calculation
					if (statusCalculationCommand.isMembersReCalculationCommand()) {
						processMembersReCalculationCommand(statusCalculationCommand);
					}

					// 4. filtered activities
					if (statusCalculationCommand.isFilteredActivityEventsCommand()) {
						determineFilteredOutActivityEventsCommand(statusCalculationCommand);
					}

					// 5. pending activities
					if (statusCalculationCommand.isPendingActivityEventsCommand()) {
						processPendingActivityEventsCommand(statusCalculationCommand);
					}

					// 6. pending tasks
					if (statusCalculationCommand.isPendingTaskEventsCommand()) {
						processPendingTaskEventsCommand(statusCalculationCommand);
					}

					// 7. Membership Feed
					if (statusCalculationCommand.isMbrShipFeedCommand()) {
						notifyMembershipAndSendEmail(statusCalculationCommand);
						processMbrShipFeedCommand(statusCalculationCommand);
					}

					// 7.5. Purge Employer Group Baseline History table by date

					if (statusCalculationCommand.isPurgeGroupBaselineHistTableCommand()) {
						processPurgeGroupBaselineHistCommand(statusCalculationCommand);
					}

					// 8. Purge AuditLog table by date
					if (statusCalculationCommand.isPurgeAuditLogTableCommand()) {
						processPurgeAuditLogCommand(statusCalculationCommand);
					}


					if (statusCalculationCommand.isPurgeProcessStatLogTableCommand()) {
						processPurgeProcessingStatusLogCommand(statusCalculationCommand);
					}


					// 10. Auto business program setup from group baseline table into
					// the business program table.
					// WIP 576 - As part of discovery for this story, determined
					// that the auto program setup command responsible for creating
					// business programs from the group baseline table for smartsteps is
					// no longer occuring.  The shell job has been retired.  Instead, new smartsteps
					// business programs are being autopopulated through a stored procedure.  See
					// AutoPopulateNewSmartSteps under command isAutoProgramSetupNewSmartSteps.
				/*if(statusCalculationCommand.isAutoProgramSetup())
				{
					LookUpValueCode autoPopulate = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.BPM_AUTOPOPULATE_CTRL, BPMConstants.AUTOPOPULATE_CTRL_CT);
					Integer batchCount = Integer.valueOf(autoPopulate.getLuvDesc());
					logger.info("Start autoPopulate Batch Process using a batch count of " + batchCount);
					if (batchCount != null && batchCount > 0) {
						businessProgramService.autoPopulateBusinessPrograms(batchCount);											
						
					} else {
						throw new BPMException("Luv record that contains batch count for AutoProgramSetup is null or set to 0");
					}
				}*/

					if (statusCalculationCommand.isAutoProgramSetupNewSmartSteps()) {
						LookUpValueCode autoPopulate = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.BPM_AUTOPOPULATE_CTRL, BPMConstants.AUTOPOPULATE_CTRL_CT);
						Integer batchCount = Integer.valueOf(autoPopulate.getLuvDesc());
						logger.info("Start autoPopulate New Smart Steps Batch Process using a batch count of " + batchCount);
						if (batchCount != null && batchCount > 0) {
							businessProgramService.autoPopulateNewSmartSteps(batchCount);
						} else {
							throw new BPMException("Luv record that contains batch count for AutoProgramSetup is null or set to 0");
						}
					}

					if (statusCalculationCommand.isMbrShipPremiumBillingFeedCommand()) {
						businessProgramService.processMemberIncentivesForMembershipPremiumBillingCommand(statusCalculationCommand);
					}


					if (statusCalculationCommand.isEmployerGroupSiteSetup()) {
						logger.info("Call employer group site setup ");
						StoredProcedureResults lStoredProcedureResults = callEmployerGroupSiteSetup.execute();
						emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
						emailService.prepareAndSendBatchStatusEmail("BPM Batch Process (Status Employer GroupSite Setup) - SUCCESS",
								"<tr><td>" + "Employer Group Site Setup completed." + "</td></tr>"
								+ "<tr><td>" + "Start Records Before Run = " + lStoredProcedureResults.getCountBefore() + "</td></tr>"
								+ "<tr><td>" + "Records Inserted = " + (lStoredProcedureResults.getCountAfter() - lStoredProcedureResults.getCountBefore()) + "</td></tr>"
								+ "<tr><td>" + "Number Of Records Updated = " + lStoredProcedureResults.getCountAfter() + "</td></tr>"
								+ "<tr><td>" + "Records After Run = " + lStoredProcedureResults.getCountAfter() + "</td></tr>"
						);
					}

					if (statusCalculationCommand.isEmployerGroupBaselineSetup()) {
						logger.info("Call employer group baseline setup ");
						StoredProcedureResults lStoredProcedureResults = callEmployerGroupBaselineSetup.execute();
						logger.info("Call employer group baseline setup finished");
						emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
						emailService.prepareAndSendBatchStatusEmail("BPM Batch Process Status (Employer GroupBaseline Setup) - SUCCESS",
								"<tr><td>" + "Employer Group Baseline Setup completed." + "</td></tr>"
								+ "<tr><td>" + "Start Records Before Run = " + lStoredProcedureResults.getCountBefore() + "</td></tr>"
								+ "<tr><td>" + "Records Inserted = " + (lStoredProcedureResults.getCountAfter() - lStoredProcedureResults.getCountBefore()) + "</td></tr>"
								+ "<tr><td>" + "Number Of Records Updated = " + lStoredProcedureResults.getCountUpdate() + "</td></tr>"
								+ "<tr><td>" + "Records After Run = " + lStoredProcedureResults.getCountAfter() + "</td></tr>"
						);
					}


					if (statusCalculationCommand.isPopulateMissingPeople()) {
						logger.info("Call callPopulateMissingPeople ");
						StoredProcedureResults lStoredProcedureResults = callPopulateMissingPeople.execute();
						logger.info("Call callPopulateMissingPeople finished");
						emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
						emailService.prepareAndSendBatchStatusEmail("BPM Batch Process Status (Populate Missing People) - SUCCESS",
								"<tr><td>" + "Populate Missing People completed." + "</td></tr>"
								+ "<tr><td>" + "Number Of Records Updated = " + lStoredProcedureResults.getCountUpdate() + "</td></tr>"
						);
					}

					if (statusCalculationCommand.isPopulateMissingPersonProgramActivities()) {
						logger.info("Call callPopulateMissingPersonProgramActivities ");
						StoredProcedureResults lStoredProcedureResults = callPopulateMissingPersonProgramActivities.execute();
						logger.info("Call callPopulateMissingPersonProgramActivities finished");
						emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
						emailService.prepareAndSendBatchStatusEmail("BPM Batch Process Status (Reprocess Activity Events missing Person Program Activities) - SUCCESS",
								"<tr><td>" + "Reprocess Activity Events Missing Person Program Activities." + "</td></tr>" +
										    "<td><tr>" + "Number Of Activity Event Records Set to Pending = " + lStoredProcedureResults.getCountUpdate() + "</td></tr>"
						);
					}
                /*
                  BPM-45: Identify dual covered members and recalculate if one contract is QUALIFIED and the other is
                  still ELIGIBLE.
                 */
					if (statusCalculationCommand.isRecalcDualCoveredPersons()) {
						logger.info("Call callRecalcDualCoveredPersons ");
						StoredProcedureResults lStoredProcedureResults = callRecalcDualCoveredPersons.execute();
						//Process all dual covered persons marked for recalculation.
						statusCalculationCommand.setCurrentCommandText("Batch Membership Recalc");
						// set current command to fetch processID
						statusCalculationCommand
								.setCurrentProcessingCommand(StatusCalculationCommand.MEMBERS_RECALCULATION);
						statusCalculationCommand.setProcessIDForMembersReCalculationCommand(BPMConstants.MEMBERS_RECALCULATION_PRCS_ID);
						processBatchMembersForCommand(statusCalculationCommand);

						logger.info("Call callRecalcDualCoveredPersons finished");
						emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
						emailService.prepareAndSendBatchStatusEmail("BPM Batch Process Status (Recalc Dual Covered Persons ELIGIBLE and QUALIFIED) - SUCCESS",
								"<tr><td>" + "Recalculate Dual Covered Persons ELIGIBLE and QUALIFIED." + "</td></tr>"
                                        + "<tr><td>" + "Number Of Dual Covered Persons Recalculated = " + lStoredProcedureResults.getCountUpdate() + "</td></tr>"
						);
					}

					if (statusCalculationCommand.isDeleteTermedParticipants()) {
						StoredProcedureResults lStoredProcedureResults = callDeleteTermedParticipants.execute();
						emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
						emailService.prepareAndSendBatchStatusEmail("BPM Batch Process Status (Delete Termed Participants) - SUCCESS",
								"<tr><td>" + "Delete Termed Participants completed." + "</td></tr>"
										+ "<tr><td>" + "Number Of Person Records Deleted = " + lStoredProcedureResults.getCountDeletedPersons() + "</td></tr>"
										+ "<tr><td>" + "Number Of Contract Records Deleted = " + lStoredProcedureResults.getCountDeletedContracts() + "</td></tr>"
						);
					}

					if (statusCalculationCommand.isDeleteTermedByGroup()) {
						String lGroupNo = (String) statusCalculationCommand.getParametersMap().get("groupNumber");
						String lContractEndedAfterDate = (String) statusCalculationCommand.getParametersMap().get("contractEndedAfterDate");

						StoredProcedureResults lStoredProcedureResults = callDeleteTermedByGroup.execute(lGroupNo, lContractEndedAfterDate);
						emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
						emailService.prepareAndSendBatchStatusEmail("BPM Batch Process Status (Delete Termed By Group) - SUCCESS",
								"<tr><td>" + "Delete Termed Participants By Group completed for Group No " + lGroupNo + "</td></tr>"
								+ "<tr><td>" + "Number Of Person Records Deleted = " + lStoredProcedureResults.getCountDeletedPersons() + "</td></tr>"
								+ "<tr><td>" + "Number Of Contract Records Deleted = " + lStoredProcedureResults.getCountDeletedContracts() + "</td></tr>"
						);
					}

					if (statusCalculationCommand.isCallPopulatePackageBaseline()) {
						StoredProcedureResults lStoredProcedureResults = callPopulatePackageBaseline.execute();
						emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
						emailService.prepareAndSendBatchStatusEmail("BPM Batch Process Status (Call Populate PackageBaseline) - SUCCESS",
								"<tr><td>" + "\nPopulate Employer Package Baseline completed:" + "</td></tr>"
										+ "<tr><td>" + "Start Records Before Run = " + lStoredProcedureResults.getCountBefore() + "</td></tr>"
										+ "<tr><td>" + "Records Inserted = " + (lStoredProcedureResults.getCountAfter() - lStoredProcedureResults.getCountBefore()) + "</td></tr>"
										+ "<tr><td>" + "Number Of Records Updated = " + lStoredProcedureResults.getCountUpdate() + "</td></tr>"
										+ "<tr><td>" + "Records After Run = " + lStoredProcedureResults.getCountAfter() + "</td></tr>"
						);
					}

					if (statusCalculationCommand.isFilteredOutActivityReport()) {
						LookUpValueCode lFilePathLUV = this.lookUpValueDAO.getLUVCodeByGroupNValue(BPMConstants.BPM_FILTERED_OUT_LUV_GRP, BPMConstants.BPM_FILTERED_OUT_PATH_LUVAL);

						String lFileName = callFilteredOutActivity.execute(lFilePathLUV.getLuvDesc());

						ArrayList<String> lAttachmentLocations = new ArrayList<String>();
						lAttachmentLocations.add(lFileName);
						emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
						emailService.prepareAndSendBatchStatusEmail("BPM Batch Process Status (FilteredOut Activity Report) - SUCCESS",
								"<tr><td>" + "Filtered-Out Activity Report Completed. File Attached." + "</td></tr>"
								, lAttachmentLocations
						);
					}

					if (statusCalculationCommand.isAutoPopulateAuditReport()) {
						LookUpValueCode lFilePathLUV = this.lookUpValueDAO.getLUVCodeByGroupNValue(BPMConstants.BPM_AUTOPOPULATE_AUDIT_GRP, BPMConstants.BPM_AUTOPOPULATE_AUDIT_PATH_LUVAL);

						ArrayList<String> lAttachmentLocations = new ArrayList<String>();

						String lFileName = callEndedGroups.execute(lFilePathLUV.getLuvDesc());
						lAttachmentLocations.add(lFileName);

						lFileName = callEndedGroupsBizSetup.execute(lFilePathLUV.getLuvDesc());
						lAttachmentLocations.add(lFileName);

						lFileName = callEndedMedical.execute(lFilePathLUV.getLuvDesc());
						lAttachmentLocations.add(lFileName);

						lFileName = callChangedMarketEZ.execute(lFilePathLUV.getLuvDesc());
						lAttachmentLocations.add(lFileName);

						// No Need
						lFileName = callChangedMarketNonEZ.execute(lFilePathLUV.getLuvDesc());
						lAttachmentLocations.add(lFileName);
						emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
						emailService.prepareAndSendBatchStatusEmail("BPM Batch Process Status (Auto Populate Audit Report) - SUCCESS",
								"<tr><td>" + "AutoPopulate Audit Report - Completed. Files Attached." + "</td></tr>"
								, lAttachmentLocations
						);
					}

					if (statusCalculationCommand.isCorrectPurchaserSubType()) {
						StoredProcedureResults lStoredProcedureResults = callCorrectPurchaserSubtype.execute();
						emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
						emailService.prepareAndSendBatchStatusEmail("BPM Batch Process Status (Correct Purchaser Subtype) - SUCCESS",
								"<tr><td>" + "Correct Purchaser Subtype completed." + "</td></tr>"
								+ "<tr><td>" + "Number of distinct groups selected = " + lStoredProcedureResults.getCountBefore() + "</td></tr>"
								+ "<tr><td>" + "Number Of Package Baseline Records Updated = " + lStoredProcedureResults.getCountUpdate() + "</td></tr>"
						);
					}

					// 11. Reconcile person contract history table against contract program status table.  If person contract status from history does
					// not match contract status from contract program status table, update person processing status log by updating the contract status which
					// will trigger contract program status to come over in the Cache membership feed.

					if (statusCalculationCommand.isPersonContractHistReconciliationCommand()) {
						processReconcilePersonContractHistoryCommand(statusCalculationCommand);
					}

					// 12. Employer Reporting Fulfillment feed

					if (statusCalculationCommand.isEmployerReportingFulfillmentCommand()) {
						processEmployerFulfillmentReportingCommand(statusCalculationCommand);
					}
					// 13. resend Employer Reporting Fulfillment file.
					if (statusCalculationCommand.isResendEmployerReportingFulfillmentCommand()) {
						resendEmployerFulfillmentReportingtoCSVFileCommand(statusCalculationCommand);
					}
					// 13. process HRA Contribution.
					if (statusCalculationCommand.isProcessCDHPHRAFulfillment()) {
						processCDHPHRAContributionsCommand(statusCalculationCommand);
					}
					// 14. process HSA Contribution.
					if (statusCalculationCommand.isProcessCDHPHSAFulfillment()) {
						processCDHPHSAContributionsCommand(statusCalculationCommand);
					}

			/*		// 15. batch up incented rewards and send to InteliSpend.
					if (statusCalculationCommand.isProcessRewardFulfillment()) {
						processRewardsToIntelispendCommand(statusCalculationCommand);
					}*/

					// 16. process reward files produced by Intelispend.
					if (statusCalculationCommand.isProcessRewardFilesFromIntelispendFulfillment()) {
						processRewardFilesFromIntelispendCommand(statusCalculationCommand);
					}

					// 17. upload employer activity file, perform validations against file, write to activity event log and kickoff
					//     pending activity process.
					if (statusCalculationCommand.isProcessBatchEmployerActivitiesPreprocessCommand()) {
						logger.info("Call processUploadEmployerActivityPreprocessCommand ");
						statusCalculationCommand.setHostName(hostName);
						uploadEmployerActivityPreprocessService.processUploadEmployerActivityPreprocessCommand(statusCalculationCommand);
					}

					// 18. determine if uploaded employer activity file balances to what was loaded into BPM.  Generate post process summary report
					// e-mail notification.
					if (statusCalculationCommand.isProcessBatchEmployerActivitiesPostprocessCommand()) {
						logger.info("Call processUploadEmployerActivityPostprocessCommand ");
						logger.info("host name is  " + hostName);
						statusCalculationCommand.setHostName(hostName);
						uploadEmployerActivityPostprocessService.processUploadEmployerActivityPostprocessCommand(statusCalculationCommand);
					}

					// 19. determine if uploaded employer activity file balances to what was loaded into BPM.  Generate post process summary report
					// e-mail notification.
					if (statusCalculationCommand.isProcessBatchOptumMemberActivitiesIncentedToFulfillReconCommand()) {
						logger.info("Call processUploadEmployerActivityIncentToFulfillReconCommand ");
						logger.info("host name is  " + hostName);
						statusCalculationCommand.setHostName(hostName);
						uploadEmployerActivityIncentToFulfillReconService.processUploadEmployerActivityIncentToFulfillReconCommand(statusCalculationCommand);
					}

					// 20. Batch job to find activity events that are IN_PROCESS and reset to PENDING.  Some times
					//     activity events that go through status calculation don't make it all the way through
					//     and remain in a IN_PROCESS state.
					if (statusCalculationCommand.isProcessResetActivityEventsFromInprocessToPendingCommand()) {
						logger.info("Call ProcessResetActivityEventsFromInprocessToPendingCommand ");
						logger.info("host name is  " + hostName);
						statusCalculationCommand.setHostName(hostName);
						resetActivityEventsFromInprocessToPendingService.processResetActivityEventsFromInprocessToPendingCommand(statusCalculationCommand);
					}

					// 21. Batch job to reprocess incented activities with benefit contract types of UNRESOLVED.
					if (statusCalculationCommand.isProcessUnresolvedContractBenefitTypeForActivityIncentiveCommand()) {
						logger.info("Call ProcessUnresolvedContractBenefitTypeForActivityIncentiveCommand ");
						logger.info("host name is  " + hostName);
						statusCalculationCommand.setHostName(hostName);
						reprocessUnresolvedBenefitContractTypeForActivityIncentivesService.processUnresolvedContractBenefitTypeForActivityIncentiveCommand(statusCalculationCommand);
					}

					// 22. Batch job to reconcile and report on contract and member based inentives that don't match up to program contribution grids.
					if (statusCalculationCommand.isProcessPersonContractActivityToContribGridReconCommand()) {
						logger.info("Call ProcessPersonContractActivityToContribGridReconCommand ");
						logger.info("host name is  " + hostName);
						statusCalculationCommand.setHostName(hostName);
						personContractActivityToContribGridReconService.processPersonContractActivityToContribGridReconCommand(statusCalculationCommand);
					}

					// 23. Batch job to perform end to end reconciliation on employer activities.
					if (statusCalculationCommand.isEmployerActivityEndToEndReconCommand()) {
						logger.info("Call ProcessEmployerActivityEndToEndReconCommand ");
						logger.info("host name is  " + hostName);
						statusCalculationCommand.setHostName(hostName);
						employerActivityReconciliationService.processEmployerActivityReconciliationCommand(statusCalculationCommand);
					}

					// 24. Batch job to perform an archive and purge of person contract history records over to the person contract history archive table.
					if (statusCalculationCommand.isArchivePersonContractProgramHistoryCommand()) {
						logger.info("Call ProcessArchivePersonContractProgramHistoryCommand ");
						logger.info("host name is  " + hostName);
						statusCalculationCommand.setHostName(hostName);
						archivePersonContractProgramHistoryService.processArchivePersonContractProgramHistoryCommand(statusCalculationCommand);
					}

					// 25. Batch job for producing a detail report of the the person contract recycle table where action is needed against person contract and member statuses
					//     that changed and didn't meet tollgate rules.
					if (statusCalculationCommand.isPersonContractRecycleActionNeededReportCommand()) {
						logger.info("Call CreatePersonContractRecycleReportOnActionNeededStatusesCommand ");
						logger.info("host name is  " + hostName);
						statusCalculationCommand.setHostName(hostName);
						personContractRecycleReportService.createPersonContractRecycleReportOnActionNeededStatusesCommand(statusCalculationCommand);
					}

					// 26. Batch job to create activity events that are dependent on other activities taken.  Currently Vermeer
					// is the only employer group that is run through this process.  The process will create an employer sponsored activity to complete the
					// Qualification of the member on the contract as long as a prerequisite activity is already taken.
					if (statusCalculationCommand.isActivityEventCreationBasedOnPreconditionCommand()) {
						logger.info("Call ActivityEventCreationBasedOnActivityDependencyCommand ");
						logger.info("host name is  " + hostName);
						statusCalculationCommand.setHostName(hostName);
						activityEventCreationBasedOnPreconditionService.processActivityEventCreationBasedOnPrecondition(statusCalculationCommand);
					}
				}
			}


	}

	/**
	 * Core private method to calculate and update Program/Member/Contract
	 * status based on member and member's relative mebers.
	 * 
	 * It is been called passing personID as parameter. STEPS: 1. Find all
	 * business programs participating by this person.(current year/active
	 * programs) 2. Create BusinessProgramAdapter based on each program and add
	 * all to Collection of program adaptors. 3. Find all members(relatives
	 * spouse, dom including self) 4. Create MemberAdaptor for each member and
	 * add to Collection of MemberAdaptor s 5. Add relative members to each
	 * MemberAdaptor 6. find and add PackageSubgroupHistory to each
	 * MemberAdapter 7. execute Rules on these two collectios - memberAdapters
	 * and programAdapters 8. from the results, a)delete existing automatic
	 * exemptions b)Issue new automatic Memmber exemptions. c) Update member
	 * program status d) Udate member program contract status
	 *
	 */
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
			com.healthpartners.service.imfs.exception.BPMBusinessValidationException.class, BPMException.class })
	public void updateProgramStatusBasedOnMember(Integer personID)
			throws com.healthpartners.service.imfs.exception.BPMBusinessValidationException, BPMException,
			DataAccessException {
		

		if (personID == null || personID.intValue() == 0) {
			logger.info("updateProgramStatusBasedOnMember, No PersonID !!! returning..");
			// no calculation - return
			return;
		}
		
		Collection<BPMBusinessProgram> businessPrograms = null;
		Collection<MemberTO> members = new ArrayList<MemberTO>();
		// Collection<RuleAdapter> rules = new ArrayList<RuleAdapter>();
		// Collection<Object> facts = new ArrayList<Object>();
		// Map<String, Object> globals = new HashMap<String, Object>();
		Collection<MemberAdapter> memberAdapters = new ArrayList<MemberAdapter>();
		Collection<BusinessProgramAdapter> programAdapters = new ArrayList<BusinessProgramAdapter>();

	
		// String elapsedTime = null;
		// java.util.Date startDate = new java.util.Date();

		// Begin a transaction.
		// DefaultTransactionDefinition def = new
		// DefaultTransactionDefinition();
		// def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		// TransactionStatus status = txManager.getTransaction(def);

		try {
			logger.info("@@Start statusCalculation for personID=" + personID);
			//
			//		/ (1024 * 1024.0) + " MB");

			// Retrieve all business programs in which a member participates.
			businessPrograms = memberService.getParticipatingBusinessPrograms(personID);

			if (businessPrograms == null || businessPrograms.size() == 0) {
				logger
						.info("updateProgramStatusBasedOnMember, No Business programs for calculation!!! returning..");
				
			} else {

				// Create BusinessProgramAdapter based on each program and add
				// all to Collection of program adaptors.
				Iterator<BPMBusinessProgram> iter = businessPrograms.iterator();
				while (iter.hasNext()) {
					BPMBusinessProgram businessProgram = iter.next();
					programAdapters.add(createProgramAdapters(businessProgram));
				}

				// set Rule conditions
				// TODO: get rules based on program type -
				// now only healthy benefit rules - common
				// for all
				/*
				 * BusinessProgramTO businessProgram = new BusinessProgramTO();
				 * businessProgram.setBusinessProgram(new BusinessProgram());
				 * businessProgram.getBusinessProgram().setProgramTypeCodeID(
				 * BPMConstants.PROGRAM_TYPE_CODE_HEALTY_BENEFITS);
				 * 
				 * Collection<RuleAdapter> businessProgramRules =
				 * ruleGroupService
				 * .getAllRulesForStatusCalculation(businessProgram);
				 * rules.addAll(businessProgramRules);
				 */

				// Set the global object (from which we will retrieve results).
				RulesResultHelper results = new RulesResultHelper();
				// globals.put("rulesResultHelper", results);

				// Get all members that are related to this member including
				// self.
				members = getMembersForStatusCalculation(personID, businessPrograms);
				
				logger.info("----No of Members for Status Calculation = " + members.size());
				
				// If no members were returned, then don't run the calculation.
				if (members != null && members.size() > 0) {

					logger.info("@@related members including self="
							+ members.size());
					
					memberAdapters = createMemberAdapters(members, businessPrograms);
					
					// set type of risks, and riskgroups to each MemberAdapter
					setRiskAndRiskGroupDetails((ArrayList<MemberAdapter>) memberAdapters);

					// find and add PackageSubgroupHistory to each MemberAdapter
					findPackageSubgroupHistory((ArrayList<MemberAdapter>) memberAdapters);
					
					
					// Fire all rules.
					logger.info("@@@start - execute rules@@@");
					/*
					 * drools rules engine is taking around 10 seconds to
					 * process, and consuming around 20 MB memory, for now
					 * decided to run through java method which takes less than
					 * 1 second and no memory overhead. But for any good reasons
					 * to use drools, turn on that.
					 */
					// RulesEngineHelper.executeRules(rules, globals, facts);
					results = executeRules(programAdapters, memberAdapters);
					
					// From results, update Program/Member/Contract status
					// delete existing automatic exemptions
					qualificationOverrideService
							.deleteAutomaticMemberExemptions(results
									.getDeleteAutomaticExemptions());
					// Issue automatic Memmber exemptions.
					qualificationOverrideService.issueMemberExemption(results
							.getGeneratedExemptions());
					
					//EV 93292 - promotion postponed until passes QA 4/21/2016
					//HCEREWARD-252:  Reviewed this method call and looks like it is
					//				  not needed.
					/*memberService.updateMemberContractRecyclePerTollgateRules(results
							.getGeneratedMemberProgramStatuses(), results
							.getGeneratedMemberContractStatuses());
					*/
					
					// Update member program statuses.
					memberService.updateMemberProgramStatus(results
							.getGeneratedMemberProgramStatuses());

					// Update contract program statuses.
					memberService.updateMemberContractStatus(results
							.getGeneratedMemberContractStatuses());
										
					// Loop through the contract-based and member-based incentives.
					// Set the incentive-activation-status-code of the member udpate
					// to the activation status of the corresponding incentive-option.
					results.setIncentiveActivationStatusCodes();
					
					//EV84911 - Add person contract program history record when contract or member status changes.
					memberService.createPersonContractProgramHistory(results
							.getGeneratedMemberProgramStatuses(), results
							.getGeneratedMemberContractStatuses(), members);										
										
				
					if(results.getGeneratedMemberProgramIncentiveStatuses() != null)
					{
						for(MemberProgramIncentiveTO lMemberProgramIncentiveTO : results.getGeneratedMemberProgramIncentiveStatuses())
						{
						   businessProgramService.updateMemberProgramIncentive(lMemberProgramIncentiveTO);
						}
					}
					
					updateContractProgramIncentive(results);
					
					//EV76364
					updatePersonProgramActivityStatus(results);
					
					updatePersonActivityIncentive(results);
								
				}

			}
			
			//Perform status calculation for retro active activities taken during qualification period but after contract terms.
			clearStatCalcObjects(businessPrograms, members, memberAdapters, programAdapters);
			businessPrograms = memberService.getParticipatingBusinessProgramsWTermedContract(personID);
			
				
			// The block of code that follows only executes if a contract was ended within the persons eligibility.
			
			if (businessPrograms == null || businessPrograms.size() == 0) {
				logger
						.info("updateProgramStatusBasedOnMember, No Business programs for member incentive activity calculation!!! returning..");
			} else {								
				
				// Create BusinessProgramAdapter based on each program and add
				// all to Collection of program adaptors.
				Iterator<BPMBusinessProgram> iter = businessPrograms.iterator();
				while (iter.hasNext()) {
					BPMBusinessProgram businessProgram = iter.next();					
					programAdapters.add(createProgramAdapters(businessProgram));
				}
				
				// Get all members that are related to this member including
				// self.
				members = getMembersForStatusCalculation(personID, businessPrograms);
				
				logger.info("----No of Members WTermedContract for Status Calculation = " + members.size());
				
				// If no members were returned, then don't run the Member Activity Incentive Rules.
				if (members != null && members.size() > 0) {

					logger.info("@@related members including self="
							+ members.size());

					// Wrap person in BPMPersonMemberAdapter, assert to rules
					// engine.
					
					memberAdapters = createMemberAdapters(members, businessPrograms);
					// set type of risks, and riskgroups to each MemberAdapter
					setRiskAndRiskGroupDetails((ArrayList<MemberAdapter>) memberAdapters);
	
					// find and add PackageSubgroupHistory to each MemberAdapter
					findPackageSubgroupHistory((ArrayList<MemberAdapter>) memberAdapters);
					
					
					// Fire all rules.
					logger.debug("@@@start - execute rules@@@");
					/*
					 * drools rules engine is taking around 10 seconds to
					 * process, and consuming around 20 MB memory, for now
					 * decided to run through java method which takes less than
					 * 1 second and no memory overhead. But for any good reasons
					 * to use drools, turn on that.
					 */
					// RulesEngineHelper.executeRules(rules, globals, facts);
					RulesResultHelper results = executeRules(programAdapters, memberAdapters);										
					
					updateContractProgramIncentive(results);
					
					updatePersonActivityIncentive(results);										 
				
				}
				
			}
			
			// Commit the transaction.
			// txManager.commit(status);
		} catch (DataAccessException dae) 
		{
			logger.error("Exception thrown calculating status for prsn demog ID = " + personID);
			BPMUtils.logException(logger, dae);			
			throw dae;
		} catch (Exception e) {
			logger.error("Exception thrown calculating status for prsn demog ID = " + personID);
			BPMUtils.logException(logger, e);			
			throw new BPMException(e);
		} finally {
			clearStatCalcObjects(businessPrograms, members, memberAdapters, programAdapters);
			
			/*
			 * 
			 * Runtime.getRuntime().freeMemory() / (1024 * 1024.0) + " MB");
			 */
			// Runtime.getRuntime().gc();
			//
			//		/ (1024 * 1024.0) + " MB");

			// log time taken to process
			// java.util.Date endDate = new java.util.Date();
			// elapsedTime = BPMUtils.getTimeDifferenceAsString(startDate,
			// endDate);
			logger.info("@@End statusCalculation for personID=" + personID);
			// ", ..process duration:" + elapsedTime);
		}
	}
	
	private void clearStatCalcObjects(Collection<BPMBusinessProgram> businessPrograms, Collection<MemberTO> members, Collection<MemberAdapter>memberAdapters, Collection<BusinessProgramAdapter> programAdapters) {
		if (businessPrograms != null) {
			businessPrograms.clear();
			businessPrograms = null;
		}
		if (members != null) {
			members.clear();
			members = null;
		}
		/*
		 * if (rules != null) { rules.clear(); rules = null; } if (facts !=
		 * null) { facts.clear(); facts = null; } if (globals != null) {
		 * globals.clear(); globals = null; }
		 */
		if (memberAdapters != null) {
			memberAdapters.clear();
			memberAdapters = null;
		}
		if (programAdapters != null) {
			programAdapters.clear();
			programAdapters = null;
		}
	}
	
	private Collection<MemberTO> getMembersForStatusCalculation(Integer personID, Collection<BPMBusinessProgram> businessPrograms) throws Exception {
		Collection<MemberTO> members = new ArrayList<MemberTO>();
		Iterator<BPMBusinessProgram> businessProgramIterator = businessPrograms.iterator();
		while (businessProgramIterator.hasNext()) 
		{
			BPMBusinessProgram businessProgram = businessProgramIterator.next();
			try {
			    members.addAll(memberService
					.getMembersForStatusCalculation(personID, businessProgram));
			} catch (Exception e) {
				logger.error("An unexpected error has occured in getMembersForStatusCalculation: " + e.getMessage(),
						e);
				throw new Exception(e);
			}
		}
		
		return members;
	}
	
	private Collection<MemberAdapter> createMemberAdapters(Collection<MemberTO> members, Collection<BPMBusinessProgram> businessPrograms) throws Exception {
		
		Collection<MemberAdapter> memberAdapters = new ArrayList<MemberAdapter>();
		Iterator<MemberTO> membersIter = members.iterator();
		while (membersIter.hasNext()) {
			MemberTO member = membersIter.next();
			MemberAdapter adapter = new MemberAdapter(member);	  
			try {
				adapter.setCurrentDateTime(qualificationTimeService
					.getCurrentDate());
			} catch (Exception e) {
				logger.error("An unexpected error has occured in getMemberAdapters: " + e.getMessage(),
						e);
				throw new Exception(e);
			}
			
			memberAdapters.add(adapter);
			logger.info("@@member - MemberContractPrograms="
					+ adapter.getMember()
							.getMemberContractPrograms().size());																							
		}
		MemberAdapter memberAdapter = null;
		// add relative members
		Iterator<MemberAdapter> memberAdaptersIter = memberAdapters
				.iterator();
		while (memberAdaptersIter.hasNext()) {
			memberAdapter = memberAdaptersIter.next();
			
			// Find this member's program-incentive-activities (if any)
			Iterator<BPMBusinessProgram> thisBusinessProgramIterator = businessPrograms.iterator();
			while (thisBusinessProgramIterator.hasNext()) 
			{
				BPMBusinessProgram thisBusinessProgram = thisBusinessProgramIterator.next();
				
				if (thisBusinessProgram.getProgramID() == memberAdapter.getMember().getProgramID().intValue()) {
					// Sending a 0 for activity and actv_incentive ID will retrieve all activity-incentives
				    // for person and program.
				    memberAdapter.getPersonActivityIncentives().addAll(incentiveOptionDAO.getPersonActivityIncentives(memberAdapter.getId(),			
						thisBusinessProgram.getProgramID(),
		                 0, 0, null));
				    
				    //EV78853 begin
				    ContractTO lContractTO = memberAdapter.getMember().getMemberContract(thisBusinessProgram.getProgramID());	
					 Integer contractNo = null;
				    if (lContractTO != null) {
				    	if (lContractTO.getContract() != null) {
				    		contractNo = lContractTO.getContract().getContractNumber();
				    		//EV84334 - assign benefit contract type
				    		String benefitContractType = determineBenefitContractType(thisBusinessProgram.getProgramID(), contractNo);
				    		lContractTO.setBenefitContractType(benefitContractType);
				    	}
				    }
					    
					String contractNoStr = null;
					if (contractNo != null && contractNo.SIZE > 0) {
						contractNoStr = String.valueOf(contractNo);
					}
				    // Sending a 0 for activity and actv_incentive ID will retrieve all activity-incentives
				    // for person and program.  Pass in contract number to get all related participant incentives.
					// Note: Existing related person activity incentives is used within processing of activity based
					// incentives.
				    memberAdapter.getExistingRelatedPersonActivityIncentives().addAll(
						incentiveOptionDAO.getPersonActivityIncentives(memberAdapter.getId(),			
								thisBusinessProgram.getProgramID(),
		                         0, 0, contractNoStr));
				    //EV78853 end
				    
				    //EV84334 - Contribution Grid refactoring
				    
				    memberAdapter.getContractProgramIncentives().addAll(
							businessProgramService.getContractProgramIncentive(thisBusinessProgram.getProgramID(), null, contractNo));
				    
				    memberAdapter.getExistingRelatedMemberProgramIncentives().addAll(memberService.getRelatedMemberProgramIncentives(thisBusinessProgram.getProgramID(),			
							  contractNo, memberAdapter.getId()));
				    
				    memberAdapter.getMemberProgramIncentives().addAll(
						incentiveOptionDAO.getMemberProgramIncentive(thisBusinessProgram.getProgramID(),			
								 null, contractNo, memberAdapter.getId()));
				   
				    //EV84334 -end
				    
				    
				    if (incentiveOptionDAO.isActivityCompletionPeriodEnabled(thisBusinessProgram.getProgramID())) {
				    	memberAdapter.setActivityCompletionPeriodEnabled(true);
				    } else {
				    	memberAdapter.setActivityCompletionPeriodEnabled(false);
				    }
				    ArrayList<PersonPackage> personPackages = (ArrayList<PersonPackage>)personDAO.getPersonPackages(memberAdapter.getId(), thisBusinessProgram.getProgramID());
				    
				    if (personPackages.size() == 0) {
				    	personPackages = (ArrayList<PersonPackage>)personDAO.getPersonPackagesRetroTerms(memberAdapter.getId(), thisBusinessProgram.getProgramID());
				    }
				    
				    memberAdapter.getPersonPackages().addAll(personPackages);			    			    				         			    	            	            	           
				}//END if (thisBusinessProgram.getProgramID() == memberAdapter.getMember().getProgramID().intValue())
			}
			
			
			// Because each arraylist of MemberAdapters contains a person, and the relatives,
			// add the arraylist to the relatedMembers, but remove the "self" from the
			// relatedMembers arraylist.									
			Collection<MemberAdapter> relatedMembers = new ArrayList<MemberAdapter>();
			relatedMembers.addAll(memberAdapters);
			relatedMembers.remove(memberAdapter);
			memberAdapter.setRelatedMembers(relatedMembers);						
			
			// facts.add(memberAdapter);
		}
		
	
		
		return memberAdapters;
	}
	
	private BusinessProgramAdapter createProgramAdapters(BPMBusinessProgram businessProgram) throws Exception {
		
		BusinessProgramAdapter adapter = new BusinessProgramAdapter(
			businessProgram);
	    try {
			ArrayList<QualificationCheckmark> lQualificationCheckmarks = (ArrayList<QualificationCheckmark>) 
				businessProgramService.getQualificationCheckmarks(businessProgram.getProgramID());
			
			for(int i = 0; i < lQualificationCheckmarks.size(); i++)
			{
				int lQualificationCheckmarkID = lQualificationCheckmarks.get(i).getQualificationCheckmarkID();
				lQualificationCheckmarks.get(i).setCheckmarkRequirements((ArrayList<CheckmarkRequirement>)businessProgramService.getCheckmarkRequirements(lQualificationCheckmarkID));
				
				lQualificationCheckmarks.get(i).setParticipationGroup(
				    businessProgramService.getParticipationGroup(lQualificationCheckmarks.get(i).getParticipationGroupID()));
			}
			
			ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>)
			    businessProgramService.getProgramIncentiveOptions(businessProgram.getProgramID());
								
			for(int j = 0; j < lProgramIncentiveOptions.size(); j++)
			{				
				lProgramIncentiveOptions.get(j).setIncentiveRequirements((ArrayList<IncentiveRequirement>)
				    businessProgramService.getIncentiveRequirements(businessProgram.getProgramID()
				    		, lProgramIncentiveOptions.get(j).getIncentiveOption().getIncentiveOptionID()));
				
				
				lProgramIncentiveOptions.get(j).setParticipationGroup(businessProgramService.getParticipationGroup(lProgramIncentiveOptions.get(j).getParticipationGroupID()));
				//EV84334
				lProgramIncentiveOptions.get(j).setProgramContributionGrids(businessProgramService.getProgramContributionGrids(lProgramIncentiveOptions.get(j).getProgramIncentiveOptionID()));
				
				// Set the package rule group
				lProgramIncentiveOptions.get(j).setIncentivePackageRuleGroup(businessProgramService.getPackageRuleGroup(lProgramIncentiveOptions.get(j).getIncentivePackageRuleGroupID()));
			}	
			
			ArrayList<AuthCode> lExtendedAuthCodes = (ArrayList<AuthCode>) 
					businessProgramService.getExtendedAuthCodes(businessProgram.getProgramID());
			
			ArrayList<AuthCode> lEligibleAuthCodes = (ArrayList<AuthCode>) 
					businessProgramService.getEligibleAuthCodes(businessProgram.getProgramID());
			
			ArrayList<EligibleProgramActivity> lEligibleProgramActivities = (ArrayList<EligibleProgramActivity>) 
					businessProgramService.getEligibleProgramActivities(businessProgram.getProgramID());
			
			adapter.setQualificationCheckmarks(lQualificationCheckmarks);
			adapter.setProgramIncentiveOptions(lProgramIncentiveOptions);
			adapter.setExtendedAuthCodes(lExtendedAuthCodes);
			adapter.setEligibleAuthCodes(lEligibleAuthCodes);
			adapter.setEligibleProgramActivities(lEligibleProgramActivities);
			
			logger.info("@@member - BusinessProgram ID ="
					+ adapter.getId());
			
			
	    } catch (Exception e) {
			// Rollback the transaction on error.
			// txManager.rollback(status);

			logger.error("An unexpected error has occured in getProgramAdapters: " + e.getMessage(),
					e);
			throw new Exception(e);
		}
	    
	    return adapter;
	}
	
	/**
	 * Update contract program incentive. A row is inserted for contract program incentive upon creation of 
	 * person program status. Once the contract incentive is achieved, that row is updated.
	 * 
	 * 03-29-2013 EV 66735 - Set the Contract Status Achieved Date only when the status goes from
	 * the initial not-achieved to achieved.
	 * 
	 * @param results
	 * @throws Exception
	 */
	private void updateContractProgramIncentive(RulesResultHelper results) throws Exception {
		ArrayList<ContractProgramIncentiveTO> lContractProgramIncentives = (ArrayList<ContractProgramIncentiveTO>)
			    results.getGeneratedContractIncentiveStatuses();					
		for(ContractProgramIncentiveTO lContractProgramIncentive : lContractProgramIncentives)
		{
			String lNewStatus = lContractProgramIncentive.getContractIncentiveStatusCode();
			String lCurrentStatus = "";
			
			ArrayList<ContractProgramIncentiveTO> lExistingContractProgramIncentiveList = (ArrayList<ContractProgramIncentiveTO>)
			    businessProgramService.getContractProgramIncentive(lContractProgramIncentive.getBusinessProgramID()
					, lContractProgramIncentive.getIncentiveOptionID()
					, lContractProgramIncentive.getContractNo());
			
			if(lExistingContractProgramIncentiveList.size() > 0)
			{
				lCurrentStatus = lExistingContractProgramIncentiveList.get(0).getContractIncentiveStatusCode();
				if (lContractProgramIncentive.getContractProgramStatusID() == null) {
					Integer contractProgramStatusID = lExistingContractProgramIncentiveList.get(0).getContractProgramStatusID();
					lContractProgramIncentive.setContractProgramStatusID(contractProgramStatusID);
				}
			}
						
		    businessProgramService.updateContractProgramIncentive(lContractProgramIncentive);
		    
		    if(BPMConstants.BPM_CONTRACT_INCENTIVE_ACHIEVED.equals(lNewStatus))
		    {		  
		    	Integer lMetQualificationCheckmarkID = 0;
		    			    	
		    	// -------------------------------------------------
		    	// EV 58085 - Assign Checkmarks to Incentive Options.
		    	// -------------------------------------------------
		    	// Update qualification checkmark for the persons on the contract.
		    	Collection<MemberProgramUpdateTO> lMemberProgramStatuses = results.getGeneratedMemberProgramStatuses();		    			    			    
		    	
		    	for(MemberProgramUpdateTO lMemberProgramStatus : lMemberProgramStatuses)
		    	{		    			
		    		if(lMemberProgramStatus.getProgramIncentiveOptionID().intValue() == lContractProgramIncentive.getProgramIncentiveOptionID().intValue())
		    		{
		    			lMetQualificationCheckmarkID = lMemberProgramStatus.getQualificationCheckmarkID();
			    		personDAO.updatePersonQualificationCheckmark(lMemberProgramStatus.getPersonID()
					            , lMemberProgramStatus.getProgramID()
					            , lContractProgramIncentive.getProgramIncentiveOptionID()
					            , lMetQualificationCheckmarkID);
			    		
			    		contractDAO.updateMemberContractStatus(lMemberProgramStatus.getProgramIncentiveOptionID(), lMemberProgramStatus.getProgramID(), lContractProgramIncentive.getContractNo()
			    				, BPMConstants.CONTRACT_STATUS_QUALIFIED, BPMConstants.BPM_USER_SYSTEM);
			    		
			    		lContractProgramIncentive.setQualificationCheckmarkID(lMetQualificationCheckmarkID);
		    		}
		    	}
		    	// -------------------------------------------------
		    	// EV 58085 - Assign Checkmarks to Incentive Options.
		    	// -------------------------------------------------
		    }
		    
		    // EV 95424 - If the status is achieved, set the activation status of 
		    // this incentive option to Acitve. Otherwise to Inactive.
		    if(BPMConstants.BPM_CONTRACT_INCENTIVE_ACHIEVED.equals(lNewStatus))
		    {
		    	lContractProgramIncentive.setActivationStatusCode(BPMConstants.PROGRAM_INCENTIVE_OPTION_ACTIVATION_ACTIVE);
		    }		    
		    // 95424 
		    
		    incentiveOptionDAO.updateContractProgramIncentive(lContractProgramIncentive);
		    
		    boolean lSetToNull = false;
		    // EV 66735
		    // If the status has changed from did-not-achieve to achieved, set the date.		    
		    if(BPMConstants.BPM_CONTRACT_INCENTIVE_ACHIEVED.equals(lNewStatus))
		    {
		    	lSetToNull = false;		    	
		    }
		    
		    if(BPMConstants.BPM_CONTRACT_INCENTIVE_NOT_ACHIEVED.equals(lNewStatus))
		    {
		    	// If the status is NOT_ACHIEVED, set the achieved date to null.
		    	lSetToNull = true;
		    }
		    
		    if(BPMConstants.BPM_CONTRACT_INCENTIVE_NOT_ACHIEVED.equals(lCurrentStatus)
		    		&& (lNewStatus == null || BPMConstants.BPM_CONTRACT_INCENTIVE_NOT_ACHIEVED.equals(lNewStatus)))
		    {
		    	// If the status is NOT_ACHIEVED, set the achieved date to null.
		    	lSetToNull = true;
		    }
		    
		    // Update the date.
	    	incentiveOptionDAO.setContractIncentiveAchievedDate(lContractProgramIncentive.getBusinessProgramID()
	    			, lContractProgramIncentive.getIncentiveOptionID()
	    			, lContractProgramIncentive.getContractNo()
	    			, lSetToNull);
		   
		}

	}
	/*
	 * EV76364
	 * Update to person program activity status if activity taken is for a completed Tobacco Cessation program that
	 * may or may not have been completed during the alotted time period.  Outcome field will contain achieved or not achieved. 
	 */
	private void updatePersonProgramActivityStatus(RulesResultHelper results) throws Exception {
		
		ArrayList<ActivityEvent> lPersonProgramActivityStatusCompleters = (ArrayList<ActivityEvent>)
				results.getPersonProgramActivityStatusCompleters();
		if (lPersonProgramActivityStatusCompleters != null && lPersonProgramActivityStatusCompleters.size() > 0) {
			for(ActivityEvent lActivityEvent : lPersonProgramActivityStatusCompleters)
			{

				try {
					activityDAO.updateMemberActivity(lActivityEvent);
					
					} catch (Exception e) {
						// Rollback the transaction on error.
						// txManager.rollback(status);
				
						logger.error("An unexpected error has occured in updatePersonProgramActivityStatus: " + e.getMessage(), e);
						throw new Exception(e);
				}
			}	
		}

		ArrayList<ActivityEvent> lPersonProgramActivityStatusNonCompleters = (ArrayList<ActivityEvent>)
				results.getPersonProgramActivityStatusNonCompleters();
		if (lPersonProgramActivityStatusNonCompleters != null && lPersonProgramActivityStatusNonCompleters.size() > 0) {
		for(ActivityEvent lActivityEvent : lPersonProgramActivityStatusNonCompleters)
		{
			
			try {
				activityDAO.updateMemberActivity(lActivityEvent);
				
				} catch (Exception e) {
					// Rollback the transaction on error.
					// txManager.rollback(status);
			
					logger.error("An unexpected error has occured in updatePersonProgramActivityStatus: " + e.getMessage(), e);
					throw new Exception(e);
				}
			}
		}
	}

	private void updatePersonActivityIncentive(RulesResultHelper results) throws Exception {
		ArrayList<PersonActivityIncentive> lPersonActivityIncentives = (ArrayList<PersonActivityIncentive>)
	    												results.getPersonActivityIncentives();
		for(int i = 0; i < lPersonActivityIncentives.size(); i++)
		{
			Integer programID = lPersonActivityIncentives.get(i).getBusinessProgramID();
			Integer contractNo = lPersonActivityIncentives.get(i).getContractNo();
			String benefitContractType = determineBenefitContractType(programID, contractNo);
			lPersonActivityIncentives.get(i).setBenefitContractType(benefitContractType);
			try {
				businessProgramService.updatePersonActivityIncentive(lPersonActivityIncentives.get(i), BPMConstants.BPM_USER_SYSTEM);
			} catch (Exception e) {
				// Rollback the transaction on error.
				// txManager.rollback(status);

				logger.error("An unexpected error has occured in updatePersonActivityIncentive: " + e.getMessage(),
						e);
				throw new Exception(e);
			}
		}					
	}
		
	
	public String determineBenefitContractType(Integer programID, Integer contractNo ) throws DataAccessException {
		String benefitContractType = BPMConstants.BEN_CON_TYPE_UNRESOLVED;
		
		
		try {
			
			Collection<MemberUpdate> lMemberUpdate = contractDAO.getBPMMembersForProgramContractV2(contractNo, programID);
			benefitContractType = resolveToBenefitCoverageType(lMemberUpdate);
			
		} catch (DataAccessException dae) {
			logger
			.error("An unexpected error has occured in determineBenefitCoverageType: "
					+ dae.getMessage(), dae);
			throw dae;
		}
		
		if (benefitContractType.equals(BPMConstants.BEN_CON_TYPE_UNRESOLVED)) {
			logger
			.error("An unexpected error has occured in determineBenefitCoverageType.  BenefitContractType went unresolved.  Will impact CDHP feeds by not sending a contribution.");
			logger
			.error("Key used for the lookup: Contract is " + contractNo + " Business Program is " + programID);
			logger
			.error("Method call made at contractDAO.getBPMMembersForProgramContract18YrsNOlder");
			
		
		}

		return benefitContractType;
	}

	private void setTopicMessageToKickstartETLMembershipUpdateMultiProcessing() {

	}
	/*
	 * Resolve to Policy Holder, PH + Spouse, PH +1, PH + Family, PH + Family No Spouse (FAMILY - all based on the number of family members)
	 * AND DEPENDENT_ONLY
	 * on the contract outside of being a PH or Spouse.)
	*/
	private	String resolveToBenefitCoverageType(Collection<MemberUpdate> lMembersUpdate) {
		Integer familyMemberCount = lMembersUpdate.size();
		boolean policyHolderExists = false;
		boolean spouseExists = false;
        boolean domesticPartnerExists = false;
		String benefitContractType = BPMConstants.BEN_CON_TYPE_UNRESOLVED;
		Iterator<MemberUpdate> iter = (Iterator<MemberUpdate>)lMembersUpdate.iterator();
		while (iter.hasNext()) {
			MemberUpdate lMemberUpdate = (MemberUpdate)iter.next();
			//PH
			if (lMemberUpdate.getRelationshipID().equals(BPMConstants.RELSHP_SELF)) {
						benefitContractType = BPMConstants.BEN_CON_TYPE_SELF;
						policyHolderExists = true;
			//PH and Spouse
			} else if (lMemberUpdate.getRelationshipID().equals(BPMConstants.RELSHP_SPOUSE)) {
				benefitContractType = BPMConstants.BEN_CON_TYPE_SELF_SPOUSE;
				spouseExists = true;
				//PH
			} else if (lMemberUpdate.getRelationshipID().equals(BPMConstants.RELSHP_SELF)) {
					benefitContractType = BPMConstants.BEN_CON_TYPE_SELF;
					policyHolderExists = true;
            } else if (lMemberUpdate.getRelationshipID().equals(BPMConstants.RELSHP_DOM_PARTNER)) {
                benefitContractType = BPMConstants.BEN_CON_TYPE_SELF_DOM;
                domesticPartnerExists = true;
			//PH and dependent only (Self plus 1)
			} else if (policyHolderExists && !spouseExists && !domesticPartnerExists && familyMemberCount == 2) {
						benefitContractType = BPMConstants.BEN_CON_TYPE_SELF_PLUS_1;
		    //PH and family
            } else if (policyHolderExists && spouseExists && familyMemberCount > 2) {
                benefitContractType = BPMConstants.BEN_CON_TYPE_SELF_PLUS_FAMILY;
			} else if (policyHolderExists && domesticPartnerExists && familyMemberCount > 2) {
				benefitContractType = BPMConstants.BEN_CON_TYPE_SELF_PLUS_FAMILY;
			//PH and family with no spouse can include domestic partner
			} else if (policyHolderExists && !spouseExists && !domesticPartnerExists && familyMemberCount > 2) {
						benefitContractType = BPMConstants.BEN_CON_TYPE_SELF_FAM_NO_SP;
			} else if (lMemberUpdate.getRelationshipID().equals(BPMConstants.RELSHP_DEPENDENT)) {
						benefitContractType = BPMConstants.BEN_CON_TYPE_BEN_CON_DEP;
			}


		}
		
		return benefitContractType;
	}

	/**
	 * Custom method to run rules on each MemberAdapter and
	 * BusinessProgramAdapter and return results. Rules: 
	 * 
	 * 1.Start Loop Collection<BusinessProgramAdapter>
	 * 
	 * 2. Inner Loop Collection<MemberAdapter> memberAdapters
	 * 
	 * 3. find member eligible for program
	 * 
	 * 4. mark for delete existing automatic exemptions
	 * 
	 * 5. find MemberExemptionChanging, if true add exemptions to results
	 * 
	 * 6. find MemberStatusChanging, if true, add member status to results
	 * 
	 * 7. find ContractStatusChanging, if true, add contract status to results
	 * 
	 * @return RulesResultHelper results after firing rules
	 * 
	 * NOTE: drools rules engine is taking around 10 seconds to process for
	 * single member, and consuming around 20 MB memory, for now decided to run
	 * through java method which takes less than 1 second and no memory
	 * overhead. But for any good reasons to use drools, turn on that.
	 */
	private RulesResultHelper executeRules(
			Collection<BusinessProgramAdapter> programAdapters,
			Collection<MemberAdapter> memberAdapters) {
		
		RulesResultHelper results = new RulesResultHelper();

		if (programAdapters != null && memberAdapters != null) {
			// loop throgh each program
			Iterator<BusinessProgramAdapter> itrProg = programAdapters
					.iterator();
			while (itrProg.hasNext()) {
				BusinessProgramAdapter programAdapter = itrProg.next();
								
				determineTermedAndExecuteRules(programAdapter,
						memberAdapters,
						results);			
			} // each prog
		} // end if progr and members

		return results;
	}
	
	/**
	 * Determine if the contract has termed. If so, call executeContractTermActivityIncentiveRules.
	 * If the contract is still in effect, call the rules engine corresponding to the program type code.
	 * 
	 * @param programAdapter
	 * @param memberAdapters
	 * @param results
	 */
	private void determineTermedAndExecuteRules(BusinessProgramAdapter programAdapter,
			Collection<MemberAdapter> memberAdapters,
			RulesResultHelper results)
	{		
		Calendar lToday = Calendar.getInstance();
		BPMUtils.setTimeToZero(lToday);
		
		Collection<ProgramIncentiveOption> saveProgramIncentiveOptions = new ArrayList<ProgramIncentiveOption>();
		Map<Integer, MemberProgramIncentiveTO> memberBasedIncentiveStatusMapRelated = new HashMap<Integer, MemberProgramIncentiveTO>();
		
		
		Iterator<MemberAdapter> itrMemb = memberAdapters.iterator();
		// loop throgh each member
		while (itrMemb.hasNext()) 
		{
			//EV68617 
			if (saveProgramIncentiveOptions.isEmpty()) {
				//first time through save incentive options since same programAdapter is used across multiple member adapters.
				//Program Incentive Options can be manipulated by the business rules for each member going through status calc.
				saveProgramIncentiveOptions.addAll(programAdapter.getProgramIncentiveOptions());
			} else {
				Collection<ProgramIncentiveOption> copyProgramIncentiveOptions = copyProgramIncentiveOptions(saveProgramIncentiveOptions);
				programAdapter.setProgramIncentiveOptions(copyProgramIncentiveOptions);
			}
			
			
			MemberAdapter memberAdapter = itrMemb.next();

			//BPM-291 added condition to ensure program adapter and member adapter program id's match before executing rules.
			if (programAdapter.getBusinessProgramId().intValue() == memberAdapter.getMember().getProgramID()) {

				// EV 58085
				// Initialize MemberAdapter
				initializeMemberAdapterIncentiveStatuses(memberAdapter, programAdapter);
				// EV 58085

				if (memberAdapter.getMember().getContractEndDateOfMember(programAdapter.getBusinessProgramId()) != null) {
					BPMUtils.setTimeToZero(memberAdapter.getMember().getContractEndDateOfMember(programAdapter.getBusinessProgramId()));
				}

				// If the contract end date is today or before, the contract has termed.
				if (memberAdapter.getMember().getContractEndDateOfMember(programAdapter.getBusinessProgramId()) != null
						&& !memberAdapter.getMember().getContractEndDateOfMember(programAdapter.getBusinessProgramId()).after(lToday)) {
					executeContractTermActivityIncentiveRules(programAdapter, memberAdapter, results);
				}
				// find member eligible for program
				if (memberAdapter.isEligibleForBusinessProgram(programAdapter)) {
					//Consider all active program types if termed contract exists when evaluating retro activities.
					if (BPMConstants.PROGRAM_TYPE_CODE_HEALTY_BENEFITS.equals(programAdapter.getBusinessProgramTypeCodeId()) ||
							BPMConstants.PROGRAM_TYPE_CODE_JOURNEYWELL.equals(programAdapter.getBusinessProgramTypeCodeId()) ||
							BPMConstants.PROGRAM_TYPE_CODE_OTHERWELLNESS.equals(programAdapter.getBusinessProgramTypeCodeId())
					) {
						executeHealthyBenefitsRules(programAdapter, memberAdapter, results);

					} else if (BPMConstants.PROGRAM_TYPE_CODE_SMART_STEPS.equals(programAdapter.getBusinessProgramTypeCodeId())) {
						executeSmartStepsRules(programAdapter, memberAdapter, results);
					} else if (BPMConstants.PROGRAM_TYPE_CODE_HIP.equals(programAdapter.getBusinessProgramTypeCodeId())) {
						executeHIPRules(programAdapter, memberAdapter, results);

					} else if (BPMConstants.PROGRAM_TYPE_CODE_NEW_JOURNEYWELL.equals(programAdapter.getBusinessProgramTypeCodeId())
							|| BPMConstants.PROGRAM_TYPE_CODE_JOURNEYWELL_4.equals(programAdapter.getBusinessProgramTypeCodeId())
							|| BPMConstants.PROGRAM_TYPE_CODE_OCTAVIUS.equals(programAdapter.getBusinessProgramTypeCodeId())
							|| BPMConstants.BPM_SMALL_GROUP_TP.equalsIgnoreCase(programAdapter.getBusinessProgram().getSmallGroupType())) {

						if (memberBasedIncentiveStatusMapRelated.size() > 0) {
							Collection<MemberProgramIncentiveTO> lMemberProgramIncentiveTOs = memberBasedIncentiveStatusMapRelated.values();
							memberAdapter.getExistingRelatedMemberProgramIncentives().addAll(lMemberProgramIncentiveTOs);
						}
						executeNewJourneyWellRules(programAdapter, memberAdapter, results);
						//in order to count pending activities taken across a contract, set aside what has
						//been incented already to be used in the next memberAdapter object which helps drive
						//member based capping rules.
						memberBasedIncentiveStatusMapRelated.putAll(memberAdapter.getMemberBasedIncentiveStatusMap());
					}
				}
			}
		}
	}
	/*
	 * This method added in order to make a copy of the original program incentive options so that it can be reassigned back to the programAdapter
	 * for the next person to be processed through status calculation.  Without this method, program incentive options could be compromised by the
	 * previous participant.
	 */
	private Collection<ProgramIncentiveOption> copyProgramIncentiveOptions(Collection<ProgramIncentiveOption> saveProgramIncentiveOptions) {
		ArrayList<ProgramIncentiveOption> copyProgramIncentiveOptionsAL = new ArrayList<ProgramIncentiveOption>();
		
		copyProgramIncentiveOptionsAL.addAll(saveProgramIncentiveOptions);
		
		return copyProgramIncentiveOptionsAL;
	}
	
	/**
	 * Execute business rules for the Healthy Benefits program.
	 * 
	 * @param programAdapter
	 * @param memberAdapter
	 * @param results
	 */
	private void executeHealthyBenefitsRules(
			BusinessProgramAdapter programAdapter,
			MemberAdapter memberAdapter,
			RulesResultHelper results)
	{
		// mark for delete existing automatic exemptions
		results.markForDeleteAutomaticMemberExemptions(
				memberAdapter, programAdapter);

		// add automatic exemptions
		if (memberAdapter
				.isMemberExemptionChanging(programAdapter)) {
			results.changeMemberExemption(memberAdapter,
					programAdapter);
		}

		logger.info("In executeHealthyBenefitsRules, calling isMemberStatusChangingWithinHealthyBenefits.");
		// member status
		if (memberAdapter
				.isMemberStatusChangingWithinHealthyBenefits(programAdapter)) {
			results.changeMemberStatus(memberAdapter,
					programAdapter);
		}

		// contract status
		if (memberAdapter
				.isContractStatusChanging(programAdapter)) {
			results.changeContractStatus(memberAdapter,
					programAdapter);
		}
		
		if (memberAdapter
				.isContractIncentiveStatusChanging(programAdapter)) {
			results.changeContractIncentiveStatus(memberAdapter,
					programAdapter);
		}
		
		//EV76364
		results.changePersonProgramActivityStatus(memberAdapter, programAdapter);
		
		results.changePersonActivityIncentives(memberAdapter, programAdapter);
		
		memberAdapter.checkIncentiveOptions(programAdapter);
		results.changePersonActivityIncentives(memberAdapter, programAdapter);
	}
		
	
	/**
	 * Execute business rules for the New Journey Well program.
	 * 
	 * @param programAdapter
	 * @param memberAdapter
	 * @param results
	 */
	private void executeNewJourneyWellRules(
			BusinessProgramAdapter programAdapter,
			MemberAdapter memberAdapter,
			RulesResultHelper results)
	{		
			// mark for delete existing automatic exemtions
			results.markForDeleteAutomaticMemberExemptions(memberAdapter, programAdapter);

			// add automatic exemptions
			if (memberAdapter.isMemberExemptionChanging(programAdapter)) {
				results.changeMemberExemption(memberAdapter,programAdapter);
			}															
			
			// Check Qualification Checkmarks for each biz pgm incentive option.
			// Member will have a status for each biz pgm incentive option.			
			memberAdapter.checkQualificationCheckmarks(programAdapter);						
			
			// member status
			//if (memberAdapter.isMemberStatusChangingWithinHealthyBenefits(programAdapter))
			//{
				results.changeMemberStatus(memberAdapter,programAdapter);
			//}
						
			if(memberAdapter.isMemberIncentiveStatusChanging(programAdapter))
			{
				// MEMBER_BASED incentives.				
				results.changeMemberProgramIncentiveStatus(memberAdapter,programAdapter);			
			}						
						
			// contract status
			if (memberAdapter.isContractStatusChanging(programAdapter)) {
				results.changeContractStatus(memberAdapter,programAdapter);
			}
			
			if (memberAdapter.isContractIncentiveStatusChanging(programAdapter)) {
				results.changeContractIncentiveStatus(memberAdapter,programAdapter);
			}
			
			
			//EV76364
			results.changePersonProgramActivityStatus(memberAdapter, programAdapter);
			
			results.changePersonActivityIncentives(memberAdapter, programAdapter);
			
			memberAdapter.checkIncentiveOptions(programAdapter);
			results.changePersonActivityIncentives(memberAdapter, programAdapter);					
	}
	
	
	
	/**
	 * EV 46192 - Execute business rules where retroactive activities with termed contracts are being processed.
	 * 
	 * @param programAdapter
	 * @param memberAdapter
	 * @param results
	 */
	private void executeContractTermActivityIncentiveRules(
			BusinessProgramAdapter programAdapter,
			MemberAdapter memberAdapter,
			RulesResultHelper results)
	{		
		// find member eligible for program
		if (memberAdapter
				.isEligibleForBusinessProgram(programAdapter)) {
			
			memberAdapter.checkIncentiveOptions(programAdapter);
			results.changePersonActivityIncentives(memberAdapter, programAdapter);
		}		
	}
	
	
	/**
	 * Execute business rules for the Smart Steps program.
	 * 
	 * @param programAdapter
	 * @param memberAdapter
	 * @param results
	 */
	private void executeSmartStepsRules(
			BusinessProgramAdapter programAdapter,
			MemberAdapter memberAdapter,
			RulesResultHelper results)
	{					
            //	member status
			if (memberAdapter.isMemberStatusChangingWithinSmartSteps(programAdapter)) 
			{
				results.changeMemberStatus(memberAdapter, programAdapter);
			}
			
			results.changeSmartStepsContractStatus(memberAdapter, programAdapter);
			
			if (memberAdapter
					.isContractIncentiveStatusChanging(programAdapter)) {
				results.changeContractIncentiveStatus(memberAdapter,
						programAdapter);
			}
			
			memberAdapter.checkIncentiveOptions(programAdapter);
			results.changePersonActivityIncentives(memberAdapter, programAdapter);			
	}
	
	/**
	 * Execute business rules for the Health Improvement Program.
	 * 
	 * @param programAdapter
	 * @param memberAdapter
	 * @param results
	 */
	private void executeHIPRules(
			BusinessProgramAdapter programAdapter,
			MemberAdapter memberAdapter,
			RulesResultHelper results)
	{					
        //	member status
		if (memberAdapter.isMemberStatusChangingWithinHIP(programAdapter)) 
		{
			results.changeMemberStatus(memberAdapter, programAdapter);
		}
		
        // contract status
		if (memberAdapter.isContractStatusChanging(programAdapter)) 
		{
			results.changeContractStatus(memberAdapter, programAdapter);
		}
		if (memberAdapter.isContractIncentiveStatusChanging(programAdapter)) 
		{
			results.changeContractIncentiveStatus(memberAdapter, programAdapter);
		}
		
		memberAdapter.checkIncentiveOptions(programAdapter);
		results.changePersonActivityIncentives(memberAdapter, programAdapter);			
	}

	/**
	 * membership update batch process
	 * 
	 * @param statusCalculationCommand
	 * @throws BPMException
	 */
	private void processEtlMembershipUpdateCommand(
			StatusCalculationCommand statusCalculationCommand)
			throws BPMException {					
		// text/ label
		statusCalculationCommand.setCurrentCommandText("Etl Membership Update");

		// set current command to fetch processID
		statusCalculationCommand
				.setCurrentProcessingCommand(StatusCalculationCommand.ETL_MEMBERSHIP_UPDATE);

		logger.info("@@Start - Batch Etl Membership Update ...");
		// start processing command
		processBatchMembersForCommand(statusCalculationCommand);		
		logger.info("@@End - Batch Etl Membership Update ...");

		// finished, reset current command to null
		statusCalculationCommand.resetCurrentProcessingCommand();
	}

	
	/**
	 * Process only updates from membership (MODS). Do not perform status calculation so to make this
	 * process a bit faster.
	 * 
	 * @param statusCalculationCommand
	 * @throws BPMException
	 */
	//Comment out for story BPM-343.
//	private void processEtlMembershipUpdateOnlyCommand(StatusCalculationCommand statusCalculationCommand)
//	throws BPMException
//	{
//		// text/ label
//		statusCalculationCommand.setCurrentCommandText("Etl Membership-Update-Only");
//
//		// set current command to fetch processID
//		statusCalculationCommand.setCurrentProcessingCommand(StatusCalculationCommand.ETL_MEMBERSHIP_UPDATE_ONLY);
//
//		logger.info("@@Start - Batch Etl Membership-Update-Only...");
//		// start processing command
//
//		processBatchMembersOnly(statusCalculationCommand);
//
//		logger.info("@@End   - Batch Etl Membership-Update-Only ...");
//
//		// finished, reset current command to null
//		statusCalculationCommand.resetCurrentProcessingCommand();
//	}
//

	/**
	 * Elapsed Time batch process(hold for contact, qualification end
	 * datereached)
	 * 
	 * @param statusCalculationCommand
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	private void processElapsedTimeCommand(StatusCalculationCommand statusCalculationCommand)
	throws BPMException, DataAccessException 
	{
		
		//Find everyone that is not in the person program status table whose 18th birthday 
		//is here and and insert a row for them in the person program status table to be eligible for 
		//taking programs.  Also, sets the contract program statuses to NOT_APPLICABLE in a separate insert query.
		insertPersonProgramStatus18YearOldsForIncentiveOptionByProgramType(BPMConstants.PROGRAM_TYPE_CODE_SMART_STEPS, BPMConstants.INCENTIVE_OPTION_TYPE_NAME_SMARTSTEPS);
		insertPersonProgramStatus18YearOldsForIncentiveOptionByProgramType(BPMConstants.PROGRAM_TYPE_CODE_EZPLAN, BPMConstants.INCENTIVE_OPTION_TYPE_NAME_SMARTSTEPS);
		
		// text/label
		statusCalculationCommand.setCurrentCommandText("Member Elapsed Time");

		// set current command to fetch processID
		statusCalculationCommand
				.setCurrentProcessingCommand(StatusCalculationCommand.MEMBER_ELAPSED_TIME);
		statusCalculationCommand.setProcessIDForMemberElapsedTimeCommand(BPMConstants.ETL_MEMBERSHIP_UPDATE_PRCS_ID);	
		statusCalculationCommand.setUserID(BPMConstants.BPM_PROCESS_MEMBER_ELIGIBLE_BEYOND_QUALIFICATION_PERIOD);
		
		logger.info("@@Start - Batch Member Elapsed Time ...");	
		logger.info("@@        Identify and mark members who's status is still set to ELIGIBLE");	
		logger.info("@@        beyond the business programs qualification period.");
		processMemberElapsedTimes(statusCalculationCommand);		
		processBatchMembersForCommand(statusCalculationCommand);
		logger.info("@@End  - Batch Member Elapsed Time ...");
		
		logger.info("@@Start - Batch Member Update for past contract end dates.");		
		// Set up command for membership Update.
		statusCalculationCommand.setCurrentProcessingCommand(StatusCalculationCommand.MEMBER_ELAPSED_TIME);
		statusCalculationCommand.setProcessIDForMemberElapsedTimeCommand(BPMConstants.ETL_MEMBERSHIP_UPDATE_PRCS_ID);
        statusCalculationCommand.setUserID(BPMConstants.BPM_PROCESS_PAST_CONTRACT_END_DATES);
        
     // Insert-Select past contract end dates into processing status log table.
	    int numberOfPersonsWithContractEnds = insertProcessingStatusLogForPastContractEndDates();
	    logger.info("@@Number of persons with termed contracts to be reprocessed " + numberOfPersonsWithContractEnds);	
        processBatchMembersForCommand(statusCalculationCommand);
        logger.info("@@End  - Batch Member Update for past contract end dates.");

		// finished, reset current command to null
		statusCalculationCommand.resetCurrentProcessingCommand();
	}
	
	/** Check for the combination of a completed and active or cancel activity that came in at the same time.
	*   Why does this need to be done? because the first activity event picked up will be the one that gets
	*   processed.  So if the active activity is processed after the completed, the member contract status will
	*   not change to QUALIFIED.  So the method call will check for this scenerio and if true, change the 
	*   insert_ts to a minute ahead.
	*   Within this same method a call is made to another method to adjust Time Stamp of Completed activity if ACTIVE or CANCEL came in at same time.
	*/
	
	private int processCompleteActivityEventsSentInAtSameTimeAsActiveOrCancel()
			throws BPMException, DataAccessException {
	
		int numberOfActivityEventTSUpdates = activityEventLogDAO.processCompleteActivityEventsSentInAtSameTimeAsActiveOrCancel();
		
		return numberOfActivityEventTSUpdates;
	}

	/**
	 * Member status calculation batch process
	 * 
	 * @param statusCalculationCommand
	 * @throws BPMException
	 */
	private void processMembersReCalculationCommand(
			StatusCalculationCommand statusCalculationCommand)
			throws BPMException {

		statusCalculationCommand
				.setCurrentCommandText("Members Re Calculation");

		// set current command to fetch processID
		statusCalculationCommand
				.setCurrentProcessingCommand(StatusCalculationCommand.MEMBERS_RECALCULATION);

		logger.info("@@Start - Batch Members Re Calculation ...");
		processBatchMembersForCommand(statusCalculationCommand);
		logger.info("@@End - Batch Members Re Calculation ...");

		// finished, reset current command to null
		statusCalculationCommand.resetCurrentProcessingCommand();
	}

	/**
	 * Purge Group Basline History table by date batch process()
	 * Cutoff date for purging is controlled through the LUV table.
	 *
	 * @param statusCalculationCommand
	 * @throws BPMException
	 * @throws DataAccessException
	 */

	private void processPurgeGroupBaselineHistCommand(
			StatusCalculationCommand statusCalculationCommand)
			throws BPMException, DataAccessException {

		Integer groupBaselineHistCountBefore = null;
		Integer deletedRecs = null;
		Integer groupBaselineHistCountAfter = null;

		String failureReason = null;
		String elapsedTime = null;
		java.util.Date startDate = new java.util.Date();
		java.util.Date endDate = null;
		java.sql.Date purgeDate = null;

		// text/label
		statusCalculationCommand.setCurrentCommandText("Purge Employer Group Baseline Table");

		// set current command to fetch processID
		statusCalculationCommand
				.setCurrentProcessingCommand(StatusCalculationCommand.PURGE_GROUPBASELINEHIST_TABLE);

		logger.info("@@Start - Batch Purge Employer Group Baseline History Table ...");

		try {
			groupBaselineHistCountBefore = getGroupBaselineHistCount();

			purgeDate = getPurgeDate(BPMConstants.PURGE_GROUPBASELINEHIST_TABLE_MONTHTOKEEP);

			deletedRecs = purgeGroupBaselineHist(purgeDate);
			groupBaselineHistCountAfter = getGroupBaselineHistCount();

		} catch (Exception e) {
			failureReason = BPMUtils.getStakTraceAsString(e);
			logger.error(failureReason, e);
		} finally {
			endDate = new java.util.Date();
			elapsedTime = BPMUtils
					.getTimeDifferenceAsString(startDate, endDate);
			logger.info("@@purgeGroupBaselineHist ="
					+ deletedRecs + ", Total Time=" + elapsedTime);
		}

		logger.info("@@End - Batch Purge EmployerGroupBaselineHist Table ...");

		// prepare summary email body
		StringBuffer batchMailSubject = new StringBuffer();
		batchMailSubject.append("BPM Batch Process Status (Purge Employer Group Baseline History)");
		StringBuffer batchMailContent = new StringBuffer();

		batchMailContent.append("<tr><td>" + "BPM Batch Name: "
				+ statusCalculationCommand.getCurrentCommandText() + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Initiated User: "
				+ statusCalculationCommand.getUserID() + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Time Start: "
				+ BPMUtils.getFormattedDateTime(startDate) + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Time Completed: "
				+ BPMUtils.getFormattedDateTime(endDate) + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Elapsed Time: " + elapsedTime + "</td></tr>");


		batchMailContent.append("<tr><td>" + "Purge cutoff date for this run is : "
				+ purgeDate.toString() + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Number of EmployerGroupBaselineHist records read before purge: "
				+ groupBaselineHistCountBefore + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Number of EmployerGroupBaselineHist records deleted: "
				+ deletedRecs + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Number of EmployerGroupBaselineHist records read after purge: "
				+ groupBaselineHistCountAfter + "</td></tr>");

		if (groupBaselineHistCountBefore != (groupBaselineHistCountAfter  + deletedRecs)) {
			failureReason = "Sum of records counted (" + groupBaselineHistCountBefore + ") before purge does not match the sum of records counted (" + groupBaselineHistCountAfter + ") after purge plus records deleted (" + deletedRecs + ")";
		}

		if (failureReason != null) {
			batchMailSubject.append(" - FAILED");
			batchMailContent.append("<tr><td>" + "Result: FAILED" + "</td></tr>");
			batchMailContent.append("<tr><td>" + "Reason: " + "</td></tr>");
			batchMailContent.append(failureReason);
		} else {
			batchMailSubject.append(" - SUCCESS");
			batchMailContent.append("<tr><td>" + "Result: SUCCESS" + "</td></tr>");
		}
		emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
		// send email batch summary
		emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
				batchMailContent.toString());

		businessProgramService.writeToAuditLog(statusCalculationCommand, batchMailSubject.toString(), startDate.toString(), endDate.toString(),
				elapsedTime.toString(), Integer.toString(deletedRecs));

		if (failureReason != null) {
			throw new BPMException(failureReason);
		}

		// finished, reset current command to null
		statusCalculationCommand.resetCurrentProcessingCommand();
	}
	
	/**
	 * Purge AuditLog table by date batch process()
	 * Cutoff date for purging is controlled through the LUV table.
	 * 
	 * @param statusCalculationCommand
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	            
	private void processPurgeAuditLogCommand(
			StatusCalculationCommand statusCalculationCommand)
			throws BPMException, DataAccessException {
		
		Integer auditLogCountBefore = null;
		Integer deletedRecs = null;
		Integer auditLogCountAfter = null;
		
		String failureReason = null;
		String elapsedTime = null;
		java.util.Date startDate = new java.util.Date();
		java.util.Date endDate = null;
		java.sql.Date purgeDate = null;
		
		// text/label
		statusCalculationCommand.setCurrentCommandText("Purge AuditLog Table");

		// set current command to fetch processID
		statusCalculationCommand
				.setCurrentProcessingCommand(StatusCalculationCommand.PURGE_AUDIT_LOG_TABLE);
		
		logger.info("@@Start - Batch Purge AuditLog Table ...");	
	    
		try {
			auditLogCountBefore = getAuditLogCount();
			
			purgeDate = getPurgeDate(BPMConstants.PURGE_AUDIT_LOG_TABLE_MONTHTOKEEP);
			
			deletedRecs = purgeAuditLog(purgeDate);
			auditLogCountAfter = getAuditLogCount();
		
		} catch (Exception e) {
			failureReason = BPMUtils.getStakTraceAsString(e);
			logger.error(failureReason, e);
		} finally {
			endDate = new java.util.Date();
			elapsedTime = BPMUtils
					.getTimeDifferenceAsString(startDate, endDate);
			logger.info("@@Batch Purge AuditLog table records deleted ="
					+ deletedRecs + ", Total Time=" + elapsedTime);
		}
		
		logger.info("@@End - Batch Purge AuditLog Table ...");
		
		// prepare summary email body
		StringBuffer batchMailSubject = new StringBuffer();
		batchMailSubject.append("BPM Batch Process Status (PurgeAuditLog) ");
		StringBuffer batchMailContent = new StringBuffer();
		batchMailContent.append("<tr><td>" + "BPM Batch Name: "
				+ statusCalculationCommand.getCurrentCommandText() + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Initiated User: "
				+ statusCalculationCommand.getUserID() + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Time Start: "
				+ BPMUtils.getFormattedDateTime(startDate) + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Time Completed: "
				+ BPMUtils.getFormattedDateTime(endDate) + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Elapsed Time: " + elapsedTime + "</td></tr>");
		/*
		 * batchMailContent .append("\nNumber of persons considered for
		 * processing: " + totalPersonsTobeProcessed);
		 */
		
		batchMailContent.append("<tr><td>" + "Purge date for this run is : "
				+ purgeDate.toString() + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Number of AuditLog records read before purge: "
				+ auditLogCountBefore + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Number of AuditLog records deleted: "
				+ deletedRecs + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Number of AuditLog records read after purge: "
				+ auditLogCountAfter + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Note: Sum of records counted before purge  may not always match to the sum of records read plus records deleted. " + "</td></tr>");
		batchMailContent.append("<tr><td>" + "  Audit records continue to be recorded to the AuditLog table given activity from source systems." + "</td></tr>");
		if (failureReason != null) {
			batchMailSubject.append(" - FAILED");
			batchMailContent.append("<tr><td>" + "Result: FAILED" + "</td></tr>");
			batchMailContent.append("<tr><td>" + "Reason: ");
			batchMailContent.append(failureReason + "</td></tr>");
		} else {
			batchMailSubject.append(" - SUCCESS");
			batchMailContent.append("<tr><td>" + "Result: SUCCESS" + "</td></tr>");
		}
		
		emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
		// send email batch summary
		emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
				batchMailContent.toString());
		
		businessProgramService.writeToAuditLog(statusCalculationCommand, batchMailSubject.toString(), startDate.toString(), endDate.toString(),
				elapsedTime.toString(), Integer.toString(deletedRecs));
	
		if (failureReason != null) {
			throw new BPMException(failureReason);
		}

		// finished, reset current command to null
		statusCalculationCommand.resetCurrentProcessingCommand();
	}
	
	/**
	 * Purge ProcessingStatusLog table by date batch process()
	 * Cutoff date for purging is controlled through the LUV table.
	 * 
	 * @param statusCalculationCommand
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	            
	private void processPurgeProcessingStatusLogCommand(
			StatusCalculationCommand statusCalculationCommand)
			throws BPMException, DataAccessException {
		
		Integer processStatLogCountBefore = null;
		Integer deletedRecs = null;
		Integer processStatLogCountAfter = null;
		
		String failureReason = null;
		String elapsedTime;
		java.util.Date startDate = new java.util.Date();
		java.util.Date endDate;
		java.sql.Date purgeDate = null;
		
		// text/label
		statusCalculationCommand.setCurrentCommandText("Purge ProcessingStatusLog Table");

		// set current command to fetch processID
		statusCalculationCommand
				.setCurrentProcessingCommand(StatusCalculationCommand.PURGE_PROCESSLG_TABLE);
		
		logger.info("@@Start - Batch Purge ProcessingStatusLog Table ...");	
	    
		try {
			processStatLogCountBefore = getProcessStatLogCount();
			
			purgeDate = getPurgeDate(BPMConstants.PURGE_PROCESSLG_TABLE_MONTHTOKEEP);
			
			deletedRecs = purgeProcessStatLog(purgeDate);
			processStatLogCountAfter = getProcessStatLogCount();
		
		} catch (Exception e) {
			failureReason = BPMUtils.getStakTraceAsString(e);
			logger.error(failureReason, e);
		} finally {
			endDate = new java.util.Date();
			elapsedTime = BPMUtils
					.getTimeDifferenceAsString(startDate, endDate);
			logger.info("@@Batch Purge ProcessingStatusLog table records deleted ="
					+ deletedRecs + ", Total Time=" + elapsedTime);
		}
		
		logger.info("@@End - Batch Purge ProcessingStatusLog Table ...");
		
		// prepare summary email body
		StringBuffer batchMailSubject = new StringBuffer();
		batchMailSubject.append("BPM Batch Process Status (Purge Processing Status Log)");
		StringBuffer batchMailContent = new StringBuffer();
		batchMailContent.append("<tr><td>" + "BPM Batch Name: "
				+ statusCalculationCommand.getCurrentCommandText() + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Initiated User: "
				+ statusCalculationCommand.getUserID() + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Time Start: "
				+ BPMUtils.getFormattedDateTime(startDate) + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Time Completed: "
				+ BPMUtils.getFormattedDateTime(endDate) + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Elapsed Time: " + elapsedTime + "</td></tr>");
		batchMailContent.append("<tr><td>" +"Purge date for this run is : "
					+ purgeDate.toString() + "</td></tr>");

		batchMailContent.append("<tr><td>" + "Number of ProcessingStatusLog records read before purge: "
				+ processStatLogCountBefore + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Number of ProcessingStatusLog records deleted: "
				+ deletedRecs + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Number of ProcessingStatusLog records read after purge: "
				+ processStatLogCountAfter + "</td></tr>");
		
		if (processStatLogCountBefore != (processStatLogCountAfter  + deletedRecs)) {
			failureReason = "Record count read does not match the sum of records read after purge plus records deleted.";
		}
		
		if (failureReason != null) {
			batchMailSubject.append(" - FAILED");
			batchMailContent.append("<tr><td>" + "Result: FAILED");
			batchMailContent.append("<tr><td>" + "Reason: " + "</td></tr>");
			batchMailContent.append("<tr><td>" + failureReason + "</td></tr>");
		} else {
			batchMailSubject.append(" - SUCCESS");
			batchMailContent.append("<tr><td>" + "Result: SUCCESS" + "</td></tr>");
		}
		emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
		// send email batch summary
		emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
				batchMailContent.toString());
		
		businessProgramService.writeToAuditLog(statusCalculationCommand, batchMailSubject.toString(), startDate.toString(), endDate.toString(),
				elapsedTime.toString(), Integer.toString(deletedRecs));
	
		if (failureReason != null) {
			throw new BPMException(failureReason);
		}

		// finished, reset current command to null
		statusCalculationCommand.resetCurrentProcessingCommand();
	}

	/*
	 *  Delete Employer Group Baseline History records based on purge date.
	 */

	private Integer purgeGroupBaselineHist(java.sql.Date purgeDate)

	{


		Integer deletedRecs = groupBaselineDAO.purgeGroupBaselineHistByDate(purgeDate);

		return deletedRecs;
	}
	
	/*
	 *  Delete log records based on purge date.
	 */
	
	private Integer purgeProcessStatLog(java.sql.Date purgeDate)

	{
		
		Integer deletedRecs = processingStatusLogDAO.purgeProcessStatLogByDate(purgeDate);
		
		return deletedRecs;
    }
	
	/*
	 *  Delete log records based on purge date.
	 */
	
	private Integer purgeAuditLog(java.sql.Date purgeDate)

	{
		
		Integer deletedRecs = auditLogService.purgeAuditLogByDate(purgeDate);
		
		return deletedRecs;
    }
	
	/*
	 *  Calculate purge date.
	 */
	private java.sql.Date getPurgeDate(String value) throws BPMException {
		
		LookUpValueCode lookUpValueCode = getLUVCodeByGroupNValue(BPMConstants.BPM_PURGE, value);
		String monthSpan = lookUpValueCode.getLuvDesc();
		monthSpan = "-" + monthSpan;  //Append minus sign.
		java.sql.Date purgeDateSql = BPMUtils.determineCutOffDate(monthSpan);
		
		return purgeDateSql;
	}
	
	/*
	 *  Get person contract history reconciliation date.
	 */
	private java.sql.Date getPersonContractHistoryReconciliationDate(String value) throws BPMException {
		
		LookUpValueCode lookUpValueCode = getLUVCodeByGroupNValue(BPMConstants.BPM_RECON_CUTOFF, value);
		String weekSpan = lookUpValueCode.getLuvDesc();
		weekSpan = "-" + weekSpan;  //Append minus sign.
		java.sql.Date contractReconDateSql = BPMUtils.determineWeekCutOffDate(weekSpan);
		
		return contractReconDateSql;
	}

	private int getGroupBaselineHistCount()
			throws BPMException
	{


		int groupBaselineHistCount = groupBaselineDAO.getGroupBaselineHistCount();

		return groupBaselineHistCount;
	}

	private int getProcessStatLogCount()
		throws BPMException
	{
	
		int processStatLogCount = processingStatusLogDAO.getProcessStatLogCount();
		
		return processStatLogCount;
	}
	
	private int getAuditLogCount()
			throws BPMException
	{
		
		int auditLogCount = auditLogService.getAuditLogCount();
		
		return auditLogCount;
	}

	/**
	 * method processes the batch based on type in StatusCalculationCommand 1.
	 * membership update 2. Re-Calculation of status(elapsed time incuded)
	 * 
	 * @param statusCalculationCommand
	 * @throws BPMException
	 */
	public void processBatchMembersForCommand(
			StatusCalculationCommand statusCalculationCommand)
			throws BPMException {

		int batchSize = DEFAULT_BATCH_SIZE;
		String failureReason = null;
		String elapsedTime = null;
		int totalPersonsTobeProcessed = 0;
		int personsProcessedSoFar = 0;
		java.util.Date startDate = new java.util.Date();
		java.util.Date endDate = null;
		try {
			// get batch size
			if (statusCalculationCommand.getBatchSize() != null) {
				batchSize = statusCalculationCommand.getBatchSize().intValue();
			}

			// get total number of persons to be processed from log table for
			// this type
			totalPersonsTobeProcessed = memberService
					.getNumberOfPendingPersonsTobeProcessed(statusCalculationCommand
							.getProcessIDForCurrentProcessingCommand()
							.intValue());

			logger.info("@@Batch-total Persons to processed ="
					+ totalPersonsTobeProcessed);

			// process each batch
			boolean hasMoreBatches = false;
			if (totalPersonsTobeProcessed > 0) {
				hasMoreBatches = true;
			}
			while (hasMoreBatches) {

				// fetch personIDs of persons to be processed from log table for
				// this type
				Collection<Integer> lpersonIdsToProcessNow = memberService
						.getPendingPersonsTobeProcessed(
								batchSize,
								statusCalculationCommand
										.getProcessIDForCurrentProcessingCommand()
										.intValue());

				// update processing status log to in processing				
				updatePersonProcessingStatusLog(lpersonIdsToProcessNow,
						statusCalculationCommand
								.getProcessIDForCurrentProcessingCommand()
								.intValue(),
						BPMConstants.PROCESSING_STATUS_INPROCESS,
						BPMConstants.BPM_USER_SYSTEM);                								
				
				Iterator<Integer> iter = lpersonIdsToProcessNow.iterator();
				// loop throgh each personID
				while (iter.hasNext()) {
					Integer personID = iter.next();
					if (statusCalculationCommand
							.isCurrentProcessingEtlMembershipUpdateCommand()) {
						// etl membership update
						processEtlMembershipUpdate(personID,
								statusCalculationCommand);
					} else {
						// recalculate member status
						processMemberReCalculation(personID,
								statusCalculationCommand);
					}
				}

				// total processed so far
				personsProcessedSoFar = personsProcessedSoFar
						+ lpersonIdsToProcessNow.size();

				logger.info("@@Batch - persons processed so far ="
						+ personsProcessedSoFar);

				// remainig persons to process
				int remainingPendingPersons = totalPersonsTobeProcessed
						- personsProcessedSoFar;

				logger.info("@@Batch - remaining Persons ="
						+ remainingPendingPersons);
				// decide for next batch
				if (lpersonIdsToProcessNow.size() <= 0) {
					// to avoid infinite looping due to database inconsistency
					hasMoreBatches = false;
				} else if (remainingPendingPersons > 0) {
					// to avoid infinite looping due to database inconsistency
					hasMoreBatches = true;
				} else {
					hasMoreBatches = false;
				}
			}													

		} catch (Exception e) {
			failureReason = BPMUtils.getStakTraceAsString(e);
			logger.error(failureReason, e);
		} finally {
			endDate = new java.util.Date();
			elapsedTime = BPMUtils
					.getTimeDifferenceAsString(startDate, endDate);
			logger.info("@@Batch Total Persons processed ="
					+ personsProcessedSoFar + ", Total Time=" + elapsedTime);
		}
		
		// prepare summary email body
		StringBuffer batchMailSubject = new StringBuffer();
		
		batchMailSubject.append("BPM Batch Process Status (Membership Update)");
		
		StringBuffer batchMailContent = new StringBuffer();
		batchMailContent
		.append("<table>");
		batchMailContent.append("<tr><td>BPM Batch Name: "
				+ statusCalculationCommand.getCurrentCommandText() + "</td></tr>");
		batchMailContent.append("<tr><td>Initiated User: "
				+ statusCalculationCommand.getUserID() + "</td></tr>");
		batchMailContent.append("<tr><td>Time Start: "
				+ BPMUtils.getFormattedDateTime(startDate) + "</td></tr>");
		batchMailContent.append("<tr><td>Time Completed: "
				+ BPMUtils.getFormattedDateTime(endDate) + "</td></tr>");
		batchMailContent.append("<tr><td>Elapsed Time: " + elapsedTime + "</td></tr>");
		/*
		 * batchMailContent .append("\nNumber of persons considered for
		 * processing: " + totalPersonsTobeProcessed);
		 */
		batchMailContent.append("<tr><td>Number of persons processed: "
				+ personsProcessedSoFar + "</td></tr>");
		if (failureReason != null) {
			batchMailSubject.append(" - FAILED>");
			batchMailContent.append("<tr><td>Result: FAILED</td></tr>");
			batchMailContent.append("<tr><td>Reason: ");
			batchMailContent.append(failureReason);
			batchMailContent.append(" </td></tr>");
		} else {
			batchMailSubject.append(" - SUCCESS");
			batchMailContent.append("<tr><td>Result: SUCCESS</td></tr>");
		}
		
		batchMailContent
		.append("</table>");
		
		emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
		// send email batch summary
		emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
				batchMailContent.toString());
		
		businessProgramService.writeToAuditLog(statusCalculationCommand, batchMailSubject.toString(), startDate.toString(), endDate.toString(),
				elapsedTime.toString(), Integer.toString(personsProcessedSoFar));
	
		if (failureReason != null) {
			throw new BPMException(failureReason);
		}
	}
	
	
	
	/**
	 * Process only updates from membership (MODS). Do not perform status calculation so to make this
	 * process a bit faster.
	 * 
	 * @param statusCalculationCommand
	 * @throws BPMException
	 */
	public void processBatchMembersOnly(StatusCalculationCommand statusCalculationCommand)
	throws BPMException 
	{
		int batchSize = DEFAULT_BATCH_SIZE;
		String failureReason = null;
		String elapsedTime = null;
		int totalPersonsTobeProcessed = 0;
		int personsProcessedSoFar = 0;
		java.util.Date startDate = new java.util.Date();
		java.util.Date endDate = null;
		try 
		{
			// get batch size
			if (statusCalculationCommand.getBatchSize() != null) 
			{
				batchSize = statusCalculationCommand.getBatchSize().intValue();
			}

			// get total number of persons to be processed from log table for
			// this type
			totalPersonsTobeProcessed = memberService.getNumberOfPendingPersonsTobeProcessed(statusCalculationCommand
							.getProcessIDForCurrentProcessingCommand().intValue());

			logger.info("@@Batch-total Persons to processed =" + totalPersonsTobeProcessed);

			// process each batch
			boolean hasMoreBatches = false;
			if (totalPersonsTobeProcessed > 0) 
			{
				hasMoreBatches = true;
			}
			while (hasMoreBatches) 
			{
				// fetch personIDs of persons to be processed from log table for
				// this type
				Collection<Integer> lpersonIdsToProcessNow = memberService.getPendingPersonsTobeProcessed(
								batchSize,
								statusCalculationCommand.getProcessIDForCurrentProcessingCommand().intValue());

				// update processing status log to in processing				
				updatePersonProcessingStatusLog(lpersonIdsToProcessNow,
						statusCalculationCommand.getProcessIDForCurrentProcessingCommand().intValue(),
						BPMConstants.PROCESSING_STATUS_INPROCESS,
						BPMConstants.BPM_USER_SYSTEM);                								

				Iterator<Integer> iter = lpersonIdsToProcessNow.iterator();
				// loop throgh each personID
				while (iter.hasNext()) 
				{
					Integer personID = iter.next();
					processEtlMembershipUpdateOnly(personID, statusCalculationCommand);
				}

				// total processed so far
				personsProcessedSoFar = personsProcessedSoFar + lpersonIdsToProcessNow.size();

				logger.info("@@Batch - persons processed so far =" + personsProcessedSoFar);

				// remainig persons to process
				int remainingPendingPersons = totalPersonsTobeProcessed - personsProcessedSoFar;

				logger.info("@@Batch - remaining Persons ="
						+ remainingPendingPersons);
				// decide for next batch
				if (lpersonIdsToProcessNow.size() <= 0) {
					// to avoid infinite looping due to database inconsistency
					hasMoreBatches = false;
				} else if (remainingPendingPersons > 0) {
					// to avoid infinite looping due to database inconsistency
					hasMoreBatches = true;
				} else {
					hasMoreBatches = false;
				}
			}

		} catch (Exception e) {
			failureReason = BPMUtils.getStakTraceAsString(e);
			logger.error(failureReason, e);
		} finally {
			endDate = new java.util.Date();
			elapsedTime = BPMUtils
					.getTimeDifferenceAsString(startDate, endDate);
			logger.info("@@Batch Total Persons processed ="
					+ personsProcessedSoFar + ", Total Time=" + elapsedTime);
		}
		
		// prepare summary email body
		StringBuffer batchMailSubject = new StringBuffer();
		batchMailSubject.append("BPM Batch Process Status (Process Batch Members Only - No Status Calculation)");
		StringBuffer batchMailContent = new StringBuffer();
		batchMailContent.append("<tr><td>" + "BPM Batch Name: "
				+ statusCalculationCommand.getCurrentCommandText() + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Initiated User: "
				+ statusCalculationCommand.getUserID() + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Time Start: "
				+ BPMUtils.getFormattedDateTime(startDate) + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Time Completed: "
				+ BPMUtils.getFormattedDateTime(endDate) + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Elapsed Time: " + elapsedTime + "</td></tr>");
		/*
		 * batchMailContent .append("\nNumber of persons considered for
		 * processing: " + totalPersonsTobeProcessed);
		 */
		batchMailContent.append("<tr><td>" +"Number of persons processed: "
				+ personsProcessedSoFar + "</td></tr>");
		if (failureReason != null) {
			batchMailSubject.append(" - FAILED");
			batchMailContent.append("<tr><td>" + "Result: FAILED" + "</td></tr>");
			batchMailContent.append("<tr><td>" + "Reason: " + "</td></tr>");
			batchMailContent.append("<tr><td>" + failureReason + "</td></tr>");
		} else {
			batchMailSubject.append(" - SUCCESS");
			batchMailContent.append("<tr><td>" + "Result: SUCCESS" + "</td></tr>");
		}
		emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
		// send email batch summary
		emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
				batchMailContent.toString());
		
		businessProgramService.writeToAuditLog(statusCalculationCommand, batchMailSubject.toString(), startDate.toString(), endDate.toString(),
				elapsedTime.toString(), Integer.toString(personsProcessedSoFar));
	
		if (failureReason != null) {
			throw new BPMException(failureReason);
		}
	}
	
	
	
	

	/**
	 * updates Processing Status in ProcessingStatusLog table
	 * 
	 * @param personIds
	 * @param processId
	 * @param processingStatusValue
	 * @param userId
	 * @throws DataAccessException
	 * @throws BPMException
	 */
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
			com.healthpartners.service.imfs.exception.BPMBusinessValidationException.class, BPMException.class })
	public void updatePersonProcessingStatusLog(Collection<Integer> personIds,
			Integer processId, String processingStatusValue, final String userId)
			throws DataAccessException, BPMException {
		// Begin a transaction.
		// DefaultTransactionDefinition def = new
		// DefaultTransactionDefinition();
		// def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		// TransactionStatus status = txManager.getTransaction(def);
		try {

			memberService.updatePersonProcessingStatus(personIds, processId,
					processingStatusValue, userId);

			// Commit the transaction.
			// txManager.commit(status);
		} catch (DataAccessException dae) {
			// Rollback the transaction on error.
			// txManager.rollback(status);
			logger
					.error("An unexpected error has occured: "
							+ dae.getMessage(), dae);
			throw dae;
		} catch (Exception e) {
			// Rollback the transaction on error.
			// txManager.rollback(status);
			logger.error("An unexpected error has occured: " + e.getMessage(),
					e);
			throw new BPMException(e);
		}
	}

	/**
	 * method process the membership update 1. update membership details using
	 * memberService.updateMembershipData(pPersonID); 2. calculate member status
	 * for each updated member 3. update processing status to completed
	 * 
	 * @param pPersonID
	 * @param statusCalculationCommand
	 * @throws DataAccessException
	 * @throws BPMException
	 */
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
			com.healthpartners.service.imfs.exception.BPMBusinessValidationException.class, BPMException.class })
	public void processEtlMembershipUpdate(Integer pPersonID,
			StatusCalculationCommand statusCalculationCommand)
			throws DataAccessException, BPMException {
		// Begin a transaction.
		// DefaultTransactionDefinition def = new
		// DefaultTransactionDefinition();
		// def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		// TransactionStatus status = txManager.getTransaction(def);
		try {
			// update membership data for ETL updates, returns updated personIDs
			TreeSet<Integer> personIDsFromMembershipUpdate = memberService
					.updateMembershipData(pPersonID);

			// loop through updated members
			Iterator<Integer> itr = personIDsFromMembershipUpdate.iterator();
			while (itr.hasNext()) {
				Integer membershipUpdatePersonID = itr.next();
				// Re-calculate member status
				updateProgramStatusBasedOnMember(membershipUpdatePersonID);
			}
			
			// update processing status to completed
			memberService.updatePersonProcessingStatusLog(pPersonID,
					statusCalculationCommand
							.getProcessIDForCurrentProcessingCommand(),
					BPMConstants.PROCESSING_STATUS_COMPLETED,
					BPMConstants.BPM_USER_SYSTEM);			 

			// Commit the transaction.
			// txManager.commit(status);
		} catch (DataAccessException dae) {
			// Rollback the transaction on error.
			// txManager.rollback(status);
			logger
					.error("An unexpected error has occured: "
							+ dae.getMessage(), dae);
			throw dae;
		} catch (Exception e) {
			StringWriter sw = new StringWriter();
	        PrintWriter pw = new PrintWriter(sw);
	        e.printStackTrace(pw);
		    logger.error(sw.toString());
		    
			throw new BPMException(e);
		}
	}

	
	/**
	 * 
	 * @param pPersonID
	 * @param statusCalculationCommand
	 * @throws DataAccessException
	 * @throws BPMException
	 */
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
			com.healthpartners.service.imfs.exception.BPMBusinessValidationException.class, BPMException.class })
	private void processEtlMembershipUpdateOnly(Integer pPersonID,
			StatusCalculationCommand statusCalculationCommand)
			throws DataAccessException, BPMException 
	{		
		try 
		{
			// update membership data for ETL updates, returns updated personIDs
			TreeSet<Integer> personIDsFromMembershipUpdate = memberService
					.updateMembershipData(pPersonID);

			// update processing status to completed
			memberService.updatePersonProcessingStatusLog(pPersonID,
					statusCalculationCommand
							.getProcessIDForCurrentProcessingCommand(),
					BPMConstants.PROCESSING_STATUS_COMPLETED,
					BPMConstants.BPM_USER_SYSTEM);
		} 
		catch (DataAccessException dae) 
		{			
			logger.error("An unexpected error has occured: " + dae.getMessage(), dae);
			throw dae;
		} 
		catch (Exception e) 
		{
			logger.error("An unexpected error has occured: " + e.getMessage(), e);
			throw new BPMException(e);
		}
	}
	
	
	/**
	 * 
	 * method process the Re-calculate member status 1. calculate member status
	 * for each updated member 2. update processing status to completed
	 * 
	 * @param pPersonID
	 * @param statusCalculationCommand
	 * @throws DataAccessException
	 * @throws BPMException
	 */
	private void processMemberReCalculation(Integer pPersonID,
			StatusCalculationCommand statusCalculationCommand)
			throws DataAccessException, BPMException {
		// Begin a transaction.
		/*
		 DefaultTransactionDefinition def = new DefaultTransactionDefinition();
		 def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		 TransactionStatus status = txManager.getTransaction(def);
		 */
		try {
			// Re-calculate member status
			updateProgramStatusBasedOnMember(pPersonID);								
			// update processing status to completed
			memberService.updatePersonProcessingStatusLog(pPersonID,
					statusCalculationCommand
							.getProcessIDForCurrentProcessingCommand(),
					BPMConstants.PROCESSING_STATUS_COMPLETED,
					BPMConstants.BPM_USER_SYSTEM);
			// Commit the transaction.
			// txManager.commit(status);
		} catch (DataAccessException dae) {
			// Rollback the transaction on error.
			// txManager.rollback(status);
			logger.error("An unexpected error has occured: " + dae.getMessage(), dae);
			throw dae;
		} catch (Exception e) {
			// Rollback the transaction on error.
			// txManager.rollback(status);
			logger.error("An unexpected error has occured: " + e.getMessage(), e);
			throw new BPMException(e);
		}
	}

	/**
	 * process all activities with pending state
	 * 
	 * @param statusCalculationCommand
	 * @throws BPMException
	 */
	public void processPendingActivityEventsCommand(
			StatusCalculationCommand statusCalculationCommand)
			throws BPMException {
		String failureReason = null;
		String elapsedTime = null;
		int numberOfPendingActivities = 0;
		java.util.Date startDate = new java.util.Date();
		java.util.Date endDate = null;
		int lActivitiesProcessedSoFar = 0;
		
		//This needs to run before pending activities runs.  The scenerio being
		//searched for rarely happens but when it does it use to take manual intervention to correct.  If the scenerio is present,
		// The insert date changes for the complete and advanced by a millisecond so the COMPLETE status get's processed first when
		// member elapsed time runs.  Also sets record to PENDING so it get's picked up in the Process Pending Activity batch job.
		logger.info("@@Start - Process Complete Activity Events Sent In At Same Time As Active Or Cancel ...");		
		int numberOfActivityEventTSUpdates = processCompleteActivityEventsSentInAtSameTimeAsActiveOrCancel();
		logger.info("@@ Number of COMPLETE and Active/Cancel Activity Events triggering TimeStamp Updates to COMPLETE activity event is " + numberOfActivityEventTSUpdates);		
		logger.info("@@End - Process Complete Activity Events Sent In At Same Time As Active Or Cancel ...");		
		
		
		logger.info("@@Start - Batch pending activity events ...");
		statusCalculationCommand.setCurrentCommandText("Pending Activities");
		try {												
			// NOTE: batch size is ignored since we are just putting message out
			// for each pending activity
			numberOfPendingActivities = activityEventLogDAO
					.getNumberOfPendingActivityEvents();

			logger.info("@@Batch-total pendig activities to process ="
					+ numberOfPendingActivities);						

			boolean hasMoreBatches = false;
			if (numberOfPendingActivities > 0) 
			{
				hasMoreBatches = true;
			}
			
			while (hasMoreBatches)
			{
				// get all pending
				Collection<Long> pendingActivityEventIds = activityEventLogDAO
						.getPendingActivityEventLogIDs(DEFAULT_BATCH_SIZE_ACTIVITY);								
				
				Iterator<Long> itr = pendingActivityEventIds.iterator();
				
				while(itr.hasNext())
				{					
					Long activityEventLogID = itr.next();
					// synchronous processing
					// send JMS to process asynchronous										
					setActivityStatusesToInProcess(activityEventLogID);
															
					activityEventService.processActivityEvent(activityEventLogID);
					
					lActivitiesProcessedSoFar++;
				}

				logger.info("@@Batch - remaining Activities ="
						+ pendingActivityEventIds.size());
				// decide for next batch
				if (pendingActivityEventIds.size() > 0) {
					// to avoid infinite looping due to database inconsistency
					hasMoreBatches = true;					
				} else {
					hasMoreBatches = false;
				}				
			}

		} catch (Exception e) {
			failureReason = BPMUtils.getStakTraceAsString(e);
			logger.error(failureReason, e);
		} finally {
			endDate = new java.util.Date();
			elapsedTime = BPMUtils
					.getTimeDifferenceAsString(startDate, endDate);
			logger
					.info("@@@@End - Number of Pending Activities processed: "
							+ lActivitiesProcessedSoFar
							+ "..Total Time ="
							+ elapsedTime);
		}

		StringBuffer batchMailSubject = new StringBuffer();
		batchMailSubject.append("BPM Batch Process Status (Process Pending Activity Events) ");
		StringBuffer batchMailContent = new StringBuffer();

		batchMailContent.append("<tr><td>BPM Batch Name: " + statusCalculationCommand.getCurrentCommandText() + "</td></tr>");
		
		batchMailContent.append("<tr><td>Initiated User: "
				+ statusCalculationCommand.getUserID() + "</td></tr>");
		batchMailContent.append("<tr><td>Time Start: "
				+ BPMUtils.getFormattedDateTime(startDate) + "</td></tr>");
		batchMailContent.append("<tr><td>Time End: "
				+ BPMUtils.getFormattedDateTime(endDate) + "</td></tr>");
		batchMailContent.append("<tr><td>Elapsed Time: "
				+ elapsedTime + "</td></tr>");
		batchMailContent
				.append("<tr><td>Number of Pending Activities processed: "
						+ lActivitiesProcessedSoFar + "</td></tr>");

		if (failureReason != null) {
			batchMailSubject.append("- FAILED");
			batchMailContent.append("<tr><td>Result: FAILED </td></tr>");
			batchMailContent.append("<tr><td>Reason: </td></tr>");
			batchMailContent.append(failureReason);
		} else {
			batchMailSubject.append("- SUCCESS");
			batchMailContent.append("<tr><td>Result: SUCCESS</td></tr>");
		}
		emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
		emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
				batchMailContent.toString());
		
		businessProgramService.writeToAuditLog(statusCalculationCommand, batchMailSubject.toString(), startDate.toString(), endDate.toString(),
				elapsedTime.toString(), Integer.toString(numberOfPendingActivities));

		if (failureReason != null) {
			throw new BPMException(failureReason);
		}
	}
	
	
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
			com.healthpartners.service.imfs.exception.BPMBusinessValidationException.class, BPMException.class })
	private void setActivityStatusesToInProcess(Long pActivityEventLogID)
	{
		ActivityEvent activityEvent = new ActivityEvent();
		activityEvent.setActivityEventLogID(pActivityEventLogID);
		activityEvent.setModifyUserId(BPMConstants.BPM_USER_SYSTEM);
		activityEvent.setProcessingStatusValue(BPMConstants.PROCESSING_STATUS_INPROCESS);

		activityEventLogDAO.updateActivityLogProcessingStatus(activityEvent);

				
		return;
	}
	
	/**
	 * determine if reason 3 and 5 filtered out activities exist, repend the activities, kick
	 * off the pending activities process, recount filtered activities left, and produce a summary report.
	 * Number of days to look back is controlled through xml file.
	 * 
	 * @param statusCalculationCommand
	 * @throws BPMException
	 */
	private void determineFilteredOutActivityEventsCommand(
			StatusCalculationCommand statusCalculationCommand)
			throws BPMException {
		String failureReason = null;
		String elapsedTime = null;
		boolean pendingBatchJobSuccess = true;
		
		int numberOfFilteredActivitiesBeforeRsnCode3 = 0;
		int numberOfFilteredActivitiesBeforeRsnCode5 = 0;
		int numberOfFilteredActivitiesAfterRsnCode3 = 0;
		int numberOfFilteredActivitiesAfterRsnCode5 = 0;
		int filteredOutActivitiesUpdatedRsnCode3Count = 0;
		int filteredOutActivitiesUpdatedRsnCode5Count = 0;
		
		java.util.Date startDate = new java.util.Date();
		java.util.Date endDate = null;
		logger.info("@@Start - Batch reprocess filtered out activity events for reason codes 3 and 5 ...");
		statusCalculationCommand.setCurrentCommandText("Reprocess Filtered Out Activities");
		int daySpan = statusCalculationCommand.getDaySpanToCtrlFilteredOutActivity();
		
		
		try {
			// Capture record count of filtered activities before.
			logger.info("@@daySpan is ="
					+ daySpan);
			numberOfFilteredActivitiesBeforeRsnCode3 = activityEventLogDAO
					.getNumberOfFilteredActivityEvents(BPMConstants.BPM_FILTERD_OUT_RSN_CD3_ACTIVE_W_EXISTING_COMPLETE, daySpan);
			numberOfFilteredActivitiesBeforeRsnCode5 = activityEventLogDAO
					.getNumberOfFilteredActivityEvents(BPMConstants.BPM_FILTERD_OUT_RSN_CD5_NO_ACTIVE, daySpan);
			
			logger.info("@@Batch-total filtered activities for reason code " + BPMConstants.BPM_FILTERD_OUT_RSN_CD3_ACTIVE_W_EXISTING_COMPLETE + " that exist before pending activities runs ="
					+ numberOfFilteredActivitiesBeforeRsnCode3);
			logger.info("@@Batch-total filtered activities for reason code " + BPMConstants.BPM_FILTERD_OUT_RSN_CD5_NO_ACTIVE + " that exist before pending activities runs ="
					+ numberOfFilteredActivitiesBeforeRsnCode5);
			
			//Update filtered activities by setting the activity event processing status to PENDING.
			
			filteredOutActivitiesUpdatedRsnCode3Count = activityEventLogDAO.updateQualifyingFilteredOutActivityEventsToPending(BPMConstants.BPM_FILTERD_OUT_RSN_CD3_ACTIVE_W_EXISTING_COMPLETE, daySpan);
			filteredOutActivitiesUpdatedRsnCode5Count = activityEventLogDAO.updateQualifyingFilteredOutActivityEventsToPending(BPMConstants.BPM_FILTERD_OUT_RSN_CD5_NO_ACTIVE, daySpan);
			
			//kick off pending activities here.
			StatusCalculationCommand statusCalculationCommand2 = new StatusCalculationCommand();
			statusCalculationCommand2.setCurrentCommandText("Pending Activities");
			statusCalculationCommand2.setPendingActivityEventsCommand();
			
			
			try {
				processPendingActivityEventsCommand(statusCalculationCommand2);
			} catch (Exception e) {
				pendingBatchJobSuccess = false;
				logger.info("@@Pending batch job failure ");
				failureReason = BPMUtils.getStakTraceAsString(e);
				logger.error(failureReason, e);
			} 

			
			// Capture record count of filtered activities after.
			
			numberOfFilteredActivitiesAfterRsnCode3 = activityEventLogDAO
					.getNumberOfFilteredActivityEvents(BPMConstants.BPM_FILTERD_OUT_RSN_CD3_ACTIVE_W_EXISTING_COMPLETE, daySpan);
			numberOfFilteredActivitiesAfterRsnCode5 = activityEventLogDAO
					.getNumberOfFilteredActivityEvents(BPMConstants.BPM_FILTERD_OUT_RSN_CD5_NO_ACTIVE, daySpan);

			logger.info("@@Batch-total filtered activities that exist after pending activities runs for reason code 3 ="
					+ numberOfFilteredActivitiesAfterRsnCode3);
			logger.info("@@Batch-total filtered activities that exist after pending activities runs for reason code 5 ="
					+ numberOfFilteredActivitiesAfterRsnCode5);


		} catch (Exception e) {
			failureReason = BPMUtils.getStakTraceAsString(e);
			logger.error(failureReason, e);
		} 
		
		
			
		endDate = new java.util.Date();
		elapsedTime = BPMUtils
				.getTimeDifferenceAsString(startDate, endDate);
		logger
				.info("@@@@End - Batch filtered activity events sent messages for reason code 3 ="
						+ numberOfFilteredActivitiesBeforeRsnCode3
						+ "..Total Time ="
						+ elapsedTime);
		logger
		.info("@@@@End - Batch filtered activity events sent messages for reason code 5 ="
				+ numberOfFilteredActivitiesBeforeRsnCode5
				+ "..Total Time ="
				+ elapsedTime);


		StringBuffer batchMailSubject = new StringBuffer();
		batchMailSubject.append("FILTERED OUT ACTIVITIES REPROCESSED");
		StringBuffer batchMailContent = new StringBuffer();
		batchMailContent.append("<tr><td>" + "BPM Batch Name: " + statusCalculationCommand.getCurrentCommandText() + "</td></tr>");
		
		batchMailContent.append("<tr><td>" +"Initiated User: "
				+ statusCalculationCommand.getUserID() + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Time Start: "
				+ BPMUtils.getFormattedDateTime(startDate) + "</td></tr>");
		
		if (failureReason != null) {
			batchMailSubject.append("- FAILED");
			batchMailContent.append("<tr><td>" + "Result: FAILED" + "</td></tr>");
			batchMailContent.append("<tr><td>" + "Reason: + " + "</td></tr>");
			batchMailContent.append("<tr><td>" + failureReason + "</td></tr>");
		} else {
			batchMailSubject.append("- SUCCESS");
			batchMailContent.append("<tr><td>" + "Result: SUCCESS" + "</td></tr>");
		}
		
		batchMailContent
		.append("<tr><td>" + "- Date span parameter set to look back " + daySpan + " days." + "</td></tr>");
		
		batchMailContent
		.append("<tr><td>" + "- Before: *Reason code 3 filtered out activities count: "
				+ numberOfFilteredActivitiesBeforeRsnCode3 + "</td></tr>");
		
		batchMailContent
			.append("<tr><td>" + "         *Reason code 5 filtered out activities count: "
					+ numberOfFilteredActivitiesBeforeRsnCode5 + "</td></tr>");
		
		int totalCt = filteredOutActivitiesUpdatedRsnCode3Count + filteredOutActivitiesUpdatedRsnCode5Count;
			batchMailContent
			.append("<tr><td>" + "- Filtered out activities set to PENDING: " + totalCt + "</td></tr>");
		
		if (pendingBatchJobSuccess) {
			batchMailContent
			.append("<tr><td>" + "- Pending activities batch job completed." + "</td></tr>");
		} else {
			batchMailContent
			.append("<tr><td>" +"- Pending activities batch job did not complete." + "</td></tr>");
		}
		
		batchMailContent
			.append("<tr><td>" + "- After: *Reason code 3 filtered out activities count: "
					+ numberOfFilteredActivitiesAfterRsnCode3 + "</td></tr>");
		
		batchMailContent
			.append("<tr><td>" + "-        *Reason code 5 filtered out activities count: "
					+ numberOfFilteredActivitiesAfterRsnCode5 + "</td></tr>");
		
		batchMailContent
		.append("<tr><td>" +" *Reason code 3: An activity event of COMPLETE already exists for this ACTIVE status sent in." + "</td></tr>");
		batchMailContent
		.append("<tr><td>" + " *Reason code 5: For this activity event of COMPLETE, INACTIVE, CANCEL, or DELETE, there must be an existing ACTIVE in the same program year." + "</td></tr>");
		batchMailContent
		.append("<tr><td>" + " *** See Filtered Activity Search screen located in the Member Admin section of the BPM Admin application for filtered out activity lookups." + "</td></tr>");
		
		
		emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
		emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
				batchMailContent.toString());
		
		businessProgramService.writeToAuditLog(statusCalculationCommand, batchMailSubject.toString(), startDate.toString(), endDate.toString(),
				elapsedTime.toString(), Integer.toString(numberOfFilteredActivitiesAfterRsnCode3 + numberOfFilteredActivitiesAfterRsnCode5));

		if (failureReason != null) {
			throw new BPMException(failureReason);
		}
		
	}

	/**
	 * process all tasks with pending state
	 * 
	 * @param statusCalculationCommand
	 * @throws BPMException
	 */
	public void processPendingTaskEventsCommand(
			StatusCalculationCommand statusCalculationCommand)
			throws BPMException {
		String failureReason = null;
		String elapsedTime = null;
		int numberOfPendingTasks = 0;
		java.util.Date startDate = new java.util.Date();
		java.util.Date endDate = null;
		logger.info("@@Start - Batch pending task events ...");
		try {

			// NOTE: batch size is ignored since we are just putting message out
			// for each pending task
			numberOfPendingTasks = taskEventLogDAO
					.getNumberOfPendingTaskEvents();

			logger.info("@@Batch-total pending tasks to process ="
					+ numberOfPendingTasks);

			// get all pending
			Collection<Long> pendingTaskEventIds = taskEventLogDAO
					.getPendingTaskEventLogIDs(numberOfPendingTasks);

			Iterator<Long> itr = pendingTaskEventIds.iterator();
		
			
			while (itr.hasNext()) {
				Long taskEventLogID = itr.next();
				// synchronous processing	
				
				taskEventService.processTaskEvent(taskEventLogID);
				// milli seconds ?? sleep to alow messaging to process
				// Thread.sleep(5000);
			}

		} catch (Exception e) {
			failureReason = BPMUtils.getStakTraceAsString(e);
			logger.error(failureReason, e);
		} finally {
			endDate = new java.util.Date();
			elapsedTime = BPMUtils
					.getTimeDifferenceAsString(startDate, endDate);
			logger.info("@@@@End - Task Events Processed: "
					+ numberOfPendingTasks + "..Total Time =" + elapsedTime);
		}

		StringBuffer batchMailSubject = new StringBuffer();
		batchMailSubject.append("BPM Batch Process Status (Process Pending TaskEvents)");
		StringBuffer batchMailContent = new StringBuffer();
		batchMailContent.append("BPM Batch Name: Pending Tasks");
		batchMailContent.append("<tr><td>" + "Initiated User: "
				+ statusCalculationCommand.getUserID() + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Time Start: "
				+ BPMUtils.getFormattedDateTime(startDate) + "</td></tr>");
		batchMailContent
				.append("<tr><td>" + "Task Events Processed: "
						+ numberOfPendingTasks + "</td></tr>");
		if (failureReason != null) {
			batchMailSubject.append("- FAILED");
			batchMailContent.append("<tr><td>" +"Result: FAILED");
			batchMailContent.append("<tr><td>" + "Reason: " + "</td></tr>");
			batchMailContent.append("<tr><td>" + failureReason + "</td></tr>");
		} else {
			batchMailSubject.append("- SUCCESS");
			batchMailContent.append("<tr><td>" + "Result: SUCCESS" + "</td></tr>");
		}
		emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
		emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
				batchMailContent.toString());
		
		businessProgramService.writeToAuditLog(statusCalculationCommand, batchMailSubject.toString(), startDate.toString(), endDate.toString(),
				elapsedTime.toString(), Integer.toString(numberOfPendingTasks));
		

	}

	
	/**
	 * Select and Insert for Membership Update, all the contracts that have ended
	 * but the contract_program_status participation end date does not reflect that.
	 */	
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
			com.healthpartners.service.imfs.exception.BPMBusinessValidationException.class, BPMException.class })
	protected int insertProcessingStatusLogForPastContractEndDates()
	throws BPMException
	{		 
		int lNumberOfPersonsWithContractEnds = personDAO.insertProcessingStatusLogForPastContractEndDates();
		
		return lNumberOfPersonsWithContractEnds;
	}
	
	/**
	 * This method calls the DAO which finds everyone the program type specified whose 18th
	 * birthday has arrived which makes them eligible for incentive options (and are not already in BPM)
	 * Their person IDs is inserted in the processing status log table so that they are picked up
	 * by the batch membership update and are inserted into the BPM person_program_status table.
	 * WIP 675 - tjq - 11/1/2017 - refactor method to be dynamic.
	 */
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
			com.healthpartners.service.imfs.exception.BPMBusinessValidationException.class, BPMException.class })
	private void insertPersonProgramStatus18YearOldsForIncentiveOptionByProgramType(String programType, String incentiveOptionName)
	{
		personDAO.insertPersonProgramStatus18YearOldsForIncentiveOptionByProgramType(programType, incentiveOptionName);
	}
		
	
	/**
	 * executes elapsed time query persons eligible beyond qualification period.   Place results in
	 * processing status log table for recalculation.
	 * 
	 * @param statusCalculationCommand
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public void processMemberElapsedTimes(
			StatusCalculationCommand statusCalculationCommand)
			throws BPMException, DataAccessException {
		int resetCount = 0;
		int batchSize = DEFAULT_BATCH_SIZE;

		// Process member elapsed-time attributes?
		logger.info("@start - evaluate members still eligible after qualification period as part of elapsed-time checking. ");
		try {

			if (statusCalculationCommand.getBatchSize() != null) {
				batchSize = statusCalculationCommand.getBatchSize().intValue();
			}

			
			TreeSet<Integer> memberIds = new TreeSet<Integer>();
			
			Collection<Integer> results = memberService.getPersonsEligibleBeyondQualificationPeriod();
			logger.info("results Size = " + results.size());
			memberIds.addAll(results);
			resetCount += results.size();
			resetMemberProcessingTimestamps(memberIds, batchSize);
				
			
			// Process any remaining members.
			logger.debug(resetCount + " members had their elapsed time reset");
		} catch (Exception e) {
			businessProgramService.writeToAuditLog(statusCalculationCommand, "BPM Batch Process Status (Process Member Elapsed Time) - " + BPMConstants.RESULT_FAILURE, "no start date", "no end date",
					"no elapsed time", Integer.toString(resetCount));
			logger.error("An unexpected error has occured: " + e.getMessage(),
					e);
			throw new BPMException(e);
		}

		logger.info("@end - evaluate members still eligible after qualification period as part of elapsed-time checking. ");
		
		businessProgramService.writeToAuditLog(statusCalculationCommand, "BPM Batch Process Status (Process Member Elapsed Time) - " + BPMConstants.RESULT_SUCCESS, "no start date", "no end date",
				"no elapsed time", Integer.toString(resetCount));
	}
	
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
			com.healthpartners.service.imfs.exception.BPMBusinessValidationException.class, BPMException.class })
	private void notifyMembershipAndSendEmail(StatusCalculationCommand statusCalculationCommand)
	throws BPMException
	{
		logger.info("@Start - Notify Membership of approaching membership status flag.");

		updateMembershipStatusFlag();		
		// Notify Membership once about programs whose membership process flag is set.
		// Membership-Ready = true
		notifyMembership(statusCalculationCommand.getProcessName(), true);
		
		// And once again about programs whose membership process flag will be set in the next 2 days.
		// Membership-Ready = false
		notifyMembership(statusCalculationCommand.getProcessName(), false);
    }
	

private void processMbrShipFeedCommand(
			StatusCalculationCommand statusCalculationCommand)
			throws BPMException
	{
		logger.info("@Start - Membership Feed. ");
		
		String failureReason = null;
		String elapsedTime = null;
		
		java.util.Date startDate = new java.util.Date();
		java.util.Date endDate = null;
		int recordsSentToMembershipCount = 0;
		int recordsWrittenToGroupSiteYearCount = 0;
		recycleRecordsOnHoldR1 = 0;
		recycleRecordsOnHoldR2 = 0;
		recycleRecordsOnHoldR3 = 0;
		recycleRecordsOnHoldToReleased = 0; 
		recycleRecordsApprovedToReleased = 0; 
		recycleRecordsDeniedNNowQaulified = 0;
		recycleRecordsOnHoldToBeReleased = 0;
		recycleRecordsOnHoldWaitingToBeReviewed = 0;
		
		// Read through recycle table for ON HOLD's.  Check to see if now Q.  If Q, then set person contract date
		// to todays date so BPM person contract is included with the rest of the membership feed transactions.
		
		recycleRecordsOnHoldToBeReleased = determineIfQualfiedForRemainingOnHolds();
		
		BPMAuditRecord bpmAuditRecord = new BPMAuditRecord();
		ReconLogStage reconLogStage = new ReconLogStage();
		
		String processName = statusCalculationCommand.getProcessName();
		bpmAuditRecord.setApplicationId(processName);
		bpmAuditRecord.setApplicationEvent("processMbrShipFeedCommand");
		statusCalculationCommand.setCurrentCommandText("Membership Status Update Feed");
		int recordsInPersonProgramTableCount =  membershipFeedStageService.getPersonProgramCount();

		logger.info("++++++ recordsInPersonProgramTableCount " + recordsInPersonProgramTableCount);
		
		Collection<PersonProgramStage> personProgamsStage = null;					
		
		if (recordsInPersonProgramTableCount == 0) {
			try {
					
					 personProgamsStage = personDAO.getMembershipStatusFeed(processName);
					if (!personProgamsStage.isEmpty()) {
						//TEST ONLY: limitRecords used for testing purposes so have control over volume being written.
						//personProgamsStage = limitRecords(personProgamsStage);
						Collection<PersonProgramStage> personProgramsStagePassedTollgate = membershipFeedTollgate(personProgamsStage);
						recordsSentToMembershipCount = membershipFeedStageService.insertPersonPrograms(personProgramsStagePassedTollgate);
						
						bpmAuditRecord.setParam4(Integer.toString(recordsSentToMembershipCount));
						//removed because of tollgate process.  Count from BPM membershipfeed query is not always accurate and will
						// not match person contract cache count when an approved recycle record is processed.  May find we need it in the future.
						/*int recordsWrittenToMembershipTableCount = membershipFeedStageService.getPersonProgramCount();
						int personsWithStatusChangeCount = personProgamsStage.size();
						if (personsWithStatusChangeCount != recordsWrittenToMembershipTableCount) {
							failureReason = "Records written to membership table do not match record count for persons with status changes:  personsWithStatusChangeCount is " + personsWithStatusChangeCount + " : recordsWrittenToMembershipTableCount is " +  recordsWrittenToMembershipTableCount;
						}*/
						Collection<GroupSiteYearStage> bpmGroupSiteYearsStage = businessProgramService.getBPMGroupSiteYear();
						
						if (bpmGroupSiteYearsStage.isEmpty()) {
							failureReason = "No GroupSiteYear records written to staging table.  This is a refresh process so there should be records.  Investigate!";
						} else {
							recordsWrittenToGroupSiteYearCount = membershipFeedStageService.insertGroupSiteYears(bpmGroupSiteYearsStage);
							if (bpmGroupSiteYearsStage.size() != recordsWrittenToGroupSiteYearCount) {
								failureReason = "Records written to group site year table do not match record count from BPM groupSiteYear:  BPMgroupSiteYearCount is " + bpmGroupSiteYearsStage.size() + " : recordsWrittentToGroupSiteYearCount is " +  recordsWrittenToGroupSiteYearCount;
							}
						}
					}
				} catch (Exception e) {
					failureReason = BPMUtils.getStakTraceAsString(e);
					logger.error(failureReason, e);
				} finally {
					endDate = new java.util.Date();
					elapsedTime = BPMUtils
							.getTimeDifferenceAsString(startDate, endDate);
					logger.info("@@@@End - Records sent to membership (person program stage table) count ="
							+ recordsSentToMembershipCount + "..Total Time =" + elapsedTime);
					logger.info("@@@@End - Records sent to membership (Group Site Year stage table) count ="
							+ recordsWrittenToGroupSiteYearCount);
					logger.info("@@@@End - TOLLGATE TO ON HOLD Rule 1: Number of person contracts placed ON HOLD and written to recycle file: ="
							+ recycleRecordsOnHoldR1);
					logger.info("@@@@End - TOLLGATE TO ON HOLD Rule 2: Number of person contracts placed ON HOLD and written to recycle file: ="
							+ recycleRecordsOnHoldR2);
					logger.info("@@@@End - TOLLGATE TO ON HOLD Rule 3: Number of person contracts placed ON HOLD and written to recycle file: ="
							+ recycleRecordsOnHoldR3);
					logger.info("@@@@End - TOLLGATE RELEASED (APPROVED): Number of person contracts APPROVED triggering release from recycle file:  ="
							+ recycleRecordsApprovedToReleased);
					logger.info("@@@@End - TOLLGATE ON HOLD WAITING TO BE REVIEWED FOR RELEASE AND ARE NOW QUALIFIED:  = "
							+ recycleRecordsOnHoldWaitingToBeReviewed);
					logger.info("@@@@End - TOLLGATE ON HOLD TO BE RELEASED DUE TO NOW QUALIFIED:  = "
							+ (recycleRecordsOnHoldToBeReleased - recycleRecordsOnHoldWaitingToBeReviewed));
					logger.info("@@@@End - TOLLGATE RELEASED (ON HOLD): Number of person contracts ON HOLD but now QUALIFIED triggering release from recycle file:  ="
							+ recycleRecordsOnHoldToReleased);
					logger.info("@@@@End - TOLLGATE DENIED TO ON HOLD: Number of person contracts that went from DENIED to ON HOLD due to contract now qualified:  = "
							+ recycleRecordsDeniedNNowQaulified);
					
					
				}
			
		} else {
			endDate = new java.util.Date();
			elapsedTime = BPMUtils
					.getTimeDifferenceAsString(startDate, endDate);
			failureReason = ("Person Program Stage (PerConPgmStage Cache) TABLE NOT EMPTY! Contact Membership Team to investigate why.  Membership feed will not occur until this table get's cleared out.  Number currently in the table is "
				+ recordsInPersonProgramTableCount);
		}		
			
		StringBuffer batchMailSubject = new StringBuffer();
		batchMailSubject.append("BPM Batch Process Status (Process MemberShip Feed) ");
		StringBuffer batchMailContent = new StringBuffer();
		
		
		
		batchMailContent.append("<tr><td>" + "BPM Batch Name: " + statusCalculationCommand.getCurrentCommandText() + "</td></tr>");

		batchMailContent.append("<tr><td>" + "Initiated User: "
				+ statusCalculationCommand.getUserID());
		batchMailContent.append("<tr><td>" + "Time Start: "
				+ BPMUtils.getFormattedDateTime(startDate) + "\n");
		
		
		batchMailContent
		.append("<tr><td>" + "Number of member's with BPM member status sent to the membership system is "
				+ recordsSentToMembershipCount + "</td></tr>");
		batchMailContent
		.append("<tr><td>" + "TOLLGATE COUNT SUMMARY" + "</td></tr>");

		batchMailContent
		.append("<tr><td>" + "ON HOLD Tollgate Bus Rule 1 (Q to E or DNQ): Person contracts placed ON HOLD in recycle file "
				+ recycleRecordsOnHoldR1 + "</td></tr>");
		batchMailContent
		.append("<tr><td>" + "ON HOLD Tollgate Bus Rule 2 (DNQ to Q with no Exemption): Person contracts placed ON HOLD in recycle file "
				+ recycleRecordsOnHoldR2 + "</td></tr>");
		batchMailContent
		.append("<tr><td>" + "ON HOLD Tollgate Bus Rule 3 (Remains E after Qualification period): Person contracts placed ON HOLD in recycle file "
				+ recycleRecordsOnHoldR3 + "</td></tr>");
		Integer recycleRecordsOnHoldTotal = recycleRecordsOnHoldR1 + recycleRecordsOnHoldR2 + recycleRecordsOnHoldR3;
		if (recycleRecordsOnHoldTotal > 0) {
			
			emailService.setEmailDestination(BPMConstants.EMAIL_DESTINATION_MEMBERSHIP);
			emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
			emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
					batchMailContent.toString());
			
		} 
		batchMailContent
		.append("<tr><td>" + "APPROVED TO RELEASED: Number of person contracts approved triggering release from recycle file: "
				+ recycleRecordsApprovedToReleased + "</td></tr>");
		batchMailContent
		.append("<tr><td>" + "ON HOLD WAITING TO BE REVIEWED: Number of person contracts ON HOLD but now Qualified waiting to be reviewed: "
				+ recycleRecordsOnHoldWaitingToBeReviewed  + "</td></tr>");
		batchMailContent
		.append("<tr><td>" + "ON HOLD TO BE RELEASED: Number of person contracts ON HOLD but now Qualified for release: "
				+ (recycleRecordsOnHoldToBeReleased - recycleRecordsOnHoldWaitingToBeReviewed)  + "</td></tr>");
		batchMailContent
		.append("<tr><td>" + "ON HOLD TO RELEASED: Number of person contracts on hold and now QUALIFIED triggering automatic approve/release from recycle file: "
				+ recycleRecordsOnHoldToReleased + "</td></tr>");
		batchMailContent
		.append("<tr><td>" + "DENIED TO ON HOLD: Number of person contracts that went from DENIED to ON HOLD due to contract now qualified: "
				+ recycleRecordsDeniedNNowQaulified  + "</td></tr>");
		
		
		if (failureReason != null) {
			bpmAuditRecord.setEventResult("FAILED");
			batchMailSubject.append("- FAILED");
			batchMailContent.append("\nResult: FAILED");
			batchMailContent.append("\nReason: \n");
			batchMailContent.append(failureReason);
		} else {
			bpmAuditRecord.setEventResult("SUCCESS");
			batchMailSubject.append("- SUCCESS");
			batchMailContent.append("\nResult: SUCCESS");
		}
		emailService.setEmailDestination(BPMConstants.EMAIL_DESTINATION_MEMBERSHIP);
		emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
		emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
				batchMailContent.toString());
		
		Integer newAuditLogId = businessProgramService.createAuditEventLogEntry(bpmAuditRecord);
		
		reconLogStage.setAuditLogId(newAuditLogId);
		reconLogStage.setAppEventResultId(bpmAuditRecord.getEventResult());
		reconLogStage.setAppEventId(bpmAuditRecord.getApplicationEvent());
		reconLogStage.setAppId(bpmAuditRecord.getApplicationId());
		reconLogStage.setParam1Id(bpmAuditRecord.getParam1());
		reconLogStage.setParam2Id(bpmAuditRecord.getParam2());
		reconLogStage.setParam3Id(Integer.toString(recordsWrittenToGroupSiteYearCount));
		reconLogStage.setParam4Id(bpmAuditRecord.getParam4());
		
		createReconLogStageEntry(reconLogStage);
		
		businessProgramService.writeToAuditLog(statusCalculationCommand, batchMailSubject.toString(), startDate.toString(), endDate.toString(),
				elapsedTime.toString(), Integer.toString(recordsWrittenToGroupSiteYearCount));
	
		createPersonContractOnHoldReport(statusCalculationCommand);

		if (failureReason != null) {
			logger.info("processMbrShipFeedCommand Failed: " + failureReason);
			throw new BPMException(failureReason);
		}
		
		logger.info("@End - Membership Feed. ");
	}

	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
			com.healthpartners.service.imfs.exception.BPMBusinessValidationException.class, BPMException.class })
public void processCDHPHRAContributionsCommand(
			StatusCalculationCommand statusCalculationCommand)
			throws BPMException
	{
		logger.info("@Start - HRA Contributions. ");
		
		String failureReason = null;
		String elapsedTime = null;
		
		java.util.Date startDate = new java.util.Date();
		java.util.Date endDate = null;
		int recordsGeneratedCount = 0;
		int contributionsAchievedCount = 0;
		int contributionsAchievedTierModel = 0;
		int contributionsAchievedEmployerSponsored = 0;
		
		recycleRecordsOnHoldR1 = 0;
		recycleRecordsOnHoldR2 = 0;
		recycleRecordsOnHoldR3 = 0;
		recycleRecordsApprovedToReleased = 0; 
		
		
		
		
		BPMAuditRecord bpmAuditRecord = new BPMAuditRecord();
		ReconLogStage reconLogStage = new ReconLogStage();
		
		String processName = statusCalculationCommand.getProcessName();
		bpmAuditRecord.setApplicationId(processName);
		bpmAuditRecord.setApplicationEvent("processHRAContributionCommand");
		statusCalculationCommand.setCurrentCommandText("HRA Contribution Feed");
		
		try {
			    Collection<PersonActivityAchievedContribution> hraParticipantContributionsMerged = null; 
				ArrayList<PersonActivityAchievedContribution> hraParticipantContributions = personDAO.getAllCDHPHRAParticipantContributions();
				
				contributionsAchievedCount = hraParticipantContributions.size();
				hraParticipantContributionsMerged = processCDHPTollgateRules(hraParticipantContributions);
				
				Collection<PersonActivityAchievedContribution> hraParticipantCompletionsNCombinedSameDay = combineContributionsByContract(hraParticipantContributions);
				
				int recsWrittenContractAchieved = 0;
				int recsWrittenPersonAchieved = 0;
				
				if (hraParticipantContributionsMerged.size() > 0) {
					recsWrittenPersonAchieved = memberService.insertCDHPFulfillmentHistory(hraParticipantContributionsMerged);
				}
				if (hraParticipantCompletionsNCombinedSameDay.size() > 0) {
					recsWrittenContractAchieved = memberService.insertCDHPFulfillments(hraParticipantCompletionsNCombinedSameDay);
				}
			    
				Calendar pCalendar = Calendar.getInstance();
				
				java.sql.Date fileSentDate = new java.sql.Date(pCalendar.getTime().getTime());
				
				if (statusCalculationCommand.getSnapShotCDHPHRAFulfillTrackDate() != null) {
					fileSentDate = BPMUtils.getDateMMDDYYYYFromString(statusCalculationCommand.getSnapShotCDHPHRAFulfillTrackDate());
				} 
				
				Collection<CDHPFulfillmentTrackingReport> hraFulfillmentContributionTrackingRpts = contractDAO.getCDHPFulfillmentTrackingReport(null, BPMConstants.CDHP_PURCH_SUB_TP_NM_HRA, fileSentDate);
				
				hraFulfillmentContributionTrackingRpts = assignSupportingAttributes(hraFulfillmentContributionTrackingRpts, BPMConstants.CDHP_BATCH_TYPE_HRA);
				
				logger.info("@@@@ - CDHP HRA Contributions to send " + hraFulfillmentContributionTrackingRpts.size());
				
				
				recordsGeneratedCount = sendCDHPHraContributionFile(hraFulfillmentContributionTrackingRpts);
				
				logger.info("@@@@ - CDHP HRA Contributions sent " + recordsGeneratedCount);
				
				int recBatchLogWritten = insertCDHPBatchLog(recordsGeneratedCount, BPMConstants.CDHP_BATCH_TYPE_HRA);
				logger.info("@@@@ - CDHP Batch Log record written count " + recBatchLogWritten);
				bpmAuditRecord.setParam4(Integer.toString(recBatchLogWritten));
					
			} catch (Exception e) {
				failureReason = BPMUtils.getStakTraceAsString(e);
				logger.error(failureReason, e);
			} finally {
				endDate = new java.util.Date();
				elapsedTime = BPMUtils
						.getTimeDifferenceAsString(startDate, endDate);
				logger.info("@@@@End - Records sent to Surround (Powerplus) count ="
						+ recordsGeneratedCount + "..Total Time =" + elapsedTime);
				
				logger.info("@@@@End - TOLLGATE TO ON HOLD Rule 1: Number of person HRA contributions placed ON OLD due to already being sent: ="
						+ recycleRecordsOnHoldR1);
				logger.info("@@@@End - TOLLGATE TO ON HOLD Rule 2: Number of person HRA contributions placed ON HOLD for participant cap exceeded: = "
						+ recycleRecordsOnHoldR2);
				logger.info("@@@@End - TOLLGATE TO ON HOLD Rule 3: Number of person HRA contributions placed ON HOLD for family cap exceeded: = "
						+ recycleRecordsOnHoldR3);
				logger.info("@@@@End - TOLLGATE RELEASED (APPROVED): Number of person HRA contributions APPROVED triggering release from recycle file:  ="
						+ recycleRecordsApprovedToReleased);
			}
			
	
			
		StringBuffer batchMailSubject = new StringBuffer();
		batchMailSubject.append("BPM HRA Contribution Batch Process Status");
		
		StringBuffer batchMailContent = new StringBuffer();
		batchMailContent.append("<tr><td>" + "BPM Batch Name: " + statusCalculationCommand.getCurrentCommandText() + "</td></tr>");

		batchMailContent.append("<tr><td>" + "Initiated User: "
				+ statusCalculationCommand.getUserID() + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Time Start: "
				+ BPMUtils.getFormattedDateTime(startDate) + "</td></tr>");
		
		batchMailContent
		.append("<tr><td>" + "Number of person HRA Contributions to be processed based upon contribution tiering model: "
				+ contributionsAchievedTierModel + "</td></tr>");
		
		batchMailContent
		.append("<tr><td>" + "Number of person HRA Contributions to be processed based upon Employer Sponsored Contribution: "
				+ contributionsAchievedEmployerSponsored + "</td></tr>");
		
		batchMailContent
		.append("<tr><td>" + "Number of person HRA Contributions to process is "
				+ contributionsAchievedCount + "</td></tr>");
		 
		batchMailContent
		.append("<tr><td>" + "Number of person HRA Contributions sent to EDI for processing by Surround System(PowerPlus) is "
				+ recordsGeneratedCount + "</td></tr>");
		batchMailContent
		.append("<tr><td>" + "TOLLGATE COUNT SUMMARY" + "</td></tr>");
		
		batchMailContent
		.append("<tr><td>" + "ON HOLD Tollgate Bus Rule 1 (HRA contribution already sent): Person HRA contributions to recycle file "
				+ recycleRecordsOnHoldR1 + "</td></tr>");
		batchMailContent
		.append("<tr><td>" + "ON HOLD Tollgate Bus Rule 2 (Participant cap exceeded): Person HRA contributions to recycle file "
				+ recycleRecordsOnHoldR2 + "</td></tr>");
		batchMailContent
		.append("<tr><td>" + "ON HOLD Tollgate Bus Rule 3 (Family cap exceeded): Person HRA contributions to recycle file "
				+ recycleRecordsOnHoldR3 + "</td></tr>");
		batchMailContent
		.append("<tr><td>" + "ON HOLD Tollgate Bus Rule 4 (Person activity contribution already achieved across a contract or package.): Captured to CDHP Fulfillment Recycle file. See Member Activity CDHP Fulfillment Error Recycle ON HOLD Report." + "</td></tr>");
	  
		Collection<PersonProgramActivityIncentiveStatus> unresolvedPersonProgramActivityIncentiveStatus = personDAO.getUnresolvedPersonPgmActivityIncentiveStatus();
		
		if (unresolvedPersonProgramActivityIncentiveStatus.size() > 0) {
			batchMailContent
			.append("<tr><td>" + "ATTENTION!  Unresolved Benefit Contract Types exist in the person program actvity incentive status table.  Count is "
				+ unresolvedPersonProgramActivityIncentiveStatus.size() + "\nIMPACT: This needs to be researched and resolved since its preventing members from getting HRA contribuitons." + "</td></tr>");
			emailService.setEmailDestination(BPMConstants.EMAIL_DESTINATION_CDHP_HRA);
			emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
			emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
					batchMailContent.toString());
			
		}
		batchMailContent
		.append("<tr><td>" + "APPROVED TO RELEASED: Number of person HRA contributions approved triggering release from recycle file: "
				+ recycleRecordsApprovedToReleased + "</td></tr>");
		
		if (failureReason != null) {
			bpmAuditRecord.setEventResult("FAILED");
			batchMailSubject.append("- FAILED");
			batchMailContent.append("\nResult: FAILED");
			batchMailContent.append("\nReason: \n");
			batchMailContent.append(failureReason);
		} else {
			bpmAuditRecord.setEventResult("SUCCESS");
			batchMailSubject.append("- SUCCESS");
			batchMailContent.append("\nResult: SUCCESS");
		}
		emailService.setEmailDestination(BPMConstants.EMAIL_DESTINATION_CDHP_HRA);
		emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
		emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
				batchMailContent.toString());
		
		Integer newAuditLogId = businessProgramService.createAuditEventLogEntry(bpmAuditRecord);
		
		reconLogStage.setAuditLogId(newAuditLogId);
		reconLogStage.setAppEventResultId(bpmAuditRecord.getEventResult());
		reconLogStage.setAppEventId(bpmAuditRecord.getApplicationEvent());
		reconLogStage.setAppId(bpmAuditRecord.getApplicationId());
		reconLogStage.setParam1Id(bpmAuditRecord.getParam1());
		reconLogStage.setParam2Id(bpmAuditRecord.getParam2());
		reconLogStage.setParam3Id(bpmAuditRecord.getParam3());
		reconLogStage.setParam4Id(bpmAuditRecord.getParam4());
		

		
		businessProgramService.writeToAuditLog(statusCalculationCommand, batchMailSubject.toString(), startDate.toString(), endDate.toString(),
				elapsedTime.toString(), Integer.toString(recordsGeneratedCount));
	

		if (failureReason != null) {
			logger.info("CDHP HRA Member Fulfillment batch process Failed: " + failureReason);
			throw new BPMException(failureReason);
		}
		
		
		logger.info("@End - processHRAContributionCommand. ");
	}
	
	

	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
			com.healthpartners.service.imfs.exception.BPMBusinessValidationException.class, BPMException.class })
public void processCDHPHSAContributionsCommand(
			StatusCalculationCommand statusCalculationCommand)
			throws BPMException
	{
		logger.info("@Start - HSAContributions. ");
		
		String failureReason = null;
		String elapsedTime = null;
		
		Calendar pCalendar = Calendar.getInstance();
		java.sql.Date transactionDate = new java.sql.Date(pCalendar.getTime().getTime());
		
		java.util.Date startDate = new java.util.Date();
		java.util.Date endDate = null;
		int contributionsAchievedCount = 0;
		int recordsGeneratedCount = 0;
		
		
		BPMAuditRecord bpmAuditRecord = new BPMAuditRecord();
		ReconLogStage reconLogStage = new ReconLogStage();
		
		String processName = statusCalculationCommand.getProcessName();
		bpmAuditRecord.setApplicationId(processName);
		bpmAuditRecord.setApplicationEvent("processHSAContributionCommand");
		statusCalculationCommand.setCurrentCommandText("HSA Contribution Feed");
		int recsWrittenPersonAchievedHSA = 0;
		
		Collection<CDHPControlGroup> lCDHPControlGroups = null;
		
		try {
			    
				Collection<PersonActivityAchievedContribution> hsaParticipantContributions = personDAO.getAllCDHPHSAParticipantContributions();
				
				contributionsAchievedCount = hsaParticipantContributions.size();
				hsaParticipantContributions = processCDHPTollgateRules(hsaParticipantContributions);
				
				int recsWrittenContractAchieved = 0;
				
				
				if (hsaParticipantContributions.size() > 0) {
					recsWrittenPersonAchievedHSA = memberService.insertCDHPFulfillmentHistory(hsaParticipantContributions);
				}
				
				
				// read from HSA Group FTP Control Table all active HSA groups
				lCDHPControlGroups = cdhpControlGroupDAO.getCDHPControlGroups();
				Iterator<CDHPControlGroup> iter ;

				if(lCDHPControlGroups != null){
					 iter =  (Iterator<CDHPControlGroup>)lCDHPControlGroups.iterator();
				}else {
					iter = null;
				}
				if(iter != null) {
					while (iter.hasNext()) {

						CDHPControlGroup lCDHPControlGroup = (CDHPControlGroup) iter.next();

						//determine if group will run based on run frequency here
						String runFrequency = lCDHPControlGroup.getRunFrequency();

						if (isTimeToProcessGroup(runFrequency)) {
							try {
								Collection<CDHPFulfillmentTrackingReportHist> hsaFulfillmentContributionHistoryTrackingRpts = null;
								logger.info("@@@@ - Start processing HSA Group " + lCDHPControlGroup.getGroupNo());

								lCDHPControlGroup.setGroupProcessedToday();
								//Retrieve most recent processing tracking record for group when the group was last run.
								CDHPControlGroupProcessTracker lCDHPControlGroupProcessTracker = cdhpControlGroupDAO.getCDHPControlGroupProcessTracker(lCDHPControlGroup.getControlGroupID());
								//Using the group number, package sub type (Group - HSA), and
								//date last HSA's sent for group, retrieve all persons achieving HSA contributions.
								if (lCDHPControlGroupProcessTracker != null) {
									hsaFulfillmentContributionHistoryTrackingRpts =
											personDAO.getCDHPFulfillmentTrackingReportHistByGroup(lCDHPControlGroup.getGroupNo(), lCDHPControlGroup.getPackageSubType(), lCDHPControlGroupProcessTracker.getDateLastProcessed());
								} else {
									throw new Exception("No CDHP Control Group Process Tracker record exists for determining when HSA contributions were last processed for group " + lCDHPControlGroup.getGroupNo());
								}

								Integer readyToRetrieveFromEmployerPortalCount = 0;

								if (hsaFulfillmentContributionHistoryTrackingRpts.size() > 0) {
									lCDHPControlGroup.setCdhpFulfillmentReportHistCountToProcess(hsaFulfillmentContributionHistoryTrackingRpts.size());

									//Need to remap field attributes from lCDHPFulfillmentTrackingReportHist DTO to PersonActivityAchievedContribution DTO
									//so contribution combine method can be reused along with method call insertCDHPFulfillments.
									Collection<PersonActivityAchievedContribution> lPersonActivityAchievedContribution =
											mapperPersonActivityAchievedContribution(hsaFulfillmentContributionHistoryTrackingRpts);

									Collection<PersonActivityAchievedContribution> hsaParticipantCompletionsNCombinedContributionDate =
											combineContributionsByContributionDateWithinContract(lPersonActivityAchievedContribution);
									lCDHPControlGroup.setContributionsAfterCombineCount(hsaParticipantCompletionsNCombinedContributionDate.size());
									if (hsaParticipantCompletionsNCombinedContributionDate.size() > 0) {
										recsWrittenContractAchieved = memberService.insertCDHPFulfillments(hsaParticipantCompletionsNCombinedContributionDate);
										lCDHPControlGroup.setInsertCDHPFulfillmentCount(recsWrittenContractAchieved);
									}

									Collection<CDHPFulfillmentTrackingReport> hsaFulfillmentContributionTrackingRpts = contractDAO.getCDHPFulfillmentTrackingReport(lCDHPControlGroup.getGroupNo(), lCDHPControlGroup.getPackageSubType(), transactionDate);

									readyToRetrieveFromEmployerPortalCount = countReadyToRetrieveFromEmployerPortal(hsaFulfillmentContributionTrackingRpts);
									lCDHPControlGroup.setCdhpFulfillmentCountToBeRetrievedFromEmployerPortal(readyToRetrieveFromEmployerPortalCount);

									hsaFulfillmentContributionTrackingRpts = determineSendToHPDIT(hsaFulfillmentContributionTrackingRpts);
									lCDHPControlGroup.setCdhpFulfillmentCountToSendToHPDIT(hsaFulfillmentContributionTrackingRpts.size());


									if (hsaFulfillmentContributionTrackingRpts.size() > 0) {
										hsaFulfillmentContributionTrackingRpts = assignSupportingAttributes(hsaFulfillmentContributionTrackingRpts, BPMConstants.CDHP_BATCH_TYPE_HSA);
										logger.info("@@@@ - CDHP HSA Contributions to send to HPDIT " + hsaFulfillmentContributionTrackingRpts.size());
										recordsGeneratedCount = generatCSVNFTPCDHPHsaContributionFile(hsaFulfillmentContributionTrackingRpts, lCDHPControlGroup);

										logger.info("@@@@ - CDHP HSA Contributions successfully sent to HPDIT " + recordsGeneratedCount);
									} else if (readyToRetrieveFromEmployerPortalCount > 0) {
										logger.info("@@@@ - CDHP HSA Contributions ready to be retrieved from Employer Portal count is " + readyToRetrieveFromEmployerPortalCount);
										recordsGeneratedCount = readyToRetrieveFromEmployerPortalCount;
									} else {
										logger.info("@@@@ - No CDHP HSA Contributions to send to HPDIT today.");
									}
								}

								cdhpControlGroupDAO.insertCDHPControlGroupProcessTracker(lCDHPControlGroup.getControlGroupID(), BPMConstants.RESULT_SUCCESS, recordsGeneratedCount);
							} catch (Exception e) {
								cdhpControlGroupDAO.insertCDHPControlGroupProcessTracker(lCDHPControlGroup.getControlGroupID(), BPMConstants.RESULT_FAILURE, recordsGeneratedCount);
								throw new Exception("Error during processing of HSA contributions.  Group being processed is " + lCDHPControlGroup.getGroupNo() + "Exception: " + e);
							}
						} else {
							logger.info("@@@@ - No CDHP HSA Groups ACTIVE at this time. CDHPControlGroup record count is " + lCDHPControlGroups.size());
						}

					}

				}
				logger.info("@@@@ - CDHP HSA Contributions loaded to CDHPFulfillmentHistory " + recsWrittenPersonAchievedHSA);
				
				
				int recBatchLogWritten = insertCDHPBatchLog(recsWrittenPersonAchievedHSA, BPMConstants.CDHP_BATCH_TYPE_HSA);
				logger.info("@@@@ - CDHP Batch Log record written count " + recBatchLogWritten);
				bpmAuditRecord.setParam4(Integer.toString(recsWrittenPersonAchievedHSA));
					
			} catch (Exception e) {
				failureReason = BPMUtils.getStakTraceAsString(e);
				logger.error(failureReason, e);
			} finally {
				endDate = new java.util.Date();
				elapsedTime = BPMUtils
						.getTimeDifferenceAsString(startDate, endDate);
			}
			
	
			
		StringBuffer batchMailSubject = new StringBuffer();
		batchMailSubject.append("BPM HSA Contribution Batch Process Status");
		
		StringBuffer batchMailContent = new StringBuffer();
		batchMailContent.append("<tr><td>" + "\nBPM Batch Name: " + statusCalculationCommand.getCurrentCommandText() + "</td></tr>");

		batchMailContent.append("<tr><td>" + "Initiated User: "
				+ statusCalculationCommand.getUserID() + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Time Start: "
				+ BPMUtils.getFormattedDateTime(startDate) + "</td></tr>");
		
		batchMailContent
		.append("<tr><td>" + "Number of person HSA Contributions written to CDHP Fulfillment History table: "
				+ contributionsAchievedCount + "</td></tr>");
		 
		batchMailContent
		.append("<tr><td>" + "What follows is information on participating HSA employer groups:" + "</td></tr>");
		
		Iterator<CDHPControlGroup> iter =  (Iterator<CDHPControlGroup>)lCDHPControlGroups.iterator();
		boolean noGroupsProcessed = true;
		while (iter.hasNext()) {
			CDHPControlGroup lCDHPControlGroup = (CDHPControlGroup)iter.next();
			
			if (lCDHPControlGroup.isGroupProcessedToday()) {
				noGroupsProcessed = false;
				batchMailContent
				.append("<tr><td>" + "=======================================================================================" + "</td></tr>");
				batchMailContent
				.append("<tr><td>" + "Control group run frequency is "
						+ lCDHPControlGroup.getRunFrequency() + "</td></tr>");
				batchMailContent
				.append("<tr><td>" + "HSA file produced for group "
						+ lCDHPControlGroup.getGroupNo() + "-" + lCDHPControlGroup.getGroupName() + "</td></tr>");
				batchMailContent
				.append("<tr><td>" + "HSA person contribution record count from CDHP Fulfillment Report Tracking History Table  "
						+ lCDHPControlGroup.getCdhpFulfillmentReportHistCountToProcess() + "</td></tr>");
				batchMailContent
				.append("<tr><td>" + "HSA contribution count after combine consideration at contract level "
						+ lCDHPControlGroup.getContributionsAfterCombineCount() + "</td></tr>");
				batchMailContent
				.append("<tr><td>" + "HSA contribution records written to CDHP Fulfillment table "
						+ lCDHPControlGroup.getInsertCDHPFulfillmentCount() + "</td></tr>");
				
				
				if (lCDHPControlGroup.getOutputExternalFileServerDirectoryPath().isEmpty()) {
					batchMailContent
					.append("<tr><td>" + "CDHP HSA Fulfillment table loaded for Employer Portal to report against. Record count is " + lCDHPControlGroup.getCdhpFulfillmentCountToBeRetrievedFromEmployerPortal() + "</td></tr>");
					
				} else {
					batchMailContent
					.append("<tr><td>" + "CDHP HSA Fulfillment records FTP'ed to HPDIT location " + "//hpstore2/cip/" + lCDHPControlGroup.getOutputExternalFileServerDirectoryPath() + "." + "  Record count is "
							+ lCDHPControlGroup.getCdhpFulfillmentCountToSendToHPDIT() + "</td></tr>");
					batchMailContent
					.append("<tr><td>" + "*Note: Records written to CDHP Fulfillment table vs records sent to HPDIT may be different due to"  + "</td></tr>"
							+ "<tr><td>" + "how the fulfillment routing type is setup. Example: Send To HPDIT vs Send to Employer Group." + "</td></tr>");
				}
			}
		}
		
		if (noGroupsProcessed) {
			batchMailContent
			.append("<tr><td>" + "ATTENTION: NO CDHP HSA GROUP FILES WERE FTP'ED TODAY" + "</td></tr>");
		}
	  
		
		
		if (failureReason != null) {
			bpmAuditRecord.setEventResult("FAILED");
			batchMailSubject.append("- FAILED");
			batchMailContent.append("\nResult: FAILED");
			batchMailContent.append("\nReason: \n");
			batchMailContent.append(failureReason);
		} else {
			bpmAuditRecord.setEventResult("SUCCESS");
			batchMailSubject.append("- SUCCESS");
			batchMailContent.append("\nResult: SUCCESS");
		}
		emailService.setEmailDestination(BPMConstants.EMAIL_DESTINATION_CDHP_HSA);
		emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
		emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
				batchMailContent.toString());
		
		Integer newAuditLogId = businessProgramService.createAuditEventLogEntry(bpmAuditRecord);
		
		reconLogStage.setAuditLogId(newAuditLogId);
		reconLogStage.setAppEventResultId(bpmAuditRecord.getEventResult());
		reconLogStage.setAppEventId(bpmAuditRecord.getApplicationEvent());
		reconLogStage.setAppId(bpmAuditRecord.getApplicationId());
		reconLogStage.setParam1Id(bpmAuditRecord.getParam1());
		reconLogStage.setParam2Id(bpmAuditRecord.getParam2());
		reconLogStage.setParam3Id(bpmAuditRecord.getParam3());
		reconLogStage.setParam4Id(bpmAuditRecord.getParam4());
		

		
		businessProgramService.writeToAuditLog(statusCalculationCommand, batchMailSubject.toString(), startDate.toString(), endDate.toString(),
				elapsedTime.toString(), Integer.toString(recsWrittenPersonAchievedHSA));
	

		if (failureReason != null) {
			logger.info("CDHP HSA Member Fulfillment batch process Failed: " + failureReason);
			throw new BPMException(failureReason);
		}
		
		
		logger.info("@End - processHSAContributionCommand. ");
	}
/*
 * Batch job to process and route reward transactions to Intelispend vendor using their hosted webservice.  Transactins
 * sent represent a request for gift cards.  Quote ID determines what type of gift card they get.  Quote ID is provided
 * by the vendor.
 */
/*
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
			com.healthpartners.service.imfs.exception.BPMBusinessValidationException.class, BPMException.class })
private void processRewardsToIntelispendCommand(
			StatusCalculationCommand statusCalculationCommand)
			throws BPMException {
		logger.info("@Start - Rewards. ");


		String failureReason = null;
		String elapsedTime = null;


		ArrayList<String> rewardSetupNotCompleteForQuoteID = new ArrayList<String>();

		java.util.Date startDate = new java.util.Date();
		java.util.Date endDate = null;

		setErrorMessageFromVendorWebservice(null);


		statusCalculationCommand.setCurrentCommandText("Reward Transaction Feed To InteliSpend");

		ArrayList<RewardCardQuoteByProgramSummary> lRewardCardQuoteByProgramsSummaryArrayList = new ArrayList<RewardCardQuoteByProgramSummary>();


		Collection<RewardCardQuoteByProgramSummary> rewardCardQuoteByProgramsSummary = null;

		HashMap<String, String> quoteOrderNumberMap = new HashMap<String, String>();

		Collection<RewardCardQuote> lRewardCardQuotes = null;

		String processXMLRewardErrorMessage = null;

		try {

			RewardCardClientData lKnowYourClientData = null;

			Collection<RewardControlProgram> lRewardControlPrograms = null;
			HashMap<String, Collection<RewardFulfillmentTrackingReportHist>> lQuoteRewardsHashMap = new HashMap<String, Collection<RewardFulfillmentTrackingReportHist>>();

			lRewardCardQuotes = rewardCardService.getQuotesFromBusProgramsWithRewardCards();
			logger.info("quotes returned size " + lRewardCardQuotes.size());
			for (RewardCardQuote lRewardCardQuote : lRewardCardQuotes) {

				String quoteID = lRewardCardQuote.getQuoteID();

				RewardCardQuoteByProgramSummary lRewardCardQuoteByProgramSummary = new RewardCardQuoteByProgramSummary();
				lRewardCardQuoteByProgramSummary.setQuoteID(quoteID);


				lRewardControlPrograms = rewardCardService.getRewardControlPrograms(quoteID);

				logger.info("number of programs returned " + lRewardControlPrograms.size());

				for (RewardControlProgram lRewardControlProgram : lRewardControlPrograms) {

					lKnowYourClientData = rewardCardService.getRewardCardClientData(lRewardControlProgram.getProgramID(), lRewardControlProgram.getIncentiveOptionID());

					lRewardControlProgram.setProgramProcessedToday();
					//Retrieve most recent processing tracking record for group when the group was last run successfully.
					RewardControlProgramProcessTracker lRewardControlProgramProcessTracker = rewardCardService.getRewardControlProgramProcessTracker(lRewardControlProgram.getControlProgramID());

					//Determine if incented activites eligible for reward card exist and ready
					//to be fulfilled for program enrolled in reward card incentives.
					Collection<PersonActivityAchievedReward> lPersonActivityAchievedRewards = personDAO.getAllParticipantRewards(lRewardControlProgram.getProgramID(), lRewardControlProgramProcessTracker.getDateLastProcessed());
					logger.info("rewards fulfilled " + lPersonActivityAchievedRewards.size());
					if (lPersonActivityAchievedRewards.size() > 0) {


						lPersonActivityAchievedRewards = evaluateTollgateRulesForIncentedRewardActivities(lPersonActivityAchievedRewards, lRewardCardQuoteByProgramSummary);

						logger.info("Number of records to insert to fulfillment table " + lPersonActivityAchievedRewards.size());
						memberService.insertRewardFulfillmentHistory(lPersonActivityAchievedRewards);

						recordToProgramRewardsFulfilledSummaryMap(lRewardCardQuoteByProgramSummary.getProgramRewardFulfilledSummaryMap(), lPersonActivityAchievedRewards);
						recordToProgramControlReportingMap(lRewardCardQuoteByProgramSummary.getProgramControlReportingMap(), lRewardControlProgram);

					}

					//determine if group will run based on run frequency here
					String runFrequency = lRewardControlProgram.getRunFrequency();
					logger.info("run frequency is " + runFrequency);
					if (isTimeToProcessGroup(runFrequency)) {

						Collection<RewardFulfillmentTrackingReportHist> rewardFulfillmentHistoryTrackingRpts = null;
						logger.info("@@@@ - Start processing Reward Program " + lRewardControlProgram.getProgramID());


						//If missing reward control program process tracker record indicates group site enrolled
						//in reward cards for first time so use todays date.
						java.sql.Date dateLastProcessed = BPMUtils.getCurrentDate();
						if (lRewardControlProgramProcessTracker != null) {
							dateLastProcessed = lRewardControlProgramProcessTracker.getDateLastProcessed();
						}

						//Using the business program id, quote id (controls type of card issued by vendor), and
						//date last rewards were sent for the program, retrieve all persons achieving rewards.


						logger.info("Parms: quoteID                              " + quoteID);
						logger.info("In processRewardsToIntelispendCommand. before getRewardFulfillmentTrackingReportHistByProgram ");
						logger.info("Parms: lRewardControlProgram.getProgramID() " + lRewardControlProgram.getProgramID());
						logger.info("Parms: incentiveOptionID                    " + lRewardControlProgram.getIncentiveOptionID());
						logger.info("Parms: date last process succesfully        " + dateLastProcessed);
						rewardFulfillmentHistoryTrackingRpts =
								personDAO.getRewardFulfillmentTrackingReportHistByProgram(lRewardControlProgram.getProgramID(), lRewardControlProgram.getIncentiveOptionID(), quoteID, dateLastProcessed);

						logger.info("Number of records read from fulfillment table " + rewardFulfillmentHistoryTrackingRpts.size());

						recordToProgramRewardsFulfilledReadSummaryMap(lRewardCardQuoteByProgramSummary.getProgramRewardFulfillRptHistReadSummaryMap(), lRewardControlProgram.getProgramID(), rewardFulfillmentHistoryTrackingRpts.size());

						if (rewardFulfillmentHistoryTrackingRpts.isEmpty()) {
							logger.info("No fulfillent records to process for program ID " + lRewardControlProgram.getProgramID());
						} else {

							//Record program control dto indexed by program id to hashmap for reporting summary
							recordToProgramControlReportingMap(lRewardCardQuoteByProgramSummary.getProgramControlReportingMap(), lRewardControlProgram);


							//Check to see if reward fulfillment ON HOLD or DENIED in error recycle then bypass.
							//Also, check for approved status and flip to released allowing transaction to flow through.
							rewardFulfillmentHistoryTrackingRpts = processAgainstRewardRecycle(rewardFulfillmentHistoryTrackingRpts, lRewardCardQuoteByProgramSummary);

							//Check to see if address is available.  If not, write record to error reycle.
							//Once address shows up, then transaction can be released.
							//Note: lRewardCardQuoteByProgramSummary is passed by reference
							rewardFulfillmentHistoryTrackingRpts = rewardCardService.assignAddressUsingMODSWhereToSendRewardCard(rewardFulfillmentHistoryTrackingRpts, lRewardCardQuoteByProgramSummary, lRewardControlProgram);

						}

						lRewardControlProgram.setRewardFulfillmentCountToSendToVendor(rewardFulfillmentHistoryTrackingRpts.size());
						lQuoteRewardsHashMap = batchUpTransactionsByQuoteID(rewardFulfillmentHistoryTrackingRpts, lQuoteRewardsHashMap, quoteID);

					}//end if

				}//end while loop for control groups

				if (lQuoteRewardsHashMap.isEmpty()) {
					logger.info("@@@@ - Empty quote reward hash map indicates that no programs were returned for quoteID " + quoteID);
					rewardSetupNotCompleteForQuoteID.add(quoteID);
				} else {
					lRewardCardQuoteByProgramsSummaryArrayList.add(lRewardCardQuoteByProgramSummary);
				}

			} //end while loop for quote ID

			Integer batchTotalRewardsSent = 0;
			if (lQuoteRewardsHashMap.isEmpty()) {
				logger.info("@@@@ - Empty quote reward hash map indicates that no programs were returned for the quote.");
			} else {
				rewardCardQuoteByProgramsSummary = processXMLRewardFile(lQuoteRewardsHashMap, quoteOrderNumberMap, lRewardCardQuoteByProgramsSummaryArrayList, lKnowYourClientData);
				batchTotalRewardsSent = getBatchTotalRewardSentCount(rewardCardQuoteByProgramsSummary);

			}
			logger.error("Call insertRewardBatchLog method...");
			insertRewardBatchLog(batchTotalRewardsSent, BPMConstants.REWARD_BATCH_TYPE_INTELISPEND);
		} catch (BPMException be) {
			logger.error("BPMException error caught.  Error message being passed.");
			processXMLRewardErrorMessage = be.getMessage();

		} catch (Exception e) {
			logger.error("Exception caught at processRewardsToIntelispendCommand.");
			failureReason = BPMUtils.getStakTraceAsString(e);
			logger.error(failureReason, e);
		} finally {

			endDate = new java.util.Date();
			elapsedTime = BPMUtils
					.getTimeDifferenceAsString(startDate, endDate);
			logger.info("processXMLRewardErrorMessage: " + processXMLRewardErrorMessage);
			logger.info("failureReason: " + failureReason);
			buildNSendRewardCardSummaryEmail(statusCalculationCommand, startDate, endDate, elapsedTime, failureReason, processXMLRewardErrorMessage, lRewardCardQuotes,
						rewardSetupNotCompleteForQuoteID, quoteOrderNumberMap, lRewardCardQuoteByProgramsSummaryArrayList, rewardCardQuoteByProgramsSummary);
			if (failureReason != null) {
				throw new BPMException(failureReason);
			} else if(processXMLRewardErrorMessage != null) {
				        throw new BPMException(processXMLRewardErrorMessage);
			}
		}

		logger.info("@End - processRewardsContributionCommand. ");
		
	}
*/

	private void buildNSendRewardCardSummaryEmail(StatusCalculationCommand statusCalculationCommand,
                                                  java.util.Date startDate,
                                                  java.util.Date endDate,
                                                  String elapsedTime,
                                                  String failureReason,
                                                  String processXMLRewardErrorMessage,
                                                  Collection<RewardCardQuote> lRewardCardQuotes,
                                                  ArrayList<String> rewardSetupNotCompleteForQuoteID,
                                                  HashMap<String, String> quoteOrderNumberMap,
												  ArrayList<RewardCardQuoteByProgramSummary> lRewardCardQuoteByProgramsSummaryArrayList,
												  Collection<RewardCardQuoteByProgramSummary> rewardCardQuoteByProgramsSummary ) {

        logger.info("Build and send email section...");
        StringBuffer batchMailSubject = new StringBuffer();
        batchMailSubject.append("BPM Reward Transactions To InteliSpend Batch Process Status");
        logger.info("BPM Reward Transactions To InteliSpend Batch Process Status");

        StringBuffer batchMailContent = new StringBuffer();
        batchMailContent.append("<tr><td>" + "BPM Batch Name: " + statusCalculationCommand.getCurrentCommandText() + "<td><tr>");
        logger.info("BPM Batch Name: " + statusCalculationCommand.getCurrentCommandText());

        batchMailContent.append("<tr><td>" + "Initiated User: "
                + statusCalculationCommand.getUserID() + "<td><tr>");
        batchMailContent.append("<tr><td>" + "Time Start: "
                + BPMUtils.getFormattedDateTime(startDate) + "<td><tr>");

        batchMailContent.append("<tr><td>" + "Time Ended: "
                + BPMUtils.getFormattedDateTime(endDate) + "<td><tr>");

        batchMailContent.append("<tr><td>" + "Total Elapsed Time was: "
                + elapsedTime + "<td><tr>");



        if (failureReason != null || processXMLRewardErrorMessage != null || getErrorMessageFromVendorWebservice() != null) {
            batchMailSubject.append("- FAILED");
            batchMailContent.append("\nResult: FAILED");

            if (failureReason != null) {
                batchMailContent.append("<tr><td>" + "Reason: " + failureReason + "<td><tr>");
            } else {
                batchMailContent.append("<tr><td>" + "Reason: See error below" + "<td><tr>");
            }
            System.out.println("Total Elapsed Time was: "
                    + elapsedTime);
        } else {
            batchMailSubject.append("- SUCCESS");
            batchMailContent.append("<tr><td>" + "Result: SUCCESS" + "<td><tr>");
        }


        if (failureReason != null || processXMLRewardErrorMessage != null || getErrorMessageFromVendorWebservice() != null) {
            //don't display summary.
        } else if (lRewardCardQuotes.size() > 0) {
            batchMailContent
                    .append("<tr><td>" + "SUMMARY BY INTELISPEND QUOTE ID / BPM PROGRAM GROUP SITE SECTION:" + "<td><tr>");
        } else {
            batchMailContent
                    .append("<tr><td>" + "ATTENTION: NO QUOTE IDs ASSIGNED IN REWARD CARD DEFINITION TABLE." + "<td><tr>");
        }

        int totalRejected = 0;
        int numberOfRewardsFulfilledTotal = 0;
        boolean errorsReturned = false;

        logger.info("Line 5 ...");

        HashMap<String, String> rewardSetupNotCompletedForQuotedIDMap = new HashMap<String, String>();
        for (String quote : rewardSetupNotCompleteForQuoteID) {
            logger.info("Quote ID identified as not setup.  Set aside in map.  QuoteID is " + quote);
            rewardSetupNotCompletedForQuotedIDMap.put(quote, quote);
        }

        try {
            for (RewardCardQuote lRewardCardQuote : lRewardCardQuotes) {
                String quoteID = lRewardCardQuote.getQuoteID();
                String quoteDesc = lRewardCardQuote.getQuoteDescription();


                if (rewardSetupNotCompletedForQuotedIDMap.containsKey(quoteID)) {
                    logger.info("Alert quote id flagged as not setup properly within business program incentive options!  Quote is " + quoteID);
                    batchMailContent
                            .append("<tr><td>" + "***ALERT! ALERT! ALERT! ALERT! ALERT! ALERT! ALERT! ALERT! ALERT! ALERT! ALERT! ALERT! ALERT!" + "<td><tr>");
                    batchMailContent
                            .append("<tr><td>" + "ATTENTION: DETECTED NO PROGRAMS FOR QUOTE ID " + quoteID + " SETUP IN SYSTEM!  REVIEW YOUR REWARD CARD CONFIGURATION BY BUSINESS PROGRAM!" + "<td><tr>");
                } else if (processXMLRewardErrorMessage != null || getErrorMessageFromVendorWebservice() != null) {
                	if (getErrorMessageFromVendorWebservice() != null) {
						processXMLRewardErrorMessage = getErrorMessageFromVendorWebservice();
					}
                    logger.info("Error returned from vendor webservice call: " + processXMLRewardErrorMessage + "  Quote is " + quoteID);
                    batchMailContent
                            .append("<tr><td>" + "ALERT! ALERT! ALERT! ALERT! ALERT! ALERT! ALERT! ALERT! ALERT! ALERT! ALERT! ALERT! ALERT!" + "</td></tr>");
                    batchMailContent
                            .append("<tr><td>" + "Batched up reward card transactions rejected by call made to vendors reward card webservice!" + "</td></tr>");
					batchMailContent
                            .append("<tr><td>" + "Quote id being passed in is " + quoteID + "</td></tr>");
                    batchMailContent
                            .append("<tr><td>" + "XML Reward Error Message - " + processXMLRewardErrorMessage + "</td></tr>");
                } else {

                    logger.info("Produce summary report for quote id " + quoteID);


                    batchMailContent
                            .append("<tr><td>" + "************************************************************************************************************* " + "</td></tr>");
                    batchMailContent
                            .append("<tr><td>" + "QUOTE ID " + quoteID + " (" + quoteDesc + ") " + "REPRESENTED FOR FOLLOWING SUMMARY COUNTS BY GROUP SITE");
                    batchMailContent
                            .append("<tr><td>" + "************************************************************************************************************* " + "</td></tr>");

                    Collection<RewardControlProgram> lRewardControlPrograms = getProgramControlProducingSummaryReport(quoteID, rewardCardQuoteByProgramsSummary);

                    for (RewardControlProgram lRewardControlProgram : lRewardControlPrograms) {

                        String runFrequency = lRewardControlProgram.getRunFrequency();
                        boolean processSummary = false;

                        if (isTimeToProcessGroup(runFrequency)) {

                            java.sql.Date currentDate = BPMUtils.getCurrentDate();

                            Collection<RewardCardRecycleDetail> lRewardCardRecycleOnHolds = rewardCardService.getRewardRecycleByProgramOnHold(lRewardControlProgram.getProgramID(), currentDate);

                            Integer numberOfRewardsFulfilled = getNumberIncentedRewardFulfillWrittenFromIncentedFromSummary(lRewardControlProgram.getProgramID(), lRewardControlProgram.getQuoteNo(), rewardCardQuoteByProgramsSummary);
                            numberOfRewardsFulfilledTotal = numberOfRewardsFulfilledTotal + numberOfRewardsFulfilled;

                            Integer numberOfRewardFulfillRecsRead = getNumberRewardFulfillRecsReadFromSummary(lRewardControlProgram.getProgramID(), lRewardControlProgram.getQuoteNo(), rewardCardQuoteByProgramsSummary);
                            Integer numberOfRecycle = getNumberOfRecycleFromSummary(lRewardControlProgram.getProgramID(), lRewardControlProgram.getQuoteNo(), rewardCardQuoteByProgramsSummary);
                            Integer numerOfMultiActivity = getNumberBypassedForMultiActivityFromSummary(lRewardControlProgram.getProgramID(), lRewardControlProgram.getQuoteNo(), rewardCardQuoteByProgramsSummary);
                            Integer numberOfReleased = getNumberOfReleasedFromSummary(lRewardControlProgram.getProgramID(), lRewardControlProgram.getQuoteNo(), rewardCardQuoteByProgramsSummary);
                            Integer numberOfMissingAddresses = getNumberWithoutAddressFromSummary(lRewardControlProgram.getProgramID(), lRewardControlProgram.getQuoteNo(), rewardCardQuoteByProgramsSummary);
                            Integer numberOfOrders = getNumberOfOrdersFromSummary(lRewardControlProgram.getProgramID(), lRewardControlProgram.getQuoteNo(), rewardCardQuoteByProgramsSummary);
                            Integer numberOfErrors = getNumberOfErrorsFromSummary(lRewardControlProgram.getProgramID(), lRewardControlProgram.getQuoteNo(), rewardCardQuoteByProgramsSummary);

                            processSummary = false;
                            if (numberOfRewardFulfillRecsRead > 0)
                                processSummary = true;
                            if (numberOfRecycle > 0)
                                processSummary = true;
                            if (numerOfMultiActivity > 0) {
                                processSummary = true;
                            }
                            if (numberOfReleased > 0)
                                processSummary = true;
                            if (numberOfMissingAddresses > 0)
                                processSummary = true;
                            if (numberOfOrders > 0)
                                processSummary = true;
                            if (numberOfErrors > 0)
                                processSummary = true;

                            if (processSummary) {

                                batchMailContent
                                        .append("<tr><td>" + "==============================================================================================================" + "</td></tr>");

                                batchMailContent
                                        .append("<tr><td>" + "Intelispend transactions for Group "
                                                + lRewardControlProgram.getGroupNo() + "-" +  lRewardControlProgram.getGroupName() + " and Site " + lRewardControlProgram.getSiteNo() + "-" + lRewardControlProgram.getSiteName() + "</td></tr>");
                                batchMailContent
                                        .append("<tr><td>" + "Control group run frequency is "
                                                + lRewardControlProgram.getRunFrequency() + "</td></tr>");
                                batchMailContent
                                        .append("<tr><td>" + "--- " + numerOfMultiActivity + " incented records bypassed that met multi activity tollgate rule." + "</td></tr>");
                                batchMailContent
                                        .append("<tr><td>" + "--- " + numberOfRewardsFulfilled + " incented records from incented table written to reward fulfillment history table." + "</td></tr>");
                                batchMailContent
                                        .append("<tr><td>" + "--- " + numberOfRewardFulfillRecsRead + " fulfillment records read from reward fulfillment tracking table." + "</td></tr>");
                                batchMailContent
                                        .append("<tr><td>" + "--- " + numberOfRecycle + " reward card transactions ON HOLD or DENIED in error recycle - bypass." + "</td></tr>");
                                batchMailContent
                                        .append("<tr><td>" +"--- " + numberOfReleased + " reward card transactions flagged as APPROVED and status changed to RELEASED from recycle - allow." + "</td></tr>");
                                batchMailContent
                                        .append("<tr><td>" + "--- " + numberOfMissingAddresses + " reward card transactions missing address - bypass." + "</td></tr>");
                                batchMailContent
                                        .append("<tr><td>" + "--- " + numberOfOrders + " reward card transactions sent to InteliSpend." + "</td></tr>");
                                batchMailContent
                                        .append("<tr><td>" + "--- " + numberOfErrors + " reward card transactions returned in error by InteliSpend." + "</td></tr>");

                                //Todays errors returned from Intelispend.
                                if (numberOfErrors > 0) {
                                    batchMailContent
                                            .append("<tr><td>" + "WARNING: Quote batch file rejected by InteliSpend.  This will need to be resolved ASAP and resent." + "</td></tr>");
                                    errorsReturned = true;

                                } else if (lRewardCardRecycleOnHolds.size() > 0) {
                                    if (numberOfOrders > 0) {
                                        batchMailContent
                                                .append("<tr><td>" + "WARNING: Quote batch file sent to InteliSpend was successful but what follows is the detail summary of the remaining" + "</td></tr>");
                                        batchMailContent
                                                .append("<tr><td>" + "Reward Fulfillment transactions for this group site still ON HOLD in the recycle table:" + "</td></tr>");
                                    } else {
                                        batchMailContent
                                                .append("<tr><td>" + "Reward Fulfillment transactions for this group site still ON HOLD in the recycle table:" + "</td></tr>");

                                    }

                                    totalRejected = totalRejected + lRewardCardRecycleOnHolds.size();
                                    char padWithChar = ' ';
                                    int widthFieldColumn = 50;
                                    int width1 = 20;
                                    int width2 = 1;
                                    batchMailContent
                                            .append("<tr><td>" + "Member No Last Name" + "</td>" + "<td>" + "First Name" + "</td>" +  "<td>" + "MI" + "</td>" + "<td>" + "Field Column Name" + "</td>" + "<td>" +  "Reason Description" + "</td><tr>");
                                    for (RewardCardRecycleDetail lRewardCardRecycleOnHold : lRewardCardRecycleOnHolds) {
                                        batchMailContent
                                                .append("<tr><td>" + lRewardCardRecycleOnHold.getMemberNo() + "</td><td>" + BPMUtils.justifyLeft(lRewardCardRecycleOnHold.getLastName(), width1, padWithChar)  + "</td><td>" + BPMUtils.justifyLeft(lRewardCardRecycleOnHold.getFirstName(), width1, padWithChar)  + "</td><td>" + BPMUtils.justifyLeft(lRewardCardRecycleOnHold.getMiddleName(), width2, padWithChar)  + "</td><td>" + BPMUtils.justifyLeft(lRewardCardRecycleOnHold.getFieldColumn(), widthFieldColumn, padWithChar) + "</td><td>" + "*** " + lRewardCardRecycleOnHold.getReasonDesc() + "</td></tr>");

                                    }
                                }


                                if (numberOfOrders == 0) {
                                    batchMailContent
                                            .append("<tr><td>" + "ATTENTION: NO REWARD TRANSACTIONS SENT TO INTELISPEND TODAY FOR THIS GROUP SITE!" + "</td></tr>");
                                }

                                System.out.println(batchMailContent.toString());

                            }
                        }
                    }
                    if (lRewardControlPrograms.isEmpty()) {
                        batchMailContent
                                .append("<tr><td>" + "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" + "</td></tr>");
                        batchMailContent
                                .append("<tr><td>" +"NO REWARD CARD ACTIVITY FOR GROUP SITES TODAY." + "</td></tr>");
                        batchMailContent
                                .append("<tr><td>" + "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" + "</td></tr>");
                    }
                }

                if (quoteOrderNumberMap.get(quoteID) != null) {
                    batchMailContent
                            .append("<tr><td>" + "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" + "</td></tr>");
                    batchMailContent
                            .append("<tr><td>" + "BATCH FILE FOR QUOTE " + quoteID + " (" + quoteDesc + ") " + " WAS ACCEPTED BY INTELISPEND!" + "</td></tr>");
                    String orderNumber = quoteOrderNumberMap.get(quoteID);
                    batchMailContent
                            .append("<tr><td>" + "ORDER NUMBER RETURNED FROM INTELISPEND AND RECORDED BACK TO REWARD FULFILLMENT RECORDS IS " + orderNumber + "</td></tr>");
                    batchMailContent
                            .append("<tr><td>" + "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" + "</td></tr>");
                }

            }

        } catch (Exception e) {
            logger.error("Exception message is " + e.getMessage());
            logger.error(e.getStackTrace());
        } finally {
            logger.error("Continue on to produce e-mail notificaiton");
        }

        System.out.println(batchMailSubject.toString());
        System.out.println(batchMailContent.toString());

        logger.info(batchMailSubject.toString());
        logger.info(batchMailContent.toString());

        String errorNoProgramsForQuoteIDMessage = "";
        for (String quote : rewardSetupNotCompleteForQuoteID) {
            errorNoProgramsForQuoteIDMessage = "<tr><td>" + "Quote did not match to program control report.  Abort program and investigate.  May indicate no program reward incentive options setup."+ "</td></tr>";
            logger.error(errorNoProgramsForQuoteIDMessage);
            errorsReturned = true;
        }


        String noProgramsErrorReason = "";
        if (errorsReturned) {
            noProgramsErrorReason = "<tr><td>" + "Errors returned from Intelispend.  Need to be investigated" + "</td></tr>";
            noProgramsErrorReason = noProgramsErrorReason + errorNoProgramsForQuoteIDMessage;
            batchMailContent.append(new Exception(noProgramsErrorReason));
            logger.error(noProgramsErrorReason);
        }

        logger.info("Prepare and send email......");
        emailService.setEmailDestination(BPMConstants.EMAIL_DESTINATION_REWARDS_INTELISPEND);
        emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
        emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
                batchMailContent.toString());
        logger.info("Email sent...");


    }

	/*
	 * Batch job to process an order and shipment file from Intelispend.  File format is csv.  Records are streamed and loaded into their own tables by
	 * shipment and order.  Shipment file is used to update the reward fulfillment table with Reward Card information.
	 */
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class,
				com.healthpartners.service.imfs.exception.BPMBusinessValidationException.class, BPMException.class })
	public void processRewardFilesFromIntelispendCommand(
				StatusCalculationCommand statusCalculationCommand)
				throws BPMException
		{
			logger.info("@Start - Processing Order and Shipment file sent from Intelispend. ");
			
			String failureReason = null;
			String failureReasonShipped = null;
			String elapsedTime = null;
			
			int shippedRecsInputCt = 0;
			int orderedRecsInputCt = 0;
			
			int shippedRecsInsertedUpdated = 0;
			int orderedRecsInserted = 0;
			int fulfillRecordsUpdated =  0;
			
			String shippedFileLocationFrom = null;
			String shippedFileLocationTo = null;
			String orderedFileLocationFrom = null;
			String orderedFileLocationTo = null;
			
			java.util.Date startDate = new java.util.Date();
			java.util.Date endDate = null;
			
			Collection<RewardIntelispendShipped> lRewardIntelispendShippedRecs = null;
			Collection<RewardIntelispendOrdered> lRewardIntelispendOrderedRecs = null;
			
			ArrayList<RewardIntelispendShipped> lRewardIntelispendShippedRemoved = null;
			ArrayList<RewardIntelispendOrdered> lRewardIntelispendOrderedRemoved = null;
			
			RewardIntelispendDataFileHelper lRewardIntelispendDataFileHelper = new RewardIntelispendDataFileHelper();
			lRewardIntelispendDataFileHelper.setPersonDAO(personDAO);
			
			statusCalculationCommand.setCurrentCommandText("Reward Shipped and Order File Update");
			
			
			try {
					
					LookUpValueCode shippedStatusLuv = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.REWARD_CARD_STATUS_TP, BPMConstants.SHIPPED);
					Integer shippedStatusID = shippedStatusLuv.getLuvId();
				    
					LookUpValueCode shippedFileLocLuv = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.BPM_INTELISPEND_RPT, BPMConstants.BPM_INTELISPEND_SHIP_FILEPATH_FROM);
					shippedFileLocationFrom = shippedFileLocLuv.getLuvDesc();
					LookUpValueCode shippedFileLocToLuv = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.BPM_INTELISPEND_RPT, BPMConstants.BPM_INTELISPEND_SHIP_FILEPATH_TO);
					shippedFileLocationTo = shippedFileLocToLuv.getLuvDesc();
					
					LookUpValueCode orderedFileLocLuv = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.BPM_INTELISPEND_RPT, BPMConstants.BPM_INTELISPEND_ORDER_FILEPATH_FROM);
					orderedFileLocationFrom = orderedFileLocLuv.getLuvDesc();
					
					LookUpValueCode orderedFileLocToLuv = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.BPM_INTELISPEND_RPT, BPMConstants.BPM_INTELISPEND_ORDER_FILEPATH_TO);
					orderedFileLocationTo = orderedFileLocToLuv.getLuvDesc();
					
						
					logger.info("shippedFileLocationFrom" + shippedFileLocationFrom);
					lRewardIntelispendShippedRecs =
									lRewardIntelispendDataFileHelper.readNFormatCSVShippedFile(shippedFileLocationFrom, shippedStatusID);
					logger.info("Total shipped records read " + lRewardIntelispendShippedRecs.size());
					logger.info("orderedFileLocationFrom" + orderedFileLocationFrom);
					lRewardIntelispendOrderedRecs = 	
				    				lRewardIntelispendDataFileHelper.readNFormatCSVOrderedFile(orderedFileLocationFrom, shippedStatusID);
					logger.info("Total ordered records read " + lRewardIntelispendOrderedRecs.size());
					
					
					
				   //Shipped file must be error free.
				   if (lRewardIntelispendDataFileHelper.getRewardCardShippedDetailErrors().size() == 0) {
					   if (lRewardIntelispendShippedRecs != null && lRewardIntelispendShippedRecs.size() > 0) {
						   //Write shipping report to its own table.
						   //EV89209
						   //method call updateRewardShipDetailReport will allow for inserts and updates.
						   //update functionality exists for replacement cards.
						   shippedRecsInputCt = lRewardIntelispendShippedRecs.size();
						   lRewardIntelispendShippedRemoved = rewardCardService.findNRemoveDuplicateRewardShipped(lRewardIntelispendShippedRecs);
						   shippedRecsInsertedUpdated = rewardCardService.updateRewardShipDetailReport(lRewardIntelispendShippedRecs);
						   
						   //Using shipped report client data, update back to reward fulfillment table and
							//  add reward fulfillment card status of shipped. 
						   fulfillRecordsUpdated = rewardCardService.updateRewardFulfillRptTrackHist(lRewardIntelispendShippedRecs);
					   }
				   }
				 
				   //Order file must be error free.
				   if (lRewardIntelispendDataFileHelper.getRewardCardOrderDetailErrors().size() == 0) {
					   if (lRewardIntelispendOrderedRecs != null && lRewardIntelispendOrderedRecs.size() > 0) {
						   //Avoid writing duplicates in case batch process is run more than once for the same files or
						   //vendor resends the same transactions.  Without this in place, will mess up BUSGODS reporting.
						   orderedRecsInputCt = lRewardIntelispendOrderedRecs.size();
						   lRewardIntelispendOrderedRemoved = rewardCardService.findNRemoveDuplicateRewardOrdered(lRewardIntelispendOrderedRecs);
						  
						   orderedRecsInserted = rewardCardService.insertRewardOrderDetailReport(lRewardIntelispendOrderedRecs);
				
					   }
				   }
			} catch (BPMException e) {
				  failureReason = e.getMessage();
				  logger.error(failureReason, e);
			} catch (IOException ioe) {
				failureReason = ioe.getMessage();
				logger.error("Message is " + ioe.getMessage());
				logger.error("Cause is " + ioe.getCause());
				logger.error("LocalizedMessage is " + ioe.getLocalizedMessage());
			    logger.error("IOException caught.  Stacktrace is " + ioe.getStackTrace());
			} catch (IllegalArgumentException iae) {
				failureReason = iae.getMessage();
				logger.error("Message is " + iae.getMessage());
				logger.error("Cause is " + iae.getCause());
				logger.error("LocalizedMessage is " + iae.getLocalizedMessage());
			    logger.error("IllegalArgumentException caught.  Stacktrace is " + iae.getStackTrace());
			} catch (Exception e) {
				failureReason = e.getMessage();
				logger.error("Message is " + e.getMessage());
				logger.error("Cause is " + e.getCause());
				logger.error("LocalizedMessage is " + e.getLocalizedMessage());
				logger.error("Exception caught.  Stacktrace is " + e.getStackTrace());
				
			} finally {
				endDate = new java.util.Date();
				elapsedTime = BPMUtils
						.getTimeDifferenceAsString(startDate, endDate);
			}
				
					
			boolean shippedDupsExist = false;		
			boolean orderDupsExist = false;
			
			StringBuffer batchMailSubject = new StringBuffer();
		
			batchMailSubject.append("BPM InteliSpend Order and Shipping Detail Reporting Update Batch Process");
			
			StringBuffer batchMailContent = new StringBuffer();
			batchMailContent
			.append("<table>");
			batchMailContent.append("<tr><td>BPM Batch Name: " + statusCalculationCommand.getCurrentCommandText() + "</td></tr>");

			batchMailContent.append("<tr><td>Initiated User: "
					+ statusCalculationCommand.getUserID() + "</td></tr>");
			batchMailContent.append("<tr><td>Time Start: "
					+ BPMUtils.getFormattedDateTime(startDate) + "</td></tr>");
			batchMailContent.append("<tr><td>Time Ended: "
					+ BPMUtils.getFormattedDateTime(endDate) + "</td></tr>");
			batchMailContent.append("<tr><td>Total Elapsed Time was: "
					+ elapsedTime + "</td></tr>");
			
			try {
				if (failureReason == null) {
					boolean reportOnshippedDetailErrors = false;
					if (lRewardIntelispendDataFileHelper.getRewardCardOrderDetailErrors() != null && lRewardIntelispendDataFileHelper.getRewardCardOrderDetailErrors().size() > 0) {
							failureReason = "File contains errors. See error report.";
							batchMailSubject.append("- FAILED");
							batchMailContent.append("<tr><td>Result: FAILED</td></tr>");
							batchMailContent.append("<tr><td>Reason: ");
							batchMailContent.append(failureReason);
							batchMailContent.append(" </td></tr>");
							reportOnDetailErrors(lRewardIntelispendDataFileHelper.getRewardCardOrderDetailErrors(), batchMailContent, reportOnshippedDetailErrors);
					}
					
					if (lRewardIntelispendDataFileHelper.getRewardCardShippedDetailErrors() != null && lRewardIntelispendDataFileHelper.getRewardCardShippedDetailErrors().size() > 0) {
						reportOnshippedDetailErrors = true;
						failureReason = "File contains errors. See error report.";
						batchMailSubject.append("- FAILED");
						batchMailContent.append("<tr><td>Result: FAILED</td></tr>");
						batchMailContent.append("<tr><td>Reason: ");
						batchMailContent.append(failureReason);
						batchMailContent.append(" </td></tr>");
						reportOnDetailErrors(lRewardIntelispendDataFileHelper.getRewardCardShippedDetailErrors(), batchMailContent, reportOnshippedDetailErrors);
					}
					
					
				} else {
						batchMailSubject.append("- FAILED");
						batchMailContent.append("<tr><td>Result: FAILED</td></tr>");
						batchMailContent.append("<tr><td>Reason: ");
						
						batchMailContent.append(failureReason);
						batchMailContent.append(" </td></tr>");
				}
			
				if (failureReason == null) {
					if (lRewardIntelispendShippedRemoved != null && lRewardIntelispendShippedRemoved.size() > 0) {
						shippedDupsExist = true;
						failureReason = "Duplicate Shipped Detail transactions  exist.";
						batchMailSubject.append("- FAILED");
						batchMailContent.append("<tr><td>Result: FAILED</td></tr>");
						batchMailContent.append("<tr><td>Reason: ");
						batchMailContent.append(failureReason);
						batchMailContent.append(" </td></tr>");
						
						reportOnShippedDetail(batchMailContent, lRewardIntelispendShippedRemoved, shippedRecsInsertedUpdated, fulfillRecordsUpdated, shippedRecsInputCt);
						
					} 
					
					if (lRewardIntelispendOrderedRemoved != null && lRewardIntelispendOrderedRemoved.size() > 0) {
						orderDupsExist = true;
						failureReason = "Duplicate Order Detail transactions  exist.";
						batchMailSubject.append("- FAILED");
						batchMailContent.append("<tr><td>Result: FAILED</td></tr>");
						batchMailContent.append("<tr><td>Reason: ");
						batchMailContent.append(failureReason);
						batchMailContent.append(" </td></tr>");
						
						reportOnOrderDetail(batchMailContent, lRewardIntelispendOrderedRemoved, orderedRecsInserted, orderedRecsInputCt);
						
					} 
					
					//move order and shipped files from preprocess folder to processed folder.  Once completed, deletes
					//file from preprocess folder.
					if (failureReason == null) {
						batchMailSubject.append("- SUCCESS");
						batchMailContent.append("<tr><td>Result: SUCCESS</td></tr>");
						
						logger.info("Move orderedFileLocationFrom " + orderedFileLocationFrom + " to " + orderedFileLocationTo);
						BPMUtils.moveFiles(orderedFileLocationFrom, orderedFileLocationTo);
						logger.info("Move shippedFileLocationFrom " + shippedFileLocationFrom + " to " + shippedFileLocationTo);
						BPMUtils.moveFiles(shippedFileLocationFrom, shippedFileLocationTo);
					}
				}
				
				batchMailContent
				.append("<table>");
				// No records in the Shipped Report.
				if(lRewardIntelispendShippedRecs.size() <= 0 && lRewardIntelispendDataFileHelper.getRewardCardShippedDetailErrors().size() <= 0 && !shippedDupsExist) 
				{
					batchMailContent.append("<tr><td>Intelispend Shipped Report count: NO RECORDS TO LOAD TODAY.</td></tr>");
				} else {
					if (failureReason == null) {
						  batchMailContent.append("<tr><td>Intelispend Shipped Report count: RECORDS WRITTEN - " + lRewardIntelispendShippedRecs.size() +  "</td></tr>");
					} else {
						batchMailContent.append("<tr><td>Intelispend Shipped Report count: RECORDS WRITTEN - 0 </td></tr>");
					}
				}
				
				// No records in the Ordered Report.
				if(lRewardIntelispendOrderedRecs.size() <= 0 && lRewardIntelispendDataFileHelper.getRewardCardOrderDetailErrors().size() <= 0 && !orderDupsExist) 
				{
					batchMailContent.append("<tr><td>Intelispend Ordered Report count: NO RECORDS TO LOAD TODAY.</td></tr>");
				} else {
					if (failureReason == null) {
						batchMailContent.append("<tr><td>Intelispend Ordered Report count: RECORDS WRITTEN - " + lRewardIntelispendOrderedRecs.size() +  "</td></tr>");
					} else {
						batchMailContent.append("<tr><td>Intelispend Ordered Report count: RECORDS WRITTEN - 0 </td></tr>");
					}
				}
				batchMailContent
				.append("</table>");
				
			} catch (Exception e) {
				failureReason = "Issue with moving order and shipped files from preprocess folder to processed folder.";
				batchMailContent.append("<tr><td>" + failureReason + "</td></tr>");
				
			} finally {
				
				batchMailContent
						.append("</table>");
				emailService.setEmailDestination(BPMConstants.EMAIL_DESTINATION_REWARDS_INTELISPEND);
				emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
				emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
						batchMailContent.toString());
			}
			
			

			if (failureReason != null) {
				logger.info("\nReward INTELISPEND batch process Failed: " + failureReason);
				throw new BPMException(failureReason);
			}
			
			
			logger.info("\n@End - processRewardsContributionCommand. ");
		}
		
		private void reportOnDetailErrors(Collection<RewardCardError> rewardCardErrors, StringBuffer batchMailContent, boolean reportOnshippedDetailErrors) {
			
				batchMailContent
				.append("</table>");
				batchMailContent
				.append("<table>");
				batchMailContent
				.append("<tr><td> </td></tr>");
				
				if (reportOnshippedDetailErrors) {
					batchMailContent
					.append("<tr><td>*****************Intelispend Shipped Detail Error Summary ******************</td></tr>");
					batchMailContent.append("<tr><td>Order Number: "
							+ rewardCardErrors.iterator().next().getRewardIntelispendShipped().getOrderNumber()+ "</td></tr>");
					batchMailContent.append("<tr><td>Report File Name: "
							+ rewardCardErrors.iterator().next().getRewardIntelispendShipped().getShipReportFileName() + "</td></tr>");
				} else {
					batchMailContent
					.append("<tr><td>*****************Intelispend Ordered Detail Error Summary ******************</td></tr>");
					batchMailContent.append("<tr><td>Order Number: "
							+ rewardCardErrors.iterator().next().getRewardIntelispendOrdered().getOrderNumber()+ "</td></tr>");
					batchMailContent.append("<tr><td>Report File Name: "
							+ rewardCardErrors.iterator().next().getRewardIntelispendOrdered().getOrderReportFileName() + "</td></tr>");
				}
				
				
				batchMailContent
				.append("</table>");
				batchMailContent
				.append("<table>");
			
					
				// column header
				batchMailContent
				.append("<tr><td> </td></tr>");
				batchMailContent.append("<tr><td> Line</td><td>Data Element</td><td>Error Reason</td><td>Last Name</td><td>First Name</td><td>Person ID</td><td>PID Number</td><td>Fulfill Hist ID</td></tr>");
				
				int rowCt = 1;
		    	for (RewardCardError lRewardCardError : rewardCardErrors) {
		    		batchMailContent
					.append("<tr><td colspan=10>----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
		    		if (reportOnshippedDetailErrors) {
						batchMailContent.append("<tr><td> "
								+ rowCt + "</td><td>"
								+ lRewardCardError.getDataElement() + "</td><td>"
								+ lRewardCardError.getErrorReason() + "</td><td>"
								+ lRewardCardError.getRewardIntelispendShipped().getLastName() + "</td><td>"
								+ lRewardCardError.getRewardIntelispendShipped().getFirstName() + "</td><td>"
								+ lRewardCardError.getRewardIntelispendShipped().getPersonIDIndicativeData3() + "</td><td>"
								+ lRewardCardError.getRewardIntelispendShipped().getPidNumber() + "</td><td>"
								+ lRewardCardError.getRewardIntelispendShipped().getRewardFulfillHistIDIndicativeData4() + "</td><td>"
								+ "</td></tr>");
		    		} else {
		    			
		    			batchMailContent.append("<tr><td> "
								+ rowCt + "</td><td>"
								+ lRewardCardError.getDataElement() + "</td><td>"
								+ lRewardCardError.getErrorReason() + "</td><td>"
								+ lRewardCardError.getRewardIntelispendOrdered().getLastName() + "</td><td>"
								+ lRewardCardError.getRewardIntelispendOrdered().getFirstName() + "</td><td>"
								+ lRewardCardError.getRewardIntelispendOrdered().getPersonIDIndicativeData3() + "</td><td>"
								+ lRewardCardError.getRewardIntelispendOrdered().getPidNumber() + "</td><td>"
								+ lRewardCardError.getRewardIntelispendOrdered().getRewardFulfillHistIDIndicativeData4() + "</td><td>"
								+ "</td></tr>");
		    		}
					rowCt++;
		    	}
		    	
		    	batchMailContent
				.append("<tr><td colspan=10>=================================================================================================================================================================================================================================</td></tr>");
		    	
		} 
		
		private void reportOnShippedDetail(StringBuffer batchMailContent, ArrayList<RewardIntelispendShipped> lRewardIntelispendShippedRemoved, int shippedRecsInsertedUpdated, int fulfillRecordsUpdated, int shippedRecsInputCt) {
			
			
			batchMailContent
			.append("</table>");
			batchMailContent
			.append("<table>");
			batchMailContent
			.append("<tr><td> </td></tr>");
			batchMailContent
			.append("<tr><td>*****************Intelispend Shipping Detail Report Summary ******************</td></tr>");
			batchMailContent
			.append("</table>");
			
			
			batchMailContent
			.append("<table>");
			if (lRewardIntelispendShippedRemoved.size() == 0 && shippedRecsInsertedUpdated > 0) {
				batchMailContent
				.append("<tr><td>" + shippedRecsInsertedUpdated + " Shipping Detail Report records inserted/updated into Shipping Detail Reporting table.</td></tr>");
				batchMailContent
				.append("<tr><td> " + fulfillRecordsUpdated + " Shipping Detail Report records updated to Reward Fulfillment table.</td></tr>");
				batchMailContent
				.append("</table>");
			} else if (lRewardIntelispendShippedRemoved.size() > 0) {
					
					if (shippedRecsInsertedUpdated > 0) {
						batchMailContent
						.append("<tr><td>" + shippedRecsInsertedUpdated + " shipping Report records inserted/updated into Shipping Detail Reporting table.</td></tr>");
						batchMailContent
						.append("<tr><td>" + fulfillRecordsUpdated + " Shipping Detail Report records updated to Reward Fulfillment table.</td></tr>");
					} 
					
					batchMailContent
					.append("<tr><td>Intelispend Shipping Detail Report contains duplicates. " + lRewardIntelispendShippedRemoved.size() + " duplicates detected out of " + shippedRecsInputCt + " records.</td></tr>");
					batchMailContent
					.append("<tr><td>File processed successfully but contact InteliSpend to find out why duplicates are being sent or b) determine if batch job was already run against the same file.</td></tr>");
					
					batchMailContent.append("<tr><td>DUPLICATE SHIPPING DETAIL REPORT RECORDS FOLLOW: </td></tr>");
					batchMailContent.append("</table>");
					batchMailContent
					.append("<table>");
					batchMailContent.append("<tr><td> Line</td><td>Order Number</td><td>PID Number</td><td>Last Name</td><td>First Name</td><td>Group No</td><td>Group Name</td></tr>");
					int rowCt = 1;
			    	for (RewardIntelispendShipped lRewardIntelispendShipped: lRewardIntelispendShippedRemoved) {
							
			    		batchMailContent
						.append("<tr><td colspan=7>---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
						batchMailContent.append("<tr><td> "
								+ rowCt + "</td><td>"
								+ lRewardIntelispendShipped.getOrderNumber() + "</td><td>"
								+ lRewardIntelispendShipped.getPidNumber() + "</td><td>"
								+ lRewardIntelispendShipped.getLastName() + "</td><td>"
								+ lRewardIntelispendShipped.getFirstName() + "</td><td>"
								+ lRewardIntelispendShipped.getGroupNumberIndicativeData1() + "</td><td>"
								+ lRewardIntelispendShipped.getGroupNameIndicativeData2() + "</td><td>"
								+ "</td></tr>");
						rowCt++;
			
						if (rowCt > 100) {
							batchMailContent
							.append("<tr><td>   </td></tr>");
							batchMailContent
							.append("<tr><td>   </td></tr>");
							//cap report list at 100
							batchMailContent
							.append("<tr><td colspan=7>***ATTENTION: REPORT CUTOFF AT 100 ROWS.  " + "A TOTAL OF " + lRewardIntelispendShippedRemoved.size() + " DUPLICATE ORDER DETAIL RECORDS REPORTED.</td></tr>");
							break;
						}
					
			    	}
			    	batchMailContent
					.append("<tr><td colspan=7>=================================================================================================================================================================================================================================</td></tr>");
			    	batchMailContent
					.append("</table>");
			} 
				
	
		}
		private void reportOnOrderDetail(StringBuffer batchMailContent, ArrayList<RewardIntelispendOrdered> lRewardIntelispendOrderedRemoved, int orderedRecsInserted, int orderedRecsInputCt) {
			batchMailContent
			.append("</table>");
			batchMailContent
			.append("<table>");
			batchMailContent
			.append("<tr><td> </td></tr>");
			batchMailContent
			.append("<tr><td>*****************Intelispend Ordered Detail Report Summary ******************</td></tr>");
			batchMailContent
			.append("</table>");
			
			batchMailContent
			.append("<table>");
			if (lRewardIntelispendOrderedRemoved.size() == 0 && orderedRecsInserted > 0) {
				batchMailContent
				.append("<tr><td>" + orderedRecsInserted + " Ordered Detail Report records written to Order Reporting table.</td></tr>");
				
			} else if (lRewardIntelispendOrderedRemoved.size() > 0) {
					
					if (orderedRecsInserted > 0) {
						batchMailContent
						.append("<tr><td>" + orderedRecsInserted + " Ordered Detail Report records written to Order Detail Reporting table.</td></tr>");
					} 
					batchMailContent
					.append("<tr><td>Intelispend Ordered Detail Report contains duplicates. " + lRewardIntelispendOrderedRemoved.size() + " duplicates detected out of " + orderedRecsInputCt + " records.</td></tr>");
					batchMailContent
					.append("<tr><td>File processed successfully but contact InteliSpend to find out why duplicates are being sent  or b) determine if batch job was run multiple times against the same file.</td></tr>");
					batchMailContent
					.append("</table>");
					batchMailContent
					.append("<table>");
					batchMailContent
					.append("<tr><td> </td></tr>");
					batchMailContent.append("<tr><td>DUPLICATE ORDERED DETAIL REPORT RECORDS FOLLOW: </td></tr>");
					batchMailContent
					.append("</table>");
					batchMailContent
					.append("<table>");
					if (lRewardIntelispendOrderedRemoved.size() > 0) {
						// column header
						batchMailContent
						.append("<tr><td> </td></tr>");
						batchMailContent.append("<tr><td> Line</td><td>Order Number</td><td>PID Number</td><td>Last Name</td><td>First Name</td><td>Group No</td><td>Group Name</td></tr>");
						
						int rowCt = 1;
				    	for (RewardIntelispendOrdered lRewardIntelispendOrdered: lRewardIntelispendOrderedRemoved) {
								
				    		batchMailContent
							.append("<tr><td colspan=7>---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
							batchMailContent.append("<tr><td> "
									+ rowCt + "</td><td>"
									+ lRewardIntelispendOrdered.getOrderNumber() + "</td><td>"
									+ lRewardIntelispendOrdered.getPidNumber() + "</td><td>"
									+ lRewardIntelispendOrdered.getLastName() + "</td><td>"
									+ lRewardIntelispendOrdered.getFirstName() + "</td><td>"
									+ lRewardIntelispendOrdered.getGroupNumberIndicativeData1() + "</td><td>"
									+ lRewardIntelispendOrdered.getGroupNameIndicativeData2() + "</td><td>"
									+ "</td></tr>");
							rowCt++;
				
							if (rowCt > 100) {
								batchMailContent
								.append("<tr><td>   </td></tr>");
								batchMailContent
								.append("<tr><td>   </td></tr>");
								//cap report list at 100
								batchMailContent
								.append("<tr><td colspan=7>***ATTENTION: REPORT CUTOFF AT 100 ROWS.  " + "A TOTAL OF " + lRewardIntelispendOrderedRemoved.size() + " DUPLICATE ORDER DETAIL RECORDS REPORTED.</td></tr>");
								break;
							}
						
				    	}
				    	batchMailContent
						.append("<tr><td colspan=7>=================================================================================================================================================================================================================================</td></tr>");
				    	batchMailContent
						.append("</table>");
					} 
					
				
			} 
				
			
		}

		
	/*
	   * Check to see if reward fulfillment is in recycle table.  Bypass if ON HOLD or DENIED.  If APRROVED, then
	   * update recyle record to released allowing the fulfillment transaction to pass through.
	   */
	private Collection<RewardFulfillmentTrackingReportHist> processAgainstRewardRecycle(Collection<RewardFulfillmentTrackingReportHist> rewardFulfillmentHistoryTrackingRpts, RewardCardQuoteByProgramSummary lRewardCardQuoteByProgramSummary) 
	  																	throws BPMException {
		  
		  ArrayList<RewardFulfillmentTrackingReportHist> lRewardFulfillmentTrackingReportsHistAllow = new ArrayList<RewardFulfillmentTrackingReportHist>();
		  
		  for (RewardFulfillmentTrackingReportHist lRewardFulfillmentTrackingReportHist : rewardFulfillmentHistoryTrackingRpts) {
			  try {
				  //if in recycle, then bypass
				  if (rewardCardService.isRewardFulfillOnHoldOrDenied(lRewardFulfillmentTrackingReportHist.getRewardTransHistID())) {
					  recordToProgramRecycleBypassSummaryMap(lRewardCardQuoteByProgramSummary.getProgramRecycleBypassSummaryMap(), lRewardFulfillmentTrackingReportHist);
				  } else  if (rewardCardService.isRewardFulfillApproved(lRewardFulfillmentTrackingReportHist.getRewardTransHistID())) {
						  recordToProgramRecycleReleasedSummaryMap(lRewardCardQuoteByProgramSummary.getProgramRecycleReleasedSummaryMap(), lRewardFulfillmentTrackingReportHist);
						  lRewardFulfillmentTrackingReportsHistAllow.add(lRewardFulfillmentTrackingReportHist);
				  } else {
					  lRewardFulfillmentTrackingReportsHistAllow.add(lRewardFulfillmentTrackingReportHist);
				  }
		  } catch (BPMException failureReason) {
			  		logger.info("Read agaist Reward Recycle Failed: " + failureReason);
					throw new BPMException(failureReason);
			  }
		  }
		  
		  return lRewardFulfillmentTrackingReportsHistAllow;
			  
  }
 

 
  private boolean isTimeToProcessGroup(String runFreq) {
	  boolean processHSAContributionsForGroupToday = false;
	  
	  logger.info("isTimeToProcessGroup run freq is " + runFreq);
	  boolean isFirstDayOfMonth = BPMUtils.isFirstDayOfMonth();
	  if (runFreq.equals(BPMConstants.CDHP_RUN_FREQ_DAILY)) {
		  processHSAContributionsForGroupToday = true;
	  } else if (runFreq.equals(BPMConstants.CDHP_RUN_FREQ_WEEKLY) && BPMUtils.isFirstDayOfWeekMonday()) {
		  			processHSAContributionsForGroupToday = true;
	  } else if (runFreq.equals(BPMConstants.CDHP_RUN_FREQ_MONTHLY) && isFirstDayOfMonth) {
		  			processHSAContributionsForGroupToday = true;
	  } else if (runFreq.equals(BPMConstants.CDHP_RUN_FREQ_QUARTERLY) && BPMUtils.isFirstDayOfQuarter(isFirstDayOfMonth)) {
		  processHSAContributionsForGroupToday = true;
	  }
	  
	  return processHSAContributionsForGroupToday;
	  
  }
  
  
  /*
   * Need to determine of the CDHP Fulfillment Tracking records read, which ones need to be routed to HPDIT.  This routing type sends records
   * on to become formatted into a transaction type, written to a CSV file, and then ftp'ed to a internal file server.
   */
  private Collection<CDHPFulfillmentTrackingReport> determineSendToHPDIT(Collection<CDHPFulfillmentTrackingReport> hsaFulfillmentContributionTrackingRpts) {
	  ArrayList<CDHPFulfillmentTrackingReport> hsaFulfillmentContributionTrackingRptsToHPDIT = new ArrayList<CDHPFulfillmentTrackingReport>();
	  
	  Iterator<CDHPFulfillmentTrackingReport> iter =  (Iterator<CDHPFulfillmentTrackingReport>)hsaFulfillmentContributionTrackingRpts.iterator();
	  
	  while (iter.hasNext()) {
		  CDHPFulfillmentTrackingReport lCDHPFulfillmentTrackingReport = (CDHPFulfillmentTrackingReport)iter.next();
		  if (lCDHPFulfillmentTrackingReport.getFulfillmentRoutingType().equals(BPMConstants.CDHP_FLFLMNT_RTNG_TP_HPDIT)) {
			  hsaFulfillmentContributionTrackingRptsToHPDIT.add(lCDHPFulfillmentTrackingReport);
		  }
	  }
	  
	  return hsaFulfillmentContributionTrackingRptsToHPDIT;
  }
  
  /*
   * Count number of HSA records to be reported on through the Employer Portal.  None of these records get 
   * written to an external file.  Employer downloads into a report realtime.  Count is used in the summary report
   * of the e-mail notification
   */
  private Integer countReadyToRetrieveFromEmployerPortal(Collection<CDHPFulfillmentTrackingReport> hsaFulfillmentContributionTrackingRpts) {
	  ArrayList<CDHPFulfillmentTrackingReport> hsaFulfillmentContributionTrackingRptsToEmployerPortal = new ArrayList<CDHPFulfillmentTrackingReport>();
	  
	  Iterator<CDHPFulfillmentTrackingReport> iter =  (Iterator<CDHPFulfillmentTrackingReport>)hsaFulfillmentContributionTrackingRpts.iterator();
	  
	  while (iter.hasNext()) {
		  CDHPFulfillmentTrackingReport lCDHPFulfillmentTrackingReport = (CDHPFulfillmentTrackingReport)iter.next();
		  if (lCDHPFulfillmentTrackingReport.getFulfillmentRoutingType().equals(BPMConstants.CDHP_FLFLMNT_RTNG_TP_EMP_PORTAL)) {
			  hsaFulfillmentContributionTrackingRptsToEmployerPortal.add(lCDHPFulfillmentTrackingReport);
		  }
	  }
	  
	  return hsaFulfillmentContributionTrackingRptsToEmployerPortal.size();
  }
  
  /*
   * Need to determine if the Reward Fulfillment Tracking records read which ones need to be routed to the vendor.  Based on the routing type will determine
   * where to direct transactions and the formatting to use.  Otherwise, method is reponsible for sending transactions to Intelispend and
   * processing the response object back from Intelispend determining if batch was accepted or rejected.
   */
 /* private Collection<RewardCardQuoteByProgramSummary> processXMLRewardFile(HashMap<String, Collection<RewardFulfillmentTrackingReportHist>> quoteRewardsHashMap, HashMap<String, String> quoteOrderNumberHashMap
		  , Collection<RewardCardQuoteByProgramSummary> lRewardCardQuoteByProgramsSummary
		  , RewardCardClientData pKnowYourClientData) 
		  throws BPMException {
	  
	  String xmlOrders = null;
	  
	  DXML dxmlResponse = null;
	  
	 
	  HashMap<Integer, Integer> programErrorSummaryMap = new HashMap<Integer, Integer>();
	  HashMap<Integer, Integer> programSentSummaryMap = new HashMap<Integer, Integer>();
	  
	  
	 
	  logger.info("processXMLRewardFile - quoteRewardsHashMap size is " + quoteRewardsHashMap.size());
	  Iterator iter = quoteRewardsHashMap.entrySet().iterator();	
	  while (iter.hasNext()) {
		  	
			Map.Entry pairs = (Map.Entry)iter.next();
			String quoteID = (String)pairs.getKey();
			
			Collection<RewardFulfillmentTrackingReportHist> lRewardFulfillmentTrackingReportHists = (Collection<RewardFulfillmentTrackingReportHist>)pairs.getValue();
			logger.info("processXMLRewardFile - lRewardFulfillmentTrackingReportHists size is " + lRewardFulfillmentTrackingReportHists.size());
			if (lRewardFulfillmentTrackingReportHists.size() > 0) {
				
				OutboundFileProcessing lOutboundFileProcessing = new OutboundFileProcessing();
				xmlOrders = lOutboundFileProcessing.generateIntelispendXMLRewardFileGiftCardOrders(lRewardFulfillmentTrackingReportHists, pKnowYourClientData);
				
				logger.info("@@@@ - at clientCalltoIntelispend quote id is " + quoteID);
				logger.info("@@@@ - Sending reward transaction count       " + lRewardFulfillmentTrackingReportHists.size());
					
				//System.out.println(xmlOrders); 
			//	dxmlResponse = clientCallToIntelispendService.submitXMLTransToIntelispend(xmlOrders, quoteID);
				
				LookUpValueCode rewardTrackingStatusOrderedLUV = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.REWARD_CARD_STATUS_TP, BPMConstants.ORDERED);
				LookUpValueCode sentLUV = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.TRANSM_AUDIT_STATUS, BPMConstants.TRANSM_SENT);
				Integer orderedLuvID = rewardTrackingStatusOrderedLUV.getLuvId();
				Integer sentLuvID = sentLUV.getLuvId();
				rewardCardService.insertTransmissionAuditLogs(lRewardFulfillmentTrackingReportHists, sentLuvID, orderedLuvID);
				logger.info("@@@@ - Rewards file successfully sent to Intelispend webservice for quote ID " + quoteID);
				logger.info("@@@@ - Total records sent to Intelispend " + lRewardFulfillmentTrackingReportHists.size());
				programSentSummaryMap = recordToProgramSentSummaryMap(programSentSummaryMap, lRewardFulfillmentTrackingReportHists);
				
			} else {
				logger.info("@@@@ - No rewards to send to Intelispend webservice today.");
			}
			
			try {
				programErrorSummaryMap = processXMLResponseFromIntelispend(dxmlResponse, lRewardFulfillmentTrackingReportHists, quoteID, quoteOrderNumberHashMap);
				
				if (programErrorSummaryMap.isEmpty()) {
					addRewardControlProgramTrackerStatus(quoteID, BPMConstants.RESULT_SUCCESS);
				} else {
					addRewardControlProgramTrackerStatus(quoteID, BPMConstants.RESULT_FAILURE);
				}
			} catch (BPMException be) {
				addRewardControlProgramTrackerStatus(quoteID, BPMConstants.RESULT_FAILURE);
				logger.error("BPMException caught at processXMLRewardFile. BPMException: " + be.getStackTrace());
				String errorDescription = extractDXMLResponseError(dxmlResponse);
				throw new BPMException("Error response from dxmlResponse object: " + errorDescription);
			} catch (DataAccessException dae) {
				addRewardControlProgramTrackerStatus(quoteID, BPMConstants.RESULT_FAILURE);
				logger.debug("DataAccessException caught at processXMLRewardFile. DataAccessException: " + dae.getStackTrace());
				String errorDescription = extractDXMLResponseError(dxmlResponse);
				throw new BPMException("Error response from dxmlResponse object: " + errorDescription);
			} catch (Exception e) {
				addRewardControlProgramTrackerStatus(quoteID, BPMConstants.RESULT_FAILURE);
				logger.debug("Exception caught at processXMLRewardFile.  Exception: " + e.toString());
				String errorDescription = extractDXMLResponseError(dxmlResponse);
				throw new BPMException("Error response from dxmlResponse object: " + errorDescription);
			}
			//lRewardCardQuoteByProgramSummary was instantiated from calling method therefore updating to this object.  It tracks
			//record counts by program for fulfillment records bypassed due to 1) existing in error reycle 2) missing address.  Also, within
			//this method counts the number of transactions sent and in error by program ID.  This information will later be used 
			// in summary of e-mail notification.
			for (RewardCardQuoteByProgramSummary lRewardCardQuoteByProgramSummary : lRewardCardQuoteByProgramsSummary) {
				logger.info("processXMLRewardFile lRewardCardQuoteByProgramSummary.getQuoteID() " + lRewardCardQuoteByProgramSummary.getQuoteID() + " match to " + quoteID);
				if (lRewardCardQuoteByProgramSummary.getQuoteID().equals(quoteID)) {
					lRewardCardQuoteByProgramSummary.setProgramSentSummaryMap(programSentSummaryMap);
					lRewardCardQuoteByProgramSummary.setProgramErrorSummaryMap(programErrorSummaryMap);
				} 
			}
			
			
	  }
	  
	 
	  return lRewardCardQuoteByProgramsSummary;
  }*/

	/*private String  extractDXMLResponseError(DXML dxmlResponse) {

		String errorDescription = null;
		List<ERROR> errors = dxmlResponse.getResponse().getERROR();
		for (ERROR err : errors) {
			RewardIntelispendResponse lRewardIntelispendResponse = new RewardIntelispendResponse();
			lRewardIntelispendResponse.setErrorFieldColumn(err.getERRORCOLUMN());
			lRewardIntelispendResponse.setErrorDesc(err.getERRORDESCRIPTION());
			lRewardIntelispendResponse.setErrorItemno(err.getERRORITEMNO());
			lRewardIntelispendResponse.setErrorRewardTransHistID(err.getERRORPID());
			logger.info("----------------------------------------------------");
			logger.info("ERRORPID(fulfill Hist ID)- " + err.getERRORPID());
			logger.info("ERRORITEMNO              - " + err.getERRORITEMNO());
			logger.info("ERRORCOLUMNNO            - " + err.getERRORCOLUMN());
			logger.info("ERRORDESCRIPTION         - " + err.getERRORDESCRIPTION());
			errorDescription = err.getERRORDESCRIPTION();
		}

		return errorDescription;
	}
  */
  
  /* 
   * Parse XML returned from intelispend and map to DTO.  Process DTO based on results returned.
   */
  /*private HashMap<Integer, Integer> processXMLResponseFromIntelispend(DXML dxmlResponse,
																	  Collection<RewardFulfillmentTrackingReportHist> lRewardFulfillmentTrackingReportHists,
																	  String quoteID,
																	  HashMap<String, String> quoteOrderNumberHashMap)
		  																	throws BPMException {
  	  
	  boolean batchFileAccepted = false;
	  
	  Integer programErrorCt = 0;
	  
	  HashMap<Integer, Integer> programErrorSummaryMap = new HashMap<Integer, Integer>();
	  
  	  ArrayList<RewardIntelispendResponse> lRewardIntelispendResponses = buildRewardIntelispendResponse(dxmlResponse);
  	  LookUpValueCode orderedLUV = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.REWARD_CARD_STATUS_TP, BPMConstants.ORDERED);

	  String errorResponse = null;
  	  
  	  logger.info("In processXMLResponseFromIntelispend.");
  	  
  	  try {
  		  if (lRewardFulfillmentTrackingReportHists.isEmpty()) {
  			  logger.info("No Reward Fulfillment transactions exist.  Nothing to process.");
  		  } else if (lRewardIntelispendResponses.isEmpty()) {
  		  	  errorResponse = "processXMLResponseFromIntelispend: Nothing returned by Intelispend.  Intelispend needs to be contacted to investigate.";
	  		  logger.info(errorResponse);
			  throw new BPMException(errorResponse);
	  	  } else if (lRewardIntelispendResponses.iterator().next().getSuccessDesc() != null) {

	  		  String successDesc = lRewardIntelispendResponses.iterator().next().getSuccessDesc();
	  		  logger.info("Batch successfully processed by Intelispend: " + successDesc);
	  		  
	  		  //Second token is where Order number is found in String passed back from Intelispend.
	  		  //Ex. of what is passed back: File was successfully Processed and is pending transmission. Order#:10475549
			  String[] tokens = successDesc.split(":");
			  String orderNumber = tokens[1].trim(); 
			  
			  //Capture order number indexed by quote id.  HashMap is passed by reference
			  //and later used to display order number to summary report. 
			  if (!quoteOrderNumberHashMap.containsKey(quoteID)) {
				  quoteOrderNumberHashMap.put(quoteID, orderNumber);
			  }
			  
			  logger.info("Order number assigned back to fulfillment table is " + orderNumber);
	  		  //Processing of order was successful.  Update fulfillment table with ORDER status.
	  		 
	  		  Integer orderedLuvID = orderedLUV.getLuvId();
	  		  LookUpValueCode receivedLUV = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.TRANSM_AUDIT_STATUS, BPMConstants.TRANSM_RECEIVED);
	  		  Integer receiveLuvID = receivedLUV.getLuvId();
	  		  LookUpValueCode acceptedLUV = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.REWARD_CARD_STATUS_TP, BPMConstants.ACCEPTED);
	  		  Integer acceptedLuvID = acceptedLUV.getLuvId();
	  		 
	  		 
	  		  for (RewardFulfillmentTrackingReportHist lRewardFulfillmentTrackingReportHist : lRewardFulfillmentTrackingReportHists) {
	  			  lRewardFulfillmentTrackingReportHist.setReasonCodeID(Integer.toString(orderedLuvID));
	  			  lRewardFulfillmentTrackingReportHist.setOrderNumber(orderNumber);
	  			  Integer rewardTranHistID = lRewardFulfillmentTrackingReportHist.getRewardTransHistID();
	  			  
	  			  rewardCardService.updateRewardFulfillmentHistWOrderNumber(rewardTranHistID, orderNumber);
	  			  
	  			  rewardCardService.insertRewardFulfillmentStatus(lRewardFulfillmentTrackingReportHist, BPMConstants.INTELISPEND_USER_SYSTEM);
	  			  
	  			  Integer transactionID  = lRewardFulfillmentTrackingReportHist.getRewardTransHistID();
	  			  rewardCardService.insertTransmissionAuditLog(transactionID, receiveLuvID, acceptedLuvID);
	  		  }
	  		 
	  	  } else {
	  		  
	  		  Integer prevTransactionID = null;
	  		  
	  		  //Write errors to recycle table sent back from Intelispend by data elment in error.
	  		  LookUpValueCode rewardRecycleStatusOnHoldLUV = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.BPM_REWARD_RECYCLE_STATUS, BPMConstants.REWARD_RECYCLE_STATUS_ON_HOLD);
	  		  LookUpValueCode rewardTrackingStatusRejectedLUV = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.REWARD_CARD_STATUS_TP, BPMConstants.REJECTED);
	  		  
	  		  LookUpValueCode sentLUV = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.TRANSM_AUDIT_STATUS, BPMConstants.TRANSM_RECEIVED);
	  		  
	  		  logger.info("processXMLResponseFromIntelispend lRewardIntelispendResponses ct is " + lRewardIntelispendResponses.size());
	  		  for (RewardIntelispendResponse lRewardIntelispendResponse : lRewardIntelispendResponses) {
	  			  if (lRewardIntelispendResponse.getErrorRewardTransHistID() == null || lRewardIntelispendResponse.getErrorRewardTransHistID().isEmpty()) {
	  				  errorResponse = "Intelispend Error Response returning reward transaction history id of null or empty string.  " +
	  				  						  "This indicates that not all required data elements are represented or an xml tag is missing as part of the data string sent to Intelispend."
	  				  						  + "It may also indicate that an attempt was made to send duplicate transactions.  See ERRORDESCRIPTION from log file.";

					  throw new BPMException(errorResponse);
	  			  }
	  			  lRewardIntelispendResponse.setRecycleStatusID(rewardRecycleStatusOnHoldLUV.getLuvId());
	  			  RewardFulfillmentTrackingRecycle lRewardFulfillmentTrackingRecycle = rewardFulfillRecylceMapper(lRewardIntelispendResponse);
	  			  if (doesErrorsAlreadyExistInRecycleByTransHistID(lRewardIntelispendResponse)) {
	  				  //same transaction and type of field column error already recorded to recycle table.  This should rarely happen
	  				  //but in case it does, avoid doubling up on the same field column error in recycle table.
	  			  } else {
	  				  rewardCardService.insertRewardFulfillmentRecycle(lRewardFulfillmentTrackingRecycle, BPMConstants.INTELISPEND_USER_SYSTEM);
	  			  }
	  			  
	  			  Integer rejectedCodeID = rewardTrackingStatusRejectedLUV.getLuvId();
	  			 
	  			  RewardFulfillmentTrackingReportHist lRewardFulfillmentTrackingReportHist = new RewardFulfillmentTrackingReportHist();
	  			  lRewardFulfillmentTrackingReportHist.setRewardTransHistID(Integer.valueOf(lRewardIntelispendResponse.getErrorRewardTransHistID()));
	  			  lRewardFulfillmentTrackingReportHist.setReasonCodeID(Integer.toString(rejectedCodeID));
	  			  //Add reward card status of REJECTED if latest status of REJECTED does not exist.
	  			  if (rewardCardService.isStatusAlreadyExist(Integer.valueOf(lRewardIntelispendResponse.getErrorRewardTransHistID()), BPMConstants.REJECTED)) { 
	  				  //same transaction resent already recorded as rejected
	  			  } else {
	  				  
	  				  Integer transactionID = lRewardFulfillmentTrackingReportHist.getRewardTransHistID();
	  				  Integer rejectedLuvID = rewardTrackingStatusRejectedLUV.getLuvId();
	  				  Integer receivedLuvID = sentLUV.getLuvId();
	  				  rewardCardService.insertTransmissionAuditLog(transactionID, receivedLuvID, rejectedLuvID);
	  				  
	  				  lRewardFulfillmentTrackingReportHist.setReasonCodeID(Integer.toString(rejectedLuvID));
	  				  rewardCardService.insertRewardFulfillmentStatus(lRewardFulfillmentTrackingReportHist, BPMConstants.INTELISPEND_USER_SYSTEM);
	  			  }
	  			  
		  		  if (prevTransactionID != lRewardFulfillmentTrackingReportHist.getRewardTransHistID()) {
		  			Integer programID = rewardCardService.getProgramID(lRewardFulfillmentTrackingReportHist.getRewardTransHistID());
		  			programErrorSummaryMap = recordToProgramErrorSummaryMap(programErrorSummaryMap, programID);
		  			prevTransactionID = lRewardFulfillmentTrackingReportHist.getRewardTransHistID();
		  		  }
	  		  }
	  		 
	  	  }
  	  } catch (BPMException be) {
  	      logger.error("BPMException caught at processXMLResponseFromIntelispend.  Message is " + be.getMessage());
  		  throw new BPMException(be);
  	  } catch (DataAccessException dae) {
          logger.error("DataAccessException caught at processXMLResponseFromIntelispend.  Message is " + dae.getStackTrace());
		  throw new BPMException(dae);
  	  } catch (Exception e) {
  		  logger.error("Exception caught at processXMLResponseFromIntelispend.  Message is " + e.getStackTrace());
		  throw new BPMException(e);
  	  }

  	  
  	  return programErrorSummaryMap;
  	  
  }*/
  
  /*
   * Capture program control records that have incented activities.  This will be later used to drive what programs will appear in the summary report.
   */
  private  HashMap<Integer, RewardControlProgram> recordToProgramControlReportingMap(HashMap<Integer, RewardControlProgram> programControlReportingMap, RewardControlProgram lRewardControlProgram) {
	 
	  if (programControlReportingMap.containsKey(lRewardControlProgram.getProgramID())) {
		  //an entry is already for this program.  Ignore multiples if more than one incentive option has been setup within the same business program.
	  } else {
		  programControlReportingMap.put(lRewardControlProgram.getProgramID(), lRewardControlProgram);
	  }
		    
	  return programControlReportingMap;
  }
  
  /*
   * Capture counts by program of reward fulfillment tracking records read.  HashMap will be later used to produce a summary report.
   */
  private  HashMap<Integer, Integer> recordToProgramRewardsFulfilledReadSummaryMap(HashMap<Integer, Integer> programRewardFulfillRptHistReadSummaryMap, Integer programID, int programRewardsFulfillReadCt) {
	  Integer programRewardsFulfillReadCtTotal = null;;
	  
	 
		  if (programRewardFulfillRptHistReadSummaryMap.containsKey(programID)) {
			  programRewardsFulfillReadCtTotal = programRewardFulfillRptHistReadSummaryMap.get(programID);
			  programRewardsFulfillReadCtTotal = programRewardsFulfillReadCtTotal +  programRewardsFulfillReadCt;
			  programRewardFulfillRptHistReadSummaryMap.put(programID, programRewardsFulfillReadCtTotal);
		  } else {
			  programRewardFulfillRptHistReadSummaryMap.put(programID, programRewardsFulfillReadCt);
		  }
	 
		    
	  return programRewardFulfillRptHistReadSummaryMap;
  }
  
  /*
   * Capture counts by program of incented transactions written to reward fulfillment table.  HashMap will be later used to produce a summary report.
   */
  private  HashMap<Integer, Integer> recordToProgramRewardsFulfilledSummaryMap(HashMap<Integer, Integer> programRewardsFulfilledSummaryMap, Collection<PersonActivityAchievedReward> personRewardsFulfilled) {
	  Integer programRewardsFulfilledCt = null;;
	  
	  for (PersonActivityAchievedReward personRewardFulfilled : personRewardsFulfilled) {
		  if (programRewardsFulfilledSummaryMap.containsKey(personRewardFulfilled.getProgramID())) {
			  programRewardsFulfilledCt = programRewardsFulfilledSummaryMap.get(personRewardFulfilled.getProgramID());
			  programRewardsFulfilledCt++;
			  programRewardsFulfilledSummaryMap.put(personRewardFulfilled.getProgramID(), programRewardsFulfilledCt);
		  } else {
			  programRewardsFulfilledCt = 1;
			  programRewardsFulfilledSummaryMap.put(personRewardFulfilled.getProgramID(), programRewardsFulfilledCt);
		  }
	  }
		    
	  return programRewardsFulfilledSummaryMap;
  }
  
  /*
   * Capture counts by program of transactions bypassed because it exists on the recycle table.  HashMap will be later used to produce a summary report.
   */
  private  HashMap<Integer, Integer> recordToProgramMultiActivityBypassSummaryMap(HashMap<Integer, Integer> programMultiActivityBypassSummaryMap, RewardFulfillmentTrackingReportHist lRewardFulfillmentTrackingReportHist) {
	  Integer programRecycleBypassCt = null;;
	  
	  if (programMultiActivityBypassSummaryMap.containsKey(lRewardFulfillmentTrackingReportHist.getProgramID())) {
		  programRecycleBypassCt = programMultiActivityBypassSummaryMap.get(lRewardFulfillmentTrackingReportHist.getProgramID());
		  programRecycleBypassCt++;
		  programMultiActivityBypassSummaryMap.put(lRewardFulfillmentTrackingReportHist.getProgramID(), programRecycleBypassCt);
	  } else {
		  programRecycleBypassCt = 1;
		  programMultiActivityBypassSummaryMap.put(lRewardFulfillmentTrackingReportHist.getProgramID(), programRecycleBypassCt);
	  }
		    
	  return programMultiActivityBypassSummaryMap;
  }

  
  /*
   * Capture counts by program of transactions bypassed because it exists on the recycle table.  HashMap will be later used to produce a summary report.
   */
  private  HashMap<Integer, Integer> recordToProgramRecycleBypassSummaryMap(HashMap<Integer, Integer> programRecycleBypassSummaryMap, RewardFulfillmentTrackingReportHist lRewardFulfillmentTrackingReportHist) {
	  Integer programRecycleBypassCt = null;;
	  
	  if (programRecycleBypassSummaryMap.containsKey(lRewardFulfillmentTrackingReportHist.getProgramID())) {
		  programRecycleBypassCt = programRecycleBypassSummaryMap.get(lRewardFulfillmentTrackingReportHist.getProgramID());
		  programRecycleBypassCt++;
		  programRecycleBypassSummaryMap.put(lRewardFulfillmentTrackingReportHist.getProgramID(), programRecycleBypassCt);
	  } else {
		  programRecycleBypassCt = 1;
		  programRecycleBypassSummaryMap.put(lRewardFulfillmentTrackingReportHist.getProgramID(), programRecycleBypassCt);
	  }
		    
	  return programRecycleBypassSummaryMap;
  }

  
  /*
   * Capture counts by program of transactions approved and updated to a status of released in the reward recycle table.  HashMap will be later used to produce a summary report.
   */
  private  HashMap<Integer, Integer> recordToProgramRecycleReleasedSummaryMap(HashMap<Integer, Integer> programRecycleReleasedSummaryMap, RewardFulfillmentTrackingReportHist lRewardFulfillmentTrackingReportHist) {
	  Integer programRecycleReleasedCt = null;;
	  
	  if (programRecycleReleasedSummaryMap.containsKey(lRewardFulfillmentTrackingReportHist.getProgramID())) {
		  programRecycleReleasedCt = programRecycleReleasedSummaryMap.get(lRewardFulfillmentTrackingReportHist.getProgramID());
		  programRecycleReleasedCt++;
		  programRecycleReleasedSummaryMap.put(lRewardFulfillmentTrackingReportHist.getProgramID(), programRecycleReleasedCt);
	  } else {
		  programRecycleReleasedCt = 1;
		  programRecycleReleasedSummaryMap.put(lRewardFulfillmentTrackingReportHist.getProgramID(), programRecycleReleasedCt);
	  }
		    
	  return programRecycleReleasedSummaryMap;
  }
  
  
  
  /*
   * Capture counts by program of transactions sent to Intelispend.  HashMap will be later used to produce a summary report.
   */
  private  HashMap<Integer, Integer> recordToProgramSentSummaryMap(HashMap<Integer, Integer> programSentSummaryMap, Collection<RewardFulfillmentTrackingReportHist> lRewardFulfillmentTrackingReportHists) {
	  Integer programSentCt = null;
	  for (RewardFulfillmentTrackingReportHist lRewardFulfillmentTrackingReportHist : lRewardFulfillmentTrackingReportHists) {
		  if (programSentSummaryMap.containsKey(lRewardFulfillmentTrackingReportHist.getProgramID())) {
			  programSentCt = programSentSummaryMap.get(lRewardFulfillmentTrackingReportHist.getProgramID());
			  programSentCt++;
			  programSentSummaryMap.put(lRewardFulfillmentTrackingReportHist.getProgramID(), programSentCt);
		  } else {
			  programSentCt = 1;
			  programSentSummaryMap.put(lRewardFulfillmentTrackingReportHist.getProgramID(), programSentCt);
		  }
		  
	  }
	  
	  return programSentSummaryMap;
  }
  
  
  
  /*
   * Capture counts by program of transactions in error sent back from Intelispend.  HashMap will be later used to as part of the summary report.
   */
   private HashMap<Integer, Integer> recordToProgramErrorSummaryMap(HashMap<Integer, Integer> programErrorSummaryMap, Integer programID) {
	    Integer programErrorCt = null;
	    
		if (programErrorSummaryMap.containsKey(programID)) {
			  programErrorCt = programErrorSummaryMap.get(programID);
			  programErrorCt++;
			  programErrorSummaryMap.put(programID, programErrorCt);
		} else {
			programErrorCt = 1;
			programErrorSummaryMap.put(programID, programErrorCt);
		}
	
		return programErrorSummaryMap;
	}
   
   /*
    * From the collection that contains summary counts by program id,
    * return the count of incented activites bypassed that met multi activity tollgate rule.
    */
   
   private Integer getNumberBypassedForMultiActivityFromSummary(Integer programID, String quoteID, Collection<RewardCardQuoteByProgramSummary> rewardCardsQuotesByProgramSummary) {
	   
	   Integer numberWithMultiActivity = 0;
	   
	   for (RewardCardQuoteByProgramSummary lRewardCardQuoteByProgramSummary : rewardCardsQuotesByProgramSummary) {
		   if (lRewardCardQuoteByProgramSummary.getQuoteID().equals(quoteID)) {
			   HashMap<Integer, Integer> programMultiActivitySummaryMap = lRewardCardQuoteByProgramSummary.getProgramMultiActivitySummaryMap();
			   if (programMultiActivitySummaryMap != null && programMultiActivitySummaryMap.get(programID) != null) {
				   numberWithMultiActivity = programMultiActivitySummaryMap.get(programID);
			   }
	   		}
	   }
	   
	   return numberWithMultiActivity;
   }
   
   /*
    * Get the collection of program ids that produced a summary count of incented and fulfillment rewards.
    * Collection of program ids will drive the summary reporting that is displayed on the e-mail notification. 
    */
   
   private Collection<RewardControlProgram> getProgramControlProducingSummaryReport(String quoteID, Collection<RewardCardQuoteByProgramSummary> rewardCardQuoteByProgramsSummary) {
	    
	   Collection<RewardControlProgram> lRewardControlPrograms = new ArrayList<RewardControlProgram>();
	   for (RewardCardQuoteByProgramSummary lRewardCardQuoteByProgramSummary : rewardCardQuoteByProgramsSummary) {
		   if (lRewardCardQuoteByProgramSummary.getQuoteID().equals(quoteID)) {
			   return lRewardCardQuoteByProgramSummary.getProgramControlReportingMap().values();
	   		}
	   }
	   return lRewardControlPrograms;
   }
   
   /*
    * From the collection that contains summary counts by program id of what was sent and in error after a the Intelispend batch run finished,
    * return the total number of records processed from the program sent hashmap.
    */
   
   private Integer getBatchTotalRewardSentCount(Collection<RewardCardQuoteByProgramSummary> rewardCardsQuotesByProgramSummary) {
	   
	   Integer batchTotalRewardsSent = 0;
	   
	   for (RewardCardQuoteByProgramSummary lRewardCardQuoteByProgramSummary : rewardCardsQuotesByProgramSummary) {
		   HashMap<Integer, Integer> programSentSummaryMap = lRewardCardQuoteByProgramSummary.getProgramSentSummaryMap();
		   
		   if (programSentSummaryMap != null) {
			   Collection<Integer> programSentCounts = programSentSummaryMap.values();
			   for (Integer programSentCount : programSentCounts) {
				   
				   batchTotalRewardsSent = batchTotalRewardsSent + programSentCount;
			   }
		   }
	   }
	   
	   return batchTotalRewardsSent;
   }
   
   /*
    * From the collection that contains summary counts by program id,
    * return the count of missing addresses by program preventing transactions from being sent on to Intelispend.
    */
   
   private Integer getNumberIncentedRewardFulfillWrittenFromIncentedFromSummary(Integer programID, String quoteID, Collection<RewardCardQuoteByProgramSummary> rewardCardsQuotesByProgramSummary) {
	   
	   Integer numberRewardsFulfilled = 0;
	   
	   for (RewardCardQuoteByProgramSummary lRewardCardQuoteByProgramSummary : rewardCardsQuotesByProgramSummary) {
		   if (lRewardCardQuoteByProgramSummary.getQuoteID().equals(quoteID)) {
			   HashMap<Integer, Integer> programRewardFulfilledSummaryMap = lRewardCardQuoteByProgramSummary.getProgramRewardFulfilledSummaryMap();
			   if (programRewardFulfilledSummaryMap != null && programRewardFulfilledSummaryMap.get(programID) != null) {
				   numberRewardsFulfilled = programRewardFulfilledSummaryMap.get(programID);
			   }
	   		}
	   }
	   
	   return numberRewardsFulfilled;
   }
   
   /*
    * From the collection that contains summary counts by program id,
    * return the count of fulfillment tracking records read by program.
    */
   
   private Integer getNumberRewardFulfillRecsReadFromSummary(Integer programID, String quoteID, Collection<RewardCardQuoteByProgramSummary> rewardCardsQuotesByProgramSummary) {
	   
	   Integer numberRewardFulfillRecsRead = 0;
	 
	   for (RewardCardQuoteByProgramSummary lRewardCardQuoteByProgramSummary : rewardCardsQuotesByProgramSummary) {
		   if (lRewardCardQuoteByProgramSummary.getQuoteID().equals(quoteID)) {
			   HashMap<Integer, Integer> programRewardReadFromFulfilledSummaryMap = lRewardCardQuoteByProgramSummary.getProgramRewardReadFromFulfilledSummaryMap();
			   numberRewardFulfillRecsRead = lRewardCardQuoteByProgramSummary.getProgramRewardFulfillRptHistReadSummaryMap().get(programID);  
	   		}
	   }
	  
	   return numberRewardFulfillRecsRead;
   }
   
   
   /*
    * From the collection that contains summary counts by program id,
    * return the count of missing addresses by program preventing transactions from being sent on to Intelispend.
    */
   
   private Integer getNumberWithoutAddressFromSummary(Integer programID, String quoteID, Collection<RewardCardQuoteByProgramSummary> rewardCardsQuotesByProgramSummary) {
	   
	   Integer numberMissingAddress = 0;
	   
	   for (RewardCardQuoteByProgramSummary lRewardCardQuoteByProgramSummary : rewardCardsQuotesByProgramSummary) {
		   if (lRewardCardQuoteByProgramSummary.getQuoteID().equals(quoteID)) {
			   HashMap<Integer, Integer> programMissingAddressSummaryMap = lRewardCardQuoteByProgramSummary.getProgramMissingAddressSummaryMap();
			   if (programMissingAddressSummaryMap != null && programMissingAddressSummaryMap.get(programID) != null) {
				   numberMissingAddress = programMissingAddressSummaryMap.get(programID);
			   }
	   		}
	   }
	   
	   return numberMissingAddress;
   }
   
   /*
    * From the collection that contains summary counts by program id,
    * return the count of transactions that were bypassed because they exist on recycle table.
    */
   
   private Integer getNumberOfRecycleFromSummary(Integer programID, String quoteID, Collection<RewardCardQuoteByProgramSummary> rewardCardsQuotesByProgramSummary) {
	   
	   Integer numberOfRecycle = 0;
	   
	   for (RewardCardQuoteByProgramSummary lRewardCardQuoteByProgramSummary : rewardCardsQuotesByProgramSummary) {
		   if (lRewardCardQuoteByProgramSummary.getQuoteID().equals(quoteID)) {
			   HashMap<Integer, Integer> programRecycleBypassSummaryMap = lRewardCardQuoteByProgramSummary.getProgramRecycleBypassSummaryMap();
			   if (programRecycleBypassSummaryMap != null && programRecycleBypassSummaryMap.get(programID) != null) {
				   numberOfRecycle = programRecycleBypassSummaryMap.get(programID);
			   }
	   		}
	   }
	   
	   return numberOfRecycle;
   }
   
  
   /*
    * From the collection that contains summary counts by program id,
    * return the count of missing addresses by program preventing transactions from being sent on to Intelispend.
    */
   
   private Integer getNumberOfReleasedFromSummary(Integer programID, String quoteID, Collection<RewardCardQuoteByProgramSummary> rewardCardsQuotesByProgramSummary) {
	   
	   Integer numberOfRecycle = 0;
	   
	   for (RewardCardQuoteByProgramSummary lRewardCardQuoteByProgramSummary : rewardCardsQuotesByProgramSummary) {
		   if (lRewardCardQuoteByProgramSummary.getQuoteID().equals(quoteID)) {
			   HashMap<Integer, Integer> programRecycleReleasedSummaryMap = lRewardCardQuoteByProgramSummary.getProgramRecycleReleasedSummaryMap();
			   if (programRecycleReleasedSummaryMap != null && programRecycleReleasedSummaryMap.get(programID) != null) {
				   numberOfRecycle = programRecycleReleasedSummaryMap.get(programID);
			   }
	   		}
	   }
	   
	   return numberOfRecycle;
   }
   
   /*
    * From the collection that contains summary counts by program id of what was sent and in error after a the Intelispend batch run finished,
    * return the count of total number of transactions sent to intelispend for the given program.
    */
   
   private Integer getNumberOfOrdersFromSummary(Integer programID, String quoteID, Collection<RewardCardQuoteByProgramSummary> rewardCardsQuotesByProgramSummary) {
	   
	   Integer numberOfOrders = 0;
	   
	   for (RewardCardQuoteByProgramSummary lRewardCardQuoteByProgramSummary : rewardCardsQuotesByProgramSummary) {
		   if (lRewardCardQuoteByProgramSummary.getQuoteID().equals(quoteID)) {
			   HashMap<Integer, Integer> programSentSummaryMap = lRewardCardQuoteByProgramSummary.getProgramSentSummaryMap();
			   if (programSentSummaryMap != null && programSentSummaryMap.get(programID) != null) {
				   numberOfOrders = programSentSummaryMap.get(programID);
			   }
	   		}
	   }
	   
	   return numberOfOrders;
   }
   
   /*
    * From the collection that contains summary counts by program id of what was sent and in error after a the Intelispend batch run finished,
    * return the count of total number of transactions sent to intelispend for the given program.
    */
   
   private Integer getNumberOfErrorsFromSummary(Integer programID, String quoteID, Collection<RewardCardQuoteByProgramSummary> rewardCardsQuotesByProgramSummary) {
	   
	   Integer numberOfErrors = 0;
	   
	   for (RewardCardQuoteByProgramSummary lRewardCardQuoteByProgramSummary : rewardCardsQuotesByProgramSummary) {
		   if (lRewardCardQuoteByProgramSummary.getQuoteID().equals(quoteID)) {
			   HashMap<Integer, Integer> programSentErrorMap = lRewardCardQuoteByProgramSummary.getProgramErrorSummaryMap();
			   if (programSentErrorMap != null && programSentErrorMap.get(programID) != null) {
					   numberOfErrors = programSentErrorMap.get(programID);
			   }
	   		}
	   }
	   
	   return numberOfErrors;
   }
   
   
   
  
  /*
   * Record the status of the group site control record transactions sent so there is a record of it and if a batch was sent successfully
   * or not.
   */
  private void addRewardControlProgramTrackerStatus(String quoteID, String resultStatus) throws BPMException {
	  try {
		  Collection<RewardControlProgram> lRewardControlPrograms = rewardCardService.getRewardControlPrograms(quoteID);
		  for (RewardControlProgram lRewardControlProgram : lRewardControlPrograms) {
				rewardCardService.insertRewardControlProgramProcessTracker(lRewardControlProgram.getControlProgramID(), resultStatus, lRewardControlProgram.getRewardFulfillmentCountToSendToVendor());
				//batchTotalRewardsAchieved = batchTotalRewardsAchieved + lRewardControlProgram.getRewardFulfillmentCountToSendToVendor();
			}
	  } catch (Exception e) {
		  throw new BPMException(e);
	  }
  }
  
 
 
  
  /*
   * Check to see if error returned from Intelispend already exists by item number and is ON HOLD or DENIED If yes, then do not insert a duplicate
   * error into the recycle table.
   */
  private boolean doesErrorsAlreadyExistInRecycleByTransHistID(RewardIntelispendResponse lRewardIntelispendResponse) {
		
	    boolean errorExists = false;
		Integer rewardTransHistID = Integer.valueOf(lRewardIntelispendResponse.getErrorRewardTransHistID());
	
		try {
			errorExists = rewardCardService.doesErrorExistInRewardRecycle(rewardTransHistID);
		} catch (BPMException e) {
			
			logger.error("Read error against Reward Recyle table.  Stacktrace follows: " + e.getStackTrace());
			return errorExists;
		}
		
		
		
		return errorExists;
  }
  
  
  
  private RewardFulfillmentTrackingRecycle rewardFulfillRecylceMapper(RewardIntelispendResponse lRewardIntelispendResponse) {
	  
	  RewardFulfillmentTrackingRecycle lRewardFulfillmentTrackingRecycle = new RewardFulfillmentTrackingRecycle();
	  lRewardFulfillmentTrackingRecycle.setRecycleStatusId(lRewardIntelispendResponse.getRecycleStatusID());
	  lRewardFulfillmentTrackingRecycle.setReasonDesc(lRewardIntelispendResponse.getErrorDesc());
	  lRewardFulfillmentTrackingRecycle.setFieldColumn(lRewardIntelispendResponse.getErrorFieldColumn());
	  lRewardFulfillmentTrackingRecycle.setRewardTransHistID(Integer.valueOf(lRewardIntelispendResponse.getErrorRewardTransHistID()));
	  lRewardFulfillmentTrackingRecycle.setItemNo(lRewardIntelispendResponse.getErrorItemno());
	  
	  return lRewardFulfillmentTrackingRecycle;
	  
  }
  
  private Collection<PersonActivityAchievedContribution> mapperPersonActivityAchievedContribution(Collection<CDHPFulfillmentTrackingReportHist> hsaFulfillmentContributionHistoryTrackingRpts) {
		 
		 ArrayList<PersonActivityAchievedContribution> lPersonActivityAchievedContributions = new ArrayList<PersonActivityAchievedContribution>();
		 Iterator<CDHPFulfillmentTrackingReportHist> iter = (Iterator<CDHPFulfillmentTrackingReportHist>)hsaFulfillmentContributionHistoryTrackingRpts.iterator();
		 
		 while (iter.hasNext()) {
			 CDHPFulfillmentTrackingReportHist lCDHPFulfillmentTrackingReportHist = (CDHPFulfillmentTrackingReportHist)iter.next();
			 PersonActivityAchievedContribution lPersonActivityAchievedContribution = new PersonActivityAchievedContribution();
			 lPersonActivityAchievedContribution.setProgramID(lCDHPFulfillmentTrackingReportHist.getProgramID());
			 lPersonActivityAchievedContribution.setContractNo(lCDHPFulfillmentTrackingReportHist.getContractNo());
			 lPersonActivityAchievedContribution.setContributionAmt(lCDHPFulfillmentTrackingReportHist.getContributionAmount());
			 lPersonActivityAchievedContribution.setPackageSubType(lCDHPFulfillmentTrackingReportHist.getPackageSubTypeName());
			 lPersonActivityAchievedContribution.setContributionDate(lCDHPFulfillmentTrackingReportHist.getContributionDate());
			 lPersonActivityAchievedContribution.setContribTypeCodeID(lCDHPFulfillmentTrackingReportHist.getContributionTypeCodeId());
			 lPersonActivityAchievedContribution.setIncentiveOptionID(lCDHPFulfillmentTrackingReportHist.getIncentiveOptionID());
			 lPersonActivityAchievedContribution.setActivityID(lCDHPFulfillmentTrackingReportHist.getActivityID());
			 lPersonActivityAchievedContribution.setPersonDemographicsID(lCDHPFulfillmentTrackingReportHist.getPersonDemographicsID());
			 lPersonActivityAchievedContributions.add(lPersonActivityAchievedContribution);
			 
		 }
		 return lPersonActivityAchievedContributions;
	 }
  
/*private ArrayList<RewardIntelispendResponse> buildRewardIntelispendResponse(DXML dxmlResponse) {
	  
	  ArrayList<RewardIntelispendResponse> lRewardIntelispendResponses = new ArrayList<RewardIntelispendResponse>();
	  
	  try {  
	        if (dxmlResponse.getResponse().getERROR().size() > 0) {
	        	logger.info("Errors exist for this batch");
	        	List<ERROR> errors = dxmlResponse.getResponse().getERROR();
	        	for (ERROR err : errors) {
	        		RewardIntelispendResponse lRewardIntelispendResponse = new RewardIntelispendResponse();
					lRewardIntelispendResponse.setErrorFieldColumn(err.getERRORCOLUMN());
					lRewardIntelispendResponse.setErrorDesc(err.getERRORDESCRIPTION());
					lRewardIntelispendResponse.setErrorItemno(err.getERRORITEMNO());
					lRewardIntelispendResponse.setErrorRewardTransHistID(err.getERRORPID());
					logger.info("----------------------------------------------------");
					logger.info("ERRORPID(fulfill Hist ID)- " + err.getERRORPID());
					logger.info("ERRORITEMNO              - " + err.getERRORITEMNO());
					logger.info("ERRORCOLUMNNO            - " + err.getERRORCOLUMN());
					logger.info("ERRORDESCRIPTION         - " + err.getERRORDESCRIPTION());
					lRewardIntelispendResponses.add(lRewardIntelispendResponse);
					setErrorMessageFromVendorWebservice(err.getERRORDESCRIPTION());
				}         
		      //check for successful batch sent
	        } else {
	  	           RewardIntelispendResponse lRewardIntelispendResponse = new RewardIntelispendResponse();
	  		       String successDesc =  dxmlResponse.getResponse().getSUCCESS();
	  		       logger.info("----------------------------------------------------");
	  		       logger.info("Batch successfull description - " + successDesc);
	  		       lRewardIntelispendResponse.setSuccessDesc(successDesc);
	  	           lRewardIntelispendResponses.add(lRewardIntelispendResponse); 
		    }
	        
	  }catch (Exception e) {
	        e.printStackTrace();
	  }
	 
	  
	  return lRewardIntelispendResponses;
	  
	}
  */
	
	/*
	 * /Batch up the reward fulfillment transactions by quote id.  Transactions will roll up to one quote id.
	 */
	private HashMap<String, Collection<RewardFulfillmentTrackingReportHist>> batchUpTransactionsByQuoteID(Collection<RewardFulfillmentTrackingReportHist> rewardFulfillmentHistoryTrackingRpts, HashMap<String, Collection<RewardFulfillmentTrackingReportHist>> lQuoteRewardsHashMap, String quoteID) {
		
		if (lQuoteRewardsHashMap.containsKey(quoteID)) {
			Collection<RewardFulfillmentTrackingReportHist> rewardFulfillments = (Collection<RewardFulfillmentTrackingReportHist>)lQuoteRewardsHashMap.get(quoteID);
			rewardFulfillments.addAll(rewardFulfillmentHistoryTrackingRpts);
		} else {
			lQuoteRewardsHashMap.put(quoteID, rewardFulfillmentHistoryTrackingRpts);
		}	
		
		
		return lQuoteRewardsHashMap;
	}
	  
   
/*
 * Produce a list of member contracts with an ON HOLD status from the person contract recycle table.  Send in an e-mail
 * to a distribution list of business users responsible for monitoring member contracts on hold.  This will be a check and balance
 * between BUSG Team members and the business users waiting for ON HOLDs to be addressed within the BPM system.
 */
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
			com.healthpartners.service.imfs.exception.BPMBusinessValidationException.class, BPMException.class })
public void createPersonContractOnHoldReport(StatusCalculationCommand statusCalculationCommand) throws BPMException
	{
		boolean isMoreThan50 = false;
		logger.info("@Start - Create Person Contract On Hold Report. ");
		
		StringBuffer batchMailSubject = new StringBuffer();
		batchMailSubject.append("BPM Batch Process Status (Person Contract OnHold Report) ");
		StringBuffer batchMailContent = new StringBuffer();
		batchMailContent.append("<table>");
		batchMailContent.append("<tr><td>BPM Batch Name: Member Contract Recycle ON HOLD Report</td></tr>");

		batchMailContent.append("<tr><td>Initiated User: "
				+ statusCalculationCommand.getUserID() + "</td></tr>");
		
		batchMailContent
		.append("<tr><td>MEMBER CONTRACT RECYCLE REPORT WITH ON HOLD STATUSES DUE TO TOLLGATE RULES NOT MET</td></tr> ");
		batchMailContent.append("</table>");
		Collection<PersonContractRecycleList> lPersonContractsRecycleList = personDAO.getPersonContractRecycleByRecycleStatus(BPMConstants.PERSON_CONTRACT_RECYCLE_STATUS_ON_HOLD);
		if (lPersonContractsRecycleList.size() > 0) {
			// column headers

			batchMailContent.append("<table>");
			batchMailContent
			.append("<tr><td>Row</td><td>Recycle Status</td><td>Recycle Status Date</td><td>Member ID</td><td>Contract No</td><td>Member Name</td><td>Group ID</td><td>Group Name</td><td>Tollgate Rule Not Met</td></tr>");

			Iterator<PersonContractRecycleList> iter  = (Iterator<PersonContractRecycleList>) lPersonContractsRecycleList.iterator();
			int rowCt = 1;
	    	while (iter.hasNext()) {
	    		PersonContractRecycleList lPersonContractRecycleList = (PersonContractRecycleList)iter.next();
				batchMailContent
						.append("<tr>");
				batchMailContent
				.append("<td>" + rowCt + "</td>" + "<td>" + lPersonContractRecycleList.getRecycleStatus() + "</td>");
				String recycleStatusDate = BPMUtils.formatDateMMddyyyy(lPersonContractRecycleList.getRecycleStatusDate());
				batchMailContent
				.append("<td>"  + recycleStatusDate + "</td>");
				batchMailContent
				.append("<td>"  + lPersonContractRecycleList.getMemberNo() + "</td>");
				batchMailContent
				.append("<td>"  + lPersonContractRecycleList.getContractNo() + "</td>");
				batchMailContent.append("<td>");
				batchMailContent
				.append(lPersonContractRecycleList.getLastName() + ", " + lPersonContractRecycleList.getFirstName());
				batchMailContent.append("</td>");

				batchMailContent
						.append("<td>" + lPersonContractRecycleList.getGroupNo() + "</td>");
				batchMailContent
						.append("<td>" + lPersonContractRecycleList.getGroupName() + "</td>");

				if (lPersonContractRecycleList.getReasonDescription() != null) {
					batchMailContent
							.append("<td>" + lPersonContractRecycleList.getReasonDescription() + "</td>");
				} else {
					batchMailContent
							.append("<td>DESCRIPTION NOT AVAILABLE</td>");
				}
				batchMailContent
						.append("</tr>");
				rowCt++;
				if (rowCt > 50) {
					isMoreThan50 = true;
					break;
				}

	    	}
			batchMailContent.append("</table>");
	    	if (isMoreThan50) {
				//cap report list at 50
				batchMailContent.append("<table>");
				batchMailContent.append("<tr>");
				batchMailContent
						.append("<td>***ATTENTION: REPORT CUTOFF AT 50 ROWS.  " + "A TOTAL OF " + lPersonContractsRecycleList.size() + " ON HOLD MEMBER CONTRACTS RETURNED.</td>");
				batchMailContent.append("<tr>");
				batchMailContent.append("</table>");
			}
	    	emailService.setEmailDestination(BPMConstants.EMAIL_DESTINATION_MEMBERSHIP_ONHOLD_RPT);
	    	emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
			emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
					batchMailContent.toString());
		} 
		
    	
	}
	
	/*
	 * Produce a list of those member contracts out of sync with member contracts on the member contract history table which is a reflection
	 * of what was sent to Cache membership.  Send in an e-mail to a distribution list of business users responsible for researching why contract
	 * status's were never sent to Cache membership. 
	 */
		@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
				com.healthpartners.service.imfs.exception.BPMBusinessValidationException.class, BPMException.class })
	private void createPersonContractReconciliationReport(StatusCalculationCommand statusCalculationCommand, ArrayList<PersonContractHist> lPersonContractsHistDifferences) throws BPMException
		{
			logger.info("@Start - Create Person Contract Reconciliation Detail Report. ");
			
			StringBuffer batchMailSubject = new StringBuffer();
			batchMailSubject.append("<tr><td>" + "BPM Batch Process - Member Contract Reconciliation Detail Report - Status: " + "</td></tr>");
			StringBuffer batchMailContent = new StringBuffer();
			
			batchMailContent.append("<tr><td>" + "BPM Batch Name: Member Contract Reconciliation Detail Report" + "</td></tr>");

			batchMailContent.append("<tr><td>" + "Initiated User: "
					+ statusCalculationCommand.getUserID() + "</td></tr>");
			
			batchMailContent
			.append("<tr><td>" + " MEMBER CONTRACT RECONCILIATION DETAIL REPORT" + "</td></tr>");
			
			if (lPersonContractsHistDifferences.size() > 0) {
				// column headers
				
				batchMailContent
				.append("<tr><td>" + "Group No" + "</td>" +  "<td>"  + "Site No"  + "</td>" +  "<td>" + "Member No" + "</td>" + "<td>" + "Contract No"  + "</td>"  + "<td>" + "Member Name"   + "</td>"  + "<td>" + "Contract Status" + "</td>" + "<td>" + "Chg Date"  + "</td>" + "<td>" + "Cache Contract Status" + "</td>" + "<td>"  +  "Sent Date" + "</td></tr>");
				
				Iterator<PersonContractHist> iter  = (Iterator<PersonContractHist>) lPersonContractsHistDifferences.iterator();
				int rowCt = 1;
		    	while (iter.hasNext()) {
		    		PersonContractHist lPersonContractHistDifference = (PersonContractHist)iter.next();
					
		    		char padWithChar = ' ';
					int width = 8;
					String groupNumberStr = Integer.toString(lPersonContractHistDifference.getGroupID());
					String groupNumberPadded = BPMUtils.justifyRight(groupNumberStr, width, padWithChar);
					batchMailContent
					.append("\n " + rowCt + ") " + groupNumberPadded + " ");
					
					String siteNumberStr = Integer.toString(lPersonContractHistDifference.getSiteID());
					String siteNumberPadded = BPMUtils.justifyRight(siteNumberStr, width, padWithChar);
					batchMailContent.append("<tr><td>" + siteNumberPadded + "        ");
					
					batchMailContent
					.append("<tr><td>" + lPersonContractHistDifference.getMemberNumber() + "</td></tr>");
					
					batchMailContent
					.append("<tr><td>" + lPersonContractHistDifference.getContractNumber() + "</td></tr>");
					
					batchMailContent
					.append("<tr><td>" + lPersonContractHistDifference.getLastName() + "</td></tr>");
					batchMailContent
					.append("<tr><td>" + ", " + lPersonContractHistDifference.getFirstName() + "</td></tr>");
					
					batchMailContent
					.append("<tr><td>" + lPersonContractHistDifference.getContractStatus() + "</td></tr>");
					batchMailContent
					.append("<tr><td>" + lPersonContractHistDifference.getContractStatusDate() + "</td></tr>");
					
					batchMailContent
					.append("<tr><td>" + lPersonContractHistDifference.getHistoryContractStatus() + "</td></tr>");
					batchMailContent
					.append("<tr><td>" + lPersonContractHistDifference.getHistoryContractInsertDate() + "</td></tr>");
					
					
					rowCt++;
					if (rowCt > 100) {
						//cap report list at 100
						batchMailContent
						.append("<tr><td>" + "***ATTENTION: REPORT CUTOFF AT 100 ROWS.  " + "A TOTAL OF " + lPersonContractsHistDifferences.size() + " Member Contract Statuses not matching Cache Membership." + "</td></tr>");
						break;
					}
				
		    	} 
		    	emailService.setEmailDestination(BPMConstants.BPM_EMAIL_TO_ADDR_RECONCILE_RPT);
		    	emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
				emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
						batchMailContent.toString());
			} 
			
	    	
		}
	
	
	
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
			com.healthpartners.service.imfs.exception.BPMBusinessValidationException.class, BPMException.class })
public void processReconcilePersonContractHistoryCommand(
			StatusCalculationCommand statusCalculationCommand)
			throws BPMException
	{
		logger.info("@Start - Person Contract History Reconciliation. ");
		
		int recsWritten = 0;
		
		String failureReason = null;
		String elapsedTime = null;
		
		java.util.Date startDate = new java.util.Date();
		java.util.Date endDate = null;
		
		
		
		BPMAuditRecord bpmAuditRecord = new BPMAuditRecord();
		
		
		String processName = statusCalculationCommand.getProcessName();
		bpmAuditRecord.setApplicationId(processName);
		bpmAuditRecord.setApplicationEvent("processReconcilePersonContractHistoryCommand");
		statusCalculationCommand.setCurrentCommandText("Person Contract History Reconciliation");
		
		java.sql.Date lPersonContractHistoryReconcCutoffDate = getPersonContractHistoryReconciliationDate(BPMConstants.PRSN_CONTRACT_HIST_RECON_CUTOFF_DATE);
			
		
		ArrayList<PersonContractHist> lPersonContractsHistDifferences  =  (ArrayList<PersonContractHist>)memberService.getPersonContractHistoryReconciled(lPersonContractHistoryReconcCutoffDate);
		
		if (lPersonContractsHistDifferences.size() > 0) {
			try {
				//EV81688 - Still need to touch the person program status with todays date to bring
				//          over contract status.   EV addresses contract status is incorrect and needs to
				//          be reprocessed.  This is where a processing status log is inserted forcing 
				//          activities for the person to be recalculated when pending activities batch job
				//          kicks off.
				updateMemberProgramStatusContractStatusDate(lPersonContractsHistDifferences);
			
				for (PersonContractHist lPersonContractHistDifferences : lPersonContractsHistDifferences) {
					Integer personDemographicsId = lPersonContractHistDifferences.getPersonDemographicsID();
					Integer processId = BPMConstants.BPM_ADMIN_MEMBERSHIP_UPDATE_PRCS_ID;
					String processingStatusValue = BPMConstants.PROCESSING_STATUS_PENDING;
					String userId = null;
					if (statusCalculationCommand.getUserID() != null) {
						userId = statusCalculationCommand.getUserID();
					} else {
						userId = BPMConstants.BPM_USER_SYSTEM;
					}
					
					memberService.insertPersonProcessingStatus(personDemographicsId, processId, processingStatusValue, userId);
					recsWritten++;
				}
				} catch (Exception e) {
					failureReason = BPMUtils.getStakTraceAsString(e);
					logger.error(failureReason, e);
				} finally {
					endDate = new java.util.Date();
					elapsedTime = BPMUtils
							.getTimeDifferenceAsString(startDate, endDate);
					logger.info("@@@@End - Total processing time " + elapsedTime);
					logger.info("@@@@End - Number of Person Contract History to Contract Program Status differences:  = "
							+ lPersonContractsHistDifferences.size());
					logger.info("@@@@End - Number of Processing Status Log records written:  = "
							+ recsWritten);
					
					
				}
			
		} else {
			endDate = new java.util.Date();
			elapsedTime = BPMUtils
					.getTimeDifferenceAsString(startDate, endDate);	
		}		
			
		StringBuffer batchMailSubject = new StringBuffer();
		batchMailSubject.append("BPM Batch Process - Contract Status Reconciliation - Status: ");
		StringBuffer batchMailContent = new StringBuffer();
		batchMailContent.append("BPM Batch Name: Contract Status Reconciliation");
		batchMailContent.append("\nInitiated User: "
				+ statusCalculationCommand.getUserID());
		batchMailContent.append("\nTime Start: "
				+ BPMUtils.getFormattedDateTime(startDate));
		batchMailContent.append("\nContract Reconciliation Cutoff Date: "
				+ BPMUtils.getFormattedDateTime(lPersonContractHistoryReconcCutoffDate));
		
		if (recsWritten > 0) {
		batchMailContent
				.append("\nPerson Contract History Statuses not current with Contract Statuses on BPM System is " + lPersonContractsHistDifferences.size());
		batchMailContent
		.append("\nProcessing status log records written:  " + recsWritten);
		} else {
			batchMailContent
			.append("\n ALL Person Contract History Statuses are current with Contract Statuses on BPM System. ");
		}
						
		
		if (failureReason != null) {
			bpmAuditRecord.setEventResult("FAILED");
			batchMailSubject.append("- FAILED");
			batchMailContent.append("\nResult: FAILED");
			batchMailContent.append("\nReason: \n");
			batchMailContent.append(failureReason);
		} else {
			bpmAuditRecord.setEventResult("SUCCESS");
			batchMailSubject.append("- SUCCESS");
			batchMailContent.append("\nResult: SUCCESS");
		}
		emailService.setEmailDestination(BPMConstants.EMAIL_DESTINATION_MEMBERSHIP);
		emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
		emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
				batchMailContent.toString());
		
		
		
		businessProgramService.writeToAuditLog(statusCalculationCommand, batchMailSubject.toString(), startDate.toString(), endDate.toString(),
				elapsedTime.toString(), Integer.toString(recsWritten));

		if (failureReason != null) {
			logger.info("processReconcilePersonContractHistoryCommand Failed: " + failureReason);
			throw new BPMException(failureReason);
		}
		
		createPersonContractReconciliationReport(statusCalculationCommand, lPersonContractsHistDifferences);
		
		logger.info("@End - Person Contract History Reconciliation. ");
	}
/*
 * This batch process is responsible for updating the employer fulfillment tracking table and sending 
 * a common delimited file to an employer.  Looks for non HA program activities completed and writes the
 * result to the tracking file.  A second step reads from the tracking file and writes the member completed activities
 * to a csv file.
 *  	
 */

private void processEmployerFulfillmentReportingCommand(
			StatusCalculationCommand statusCalculationCommand)
			throws BPMException
	{
		logger.info("@Start - Employer Fulfillment Reporting. ");
		
		int recsWritten = 0;
		int recsSent = 0;
		
		String failureReason = null;
		String elapsedTime = null;
		
		java.util.Date startDate = new java.util.Date();
		java.util.Date endDate = null;
		
		
		
		BPMAuditRecord bpmAuditRecord = new BPMAuditRecord();
		
		
		String processName = statusCalculationCommand.getProcessName();
		String groupNo     = statusCalculationCommand.getGroupNo();
		
		//Returns todays date if no date was sent in.
		logger.info("@Start - Returns todays date if no date was sent in. ");
		java.sql.Date snapShotEmplTrackDate = BPMUtils.getDateFromString(statusCalculationCommand.getSnapShotEmplFulfillTrackDate());
		
		
		
		
		bpmAuditRecord.setApplicationId(processName);
		bpmAuditRecord.setApplicationEvent("processEmployerFulfillmentReportingCommand");
		statusCalculationCommand.setCurrentCommandText("Employer Fulfillment Reporting");
		
		
		try {
			if (groupNo == null || groupNo.isEmpty()) {
				failureReason = "processEmployerFulfillmentReportingCommand: Missing Group Number";
				logger.error(failureReason);
			} else {
				String additionalActivityCompletersToProcessBasedOnWeekNDayOfMonth = determineTheWeekNDayOfMonthToProcess();
				logger.info("@ Participating completers are for group " + groupNo);
				logger.info("@ determineTheWeekNDayOfMonthToProcess count returned is " + additionalActivityCompletersToProcessBasedOnWeekNDayOfMonth);
				recsWritten = personDAO.insertEmployerFulfillmentMemberActivityCompletions(groupNo, additionalActivityCompletersToProcessBasedOnWeekNDayOfMonth);
				logger.info("@ New activity completer counts are " + recsWritten);
			}
		} catch (Exception e) {
			failureReason = BPMUtils.getStakTraceAsString(e);
			logger.error(failureReason, e);
		}
		
		
		if (recsWritten > 0) {
			Collection<EmployerFulfillmentMemberActivity> memberActivityCompletions  = personDAO.getEmployerFulfillmentMemberActivityCompletions(groupNo, snapShotEmplTrackDate, null);
			logger.info("@@@@ - Member Activity Completions to send " + memberActivityCompletions.size());
			try {
				recsSent = sendEmployerActivityCompletionFile(memberActivityCompletions);
			} catch (BPMException e) {
				failureReason = BPMUtils.getStakTraceAsString(e);
				logger.error(failureReason, e);
			} catch (Exception e) {
				failureReason = BPMUtils.getStakTraceAsString(e);
				logger.error(failureReason, e);
			}
		}
			
		endDate = new java.util.Date();
		elapsedTime = BPMUtils
				.getTimeDifferenceAsString(startDate, endDate);
		logger.info("@@@@End - Total processing time " + elapsedTime);
		logger.info("@@@@End - Number of Employer Fulfillment Member Activity Completions written to tracking table:  = "
				+ recsWritten);	
		
			
		StringBuffer batchMailSubject = new StringBuffer();
		batchMailSubject.append("BPM Batch Process Status (Employer Fulfillment Reporting)");
		StringBuffer batchMailContent = new StringBuffer();
		
		
		batchMailContent.append("<tr><td>" + "BPM Batch Name: Employer Fulfillment Reporting" + "</td></tr>");
		
		batchMailContent.append("<tr><td>" + "Initiated User: "
				+ statusCalculationCommand.getUserID() + "</td></tr>");
		batchMailContent.append("<tr><td>" + "Time Start: "
				+ BPMUtils.getFormattedDateTime(startDate) + "</td></tr>");
		
		batchMailContent.append("<tr><td>" + "Reporting on group " + groupNo + "." + "</td></tr>");
		
		
		if (recsWritten > 0 && recsSent > 0) {
			batchMailContent
					.append("<tr><td>" + "Records written to Employer Fulfillment Tracking table " + recsWritten + "." + "</td></tr>");
			batchMailContent
					.append("<tr><td>" + "Records written to employer completions csv file: " + recsSent + "." + "</td></tr>");
		} else if (recsSent == 0) {
			batchMailContent
			.append("<tr><td>" + "There were no employer activity completion records to write to csv file. " + "</td></tr>");
		} 
						
		if (failureReason != null) {
			bpmAuditRecord.setEventResult("FAILED");
			batchMailSubject.append("- FAILED");
			batchMailContent.append("<tr><td>" + "Result: FAILED" + "</td></tr>");
			batchMailContent.append("<tr><td>" + "Reason: " + "</td></tr>");
			batchMailContent.append("<tr><td>" + failureReason + "</td></tr>");
		} else {
			bpmAuditRecord.setEventResult("SUCCESS");
			batchMailSubject.append("- SUCCESS");
			batchMailContent.append("<tr><td>" + "Result: SUCCESS" + "</td></tr>");
		}
		emailService.setEmailDestination(BPMConstants.EMAIL_DESTINATION_EMPLOYER_FULFILLMENT_RPT);
		emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_TEXT);
		emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
				batchMailContent.toString());
		
		
		
		businessProgramService.writeToAuditLog(statusCalculationCommand, batchMailSubject.toString(), startDate.toString(), endDate.toString(),
				elapsedTime.toString(), Integer.toString(recsWritten));

		if (failureReason != null) {
			logger.info("processEmployerFulfillmentReportingCommand Failed: " + failureReason);
			throw new BPMException(failureReason);
		}
		
		
		logger.info("@End - Employer Fulfillment Reporting. ");
	}

	/*
	 * This batch process allows for the resending of the Employer Fulfillment Reporting file given the 
	 * group number and date when the transactions of completed activities were generated. 
	 *  	
	 */

	private void resendEmployerFulfillmentReportingtoCSVFileCommand(
				StatusCalculationCommand statusCalculationCommand)
				throws BPMException
		{
			logger.info("@Start - Resend Employer Fulfillment Reporting file. ");
			
			int recsWritten = 0;
			int recsSent = 0;
			
			String failureReason = null;
			String elapsedTime;
			
			java.util.Date startDate = new java.util.Date();
			java.util.Date endDate;
			
			java.sql.Date snapShotEmplTrackDate;
			java.sql.Date startEmplTrackDate;
			
			BPMAuditRecord bpmAuditRecord = new BPMAuditRecord();

			String processName = statusCalculationCommand.getProcessName();
			
			if (statusCalculationCommand.getSnapShotEmplFulfillTrackDate() != null) {
				snapShotEmplTrackDate = BPMUtils.getDateFromStringMMddyyyy(statusCalculationCommand.getSnapShotEmplFulfillTrackDate());
			}else {
				snapShotEmplTrackDate = null;
			}
			if (statusCalculationCommand.getStartEmplFulfillTrackDate() != null) {
				startEmplTrackDate =  BPMUtils.getDateFromStringMMddyyyy(statusCalculationCommand.getStartEmplFulfillTrackDate());
			}else{
				startEmplTrackDate = null;
			}
			
			String groupNo = statusCalculationCommand.getGroupNo();
			
			bpmAuditRecord.setApplicationId(processName);
			bpmAuditRecord.setApplicationEvent("resendEmployerFulfillmentReportingtoCSVFileCommand");
			statusCalculationCommand.setCurrentCommandText("Employer Fulfillment Reporting");

		  try {	
			Collection<EmployerFulfillmentMemberActivity> memberActivityCompletions  = personDAO.getEmployerFulfillmentMemberActivityCompletions(groupNo, snapShotEmplTrackDate, startEmplTrackDate);
			if (memberActivityCompletions.size() > 0) {
				logger.info("@@@@ - Member Activity Completions to send " + memberActivityCompletions.size());
				recsSent = sendEmployerActivityCompletionFile(memberActivityCompletions);
			}
		  } catch (Exception e) {
			failureReason = BPMUtils.getStakTraceAsString(e);
			logger.error(failureReason, e);
		  }  
		
		  endDate = new java.util.Date();
		  elapsedTime = BPMUtils
				.getTimeDifferenceAsString(startDate, endDate);
		  logger.info("@@@@End - Total processing time " + elapsedTime);
		  if (statusCalculationCommand.getSnapShotEmplFulfillTrackDate() != null) {
		     logger.info("@@@@Represents resending of Employer Fulfillment Member Activity completions using snapshot date " + snapShotEmplTrackDate);
		  }
		  if (statusCalculationCommand.getStartEmplFulfillTrackDate() != null) {
		     logger.info("@@@@Represents resending of Employer Fulfillment Member Activity completions using start date " + startEmplTrackDate);
		  }
		  logger.info("@@@@End - Number of Employer Fulfillment Member Activity Completions sent to csv file:  = "
				+ recsSent);	
			
		  
			
				
			StringBuffer batchMailSubject = new StringBuffer();
			batchMailSubject.append("BPM Batch Process Status (Resend Employer Fulfillment Reporting file) ");
			StringBuffer batchMailContent = new StringBuffer();
			
			batchMailContent.append("<tr><td>" + "BPM Batch Name: Resend Employer Fulfillment Reporting" + "<td><tr>");
			
			batchMailContent.append("<tr><td>" + "Initiated User: "
					+ statusCalculationCommand.getUserID());
				
			batchMailContent.append("<tr><td>" + "Time Start: "
		    			+ BPMUtils.getFormattedDateTime(startDate) + "<td><tr>");

			
			batchMailContent.append("<tr><td>" +"Reporting on group " + groupNo + "." + "<td><tr>");
			if (snapShotEmplTrackDate != null) {
				batchMailContent.append("<tr><td>" + "Date used " + statusCalculationCommand.getSnapShotEmplFulfillTrackDate() + "." + "<td><tr>");
			} else if (startEmplTrackDate != null) {
				     batchMailContent.append("<tr><td>" + "Start date used " + statusCalculationCommand.getStartEmplFulfillTrackDate() + "." + "<td><tr>");
			} else {
				batchMailContent.append("<tr><td>" + "No target date specified.  Choices are a snapshot date or start date. " + "<td><tr>");
			}
			
			
			batchMailContent
						.append("<tr><td>" + "Records written to employer completions csv file: " + recsSent + "." + "<td><tr>");

			if (failureReason != null) {
				bpmAuditRecord.setEventResult("FAILED");
				batchMailSubject.append("- FAILED");
				batchMailContent.append("<tr><td>" + "Result: FAILED" + "</td></tr>");
				batchMailContent.append("<tr><td>" + "Reason: \n");
				batchMailContent.append(failureReason + "</td></tr>");
			} else {
				bpmAuditRecord.setEventResult("SUCCESS");
				batchMailSubject.append("- SUCCESS");
				batchMailContent.append("<tr><td>" + "Result: SUCCESS" + "</td></tr>");
			}
			
			
			emailService.setEmailDestination(BPMConstants.EMAIL_DESTINATION_EMPLOYER_FULFILLMENT_RPT);
			emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
			emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
					batchMailContent.toString());
			
			
			
			businessProgramService.writeToAuditLog(statusCalculationCommand, batchMailSubject.toString(), startDate.toString(), endDate.toString(),
					elapsedTime.toString(), Integer.toString(recsWritten));

			if (failureReason != null) {
				logger.info("resendEmployerFulfillmentReportingtoCSVFileCommand Failed: " + failureReason);
				throw new BPMException(failureReason);
			}
			
			
			logger.info("@End - Resend Employer Fulfillment Reporting file. ");
		}
	/*
	 * Determine if today lands on a Wednesday of the 2nd or 4th week. 
	 */
	private String determineTheWeekNDayOfMonthToProcess() {
		
		int processWeekOpt1 = 0;
		int processWeekOpt2 = 0;
		int dayOfWeek = determineDayOfWeekToProcess();
	
		String frequenceCode = BPMConstants.BPM_EMPL_FULFILL_ACT_RPT_FREQ_OFF_WEEK;
		try {
			LookUpValueCode weekToprocess1 = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.BPM_EMPL_FULFILL_CTRL_WEEKOFMONTH, BPMConstants.BPM_EMPL_FULFILL_WEEK_CTRL1);
			processWeekOpt1 = Integer.parseInt(weekToprocess1.getLuvDesc());
		
			LookUpValueCode weekToprocess2 = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.BPM_EMPL_FULFILL_CTRL_WEEKOFMONTH, BPMConstants.BPM_EMPL_FULFILL_WEEK_CTRL2);
			processWeekOpt2 = Integer.parseInt(weekToprocess2.getLuvDesc());
			
		} catch (Exception ex) {
			logger.error("Error performing lookup of LookUpValue id on " +  BPMConstants.BPM_EMPL_FULFILL_CTRL_WEEKOFMONTH);
			ex.printStackTrace();
		}
		
		logger.info("ProgramStatusCalculationImpl.determineTheWeekNDayOfMonthToProcess: week to process opt1 " + processWeekOpt1 + " day of week " + dayOfWeek);
		java.util.Date secondWednesdayDate = 
			BPMUtils.getNthXdayInMonth(new java.util.Date(), processWeekOpt1, dayOfWeek);
		secondWednesdayDate = (java.util.Date) DateUtils.truncate(secondWednesdayDate, Calendar.DATE);
		
		Calendar todaysDate = Calendar.getInstance();
		java.util.Date truncTodaysDate = (java.util.Date) DateUtils.truncate(todaysDate.getTime(), Calendar.DATE);
        
		logger.info("ProgramStatusCalculationImpl.determineTheWeekNDayOfMonthToProcess: week to process opt2 " + processWeekOpt2 + " day of week " + dayOfWeek);
		java.util.Date fourthWednesdayDate = 
			 BPMUtils.getNthXdayInMonth(new java.util.Date(), processWeekOpt2, dayOfWeek);
		fourthWednesdayDate = (java.util.Date) DateUtils.truncate(fourthWednesdayDate, Calendar.DATE);
		
		logger.info("ProgramStatusCalculationImpl.determineTheWeekNDayOfMonthToProcess:  secondWednesdayDate " + secondWednesdayDate.toString());
		logger.info("ProgramStatusCalculationImpl.determineTheWeekNDayOfMonthToProcess:  fourthWednesdayDate " + fourthWednesdayDate.toString());
		
		if (secondWednesdayDate.equals(truncTodaysDate)) {
			frequenceCode = BPMConstants.BPM_EMPL_FULFILL_ACT_RPT_FREQ_WEDNESDAY_WEEK2;
		} else if (fourthWednesdayDate.equals(truncTodaysDate)) {
			frequenceCode = BPMConstants.BPM_EMPL_FULFILL_ACT_RPT_FREQ_WEDNESDAY_WEEK4;
		} 
		
		logger.info("ProgramStatusCalculationImpl.determineTheWeekNDayOfMonthToProcess:  frequenceCode " + frequenceCode);
		
		return frequenceCode;
	}
	/*
	 * Retrieve day of week to send activtiy completions for group.
	 */
	private int determineDayOfWeekToProcess() {
		int day = 0;
		LookUpValueCode dayOfWeekCode = null;
		
		try {
			dayOfWeekCode = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.BPM_EMPL_FULFILL_DAY_OF_WEEK_GROUPING, BPMConstants.BPM_EMPL_FULFILL_DAY_OF_WEEK);
			logger.info("Day of week set in LUV table to determine when to send activity completions: " + dayOfWeekCode.getLuvDesc());
			if (dayOfWeekCode.getLuvDesc().equals(BPMConstants.SUNDAY)) {
				return Calendar.SUNDAY;
			} else if (dayOfWeekCode.getLuvDesc().equals(BPMConstants.MONDAY)) {
						return Calendar.MONDAY;
			} else if (dayOfWeekCode.getLuvDesc().equals(BPMConstants.TUESDAY)) {
				return Calendar.TUESDAY;
			} else if (dayOfWeekCode.getLuvDesc().equals(BPMConstants.WEDNESDAY)) {
				return Calendar.WEDNESDAY;
			} else if (dayOfWeekCode.getLuvDesc().equals(BPMConstants.THURSDAY)) {
				return Calendar.THURSDAY;
			} else if (dayOfWeekCode.getLuvDesc().equals(BPMConstants.FRIDAY)) {
				return Calendar.FRIDAY;
			} else if (dayOfWeekCode.getLuvDesc().equals(BPMConstants.SATURDAY)) {
				return Calendar.SATURDAY;
			} 
		} catch (Exception ex) {
			logger.error("Error performing lookup of LookUpValue id on " +  BPMConstants.BPM_EMPL_FULFILL_DAY_OF_WEEK_GROUPING);
			ex.printStackTrace();
		}
		return day;
	}

    /*
     * Setup object GenerateEmplTrackingCsv to generate the csv file of activity completions by participating member(employee) that gets sent to employer.
     */
	private int	sendEmployerActivityCompletionFile(Collection<EmployerFulfillmentMemberActivity> memberActivityCompletions) throws BPMException {
		   int recsWritten = 0;
		   GenerateEmplTrackingCsv pGenerateEmplTrackingCsv = new GenerateEmplTrackingCsv();
		   try {
			   LookUpValueCode lookUpValueCode = getLUVCodeByGroupSingle(BPMConstants.BPM_EMPL_FULFILL_CSV_PATH_ALLINA);
			   String filePath = lookUpValueCode.getLuvDesc();
			   
			   recsWritten = pGenerateEmplTrackingCsv.generateCsvFile(memberActivityCompletions, filePath);
			   FTPFile ftpFile = new FTPFile();
			   //String ftpDir = "/Allina_FTP/";
			   String inputDir = "output_bpm/";
			   String processedDir = "processed_output_bpm/";
			   
			   lookUpValueCode = getLUVCodeByGroupNValue(BPMConstants.BPM_FTP_HOST_SRVR, BPMConstants.WINFTP_DOMAIN);
			   String serverDomain = lookUpValueCode.getLuvDesc();
			   lookUpValueCode = getLUVCodeByGroupNValue(BPMConstants.BPM_FTP_HOST_SRVR, BPMConstants.WINFTP_ALLINA_DIR);
			   String ftpDir = lookUpValueCode.getLuvDesc();
			   lookUpValueCode = getLUVCodeByGroupNValue(BPMConstants.BPM_FTP_HOST_SRVR, BPMConstants.WINFTP_ACT);
			   String serverAccount = lookUpValueCode.getLuvDesc();
			   lookUpValueCode = getLUVCodeByGroupNValue(BPMConstants.BPM_FTP_HOST_SRVR, BPMConstants.WINFTP_PW);
			   String serverPassword = lookUpValueCode.getLuvDesc();
			   
			 //See Apache FTPClient java doc for definition on enterRemotePassiveMode.
			   boolean enterPassiveMode = false;
			   
			   ftpFile = setupFTPProcess(serverDomain, enterPassiveMode, serverAccount, serverPassword, ftpFile, ftpDir, inputDir, processedDir);
	
			   ftpFile.sendFTPFile();
		   } catch (BPMException e) {
				String failureReason = BPMUtils.getStakTraceAsString(e);
				logger.debug(failureReason, e);
				throw e;
		   } catch (Exception e) {
				String failureReason = BPMUtils.getStakTraceAsString(e);
				logger.debug(failureReason, e);
				throw new BPMException(failureReason, e);
		   } 
		   
		   
		   
		   return recsWritten;
	
	}
	
	 /*
     * Handles FTP'ing of HRA Contribution file
     */
	private int	sendCDHPHraContributionFile(Collection<CDHPFulfillmentTrackingReport> lCDHPHRAFulfillmentTrackingReport) throws BPMException {
		   int recsWritten = 0;
		  
		   try {
			   LookUpValueCode lookUpValueCode = getLUVCodeByGroupSingle(BPMConstants.BPM_CDHP_FULFILL_ASCII_PATH_HRA);
			   String filePath = lookUpValueCode.getLuvDesc();
			   logger.info("sendCDHPContributionFile file path is " + filePath);
			   ArrayList<LookUpValueCode> lCDHPEnvironments = (ArrayList<LookUpValueCode>)lookUpValueDAO.getLUVCodesByGroup(BPMConstants.CDHP_TRANS_ENV);
				//Should always be one record returned.
				String lCDHPEnvIdentifier = lCDHPEnvironments.get(0).getLuvVal();
				
			  logger.info("sendCDHPContributionFile lCDHPEnvIdentifier is " + lCDHPEnvIdentifier);
				
			   
			   OutboundFileProcessing lOutboundFileProcessing = new OutboundFileProcessing();
			   recsWritten = lOutboundFileProcessing.generateCDHPHRAFile(lCDHPHRAFulfillmentTrackingReport, filePath, lCDHPEnvIdentifier);
			   
			   logger.info("sendCDHPContributionFile lOutboundFileProcessing.generateCDHPHRAFile count is " + recsWritten);
			   
			   FTPFile ftpFile = new FTPFile();
			   String inputDir = "output_bpm_hra/";
			   String processedDir = "processed_output_bpm_hra/";
			   
			   lookUpValueCode = getLUVCodeByGroupNValue(BPMConstants.BPM_FTP_HOST_SRVR, BPMConstants.EDI_DIR);
			   String ftpDir = lookUpValueCode.getLuvDesc();
			   lookUpValueCode = getLUVCodeByGroupNValue(BPMConstants.BPM_FTP_HOST_SRVR, BPMConstants.EDI_DOMAIN);
			   String serverDomain = lookUpValueCode.getLuvDesc();
			   lookUpValueCode = getLUVCodeByGroupNValue(BPMConstants.BPM_FTP_HOST_SRVR, BPMConstants.EDI_ACT);
			   String serverAccount = lookUpValueCode.getLuvDesc();
			   lookUpValueCode = getLUVCodeByGroupNValue(BPMConstants.BPM_FTP_HOST_SRVR, BPMConstants.EDI_PW);
			   String serverPassword = lookUpValueCode.getLuvDesc();
			   
			 //See Apache FTPClient java doc for definition on enterRemotePassiveMode.
			   boolean enterPassiveMode = true;
			   
			   ftpFile = setupFTPProcess(serverDomain, enterPassiveMode, serverAccount, serverPassword, ftpFile, ftpDir, inputDir, processedDir);
			  
			   ftpFile.sendFTPFile();
		   } catch (Exception e) {
				String failureReason = BPMUtils.getStakTraceAsString(e);
				logger.debug(failureReason, e);
				throw new BPMException(failureReason, e);
		   } 
		   
		   
		   
		   return recsWritten;
	
	}
	
	/*
     * Generate CDHP HSA transaction csv file and FTP to external filer server. 
     */
	private int	generatCSVNFTPCDHPHsaContributionFile(Collection<CDHPFulfillmentTrackingReport> lCDHPHSAFulfillmentTrackingReport, CDHPControlGroup lCDHPControlGroup) throws BPMException {
		   int recsWritten = 0;
		   
		   try {
			   
			   logger.info("sendCDHPContributionFile input file directory and file name is " + lCDHPControlGroup.getOutputFilePath());
			  
			   ArrayList<LookUpValueCode> lCDHPEnvironments = (ArrayList<LookUpValueCode>)lookUpValueDAO.getLUVCodesByGroup(BPMConstants.CDHP_TRANS_ENV);
				//Should always be one record returned.
				String lCDHPEnvIdentifier = lCDHPEnvironments.get(0).getLuvVal();
				
			   
			   OutboundFileProcessing lOutboundFileProcessing = new OutboundFileProcessing();
			   recsWritten = lOutboundFileProcessing.generateCDHPHSAFile(lCDHPHSAFulfillmentTrackingReport, lCDHPControlGroup, lCDHPEnvIdentifier);
			   
			   logger.info("sendCDHPContributionFile lOutboundFileProcessing.generateCDHPHRAFile count is " + recsWritten);
			   
			   FTPFile ftpFile = new FTPFile();
			   
			   LookUpValueCode lookUpValueCode = getLUVCodeByGroupNValue(BPMConstants.BPM_FTP_HOST_SRVR, BPMConstants.WINFTP_DOMAIN);
			   String serverDomain = lookUpValueCode.getLuvDesc();
			   lookUpValueCode = getLUVCodeByGroupNValue(BPMConstants.BPM_FTP_HOST_SRVR, BPMConstants.WINFTP_ACT);
			   String serverAccount = lookUpValueCode.getLuvDesc();
			   lookUpValueCode = getLUVCodeByGroupNValue(BPMConstants.BPM_FTP_HOST_SRVR, BPMConstants.WINFTP_PW);
			   String serverPassword = lookUpValueCode.getLuvDesc();
			   
			   //Not required to set passive mode to true when using winftp server.
			   boolean enterPassiveMode = false;
			   
			   String extFileServerPath = lCDHPControlGroup.getOutputExternalFileServerDirectoryPath();
			   logger.info("sendCDHPContributionFile external file server file path is " + extFileServerPath);
			   
			   ftpFile = setupFTPProcess(serverDomain, enterPassiveMode, serverAccount, serverPassword, ftpFile, extFileServerPath, lCDHPControlGroup.getOutputFilePath(), lCDHPControlGroup.getProcessedOutputFilePath());
			  
			   ftpFile.sendFTPFile();
		   } catch (Exception e) {
				String failureReason = BPMUtils.getStakTraceAsString(e);
				logger.error(failureReason, e);
				throw new BPMException(failureReason, e);
		   } 
		   
		   
		   
		   return recsWritten;
	
	}
	
	
	
	private FTPFile setupFTPProcess(String serverDomain, boolean enterPassiveMode, String serverAccount, String serverPassword, FTPFile ftpFile, String ftpDir, String inputDir, String processedDir) {
		
		ftpFile.setFtpServerDomain(serverDomain);
		ftpFile.setUser(serverAccount);
		ftpFile.setPassword(serverPassword);
		ftpFile.setInputDir(inputDir);
		ftpFile.setProcessedDir(processedDir);
		ftpFile.setOutputFTPDir(ftpDir);
		//ftpFile.setEnterRemotePassiveMode(enterRemotePassiveMode);
		ftpFile.setEnterLocalPassiveMode(enterPassiveMode);
		
		return ftpFile;
	}
	
    private int updateMemberProgramStatusContractStatusDate(ArrayList<PersonContractHist> lPersonContractHist) {
    	Iterator<PersonContractHist> iter = (Iterator<PersonContractHist>)lPersonContractHist.iterator();
    	int recsWritten = 0;
    	while (iter.hasNext()) {
    		PersonContractHist personContractHist = (PersonContractHist)iter.next();
    		
    		try {
    			//set person program status to today's date
				personDAO.updateMemberProgramStatusContractStatusDate(personContractHist.getPersonDemographicsID(), personContractHist.getProgramID());
				recsWritten++;
			} catch (DataAccessException e) {
				logger.info("@ProgramStatusCalculationServiceImpl.updateMemberProgramStatusContractStatusDate: DataAccessException error. ");
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NumberFormatException e) {
				logger.info("@ProgramStatusCalculationServiceImpl.updateMemberProgramStatusContractStatusDate: NumberFormatException error. ");
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
    	}
    	
    	return recsWritten;
    
    }
        
	
	public Collection<PersonProgramStage> membershipFeedTollgate(Collection<PersonProgramStage> personProgramsStage) throws BPMException {
		PersonProgramStage personProgramStage = null;	
		Collection<PersonProgramStage> bypassRecycledPersonContracts = new ArrayList<PersonProgramStage>();
		Iterator<PersonProgramStage> iter = personProgramsStage.iterator();
		int newPersonContractsCount = 0;
		while (iter.hasNext()) {
			personProgramStage = iter.next();
			try {
				
				// Determine if history record exists.
				Integer pContractNumber = personProgramStage.getContractNumber();
				Integer pProgramId = personProgramStage.getProgramID();
				Integer pPersonDemographicsID = personProgramStage.getPersonDemographicsID();
				Integer pProgramIncentiveOptionID = personProgramStage.getProgramIncentiveOptionID();
				PersonContractHist personContractHist = personDAO.getPersonContractHistForPersonContractMax(pPersonDemographicsID, pContractNumber, pProgramId, pProgramIncentiveOptionID);
				
				//Force contract status recalc if participation end date exists and BPM contract status and person contract history are different.
				determineParticipationEndDateForContractStatusRecalc(personProgramStage, personContractHist);
				
				//Check to see if person contract is in recycle table.
				PersonContractRecycle personContractRecycle = null;
				if (personContractHist != null) {
					personContractRecycle = personDAO.getPersonContractRecycleForPersonContract(pContractNumber, pPersonDemographicsID, pProgramId, null);
				}
				if (personContractRecycle != null) {
					if (isRecycleStatusReleased(personContractRecycle)) {
						//Check to see if contract status current and history are the same.  If NOT then send through tollgate rules evaulation.
						if (!personProgramStage.getContractStatus().equals(personContractHist.getContractStatus())) {
							bypassRecycledPersonContracts = evaluateTollgateRules(personProgramStage, personContractHist, bypassRecycledPersonContracts);
						}
					} else if (isRecycleStatusOnHoldNNowQualified(personContractRecycle, personProgramStage.getContractStatus())) {						
								LookUpValueCode lookUpValueCode = getLUVCodeByGroupNValue(BPMConstants.BPM_RECYCLE_STATUS, BPMConstants.PERSON_CONTRACT_RECYCLE_STATUS_RELEASED);
								personContractRecycle.setRecycleStatusId(lookUpValueCode.getLuvId());
								personContractRecycle.setApproverUserId("BPM");
								personContractRecycle.setReasonDesc("Person Contract is now QUALIFIED.  Status changed from ON HOLD to RELEASED.");
								personDAO.updatePersonContractRecycleStatusWithReasonDesc(personContractRecycle);
								recycleRecordsOnHoldToReleased++;
					} else if (isRecycleStatusApproved(personContractRecycle)) {
						
								// update person program status date to today's date to be picked up in next day's run of
								// membership.
								
								//personDAO.updateMemberProgramStatusContractStatusDate(personContractRecycle.getPersonNumber(), personContractRecycle.getProgramId());
								
								LookUpValueCode lookUpValueCode = getLUVCodeByGroupNValue(BPMConstants.BPM_RECYCLE_STATUS, BPMConstants.PERSON_CONTRACT_RECYCLE_STATUS_RELEASED);
								personContractRecycle.setRecycleStatusId(lookUpValueCode.getLuvId());
								personDAO.updatePersonContractRecycleStatus(personContractRecycle);
								recycleRecordsApprovedToReleased++;				
					} else if (isRecycleStatusDeniedNNowQualified(personContractRecycle, personProgramStage.getContractStatus())) {
								//Place person contract back "ON HOLD" to be reviewed. 
								PersonContractRecycle newPersonProgramRecycle = buildPersonProgramRecycle(personProgramStage, personContractRecycle.getContractStatusCurrent());
								newPersonProgramRecycle.setReasonDesc("Person Contract is now QUALIFIED From DENIED.  Placed back ON HOLD.");
								personDAO.insertPersonContractRecycle(newPersonProgramRecycle); 
								bypassRecycledPersonContracts.add(personProgramStage);
								recycleRecordsDeniedNNowQaulified++;
					} else {
						bypassRecycledPersonContracts.add(personProgramStage);
					}
				} else { 
					if (personContractHist != null) {
						bypassRecycledPersonContracts = evaluateTollgateRules(personProgramStage, personContractHist, bypassRecycledPersonContracts);
					} else {
						newPersonContractsCount++;
					}
				}
			
			} catch (BPMException e) {
				Integer pContractNumber = personProgramStage.getContractNumber();
				Integer pProgramId = personProgramStage.getProgramID();
				Integer pPersonDemographicsID = personProgramStage.getPersonDemographicsID();
				logger.error("Contract number " + pContractNumber);
				logger.error("program id " + pProgramId);
				logger.error("pPersonDemographicsID " + pPersonDemographicsID);
				
				logger.error("An unexpected error accessing program history table: " + e.getMessage(),
						e);
				throw new BPMException(e.getMessage(), e);
			} catch (Exception ex) {
				Integer pContractNumber = personProgramStage.getContractNumber();
				Integer pProgramId = personProgramStage.getProgramID();
				Integer pPersonDemographicsID = personProgramStage.getPersonDemographicsID();
				logger.error("Contract number " + pContractNumber);
				logger.error("program id " + pProgramId);
				logger.error("pPersonDemographicsID " + pPersonDemographicsID);
				logger.error("An unexpected error accessing program history table: " + ex.getMessage(),
						ex);
				throw new BPMException(ex.getMessage(), ex);
			
			}  
				
		}
		logger
		.info("membershipFeedTollgate(), New person contracts to person contract history count " + newPersonContractsCount);
		//Remove person contracts that meet tollgate criteria from membership feed person contract collection.
		if (bypassRecycledPersonContracts.size() > 0) {
			PersonProgramStage personContractToRemove = null;
			Iterator<PersonProgramStage> iterRemove = bypassRecycledPersonContracts.iterator();
			while (iterRemove.hasNext()) {
				personContractToRemove = iterRemove.next();
				personProgramsStage.remove(personContractToRemove);
			}	
		}
		Collection<PersonContractHist> personContractsHist = buildPersonContractsHist(personProgramsStage);
		memberService.insertPersonContractHist(personContractsHist);
	
		return personProgramsStage;
	}
	/*
	 * Read for person contract history and perform Qualified tollgate check (Business Rule's 1, 2, and 3).
	 */
	Collection<PersonProgramStage> evaluateTollgateRules(PersonProgramStage personProgramStage, PersonContractHist personContractHist, Collection<PersonProgramStage> bypassRecycledPersonContracts) throws BPMException {
		// Tollgate rule 1 - Status still ELIGIBLE after qualification period.
		if (isContractStatusEligibleAfterQaulPeriod(personProgramStage)) {
			//write personProgramStage to recycle table as "on hold".
			PersonContractRecycle newPersonProgramRecycle = buildPersonProgramRecycle(personProgramStage, personContractHist.getContractStatus());
			newPersonProgramRecycle.setReasonDesc(BPMConstants.PERSON_CONTRACT_HIST_RECYCLE_TOLLGATE_RULE_1);
			personDAO.insertPersonContractRecycle(newPersonProgramRecycle);
			
			//remove from personProgramsStagecreatePersonContractOnHoldReport
			bypassRecycledPersonContracts.add(personProgramStage);
			recycleRecordsOnHoldR3++;
			// Tollgate rule 2 - Status changed from QUALIFY to DID_NOT_QUALIFY..
		}else if (isContractStatusChangingFromQToDNQ(personProgramStage, personContractHist)) {
				//write personProgramStage to recycle table as "on hold".
				PersonContractRecycle newPersonProgramRecycle = buildPersonProgramRecycle(personProgramStage, personContractHist.getContractStatus());
				newPersonProgramRecycle.setReasonDesc(BPMConstants.PERSON_CONTRACT_HIST_RECYCLE_TOLLGATE_RULE_2);
				personDAO.insertPersonContractRecycle(newPersonProgramRecycle);

				//remove from personProgramsStage
				bypassRecycledPersonContracts.add(personProgramStage);
				recycleRecordsOnHoldR1++;
				
				// Tollgate rule 3 - Contract status changing from Did Not Qualified to Qualified in benefit year with
				//                   no exemption granted.
			}   else if (isContractStatusChangingFromDNQToQWithNoExemption(personProgramStage, personContractHist)) {
								
					//write personProgramStage to recycle table as "on hold".
					PersonContractRecycle newPersonProgramRecycle = buildPersonProgramRecycle(personProgramStage, personContractHist.getContractStatus());
					newPersonProgramRecycle.setReasonDesc(BPMConstants.PERSON_CONTRACT_HIST_RECYCLE_TOLLGATE_RULE_3);
					personDAO.insertPersonContractRecycle(newPersonProgramRecycle);
					
					//remove from personProgramsStage
					bypassRecycledPersonContracts.add(personProgramStage);
					recycleRecordsOnHoldR2++;
				
			} 
			
		
		return bypassRecycledPersonContracts;
	}
	
	
	
	/*
	 * Force contract status recalc if participation end date exists and BPM contract status and person contract history are different.
	 * Removing the participation date temporarily for performing a member recalc of the member contract status
	 * will allow the status to change.  If participation date is present, the contract status remains frozen.
	 * If todays date is greater or equal to contract end date, then do not consider performing a member status recalc even if bpm status's do not match to person contract history.
	 * Once the Contract end date is met, no status changes are allowed.
	 * The end result of this will prevent member contracts from being written to the recylce table when contract status's between BPM and person contract history
	 * are out of sync.
	 */
	private void determineParticipationEndDateForContractStatusRecalc(PersonProgramStage personProgramStage, PersonContractHist personContractHist) throws BPMException {
		BPMBusinessProgram businessProgram = businessProgramDAO.getBusinessProgramDetail(personProgramStage.getProgramID());
		
		Integer personDemographicsID = personProgramStage.getPersonDemographicsID();
		
		MemberProgramUpdateTO personProgramStatus = personDAO.getMemberProgramStatusDetail(personDemographicsID, businessProgram.getProgramID());
		if (businessProgram.getStatusCalcEndDate() == null || Calendar.getInstance().before(businessProgram.getStatusCalcEndDate())) { 
		    if	(personProgramStatus.getParticipationEndDate() != null && personContractHist != null) {
				if (!personProgramStage.getContractStatus().equals(personContractHist.getContractStatus())) {
					//temporarily remove participation end date from person program status record.
					personDAO.updateMemberProgramStatusPartEndDate(personProgramStage.getPersonDemographicsID(), personProgramStage.getProgramID(), null);
					//recalc contract status 
					StatusCalculationCommand statusCalculationCommand = new StatusCalculationCommand();
					statusCalculationCommand.setMembersReCalculationCommand();
					statusCalculationCommand
							.setProcessIDForMembersReCalculationCommand(BPMConstants.MEMBERS_RECALCULATION_PRCS_ID);
					statusCalculationCommand
							.setCurrentProcessingCommand(StatusCalculationCommand.MEMBERS_RECALCULATION);
					try {
						processMemberReCalculation(personDemographicsID, statusCalculationCommand);
					} catch (DataAccessException de) {
						logger.error("Error attempting to perform a member recalculation.  " +
								"DataAcessException is ", de);
					} catch (BPMException be) {
						logger.error("Error attempting to perform a member recalculation.  BPMException is ", be);
					} catch (Exception e) {
						logger.error("Error attempting to perform a member recalculation.  Exception is ", e);
					} finally {
						//add participation end date back into person program status record.
						java.sql.Date participationEndDate = BPMUtils.calendarToSqlDate(personProgramStatus.getParticipationEndDate());
						personDAO.updateMemberProgramStatusPartEndDate(personProgramStage.getPersonDemographicsID(), personProgramStage.getProgramID(), participationEndDate);
					}
				}
			}
		}
	}
	
	private PersonContractRecycle buildPersonProgramRecycle(PersonProgramStage personProgramStage, String prevContractStatus) throws BPMException {
		PersonContractRecycle personProgramRecycle = new PersonContractRecycle();
		LookUpValueCode lookUpValueCode = new LookUpValueCode();
		
		//personProgramRecycle.setApproverUserId(BPMConstants.BPM_USER_SYSTEM);
		personProgramRecycle.setContractNumber(personProgramStage.getContractNumber());
		lookUpValueCode = getLUVCodeByGroupNValue(BPMConstants.BPM_CONTRACT_STATUS, personProgramStage.getContractStatus());
		personProgramRecycle.setContractStatusCurrentId(lookUpValueCode.getLuvId());
		lookUpValueCode = getLUVCodeByGroupNValue(BPMConstants.BPM_CONTRACT_STATUS, prevContractStatus);
		personProgramRecycle.setContractStatusPrevId(lookUpValueCode.getLuvId());
		personProgramRecycle.setInsertUser(BPMConstants.BPM_USER_SYSTEM);
		
		lookUpValueCode = getLUVCodeByGroupNValue(BPMConstants.BPM_RECYCLE_STATUS, BPMConstants.PERSON_CONTRACT_RECYCLE_STATUS_ON_HOLD);
		personProgramRecycle.setRecycleStatusId(lookUpValueCode.getLuvId());
		//personProgramRecycle.setReasonDesc(BPMConstants.PERSON_CONTRACT_RECYCLE_STATUS_ON_HOLD);
		
		personProgramRecycle.setPersonNumber(personProgramStage.getPersonNumber());
		personProgramRecycle.setPersonDemographicsID(personProgramStage.getPersonDemographicsID());
		personProgramRecycle.setProgramId(personProgramStage.getProgramID());
		
		return personProgramRecycle;
		
	}
	
	
	
	
	private Collection<PersonContractHist> buildPersonContractsHist(Collection<PersonProgramStage> personProgramsStage) throws BPMException {
		Iterator<PersonProgramStage> iter = personProgramsStage.iterator();
		Collection<PersonContractHist> personContractsHist = new ArrayList<PersonContractHist>();
		PersonProgramStage personProgramStage = null;
		while (iter.hasNext()) {
			PersonContractHist personContractHist = new PersonContractHist();
			personProgramStage = (PersonProgramStage)iter.next();
			personContractHist.setContractNumber(personProgramStage.getContractNumber());
			personContractHist.setContractStatus(personProgramStage.getContractStatus());
			personContractHist.setGroupID(personProgramStage.getGroupNumber());
			personContractHist.setMemberStatus(personProgramStage.getMemberStatus());
			personContractHist.setPersonNumber(personProgramStage.getPersonNumber());
			personContractHist.setPersonDemographicsID(personProgramStage.getPersonDemographicsID());
			personContractHist.setProgramID(personProgramStage.getProgramID());
			personContractHist.setBusinessProgramIncentiveOptionID(personProgramStage.getProgramIncentiveOptionID());
			personContractHist.setProgramTypeCode(String.valueOf(personProgramStage.getProgramTypeCode()));
			personContractHist.setQualificationStartDate(personProgramStage.getQualificationStartDate());
			personContractHist.setQualificationEndDate(personProgramStage.getQualificationEndDate());
			personContractHist.setProgramStartDate(personProgramStage.getProgramStartDate());
			personContractHist.setProgramEndDate(personProgramStage.getProgramEndDate());
			personContractHist.setSiteID(personProgramStage.getSiteNumber());
			personContractHist.setContractStatusDate(personProgramStage.getStatusDate());
			personContractHist.setActivationStatusCode(personProgramStage.getActivationStatusCode());
			
			personContractsHist.add(personContractHist);
		}
		return personContractsHist;
		
	}
	/*
	 * This method responsible for getting all ON HOLD person contracts from recycle table, determining if
	 * current status is qualified, and if true, updating person program status record to today's date triggering
	 * person contract to come over in membership feed.
	 */
	private int determineIfQualfiedForRemainingOnHolds() {
		
		int changedToQualifedCount = 0;
		
		//Read person contract recycle table for ON HOLD's.  Return collection.
		Collection<PersonContractRecycle> personContractRecycleOnHolds = personDAO.getPersonContractRecycleOnHolds();
		
		// If collection not zero, process collection.
		if (personContractRecycleOnHolds.size() > 0) {
			Iterator<PersonContractRecycle> iter = (Iterator<PersonContractRecycle>)personContractRecycleOnHolds.iterator();
			while (iter.hasNext()) {
				PersonContractRecycle personContractRecycle = (PersonContractRecycle) iter.next();
				//read contract program status
				MemberProgramUpdateTO memberContract = 
						contractDAO.getMemberContractStatus(personContractRecycle.getContractNumber(), personContractRecycle.getPersonNumber(), personContractRecycle.getProgramId());
				if (memberContract == null) {
					logger.error("ProgramStatusCalculationServiceImpl.membershipFeedTollgate.determineIfQualfiedForRemainingOnHoldsError: MemberContract object is null.");
					logger.error("Contract record missing from Contract_Program_Status table.  Keys to record follow:");
					logger.error("Contract number is " + personContractRecycle.getContractNumber());
					logger.error("Person number is   " + personContractRecycle.getPersonNumber());
					logger.error("Person Demogr ID   " + personContractRecycle.getPersonDemographicsID());
					logger.error("Bus program id is  " + personContractRecycle.getProgramId());
					
				} else if (memberContract.getStatusCodeValue().equals(BPMConstants.MEMBER_STATUS_QUALIFIED)) {
						  java.sql.Date progEndDate = personContractRecycle.getProgramEndDate();
					      if (progEndDate.before(new java.util.Date())) { 
					    	//Bus program end date before current date.
					    	//Recycle record needs to remain ON HOLD for further review.
					    	//Concern is contract went to Q after program year.  Further investigation
					    	//might reveal that person contract needs to remain with a contract of DNQ in
					    	//the benefit year.
					      } else {
								//set person program status to today's date
								personDAO.updateMemberProgramStatusContractStatusDate(personContractRecycle.getPersonNumber(), personContractRecycle.getProgramId());
								changedToQualifedCount++;
					      }
				}
			}
		}
		
		return changedToQualifedCount;
	}
	
	
	private Collection<PersonActivityAchievedContribution> processCDHPTollgateRules(Collection<PersonActivityAchievedContribution> cdhpParticipantCompletions) throws BPMException {
		PersonActivityAchievedContribution lPersonActivityAchievedContribution = null;	
		Collection<PersonActivityAchievedContribution> bypassRecycledCDHPParticipantCompletions = new ArrayList<PersonActivityAchievedContribution>();
		Iterator<PersonActivityAchievedContribution> iter = cdhpParticipantCompletions.iterator();
		
		while (iter.hasNext()) {
			lPersonActivityAchievedContribution = iter.next();
			try {
				
				//Check to see if person contract is in recycle table.
			    
				Integer pProgramID = lPersonActivityAchievedContribution.getProgramID();
				Integer pPersonDemographicsID= lPersonActivityAchievedContribution.getPersonDemographicsID();
				Integer pActivityID = lPersonActivityAchievedContribution.getActivityID();
				
				CDHPFulfillmentTrackingRecycle lCDHPFulfillmentTrackingRecycle = personDAO.getCDHPFulfillRecycleForPerson(pProgramID, pPersonDemographicsID, pActivityID);
				
				boolean isOnHoldORDenied = false;
				if (lCDHPFulfillmentTrackingRecycle != null) {
					if (isCDHPRecycleStatusReleased(lCDHPFulfillmentTrackingRecycle)) {
						//allow CDHP person contribution transaction to be sent.
					
					} else if (isCDHPRecycleStatusApproved(lCDHPFulfillmentTrackingRecycle)) {
								
								LookUpValueCode lookUpValueCode = getLUVCodeByGroupNValue(BPMConstants.BPM_CDHP_RECYCLE_STATUS, BPMConstants.CDHP_RECYCLE_STATUS_RELEASED);
								lCDHPFulfillmentTrackingRecycle.setRecycleStatusId(lookUpValueCode.getLuvId());
								personDAO.updateCDHPFulfillRecycleStatus(lCDHPFulfillmentTrackingRecycle);
								recycleRecordsApprovedToReleased++;				
					
					} else {
						//indicates that recycle record is either ON HOLD or DENIED so do not allow contribution transaction
						//to be sent.
						bypassRecycledCDHPParticipantCompletions.add(lPersonActivityAchievedContribution);
						isOnHoldORDenied = true;
					}
				} 
				//EV73098	
				if (!isOnHoldORDenied) {
					bypassRecycledCDHPParticipantCompletions = evaluateCDHPTollgateRules(lPersonActivityAchievedContribution, bypassRecycledCDHPParticipantCompletions);
				}
					
				
			} catch (BPMException e) {
				
				logger.error("An unexpected error accessing program history table: " + e.getMessage(),
						e);
				throw new BPMException(e.getMessage(), e);
			}  
				
		}
		
		//Remove CDHP Participant Completion records that have been flagged by tollgate rules.
		if (bypassRecycledCDHPParticipantCompletions.size() > 0) {
			PersonActivityAchievedContribution cdhpFulfillRecycleRecToRemove = null;
			Iterator<PersonActivityAchievedContribution> iterRemove = bypassRecycledCDHPParticipantCompletions.iterator();
			while (iterRemove.hasNext()) {
				cdhpFulfillRecycleRecToRemove = iterRemove.next();
				cdhpParticipantCompletions.remove(cdhpFulfillRecycleRecToRemove);
			}	
		}
	
		return cdhpParticipantCompletions;
	}
	
	
	/*
	 * Evaluate CDHP Fulfillment HRA/HSA business rules to determine if transaction to be written to recycle table.
	 */
	
	private Collection<PersonActivityAchievedContribution> evaluateCDHPTollgateRules(PersonActivityAchievedContribution lPersonActivityAchievedContribution, Collection<PersonActivityAchievedContribution> bypassRecycledCDHPParticipantCompletions) throws BPMException {
		
		CDHPFulfillmentTrackingRecycle newCDHPFulfillmentTrackingRecycle = null;
		
		// Tollgate rule 1 - Validate that if the same activity was taken by the member across different contracts or packages
		// within the same program year, they can't get another contribution.
		if (didPersonCompleteActivityNAchieveContribution(lPersonActivityAchievedContribution)) {
			
			newCDHPFulfillmentTrackingRecycle = buildCDHPFulfillmentRecycle(lPersonActivityAchievedContribution);
			newCDHPFulfillmentTrackingRecycle.setReasonTollgateRule(BPMConstants.CDHP_RECYCLE_TOLLGATE_RULE_1);
			personDAO.insertCDHPFulfillmentRecycle(newCDHPFulfillmentTrackingRecycle);
			bypassRecycledCDHPParticipantCompletions.add(lPersonActivityAchievedContribution);
			recycleRecordsOnHoldR1++;
			// Tollgate rule 2 - Person contribution exceed participant cap.
		}else if (isParticipantCapExceeded(lPersonActivityAchievedContribution)) {
				
				newCDHPFulfillmentTrackingRecycle = buildCDHPFulfillmentRecycle(lPersonActivityAchievedContribution);
				newCDHPFulfillmentTrackingRecycle.setReasonTollgateRule(BPMConstants.CDHP_RECYCLE_TOLLGATE_RULE_2);
				personDAO.insertCDHPFulfillmentRecycle(newCDHPFulfillmentTrackingRecycle);
				bypassRecycledCDHPParticipantCompletions.add(lPersonActivityAchievedContribution);
				recycleRecordsOnHoldR2++;
				
				// Tollgate rule 3 - Person contribution exceed family cap.
		}   else if (isFamilyCapExceeded(lPersonActivityAchievedContribution)) {
								
					newCDHPFulfillmentTrackingRecycle = buildCDHPFulfillmentRecycle(lPersonActivityAchievedContribution);
					newCDHPFulfillmentTrackingRecycle.setReasonTollgateRule(BPMConstants.CDHP_RECYCLE_TOLLGATE_RULE_3);
					personDAO.insertCDHPFulfillmentRecycle(newCDHPFulfillmentTrackingRecycle);
					bypassRecycledCDHPParticipantCompletions.add(lPersonActivityAchievedContribution);
					recycleRecordsOnHoldR3++;
		}   
		
		return bypassRecycledCDHPParticipantCompletions;
	}
	
	/*
	 * Evaluate Reward Incented tollgate business rules to determine if transaction will be bypassed due to rule.
	 */
	
	private Collection<PersonActivityAchievedReward> evaluateTollgateRulesForIncentedRewardActivities(Collection<PersonActivityAchievedReward> lPersonActivityAchievedRewards, RewardCardQuoteByProgramSummary lRewardCardQuoteByProgramSummary) throws BPMException {
		
		ArrayList<PersonActivityAchievedReward> lPersonActivityAchievedRewardsMultiActivity = new ArrayList<PersonActivityAchievedReward>();
	
		// Tollgate rule 1 (safegaurd for preventing more than one reward card if multi activity) - 
		// If Incentive Status for program incentive option is multi activity, determine 
		// if reward activity incented to the program incentive option has been fulfilled by a different activity for
		// the same program incentive option.  Only one incentive per set of activities can be achieved.
		for (PersonActivityAchievedReward lPersonActivityAchievedReward : lPersonActivityAchievedRewards) {
			LookUpValueCode lLookUpValueCode = lookUpValueDAO.getLUVCodeByID(lPersonActivityAchievedReward.getIncentedStatusTypeCodeID());
			if (lLookUpValueCode.getLuvVal().equals(BPMConstants.BPM_INCENTED_STATUS_TYPE_MULTI_ACTIVITY)) {
				if (isMultiActivityRewardAlreadyFulfilled(lPersonActivityAchievedReward)) {
					RewardFulfillmentTrackingReportHist lRewardFulfillmentTrackingReportHist = buildRewardFulfillmentTrackingReportHist(lPersonActivityAchievedReward);
					recordToProgramMultiActivityBypassSummaryMap(lRewardCardQuoteByProgramSummary.getProgramMultiActivitySummaryMap(), lRewardFulfillmentTrackingReportHist);
					lPersonActivityAchievedRewardsMultiActivity.add(lPersonActivityAchievedReward);
				}
			}
		}
		
		for (PersonActivityAchievedReward lPersonActivityAchievedRewardMultiActivity : lPersonActivityAchievedRewardsMultiActivity) {
			lPersonActivityAchievedRewards.remove(lPersonActivityAchievedRewardMultiActivity);
		}
		
		return lPersonActivityAchievedRewards;
	}
	
	private boolean isMultiActivityRewardAlreadyFulfilled(PersonActivityAchievedReward lPersonActivityAchievedReward) {
		boolean personRewardExist = false;
		if (personDAO.isMultiActivityRewardFulfilled(lPersonActivityAchievedReward)) {
			personRewardExist = true;
		}
		
		return personRewardExist;
		
	}
	
	private boolean didPersonCompleteActivityNAchieveContribution(PersonActivityAchievedContribution lPersonActivityAchievedContribution) {
		boolean personContribExist = false;
		CDHPFulfillmentTrackingReportHist lCDHPFulfillmentTrackingReportHist = personDAO.findPersonCDHPContributionAlreadySent(lPersonActivityAchievedContribution);
		
		if (lCDHPFulfillmentTrackingReportHist != null) {
			personContribExist = true;
		}
		
		return personContribExist;
		
	}
	
	
	
	private CDHPFulfillmentTrackingRecycle buildCDHPFulfillmentRecycle(PersonActivityAchievedContribution lPersonActivityAchievedContribution) throws BPMException {
		CDHPFulfillmentTrackingRecycle lCDHPFulfillmentTrackingRecycle = new CDHPFulfillmentTrackingRecycle();
		LookUpValueCode lookUpValueCode = new LookUpValueCode();
		
		lCDHPFulfillmentTrackingRecycle.setProgramId(lPersonActivityAchievedContribution.getProgramID());
		lCDHPFulfillmentTrackingRecycle.setPersonDemographicsID(lPersonActivityAchievedContribution.getPersonDemographicsID());
		lCDHPFulfillmentTrackingRecycle.setContractNumber(lPersonActivityAchievedContribution.getContractNo());
		lookUpValueCode = getLUVCodeByGroupNValue(BPMConstants.BPM_CDHP_RECYCLE_STATUS, BPMConstants.CDHP_RECYCLE_STATUS_ON_HOLD);
		lCDHPFulfillmentTrackingRecycle.setRecycleStatusId(lookUpValueCode.getLuvId());
		lCDHPFulfillmentTrackingRecycle.setRecycleStatDate(BPMUtils.calendarToSqlDate(Calendar.getInstance()));
		lCDHPFulfillmentTrackingRecycle.setActivityId(lPersonActivityAchievedContribution.getActivityID());
		lCDHPFulfillmentTrackingRecycle.setActivityStatusIncentiveDate(lPersonActivityAchievedContribution.getActivityStatDate());
		lCDHPFulfillmentTrackingRecycle.setPackageSubTypeName(lPersonActivityAchievedContribution.getPackageSubType());
		lCDHPFulfillmentTrackingRecycle.setInsertUser(BPMConstants.BPM_USER_SYSTEM);
		lCDHPFulfillmentTrackingRecycle.setInsertDate(BPMUtils.calendarToSqlDate(Calendar.getInstance()));
		
		return lCDHPFulfillmentTrackingRecycle;
		
	}
	
	
	
	private RewardFulfillmentTrackingReportHist buildRewardFulfillmentTrackingReportHist(PersonActivityAchievedReward lPersonActivityAchievedReward) {
		
		RewardFulfillmentTrackingReportHist lRewardFulfillmentTrackingReportHist = new RewardFulfillmentTrackingReportHist();
		
		lRewardFulfillmentTrackingReportHist.setActivityID(lPersonActivityAchievedReward.getActivityID());
		lRewardFulfillmentTrackingReportHist.setContractNo(lPersonActivityAchievedReward.getContractNo());
		lRewardFulfillmentTrackingReportHist.setContributionAmount(lPersonActivityAchievedReward.getContributionAmt());
		lRewardFulfillmentTrackingReportHist.setProgramID(lPersonActivityAchievedReward.getProgramID());
		lRewardFulfillmentTrackingReportHist.setIncentiveOptionID(lPersonActivityAchievedReward.getIncentiveOptionID());
		lRewardFulfillmentTrackingReportHist.setPersonDemographicsID(lPersonActivityAchievedReward.getPersonDemographicsID());
		lRewardFulfillmentTrackingReportHist.setPersonID(lPersonActivityAchievedReward.getPersonID());
		lRewardFulfillmentTrackingReportHist.setGroupID(lPersonActivityAchievedReward.getGroupID());
		lRewardFulfillmentTrackingReportHist.setContributionTypeCodeId(lPersonActivityAchievedReward.getContribTypeCodeID());
		
		return lRewardFulfillmentTrackingReportHist;
		
	}
	
	
	
	private LookUpValueCode getLUVCodeByGroupNValue(String group, String value) throws BPMException {
		LookUpValueCode lookUpValueCode = null;
		try {
			lookUpValueCode = lookUpValueService.getLUVCodeByGroupNValue(group, value);
		} catch (Exception ex) {
			logger.error("Error performing lookup of LookUpValue id for " +  group);
			throw new BPMException(ex.getMessage(), ex);
		}
		
		return lookUpValueCode;
	}
	
	private LookUpValueCode getLUVCodeByGroupSingle(String group) throws BPMException {
		Collection<LookUpValueCode> lookUpValueCodes = null;
		LookUpValueCode lookUpValueCode = null;
		try {
			lookUpValueCodes = lookUpValueService.getLUVCodesByGroup(group);
		} catch (Exception ex) {
			logger.error("Error performing lookup of LookUpValue id for " +  group);
			throw new BPMException(ex.getMessage(), ex);
		}
		
		if (lookUpValueCodes.size() == 1) {
			lookUpValueCode  = lookUpValueCodes.iterator().next();
		} else {
			String failureReason = "Employer Fulfillment CSV path is in error.  Path doesn't exit or more than one luv entry.";
			logger.error(failureReason);
			throw new BPMException(failureReason);
		}
		
		return lookUpValueCode;
	}
	
	private boolean isRecycleStatusApproved(PersonContractRecycle personContractRecycle) {
			
		boolean approved = false;
		if (personContractRecycle.getRecycleStatus().equals(BPMConstants.PERSON_CONTRACT_RECYCLE_STATUS_APPROVED)) {
			approved = true;
		}
		return approved;
	}
	
	private boolean isRecycleStatusReleased(PersonContractRecycle personContractRecycle) {
		
		boolean approved = false;
		if (personContractRecycle.getRecycleStatus().equals(BPMConstants.PERSON_CONTRACT_RECYCLE_STATUS_RELEASED)) {
			approved = true;
		}
		return approved;
	}
	
	private boolean isRecycleStatusDeniedNNowQualified(PersonContractRecycle personContractRecycle, String currentContractStatus) {
		
		boolean placeOnHold = false;
		if (personContractRecycle.getRecycleStatus().equals(BPMConstants.PERSON_CONTRACT_RECYCLE_STATUS_DENIED) && 
				currentContractStatus.equals(BPMConstants.MEMBER_STATUS_QUALIFIED)) {
			placeOnHold = true;
		}
		return placeOnHold;
	}
	/*
	 * Evaluate those person contract recycle records in an ON HOLD status and now have a contract that is QUALIFIED.  Allow the person contract
	 * record to be passed on to membership accounting (cache).
	 * If the program end date is from the previous year, then leave person contract with a status of ON HOLD to be evaluated manually.
	 * The idea behind this is that the contract should not have changed to QUALIFIED outside of the program year.  If current
	 * contract is DID_NOT_QUALIFY, this is what the member would know about during the benefit year and in this scenerio would be the current year.
	 * BPM 2.11 change - Added luvReviewEndDate to allow time for admin to review.
	 */
	private boolean isRecycleStatusOnHoldNNowQualified(PersonContractRecycle personContractRecycle, String currentContractStatus) {
		
		boolean placeQualified = false;
		java.sql.Date progEndDate = personContractRecycle.getProgramEndDate();
		
		
	    if (progEndDate.before(new java.util.Date())) { 
	    	//member contract changed to QUALIFIED in the benefit year (current year) so ignore.	
	    } else if (personContractRecycle.getRecycleStatus().equals(BPMConstants.PERSON_CONTRACT_RECYCLE_STATUS_ON_HOLD) && 
					currentContractStatus.equals(BPMConstants.MEMBER_STATUS_QUALIFIED)) {
	    			String days = personContractRecycle.getLuvOnHoldQualifiedReviewWindowInDays();
	    			if (allowForReviewToContinue(personContractRecycle, days)) { 
	    				//Remains on hold to allow admin to review why went from DNQ to Q after qualification period.
	    				//Once past reviewEndDate, person contract recycle record will be released to Cache.
	    			} else {
	    				placeQualified = true;
	    			}
		}
	    
		return placeQualified;
	}
	
	private boolean isCDHPRecycleStatusReleased(CDHPFulfillmentTrackingRecycle lCDHPFulfillmentTrackingRecycle) {
		
		boolean approved = false;
		if (lCDHPFulfillmentTrackingRecycle.getRecycleStatus().equals(BPMConstants.CDHP_RECYCLE_STATUS_RELEASED)) {
			approved = true;
		}
		return approved;
	}
	
	private boolean isCDHPRecycleStatusApproved(CDHPFulfillmentTrackingRecycle lCDHPFulfillmentTrackingRecycle) {
		
		boolean approved = false;
		if (lCDHPFulfillmentTrackingRecycle.getRecycleStatus().equals(BPMConstants.CDHP_RECYCLE_STATUS_APPROVED)) {
			approved = true;
		}
		return approved;
	}
	
	private boolean isRewardRecycleStatusReleased(RewardFulfillmentTrackingRecycle lRewardFulfillmentTrackingRecycle) {
		
		boolean approved = false;
		if (lRewardFulfillmentTrackingRecycle.getRecycleStatus().equals(BPMConstants.REWARD_RECYCLE_STATUS_RELEASED)) {
			approved = true;
		}
		return approved;
	}
	
	private boolean isRewardRecycleStatusApproved(RewardFulfillmentTrackingRecycle lRewardFulfillmentTrackingRecycle) {
		
		boolean approved = false;
		if (lRewardFulfillmentTrackingRecycle.getRecycleStatus().equals(BPMConstants.REWARD_RECYCLE_STATUS_APPROVED)) {
			approved = true;
		}
		return approved;
	}
	
	
	/*
	 *  Tollgate rule 1 - Check to see if a change occurred in BPM that triggered a contract status calculation change from
	 *  Qualified to another status.  Most likely to Did Not Qualify or Eligible.
	 *  EV33553 - added code to check for contract status of ELIGIBLE and member status of HOLD_FOR_CONTRACT when
	 *  person contract history is QUALIFIED.  Contract status was originall QUALIFIED because an HA activity event came in
	 *  as completed.  Then days later an HA activity event reports that member is HIGH RISK to be later enrolled in a
	 *  desease management program.  We need to allow these cases to pass the edit rules allowing the person contract to 
	 *  be repored to Cache membership.
	 *  HCEREPORT-252: comment out code that applies to Desease Management that no longer applies.  Check for cases where contract status
	 *  went from Qualified to DNQ so it is researched for validity.
	 */
	private boolean isContractStatusChangingFromQToDNQ(PersonProgramStage personProgramStage, PersonContractHist personProgramHistStage)
	{
		boolean qualifiedToDNQ = false;
		if (personProgramHistStage.getContractStatus().equals(BPMConstants.CONTRACT_STATUS_QUALIFIED)) {

//			if (personProgramStage.getContractStatus().equals(BPMConstants.CONTRACT_STATUS_ELIGIBLE) &&
//					personProgramStage.getMemberStatus().equals(BPMConstants.MEMBER_STATUS_HOLD_FOR_CONTACT)) {
//				qualifiedToAny = false;
//		} else
			//Contract status changing from QUALIFIED TO DID_NOT_QUALIFIED.  Flag for recycle table.
			if (personProgramStage.getContractStatus().equals(BPMConstants.CONTRACT_STATUS_DID_NOT_QUALIFY)) {
				qualifiedToDNQ = true;
			}
		}
		return qualifiedToDNQ;
	}
	/*
	 * Tollgate rule 2 - Check to see if a retroactive change triggered a contract status change in benefit year from Did Not Qualify
	 * to Qualified without an exemption.
	 */
	private boolean isContractStatusChangingFromDNQToQWithNoExemption(PersonProgramStage personProgramStage, PersonContractHist personProgramHistStage) {
		
		boolean isQualifiedWithNoExempt = false;
		// Check to see if previous contract status was Did Not Qualify
		if (personProgramHistStage.getContractStatus().equals(BPMConstants.CONTRACT_STATUS_DID_NOT_QUALIFY)) {
			//Check to see if current contract is Qualified.  
			if (personProgramStage.getContractStatus().equals(BPMConstants.CONTRACT_STATUS_QUALIFIED)) {
				//
				
				/*Calendar cal = Calendar.getInstance();
				int prevYear = cal.get(Calendar.YEAR) - 1;
				cal.clear();
				cal.set(prevYear, 12, 0); //Set to prev year, December 31
					
				java.sql.Date prevEndOfYear = BPMUtils.calendarToSqlDate(cal);
				*/
				Calendar cal = Calendar.getInstance();	
				java.sql.Date currDate = BPMUtils.calendarToSqlDate(cal);


				// Must be outside of program year.
				if (personProgramStage.getProgramEndDate().before(currDate)) {
					Integer programId = personProgramStage.getProgramID();
					Integer personDemographicsID = personProgramStage.getPersonDemographicsID();
					Integer programIncentiveOptionID = personProgramStage.getProgramIncentiveOptionID();
					// Check for exemption
					if (isPersonContractNotExempt(programId, personDemographicsID, programIncentiveOptionID)) {
						isQualifiedWithNoExempt = true;
					}
				}
			}
		}
				
		
		return isQualifiedWithNoExempt;
	}
	/*
	 * Tollgate rule 3 - The current Healthy Benefits program year qualification period has ended.  
	 * The member contract status did not update from Eligible to Qualified or Did Not Qualify.
	 */
	private boolean isContractStatusEligibleAfterQaulPeriod(PersonProgramStage personProgramStage) {
		
		boolean isContractStillEligibleAfterQualPeriod = false;
		
		// Check to see if beyond biz program qualification period.
		//LocalDate retrieves current date without minute, seconds, milliseconds.
		LocalDate localDate = LocalDate.now();
		java.sql.Date currDate = java.sql.Date.valueOf(localDate);
		// Must be outside of qualfication period.
		if (personProgramStage.getQualificationEndDate().before(currDate)) {
			// Determine if person contract is still Eligible
			if (personProgramStage.getContractStatus().equals(BPMConstants.CONTRACT_STATUS_ELIGIBLE)) {
				//Contract status is still ELIGIBLE after qualification period.  Flag for recycle table.
				isContractStillEligibleAfterQualPeriod = true;
			}
		}
		
		return isContractStillEligibleAfterQualPeriod;
	}
	
	

	/*
	 * This method determines if a person contract recycle record that is now QUALIFIED falls
	 * within the review window set in days on the LUV table.  The number of days can be adjusted
	 * to allow ON HOLD's now QUALIFIED to automatically be released sooner.  If a record needs to be
	 * singled out and released than mark the record as APPROVED.
	 */
	private boolean allowForReviewToContinue(PersonContractRecycle personContractRecycle, String days) {
		boolean continueToRemainOnHold = false;
		//Calc review window
		Integer daySpan = Integer.valueOf(days);
		java.sql.Date reviewStartDate = new java.sql.Date(personContractRecycle.getInsertDate().getTime());
		Calendar systemDateCal = Calendar.getInstance();
		Calendar reviewEndDate = Calendar.getInstance();
		reviewEndDate.setTime(reviewStartDate);
		reviewEndDate.add(Calendar.DATE, daySpan);
		
		java.sql.Date todaysDate = new java.sql.Date(systemDateCal.getTime().getTime()); 
		
		if (todaysDate.after(reviewEndDate.getTime())) {
			//person contract eligible to move from on hold to released if now qualified.
		} else {
			recycleRecordsOnHoldWaitingToBeReviewed++;
			continueToRemainOnHold = true;
		}
		
		return continueToRemainOnHold;
		
			
	}
	
	private boolean isPersonContractQualified(PersonProgramStage personProgramStage) {
			boolean qualified = false;
			if (personProgramStage.getContractStatus().equals(BPMConstants.CONTRACT_STATUS_QUALIFIED)) {
				qualified = true;
			}
			return qualified;
	}
	
	
	private boolean isPersonContractRecycleExist(PersonProgramStage personProgramStage) {
		boolean recycleFound = false;
		
		return recycleFound;
	}
	
	private boolean isPersonContractRecycleApproved(PersonProgramStage personProgramStage) {
		boolean approved = false;
		
		return approved;
	}
	
	private boolean isPersonContractNotExempt(Integer businessProgramId, Integer personId, Integer pProgramIncentiveOptionID) {
		
		boolean noExemption = false;
		Collection<QualificationOverride> overrideExemptions = qualificationOverrideService.getAllQualificationOverrides(personId);
		if (overrideExemptions.size() == 0) {
			noExemption = true;
		}
		else
		{
			for(QualificationOverride lExemption : overrideExemptions)
			{
				if(lExemption.getProgramIncentiveOptionID().intValue() == pProgramIncentiveOptionID.intValue())
				{
					noExemption = false;
					break;
				}
			}
		}
		return noExemption;
	}
	/*
	 * EV78853 - Changed code to determine if incentive option is configured to using a unit type of "units" vs "dollars"
	 */
	private boolean isParticipantCapExceeded(PersonActivityAchievedContribution lPersonActivityAchievedContribution) {
		boolean participantCapExceeded = false;
		
		//read from contribution history the participants past contributions if any.  Total it up and compare to cap.
		Integer programID = lPersonActivityAchievedContribution.getProgramID();
		Integer contractNo = lPersonActivityAchievedContribution.getContractNo();
		Integer personDemographicsID = lPersonActivityAchievedContribution.getPersonDemographicsID();
		Integer incentiveOptionID = lPersonActivityAchievedContribution.getIncentiveOptionID();
		Collection<CDHPFulfillmentTrackingReportHist> lCDHPFulfillmentTrackingReportHist = personDAO.getPersonContributions(programID, contractNo, personDemographicsID, incentiveOptionID);
		
		int totalPersonContributions = sumPersonContributions(lCDHPFulfillmentTrackingReportHist, lPersonActivityAchievedContribution.isUnitTypeCodeUnits());
		//EV78394 - add in current contribution for incented activity.
		if (lPersonActivityAchievedContribution.getContributionAmt() != null) {
			if (lPersonActivityAchievedContribution.isUnitTypeCodeUnits()) {
				totalPersonContributions++;
			} else {
				totalPersonContributions = totalPersonContributions + lPersonActivityAchievedContribution.getContributionAmt();
			}
		}
		if (lPersonActivityAchievedContribution.getParticipantCap() != null && lPersonActivityAchievedContribution.getParticipantCap() > 0) {
			if (totalPersonContributions > lPersonActivityAchievedContribution.getParticipantCap()) {
				participantCapExceeded = true;
			}
		}
		
		return participantCapExceeded;
		
	}
	/*
	 * EV78853 - Changed code to determine if incentive option is configured to using a unit type of "units" vs "dollars"
	 */
	private boolean isFamilyCapExceeded(PersonActivityAchievedContribution lPersonActivityAchievedContribution) {
		boolean familyCapExceeded = false;
		Integer programID = lPersonActivityAchievedContribution.getProgramID();
		Integer contractNo = lPersonActivityAchievedContribution.getContractNo();
		Integer incentiveOptionID = lPersonActivityAchievedContribution.getIncentiveOptionID();
		
		Collection<CDHPFulfillmentTrackingReportHist> lCDHPFulfillmentTrackingReportHist = personDAO.getPersonContributions(programID, contractNo, null, incentiveOptionID);

		int totalContractContributions = sumPersonContributions(lCDHPFulfillmentTrackingReportHist, lPersonActivityAchievedContribution.isUnitTypeCodeUnits());
		
		//EV78394 - add in current contribution for incented activity.
		if (lPersonActivityAchievedContribution.getContributionAmt() != null) {
			if (lPersonActivityAchievedContribution.isUnitTypeCodeUnits()) {
				totalContractContributions++;
			} else {
				totalContractContributions = totalContractContributions + lPersonActivityAchievedContribution.getContributionAmt();
			}
		}
		if (lPersonActivityAchievedContribution.getFamilyCap() != null && lPersonActivityAchievedContribution.getFamilyCap() > 0) {
			if (totalContractContributions > lPersonActivityAchievedContribution.getFamilyCap()) {
				familyCapExceeded = true;
			}
		}
		
		
		return familyCapExceeded;
	}
	
	
	
	private int sumPersonContributions(Collection<CDHPFulfillmentTrackingReportHist> lCDHPFulfillmentTrackingReportHists, boolean isUnitTypeUnits) {
		int totalPersonContributions = 0;
		
		Iterator<CDHPFulfillmentTrackingReportHist> iter = lCDHPFulfillmentTrackingReportHists.iterator();
		
		while (iter.hasNext()) {
			CDHPFulfillmentTrackingReportHist lCDHPFulfillmentTrackingReportHist = (CDHPFulfillmentTrackingReportHist)iter.next();
			//count by units since only interested in number of times participant
			//achieved an incentive by activity taken.  The other Unit Type is DOLLARS.
			if (isUnitTypeUnits) {
				totalPersonContributions++;
			} else {
				totalPersonContributions = totalPersonContributions + lCDHPFulfillmentTrackingReportHist.getContributionAmount();
			}
		}

		
		return totalPersonContributions;
	}
	
	public AuditLogService getAuditLogService() {
		return auditLogService;
	}

	public void setAuditLogService(AuditLogService auditLogService) {
		this.auditLogService = auditLogService;
	}
	
	
	private void createReconLogStageEntry(ReconLogStage reconLogStage)
	{
        try
        {
			//story BPM-882
			//This app id cannot change because the cache membership app edits
			//for app id coming from the membership feed.
			reconLogStage.setAppId("BPM");
            membershipFeedStageService.insertReconLogStage(reconLogStage);
        }
        catch(Exception e)
        {
            logger.error((new StringBuilder()).append("Error writing createReconLogStageEntry ").append(e).toString());
        }
	}
	

	/**
	 * Convert XML into SQL statements using XSL translation.
	 * 
	 * @param xmlSql
	 * @return
	 * @throws ParserException
	 */
	private String getSqlFromXml(String xmlSql, String elapsedTimeXslFile)
			throws BPMParserException {
		String sql = null;

		try {
			// Open XSL style sheet.
			InputStream xsltInputStream = this.getClass().getClassLoader()
					.getResourceAsStream(elapsedTimeXslFile);
			StreamSource styleSheetSource = new StreamSource(xsltInputStream);

			// Open XML as input stream.
			ByteArrayInputStream xmlInputStream = new ByteArrayInputStream(
					xmlSql.getBytes());
			StreamSource xmlSource = new StreamSource(xmlInputStream);

			// Open output stream.
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			StreamResult result = new StreamResult(outputStream);

			// Transform XML using XSL.
			TransformerFactory factory = (TransformerFactory) BPMTransformerFactoryFinder
					.find(BPMConstants.XML_TRANSFORM_SAXON_IMPLEMENTATION);
			Transformer trans = factory.newTransformer(styleSheetSource);
			trans.transform(xmlSource, result);
			sql = outputStream.toString();
		} catch (Exception e) {
			logger.error("An unexpected error has occured: " + e.getMessage(),
					e);
			throw new BPMParserException(e);
		}

		return sql;
	}

	/**
	 * Reset the message generation timestamp for members in the set, in
	 * batches.
	 * 
	 * @return the number of timestamps reset
	 * @param memberIds
	 * @param batchSize
	 */
	private void resetMemberProcessingTimestamps(TreeSet<Integer> memberIds,
			int batchSize) throws BPMException {

		try {
			if (memberIds != null) {
				while (memberIds.size() > 0) {
					if (batchSize > memberIds.size()) {
						batchSize = memberIds.size();
					}
					// logger.info("memberIds size = " + memberIds.size());
					ArrayList<Integer> personIdsList = new ArrayList<Integer>();
					for (int j = 0; j < batchSize; j++) {
						Integer memberId = memberIds.first();
						memberIds.remove(memberId);
						personIdsList.add(memberId);
					}

					insertPersonProcessingStatus(personIdsList,
							BPMConstants.PROCESSING_STATUS_PENDING);
				}
			}
		} catch (Exception e) {
			// Rollback the transaction on error.

			logger.error("An unexpected error has occured: " + e.getMessage(),
					e);
			throw new BPMException(e);
		}
	}

	@Transactional(transactionManager = "DataSourceTransactionManager",  timeout = 300, rollbackFor = { DataAccessException.class,
			com.healthpartners.service.imfs.exception.BPMBusinessValidationException.class, BPMException.class })
	private void insertPersonProcessingStatus(
			Collection<Integer> personIdsList, String processingStatusValue)
			throws BPMException {
		// Begin a transaction.
		// DefaultTransactionDefinition def = new
		// DefaultTransactionDefinition();
		// def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		// TransactionStatus status = txManager.getTransaction(def);

		try {
			memberService.insertPersonProcessingStatus(personIdsList,
					BPMConstants.ETL_MEMBERSHIP_UPDATE_PRCS_ID,
					processingStatusValue, BPMConstants.BPM_USER_SYSTEM);
			// Commit the transaction.
			// txManager.commit(status);
		} catch (DataAccessException dae) {
			// Rollback the transaction on error.
			// txManager.rollback(status);

			logger
					.error("An unexpected error has occured: "
							+ dae.getMessage(), dae);
			throw dae;
		} catch (Exception e) {
			// Rollback the transaction on error.
			// txManager.rollback(status);

			logger.error("An unexpected error has occured: " + e.getMessage(),
					e);
			throw new BPMException(e);
		}
	}
	

	/**
	 * For each member get their contract, package, and subgroup history.
	 * 
	 * @param pMemberAdapters
	 */
	private void findPackageSubgroupHistory(
			ArrayList<MemberAdapter> pMemberAdapters) {
		for (int i = 0; i < pMemberAdapters.size(); i++) {
			MemberAdapter lMemberAdapter = (MemberAdapter) pMemberAdapters
					.get(i);

			Integer lPersonID = lMemberAdapter.getMember().getPersonID();

			lMemberAdapter
					.setContractHistories((ArrayList<ContractHistory>) contractDAO
							.getContractHistory(lPersonID));
			
			//check to see if no contract history returned 
			//and activity completion period enabled. Member could be a dependent 18 plus
			//and is eligible for a program that has to be completed under the activity
			//completion period business rule.
			if (lMemberAdapter.getContractHistories().isEmpty()) {
				if (lMemberAdapter.isActivityCompletionPeriodEnabled()) {
					lMemberAdapter
						.setContractHistories((ArrayList<ContractHistory>) contractDAO
								.getContractHistoryForDependent(lPersonID));
				}
			} 

			ContractHistory lContractHistory = null;

			ArrayList<SubgroupHistory> subgroupHistories = new ArrayList<SubgroupHistory>();
			ArrayList<PackageHistory> packageHistories = new ArrayList<PackageHistory>();

			if (lMemberAdapter.getContractHistories() != null
					&& lMemberAdapter.getContractHistories().size() > 0) {
				for (int j = 0; j < lMemberAdapter.getContractHistories()
						.size(); j++) {
					lContractHistory = (ContractHistory) lMemberAdapter
							.getContractHistories().get(j);
					// For each current contract get the subgroup and package
					// histories.
					// There could be more than one current contract in case of
					// dual coverage.
					
					if (lContractHistory.isCurrent()) {
						packageHistories
								.addAll((ArrayList<PackageHistory>) contractDAO
										.getPackageHistory(lPersonID,
												lContractHistory.getID()));
						subgroupHistories
								.addAll((ArrayList<SubgroupHistory>) contractDAO
										.getSubgroupHistory(lPersonID,
												lContractHistory.getID()));
						
						//check to see if no packages returned 
						//and activity completion period enabled. Member could be a dependent 18 plus
						//and is eligible for a program that has to be completed under the activity
						//completion period business rule.
						if (packageHistories.isEmpty()) {
							if (lMemberAdapter.isActivityCompletionPeriodEnabled()) {	
								packageHistories
								.addAll((ArrayList<PackageHistory>) contractDAO
										.getPackageHistoryForDependent(lPersonID,
												lContractHistory.getID()));				
							}
						} 
					}
				}
			}

			lMemberAdapter.setSubgroupHistories(subgroupHistories);
			lMemberAdapter.setPackageHistories(packageHistories);

			/*
			 * Find out which packages and subgroups, current and previous, are,
			 * and were participating in Healthy Benefits.
			 */						
			
			if (lMemberAdapter.getPackageHistories() != null) {
				for (int j = 0; j < lMemberAdapter.getPackageHistories().size(); j++) {
					PackageHistory lPackageHistory = (PackageHistory) lMemberAdapter
							.getPackageHistories().get(j);
					ArrayList<MemberUpdate> lMemberUpdates = (ArrayList<MemberUpdate>) contractDAO
							.getIsParticipating(lPersonID, lPackageHistory
									.getID(), BPMConstants.BPM_HISTORY_PACKAGE);
					if (lMemberUpdates.size() > 0) {
						lPackageHistory.setParticipating(true);
					}
				}
			}

			if (lMemberAdapter.getSubgroupHistories() != null) {
				for (int j = 0; j < lMemberAdapter.getSubgroupHistories()
						.size(); j++) {
					SubgroupHistory lSubgroupHistory = (SubgroupHistory) lMemberAdapter
							.getSubgroupHistories().get(j);
					ArrayList<MemberUpdate> lMemberUpdates = (ArrayList<MemberUpdate>) contractDAO
							.getIsParticipating(lPersonID, lSubgroupHistory
									.getID(), BPMConstants.BPM_HISTORY_SUBGROUP);
					if (lMemberUpdates.size() > 0) {
						lSubgroupHistory.setParticipating(true);
					}
				}
			}
		}
	}
	/**
	 * set all types of Risks and RiskGroups to each MemberAdapter
	 * 
	 * @param pMemberAdapters
	 */
	private void setRiskAndRiskGroupDetails(
			ArrayList<MemberAdapter> pMemberAdapters) {
		if (pMemberAdapters != null) {
				ArrayList<LookUpValueCode> lRiskGroupCodes = (ArrayList<LookUpValueCode>) lookUpValueDAO
						.getLUVCodesByGroup(BPMConstants.RISK_LUV_GROUP);
				ArrayList<Risk> lRisks = (ArrayList<Risk>) riskDAO.getAllRisks();
	
				Iterator<MemberAdapter> itrMemb = pMemberAdapters.iterator();
				while (itrMemb.hasNext()) {
					MemberAdapter memberAdapter = itrMemb.next();
					memberAdapter.setRiskGroupCodes(lRiskGroupCodes);
					memberAdapter.setRisks(lRisks);
				}
		}
	}
	
	
	
	private Collection<CDHPFulfillmentTrackingReport> assignSupportingAttributes(Collection<CDHPFulfillmentTrackingReport> hraFulfillmentTrackingRpts, String cdhpBatchType) {
		
		HashMap nameOfPHMap = new HashMap();
		ContractPolicyHolderInfo contractPolicyHolderInfo = null;
		
		Iterator<CDHPFulfillmentTrackingReport> iter = hraFulfillmentTrackingRpts.iterator();
		
		while (iter.hasNext()) {
			CDHPFulfillmentTrackingReport hraFulfillmentTrackingRpt = (CDHPFulfillmentTrackingReport) iter.next();
			Integer contractNo = hraFulfillmentTrackingRpt.getContractNo();
			
			if (nameOfPHMap.containsKey(contractNo)) {
				contractPolicyHolderInfo = (ContractPolicyHolderInfo) nameOfPHMap.get(contractNo);	
			} else {
				contractPolicyHolderInfo = contractDAO.getNameOfPHByContract(hraFulfillmentTrackingRpt.getContractNo());
				nameOfPHMap.put(contractNo, contractPolicyHolderInfo);
			}
			
			hraFulfillmentTrackingRpt.setFirstName(contractPolicyHolderInfo.getFirstName());
			hraFulfillmentTrackingRpt.setLastName(contractPolicyHolderInfo.getLastName());
			hraFulfillmentTrackingRpt.setMiddleName(contractPolicyHolderInfo.getMiddleName());
			hraFulfillmentTrackingRpt.setMemberNo(contractPolicyHolderInfo.getMemberNo());
			if (cdhpBatchType.equals(BPMConstants.CDHP_BATCH_TYPE_HSA)) {
				Integer ssn = assignSocialSecurityNumber(contractPolicyHolderInfo.getPersonID());
				hraFulfillmentTrackingRpt.setSocialSecurityNo(Integer.toString(ssn));
			}
			
		}
		
		return hraFulfillmentTrackingRpts;
		
	}
	
	
	/*
	 * Using person id perform a lookup against the MODS.Person_DS table through a DB link to get social security number.
	 */
	private Integer assignSocialSecurityNumber(Integer personID) {
			
		Integer socialSecurityNo = personDAO.getPersonSoicalSecurityNo(personID);
		
		
		return socialSecurityNo;
		
	}
	/*
	 * Purpose of this method is to determine if there exists multiple persons completing activities on the same day for the same
	 * contract.  If this exists, the contribution amounts must be combined to the contract level.  Sort order is critical in order
	 * for this to work.  The SQL returns the result set of those persons acheiving contributions must be ordered by group and contract no. 
	 * 
	 */
	private Collection<PersonActivityAchievedContribution> combineContributionsByContract(Collection<PersonActivityAchievedContribution> hraParticipantCompletions) {
		
		HashMap combineContributionAmtByContract = new HashMap();
		
		ArrayList<PersonActivityAchievedContribution> personContributionsConsideredForCombining = new ArrayList<PersonActivityAchievedContribution>();
	
		
		PersonActivityAchievedContribution lPersonActivityAchievedHRAContribution = null;
		Integer contractNo = null;
		Integer contributionAmtTotal = 0;
		Integer memberCount = 0;
		Iterator<PersonActivityAchievedContribution> iterPass1 = (Iterator<PersonActivityAchievedContribution>) hraParticipantCompletions.iterator();
		
		//Pass 1: Determine if persons for the same contract completed activities and achieved a contribution
		while (iterPass1.hasNext()) {
			lPersonActivityAchievedHRAContribution = (PersonActivityAchievedContribution) iterPass1.next();
			contractNo = lPersonActivityAchievedHRAContribution.getContractNo();
			Integer contributionAmt = lPersonActivityAchievedHRAContribution.getContributionAmt();
			//Set aside contribution amounts in hash table by contract.  If more than one contribution achieved under the same contract,
			//then combine.
			if (combineContributionAmtByContract.containsKey(contractNo)) {
				// This hash table identifies the contracts that have more than one person achieving a contribution.
				ContractContributionTO combineContractContribution = (ContractContributionTO)combineContributionAmtByContract.get(contractNo);
				contributionAmtTotal = contributionAmt + combineContractContribution.getContributionAmountTotal();
				memberCount++;
				ContractContributionTO lContractContributionTO = mapperContractContribution(contractNo, contributionAmtTotal, memberCount);
				combineContributionAmtByContract.put(contractNo, lContractContributionTO);
				
			} else {
				memberCount = 1;
				ContractContributionTO lContractContributionTO = mapperContractContribution(contractNo, contributionAmt, memberCount);
				//break in contract number.  Set aside contribution amount in seperate hashtable.
				combineContributionAmtByContract.put(contractNo, lContractContributionTO);
				personContributionsConsideredForCombining.add(lPersonActivityAchievedHRAContribution);
			}
		}
		
		
		//Iterate through the hraParticipantCompletions collections and pickup contribution amounts from hash table.  If multiple more than one contribution
		//achieved on the same day for the same contract, then the sum of the contribution amounts will be picked up for the one member left in the collection.
		Iterator<PersonActivityAchievedContribution> iterPass2 = (Iterator<PersonActivityAchievedContribution>) personContributionsConsideredForCombining.iterator();
		while (iterPass2.hasNext()) {
			lPersonActivityAchievedHRAContribution = (PersonActivityAchievedContribution) iterPass2.next();
			contractNo = lPersonActivityAchievedHRAContribution.getContractNo();
			//looks for more than one contract having multiple persons achieving contributions on the same day.
			if (combineContributionAmtByContract.containsKey(contractNo)) {
				ContractContributionTO lContractContributionTO = (ContractContributionTO)combineContributionAmtByContract.get(contractNo);
				lPersonActivityAchievedHRAContribution.setCombinedContributionAmt(lContractContributionTO.getContributionAmountTotal());
				lPersonActivityAchievedHRAContribution.setParticipantCount(lContractContributionTO.getMemberCount());
			}
		}
		
		
		return personContributionsConsideredForCombining;
	
	}
	
	/*
	 * Purpose of this method is to determine if there exists multiple persons completing activities for the same contract for the same
	 * contribution date.  If this exists, the contribution amounts must be combined to the contribution date within the same contract.  Sort order is critical in order
	 * for this to work.  The SQL returns the result set of those persons acheiving contributions must be ordered by group, contract no and contribution date. 
	 * 
	 */
	public Collection<PersonActivityAchievedContribution> combineContributionsByContributionDateWithinContract(Collection<PersonActivityAchievedContribution> hsaParticipantCompletions) {
		HashMap combineContributionAmtByContractNDate = new HashMap();
		HashMap countMembersAchievingContributionsByDateWithinContract = new HashMap();
		
		
		ArrayList<PersonActivityAchievedContribution> personContributionsConsideredForCombining = new ArrayList<PersonActivityAchievedContribution>();
	
		PersonActivityAchievedContribution lPersonActivityAchievedHSAContribution = null;
		Integer contractNo = null;
		Integer prevContractNo = null;
		java.sql.Date contributionDate = null;
		Integer contributionAmtTotal = 0;
		
		int currentCombineIndex = 0;
		ContractContributionTO lContributionTO = null;
		Iterator<PersonActivityAchievedContribution> iter = (Iterator<PersonActivityAchievedContribution>) hsaParticipantCompletions.iterator();
		
		//Pass 1: Determine if persons for the same contract completed activities and achieved a contribution
		while (iter.hasNext()) {
			lPersonActivityAchievedHSAContribution = (PersonActivityAchievedContribution) iter.next();
			contractNo = lPersonActivityAchievedHSAContribution.getContractNo();
			if (prevContractNo == null) {
				prevContractNo = contractNo;
			}
			contributionDate = lPersonActivityAchievedHSAContribution.getContributionDate();
			
			Integer contributionAmt = lPersonActivityAchievedHSAContribution.getContributionAmt();
			//Set aside contribution amounts in hash table by contribution date and contract.  
			//If more than one contribution achieved under the same contribution date and contract,
			//then combine.
			if (contractNo.equals(prevContractNo)) {
				    
				if (combineContributionAmtByContractNDate.containsKey(contributionDate)) {
					// This hash table identifies the contribution amounts achieved for the same contribution date.
					ContractContributionTO combineContractContribution = (ContractContributionTO)combineContributionAmtByContractNDate.get(contributionDate);
					
					contributionAmtTotal = contributionAmt + combineContractContribution.getContributionAmountTotal();
					combineContractContribution.setContributionAmountTotal(contributionAmtTotal);
					personContributionsConsideredForCombining.get(currentCombineIndex).setCombinedContributionAmt(contributionAmtTotal);
					
					if (!countMembersAchievingContributionsByDateWithinContract.containsKey(lPersonActivityAchievedHSAContribution.getPersonDemographicsID())) {
						countMembersAchievingContributionsByDateWithinContract.put(lPersonActivityAchievedHSAContribution.getPersonDemographicsID(), lPersonActivityAchievedHSAContribution);
					}
					personContributionsConsideredForCombining.get(currentCombineIndex).setParticipantCount(countMembersAchievingContributionsByDateWithinContract.size());
					
					
				}  else {
					// break in contribution date
					countMembersAchievingContributionsByDateWithinContract.clear();
					countMembersAchievingContributionsByDateWithinContract.put(lPersonActivityAchievedHSAContribution.getPersonDemographicsID(), lPersonActivityAchievedHSAContribution);
					lContributionTO = mapperContractNContributionDateToContribution(contractNo, contributionDate, contributionAmt);
					//break in contribution date.  Set aside contribution amount in seperate hashtable.
					combineContributionAmtByContractNDate.clear();
					combineContributionAmtByContractNDate.put(contributionDate, lContributionTO);
					lPersonActivityAchievedHSAContribution.setParticipantCount(countMembersAchievingContributionsByDateWithinContract.size());
					lPersonActivityAchievedHSAContribution.setCombinedContributionAmt(lContributionTO.getContributionAmountTotal());
					personContributionsConsideredForCombining.add(lPersonActivityAchievedHSAContribution);
					currentCombineIndex = personContributionsConsideredForCombining.indexOf(lPersonActivityAchievedHSAContribution);
				}
			} else {
				//break in contract number
				prevContractNo = contractNo;
				countMembersAchievingContributionsByDateWithinContract.clear();
				countMembersAchievingContributionsByDateWithinContract.put(lPersonActivityAchievedHSAContribution.getPersonDemographicsID(), lPersonActivityAchievedHSAContribution);
				lPersonActivityAchievedHSAContribution.setParticipantCount(countMembersAchievingContributionsByDateWithinContract.size());
				lContributionTO = mapperContractNContributionDateToContribution(contractNo, contributionDate, contributionAmt);
				//break in contract number.  Set aside contribution amount in seperate hashtable.
				combineContributionAmtByContractNDate.clear();
				combineContributionAmtByContractNDate.put(contributionDate, lContributionTO);
				lPersonActivityAchievedHSAContribution.setCombinedContributionAmt(lContributionTO.getContributionAmountTotal());
				personContributionsConsideredForCombining.add(lPersonActivityAchievedHSAContribution);
				currentCombineIndex = personContributionsConsideredForCombining.indexOf(lPersonActivityAchievedHSAContribution);
				
			} 
			
		}
		
		
		return personContributionsConsideredForCombining;
	
	}
	
	
	
	private ContractContributionTO mapperContractContribution(Integer contractNo, Integer contributionAmtTotal, Integer memberCount) {
	
		ContractContributionTO lContractContributionTO = new ContractContributionTO();
		lContractContributionTO.setContractNo(contractNo);
		lContractContributionTO.setMemberCount(memberCount);
		lContractContributionTO.setContributionAmountTotal(contributionAmtTotal);
		
		return lContractContributionTO;
	}
	
	private ContractContributionTO mapperContractNContributionDateToContribution(Integer contractNo, java.sql.Date contributionDate, Integer contributionAmtTotal) {
		
		ContractContributionTO lContractContributionTO = new ContractContributionTO();
		lContractContributionTO.setContractNo(contractNo);
		lContractContributionTO.setContributionDate(contributionDate);
		lContractContributionTO.setContributionAmountTotal(contributionAmtTotal);
		
		return lContractContributionTO;
	}
		
		
	private int insertCDHPBatchLog(int recordsSent, String batchType) {
		
		CDHPBatchLog pCDHPBatchLog = new CDHPBatchLog();
		pCDHPBatchLog.setBatchType(batchType);
		pCDHPBatchLog.setRecordCount(recordsSent);
		
		int batchLogCount = batchLogDAO.insertCDHPBatchLog(pCDHPBatchLog);
		
		return batchLogCount;
	}
	
	private int insertRewardBatchLog(int recordsSent, String batchType) {
		
		RewardBatchLog pRewardBatchLog = new RewardBatchLog();
		pRewardBatchLog.setBatchType(batchType);
		pRewardBatchLog.setRecordCount(recordsSent);
		
		int batchLogCount = batchLogDAO.insertRewardBatchLog(pRewardBatchLog);
		
		return batchLogCount;
	}
	
	/**
	 * Updates the membership status flag if the current date is the membership status date.
	 */
	protected long updateMembershipStatusFlag()
	{
		return businessProgramDAO.updateMembershipStatusFlag();
		
	}
	
	/**
	 * Send an email to membership distribution list notifying them of upcoming business program
	 * membership status dates.
	 */
	protected void notifyMembership(String pProcessName, boolean pReadyForMembership)
	{
		ArrayList<BusinessProgramTO> lBusinessProgramsForMembershipList = (ArrayList<BusinessProgramTO>)  
	    businessProgramDAO.getBusinessProgramsForMembership(pReadyForMembership);
				
		prepareAndSendMembershipDateEmail(lBusinessProgramsForMembershipList, pReadyForMembership);
							
	}
	
	/**
	 * Send an email to membership distribution list notifying them of upcoming business program
	 * membership status dates.
	 * 

	 * @return
	 */
	public void prepareAndSendMembershipDateEmail(ArrayList<BusinessProgramTO> lBusinessProgramsForMembershipList
			, boolean pReadyForMembership
			) {
		
		String emailFromAddress = null;
		String dbEnvirnment = "";
		List<String> emailToAddress = new ArrayList<String>();
		StringBuffer emailContent = new StringBuffer();
		StringBuffer emailSubject = new StringBuffer();
		boolean isFirstTimeThroughWithNoMembershipFlagDateSet = true;
		boolean isFirstTimeThroughEmailFlag = true;
	
		try {			

	        Collection<LookUpValueCode> dbEnvirnments = lookUpValueDAO
			.getLUVCodesByGroup(BPMConstants.BPM_DB_ENV);			

			Iterator<LookUpValueCode> itrEnv = dbEnvirnments.iterator();
			while (itrEnv.hasNext()) {
				LookUpValueCode lvalue = itrEnv.next();
				dbEnvirnment = lvalue.getLuvDesc();
				break;
			}
			
				
		
			int rowCt = 0;
			
			// prepare summary email body
			
			Calendar membershipProcessDatePrev = null;
			
			for(BusinessProgramTO pBusinessProgramTO : lBusinessProgramsForMembershipList)
			{
				rowCt++;
				
				if (membershipProcessDatePrev == null || pBusinessProgramTO.getMembershipProcessDate() != null && 
															!pBusinessProgramTO.getMembershipProcessDate().equals(membershipProcessDatePrev)) {
					//line items appended need html end tag
					//in order to format correctly.  membershipProcessDatePrev of not null
					//indicates the first set of line item detail have been formatted and need
					//end of table tag set after a change in the membership process date.
					if (membershipProcessDatePrev != null) {
						emailContent.append("</table>");
					}
					membershipProcessDatePrev = pBusinessProgramTO.getMembershipProcessDate();
					   
				    if (isFirstTimeThroughEmailFlag) {
				    	emailContent = buildMembershipFlagMessage(pReadyForMembership, membershipProcessDatePrev);
					    emailContent = buildDetailHeader(emailContent);
				    	isFirstTimeThroughEmailFlag = false;
				    } else {
				    	emailContent.append("</table>");
						emailSubject = buildEmailSubject();
						sendEmail(emailSubject, emailContent);
						rowCt = 1;
						emailContent = buildMembershipFlagMessage(pReadyForMembership, membershipProcessDatePrev);
					    emailContent = buildDetailHeader(emailContent);
						
				    }
				    
					isFirstTimeThroughWithNoMembershipFlagDateSet = true;
					
				}
			
				
				Integer pNumberOfQualifieds = 
					    contractDAO.getContractStatusCount(BPMConstants.CONTRACT_STATUS_QUALIFIED, pBusinessProgramTO.getProgramID());
					
				Integer pNumberOfNotQualifieds = 
						contractDAO.getContractStatusCount(BPMConstants.CONTRACT_STATUS_DID_NOT_QUALIFY, pBusinessProgramTO.getProgramID());

				Calendar lTodayPlusTwoDays = Calendar.getInstance();
				lTodayPlusTwoDays.add(Calendar.DATE, 2);
				
				emailContent = buildLineItemDetail(emailContent, pBusinessProgramTO, pNumberOfQualifieds, pNumberOfNotQualifieds, rowCt);
			}
			
			if (lBusinessProgramsForMembershipList.size() > 0) {
				emailContent.append("</table>");
				emailSubject = buildEmailSubject();
				sendEmail(emailSubject, emailContent);	
			}

		} catch (Exception e) {
			logger.error(
					"Error occurred sending Membership Flag Notification email: "
							+ e.getMessage(), e);
			logger.error("  emailToAddress=" + emailToAddress);
			logger.error("  emailFromAddress=" + emailFromAddress);
			logger.error("  emailSubject=" + emailSubject.toString());
			logger.error("  emailContent=" + emailContent.toString());
			emailSubject.append(" - FAILED");
		}
		
		
	}
	

	/**
	 * 
	 * @param pMemberAdapter
	 * @param pProgramAdapter
	 */
	private void initializeMemberAdapterIncentiveStatuses(MemberAdapter pMemberAdapter, BusinessProgramAdapter pProgramAdapter)
	{
		for(ProgramIncentiveOption lProgramIncentiveOption : pProgramAdapter.getProgramIncentiveOptions())
		{
			String lCurrentMemberStatusForThisIncentive = null;
			String lCurrentContractStatusForThisIncentive = null;
			
			for(MemberContractProgramTO lMemberContractProgramTO : pMemberAdapter.getMember().getMemberContractPrograms())
			{
				if(lMemberContractProgramTO.getProgramIncentiveOptionID().intValue() == lProgramIncentiveOption.getProgramIncentiveOptionID().intValue())
				{
					lCurrentMemberStatusForThisIncentive = lMemberContractProgramTO.getMemberStatus().getStatusCodeValue();
					lCurrentContractStatusForThisIncentive = lMemberContractProgramTO.getMemberContract().getContract().getContractStatus().getStatusCodeValue();
					break;
				}
			}
			
			// If the current member or contract status came out null,
			// check the termed member-contract-program statuses.
			if(lCurrentMemberStatusForThisIncentive == null || lCurrentContractStatusForThisIncentive == null)
			{
				for(MemberContractProgramTO lMemberContractProgramTO : pMemberAdapter.getMember().getMemberTermedContractPrograms())
				{
					if(lMemberContractProgramTO.getProgramIncentiveOptionID().intValue() == lProgramIncentiveOption.getProgramIncentiveOptionID().intValue())
					{
						lCurrentMemberStatusForThisIncentive = lMemberContractProgramTO.getMemberStatus().getStatusCodeValue();
						lCurrentContractStatusForThisIncentive = lMemberContractProgramTO.getMemberContract().getContract().getContractStatus().getStatusCodeValue();
						break;
					}
				}
			}
			
			// Initialized the person- and contract-status for each incentive with the current status
			// that was read from the database in the 
			// selectMemberContractProgramStatus
			// or selectMemberTermedContractProgramStatus
			// queries.
			pMemberAdapter.getPersonIncentiveStatusMap().put(lProgramIncentiveOption.getProgramIncentiveOptionID(), 
			    pMemberAdapter.createPersonIncentiveStatus(pProgramAdapter, lProgramIncentiveOption.getProgramIncentiveOptionID(), 0,  lCurrentMemberStatusForThisIncentive 
			    		, BPMConstants.PROGRAM_INCENTIVE_OPTION_ACTIVATION_NOT_ACTIVE));
			
			pMemberAdapter.getContractIncentiveStatusMap().put(lProgramIncentiveOption.getProgramIncentiveOptionID(), 
				pMemberAdapter.createContractIncentiveStatus(pProgramAdapter, lProgramIncentiveOption.getProgramIncentiveOptionID(), 0, lCurrentContractStatusForThisIncentive
						, BPMConstants.PROGRAM_INCENTIVE_OPTION_ACTIVATION_NOT_ACTIVE));
		}
		
	}
	
	private StringBuffer buildEmailSubject() {
		
			StringBuffer emailSubject = new StringBuffer();
			emailSubject.append("BPM Membership Flag Notification");
			emailSubject.append(" - SUCCESS");
			
			return emailSubject;
	}
	
	private StringBuffer buildDetailHeader(StringBuffer emailContent) {
			
			emailContent.append("<table>");
		    emailContent.append("<tr><td>Row</td>"
					+ "<td>Group</td>"
					+ "<td>Site</td>"
					+ "<td>Benefit Year Start Date</td>"
					+ "<td>Total Contracts</td>"
					+ "<td>Achieved Count</td>"
					+ "<td>% Achieved</td>"
					+ "</tr>");
		    
		    emailContent = addDashBorder(emailContent);
		   
			return emailContent;
	}
	
	private StringBuffer buildMembershipFlagMessage(boolean pReadyForMembership, Calendar membershipProcessDatePrev) {
			
			StringBuffer emailContent = new StringBuffer();
			
			if (pReadyForMembership) {
				emailContent.append("<table>");
			    emailContent.append("<tr><td>Membership Flag will be/has been set: <strong>" + BPMUtils.formatDateMMddyyyy(membershipProcessDatePrev) + "</strong></td></tr>");
			    emailContent.append("<tr><td>For the following Group/Sites with Benefit Differential: <strong></td></tr>");
			    emailContent.append("</table>");
			} else if (membershipProcessDatePrev != null) {
				emailContent.append("<table>");
				 emailContent.append("<tr><td>Membership Flag will be/has been set: <strong>" + BPMUtils.formatDateMMddyyyy(membershipProcessDatePrev) + "</strong></td></tr>");
				emailContent.append("<tr><td>For the following Group/Sites with Benefit Differential: <strong></td></tr>");
				emailContent.append("</table>");
			} else {
				emailContent.append("<table>");
				emailContent.append("<tr><td>Membership Flag has not been set.</td></tr>");
				emailContent.append("<tr><td>For the following Group/Sites with Benefit Differential: <strong></td></tr>");
				emailContent.append("</table>");
			}	
			
			return emailContent;
	}
	
	private StringBuffer buildLineItemDetail(StringBuffer emailContent, BusinessProgramTO pBusinessProgramTO, Integer pNumberOfQualifieds, Integer pNumberOfNotQualifieds, int rowCt) {
			Integer totalContracts = pNumberOfQualifieds.intValue() + pNumberOfNotQualifieds.intValue();

			emailContent.append("<tr>"
								+ "<td>" + rowCt + "</td>"
								+ "<td>" + pBusinessProgramTO.getBusinessProgram().getEmployerGroup().getGroupNumber() + " - " + pBusinessProgramTO.getBusinessProgram().getEmployerGroup().getGroupName() + "</td>"
								+ "<td>" + pBusinessProgramTO.getBusinessProgram().getEmployerGroup().getSiteNumber() + " - " +  pBusinessProgramTO.getBusinessProgram().getEmployerGroup().getSiteName() + "</td>"
								+ "<td align=center>" + BPMUtils.formatDateMMddyyyy(pBusinessProgramTO.getBusinessProgram().getBenefitYearStartDate()) + "</td>"
								+ "<td align=center>" + totalContracts + "</td>"
								+ "<td align=center>" + String.valueOf(pNumberOfQualifieds.intValue()) + "</td>"
								+ "<td align=center>" + String.valueOf((int)(((float)pNumberOfQualifieds.intValue() / totalContracts) * 100)) + "%" + "</td></tr>");
			
			emailContent = addDashBorder(emailContent);
			
			return emailContent;
	}
	
	private StringBuffer addDashBorder(StringBuffer emailContent) {
			emailContent.append("<tr><td colspan=7>---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
			return emailContent;
	}
	
	private void sendEmail(StringBuffer emailSubject, StringBuffer emailContent) {
			
			emailService.setEmailDestination(BPMConstants.EMAIL_DESTINATION_MEMBERSHIP);
			emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
			emailService.prepareAndSendBatchStatusEmail(emailSubject.toString(), emailContent.toString());
	}
	
	/**
	 * Sets the MemberService. Should only be called by Spring.
	 * 
	 * @param service
	 *            the MemberService service
	 */
	public void setMemberService(MemberService service) {
		this.memberService = service;
	}

	/**
	 * Sets the RuleGroupService. Should only be called by Spring.
	 * 
	 * @param service
	 *            the RuleGroupService service
	 */
	public void setRuleGroupService(RuleGroupService service) {
		this.ruleGroupService = service;
	}

	/**
	 * Sets the QualificationOverrideService. Should only be called by Spring.
	 * 
	 * @param service
	 *            the QualificationOverrideService service
	 */
	public void setQualificationOverrideService(
			QualificationOverrideService service) {
		this.qualificationOverrideService = service;
	}

	/*
	 * public void setTxManager(DataSourceTransactionManager txManager) {
	 * this.txManager = txManager; }
	 */

	public QualificationTimeService getQualificationTimeService() {
		return qualificationTimeService;
	}

	public void setQualificationTimeService(
			QualificationTimeService qualificationTimeService) {
		this.qualificationTimeService = qualificationTimeService;
	}

	public ActivityEventLogDAO getActivityEventLogDAO() {
		return activityEventLogDAO;
	}

	public void setActivityEventLogDAO(ActivityEventLogDAO activityEventLogDAO) {
		this.activityEventLogDAO = activityEventLogDAO;
	}

	public TaskEventLogDAO getTaskEventLogDAO() {
		return taskEventLogDAO;
	}

	public void setTaskEventLogDAO(TaskEventLogDAO taskEventLogDAO) {
		this.taskEventLogDAO = taskEventLogDAO;
	}

	public TaskEventService getTaskEventService() {
		return taskEventService;
	}

	public void setTaskEventService(TaskEventService taskEventService) {
		this.taskEventService = taskEventService;
	}

	public MemberService getMemberService() {
		return memberService;
	}

	public QualificationOverrideService getQualificationOverrideService() {
		return qualificationOverrideService;
	}

	public RuleGroupService getRuleGroupService() {
		return ruleGroupService;
	}	


	public LookUpValueDAOJdbc getLookUpValueDAO() {
		return lookUpValueDAO;
	}

	public void setLookUpValueDAO(LookUpValueDAOJdbc lookUpValueDAO) {
		this.lookUpValueDAO = lookUpValueDAO;
	}

	public RiskDAOJdbc getRiskDAO() {
		return riskDAO;
	}

	public void setRiskDAO(RiskDAOJdbc riskDAO) {
		this.riskDAO = riskDAO;
	}

//	public ActivityEventGenerator getActivityEventGenerator() {
//		return activityEventGenerator;
//	}
//
//	public void setActivityEventGenerator(
//			ActivityEventGenerator activityEventGenerator) {
//		this.activityEventGenerator = activityEventGenerator;
//	}

//	public TaskEventGenerator getTaskEventGenerator() {
//		return taskEventGenerator;
//	}
//
//	public void setTaskEventGenerator(TaskEventGenerator taskEventGenerator) {
//		this.taskEventGenerator = taskEventGenerator;
//	}

	public final ContractDAO getContractDAO() {
		return contractDAO;
	}

	public final void setContractDAO(ContractDAO contractDAO) {
		this.contractDAO = contractDAO;
	}

	public PersonDAO getPersonDAO() {
		return personDAO;
	}

	public void setPersonDAO(PersonDAO personDAO) {
		this.personDAO = personDAO;
	}


	public GroupSiteYearStageService getGroupSiteYearStageService() {
		return groupSiteYearStageService;
	}

	public void setGroupSiteYearStageService(
			GroupSiteYearStageService groupSiteYearStageService) {
		this.groupSiteYearStageService = groupSiteYearStageService;
	}

	public BusinessProgramService getBusinessProgramService() {
		return businessProgramService;
	}

	public void setBusinessProgramService(
			BusinessProgramService businessProgramService) {
		this.businessProgramService = businessProgramService;
	}

	public MembershipFeedStageService getMembershipFeedStageService() {
		return membershipFeedStageService;
	}

	public void setMembershipFeedStageService(
			MembershipFeedStageService membershipFeedStageService) {
		this.membershipFeedStageService = membershipFeedStageService;
	}

	public final BusinessProgramDAO getBusinessProgramDAO() {
		return businessProgramDAO;
	}

	public final void setBusinessProgramDAO(BusinessProgramDAO businessProgramDAO) {
		this.businessProgramDAO = businessProgramDAO;
	}

	public EmailService getEmailService() {
		return emailService;
	}

	public void setEmailService(EmailService emailService) {
		this.emailService = emailService;
	}

	public void setLookUpValueService(LookUpValueService lookUpValueService) {
		this.lookUpValueService = lookUpValueService;
	}

	public ProcessingStatusLogDAO getProcessingStatusLogDAO() {
		return processingStatusLogDAO;
	}

	public void setProcessingStatusLogDAO(
			ProcessingStatusLogDAO processingStatusLogDAO) {
		this.processingStatusLogDAO = processingStatusLogDAO;
	}

	public IncentiveOptionDAO getIncentiveOptionDAO() {
		return incentiveOptionDAO;
	}

	public void setIncentiveOptionDAO(IncentiveOptionDAO incentiveOptionDAO) {
		this.incentiveOptionDAO = incentiveOptionDAO;
	}

	public BatchLogDAOJdbc getBatchLogDAO() {
		return batchLogDAO;
	}

	public void setBatchLogDAO(BatchLogDAOJdbc batchLogDAO) {
		this.batchLogDAO = batchLogDAO;
	}

	public CDHPControlGroupDAO getCdhpControlGroupDAO() {
		return cdhpControlGroupDAO;
	}

	public void setCdhpControlGroupDAO(CDHPControlGroupDAO cdhpControlGroupDAO) {
		this.cdhpControlGroupDAO = cdhpControlGroupDAO;
	}



	public void setActivityDAO(ActivityDAO activityDAO) {
		this.activityDAO = activityDAO;
	}

	public void setRewardCardService(RewardCardService rewardCardService) {
		this.rewardCardService = rewardCardService;
	}

	public void setGroupBaselineDAO(GroupBaselineDAO groupBaselineDAO) {

		this.groupBaselineDAO = groupBaselineDAO;
	}

//	public void setClientCallToIntelispendService(
//			ClientCallToIntelispendService clientCallToIntelispendService) {
//		this.clientCallToIntelispendService = clientCallToIntelispendService;
//	}

	public void setActivityEventCreationBasedOnPreconditionService(
			ActivityEventCreationBasedOnPreconditionService activityEventCreationBasedOnPreconditionService) {
		this.activityEventCreationBasedOnPreconditionService = activityEventCreationBasedOnPreconditionService;
	}

	public CallEmployerGroupSiteSetup getCallEmployerGroupSiteSetup() {
		return callEmployerGroupSiteSetup;
	}

	public void setCallEmployerGroupSiteSetup(
			CallEmployerGroupSiteSetup callEmployerGroupSiteSetup) {
		this.callEmployerGroupSiteSetup = callEmployerGroupSiteSetup;
	}

	public CallEmployerGroupBaselineSetup getCallEmployerGroupBaselineSetup() {
		return callEmployerGroupBaselineSetup;
	}

	public void setCallEmployerGroupBaselineSetup(
			CallEmployerGroupBaselineSetup callEmployerGroupBaselineSetup) {
		this.callEmployerGroupBaselineSetup = callEmployerGroupBaselineSetup;
	}

	public CallPopulateMissingPeople getCallPopulateMissingPeople() {
		return callPopulateMissingPeople;
	}

	public void setCallPopulateMissingPeople(
			CallPopulateMissingPeople callPopulateMissingPeople) {
		this.callPopulateMissingPeople = callPopulateMissingPeople;
	}

	public CallPopulateMissingPersonProgramActivities getCallPopulateMissingPersonProgramActivities() {
		return callPopulateMissingPersonProgramActivities;
	}

	public void setCallPopulateMissingPersonProgramActivities(CallPopulateMissingPersonProgramActivities callPopulateMissingPersonProgramActivities) {
		this.callPopulateMissingPersonProgramActivities = callPopulateMissingPersonProgramActivities;
	}

    public CallRecalcDualCoveredPersons getCallRecalcDualCoveredPersons() {
        return callRecalcDualCoveredPersons;
    }

    public void setCallRecalcDualCoveredPersons(CallRecalcDualCoveredPersons callRecalcDualCoveredPersons) {
        this.callRecalcDualCoveredPersons = callRecalcDualCoveredPersons;
    }

    public void setActivityEventService(ActivityEventService activityEventService) {
		this.activityEventService = activityEventService;
	}

	public CallDeleteTermedParticipants getCallDeleteTermedParticipants() {
		return callDeleteTermedParticipants;
	}

	public void setCallDeleteTermedParticipants(
			CallDeleteTermedParticipants callDeleteTermedParticipants) {
		this.callDeleteTermedParticipants = callDeleteTermedParticipants;
	}

	public void setUploadEmployerActivityPreprocessService(
			UploadEmployerActivityPreprocessService uploadEmployerActivityPreprocessService) {
		this.uploadEmployerActivityPreprocessService = uploadEmployerActivityPreprocessService;
	}

	public void setUploadEmployerActivityPostprocessService(
			UploadEmployerActivityPostprocessService uploadEmployerActivityPostprocessService) {
		this.uploadEmployerActivityPostprocessService = uploadEmployerActivityPostprocessService;
	}
	
	

	public void setUploadEmployerActivityIncentToFulfillReconService(
			UploadEmployerActivityIncentToFulfillReconService uploadEmployerActivityIncentToFulfillReconService) {
		this.uploadEmployerActivityIncentToFulfillReconService = uploadEmployerActivityIncentToFulfillReconService;
	}
	
	

	public void setResetActivityEventsFromInprocessToPendingService(
			ResetActivityEventsFromInprocessToPendingService resetActivityEventsFromInprocessToPendingService) {
		this.resetActivityEventsFromInprocessToPendingService = resetActivityEventsFromInprocessToPendingService;
	}

	public CallDeleteTermedByGroup getCallDeleteTermedByGroup() {
		return callDeleteTermedByGroup;
	}

	public void setCallDeleteTermedByGroup(
			CallDeleteTermedByGroup callDeleteTermedByGroup) {
		this.callDeleteTermedByGroup = callDeleteTermedByGroup;
	}

	public CallPopulatePackageBaseline getCallPopulatePackageBaseline() {
		return callPopulatePackageBaseline;
	}

	public void setCallPopulatePackageBaseline(
			CallPopulatePackageBaseline callPopulatePackageBaseline) {
		this.callPopulatePackageBaseline = callPopulatePackageBaseline;
	}

	public CallFilteredOutActivity getCallFilteredOutActivity() {
		return callFilteredOutActivity;
	}

	public void setCallFilteredOutActivity(
			CallFilteredOutActivity callFilteredOutActivity) {
		this.callFilteredOutActivity = callFilteredOutActivity;
	}

	public CallEndedGroups getCallEndedGroups() {
		return callEndedGroups;
	}

	public void setCallEndedGroups(CallEndedGroups callEndedGroups) {
		this.callEndedGroups = callEndedGroups;
	}

	public CallEndedGroupsBizSetup getCallEndedGroupsBizSetup() {
		return callEndedGroupsBizSetup;
	}

	public void setCallEndedGroupsBizSetup(
			CallEndedGroupsBizSetup callEndedGroupsBizSetup) {
		this.callEndedGroupsBizSetup = callEndedGroupsBizSetup;
	}

	public CallChangedMarketEZ getCallChangedMarketEZ() {
		return callChangedMarketEZ;
	}

	public void setCallChangedMarketEZ(CallChangedMarketEZ callChangedMarketEZ) {
		this.callChangedMarketEZ = callChangedMarketEZ;
	}

	public CallChangedMarketNonEZ getCallChangedMarketNonEZ() {
		return callChangedMarketNonEZ;
	}

	public void setCallChangedMarketNonEZ(
			CallChangedMarketNonEZ callChangedMarketNonEZ) {
		this.callChangedMarketNonEZ = callChangedMarketNonEZ;
	}

	public CallEndedMedical getCallEndedMedical() {
		return callEndedMedical;
	}

	public void setCallEndedMedical(CallEndedMedical callEndedMedical) {
		this.callEndedMedical = callEndedMedical;
	}

	public void setReprocessUnresolvedBenefitContractTypeForActivityIncentivesService(
			ReprocessUnresolvedBenefitContractTypeForActivityIncentivesService reprocessUnresolvedBenefitContractTypeForActivityIncentivesService) {
		this.reprocessUnresolvedBenefitContractTypeForActivityIncentivesService = reprocessUnresolvedBenefitContractTypeForActivityIncentivesService;
	}

	public void setPersonContractActivityToContribGridReconService(
			PersonContractActivityToContribGridReconService personContractActivityToContribGridReconService) {
		this.personContractActivityToContribGridReconService = personContractActivityToContribGridReconService;
	}

	public void setEmployerActivityReconciliationService(
			EmployerActivityReconciliationService employerActivityReconciliationService) {
		this.employerActivityReconciliationService = employerActivityReconciliationService;
	}
	
	

	public void setArchivePersonContractProgramHistoryService(
			ArchivePersonContractProgramHistoryService archivePersonContractProgramHistoryService) {
		this.archivePersonContractProgramHistoryService = archivePersonContractProgramHistoryService;
	}
	
	

	public void setPersonContractRecycleReportService(
			PersonContractRecycleReportService personContractRecycleReportService) {
		this.personContractRecycleReportService = personContractRecycleReportService;
	}

	public final EmployerActivityReconciliationService getEmployerActivityReconciliationService() {
		return employerActivityReconciliationService;
	}

	public CallCorrectPurchaserSubtype getCallCorrectPurchaserSubtype() {
		return callCorrectPurchaserSubtype;
	}

	public void setCallCorrectPurchaserSubtype(
			CallCorrectPurchaserSubtype callCorrectPurchaserSubtype) {
		this.callCorrectPurchaserSubtype = callCorrectPurchaserSubtype;
	}

	public final IncentivePackageRuleDAO getIncentivePackageRuleDAO() {
		return incentivePackageRuleDAO;
	}

	public final void setIncentivePackageRuleDAO(
			IncentivePackageRuleDAO incentivePackageRuleDAO) {
		this.incentivePackageRuleDAO = incentivePackageRuleDAO;
	}

	public String getErrorMessageFromVendorWebservice() {
		return errorMessageFromVendorWebservice;
	}

	public void setErrorMessageFromVendorWebservice(String errorMessageFromVendorWebservice) {
		this.errorMessageFromVendorWebservice = errorMessageFromVendorWebservice;
	}

}
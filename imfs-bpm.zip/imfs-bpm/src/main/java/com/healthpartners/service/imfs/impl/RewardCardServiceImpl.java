/* $Id: RuleGroupServiceImpl.java 153225 2008-01-16 19:56:08Z tjquist $ */

package com.healthpartners.service.imfs.impl;


import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dao.PersonDAO;
import com.healthpartners.service.imfs.dao.RewardCardDAO;
import com.healthpartners.service.imfs.dao.RewardControlProgramDAO;
import com.healthpartners.service.imfs.dto.BPMBusinessProgram;
import com.healthpartners.service.imfs.dto.LookUpValueCode;
import com.healthpartners.service.imfs.dto.PersonActivityAchievedReward;
import com.healthpartners.service.imfs.dto.RewardCardAddress;
import com.healthpartners.service.imfs.dto.RewardCardClientData;
import com.healthpartners.service.imfs.dto.RewardCardQuote;
import com.healthpartners.service.imfs.dto.RewardCardQuoteByProgramSummary;
import com.healthpartners.service.imfs.dto.RewardCardRecycleDetail;
import com.healthpartners.service.imfs.dto.RewardControlProgram;
import com.healthpartners.service.imfs.dto.RewardControlProgramProcessTracker;
import com.healthpartners.service.imfs.dto.RewardFulfillmentTrackingRecycle;
import com.healthpartners.service.imfs.dto.RewardFulfillmentTrackingReportHist;
import com.healthpartners.service.imfs.dto.RewardIntelispendOrdered;
import com.healthpartners.service.imfs.dto.RewardIntelispendShipped;
import com.healthpartners.service.imfs.exception.BPMBusinessValidationException;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.iface.LookUpValueService;
import com.healthpartners.service.imfs.iface.RewardCardService;



/**
 * @author tjquist
 * 
 */
@Component
@Service
public class RewardCardServiceImpl implements RewardCardService {

	protected final Logger logger = Logger.getLogger(this.getClass());
	@Autowired
	private RewardCardDAO rewardCardDAO;
	@Autowired
	private RewardControlProgramDAO rewardControlProgramDAO;
	@Autowired
	private PersonDAO personDAO;
	@Autowired
	private LookUpValueService lookUpValueService;
	
	
	/**
	 * Transaction manager data source
	 */

	private DataSourceTransactionManager txManager;

	
	@Transactional(timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public Collection<RewardCardQuote> getQuotesFromBusProgramsWithRewardCards() throws BPMException {
		
		Collection<RewardCardQuote> lRewardCardQuotes = null;
		
		try {
			lRewardCardQuotes = rewardCardDAO.getQuotesFromBusProgramsWithRewardCards();
		} catch (DataAccessException dae) {
			//txManager.rollback(status);
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		} catch (BPMException ve) {
			//txManager.rollback(status);
			logger.error("BPMException: " + ve.getMessage(), ve);
			throw ve;
		} catch (Exception e) {
			//txManager.rollback(status);
			logger.error("BPMException: " + e.getMessage(), e);
			throw new BPMException(e);
		}
		
		return lRewardCardQuotes;
		
	}
	
	@Transactional(timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public Collection<RewardControlProgram> getRewardControlPrograms(String quoteID) throws BPMException {
		
		Collection<RewardControlProgram> lRewardControlPrograms = null;
		
		try {
			lRewardControlPrograms = rewardControlProgramDAO.getRewardControlPrograms(quoteID);
		} catch (DataAccessException dae) {
			//txManager.rollback(status);
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		} catch (Exception e) {
			//txManager.rollback(status);
			logger.error("BPMException: " + e.getMessage(), e);
			throw new BPMException(e);
		}
		
		return lRewardControlPrograms;
	}
	
	@Transactional(timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public boolean isRewardFulfillOnHoldOrDenied(Integer rewardTransHistID) throws BPMException {
		
		boolean isOnHoldOrDenied = false;
		
		Collection<RewardFulfillmentTrackingRecycle> lRewardFulfillmentTrackingRecycleRecs = null;
		
		try {
			lRewardFulfillmentTrackingRecycleRecs = rewardCardDAO.getRewardFulfillRecycle(rewardTransHistID);
			for (RewardFulfillmentTrackingRecycle lRewardFulfillmentTrackingRecycle : lRewardFulfillmentTrackingRecycleRecs) {
				if (lRewardFulfillmentTrackingRecycle.getRecycleStatus().equals(BPMConstants.REWARD_RECYCLE_STATUS_ON_HOLD) ||
						lRewardFulfillmentTrackingRecycle.getRecycleStatus().equals(BPMConstants.REWARD_RECYCLE_STATUS_DENIED)) {
					isOnHoldOrDenied = true;
					break;
				} 
			}
		} catch (DataAccessException dae) {
			//txManager.rollback(status);
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		} catch (Exception e) {
			//txManager.rollback(status);
			logger.error("BPMException: " + e.getMessage(), e);
			throw new BPMException(e);
		}
		
		
		return isOnHoldOrDenied;
	}
	
	@Transactional(timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public boolean isRewardFulfillApproved(Integer rewardTransHistID) throws BPMException {
		
		boolean isApproved = false;
		
		Collection<RewardFulfillmentTrackingRecycle> lRewardFulfillmentTrackingRecycleRecs = null;
		
		try {
			lRewardFulfillmentTrackingRecycleRecs = rewardCardDAO.getRewardFulfillRecycle(rewardTransHistID);
			for (RewardFulfillmentTrackingRecycle lRewardFulfillmentTrackingRecycle : lRewardFulfillmentTrackingRecycleRecs) {
				 if (lRewardFulfillmentTrackingRecycle.getRecycleStatus().equals(BPMConstants.REWARD_RECYCLE_STATUS_APPROVED)) {
						   //Update to released
					LookUpValueCode releaseLUV = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.BPM_REWARD_RECYCLE_STATUS, BPMConstants.REWARD_RECYCLE_STATUS_RELEASED);
					Integer recycleStatusId = releaseLUV.getLuvId();
					lRewardFulfillmentTrackingRecycle.setRecycleStatusId(recycleStatusId);
					rewardCardDAO.updateRewardFulfillRecycleStatus(lRewardFulfillmentTrackingRecycle);
					isApproved = true;
				}
			}
		} catch (DataAccessException dae) {
			//txManager.rollback(status);
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		} catch (Exception e) {
			//txManager.rollback(status);
			logger.error("BPMException: " + e.getMessage(), e);
			throw new BPMException(e);
		}
		
		return isApproved;
	}
	
	@Transactional(timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public Collection<RewardFulfillmentTrackingRecycle> getRewardFulfillRecycle(int rewardTransHistID)
			throws DataAccessException {
	
		Collection<RewardFulfillmentTrackingRecycle> lRewardFulfillmentTrackingRecycles = null;
		
		try {
			lRewardFulfillmentTrackingRecycles = rewardCardDAO.getRewardFulfillRecycle(rewardTransHistID);
			
		} catch (DataAccessException dae) {
			//txManager.rollback(status);
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		} 
		
		return lRewardFulfillmentTrackingRecycles;
	}
	
	@Transactional(timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public boolean doesErrorExistInRewardRecycle(Integer rewardTransHistID, String itemNo) throws BPMException {
		
		boolean isAlreadyOnHold = false;
		
		try {
			isAlreadyOnHold = rewardCardDAO.doesErrorExistInRewardRecycle(rewardTransHistID, itemNo);
			
		} catch (DataAccessException dae) {
			//txManager.rollback(status);
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		} catch (Exception e) {
			//txManager.rollback(status);
			logger.error("BPMException: " + e.getMessage(), e);
			throw new BPMException(e);
		}
		
		return isAlreadyOnHold;
	}
	
	/*
	 * This method is called to determine if transactions returned in error from Intelispend already exist in an ON HOLD status on the error recycle.
	 * If yes, then update the recycle records so that the modify date becomes todays date.  This will allow these transactions to show up on the
	 * error report produced for the e-mail notification.
	 */
	@Transactional(timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public boolean doesErrorExistInRewardRecycle(Integer rewardTransHistID) throws BPMException {
		
		boolean isAlreadyOnHold = false;
		Integer rewardRecycleID = null;
		Collection<RewardFulfillmentTrackingRecycle> lRewardFulfillmentTrackingRecycles = null;
		
		try {
			lRewardFulfillmentTrackingRecycles = rewardCardDAO.getRewardFulfillRecycle(rewardTransHistID);
			
		} catch (DataAccessException dae) {
			//txManager.rollback(status);
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		} catch (Exception e) {
			logger.error("BPMException: " + e.getMessage(), e);
			throw new BPMException(e);
		}
		
		
		for (RewardFulfillmentTrackingRecycle lRewardFulfillmentTrackingRecycle : lRewardFulfillmentTrackingRecycles) {
			if (rewardRecycleID != null) {
				//Update record with todays date so shows up on ON HOLD detail report of e-mail notification.
				LookUpValueCode releaseLUV = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.BPM_REWARD_RECYCLE_STATUS, BPMConstants.REWARD_RECYCLE_STATUS_ON_HOLD);
				Integer recycleStatusId = releaseLUV.getLuvId();
				lRewardFulfillmentTrackingRecycle.setRecycleStatusId(recycleStatusId);
				lRewardFulfillmentTrackingRecycle.setRewardRecycleId(rewardRecycleID);
				this.updateRewardFulfillRecycleStatus(lRewardFulfillmentTrackingRecycle);
				isAlreadyOnHold = true;
			}
		}
		
		
		
		return isAlreadyOnHold;
	}
	
	@Transactional(timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public Collection<RewardCardRecycleDetail> getRewardRecycleByProgramOnHold(Integer programID, java.sql.Date selectionDate)
			throws DataAccessException {
		Collection<RewardCardRecycleDetail> lRewardCardRecycleDetails = null;
		
		try {
			lRewardCardRecycleDetails = rewardCardDAO.getRewardRecycleByProgramOnHold(programID, selectionDate);
		} catch (DataAccessException dae) {
			//txManager.rollback(status);
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		} 
		
		return lRewardCardRecycleDetails;
	}
	
	@Transactional(timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public Integer getProgramByRewardFulfillTransHistID(Integer fulfillTransHistID)
	{
		Integer programID = null;
		
		try {
			programID = personDAO.getProgramByRewardFulfillTransHistID(fulfillTransHistID);
		} catch (DataAccessException dae) {
			//txManager.rollback(status);
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		} 
		
		return programID;
	}
	@Transactional(timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	private RewardCardAddress getRewarCardAddress(Integer rewardTransHistID, Integer programID, Integer personDemographicsID, Integer incentiveOptionID) throws DataAccessException, BPMException {
		RewardCardAddress lRewardCardAddress = null;
		
		try {
			lRewardCardAddress = rewardCardDAO.getRewarCardAddress(rewardTransHistID, programID, personDemographicsID, incentiveOptionID);
			
			if (lRewardCardAddress.getRewardTransHistID() == null) {
				//check for site transfer which Titan webervice
				//is not handling when sending in reward card addresses into BPM.
				boolean pOnlyCurrentBusinessPrograms = true;
				boolean pAllowBusinessProgramSiteTransfers = true;
				Integer programIDSiteTransferredFrom = evaluateForSiteTransfer(programID, personDemographicsID, incentiveOptionID, pOnlyCurrentBusinessPrograms, pAllowBusinessProgramSiteTransfers);
				//site transfer occurred if a program id is returned.
				if (programIDSiteTransferredFrom != null) {
					lRewardCardAddress = rewardCardDAO.getRewarCardAddress(rewardTransHistID, programIDSiteTransferredFrom, personDemographicsID, incentiveOptionID);
				}
			}
		} catch (DataAccessException dae) {
			//txManager.rollback(status);
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		} catch (BPMException ve) {
			//txManager.rollback(status);
			logger.error("BPMException: " + ve.getMessage(), ve);
			throw ve;
		} catch (Exception e) {
			//txManager.rollback(status);
			logger.error("BPMException: " + e.getMessage(), e);
			throw new BPMException(e);
		}
		
		return lRewardCardAddress;
		
	}

	@Transactional(timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	private RewardCardAddress getRewardCardAddressUsingMODS(Integer personDemographicsID) throws DataAccessException, BPMException {
		RewardCardAddress lRewardCardAddress = null;

		try {
			lRewardCardAddress = rewardCardDAO.getPersonAddressUsingMODS(personDemographicsID);
		} catch (DataAccessException dae) {
			//txManager.rollback(status);
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		} catch (BPMException ve) {
			//txManager.rollback(status);
			logger.error("BPMException: " + ve.getMessage(), ve);
			throw ve;
		} catch (Exception e) {
			//txManager.rollback(status);
			logger.error("BPMException: " + e.getMessage(), e);
			throw new BPMException(e);
		}

		return lRewardCardAddress;

	}
	
	private Integer evaluateForSiteTransfer(Integer programID, Integer pPersonDemographicsID, Integer incentiveOptionID, boolean pOnlyCurrentBusinessPrograms, boolean pAllowBusinessProgramSiteTransfers) 
			throws DataAccessException, BPMException {
		
		Integer programIDFromTermedSiteForMember = null;
		
		Collection<BPMBusinessProgram> lBPMBusinessPrograms = findPersonProgram(pPersonDemographicsID, pOnlyCurrentBusinessPrograms, pAllowBusinessProgramSiteTransfers);
		
		//There should always be more than one program returned
		//if a site transfer exists for a participant.
		if (lBPMBusinessPrograms.size() > 1) {
			//1. Identify the business program or site the participant transferred to 
			//	 and was assigned to the reward card address record.
			//   Looking to assign the correct business program that represents the
			//   site the participant transferred from.
			Integer rewardCardAddressID = null;
			Integer rewardTransHistID = null;
			for (BPMBusinessProgram lBPMBusinessProgram : lBPMBusinessPrograms) {
				if (lBPMBusinessProgram.getProgramID() != programID.intValue() && lBPMBusinessProgram.getSiteEndDate().after(lBPMBusinessProgram.getEndDate())) {
					Integer programIDSiteTransferredTo = lBPMBusinessProgram.getProgramID();
					RewardCardAddress lRewardCardAddress = rewardCardDAO.getRewarCardAddress(programIDSiteTransferredTo, pPersonDemographicsID, incentiveOptionID);
					if (lRewardCardAddress.getRewardCardAddressID() != null) {
						rewardCardAddressID = lRewardCardAddress.getRewardCardAddressID();
						rewardTransHistID = lRewardCardAddress.getRewardTransHistID();
						break;
					}
				}
			}
			//2. Determine business program member transferred from if a reward card address was identified.
			if (rewardCardAddressID != null) {
				for (BPMBusinessProgram lBPMBusinessProgram : lBPMBusinessPrograms) {
					if (lBPMBusinessProgram.getProgramID() == programID.intValue()) {
						if (lBPMBusinessProgram.getSiteEndDate().before(lBPMBusinessProgram.getEndDate())) {
							//program member transferred from identified.
							//update reward address with correct program id if condition met.
							//Note: if address already verified, bypass update.
							if ((rewardTransHistID == null || rewardTransHistID == 0) || !isStatusAlreadyExist(rewardTransHistID, BPMConstants.ADDRESS_VERIFIED)) {
								rewardCardDAO.updateRewardCardAddressWithProgramID(rewardCardAddressID, programID);
								programIDFromTermedSiteForMember = programID;
								break;
							}
						}
					}
				}
			}
		}
		
		
		return programIDFromTermedSiteForMember;
	}
		
	

	protected Collection<BPMBusinessProgram> findPersonProgram(Integer pPersonDemographicsID, boolean pOnlyCurrentBusinessPrograms, boolean pAllowBusinessProgramSiteTransfers)
	throws BPMException
	{
	
		Collection<BPMBusinessProgram> lBPMBusinessPrograms = personDAO.getPersonBusinessPrograms(pPersonDemographicsID, pOnlyCurrentBusinessPrograms, pAllowBusinessProgramSiteTransfers);
	    
	  
	    return lBPMBusinessPrograms;
	}
	
	@Transactional(timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public RewardControlProgramProcessTracker getRewardControlProgramProcessTracker(Integer rewardTransHistID) throws DataAccessException, BPMException {
		RewardControlProgramProcessTracker lRewardControlProgramProcessTracker = null;
		
		try {
			lRewardControlProgramProcessTracker = rewardControlProgramDAO.getRewardControlProgramProcessTracker(rewardTransHistID);
		} catch (DataAccessException dae) {
			//txManager.rollback(status);
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		} catch (Exception e) {
			//txManager.rollback(status);
			logger.error("BPMException: " + e.getMessage(), e);
			throw new BPMException(e);
		}
		
		return lRewardControlProgramProcessTracker;
		
	}
	
	 /*
	   * Check to see if latest reward fulfillement status already exists. 
	   */
	  public boolean isStatusAlreadyExist(Integer rewardTransHistID, String rewardStatusDesc) throws BPMException {
			
			boolean statusExists = false;
			
			LookUpValueCode lLookUpValueCode = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.REWARD_CARD_STATUS_TP, rewardStatusDesc);
			Integer rewardStatusID = lLookUpValueCode.getLuvId();
			
			String rewardStatusDescResult = findLatestRewardFulfillStatus(rewardTransHistID, rewardStatusID);
			
			if (rewardStatusDescResult.equals(rewardStatusDesc)) {
				statusExists = true;
			}
			
			return statusExists;
	  }
	  
	
	/*
	 * Assign name and address information stored out on the reward card address table 
	 * to the reward fulfillment transaction.  If not found, write to error recylce and remove entry from collection since address
	 * information is required.
	 */
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public Collection<RewardFulfillmentTrackingReportHist> assignAddressWhereToSendRewardCard(Collection<RewardFulfillmentTrackingReportHist> lRewardFulfillmentHistoryTrackingRpts, 
												RewardCardQuoteByProgramSummary lRewardCardQuoteByProgramSummary, RewardControlProgram lRewardControlProgram)
															throws BPMException {
		
		ArrayList<RewardFulfillmentTrackingReportHist> lRewardFulfillmentHistoryTrackingRptsWithAddresses = new ArrayList<RewardFulfillmentTrackingReportHist>();
				
		
		for (RewardFulfillmentTrackingReportHist lRewardFulfillmentTrackingReportHist : lRewardFulfillmentHistoryTrackingRpts) {

			Integer rewardTransID = lRewardFulfillmentTrackingReportHist.getRewardTransHistID();
			Integer programID = lRewardFulfillmentTrackingReportHist.getProgramID();
			Integer personDemographicsID = lRewardFulfillmentTrackingReportHist.getPersonDemographicsID();
			Integer incentiveOptionID = lRewardFulfillmentTrackingReportHist.getIncentiveOptionID();
			
			try {
				RewardCardAddress lRewardCardAddress = getRewarCardAddress(rewardTransID, programID, personDemographicsID, incentiveOptionID);
				if (lRewardCardAddress.getRewardTransHistID() == null || lRewardCardAddress.getRewardTransHistID().intValue() == 0) {
					lRewardCardAddress.setRewardTransHistID(rewardTransID);
					rewardCardDAO.updateRewardCardAddressWMissingTransHistID(lRewardCardAddress);
				}
				
				if (lRewardCardAddress != null && lRewardCardAddress.getCity() != null) {
					
					lRewardFulfillmentTrackingReportHist.setFirstName(lRewardCardAddress.getFirstName());
					lRewardFulfillmentTrackingReportHist.setMiddleInit(lRewardCardAddress.getMiddleInit());
					lRewardFulfillmentTrackingReportHist.setLastName(lRewardCardAddress.getLastName());
					lRewardFulfillmentTrackingReportHist.setAddressLine1(lRewardCardAddress.getAddressLine1());
					lRewardFulfillmentTrackingReportHist.setAddressLine2(lRewardCardAddress.getAddressLine2());
					lRewardFulfillmentTrackingReportHist.setCity(lRewardCardAddress.getCity());
					lRewardFulfillmentTrackingReportHist.setState(lRewardCardAddress.getStatCode());
					lRewardFulfillmentTrackingReportHist.setZip(lRewardCardAddress.getPostalCode());
					lRewardFulfillmentTrackingReportHist.setExtendedZip(lRewardCardAddress.getPostalCodeExt());
					lRewardFulfillmentTrackingReportHist.setCountryCode(lRewardCardAddress.getCountryCode());
					
					LookUpValueCode rewardTrackingStatusLUV = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.REWARD_CARD_STATUS_TP, BPMConstants.ADDRESS_VERIFIED);
					Integer reasonCodeID = rewardTrackingStatusLUV.getLuvId();
					lRewardFulfillmentTrackingReportHist.setReasonCodeID(Integer.toString(reasonCodeID));
					
					//Add reward card status of ADDRESS_VERIFIED.
					this.insertRewardFulfillmentStatus(lRewardFulfillmentTrackingReportHist, BPMConstants.BPM_USER_SYSTEM);
					lRewardFulfillmentHistoryTrackingRptsWithAddresses.add(lRewardFulfillmentTrackingReportHist);
				} else {
					//modified date needs to be updated so fulfill transaction reprocesses in the next batch run
					personDAO.updateRewardFulfillmentHistWTodaysDate(rewardTransID);
					
					//EV89263 - if outside of program incentive option effective dates, then stop logging awaiting address statuses.
					Date currentDate = BPMUtils.getCurrentDate();
					if (BPMUtils.isBetweenDates(currentDate, lRewardControlProgram.getProgramIncentiveOptionEffectiveDate(), lRewardControlProgram.getProgramIncentiveOptionEndDate()) ) {
						//Add reward card status of AWAITING_ADDRESS.
						LookUpValueCode rewardTrackingStatusLUV = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.REWARD_CARD_STATUS_TP, BPMConstants.AWAITING_ADDRESS);
						Integer reasonCodeID = rewardTrackingStatusLUV.getLuvId();
						lRewardFulfillmentTrackingReportHist.setReasonCodeID(Integer.toString(reasonCodeID));
						this.insertRewardFulfillmentStatus(lRewardFulfillmentTrackingReportHist, BPMConstants.BPM_USER_SYSTEM);
						//lRewardCardQuoteByProgramSummary is passed by reference
						recordToProgramMissingAddressSummaryMap(lRewardCardQuoteByProgramSummary.getProgramMissingAddressSummaryMap(), lRewardFulfillmentTrackingReportHist);
					}
					
					
				}
			} catch (BPMException e) {
				throw e;
			}		
		}
		
		//Remove reward fulfillment objects with no addresses;
		if (lRewardFulfillmentHistoryTrackingRptsWithAddresses.size() > 0) {
			return lRewardFulfillmentHistoryTrackingRptsWithAddresses;
		} else {
			//if no addresses found, remove all fullfillment records from collection.
			lRewardFulfillmentHistoryTrackingRpts.clear();
			return lRewardFulfillmentHistoryTrackingRpts;
		}
			
	}

	/*
	 * Assign name and address from Datawarehouse
	 * to the reward fulfillment transaction.  If not found, write to error recycle and remove entry from collection since address
	 * information is required.
	 */
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public Collection<RewardFulfillmentTrackingReportHist> assignAddressUsingMODSWhereToSendRewardCard(Collection<RewardFulfillmentTrackingReportHist> lRewardFulfillmentHistoryTrackingRpts,
																							  RewardCardQuoteByProgramSummary lRewardCardQuoteByProgramSummary, RewardControlProgram lRewardControlProgram)
			throws BPMException {

		ArrayList<RewardFulfillmentTrackingReportHist> lRewardFulfillmentHistoryTrackingRptsWithAddresses = new ArrayList<RewardFulfillmentTrackingReportHist>();


		for (RewardFulfillmentTrackingReportHist lRewardFulfillmentTrackingReportHist : lRewardFulfillmentHistoryTrackingRpts) {

			Integer rewardTransID = lRewardFulfillmentTrackingReportHist.getRewardTransHistID();
			Integer personDemographicsID = lRewardFulfillmentTrackingReportHist.getPersonDemographicsID();

			try {
				RewardCardAddress lRewardCardAddress = getRewardCardAddressUsingMODS(personDemographicsID);

				if (lRewardCardAddress != null && lRewardCardAddress.getCity() != null) {

					lRewardFulfillmentTrackingReportHist.setFirstName(lRewardCardAddress.getFirstName());
					lRewardFulfillmentTrackingReportHist.setMiddleInit(lRewardCardAddress.getMiddleInit());
					lRewardFulfillmentTrackingReportHist.setLastName(lRewardCardAddress.getLastName());
					lRewardFulfillmentTrackingReportHist.setAddressLine1(lRewardCardAddress.getAddressLine1());
					lRewardFulfillmentTrackingReportHist.setAddressLine2(lRewardCardAddress.getAddressLine2());
					lRewardFulfillmentTrackingReportHist.setCity(lRewardCardAddress.getCity());
					lRewardFulfillmentTrackingReportHist.setState(lRewardCardAddress.getStatCode());
					lRewardFulfillmentTrackingReportHist.setZip(lRewardCardAddress.getPostalCode());
					lRewardFulfillmentTrackingReportHist.setExtendedZip(lRewardCardAddress.getPostalCodeExt());

					LookUpValueCode rewardTrackingStatusLUV = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.REWARD_CARD_STATUS_TP, BPMConstants.ADDRESS_VERIFIED);
					Integer reasonCodeID = rewardTrackingStatusLUV.getLuvId();
					lRewardFulfillmentTrackingReportHist.setReasonCodeID(Integer.toString(reasonCodeID));

					//Add reward card status of ADDRESS_VERIFIED.
					this.insertRewardFulfillmentStatus(lRewardFulfillmentTrackingReportHist, BPMConstants.BPM_USER_SYSTEM);
					lRewardFulfillmentHistoryTrackingRptsWithAddresses.add(lRewardFulfillmentTrackingReportHist);
				} else {
					//modified date needs to be updated so fulfill transaction reprocesses in the next batch run
					personDAO.updateRewardFulfillmentHistWTodaysDate(rewardTransID);

					//EV89263 - if outside of program incentive option effective dates, then stop logging awaiting address statuses.
					Date currentDate = BPMUtils.getCurrentDate();
					if (BPMUtils.isBetweenDates(currentDate, lRewardControlProgram.getProgramIncentiveOptionEffectiveDate(), lRewardControlProgram.getProgramIncentiveOptionEndDate()) ) {
						//Add reward card status of AWAITING_ADDRESS.
						LookUpValueCode rewardTrackingStatusLUV = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.REWARD_CARD_STATUS_TP, BPMConstants.AWAITING_ADDRESS);
						Integer reasonCodeID = rewardTrackingStatusLUV.getLuvId();
						lRewardFulfillmentTrackingReportHist.setReasonCodeID(Integer.toString(reasonCodeID));
						this.insertRewardFulfillmentStatus(lRewardFulfillmentTrackingReportHist, BPMConstants.BPM_USER_SYSTEM);
						//lRewardCardQuoteByProgramSummary is passed by reference
						recordToProgramMissingAddressSummaryMap(lRewardCardQuoteByProgramSummary.getProgramMissingAddressSummaryMap(), lRewardFulfillmentTrackingReportHist);
					}


				}
			} catch (BPMException e) {
				throw e;
			}
		}

		//Remove reward fulfillment objects with no addresses;
		if (lRewardFulfillmentHistoryTrackingRptsWithAddresses.size() > 0) {
			return lRewardFulfillmentHistoryTrackingRptsWithAddresses;
		} else {
			//if no addresses found, remove all fullfillment records from collection.
			lRewardFulfillmentHistoryTrackingRpts.clear();
			return lRewardFulfillmentHistoryTrackingRpts;
		}

	}
	
	/*
	   * Get a count by program of transactions bypassed because it exists on the recycle table.  HashMap will be later used to produce a summary report.
	   */
	  private  HashMap<Integer, Integer> recordToProgramMissingAddressSummaryMap(HashMap<Integer, Integer> programMissingAddressSummaryMap, RewardFulfillmentTrackingReportHist lRewardFulfillmentTrackingReportHist) {
		  int programMissingAddressCt = 0;
		  
		  if (programMissingAddressSummaryMap.containsKey(lRewardFulfillmentTrackingReportHist.getProgramID())) {
			  programMissingAddressCt = programMissingAddressSummaryMap.get(lRewardFulfillmentTrackingReportHist.getProgramID());
			  programMissingAddressCt++;
			  programMissingAddressSummaryMap.put(lRewardFulfillmentTrackingReportHist.getProgramID(), programMissingAddressCt);
		  } else {
			  programMissingAddressCt++;
			  programMissingAddressSummaryMap.put(lRewardFulfillmentTrackingReportHist.getProgramID(), programMissingAddressCt);
		  }
			  
		  
		  
		  return programMissingAddressSummaryMap;
	  }
	  
	
	 
  @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public int updateRewardFulfillmentHistWithTodaysDate(Integer rewardTransHistID) throws DataAccessException, BPMException {
		
		int recUpdated = 0;
		
		try {
			recUpdated = personDAO.updateRewardFulfillmentHistWTodaysDate(rewardTransHistID);
		} catch (DataAccessException dae) {
			//txManager.rollback(status);
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		} catch (Exception e) {
			//txManager.rollback(status);
			logger.error("BPMException: " + e.getMessage(), e);
			throw new BPMException(e);
		}
		
		return recUpdated;
	}
  
  @Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public int updateRewardFulfillmentHistWOrderNumber(Integer rewardTransHistID, String orderNumber) throws DataAccessException, BPMException {
		
		int recUpdated = 0;
		
		try {
			recUpdated = personDAO.updateRewardFulfillmentHistWOrderNumber(rewardTransHistID, orderNumber);
		} catch (DataAccessException dae) {
			//txManager.rollback(status);
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		} catch (Exception e) {
			//txManager.rollback(status);
			logger.error("BPMException: " + e.getMessage(), e);
			throw new BPMException(e);
		}
		
		return recUpdated;
	}
  
  
	
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public int updateRewardFulfillRecycleStatus(RewardFulfillmentTrackingRecycle lRewardFulfillmentTrackingRecycle) throws DataAccessException, BPMException {
		
		int recUpdated = 0;
		
		try {
			recUpdated = rewardCardDAO.updateRewardFulfillRecycleStatus(lRewardFulfillmentTrackingRecycle);
		} catch (DataAccessException dae) {
			//txManager.rollback(status);
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		} catch (BPMException ve) {
			//txManager.rollback(status);
			logger.error("BPMException: " + ve.getMessage(), ve);
			throw ve;
		} catch (Exception e) {
			//txManager.rollback(status);
			logger.error("BPMException: " + e.getMessage(), e);
			throw new BPMException(e);
		}
		
		return recUpdated;
	}
	
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public int insertRewardFulfillmentRecycle(RewardFulfillmentTrackingRecycle newRewardFulfillmentTrackingRecycle, String systemUser)
			throws DataAccessException, BPMException {
		
		int recInserted = 0;
		
		try {
			recInserted = rewardCardDAO.insertRewardFulfillmentRecycle(newRewardFulfillmentTrackingRecycle, systemUser);
		} catch (DataAccessException dae) {
			//txManager.rollback(status);
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		} catch (BPMException ve) {
			//txManager.rollback(status);
			logger.error("BPMException: " + ve.getMessage(), ve);
			throw ve;
		} catch (Exception e) {
			//txManager.rollback(status);
			logger.error("BPMException: " + e.getMessage(), e);
			throw new BPMException(e);
		}
		
		return recInserted;
	}
	
	

	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMException.class })
	public int updateRewardFulfillRptTrackHist(
			Collection<RewardIntelispendShipped> lRewardIntelispendShippedRecs)
			throws DataAccessException, BPMException {
		  
		  boolean noMatchOnOrderNumber = false;
		  String errorDescription = null;
		  
		  int recUpdateCt = 0;
		  Iterator<RewardIntelispendShipped> iter = lRewardIntelispendShippedRecs.iterator();
		  
		  while (iter.hasNext()) {
			  RewardIntelispendShipped lRewardIntelispendShipped = (RewardIntelispendShipped)iter.next();
			//determine order number matches before updating
			  try {
				  
				
				  LookUpValueCode rewardTrackingStatusLUV = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.REWARD_CARD_STATUS_TP, BPMConstants.SHIPPED);
				  Integer reasonCodeID = rewardTrackingStatusLUV.getLuvId();
				  logger.info("updateRewardFulfillRptTrackHist pid number is " + lRewardIntelispendShipped.getPidNumber());
				  if (BPMUtils.isValueInteger(lRewardIntelispendShipped.getPidNumber())) {
					  Integer fulfillHistID = Integer.valueOf(lRewardIntelispendShipped.getPidNumber());
					  String orderNumber = lRewardIntelispendShipped.getOrderNumber();
					  if (personDAO.matchIncomingOrderNoToFulfillOrderNo(fulfillHistID, orderNumber)) {
						  int recUpdateSuccess = personDAO.updateRewardFulfillRptTrackHist(lRewardIntelispendShipped);
						  recUpdateCt = recUpdateCt + recUpdateSuccess;
						  
						  RewardFulfillmentTrackingReportHist lRewardFulfillmentTrackingReportHist = new RewardFulfillmentTrackingReportHist();
						  lRewardFulfillmentTrackingReportHist.setRewardTransHistID(Integer.valueOf(lRewardIntelispendShipped.getPidNumber()));
						  if (lRewardIntelispendShipped.getRewardCardType().trim().equals(BPMConstants.CARD_TYPE_REPLACEMENT)) {
								//EV89209 - Add reward card status of REPLACEMENT_SHIPPED.
								  rewardTrackingStatusLUV = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.REWARD_CARD_STATUS_TP, BPMConstants.REPLACEMENT_SHIPPED);
								  reasonCodeID = rewardTrackingStatusLUV.getLuvId();
								  lRewardFulfillmentTrackingReportHist.setReasonCodeID(Integer.toString(reasonCodeID));
						  } else { 
							  lRewardFulfillmentTrackingReportHist.setReasonCodeID(Integer.toString(reasonCodeID));
						  }
						  lRewardFulfillmentTrackingReportHist.setRewardCardStatusDate(BPMUtils.formatDateMMddyyyy(lRewardIntelispendShipped.getShipDate()));
						  this.insertRewardFulfillmentStatus(lRewardFulfillmentTrackingReportHist, BPMConstants.INTELISPEND_USER_SYSTEM);
					  } else {
						  errorDescription = "ATTENTION! SHIPPED FILE ORDER NUMBER NOT MATCHING TO REWARD FULFILLMENT ORDER NUMBER GIVEN THE FULFILL HIST ID.";
						  String histAndOrderNumberDesc = "\nTried to match on fulfillHistId: " + fulfillHistID + " and  Order number: " + orderNumber;
						  errorDescription = errorDescription + histAndOrderNumberDesc;
						  logger.error(errorDescription);
						  noMatchOnOrderNumber = true;
					  }
				  } else {
					  // ordered record was a manual entry directly into Intelispends order entry website.
					  //   Fulfillment Hist id that is not numeric indicates manually entered card order.  Need to capture these
					  //   records back to the fulfillment table.
					  PersonActivityAchievedReward lPersonActivityAchievedReward = mapperRewardFulfillHistory(lRewardIntelispendShipped);
					  String pidID = lRewardIntelispendShipped.getPidNumber();
					  logger.info("updateRewardFulfillRptTrackHist PIDNumber is " + pidID);
					  if (personDAO.matchIncomingManualOrderToRewardFulfillHist(pidID)) {
						  String errorOnManualOrder = "ATTENTION! SHIPPED FILE MANUAL ORDER ALREADY ON FILE.  DUPLICATES WILL BE BYPASSED IN ORDER TO CONTINUE PROCESSING.  COULD BE THE RESULT OF THE SAME FILE BEING RUN MULTIPLE TIMES OR VENDOR SENDING DUPLICATES.";
						  errorOnManualOrder =  errorOnManualOrder + "\nA match exists on pidID: " + pidID;
						  logger.info(errorOnManualOrder);
					  } else {
						  lPersonActivityAchievedReward.setSystemID(BPMConstants.INTELISPEND_USER_SYSTEM);
						  int recUpdateSuccess = personDAO.insertRewardFulfillHistory(lPersonActivityAchievedReward);
						  
						  RewardFulfillmentTrackingReportHist lRewardFulfillmentTrackingReportHist = new RewardFulfillmentTrackingReportHist();
						  Integer rewardFulfillHistID = personDAO.getRewardFulfillHistIDByExternalTransID(lPersonActivityAchievedReward.getExternalTransactionID());
						  lRewardFulfillmentTrackingReportHist.setRewardTransHistID(rewardFulfillHistID);
						  lRewardFulfillmentTrackingReportHist.setReasonCodeID(Integer.toString(reasonCodeID));
						  lRewardFulfillmentTrackingReportHist.setRewardCardStatusDate(BPMUtils.formatDateMMddyyyy(lRewardIntelispendShipped.getShipDate()));
						  this.insertRewardFulfillmentStatus(lRewardFulfillmentTrackingReportHist, BPMConstants.INTELISPEND_USER_SYSTEM);
						  recUpdateCt = recUpdateCt + recUpdateSuccess;
					  }
				  }
				 
					  
			  } catch (BPMException e) {
				  e.setMessage(errorDescription);
				  throw e;
			  } catch (DataAccessException dae) {
				  throw dae;
			  }
		  }
		  
		  if (noMatchOnOrderNumber) {
			  String errorOnOrderNumber = "\nABORTING BATCH JOB!  CONTACT INTELISPEND TO FIND OUT WHY A BAD SHIPPED REPORT WAS SENT. UPDATES WERE ROLLED BACK.";
			  logger.error(errorOnOrderNumber);
			  BPMException exception = new BPMException();
			  exception.setMessage(errorDescription + errorOnOrderNumber);
			  throw exception;
		  }
		  
		  return recUpdateCt;
	}
	
	
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMException.class })
	public int insertRewardFulfillmentStatus(
			RewardFulfillmentTrackingReportHist lRewardFulfillmentTrackingReportHist, String systemID)
			throws DataAccessException, BPMException {
		  Integer rewardTransHistID = lRewardFulfillmentTrackingReportHist.getRewardTransHistID();
		  Integer reasonCodeID = Integer.valueOf(lRewardFulfillmentTrackingReportHist.getReasonCodeID());
		  Date statusDate = lRewardFulfillmentTrackingReportHist.getRewardCardStatusDate();
		  
		  int recUpdateCt = personDAO.insertRewardFulfillmentStatus(rewardTransHistID, reasonCodeID, statusDate, systemID);
		  
		  return recUpdateCt;
	}
	
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMException.class })
	public int insertTransmissionAuditLog(
			Integer transactionID, Integer sendReceiveCodeID, Integer transmissionStatusID)
			throws DataAccessException {
		
		  int recUpdateCt = rewardCardDAO.insertTransmissionAuditLog(transactionID, sendReceiveCodeID, transmissionStatusID);
		  
		  
		  return recUpdateCt;
	}
	
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMException.class })
	public int insertTransmissionAuditLogs(Collection<RewardFulfillmentTrackingReportHist> lRewardFulfillmentTrackingReportHists, Integer sendReceiveCodeID, Integer transmissionStatusID) throws DataAccessException {
			
		int recUpdateTotal = 0;
		int recUpdateCt = 0;
		
		for (RewardFulfillmentTrackingReportHist lRewardFulfillmentTrackingReportHist : lRewardFulfillmentTrackingReportHists) {
			Integer transactionID = lRewardFulfillmentTrackingReportHist.getRewardTransHistID();
			recUpdateCt = rewardCardDAO.insertTransmissionAuditLog(transactionID, sendReceiveCodeID, transmissionStatusID);
			recUpdateTotal = recUpdateTotal + recUpdateCt;
		}	  
		  
		return recUpdateTotal;
	}
	
	
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class,  BPMException.class })
	public int insertRewardOrderDetailReport(Collection<RewardIntelispendOrdered> lRewardIntelispendOrderedRecs)
			throws DataAccessException, BPMException {
		boolean emptyFileAssociatedToQuoteNumberDetected = false;
		int recUpdateTotal = 0;
		Iterator<RewardIntelispendOrdered> iter = lRewardIntelispendOrderedRecs.iterator();
		while (iter.hasNext()) {
			int recUpdateCt = 0;
			RewardIntelispendOrdered lRewardIntelispendOrdered = iter.next();
			if (lRewardIntelispendOrdered.getOrderNumber() != null) {
				recUpdateCt = rewardCardDAO.insertRewardOrderDetailReport(lRewardIntelispendOrdered);
			} else {
				emptyFileAssociatedToQuoteNumberDetected = true;
			}
			recUpdateTotal = recUpdateTotal + recUpdateCt;
		}
		
		if (emptyFileAssociatedToQuoteNumberDetected) {
			logger.info("FYI - One or more empty files detected from Intelispend.  When this happens, it indicates that no orders were placed with an active quote number assigned to us by Intelsipend.  Therefore, no action needs to be taken.");
		}
		
  
		return recUpdateTotal;
		
	}
	/*
	 * EV89209
	 * method will allow for insert and updates.  Updates are sent from vendor where
	 * cards need to be replaced.
	 */
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class,  BPMException.class })
	public int updateRewardShipDetailReport(Collection<RewardIntelispendShipped> lRewardIntelispendShippedRecs)
			throws DataAccessException, BPMException {
		int recUpdateTotal = 0;
		Iterator<RewardIntelispendShipped> iter = lRewardIntelispendShippedRecs.iterator();
		while (iter.hasNext()) {
			RewardIntelispendShipped lRewardIntelispendShipped = iter.next();
			int recUpdateCt = rewardCardDAO.updateRewardShipDetailReport(lRewardIntelispendShipped);
			recUpdateTotal = recUpdateTotal + recUpdateCt;
		}
		
  
		return recUpdateTotal;
		
	}
	
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class,  BPMException.class })
	public int insertRewardControlProgramProcessTracker(Integer controlProgramID, String processStatus, Integer recordsSent)
			throws DataAccessException {
		
		int recUpdateCt = rewardControlProgramDAO.insertRewardControlProgramProcessTracker(controlProgramID, processStatus, recordsSent);
		
		return recUpdateCt;
	}
	
	
	
	@Transactional(timeout = 300, rollbackFor = {
			DataAccessException.class,  BPMException.class })
	public String findLatestRewardFulfillStatus(Integer rewardTransHistID, Integer rewardStatusID) throws DataAccessException {
		
		String rewardFulfillStatus = personDAO.findLatestRewardFulfillStatus(rewardTransHistID, rewardStatusID);
		
		return rewardFulfillStatus;
	}
	
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class,  BPMException.class })
	public ArrayList<RewardIntelispendShipped> findNRemoveDuplicateRewardShipped(Collection<RewardIntelispendShipped> lRewardIntelispendShippedRecs) throws DataAccessException {
		Integer rewardShipDuplicatesCt = 0;
		ArrayList<RewardIntelispendShipped> lRewardIntelispendShippedRemoveRecs = new ArrayList<RewardIntelispendShipped>();
		
		for (RewardIntelispendShipped lRewardIntelispendShipped : lRewardIntelispendShippedRecs) {
			rewardShipDuplicatesCt = rewardCardDAO.findDuplicateRewardShipped(lRewardIntelispendShipped);
			if (rewardShipDuplicatesCt > 0) {
				if (lRewardIntelispendShipped.getRewardCardType().trim().equals(BPMConstants.CARD_TYPE_REPLACEMENT)) {
					//ignore transactions that carry replacement card info since a reward shipping detail record will
					//already exist.
				} else {
					lRewardIntelispendShippedRemoveRecs.add(lRewardIntelispendShipped);
					logger.info("Duplicate Shipped record detected.  Transaction Hist ID is " + lRewardIntelispendShipped.getPidNumber() + ".");
				}
			} 
		}
		
		for (RewardIntelispendShipped lRewardIntelispendShipped : lRewardIntelispendShippedRemoveRecs) {
			lRewardIntelispendShippedRecs.remove(lRewardIntelispendShipped);
		}
		return lRewardIntelispendShippedRemoveRecs;
	}
	
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class,  BPMException.class })
	public ArrayList<RewardIntelispendOrdered> findNRemoveDuplicateRewardOrdered(Collection<RewardIntelispendOrdered> lRewardIntelispendOrderedRecs) throws DataAccessException {
		Integer rewardOrderDuplicatesCt = 0;
		ArrayList<RewardIntelispendOrdered> lRewardIntelispendOrderedRemoveRecs = new ArrayList<RewardIntelispendOrdered>();
		
		for (RewardIntelispendOrdered lRewardIntelispendOrdered : lRewardIntelispendOrderedRecs) {
			rewardOrderDuplicatesCt = rewardCardDAO.findDuplicateRewardOrdered(lRewardIntelispendOrdered);
			if (rewardOrderDuplicatesCt > 0) {
				logger.info("Duplicate Order record detected.  Transaction Hist ID is " + lRewardIntelispendOrdered.getPidNumber() + ".");
				lRewardIntelispendOrderedRemoveRecs.add(lRewardIntelispendOrdered);
			}
			
		}
		
		for (RewardIntelispendOrdered lRewardIntelispendOrdered : lRewardIntelispendOrderedRemoveRecs) {
			lRewardIntelispendOrderedRecs.remove(lRewardIntelispendOrdered);
		}
		
		return lRewardIntelispendOrderedRemoveRecs;
	}
	
	@Transactional(timeout = 300, rollbackFor = {
			DataAccessException.class,  BPMException.class })
	public Integer getProgramID(Integer transHistID) throws DataAccessException {
		
		Integer programID = rewardCardDAO.getProgramID(transHistID);
			
		return programID;
	}
	
	
	private RewardFulfillmentTrackingRecycle mapperRewardFulfillmentRecycle(RewardFulfillmentTrackingReportHist lRewardFulfillmentTrackingReportHist) throws BPMException {
		RewardFulfillmentTrackingRecycle lRewardFulfillmentTrackingRecycle = new RewardFulfillmentTrackingRecycle();
		LookUpValueCode lookUpValueCode = new LookUpValueCode();
		
		lRewardFulfillmentTrackingRecycle.setRewardTransHistID(lRewardFulfillmentTrackingReportHist.getRewardTransHistID());
		lRewardFulfillmentTrackingRecycle.setReasonCodeID(lRewardFulfillmentTrackingReportHist.getReasonCodeID());
		//lRewardFulfillmentTrackingRecycle.setReasonColumn(reasonColumn);
		
		//lRewardFulfillmentTrackingRecycle.setReasonItemNo(reasonItemNo);
		
		lRewardFulfillmentTrackingRecycle.setReasonDesc(lRewardFulfillmentTrackingReportHist.getReasonDesc());
		
		lookUpValueCode = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.BPM_CDHP_RECYCLE_STATUS, BPMConstants.CDHP_RECYCLE_STATUS_ON_HOLD);
		lRewardFulfillmentTrackingRecycle.setRecycleStatusId(lookUpValueCode.getLuvId());
		
		lRewardFulfillmentTrackingRecycle.setInsertUser(BPMConstants.BPM_USER_SYSTEM);
		lRewardFulfillmentTrackingRecycle.setInsertDate(BPMUtils.calendarToSqlDate(Calendar.getInstance()));
		
		return lRewardFulfillmentTrackingRecycle;
		
	}

    private PersonActivityAchievedReward mapperRewardFulfillHistory(RewardIntelispendShipped lRewardIntelispendShipped) {
    	
    	PersonActivityAchievedReward lPersonActivityAchievedReward = new PersonActivityAchievedReward();
    	
    	lPersonActivityAchievedReward.setPersonDemographicsID(lRewardIntelispendShipped.getPersonDemographicsID());

    	Double amountDouble = Double.parseDouble(lRewardIntelispendShipped.getAmount());
    	lPersonActivityAchievedReward.setContributionAmt(amountDouble.intValue());
    	
    	lPersonActivityAchievedReward.setExternalTransactionID(lRewardIntelispendShipped.getPidNumber());
    	lPersonActivityAchievedReward.setOrderID(lRewardIntelispendShipped.getOrderNumber());
    	lPersonActivityAchievedReward.setRewardCardNoMask(lRewardIntelispendShipped.getCardNumberMasked());
    	lPersonActivityAchievedReward.setContributionDate(BPMUtils.formatDateMMddyyyy(lRewardIntelispendShipped.getOrderDate()));
    	
    	
    	
    	return lPersonActivityAchievedReward;
    }
    
    
    public RewardCardClientData getRewardCardClientData(Integer pProgramID, Integer pIncentiveOptionID)    
    {
    	return rewardCardDAO.getRewardCardClientData(pProgramID, pIncentiveOptionID);
    }
    
	public void setRewardCardDAO(RewardCardDAO rewardCardDAO) {
		this.rewardCardDAO = rewardCardDAO;
	}

	public void setRewardControlProgramDAO(
			RewardControlProgramDAO rewardControlProgramDAO) {
		this.rewardControlProgramDAO = rewardControlProgramDAO;
	}

	public void setTxManager(DataSourceTransactionManager txManager) {
		this.txManager = txManager;
	}

	public void setPersonDAO(PersonDAO personDAO) {
		this.personDAO = personDAO;
	}

	public void setLookUpValueService(LookUpValueService lookUpValueService) {
		this.lookUpValueService = lookUpValueService;
	}

	
	

}

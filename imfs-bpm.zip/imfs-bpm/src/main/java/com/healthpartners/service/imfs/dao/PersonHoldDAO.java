package com.healthpartners.service.imfs.dao;

import java.util.Collection;

import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.dto.PersonHold;

public interface PersonHoldDAO 
{
	public long insertPersonHold(PersonHold pPersonHold)
	throws DataAccessException;

	public Collection<PersonHold> getPersonHolds(Integer pPersonID)
	throws DataAccessException;
	
	public long updatePersonHold(PersonHold pPersonHold)
	throws DataAccessException;
}

package com.healthpartners.service.imfs.dao;

import com.healthpartners.service.imfs.dto.NamedParameter;
import com.healthpartners.service.imfs.dto.ParticipationGroup;
import com.healthpartners.service.imfs.dto.ParticipationGroupDetail;
import com.healthpartners.service.imfs.dto.ParticipationGroupRequirement;
import com.healthpartners.service.imfs.exception.BPMException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.transaction.annotation.Transactional;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Collection;
import java.util.List;

/**
 * 
 * @author jxbourbour
 * 
 */
@Configuration
public class ParticipationGroupDAOJdbc extends JdbcDaoSupport implements ParticipationGroupDAO {
	private String selectParticipationGroups;
	private String insertParticipationGroup;
	private String deleteParticipationGroup;
	private String updateParticipationGroup;

	private DataFieldMaxValueIncrementer participationGroupIDIncrementer;
	private String selectParticipationGroupRequirement;
	private String selectParticipationGroupDetail;
	private String insertParticipationGroupRequirement;
	private String insertParticipationGroupDetail;
	private String deleteParticipationGroupRequirements;
	private String deleteParticipationGroupDetails;
	private String updateParticipationGroupDetail;

	public ParticipationGroupDAOJdbc() {
		super();
	}

	@Autowired
	DataSource bpmDataSource;

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}

	/**
	 * Retrieve a list of all the participation group definitions.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<ParticipationGroup> getParticipationGroups() throws BPMException, DataAccessException {


		NamedParameter namedParameter = new NamedParameter();
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<ParticipationGroup> lParticipationGroupList = namedParameterJdbcTemplate.query(selectParticipationGroups, namedParameters, new RowMapper() {
			@Override
			public ParticipationGroup mapRow(ResultSet rs, int i) throws SQLException {
				ParticipationGroup lParticipationGroup = new ParticipationGroup();

				lParticipationGroup.setParticipationGroupID(rs.getInt("INCNTV_PART_GRP_ID"));
				lParticipationGroup.setParticipationGroupName(rs.getString("INCNTV_PART_GRP_NM"));
				lParticipationGroup.setParticipationGroupInfo(rs.getString("INCNTV_PART_GRP_INFO"));
				lParticipationGroup.setParticipationGroupDesc(rs.getString("INCNTV_PART_GRP_DESC"));
				lParticipationGroup.setEffectiveDate(rs.getDate("EFF_DT"));
				lParticipationGroup.setEndDate(rs.getDate("END_DT"));
				lParticipationGroup.setUsed("Y".equals(rs.getString("used_flg")));
				return lParticipationGroup;
			}

		});

		return lParticipationGroupList;
	}
	
	/**
	 * Return participation group give the ID.
	 * 
	 * @param pParticipationGroupID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public ParticipationGroup getParticipationGroup(Integer pParticipationGroupID) throws BPMException, DataAccessException {

		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setIncentiveReqGroupId(pParticipationGroupID);
		
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectParticipationGroups);
		lQuery.append(" WHERE INCNTV_PART_GRP_ID = :incentiveReqGroupId");

		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<ParticipationGroup> lParticipationGroupList = namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters, new RowMapper() {
			@Override
			public ParticipationGroup mapRow(ResultSet rs, int i) throws SQLException {
				ParticipationGroup lParticipationGroup = new ParticipationGroup();

				lParticipationGroup.setParticipationGroupID(rs.getInt("INCNTV_PART_GRP_ID"));
				lParticipationGroup.setParticipationGroupName(rs.getString("INCNTV_PART_GRP_NM"));
				lParticipationGroup.setParticipationGroupInfo(rs.getString("INCNTV_PART_GRP_INFO"));
				lParticipationGroup.setParticipationGroupDesc(rs.getString("INCNTV_PART_GRP_DESC"));
				lParticipationGroup.setEffectiveDate(rs.getDate("EFF_DT"));
				lParticipationGroup.setEndDate(rs.getDate("END_DT"));
				lParticipationGroup.setUsed("Y".equals(rs.getString("used_flg")));
				return lParticipationGroup;
			}

		});

		if(lParticipationGroupList.size() > 0)
		{
		    return lParticipationGroupList.get(0);
		}
		
		return null;
	}

	/**
	 * Insert into the incntv_participation_grp table.
	 * 
	 * @param pParticipationGroup
	 * @param pModifyUserID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int insertParticipationGroup(ParticipationGroup pParticipationGroup, String pModifyUserID)
			throws BPMException, DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		int rowInserted = 0;

		Long lParticipationGroupID = new Long(participationGroupIDIncrementer.nextLongValue());

		Object params[] = new Object[] { lParticipationGroupID, pParticipationGroup.getParticipationGroupName(),
				pParticipationGroup.getParticipationGroupInfo(), pParticipationGroup.getParticipationGroupDesc(),
				pParticipationGroup.getEffectiveDate(), pParticipationGroup.getEndDate(), pModifyUserID, pModifyUserID };

		int types[] = new int[] { Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.DATE, Types.DATE,
				Types.VARCHAR, Types.VARCHAR };

		rowInserted = template.update(insertParticipationGroup, params, types);

		pParticipationGroup.setParticipationGroupID(new Integer(lParticipationGroupID.intValue()));
		insertParticipationGroupRequirements(pParticipationGroup, pModifyUserID);

		return rowInserted;
	}

	/**
	 * Delete from incntv_participation_grp table
	 * 
	 * @param lParticipationGroupID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int deleteParticipationGroup(Integer lParticipationGroupID) throws BPMException, DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		int rowInserted = 0;

		Object params[] = new Object[] { lParticipationGroupID, lParticipationGroupID };

		int types[] = new int[] { Types.INTEGER, Types.INTEGER };

		deleteParticipationGroupRequirements(lParticipationGroupID);
		rowInserted = template.update(deleteParticipationGroup, params, types);
		return rowInserted;
	}

	/**
	 * Update the incntv_participation_grp table
	 * 
	 * @param pParticipationGroup
	 * @param pModifyUserID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int updateParticipationGroup(ParticipationGroup pParticipationGroup, String pModifyUserID)
			throws BPMException, DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		int rowInserted = 0;

		if (!pParticipationGroup.isPersistent()) {
			rowInserted = this.insertParticipationGroup(pParticipationGroup, pModifyUserID);
		} else {
			Object params[] = new Object[] { pParticipationGroup.getParticipationGroupName(),
					pParticipationGroup.getParticipationGroupInfo(), pParticipationGroup.getParticipationGroupDesc(),
					pParticipationGroup.getEffectiveDate(), pParticipationGroup.getEndDate(), pModifyUserID,
					pParticipationGroup.getParticipationGroupID() };

			int types[] = new int[] { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.DATE, Types.DATE,
					Types.VARCHAR, Types.INTEGER };

			rowInserted = template.update(updateParticipationGroup, params, types);
		}

		deleteParticipationGroupRequirements(pParticipationGroup.getParticipationGroupID());
		insertParticipationGroupRequirements(pParticipationGroup, pModifyUserID);
		
		return rowInserted;
	}

	/**
	 * 
	 * @param lParticipationGroupID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public List<ParticipationGroupRequirement> getParticipationGroupRequirements(Integer lParticipationGroupID)
			throws BPMException, DataAccessException {

		Object params[] = new Object[] { lParticipationGroupID };
		int types[] = new int[] { Types.INTEGER };
		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setSubGrpId(lParticipationGroupID);
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<ParticipationGroupRequirement> lParticipationGroupRequirements = namedParameterJdbcTemplate.query(selectParticipationGroupRequirement, namedParameters, new RowMapper() {
			@Override
			public ParticipationGroupRequirement mapRow(ResultSet rs, int i) throws SQLException {
				ParticipationGroupRequirement lParticipationGroupRequirement = new ParticipationGroupRequirement();
				lParticipationGroupRequirement.setParticipationGroupID(rs.getInt("INCNTV_PART_GRP_ID"));
				lParticipationGroupRequirement.setParticipationGroupRequirementID(rs.getInt("INCNTV_PART_REQ_ID"));

				return lParticipationGroupRequirement;
			}
		});

		// Now for each ParticipationGroupRequirement, retrieve the Details.
		for (ParticipationGroupRequirement requirement : lParticipationGroupRequirements) {
			List<ParticipationGroupDetail> participationGroupDetails = getParticipationGroupDetails(requirement);
			requirement.setParticipationGroupDetails(participationGroupDetails);
		}

		return lParticipationGroupRequirements;
	}

	/**
	 *
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public List<ParticipationGroupDetail> getParticipationGroupDetails(ParticipationGroupRequirement requirement)
			throws BPMException, DataAccessException {

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { requirement.getParticipationGroupID(),
				requirement.getParticipationGroupRequirementID() };
		int types[] = new int[] { Types.INTEGER, Types.INTEGER };

		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setIncentiveReqGroupId(requirement.getParticipationGroupID());
		namedParameter.setIncentiveId(requirement.getParticipationGroupRequirementID());
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<ParticipationGroupDetail> lParticipationGroupDetailList = namedParameterJdbcTemplate.query(selectParticipationGroupDetail, namedParameters, new RowMapper() {
			@Override
			public ParticipationGroupDetail mapRow(ResultSet rs, int i) throws SQLException {
				ParticipationGroupDetail lParticipationGroupDetail = new ParticipationGroupDetail();
				lParticipationGroupDetail.setParticipationGroupID(rs.getInt("INCNTV_PART_GRP_ID"));
				lParticipationGroupDetail.setParticipationGroupRequirementID(rs.getInt("INCNTV_PART_REQ_ID"));
				lParticipationGroupDetail.setParticipationGroupDetailID(rs.getInt("INCNTV_PART_GRP_DTL_ID"));
				lParticipationGroupDetail.setParticipationGroupDetailCode(rs.getString("INCNTV_PART_GRP_DTL_CD"));
				lParticipationGroupDetail.setParticipationCodeID(rs.getInt("INCNTV_PART_CD_ID"));
				lParticipationGroupDetail.setSourceCode(rs.getString("SRCE_CD"));

				return lParticipationGroupDetail;
			}

		});

		return lParticipationGroupDetailList;
	}

	/**
	 * Insert the requirements and related details for the given group
	 *
	 * @param pModifyUserID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int insertParticipationGroupRequirements(ParticipationGroup pParticipationGroup, String pModifyUserID)
			throws BPMException, DataAccessException {
		int rowInserted = 0;
		List<ParticipationGroupRequirement> participationGroupRequirements = 
				pParticipationGroup.getParticipationGroupRequirements();
		for (int i = 0; i < participationGroupRequirements.size(); i++) {
			ParticipationGroupRequirement requirement = participationGroupRequirements.get(i);
			requirement.setParticipationGroupID(pParticipationGroup.getParticipationGroupID());
			requirement.setParticipationGroupRequirementID(i);
			rowInserted += insertParticipationGroupRequirement(requirement, pModifyUserID);
			List<ParticipationGroupDetail> participationGroupDetails = requirement.getParticipationGroupDetails();
			for (int j = 0; j < participationGroupDetails.size(); j++) {
				ParticipationGroupDetail detail = participationGroupDetails.get(j);
				detail.setParticipationGroupID(pParticipationGroup.getParticipationGroupID());
				detail.setParticipationGroupRequirementID(i);
				detail.setParticipationGroupDetailID(j);
				insertParticipationGroupDetail(detail, pModifyUserID);
			}
		}

		return rowInserted;
	}
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	private int insertParticipationGroupRequirement(ParticipationGroupRequirement requirement, String pModifyUserID)
			throws BPMException, DataAccessException {
		int rowInserted = 0;
		JdbcTemplate template = getJdbcTemplate();

		Object params[] = new Object[] { requirement.getParticipationGroupID(), requirement.getParticipationGroupRequirementID(),
				pModifyUserID, pModifyUserID };

		int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.VARCHAR, Types.VARCHAR };

		rowInserted = template.update(insertParticipationGroupRequirement, params, types);

		return rowInserted;
	}

	/**
	 *
	 * @param pModifyUserID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int insertParticipationGroupDetail(ParticipationGroupDetail detail, String pModifyUserID)
			throws BPMException, DataAccessException {
		int rowInserted = 0;
		JdbcTemplate template = getJdbcTemplate();

		Object params[] = new Object[] { detail.getParticipationGroupDetailID(), detail.getParticipationGroupRequirementID(),
				detail.getParticipationGroupID(), detail.getParticipationCodeID(), detail.getSourceCode(),
				pModifyUserID, pModifyUserID };

		int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.VARCHAR, 
				Types.VARCHAR, Types.VARCHAR };

		rowInserted = template.update(insertParticipationGroupDetail, params, types);

		return rowInserted;
	}

	/**
	 *
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */

	private int deleteParticipationGroupRequirements(Integer pParticipationGroupD) throws BPMException,
			DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		int rowInserted = 0;

		Object params[] = new Object[] { pParticipationGroupD };

		int types[] = new int[] { Types.INTEGER };

		// be sure to delete related details first
		deleteParticipationGroupDetails(pParticipationGroupD);
		rowInserted = template.update(deleteParticipationGroupRequirements, params, types);

		return rowInserted;
	}

	private int deleteParticipationGroupDetails(Integer pParticipationGroupD) throws BPMException, DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		int rowInserted = 0;

		Object params[] = new Object[] { pParticipationGroupD };

		int types[] = new int[] { Types.INTEGER };

		rowInserted = template.update(deleteParticipationGroupDetails, params, types);

		return rowInserted;
	}

	public final String getSelectParticipationGroups() {
		return selectParticipationGroups;
	}

	public final void setSelectParticipationGroups(String selectParticipationGroups) {
		this.selectParticipationGroups = selectParticipationGroups;
	}

	public final DataFieldMaxValueIncrementer getParticipationGroupIDIncrementer() {
		return participationGroupIDIncrementer;
	}

	public final void setParticipationGroupIDIncrementer(DataFieldMaxValueIncrementer participationGroupIDIncrementer) {
		this.participationGroupIDIncrementer = participationGroupIDIncrementer;
	}

	public String getInsertParticipationGroup() {
		return insertParticipationGroup;
	}

	public void setInsertParticipationGroup(String insertParticipationGroup) {
		this.insertParticipationGroup = insertParticipationGroup;
	}

	public String getDeleteParticipationGroup() {
		return deleteParticipationGroup;
	}

	public void setDeleteParticipationGroup(String deleteParticipationGroup) {
		this.deleteParticipationGroup = deleteParticipationGroup;
	}

	public String getUpdateParticipationGroup() {
		return updateParticipationGroup;
	}

	public void setUpdateParticipationGroup(String updateParticipationGroup) {
		this.updateParticipationGroup = updateParticipationGroup;
	}

	public String getSelectParticipationGroupRequirement() {
		return selectParticipationGroupRequirement;
	}

	public void setSelectParticipationGroupRequirement(String selectParticipationGroupRequirement) {
		this.selectParticipationGroupRequirement = selectParticipationGroupRequirement;
	}

	public String getSelectParticipationGroupDetail() {
		return selectParticipationGroupDetail;
	}

	public void setSelectParticipationGroupDetail(String selectParticipationGroupDetail) {
		this.selectParticipationGroupDetail = selectParticipationGroupDetail;
	}

	public String getInsertParticipationGroupRequirement() {
		return insertParticipationGroupRequirement;
	}

	public void setInsertParticipationGroupRequirement(String insertParticipationGroupRequirement) {
		this.insertParticipationGroupRequirement = insertParticipationGroupRequirement;
	}

	public String getInsertParticipationGroupDetail() {
		return insertParticipationGroupDetail;
	}

	public void setInsertParticipationGroupDetail(String insertParticipationGroupDetail) {
		this.insertParticipationGroupDetail = insertParticipationGroupDetail;
	}

	public String getDeleteParticipationGroupRequirements() {
		return deleteParticipationGroupRequirements;
	}

	public void setDeleteParticipationGroupRequirements(String deleteParticipationGroupRequirements) {
		this.deleteParticipationGroupRequirements = deleteParticipationGroupRequirements;
	}

	public String getDeleteParticipationGroupDetails() {
		return deleteParticipationGroupDetails;
	}

	public void setDeleteParticipationGroupDetails(String deleteParticipationGroupDetails) {
		this.deleteParticipationGroupDetails = deleteParticipationGroupDetails;
	}

	public String getUpdateParticipationGroupDetail() {
		return updateParticipationGroupDetail;
	}

	public void setUpdateParticipationGroupDetail(String updateParticipationGroupDetail) {
		this.updateParticipationGroupDetail = updateParticipationGroupDetail;
	}
}

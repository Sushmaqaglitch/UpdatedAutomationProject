/**
 * 
 */
package com.healthpartners.service.imfs.exception;

import java.util.ArrayList;
import java.util.List;

import com.healthpartners.service.imfs.exception.BPMErrorMessage;

/**
 * Exception class to throw validations 
 * 
 * @author mxthoutam
 *
 */
public class BPMBusinessValidationException extends Exception {

    private static final long serialVersionUID = 1234567899L;
    private List<BPMErrorMessage> errorMessages;
    
    public BPMBusinessValidationException() {
		super();
		errorMessages = new ArrayList<BPMErrorMessage>();
	}
    
    /**
     * 
     * @param message
     */
	public BPMBusinessValidationException(String message) {
		super(message);
	}

	/**
	 * 
	 * @param message
	 * @param cause
	 */
	public BPMBusinessValidationException(String message, Throwable cause) {
		super(message, cause);
	}
	
	/**
	 * 
	 * @param cause
	 */
	public BPMBusinessValidationException(Throwable cause) {
		super(cause);
	}

	/**
	 * @return the bPMErrorMessages
	 */
	public List<BPMErrorMessage> getErrorMessages() {
		return errorMessages;
	}

	/**
	 * 
	 * @param errorMessage
	 */
	public void addErrorMessage(BPMErrorMessage errorMessage){
		this.errorMessages.add(errorMessage);
	}

}

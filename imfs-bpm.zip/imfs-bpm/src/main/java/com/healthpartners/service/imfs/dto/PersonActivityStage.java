package com.healthpartners.service.imfs.dto;

import java.sql.Date;
import java.sql.Time;
/**
 * DTO for capturing person activity completers to be sent to Cache membership.  Currently, sending Tobacco Cessation Completers.
 * @author tjquist
 *
 */
public class PersonActivityStage extends BaseDTO {
	
	
	private Integer contractNumber;
	private Integer personNumber;
	private Date activityCompletionDate;
	private Integer activityID;
	private Integer transactionHistID;
	private Date runDate;
	private Time runTime;
	
	
	public Integer getContractNumber() {
		return contractNumber;
	}
	public void setContractNumber(Integer contractNumber) {
		this.contractNumber = contractNumber;
	}
	public Integer getPersonNumber() {
		return personNumber;
	}
	public void setPersonNumber(Integer personNumber) {
		this.personNumber = personNumber;
	}
	public Date getActivityCompletionDate() {
		return activityCompletionDate;
	}
	public void setActivityCompletionDate(Date activityCompletionDate) {
		this.activityCompletionDate = activityCompletionDate;
	}
	public Integer getActivityID() {
		return activityID;
	}
	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}
	public Integer getTransactionHistID() {
		return transactionHistID;
	}
	public void setTransactionHistID(Integer transactionHistID) {
		this.transactionHistID = transactionHistID;
	}
	public Date getRunDate() {
		return runDate;
	}
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	public Time getRunTime() {
		return runTime;
	}
	public void setRunTime(Time runTime) {
		this.runTime = runTime;
	}
   
	
	
    
    
}

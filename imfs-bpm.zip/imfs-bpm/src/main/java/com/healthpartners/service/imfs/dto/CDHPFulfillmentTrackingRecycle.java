package com.healthpartners.service.imfs.dto;

import java.sql.Date;
import java.sql.Time;
/**
 * 
 * @author tjquist
 *
 */
public class CDHPFulfillmentTrackingRecycle extends BaseDTO {
	
	static final long serialVersionUID = 0L;
	
	private Integer cdhpRecycleId;
	private Integer programId;
	private Integer personDemographicsID;
	private Integer contractNumber;
	private String  recycleStatus;
	private Integer recycleStatusId;
	private Integer activityId;
	private Integer activityName;
	private Date    activityStatusIncentiveDate;
	private String packageSubTypeName;
	private Date recycleStatDate;
	private String reasonDesc;
	private String reasonTollgateRule;
	private String approverUserId;
	
	private Date insertDate;
	private Date modifyDate;
	private String insertUser;
	private String modifyUser;
	
	
	
	public Integer getCdhpRecycleId() {
		return cdhpRecycleId;
	}
	public void setCdhpRecycleId(Integer cdhpRecycleId) {
		this.cdhpRecycleId = cdhpRecycleId;
	}
	public Integer getProgramId() {
		return programId;
	}
	public void setProgramId(Integer programId) {
		this.programId = programId;
	}
	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}
	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}
	
	
	public Integer getContractNumber() {
		return contractNumber;
	}
	public void setContractNumber(Integer contractNumber) {
		this.contractNumber = contractNumber;
	}
	public String getRecycleStatus() {
		return recycleStatus;
	}
	public void setRecycleStatus(String recycleStatus) {
		this.recycleStatus = recycleStatus;
	}
	public Integer getRecycleStatusId() {
		return recycleStatusId;
	}
	public void setRecycleStatusId(Integer recycleStatusId) {
		this.recycleStatusId = recycleStatusId;
	}
	public Integer getActivityId() {
		return activityId;
	}
	public void setActivityId(Integer activityId) {
		this.activityId = activityId;
	}
	public Integer getActivityName() {
		return activityName;
	}
	public void setActivityName(Integer activityName) {
		this.activityName = activityName;
	}
	public Date getActivityStatusIncentiveDate() {
		return activityStatusIncentiveDate;
	}
	public void setActivityStatusIncentiveDate(Date activityStatusIncentiveDate) {
		this.activityStatusIncentiveDate = activityStatusIncentiveDate;
	}
	public String getPackageSubTypeName() {
		return packageSubTypeName;
	}
	public void setPackageSubTypeName(String packageSubTypeName) {
		this.packageSubTypeName = packageSubTypeName;
	}
	public Date getRecycleStatDate() {
		return recycleStatDate;
	}
	public void setRecycleStatDate(Date recycleStatDate) {
		this.recycleStatDate = recycleStatDate;
	}
	public String getReasonDesc() {
		return reasonDesc;
	}
	public void setReasonDesc(String reasonDesc) {
		this.reasonDesc = reasonDesc;
	}
	
	public String getReasonTollgateRule() {
		return reasonTollgateRule;
	}
	public void setReasonTollgateRule(String reasonTollgateRule) {
		this.reasonTollgateRule = reasonTollgateRule;
	}
	public String getApproverUserId() {
		return approverUserId;
	}
	public void setApproverUserId(String approverUserId) {
		this.approverUserId = approverUserId;
	}
	public Date getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}
	public Date getModifyDate() {
		return modifyDate;
	}
	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}
	public String getInsertUser() {
		return insertUser;
	}
	public void setInsertUser(String insertUser) {
		this.insertUser = insertUser;
	}
	public String getModifyUser() {
		return modifyUser;
	}
	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}
	
	
	
	
    
}

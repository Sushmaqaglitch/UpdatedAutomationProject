/* $Id$ */

package com.healthpartners.service.imfs.dao;

import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.dto.BPMAuditRecord;

/**
 * Inserts the bpm audit log record into the bpm audit history table.
 * 
 * @author tjquist
 */
public interface AuditLogDAO {

	/**
	 * Insert the specified <code>bpm Audit Record</code>.
	 *
	 * @return the audit log id
	 * @throws DataAccessException
	 *             when a database-related error is encountered
	 */
	public Integer insertAuditLog(BPMAuditRecord BPMAuditRecord)
			throws DataAccessException;
	
	/**
	 * Delete AuditLog records based on a date.</code>.
	 * 
	 * @param purgeDate
	 * @return the audit log id
	 * @throws DataAccessException
	 *             when a database-related error is encountered
	 */
	public Integer purgeAuditLogByDate(java.sql.Date purgeDate)
			throws DataAccessException;
	
	/**
	 * Get count of records on AuditLog table.</code>.
	 *
	 * @return the audit log id
	 * @throws DataAccessException
	 *             when a database-related error is encountered
	 */
	public Integer getAuditLogCount() throws DataAccessException;
}
package com.healthpartners.service.imfs.impl;


import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Calendar;


import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/*import com.healthpartners.claims.x10.Coverage;
import com.healthpartners.claims.x10.CoverageError;
import com.healthpartners.claims.x10.CoverageRequest;
import com.healthpartners.claims.x10.CoverageResponse;
import com.healthpartners.coverage.client.CoverageServiceSoap;
import com.healthpartners.coverage.client.CoverageService_Impl;
/*



import com.healthpartners.service.bpm.common.BPMConstants;
import com.healthpartners.service.bpm.dao.LookUpValueDAO;
import com.healthpartners.service.bpm.dto.LookUpValueCode;
import com.healthpartners.service.bpm.exception.BPMException;

import com.healthpartners.service.bpm.iface.CacheCoverageService;



/**
 * Contains methods to call the Cache realtime eligibility webservice, as well as
 * methods to call CHP stored procedure to determine Member and Non-Member Eligibility.
 * 
 * @author jxbourbour
 *
 */
@Component
@Service
public class CacheCoverageServiceImpl
{	
  /*
	protected final Logger log = Logger.getLogger(this.getClass());
	
	//private CoverageService_Impl realtimeCoverageService;
	private LookUpValueDAO lookUpValueDAO;
	
	
	private String resUser;
	private String resPassword;
	private String resWsdlUrl;
	
	public String getResUser() {
		return resUser;
	}

	public void setResUser(String resUser) {
		this.resUser = resUser;
	}

	public String getResPassword() {
		return resPassword;
	}

	public void setResPassword(String resPassword) {
		this.resPassword = resPassword;
	}

	public String getResWsdlUrl() {
		return resWsdlUrl;
	}

	public void setResWsdlUrl(String resWsdlUrl) {
		this.resWsdlUrl = resWsdlUrl;
	}

	/**
	 * Connect to the Cache coverage web service.
	 * 
	 * @return
	 */
   /*
	public CoverageService_Impl getRealtimeCoverageService() throws BPMException
	{
		
		CoverageServiceSoap lCoverageServiceSoap = null;
		CoverageService_Impl lCoverageService_Impl = null;
		
		this.lookupRealtimeCoverageServiceInfo();
	    
		try {
			
			lCoverageServiceSoap = (CoverageServiceSoap)this.realtimeCoverageService.getCoverageServiceSoap(resUser.getBytes(), resPassword.getBytes());
			((javax.xml.rpc.Stub)lCoverageServiceSoap)._setProperty(javax.xml.rpc.Stub.ENDPOINT_ADDRESS_PROPERTY, resWsdlUrl);
			((javax.xml.rpc.Stub)lCoverageServiceSoap)._setProperty(BPMConstants.WEBLOGIC_WSEE_TRANSPORT_READ_TIMEOUT
					, BPMConstants.DEFAULT_READ_TIMEOUT_SECONDS * 1000);
			
			
			
		} catch (javax.xml.rpc.ServiceException se) {
			log.error("CacheCoverageService.getRealtimeCoverageService ServletException: " + se);  
		}
		
				
		
		return lCoverageService_Impl;
	}
    
	public void setRealtimeCoverageService(CoverageService_Impl realtimeCoverageService) {		
		this.realtimeCoverageService = realtimeCoverageService;													
	}
	
	/**
	 * Look up the Cache realtime member-eligibility web service URL, user name, and password from the LUV
	 * table. 
	 */
	/*
	protected void lookupRealtimeCoverageServiceInfo()
	{
		ArrayList<LookUpValueCode> lRealTimeMemberServiceUserNameList = (ArrayList<LookUpValueCode>)  
	     lookUpValueDAO.getLUVCodesByGroup(BPMConstants.CACHE_COVERAGE_USERNAME);
	
		if(lRealTimeMemberServiceUserNameList != null)
		{
			resUser = lRealTimeMemberServiceUserNameList.get(0).getLuvVal();
		}
		
		ArrayList<LookUpValueCode> lRealTimeMemberServicePasswordList = (ArrayList<LookUpValueCode>)  
	    lookUpValueDAO.getLUVCodesByGroup(BPMConstants.CACHE_COVERAGE_PASSWORD);
		
		if(lRealTimeMemberServicePasswordList != null)
		{
			resPassword = lRealTimeMemberServicePasswordList.get(0).getLuvVal();
		}
		
		ArrayList<LookUpValueCode> lRealTimeMemberServiceWSDLList = (ArrayList<LookUpValueCode>)  
	    lookUpValueDAO.getLUVCodesByGroup(BPMConstants.CACHE_COVERAGE_WSDL);
		
		// WSDL is a longer string. So it's in the description.
		if(lRealTimeMemberServiceWSDLList != null)
		{
			resWsdlUrl = lRealTimeMemberServiceWSDLList.get(0).getLuvDesc();
		}				
	}
		
	/**
	 * 
	 * Calls the Cache realtime member coverage web service.
	 *  
	 */
	/*
	public ArrayList<Coverage> getMemberCoverage(String memberNbr, Calendar coverageDate, String coverageType) 
	throws BPMException, DataRetrievalFailureException, RemoteException 
	{
		CoverageResponse lCoverageResponse = null;
		CoverageRequest coverageRequest = new CoverageRequest();
		
		
		try {
			CoverageService_Impl transactionResponse = getRealtimeCoverageService();
			CoverageServiceSoap lCoverageServiceSoap = transactionResponse.getCoverageServiceSoap();
			
			coverageRequest.setMemberNumber(memberNbr);
			coverageRequest.setCoverageType(coverageType);
			coverageRequest.setCoverageDate(coverageDate);
			
			
			lCoverageResponse = lCoverageServiceSoap.getCoverage(coverageRequest);
			CoverageError[] errors = lCoverageResponse.getCoverageError();
			if (errors != null && errors.length > 0) 
			{
				for (CoverageError error : errors) 
				{
					log.error("Error from getRealtimeCoverageService, error Code = " + error.getDescription() + ", Member ID = " + memberNbr);	
				}						
			}
		} catch (ServiceException se) {
				log.error("CacheCoverageService.getMemberCoverage: Issue around making SOAP call.");
				log.error("ServiceException error: " + se.getStackTrace());
				throw new BPMException();
			
		}
		
		
		Coverage[] lCoverage = lCoverageResponse.getCoverage();
		ArrayList<Coverage> lCoverageList = new ArrayList<Coverage>();
		lCoverageList.toArray(lCoverage);

		return lCoverageList;
	}
	
	
	
    
   
	public final LookUpValueDAO getLookUpValueDAO() {
		return lookUpValueDAO;
	}

	public final void setLookUpValueDAO(LookUpValueDAO lookUpValueDAO) {
		this.lookUpValueDAO = lookUpValueDAO;
	}

	*/
	
}

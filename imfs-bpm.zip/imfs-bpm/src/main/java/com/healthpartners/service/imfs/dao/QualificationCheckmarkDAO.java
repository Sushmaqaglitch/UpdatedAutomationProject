package com.healthpartners.service.imfs.dao;

import com.healthpartners.service.imfs.dto.ActivityDefinition;
import com.healthpartners.service.imfs.dto.CheckmarkDetail;
import com.healthpartners.service.imfs.dto.CheckmarkRequirement;
import com.healthpartners.service.imfs.dto.ProgramCheckmark;
import com.healthpartners.service.imfs.dto.QualificationCheckmark;
import com.healthpartners.service.imfs.exception.BPMException;
import org.springframework.dao.DataAccessException;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public interface QualificationCheckmarkDAO 
{
	public Collection<QualificationCheckmark> getQualificationCheckmarks(int pBusinessProgramID)
	throws BPMException, DataAccessException, BPMException;
	
	public Collection<CheckmarkRequirement> getCheckmarkRequirements(Integer pQualificationCheckmarkID)
	throws BPMException, DataAccessException;
	
	public Collection<CheckmarkDetail> getCheckmarkDetails(Integer pQualificationCheckmarkID, Integer pRequirementID)
	throws BPMException, DataAccessException;
	
	public ArrayList<ProgramCheckmark> getProgramCheckmarks(Integer pProgramID)
	throws BPMException, DataAccessException;
	
	public int insertProgramCheckmarks(ArrayList<ProgramCheckmark> pProgramCheckmarks
			, String pModifyUserID)
	throws BPMException, DataAccessException;
	
	public int updateProgramCheckmarks(ArrayList<ProgramCheckmark> pProgramCheckmarks
			, Integer pBusinessProgramID
			, String pModifyUserID)
	throws BPMException, DataAccessException;
	
	public List<ActivityDefinition> getCollectionActivities(Integer pCollectionID);
	
	public int deleteProgramCheckmarks(Integer pProgramID) 
		throws BPMException, DataAccessException;
}

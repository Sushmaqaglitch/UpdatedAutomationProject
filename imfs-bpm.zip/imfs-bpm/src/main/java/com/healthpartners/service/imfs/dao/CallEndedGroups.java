package com.healthpartners.service.imfs.dao;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;

import oracle.jdbc.internal.OracleTypes;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.object.StoredProcedure;


/**
 * Calls the Stored Procedure pkg_bpm_smarts.endedGroupsReport.
 * 
 * @author jxbourbour
 *
 */
@Configuration
public class CallEndedGroups extends StoredProcedure 
{

	protected final Log logger = LogFactory.getLog(getClass());

	@Autowired
	DataSource bpmDataSource;


	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}

    private static final String STORED_PROC_NAME = "pkg_bpm_smarts.endedGroupsReport";

    public CallEndedGroups(DataSource bpmDataSource)
    {
        super(bpmDataSource, STORED_PROC_NAME);
        
        // Input Parameter
        // None.
        
        // Output Parameters                           
        declareParameter(new SqlOutParameter("o_ended_groups_cursor", OracleTypes.CURSOR, new RowMapper<String>() 
        {
			
			public String mapRow(ResultSet lResultSet, int rowNum) throws SQLException 
			{
				StringBuffer lLine = new StringBuffer();
    			
    			lLine.append(lResultSet.getInt("biz_pgm_id"));
    			lLine.append(",");
    			
    			lLine.append(lResultSet.getInt("grp_id"));
    			lLine.append(",");
    			lLine.append(lResultSet.getInt("subgrp_id"));
    			lLine.append(",");
    			
    			lLine.append(lResultSet.getString("grp_eff"));
    			lLine.append(",");
    			lLine.append(lResultSet.getString("grp_end"));
    			lLine.append(",");
    			lLine.append(lResultSet.getString("biz_eff"));
    			lLine.append(",");
    			lLine.append(lResultSet.getString("biz_end"));
    			lLine.append(",");
    			
    			lLine.append(lResultSet.getString("biz_pgm_tp_cd"));
    			lLine.append(",");    			
    			lLine.append(lResultSet.getString("biz_pgm_nm"));
    			lLine.append(",");
    			
    			lLine.append(lResultSet.getString("EMPL_GRP_NO"));
    			lLine.append(",");    			
    			lLine.append((lResultSet.getString("empl_grp_nm")).replace(',', '-'));
    			lLine.append(",");
    			lLine.append(lResultSet.getString("EMPL_GRP_SITE_ID_NO"));
    			lLine.append(",");    			
    			lLine.append((lResultSet.getString("EMPL_GRP_SITE_NM")).replace(',', '-'));
    			lLine.append(",");
    			lLine.append(lResultSet.getString("last_renewal"));    			
    			    			
    			lLine.append("\r\n");
    			
    			return lLine.toString();
			}
		})); 
        
        compile();
    }

    /**
     * 
     *
     * @return
     */
    public String execute(String pFilePath)    
    {    	    	
        Map<String, Object> lInputParams = new HashMap<String, Object>(0);
                        
        Map<String, Object> lOutputParams = execute(lInputParams);
                                       
        if(lOutputParams.size() > 0) 
        {           	
        	Calendar lToday = Calendar.getInstance();
        	
        	String lPathAndFileName = pFilePath + BPMConstants.BPM_ENDED_GROUPS + "/"
        			                            + BPMConstants.BPM_ENDED_GROUPS + "-" + BPMUtils.formatDateCCYYmmddWODel(lToday.getTime()) + ".csv";
        	        	
        	BufferedWriter lBufferedWriter = null;
        	
        	try
        	{      
        		lBufferedWriter = new BufferedWriter(new FileWriter(lPathAndFileName));
        		
        		StringBuffer lColumnHeaders = new StringBuffer();
        		lColumnHeaders.append("BIZ_PGM_ID,");
        		lColumnHeaders.append("GRP_ID,");
        		lColumnHeaders.append("SUBGRP_ID,");
        		
        		lColumnHeaders.append("GRP_EFF_DATE,");
        		lColumnHeaders.append("GRP_END_DATE,");
        		
        		lColumnHeaders.append("BIZ_PGM_EFF_DT,");
        		lColumnHeaders.append("BIZ_PGM_END_DT,");
        		
        		lColumnHeaders.append("BIZ_PGM_TP_CD,");
        		lColumnHeaders.append("BIZ_PGM_NM,");
        		
        		lColumnHeaders.append("EMPL_GRP_NO,");
        		lColumnHeaders.append("EMPL_GRP_NM,");
        		
        		lColumnHeaders.append("SITE_NO,");
        		lColumnHeaders.append("SITE_NM,");
        		        		
        		lColumnHeaders.append("LAST_RENEWAL_DT");
        		
        		lColumnHeaders.append("\r\n");
        		        		
        		lBufferedWriter.write(lColumnHeaders.toString());
        		
        		
        		ArrayList<String> lResults = (ArrayList<String>)lOutputParams.get("o_ended_groups_cursor");

        		for(String lLine : lResults)
        		{        			
        			lBufferedWriter.write(lLine);                    
        		}
        		
        		lBufferedWriter.flush();
        		lBufferedWriter.close();
        	}
        	catch(Exception e)
        	{        		        		
        		BPMUtils.logException(logger, e);
        		return "Error. Please check the log file.";
        	}        	
        	
        	return lPathAndFileName;
        }                 
        
        return "No Data Today.";
    }

		        
}

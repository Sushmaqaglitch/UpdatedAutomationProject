package com.healthpartners.service.imfs.dao;

import java.util.Collection;

import com.healthpartners.service.imfs.dto.GroupBaseline;
import org.springframework.dao.DataAccessException;


public interface GroupBaselineDAO 
{
	public Collection<GroupBaseline> selectFromGroupBaseline(Integer batchCount)
	throws DataAccessException;

	public Integer purgeGroupBaselineHistByDate(java.sql.Date purgeDate)
			throws DataAccessException;

	public Integer getGroupBaselineHistCount() throws DataAccessException;


}

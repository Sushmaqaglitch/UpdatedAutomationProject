package com.healthpartners.service.imfs.dto;

import java.sql.Date;

/**
 * 
 * @author tjquist
 *
 */
public class PersonContractHist extends BaseDTO {
	
	static final long serialVersionUID = 0L;
	
	private Integer personContractSeqId;
	private Integer contractNumber;
	private String contractStatus;
	private String firstName;
	private String lastName;
	private String memberNumber;
	private Integer programID;
	private String memberStatus;
	private Integer groupID;
	private Integer personNumber;
	private Integer personDemographicsID;
	private String  programTypeCode;
	private Date qualificationEndDate;
	private Date qualificationStartDate;
	private Date programEndDate;
	private Date programStartDate;
	private Date runDate;
    private Integer siteID;
	private Date statusDate;
	private String historyContractStatus;
	private Date historyContractInsertDate;
	private Date contractStatusDate;
	private Date contractLastChangedDate;
	private Date memberStatusDate;
	private Integer businessProgramIncentiveOptionID;
	private Date loadDate;
	private String insertUserID;
	private String activationStatusCode;
	
	
	
    public PersonContractHist()
    {
    	super();
    }

	public Integer getContractNumber() {
		return contractNumber;
	}

	public void setContractNumber(Integer contractNumber) {
		this.contractNumber = contractNumber;
	}

	

	
	public Integer getPersonNumber() {
		return personNumber;
	}

	public void setPersonNumber(Integer personNumber) {
		this.personNumber = personNumber;
	}

	public Date getQualificationEndDate() {
		return qualificationEndDate;
	}

	public void setQualificationEndDate(Date qualificationEndDate) {
		this.qualificationEndDate = qualificationEndDate;
	}

	public Date getQualificationStartDate() {
		return qualificationStartDate;
	}

	public void setQualificationStartDate(Date qualificationStartDate) {
		this.qualificationStartDate = qualificationStartDate;
	}

	public Date getRunDate() {
		return runDate;
	}

	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}

	
	
	public Date getStatusDate() {
		return statusDate;
	}

	public void setStatusDate(Date statusDate) {
		this.statusDate = statusDate;
	}

	
	public String getContractStatus() {
		return contractStatus;
	}

	public void setContractStatus(String contractStatus) {
		this.contractStatus = contractStatus;
	}

	public String getMemberStatus() {
		return memberStatus;
	}

	public void setMemberStatus(String memberStatus) {
		this.memberStatus = memberStatus;
	}

	public String getProgramTypeCode() {
		return programTypeCode;
	}

	public void setProgramTypeCode(String programTypeCode) {
		this.programTypeCode = programTypeCode;
	}

	public Integer getProgramID() {
		return programID;
	}

	public void setProgramID(Integer programID) {
		this.programID = programID;
	}

	public Integer getPersonContractSeqId() {
		return personContractSeqId;
	}

	public void setPersonContractSeqId(Integer personContractSeqId) {
		this.personContractSeqId = personContractSeqId;
	}

	public Date getProgramEndDate() {
		return programEndDate;
	}

	public void setProgramEndDate(Date programEndDate) {
		this.programEndDate = programEndDate;
	}

	public Date getProgramStartDate() {
		return programStartDate;
	}

	public void setProgramStartDate(Date programStartDate) {
		this.programStartDate = programStartDate;
	}

	public final Integer getPersonDemographicsID() {
		return personDemographicsID;
	}

	public final void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}
	
	

	public Integer getGroupID() {
		return groupID;
	}

	public void setGroupID(Integer groupID) {
		this.groupID = groupID;
	}

	

	public Integer getSiteID() {
		return siteID;
	}

	public void setSiteID(Integer siteID) {
		this.siteID = siteID;
	}

	public String getMemberNumber() {
		return memberNumber;
	}

	public void setMemberNumber(String memberNumber) {
		this.memberNumber = memberNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getHistoryContractStatus() {
		return historyContractStatus;
	}

	public void setHistoryContractStatus(String historyContractStatus) {
		this.historyContractStatus = historyContractStatus;
	}

	
	public Date getHistoryContractInsertDate() {
		return historyContractInsertDate;
	}

	public void setHistoryContractInsertDate(Date historyContractInsertDate) {
		this.historyContractInsertDate = historyContractInsertDate;
	}
	
	

	public Date getContractStatusDate() {
		return contractStatusDate;
	}

	public void setContractStatusDate(Date contractStatusDate) {
		this.contractStatusDate = contractStatusDate;
	}

	public Date getContractLastChangedDate() {
		return contractLastChangedDate;
	}

	public void setContractLastChangedDate(Date contractLastChangedDate) {
		this.contractLastChangedDate = contractLastChangedDate;
	}

	public Date getMemberStatusDate() {
		return memberStatusDate;
	}

	public void setMemberStatusDate(Date memberStatusDate) {
		this.memberStatusDate = memberStatusDate;
	}

	public Integer getBusinessProgramIncentiveOptionID() {
		return businessProgramIncentiveOptionID;
	}

	public void setBusinessProgramIncentiveOptionID(Integer businessProgramIncentiveOptionID) {
		this.businessProgramIncentiveOptionID = businessProgramIncentiveOptionID;
	}

	public Date getLoadDate() {
		return loadDate;
	}

	public void setLoadDate(Date loadDate) {
		this.loadDate = loadDate;
	}

	
	public String getInsertUserID() {
		return insertUserID;
	}

	public void setInsertUserID(String insertUserID) {
		this.insertUserID = insertUserID;
	}

	public final String getActivationStatusCode() {
		return activationStatusCode;
	}

	public final void setActivationStatusCode(String activationStatusCode) {
		this.activationStatusCode = activationStatusCode;
	}
  
	
	
    
}

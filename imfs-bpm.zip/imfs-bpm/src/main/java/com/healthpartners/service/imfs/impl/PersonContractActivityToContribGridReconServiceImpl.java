package com.healthpartners.service.imfs.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.dao.PersonDAO;

import com.healthpartners.service.imfs.dto.PersonActivityToContribGridReport;

import com.healthpartners.service.imfs.exception.BPMBusinessValidationException;
import com.healthpartners.service.imfs.exception.BPMException;

import com.healthpartners.service.imfs.iface.EmailService;

import com.healthpartners.service.imfs.iface.PersonContractActivityToContribGridReconService;

import com.healthpartners.service.imfs.rules.StatusCalculationCommand;
@Component
@Service
public class PersonContractActivityToContribGridReconServiceImpl implements PersonContractActivityToContribGridReconService {
	

	protected final Log logger = LogFactory.getLog(getClass());
	@Autowired
	private PersonDAO personDAO;

	@Autowired
	private EmailService emailService;
	
	
	
	/*
	 * Batch job that will reconcile member incented table against the program contribution grid to determine if contribution grid is missing or relationship within
	 * contribution grid is missing.  The same reconciliation steps are also done between the contract incented table and the contribution grid.  
	*/
		@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
				BPMBusinessValidationException.class, BPMException.class })
	public void processPersonContractActivityToContribGridReconCommand(StatusCalculationCommand statusCalculationCommand) throws BPMException {
			
				logger.info("@Start - Reconciling Person Contract Activity To Contribution Grid Command. ");
				
				
				String failureReason = null;
				ArrayList<PersonActivityToContribGridReport> lPersonActivityToContribGridReports = new ArrayList<PersonActivityToContribGridReport>();
				ArrayList<PersonActivityToContribGridReport> lPersonContractActivityToContribGridReports = new ArrayList<PersonActivityToContribGridReport>();
				
				statusCalculationCommand.setCurrentCommandText("Reconciling Person Contract Activity To Contribution Grid");
				
				try{ 
					List<PersonActivityToContribGridReport> lPersonActivityToContribGridReportCDHP  = personDAO.getPersonActivityToContribGridReport(BPMConstants.CDHP_FLFLMNT_RTNG_TP_CDHP);
					if (lPersonActivityToContribGridReportCDHP.size() > 0) {
						lPersonActivityToContribGridReports.addAll(lPersonActivityToContribGridReportCDHP);
					}
					
					List<PersonActivityToContribGridReport> lPersonActivityToContribGridReportIntelispend  = personDAO.getPersonActivityToContribGridReport(BPMConstants.CDHP_FLFLMNT_RTNG_TP_INTELISPEND);
					if (lPersonActivityToContribGridReportIntelispend.size() > 0) {
						lPersonActivityToContribGridReports.addAll(lPersonActivityToContribGridReportIntelispend);
					}
					
				} catch (Exception e) {
					failureReason = e.getMessage();
					logger.error("Error in processPersonContractActivityToContribGridReconCommand.");
					logger.error("Call to personDAO failed: " + e.getMessage());
				}
				
				lPersonContractActivityToContribGridReports = determineIfContractIncentedForActivity(lPersonContractActivityToContribGridReports);
								
				createPersonActivityToContribGridReport(statusCalculationCommand, lPersonActivityToContribGridReports, lPersonContractActivityToContribGridReports, failureReason);
				
				logger.info("@End - Reconciling Person Contract Activity To Contribution Grid Command.");
				
	}
		
		private ArrayList<PersonActivityToContribGridReport> determineIfContractIncentedForActivity(ArrayList<PersonActivityToContribGridReport> lPersonContractActivityToContribGridReports) {
			ArrayList<PersonActivityToContribGridReport> lPersonContractActivityToContribGridReportsToRemove = new ArrayList<PersonActivityToContribGridReport>();
			for (PersonActivityToContribGridReport lPersonContractActivityToContribGridReport : lPersonContractActivityToContribGridReports) {
				
				Integer programID = lPersonContractActivityToContribGridReport.getProgramID();
				Integer contractNumber = lPersonContractActivityToContribGridReport.getContractNumber();
				if (personDAO.isContractIncentedForActivity(programID, contractNumber)) {
					lPersonContractActivityToContribGridReportsToRemove.add(lPersonContractActivityToContribGridReport);
				}
				
			}
			
			for (PersonActivityToContribGridReport lPersonContractActivityToContribGridReportToRemove : lPersonContractActivityToContribGridReportsToRemove) {
				lPersonContractActivityToContribGridReports.remove(lPersonContractActivityToContribGridReportToRemove);
			}
			
			return lPersonContractActivityToContribGridReports;
		}
		
		/*
		 * Produce a report that shows person activity incentives that do not reconcile to the program contribution grid.
		 */
			@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
					BPMBusinessValidationException.class, BPMException.class })
		private void createPersonActivityToContribGridReport(StatusCalculationCommand statusCalculationCommand, Collection<PersonActivityToContribGridReport> lPersonActivityToContribGridReports, Collection<PersonActivityToContribGridReport> lPersonContractActivityToContribGridReports, String failureReason) throws BPMException
			{
				logger.info("@Start - Create Processing Person Contract Activity To Contribution Grid Reconciliation Report. ");
				
				
				StringBuffer batchMailSubject = new StringBuffer();
				
				batchMailSubject
				.append("BPM Batch - Processing Person Contract Activity To Contribution Grid Reconciliation ");
				
				batchMailSubject.append(" / Status");
				StringBuffer batchMailContent = new StringBuffer();
				batchMailContent
				.append("<table>");
				batchMailContent.append("<tr><td>BPM Batch Name: Processing Person Contract Activity To Contribution Grid Reconciliation Report  </td></tr>");

				batchMailContent.append("<tr><td>Initiated User: "
						+ statusCalculationCommand.getUserID());
				
				if (failureReason != null) {
					batchMailSubject.append("- FAILED");
					batchMailContent.append("<tr><td>Result: FAILED</td></tr>");
					batchMailContent.append("<tr></td>Reason: \n");
					batchMailContent.append(failureReason + "</td></tr>");
				} else {
					batchMailSubject.append("- SUCCESS");
					batchMailContent.append("<tr></td>Result: SUCCESS</td></tr>");
				}
				
				batchMailContent
				.append("</table>");
				batchMailContent
				.append("<table>");
				
				if (lPersonActivityToContribGridReports.size() > 0) {
					batchMailContent
					.append("<tr><td>------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
					batchMailContent
							.append("<tr><td>Total Member Incented Activites missing program contribution grid setup:  " + lPersonActivityToContribGridReports.size() + "</td></tr>");
					batchMailContent
					.append("<tr><td>------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
					batchMailContent
					.append("<tr><td>MEMBER ACTIVITY INCENTIVES MISSING PROGRAM CONTRIBUTION GRID SETUP DETAIL REPORT</td></tr>");
				
					
				} else {
					batchMailContent
					.append("<tr><td>------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
					batchMailContent
					.append("<tr><td> NO MEMBER ACTIVITY INCENTIVES MISSING PROGRAM CONTRIBUTION GRID SETUP . </td></tr>");
					batchMailContent
					.append("<tr><td>------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
				}
				batchMailContent
				.append("</table>");
				
				batchMailContent
				.append("<table>");
				if (lPersonActivityToContribGridReports.size() > 0) {
					// column header
					batchMailContent
					.append("<table>");
					batchMailContent.append("<tr><td> Line</td><td>Group No</td><td>Site No</td><td>Contract No</td><td>Member No</td><td>Relationship Name</td><td>Activity Name</td><td>Incentive Option Name</td><td>Incentive Status Type</td><td>Incentive Rule Type Desc</td></tr>");
					
					int rowCt = 1;
			    	for (PersonActivityToContribGridReport lPersonActivityToContribGridReport: lPersonActivityToContribGridReports) {
							
			    		batchMailContent
						.append("<tr><td colspan=10>-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
						batchMailContent.append("<tr><td> "
								+ rowCt + "</td><td>"
								+ lPersonActivityToContribGridReport.getGroupNumber() + "</td><td>"
								+ lPersonActivityToContribGridReport.getSiteNumber() + "</td><td>"
								+ lPersonActivityToContribGridReport.getContractNumber() + "</td><td>"
								+ lPersonActivityToContribGridReport.getMemberNumber() + "</td><td>"
								+ lPersonActivityToContribGridReport.getRelationshipName() + "</td><td>"
								+ lPersonActivityToContribGridReport.getActivityName() + "</td><td>" 
								+ lPersonActivityToContribGridReport.getIncentiveOptionName() + "</td><td>" 
								+ lPersonActivityToContribGridReport.getIncentiveStatusType() + "</td><td>" 
								+ lPersonActivityToContribGridReport.getIncentiveRuleTypeDesc() + "</td><td>" 
								+ "</td></tr>");
						rowCt++;
			
						if (rowCt > 100) {
							batchMailContent
							.append("<tr><td>   </td></tr>");
							batchMailContent
							.append("<tr><td>   </td></tr>");
							//cap report list at 100
							batchMailContent
							.append("<tr><td colspan=12>***ATTENTION: REPORT CUTOFF AT 100 ROWS.  " + "A TOTAL OF " + lPersonActivityToContribGridReports.size() + " MEMBER ACTIVITY INCENTIVES UNRESOLVED BENEFIT CONTRACT TYPES.</td></tr>");
							break;
						}
					
			    	}
			    	batchMailContent
					.append("<tr><td colspan=10>============================================================================================================================================================================================================================</td></tr>");
			    	batchMailContent
					.append("</table>");
			    	
				} 
				batchMailContent
				.append("</table>");
				
				batchMailContent
				.append("<table>");
				if (lPersonContractActivityToContribGridReports.size() > 0) {
					batchMailContent
					.append("<tr><td>------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
					batchMailContent
							.append("<tr><td>Total Contract Incented Activites missing program contribution grid setup:  " + lPersonContractActivityToContribGridReports.size() + "</td></tr>");
					batchMailContent
					.append("<tr><td>------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
					batchMailContent
					.append("<tr><td>CONTRACT ACTIVITY INCENTIVES MISSING PROGRAM CONTRIBUTION GRID SETUP DETAIL REPORT</td></tr>");
				
					
				} else {
					batchMailContent
					.append("<tr><td>------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
					batchMailContent
					.append("<tr><td> NO CONTRACT ACTIVITY INCENTIVES MISSING PROGRAM CONTRIBUTION GRID SETUP . </td></tr>");
					batchMailContent
					.append("<tr><td>------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
				}
				batchMailContent
				.append("</table>");
				
				if (lPersonContractActivityToContribGridReports.size() > 0) {
					// column header
					batchMailContent
					.append("<table>");
					batchMailContent.append("<tr><td> Line</td><td>Group No</td><td>Site No</td><td>Contract No</td><td>Member No</td><td>Relationship Name</td><td>Activity Name</td><td>Incentive Option Name</td><td>Incentive Status Type</td><td>Incentive Rule Type Desc</td></tr>");
					
					int rowCt = 1;
			    	for (PersonActivityToContribGridReport lPersonContractActivityToContribGridReport: lPersonContractActivityToContribGridReports) {
							
			    		batchMailContent
						.append("<tr><td colspan=10>-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
						batchMailContent.append("<tr><td> "
								+ rowCt + "</td><td>"
								+ lPersonContractActivityToContribGridReport.getGroupNumber() + "</td><td>"
								+ lPersonContractActivityToContribGridReport.getSiteNumber() + "</td><td>"
								+ lPersonContractActivityToContribGridReport.getContractNumber() + "</td><td>"
								+ lPersonContractActivityToContribGridReport.getMemberNumber() + "</td><td>"
								+ lPersonContractActivityToContribGridReport.getRelationshipName() + "</td><td>"
								+ lPersonContractActivityToContribGridReport.getActivityName() + "</td><td>" 
								+ lPersonContractActivityToContribGridReport.getIncentiveOptionName() + "</td><td>" 
								+ lPersonContractActivityToContribGridReport.getIncentiveStatusType() + "</td><td>" 
								+ lPersonContractActivityToContribGridReport.getIncentiveRuleTypeDesc() + "</td><td>" 
								+ "</td></tr>");
						rowCt++;
			
						if (rowCt > 100) {
							batchMailContent
							.append("<tr><td>   </td></tr>");
							batchMailContent
							.append("<tr><td>   </td></tr>");
							//cap report list at 100
							batchMailContent
							.append("<tr><td colspan=12>***ATTENTION: REPORT CUTOFF AT 100 ROWS.  " + "A TOTAL OF " + lPersonActivityToContribGridReports.size() + " CONTRACT ACTIVITY INCENTIVES UNRESOLVED BENEFIT CONTRACT TYPES.</td></tr>");
							break;
						}
			    	}
			    	batchMailContent
					.append("<tr><td colspan=10>============================================================================================================================================================================================================================</td></tr>");
			    	batchMailContent
					.append("</table>");
			    	
				} 
				
				
		    	emailService.setEmailDestination(BPMConstants.BPM_EMAIL_TO_ADDR_RECONCILE_RPT);
		    	emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
				emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
						batchMailContent.toString());
			}

			
			public void setPersonDAO(PersonDAO personDAO) {
				this.personDAO = personDAO;
			}


			public void setEmailService(EmailService emailService) {
				this.emailService = emailService;
			}

			
			
		

}

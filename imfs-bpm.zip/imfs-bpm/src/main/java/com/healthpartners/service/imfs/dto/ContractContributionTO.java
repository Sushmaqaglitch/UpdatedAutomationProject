package com.healthpartners.service.imfs.dto;

/**
 * 
 * @author tjquist
 *
 */
public class ContractContributionTO {
	
	
	private Integer contractNo;
	private java.sql.Date contributionDate;
	private Integer contributionAmountTotal;
	private Integer memberCount;
	
	public Integer getContractNo() {
		return contractNo;
	}
	public void setContractNo(Integer contractNo) {
		this.contractNo = contractNo;
	}
	
	public java.sql.Date getContributionDate() {
		return contributionDate;
	}
	public void setContributionDate(java.sql.Date contributionDate) {
		this.contributionDate = contributionDate;
	}
	
	public Integer getContributionAmountTotal() {
		return contributionAmountTotal;
	}
	public void setContributionAmountTotal(Integer contributionAmountTotal) {
		this.contributionAmountTotal = contributionAmountTotal;
	}
	public Integer getMemberCount() {
		return memberCount;
	}
	public void setMemberCount(Integer memberCount) {
		this.memberCount = memberCount;
	}
	
	
    
}

/* $Id$ */

package com.healthpartners.service.imfs.impl;


import java.sql.Date;
import java.util.Collection;

import com.healthpartners.service.imfs.exception.BPMBusinessValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.dao.GroupSiteYearStageDAO;
import com.healthpartners.service.imfs.dao.ReconLogStageDAO;
import com.healthpartners.service.imfs.dao.PersonProgramStageDAO;

import com.healthpartners.service.imfs.dto.ActivityFulfillmentTrackingReportHist;
import com.healthpartners.service.imfs.dto.GroupSiteYearStage;
import com.healthpartners.service.imfs.dto.PersonActivityStage;
import com.healthpartners.service.imfs.dto.PersonActivitySummaryStage;
import com.healthpartners.service.imfs.dto.PersonProgramStage;

import com.healthpartners.service.imfs.dto.ReconLogStage;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.iface.MembershipFeedStageService;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


/**
 * @author tjquist
 * 
 */
@Component
@Service
public class MembershipFeedStageServiceImpl implements MembershipFeedStageService {
	@Autowired
	private GroupSiteYearStageDAO groupSiteYearStageDAO;
	@Autowired
	private PersonProgramStageDAO personProgramStageDAO;
	@Autowired
	private ReconLogStageDAO reconLogStageDAO;


	/*
	 * @see com.healthpartners.service.bpm.iface.GroupSiteYearStageService#getGroupSiteYearCount()
	 */
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public int getGroupSiteYearCount()
			throws BPMException, DataAccessException {
		return groupSiteYearStageDAO.getGroupSiteYearCount();
	}

	/*
	 * @see com.healthpartners.service.bpm.iface.GroupSiteYearStageService#insertGroupSiteYears()
	 */
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public int insertGroupSiteYears(Collection<GroupSiteYearStage> groupSiteYears)
		throws BPMException, DataAccessException {
		return groupSiteYearStageDAO.insertGroupSiteYears(groupSiteYears);
	}

	/*
	 * @see com.healthpartners.service.bpm.iface.GroupSiteYearStageService#deleteGroupSiteYears()
	 */
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public int deleteGroupSiteYears(Collection<GroupSiteYearStage> groupSiteYears) 
		throws BPMException, DataAccessException {
		
		return groupSiteYearStageDAO.deleteGroupSiteYears(groupSiteYears);
	}
	
	/*
	 * @see com.healthpartners.service.bpm.iface.GroupSiteYearStageService#getGroupSiteYear()
	 */
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public GroupSiteYearStage getGroupSiteYear(int groupNumber, int siteNumber, java.sql.Date qualStartDate)
		throws BPMException, DataAccessException {
		
		return groupSiteYearStageDAO.getGroupSiteYear(groupNumber, siteNumber, qualStartDate);
	}
	
	/*
	 * @see com.healthpartners.service.bpm.iface.GroupSiteYearStageService#getGroupSiteYears()
	 */
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public Collection<GroupSiteYearStage> getGroupSiteYears()
		throws BPMException, DataAccessException {
		
		return groupSiteYearStageDAO.getGroupSiteYears();
	}
	
	/*
	 * @see com.healthpartners.service.bpm.iface.PersonProgramStageService#getPersonActivityCount()
	 */
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public int getPersonActivityCount()
			throws BPMException, DataAccessException {
		return personProgramStageDAO.getPersonActivityCount();
	}


	/*
	 * @see com.healthpartners.service.bpm.iface.PersonProgramStageService#getPersonActivity()
	 */
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public PersonActivityStage getPersonActivity(int personNumber)
		throws BPMException, DataAccessException {
		
		return personProgramStageDAO.getPersonActivity(personNumber);
	}
	
	/*
	 * @see com.healthpartners.service.bpm.iface.PersonProgramStageService#insertPersonActivitys()
	 */
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public int insertPersonActivitys(Collection<ActivityFulfillmentTrackingReportHist> lActivityFulfillmentTrackingReportHist)
		throws BPMException, DataAccessException, Exception {
		return personProgramStageDAO.insertPersonActivitys(lActivityFulfillmentTrackingReportHist);
	}

	/*
	 * @see com.healthpartners.service.bpm.iface.PersonProgramStageService#deletePersonActivitys()
	 */
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public int deletePersonActivitys() 
		throws BPMException, DataAccessException {
		
		return personProgramStageDAO.deletePersonActivitys();
	}
	
	/*
	 * @see com.healthpartners.service.bpm.iface.PersonProgramStageService#insertPersonActivitys()
	 */
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public int insertPersonActivitySummary(int recordsSentToMembershipPremiumBillingCount)
		throws BPMException, DataAccessException, Exception {
		
		PersonActivitySummaryStage lPersonActivitySummaryStage = new PersonActivitySummaryStage();
		lPersonActivitySummaryStage.setNumberOfRecords(recordsSentToMembershipPremiumBillingCount);
		
		return personProgramStageDAO.insertPersonActivitySummary(lPersonActivitySummaryStage);
	}
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public PersonActivitySummaryStage getPersonActivitySummary() throws BPMException, DataAccessException {
		
		return personProgramStageDAO.getPersonActivitySummary();
		
	}

	/*
	 * @see com.healthpartners.service.bpm.iface.PersonProgramStageService#deletePersonActivitys()
	 */
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public int deletePersonActivitySummary() 
		throws BPMException, DataAccessException {
		
		return personProgramStageDAO.deletePersonActivitys();
	}
	
	
	
	/*
	 * @see com.healthpartners.service.bpm.iface.PersonProgramStageService#getPersonPrograms()
	 */
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public Collection<PersonActivityStage> getPersonActivitys()
		throws BPMException, DataAccessException {
		
		return personProgramStageDAO.getPersonActivitys();
	}
	
	/*
	 * @see com.healthpartners.service.bpm.iface.PersonProgramStageService#getPersonProgramCount()
	 */
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public int getPersonProgramCount()
			throws BPMException, DataAccessException {
		return personProgramStageDAO.getPersonProgramCount();
	}

	/*
	 * @see com.healthpartners.service.bpm.iface.PersonProgramStageService#insertPersonPrograms()
	 */
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public int insertPersonPrograms(Collection<PersonProgramStage> personPrograms)
		throws BPMException, DataAccessException {
		return personProgramStageDAO.insertPersonPrograms(personPrograms);
	}

	/*
	 * @see com.healthpartners.service.bpm.iface.PersonProgramStageService#deletePersonPrograms()
	 */
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public int deletePersonPrograms(Collection<PersonProgramStage> personPrograms) 
		throws BPMException, DataAccessException {
		
		return personProgramStageDAO.deletePersonPrograms(personPrograms);
	}
	
	/*
	 * @see com.healthpartners.service.bpm.iface.PersonProgramStageService#getPersonProgram()
	 */
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public PersonProgramStage getPersonProgram(int personNumber)
		throws BPMException, DataAccessException {
		
		return personProgramStageDAO.getPersonProgram(personNumber);
	}
	
	/*
	 * @see com.healthpartners.service.bpm.iface.PersonProgramStageService#getPersonPrograms()
	 */
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public Collection<PersonProgramStage> getPersonPrograms()
		throws BPMException, DataAccessException {
		
		return personProgramStageDAO.getPersonPrograms();
	}

	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public ReconLogStage getReconLogStage(Integer id)
    		throws DataAccessException {
		return reconLogStageDAO.getReconLogStage(id);
	}
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public  int insertReconLogStage(ReconLogStage reconLogStage)
	    	throws DataAccessException {
		return	reconLogStageDAO.insertReconLogStage(reconLogStage);
	}
	
	//Bean injections of DAO objects.

	public GroupSiteYearStageDAO getGroupSiteYearStageDAO() {
		return groupSiteYearStageDAO;
	}

	public void setGroupSiteYearStageDAO(GroupSiteYearStageDAO groupSiteYearStageDAO) {
		this.groupSiteYearStageDAO = groupSiteYearStageDAO;
	}

	public PersonProgramStageDAO getPersonProgramStageDAO() {
		return personProgramStageDAO;
	}

	public void setPersonProgramStageDAO(PersonProgramStageDAO personProgramStageDAO) {
		this.personProgramStageDAO = personProgramStageDAO;
	}

	public ReconLogStageDAO getReconLogStageDAO() {
		return reconLogStageDAO;
	}

	public void setReconLogStageDAO(ReconLogStageDAO reconLogStageDAO) {
		this.reconLogStageDAO = reconLogStageDAO;
	}

	


}

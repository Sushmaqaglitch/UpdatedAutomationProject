/* $Id: OutboundFileFactory.java 153848 2008-11-12 20:55:34Z tjquist $ */

package com.healthpartners.service.imfs.factory;

import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.CDHPFulfillmentTrackingReport;
import com.healthpartners.service.imfs.dto.DetailHRA;
import com.healthpartners.service.imfs.dto.DetailHSA;
import com.healthpartners.service.imfs.dto.HeaderHRA;
import com.healthpartners.service.imfs.dto.HeaderHSA;
import com.healthpartners.service.imfs.dto.TrailerHRA;
import com.healthpartners.service.imfs.dto.TrailerHSA;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.*;
import org.springframework.stereotype.Component;

@Component
public class OutboundCDHPTransFactory {

	
	public static DetailHRA detailHRAMapper(CDHPFulfillmentTrackingReport lCDHPHRAFulfillmentTrackingReport, String fileCreateDate) {
		
		String contributionDate = BPMUtils.formatDateCCYYmmddWODel(lCDHPHRAFulfillmentTrackingReport.getContributionDate());
		
		DetailHRA lDetailHRA = new DetailHRA();
		lDetailHRA.setRecordID(Integer.toString(lCDHPHRAFulfillmentTrackingReport.getCDHPTransID()));
		lDetailHRA.setRecordType("D");
		lDetailHRA.setActivityType(lCDHPHRAFulfillmentTrackingReport.getIncentiveReportName());
		lDetailHRA.setPolicyHolderSocialSecurityNumber("");
		lDetailHRA.setEmployerTaxID("");
		lDetailHRA.setContributionAmount(lCDHPHRAFulfillmentTrackingReport.getContributionAmount());
		lDetailHRA.setContributionDate(contributionDate);
		lDetailHRA.setFileDate(fileCreateDate);
		lDetailHRA.setHpGroupID(lCDHPHRAFulfillmentTrackingReport.getGroupNo());
		lDetailHRA.setPolicyHolderFirstName(lCDHPHRAFulfillmentTrackingReport.getFirstName());
		lDetailHRA.setPolicyHolderLastName(lCDHPHRAFulfillmentTrackingReport.getLastName());
		lDetailHRA.setPolicyHolderMiddleInit(lCDHPHRAFulfillmentTrackingReport.getMiddleName());
		lDetailHRA.setPolicyHolderHPContractID(Integer.toString(lCDHPHRAFulfillmentTrackingReport.getContractNo()));
		lDetailHRA.setPolicyHolderHPMemberID(lCDHPHRAFulfillmentTrackingReport.getMemberNo());
		//lDetailHRA.setActivityID(lCDHPHRAFulfillmentTrackingReport.getSourceActivityID());
			
		return lDetailHRA;
		
	}
	
	public static DetailHSA detailHSAMapper(CDHPFulfillmentTrackingReport lCDHPHSAFulfillmentTrackingReport, String fileCreateDate) {
		
	
		String contributionDate = BPMUtils.formatDateCCYYmmddWODel(lCDHPHSAFulfillmentTrackingReport.getContributionDate());
		
		DetailHSA lDetailHSA = new DetailHSA();
		lDetailHSA.setEmployerGroupName(lCDHPHSAFulfillmentTrackingReport.getEmployerGroupName());
		lDetailHSA.setRecordID(Integer.toString(lCDHPHSAFulfillmentTrackingReport.getCDHPTransID()));
		lDetailHSA.setRecordType("D");
		lDetailHSA.setActivityType(lCDHPHSAFulfillmentTrackingReport.getIncentiveReportName());
		lDetailHSA.setActivityDate(BPMUtils.formatDateMMddyyyy(lCDHPHSAFulfillmentTrackingReport.getContributionDate()));
		lDetailHSA.setPolicyHolderSocialSecurityNumber(lCDHPHSAFulfillmentTrackingReport.getSocialSecurityNo());
		lDetailHSA.setEmployerTaxID("");
		lDetailHSA.setContributionAmount(lCDHPHSAFulfillmentTrackingReport.getContributionAmount());
		lDetailHSA.setContributionDate(contributionDate);
		lDetailHSA.setFileDate(fileCreateDate);
		lDetailHSA.setHpGroupID(lCDHPHSAFulfillmentTrackingReport.getGroupNo());
		lDetailHSA.setPolicyHolderFirstName(lCDHPHSAFulfillmentTrackingReport.getFirstName());
		lDetailHSA.setPolicyHolderLastName(lCDHPHSAFulfillmentTrackingReport.getLastName());
		lDetailHSA.setPolicyHolderMiddleInit(lCDHPHSAFulfillmentTrackingReport.getMiddleName());
		lDetailHSA.setPolicyHolderHPContractID(Integer.toString(lCDHPHSAFulfillmentTrackingReport.getContractNo()));
		lDetailHSA.setPolicyHolderHPMemberID(lCDHPHSAFulfillmentTrackingReport.getMemberNo());
		lDetailHSA.setContributionType(lCDHPHSAFulfillmentTrackingReport.getContributionType());
		
			
		return lDetailHSA;
		
	}
	
	public static HeaderHRA headerHRAMapper(String fileCreateDate, String employerGroupID, String lCDHPEnvIdentifier) {
		
		HeaderHRA lHeaderHRA = new HeaderHRA();
		lHeaderHRA.setRecordType("H");
		lHeaderHRA.setFileDate(fileCreateDate);
		lHeaderHRA.setFileClassification(lCDHPEnvIdentifier);
		lHeaderHRA.setCarrierID("HEALTHPARTNERS");
		lHeaderHRA.setEmployerGroupID(employerGroupID);
		
		return lHeaderHRA;
		
	}
	
	public static HeaderHSA headerHSAMapper(String fileCreateDate, String employerGroupID, String lCDHPEnvIdentifier) {
		
		HeaderHSA lHeaderHSA = new HeaderHSA();
		lHeaderHSA.setRecordType("H");
		lHeaderHSA.setFileDate(fileCreateDate);
		lHeaderHSA.setFileClassification(lCDHPEnvIdentifier);
		lHeaderHSA.setCarrierID("HEALTHPARTNERS");
		lHeaderHSA.setEmployerGroupID(employerGroupID);
		
		return lHeaderHSA;
		
	}
	
	public static TrailerHRA trailerHRAMapper(int recordCount) {
		TrailerHRA lTrailerHRA = new TrailerHRA();
		lTrailerHRA.setTotalRecords(Integer.toString(recordCount));
		lTrailerHRA.setRecordType("T");
		
		return lTrailerHRA;
	}
	
	public static TrailerHSA trailerHSAMapper(int recordCount) {
		TrailerHSA lTrailerHSA = new TrailerHSA();
		lTrailerHSA.setTotalRecords(Integer.toString(recordCount));
		lTrailerHSA.setRecordType("T");
		
		return lTrailerHSA;
	}
	
	
	
}

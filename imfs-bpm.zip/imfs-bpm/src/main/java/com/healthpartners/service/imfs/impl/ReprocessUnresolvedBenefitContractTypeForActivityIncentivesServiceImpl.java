package com.healthpartners.service.imfs.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import com.healthpartners.service.imfs.common.BPMConstants;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dao.PersonDAO;
import com.healthpartners.service.imfs.dto.LookUpValueCode;
import com.healthpartners.service.imfs.dto.PersonActivityIncentToFulfillReconcile;
import com.healthpartners.service.imfs.dto.PersonActivityIncentive;
import com.healthpartners.service.imfs.dto.PersonProgramActivityIncentiveStatus;
import com.healthpartners.service.imfs.exception.BPMBusinessValidationException;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.iface.ActivityEventService;
import com.healthpartners.service.imfs.iface.BusinessProgramService;
import com.healthpartners.service.imfs.iface.EmailService;
import com.healthpartners.service.imfs.iface.LookUpValueService;
import com.healthpartners.service.imfs.iface.MemberService;
import com.healthpartners.service.imfs.iface.ReprocessUnresolvedBenefitContractTypeForActivityIncentivesService;
import com.healthpartners.service.imfs.iface.UploadEmployerActivityIncentToFulfillReconService;
import com.healthpartners.service.imfs.iface.UploadEmployerActivityPostprocessService;
import com.healthpartners.service.imfs.rules.StatusCalculationCommand;
@Component
@Service
public class ReprocessUnresolvedBenefitContractTypeForActivityIncentivesServiceImpl implements ReprocessUnresolvedBenefitContractTypeForActivityIncentivesService {
	

	protected final Log logger = LogFactory.getLog(getClass());
	@Autowired
	private PersonDAO personDAO;
	@Autowired
	private MemberService memberService;

	@Autowired
	private EmailService emailService;
	
	
	
	/*
	 * Batch job that will search against the activity incented table looking for benefit contract types set to UNRESOLVED.  Create 
	 * a processing status log record per participant effected.  By putting the participant through a member update will allow the benefit contract type
	 * to be resolved back to the activity incentive.
	*/
		@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
				BPMBusinessValidationException.class, BPMException.class })
	public void processUnresolvedContractBenefitTypeForActivityIncentiveCommand(StatusCalculationCommand statusCalculationCommand) throws BPMException {
			
				logger.info("@Start - Processing Unresolved Contract Benefit Type For Activity Incentive Command. ");
				
				
				String failureReason = null;
				
				statusCalculationCommand.setCurrentCommandText("Processing Unresolved Contract Benefit Type For Activity Incentive");
				
				Collection<PersonProgramActivityIncentiveStatus> lPersonProgramActivityIncentiveStatuses  = personDAO.getUnresolvedPersonPgmActivityIncentiveStatus();
				
			
				String userId = null;
				if (statusCalculationCommand.getUserID() != null) {
					userId = statusCalculationCommand.getUserID();
				} else {
					userId = BPMConstants.BPM_USER_SYSTEM;
				}
				
				int totalProcessingStatusRecs = 0;
				for (PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus : lPersonProgramActivityIncentiveStatuses) {
					memberService.insertPersonProcessingStatus(lPersonProgramActivityIncentiveStatus.getPersonDemographicsID(), BPMConstants.BPM_ADMIN_UNRESOLVED_BENEFIT_CONTRACT_TYPE_PRCS_ID, BPMConstants.PROCESSING_STATUS_PENDING, userId);
					totalProcessingStatusRecs++;
				}
								
				createReport(statusCalculationCommand, lPersonProgramActivityIncentiveStatuses, failureReason, totalProcessingStatusRecs);
				
				logger.info("@End - Processing Unresolved Contract Benefit Type For Activity Incentive Command.");
				
	}
		
		/*
		 * Produce a report that shows activity incentives with benefit contract types of unresolved that will be recorded to the processing status log.
		 */
			@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
					BPMBusinessValidationException.class, BPMException.class })
		private void createReport(StatusCalculationCommand statusCalculationCommand, Collection<PersonProgramActivityIncentiveStatus> lPersonProgramActivityIncentiveStatuses, String failureReason, int totalProcessingStatusRecs) throws BPMException
			{
				logger.info("@Start - Create Processing Unresolved Contract Benefit Type For Activity Incentive Report. ");
				
				
				StringBuffer batchMailSubject = new StringBuffer();
				
				batchMailSubject
				.append("BPM Batch - Processing Unresolved Contract Benefit Type For Activity Incentive ");
				
				batchMailSubject.append(" / Status");
				StringBuffer batchMailContent = new StringBuffer();
				batchMailContent
				.append("<table>");
				batchMailContent.append("<tr><td>BPM Batch Name: Processing Unresolved Contract Benefit Type For Activity Incentive </td></tr>");

				batchMailContent.append("<tr><td>Initiated User: "
						+ statusCalculationCommand.getUserID());
				
				if (failureReason != null) {
					batchMailSubject.append("- FAILED");
					batchMailContent.append("<tr><td>Result: FAILED</td></tr>");
					batchMailContent.append("<tr></td>Reason: \n");
					batchMailContent.append(failureReason + "</td></tr>");
				} else {
					batchMailSubject.append("- SUCCESS");
					batchMailContent.append("<tr></td>Result: SUCCESS</td></tr>");
				}
				
				batchMailContent
				.append("</table>");
				batchMailContent
				.append("<table>");
				
				if (lPersonProgramActivityIncentiveStatuses.size() > 0) {
					batchMailContent
					.append("<tr><td>-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
					batchMailContent
							.append("<tr><td>Total Member Incented Activites with unresolved benefit contract types:  " + lPersonProgramActivityIncentiveStatuses.size() + "</td></tr>");
					batchMailContent
					.append("<tr><td>Total Processing Status Log records inserted for reprocessing:  " + totalProcessingStatusRecs + "</td></tr>");
					batchMailContent
					.append("<tr><td>-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
					batchMailContent
					.append("<tr><td>MEMBER ACTIVITY INCENTIVES WITH UNRESOLVED BENEFIT CONTRACT TYPES " +  " </td></tr> ");
					batchMailContent
					.append("</table>");
				} else {
					batchMailContent
					.append("<tr><td>-----------------------------------------------------------------------------------------------------------------</td></tr>");
					batchMailContent
					.append("<tr><td> No Member Incented Activities with unresolved benefit contract types to report. </td></tr>");
					batchMailContent
					.append("<tr><td>-----------------------------------------------------------------------------------------------------------------</td></tr>");
				}
				batchMailContent
				.append("</table>");
				
				if (lPersonProgramActivityIncentiveStatuses.size() > 0) {
					// column header
					batchMailContent
					.append("<table>");
					batchMailContent.append("<tr><td> Line</td><td>Member No</td><td>Activity Name</td><td>Incented Date</td></tr>");
					
					Iterator<PersonProgramActivityIncentiveStatus> iter  = (Iterator<PersonProgramActivityIncentiveStatus>) lPersonProgramActivityIncentiveStatuses.iterator();
					int rowCt = 1;
			    	while (iter.hasNext()) {
			    		PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus = (PersonProgramActivityIncentiveStatus)iter.next();
							
			    		batchMailContent
									.append("<tr><td colspan=12>----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
						batchMailContent.append("<tr><td> "
								+ rowCt + "</td><td>"
								+ lPersonProgramActivityIncentiveStatus.getMemberNo() + "</td><td>"
								+ lPersonProgramActivityIncentiveStatus.getActivityName() + "</td><td>" 
								+ lPersonProgramActivityIncentiveStatus.getActivityStatusIncentiveDate() + "</td><td>" 
								+ "</td></tr>");
						rowCt++;
			
						if (rowCt > 100) {
							batchMailContent
							.append("<tr><td>   </td></tr>");
							batchMailContent
							.append("<tr><td>   </td></tr>");
							//cap report list at 100
							batchMailContent
							.append("<tr><td colspan=12>***ATTENTION: REPORT CUTOFF AT 100 ROWS.  " + "A TOTAL OF " + lPersonProgramActivityIncentiveStatuses.size() + " MEMBER ACTIVITY INCENTIVES UNRESOLVED BENEFIT CONTRACT TYPES.</td></tr>");
							break;
						}
					
			    	} 
			    	
				} 
				
				batchMailContent
				.append("</table>");
		    	emailService.setEmailDestination(BPMConstants.BPM_EMAIL_TO_ADDR_RECONCILE_RPT);
		    	emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
				emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
						batchMailContent.toString());
			}


	public PersonDAO getPersonDAO() {
		return personDAO;
	}

	public void setPersonDAO(PersonDAO personDAO) {
		this.personDAO = personDAO;
	}

	public MemberService getMemberService() {
		return memberService;
	}

	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}

	public EmailService getEmailService() {
		return emailService;
	}

	public void setEmailService(EmailService emailService) {
		this.emailService = emailService;
	}
}

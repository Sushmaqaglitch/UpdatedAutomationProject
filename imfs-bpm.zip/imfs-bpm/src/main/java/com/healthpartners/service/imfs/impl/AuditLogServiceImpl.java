
package com.healthpartners.service.imfs.impl;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
//import org.springframework.transaction.TransactionDefinition;
//import org.springframework.transaction.TransactionStatus;
//import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.dao.AuditLogDAO;
import com.healthpartners.service.imfs.dto.BPMAuditRecord;
import com.healthpartners.service.imfs.exception.BPMBusinessValidationException;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.iface.AuditLogService;


@Component
public class AuditLogServiceImpl implements
		AuditLogService {


	protected final Log logger = LogFactory.getLog(getClass());

	
	/**
	 * dao's references
	 */
	@Autowired
	private AuditLogDAO auditLogDAO;

	

	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public Integer insertAuditLog(BPMAuditRecord BPMAuditRecord)
			throws DataAccessException {
		Integer result;
		try {
			
			result = auditLogDAO.insertAuditLog(BPMAuditRecord);

		} catch (DataAccessException dae) {
			//txManager.rollback(status);
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		}
		
		return result;
	}

	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = {
			DataAccessException.class, BPMBusinessValidationException.class, BPMException.class })
	public Integer purgeAuditLogByDate(java.sql.Date purgeDate)
			throws DataAccessException {
		Integer result;
		try {
			
			result = auditLogDAO.purgeAuditLogByDate(purgeDate);
			
			// Commit the transaction.
			//txManager.commit(status);
		} catch (DataAccessException dae) {
			//txManager.rollback(status);
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		}
		
		return result;
	}
	
	public Integer getAuditLogCount()
			throws DataAccessException {
		
		int result = auditLogDAO.getAuditLogCount();
		
		return result;
	}


	public AuditLogDAO getAuditLogDAO() {
		return auditLogDAO;
	}
	public void setAuditLogDAO(AuditLogDAO auditLogDAO) {
		this.auditLogDAO = auditLogDAO;
	}


	
}

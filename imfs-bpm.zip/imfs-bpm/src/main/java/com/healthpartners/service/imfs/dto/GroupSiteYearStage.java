package com.healthpartners.service.imfs.dto;

import java.sql.Date;
import java.sql.Time;
/**
 * 
 * @author tjquist
 *
 */
public class GroupSiteYearStage extends BaseDTO {
	
	static final long serialVersionUID = 0L;
	
	private Integer groupNumber;
	private Date newHireDate;
	private String participationRequiredDesc;
	private String programType;
	private Date qualificationEndDate;
	private Date qualificationStartDate;
	private Date programEndDate;
	private Date programStartDate;
	private Date runDate;
	private Time runTime;
	private Integer siteNumber;
	private String membershipProcessFlag;
	
	
	
    public GroupSiteYearStage()
    {
    	super();
    }



	public Integer getGroupNumber() {
		return groupNumber;
	}



	public void setGroupNumber(Integer groupNumber) {
		this.groupNumber = groupNumber;
	}



	public Date getNewHireDate() {
		return newHireDate;
	}



	public void setNewHireDate(Date newHireDate) {
		this.newHireDate = newHireDate;
	}


	public String getProgramType() {
		return programType;
	}



	public void setProgramType(String programType) {
		this.programType = programType;
	}



	public Date getQualificationEndDate() {
		return qualificationEndDate;
	}



	public void setQualificationEndDate(Date qualificationEndDate) {
		this.qualificationEndDate = qualificationEndDate;
	}



	public Date getQualificationStartDate() {
		return qualificationStartDate;
	}



	public void setQualificationStartDate(Date qualificationStartDate) {
		this.qualificationStartDate = qualificationStartDate;
	}



	public Date getRunDate() {
		return runDate;
	}



	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}



	public Time getRunTime() {
		return runTime;
	}



	public void setRunTime(Time runTime) {
		this.runTime = runTime;
	}



	public Integer getSiteNumber() {
		return siteNumber;
	}



	public void setSiteNumber(Integer siteNumber) {
		this.siteNumber = siteNumber;
	}



	public String getParticipationRequiredDesc() {
		return participationRequiredDesc;
	}



	public void setParticipationRequiredDesc(String participationRequiredDesc) {
		this.participationRequiredDesc = participationRequiredDesc;
	}



	public final String getMembershipProcessFlag() {
		return membershipProcessFlag;
	}



	public final void setMembershipProcessFlag(String membershipProcessFlag) {
		this.membershipProcessFlag = membershipProcessFlag;
	}



	public Date getProgramEndDate() {
		return programEndDate;
	}



	public void setProgramEndDate(Date programEndDate) {
		this.programEndDate = programEndDate;
	}



	public Date getProgramStartDate() {
		return programStartDate;
	}



	public void setProgramStartDate(Date programStartDate) {
		this.programStartDate = programStartDate;
	}
	
}

	
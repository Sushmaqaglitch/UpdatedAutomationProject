package com.healthpartners.service.imfs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.actuate.autoconfigure.endpoint.jmx.JmxEndpointAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ImportResource;
import org.springframework.web.WebApplicationInitializer;


@SpringBootApplication(exclude = JmxEndpointAutoConfiguration.class)
@ImportResource({"classpath*:beans.xml"})
@EnableConfigurationProperties
public class SpringBootImfsBpmApplication extends SpringBootServletInitializer implements WebApplicationInitializer {
    public static void main(String[] args) {

        SpringApplication.run(SpringBootImfsBpmApplication.class, args);
    }
}
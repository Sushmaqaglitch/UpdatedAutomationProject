package com.healthpartners.service.imfs.dto;

import java.sql.Date;

/**
 * 
 * @author tjquist
 *
 */
public class PersonActivityIncentToFulfillReconcile extends BaseDTO {
	
	static final long serialVersionUID = 0L;
	
	private Integer programID;
	private String groupNo;
	private String siteNo;
	private Date programEffectiveDate;
	private Date programEndDate;
	private Integer personDemographicsID;
	private Integer activityID;
	private String registrationID;
	private String memberNumber;
	private String firstName;
	private String lastName;
	private String activityName;
	private String sourceSystem;
	private String contributionAmount;
	private Date   incentedDate;
	//EV91299
	private String contractNo;
	
	
	
    public PersonActivityIncentToFulfillReconcile()
    {
    	super();
    }





	public Integer getProgramID() {
		return programID;
	}





	public void setProgramID(Integer programID) {
		this.programID = programID;
	}





	public String getGroupNo() {
		return groupNo;
	}





	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}



	


	public String getSiteNo() {
		return siteNo;
	}





	public void setSiteNo(String siteNo) {
		this.siteNo = siteNo;
	}





	public Date getProgramEffectiveDate() {
		return programEffectiveDate;
	}





	public void setProgramEffectiveDate(Date programEffectiveDate) {
		this.programEffectiveDate = programEffectiveDate;
	}





	public Date getProgramEndDate() {
		return programEndDate;
	}





	public void setProgramEndDate(Date programEndDate) {
		this.programEndDate = programEndDate;
	}


	


	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}





	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}





	public Integer getActivityID() {
		return activityID;
	}





	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}





	public String getRegistrationID() {
		return registrationID;
	}





	public void setRegistrationID(String registrationID) {
		this.registrationID = registrationID;
	}





	public String getMemberNumber() {
		return memberNumber;
	}





	public void setMemberNumber(String memberNumber) {
		this.memberNumber = memberNumber;
	}





	public String getFirstName() {
		return firstName;
	}





	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}





	public String getLastName() {
		return lastName;
	}





	public void setLastName(String lastName) {
		this.lastName = lastName;
	}





	public String getActivityName() {
		return activityName;
	}





	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}





	public String getSourceSystem() {
		return sourceSystem;
	}





	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}





	public String getContributionAmount() {
		return contributionAmount;
	}





	public void setContributionAmount(String contributionAmount) {
		this.contributionAmount = contributionAmount;
	}





	public Date getIncentedDate() {
		return incentedDate;
	}





	public void setIncentedDate(Date incentedDate) {
		this.incentedDate = incentedDate;
	}





	public String getContractNo() {
		return contractNo;
	}





	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	
    
}

package com.healthpartners.service.imfs.dto;

import java.io.Serializable;

public class EmployerFulfillmentMemberActivity implements Serializable
{	
	static final long serialVersionUID = 0L;

	private String activityCode;
	private String employeeID;
	private java.sql.Date activityCompletionDate;
		
    public EmployerFulfillmentMemberActivity()
    {
    	super();
    }

	public String getActivityCode() {
		return activityCode;
	}

	public void setActivityCode(String activityCode) {
		this.activityCode = activityCode;
	}

	public String getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}

	public java.sql.Date getActivityCompletionDate() {
		return activityCompletionDate;
	}

	public void setActivityCompletionDate(java.sql.Date activityCompletionDate) {
		this.activityCompletionDate = activityCompletionDate;
	}

	
}

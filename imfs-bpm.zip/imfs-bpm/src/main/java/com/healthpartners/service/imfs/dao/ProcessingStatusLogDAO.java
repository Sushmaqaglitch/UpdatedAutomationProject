package com.healthpartners.service.imfs.dao;

import java.util.Collection;

import org.springframework.dao.DataAccessException;

/**
 * @author jxbourbour
 * 
 */
public interface ProcessingStatusLogDAO {

	public int updatePersonProcessingStatusLog(Integer pPersonID,
			Integer processId, String processingStatusValue, String userId)
			throws DataAccessException;

	public int[] updatePersonProcessingStatus(
			Collection<Integer> personIds, Integer processId,
			String processingStatusValue, String userId)
			throws DataAccessException;

	public long insertPersonProcessingStatusLog(Integer personId,
			Integer processId, String processingStatusValue, String userId)
			throws DataAccessException;

	public int[] insertPersonProcessingStatusLog(Collection<Integer> personIds,
			Integer processId, String processingStatusValue, String userId)
			throws DataAccessException;

	public Collection<Integer> getPendingPersonsTobeProcessed(int batchSize,
			int pProcessID) throws DataAccessException;

	public int getNumberOfPendingPersonsTobeProcessed(int pProcessID)
			throws DataAccessException;
	
	/**
	 * Delete ProcessingStatusLog records based on a date.</code>.
	 * 
	 * @param purgeDate
	 * @return the number of deleted records
	 * @throws DataAccessException
	 *             when a database-related error is encountered
	 */
	public Integer purgeProcessStatLogByDate(java.sql.Date purgeDate)
			throws DataAccessException;
	
	/**
	 * Get count of records on ProcessingStatusLog table.</code>.
	 * 
	 * @param none
	 * @return the record count of table
	 * @throws DataAccessException
	 *             when a database-related error is encountered
	 */
	public Integer getProcessStatLogCount() throws DataAccessException;

}

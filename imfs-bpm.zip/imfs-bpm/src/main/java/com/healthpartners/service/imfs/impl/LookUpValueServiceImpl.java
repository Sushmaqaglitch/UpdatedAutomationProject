/* $Id$ */

package com.healthpartners.service.imfs.impl;

import java.util.Collection;

import com.healthpartners.service.imfs.dao.LookUpValueDAO;
import com.healthpartners.service.imfs.dto.LookUpValueCode;
import com.healthpartners.service.imfs.iface.LookUpValueService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.exception.BPMException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;


/**
 * A caching implementation of the LookUpValueService interface. The caching
 * strategy used would be lazy load.
 * 
 * @author pbhenninger
 */
@Component
@Service
public class LookUpValueServiceImpl implements LookUpValueService
{

	protected final Log logger = LogFactory.getLog(getClass());
	@Autowired
	private LookUpValueDAO lookUpValueDAO;

	public LookUpValueServiceImpl() {
	}

	

	public LookUpValueCode getLUVCodeByGroupNValue(String group, String value)
			throws BPMException, DataAccessException 
	{
		LookUpValueCode lookupValueCode = null;
		try {
			lookupValueCode = lookUpValueDAO.getLUVCodeByGroupNValue(group, value);
			
		} catch (Exception e) {			
			throw new BPMException(e.getMessage(), e);
		}

		return lookupValueCode;
	}
	

	public Collection<LookUpValueCode> getLUVCodesByGroup(String group)
			throws BPMException, DataAccessException 
	{
		Collection<LookUpValueCode> lookupValueCodes = null;
		try {
			lookupValueCodes = lookUpValueDAO.getLUVCodesByGroup(group);
			
		} catch (Exception e) {			
			throw new BPMException(e.getMessage(), e);
		}

		return lookupValueCodes;
	}
	

	public LookUpValueCode getLUVCodeByID(Integer luvID)
			throws BPMException, DataAccessException 
	{
		LookUpValueCode lookupValueCode = null;
		try {
			lookupValueCode = lookUpValueDAO.getLUVCodeByID(luvID);
			
		} catch (Exception e) {			
			throw new BPMException(e.getMessage(), e);
		}

		return lookupValueCode;
	}
	
	
	
	
	/**
	 * Sets the DAO for this service. Should only be called by Spring.
	 * 
	 * @param dao
	 *            the DAO to use for LookUpValueCodeDAO services
	 */
	public void setLookUpValueDAO(LookUpValueDAO dao) {
		this.lookUpValueDAO = dao;
	}
	
}

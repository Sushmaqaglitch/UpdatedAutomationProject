package com.healthpartners.service.imfs.iface;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;

import com.healthpartners.service.imfs.dto.ActivityEvent;
import com.healthpartners.service.imfs.dto.IncentiveOption;
import com.healthpartners.service.imfs.dto.PersonActivityIncentToFulfillReconcile;
import com.healthpartners.service.imfs.exception.BPMException;
import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.exception.BPMBusinessValidationException;
import com.healthpartners.service.imfs.exception.BPMException;

/**
 * Provides ActivityDefinition Update services.
 * 
 * @author tjquist
 * 
 */
public interface ActivityEventService {

	/**
	 * Recieves the ActivityEvent from web service call
	 * 
	 * @param activityEvent
	 * @return long - activityEventLogID
	 * @throws BPMBusinessValidationException
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public long recieveActivityEvent(ActivityEvent activityEvent)
			throws BPMBusinessValidationException, BPMException,
			DataAccessException;

	/**
	 * Process the <code>ActivityEvent</code>
	 * 
	 * @param activityEventLogID
	 * @throws BPMBusinessValidationException
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public void processActivityEvent(Long activityEventLogID)
			throws BPMBusinessValidationException, BPMException,
			DataAccessException;
	
	/**
	 * Process the <code>ActivityEvent</code>
	 *
	 * @throws BPMBusinessValidationException
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public void processActivityEventRealtime(ActivityEvent activityEvent)
			throws BPMBusinessValidationException, BPMException,
			DataAccessException;

	/**
	 * Updates table PERSON_PROGRAM_ACTIVITY_STATUS for each eligible program
	 * based on this <code>ActivityEvent</code>
	 * 
	 * @param activityEvent
	 * @throws BPMBusinessValidationException
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public void updatePersonProgramActivityStatus(ActivityEvent activityEvent)
			throws BPMBusinessValidationException, BPMException,
			DataAccessException;
	
	public Collection<ActivityEvent> getMemberActivityEventLogActivity(String pMemberID, String pSourceActivityID, Date pActivityDate) throws BPMException;
	
	public int updateActivityLogProcessingStatus(Collection<ActivityEvent> activityEvents, String processingStatus) throws BPMException;
	
	public void updatePersonActivityIncentiveWithModificationDate(Collection<PersonActivityIncentToFulfillReconcile> lPersonActivityIncentToFulfillReconcileDifferences) throws BPMBusinessValidationException, BPMException, DataAccessException;
	
	
	public Collection<ActivityEvent> getActivityEventLogsByProcessingStatus(String processingStatus, java.sql.Date activityEventCutoffDate, boolean twoDaysNolderFlag, String sourceSystemID) 
			throws DataAccessException;
	
	public Collection<ActivityEvent> getActivityEventLogsByGroup(String groupNo, String siteNo, String memberNo, String lActivityEventCutoffDate, String sourceSystemID) 
			throws DataAccessException;
	
	public int insertMemberActivityBasedOnPreconditionByGroup(String groupNo, String siteNo, IncentiveOption incentiveOption, String sourceActivityID) throws DataAccessException;
	

}

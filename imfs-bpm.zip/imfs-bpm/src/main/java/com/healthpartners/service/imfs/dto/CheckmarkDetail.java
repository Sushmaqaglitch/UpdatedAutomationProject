package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;

public class CheckmarkDetail implements Serializable
{	
	static final long serialVersionUID = 0L;
		
	private Integer qualificationCheckmarkID;
	private Integer requirementID;
	private Integer activityID;
	private String activityName;
	private Integer activityTypeCodeID;
	private String activityTypeCode;
	private String activityTypeDesc;
	private Integer quantity;
	
	private ActivityCollection activityCollection;
	
	public Integer getActivityID() {
		return activityID;
	}
	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}
	
	public Integer getActivityTypeCodeID() {
		return activityTypeCodeID;
	}
	public void setActivityTypeCodeID(Integer activityTypeCodeID) {
		this.activityTypeCodeID = activityTypeCodeID;
	}
	
	public Integer getQualificationCheckmarkID() {
		return qualificationCheckmarkID;
	}
	public void setQualificationCheckmarkID(Integer qualificationCheckmarkID) {
		this.qualificationCheckmarkID = qualificationCheckmarkID;
	}
	public Integer getRequirementID() {
		return requirementID;
	}
	public void setRequirementID(Integer requirementID) {
		this.requirementID = requirementID;
	}
	public String getActivityName() {
		return activityName;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public String getActivityTypeCode() {
		return activityTypeCode;
	}
	public void setActivityTypeCode(String activityTypeCode) {
		this.activityTypeCode = activityTypeCode;
	}
	public String getActivityTypeDesc() {
		return activityTypeDesc;
	}
	public void setActivityTypeDesc(String activityTypeDesc) {
		this.activityTypeDesc = activityTypeDesc;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public ActivityCollection getActivityCollection() {
		return activityCollection;
	}
	public void setActivityCollection(ActivityCollection activityCollection) {
		this.activityCollection = activityCollection;
	}

	
}

package com.healthpartners.service.imfs.impl;


import java.util.Collection;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dao.PersonDAO;
import com.healthpartners.service.imfs.exception.BPMBusinessValidationException;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.iface.ArchivePersonContractProgramHistoryService;
import com.healthpartners.service.imfs.dao.CallArchivePersonContractPgmHistory;
import com.healthpartners.service.imfs.iface.EmailService;
import com.healthpartners.service.imfs.rules.StatusCalculationCommand;
@Component
@Service
public class ArchivePersonContractProgramHistoryServiceImpl implements ArchivePersonContractProgramHistoryService {
	

	protected final Log logger = LogFactory.getLog(getClass());
	@Autowired
	private EmailService emailService;
	@Autowired
	private PersonDAO personDAO;
	@Autowired
	private CallArchivePersonContractPgmHistory callArchivePersonContractPgmHistory;
	
	
	
	
	/*
	 * This batch job is responsible for archiving records from the person contract program history (pcph) table that are older 3 years.  Older records are written to the archive table and then removed from pcph table.
	 * All this is done throug a stored procedure call.
	*/
		@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
				BPMBusinessValidationException.class, BPMException.class })
		/**
		 * Purge ProcessingStatusLog table by date batch process()
		 * Cutoff date for purging is controlled through the LUV table.
		 * 
		 * @param statusCalculationCommand
		 * @throws BPMException
		 * @throws DataAccessException
		 */
		            
		public void processArchivePersonContractProgramHistoryCommand(
				StatusCalculationCommand statusCalculationCommand)
				throws BPMException, DataAccessException {
			
			Integer personContractHistCountBefore = null;
			Integer personContractHistCountAfter = null;
			
			String failureReason = null;
			String elapsedTime = null;
			java.util.Date startDate = new java.util.Date();
			java.util.Date endDate = null;
			
			
			// text/label
			statusCalculationCommand.setCurrentCommandText("Archive Person Contract History Table");

			// set current command to fetch processID
			statusCalculationCommand
					.setCurrentProcessingCommand(StatusCalculationCommand.ARCHIVE_PERSONCONTRACTHIST_TABLE);
			
			logger.info("@@Start - Archive Person Contract History Table ...");	
		    
			try {
				
				java.sql.Date currentDate = BPMUtils.getCurrentDate();
				
				personContractHistCountBefore = getPersonContractHistCount();
				
				callArchivePersonContractPgmHistory(currentDate);
				
				personContractHistCountAfter = getPersonContractHistCount();
			
			
			} catch (Exception e) {
				failureReason = BPMUtils.getStakTraceAsString(e);
				logger.debug(failureReason, e);
			} finally {
				endDate = new java.util.Date();
				elapsedTime = BPMUtils
						.getTimeDifferenceAsString(startDate, endDate);
			}
			
			logger.info("@@End - Batch Archive Person Contract History table ...");
			
			// prepare summary email body
			StringBuffer batchMailSubject = new StringBuffer();
			batchMailSubject.append("BPM Batch Process Status (Archive/Purge Person Contract History)");
			StringBuffer batchMailContent = new StringBuffer();
			batchMailContent.append("<tr><td>" + "BPM Batch Name: "
					+ statusCalculationCommand.getCurrentCommandText() + "</td></tr>");
			batchMailContent.append("<tr><td>" + "Initiated User: "
					+ statusCalculationCommand.getUserID() + "</td></tr>");
			batchMailContent.append("<tr><td>" + "Time Start: "
					+ BPMUtils.getFormattedDateTime(startDate) + "</td></tr>");
			batchMailContent.append("<tr><td>" + "Time Completed: "
					+ BPMUtils.getFormattedDateTime(endDate) + "</td></tr>");
			batchMailContent.append("<tr><td>" + "Elapsed Time: " + elapsedTime + "</td></tr>");

			
			batchMailContent.append("<tr><td>" + "Note: Up to 3 years of history is kept." + "</td></tr>");
			
			batchMailContent.append("<tr><td>" + "Person Contract History records read before archive/purge: "
					+ personContractHistCountBefore + "</td></tr>");
			batchMailContent.append("<tr><td>" + "Person Contract History records read after archive/purge: "
					+ personContractHistCountAfter + "</td></tr>");
			batchMailContent.append("<tr><td>" + "Person Contract History records archived/purged: "
					+ (personContractHistCountBefore - personContractHistCountAfter) + "</td></tr>");
			
			if (failureReason != null) {
				batchMailSubject.append(" - FAILED");
				batchMailContent.append("<tr><td>" + "Result: FAILED" + "</td></tr>");
				batchMailContent.append("<tr><td>" + "Reason: " + "</td></tr>");
				batchMailContent.append(failureReason);
			} else {
				batchMailSubject.append(" - SUCCESS");
				batchMailContent.append("<tr><td>" + "Result: SUCCESS" + "</td></tr>");
			}
			emailService.setEmailContentType(BPMConstants.MAIL_CONTENT_TYPE_HTML);
			// send email batch summary
			emailService.prepareAndSendBatchStatusEmail(batchMailSubject.toString(),
					batchMailContent.toString());
			
			if (failureReason != null) {
				throw new BPMException(failureReason);
			}

			// finished, reset current command to null
			statusCalculationCommand.resetCurrentProcessingCommand();
		}
		
		
		/*
		 *  Using purge cutoff date, get person contract history records to be archived and purged.
		 */
		
		private void callArchivePersonContractPgmHistory(java.sql.Date purgeCutoffDate)

		{
			
			logger.info("Call callArchivePersonContractPgmHistory ");
			java.sql.Date currentDate = BPMUtils.getCurrentDate();
			callArchivePersonContractPgmHistory.execute(currentDate);
			logger.info("Call callArchivePersonContractPgmHistory finished");
									 
	    }
		
		
		private int getPersonContractHistCount()
			throws BPMException
		{
		
			int personContractHistoryCount = personDAO.getPersonContractHistCount();
			
			return personContractHistoryCount;
		}
			

		public void setPersonDAO(PersonDAO personDAO) {
			this.personDAO = personDAO;
		}

		public void setEmailService(EmailService emailService) {
			this.emailService = emailService;
		}


		public void setCallArchivePersonContractPgmHistory(
				CallArchivePersonContractPgmHistory callArchivePersonContractPgmHistory) {
			this.callArchivePersonContractPgmHistory = callArchivePersonContractPgmHistory;
		}

		
		

}

package com.healthpartners.service.imfs.dao;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.Activity;
import com.healthpartners.service.imfs.dto.ActivityDefinition;
import com.healthpartners.service.imfs.dto.ActivityEvent;
import com.healthpartners.service.imfs.dto.ActivityExternalEmployerXref;
import com.healthpartners.service.imfs.dto.AuthCode;
import com.healthpartners.service.imfs.dto.EligibleActivity;
import com.healthpartners.service.imfs.dto.EligibleProgramActivity;
import com.healthpartners.service.imfs.dto.GenericStatusType;
import com.healthpartners.service.imfs.dto.MemberActivity;
import com.healthpartners.service.imfs.dto.NamedParameter;
import com.healthpartners.service.imfs.dto.PersonProgramActivityStatus;
import com.healthpartners.service.imfs.exception.BPMException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.transaction.annotation.Transactional;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

@Configuration

public class ActivityDAOJdbc extends JdbcDaoSupport implements ActivityDAO {
    private String selectMemberActivities;

    private String selectMemberActivitiesOutsideEnrollment;

    private String selectMemberActivitiesForPortal;

    private String selectEligibleActivities;

    private String selectMemberActivityHistory;

    private String selectMemberActivityHistoryOutsideEnrollment;

    private String selectPersonProgramActivityHistory;

    private String selectPersonProgramActivityHistoryOutsideEnrollment;

    private String insertMemberActivity;

    private String updateMemberActivity;

    private String countMemberActivityRows;

    private String deleteMemberActivities;


    private String getActivity;

    private String selectActivities;

    private String selectActivitiesOrderByHost;

    private String selectRecommendedActivities;

    private String selectRecommendedActivitiesOutsideEnrollment;

    private String selectBusinessProgramForActivity;

    private String selectBusinessProgramForActivityOutsideEnrollment;


    private String selectNewBusinessPrograms;

    private String selectMemberDMActivities;

    private String selectMemberDMActivityHistory;

    private String selectMemberDMActivityHistoryOutsideEnrollment;

    private String selectCurrentYearActivitiesForTransfer;

    private String selectPreviousYearDMActivitiesForTransfer;

    private String selectEligibleProgramActivity;

    private String selectEligibleProgramActivityOutsideEnrollment;

    private String selectFilteredOutActivities;

    private String selectFilteredOutActivitiesOutsideEnrollment;

    private String selectMinimumOnlineDuration;
    private String selectMinimumDMDuration;
    private String selectMinimumPhoneDuration;
    private String selectExistingActivity;
    private String selectExistingActivityOutsideEnrollment;
    private String selectExistingWaive;
    private String selectExistingWaiveOutsideEnrollment;

    private String deleteMemberActivity;

    private String insertEligibleActivity;

    private String selectExtendedAuthCodes;
    private String selectEligibleAuthCodes;
    private String setActivitiesToPending;
    private String selectActivity;
    private String selectPersonProgramActivityStatus;
    private String selectPersonProgramActivityStatusOutsideEnrollment;
    private String selectActivityFromExternalActivity;
    private String selectEmployerAdminsterdActivities;
    private String selectExternalEmployerActivityXref;
    private String countMemberActivityInEmployerActivityXref;

    public ActivityDAOJdbc() {
        super();
    }

    @Autowired
    DataSource bpmDataSource;

    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;


    @PostConstruct
    private void initialize() {

        setDataSource(bpmDataSource);
    }

    /**
     * Selects a list of Member Activities given the member ID.
     *
     * @return ArrayList of MemberActivity objects.
     */
    @Transactional(timeout = 60, rollbackFor = {BPMException.class})
    public Collection<MemberActivity> getMemberActivities(Integer personId,
                                                          Integer programID, boolean pMemberPortal) {

        StringBuffer lQuery = new StringBuffer();
        Object params[] = null;

        if (pMemberPortal) {
            return getMemberActivitiesForPortal(personId, programID);
        }

        lQuery.append(selectMemberActivities);

        params = new Object[]{personId, personId,
                BPMConstants.BPM_TYPE_ACTIVITY_STATUS,
                BPMConstants.ACTIVITY_STATUS_DELETE,
                BPMConstants.BPM_TYPE_ACTIVITY_TYPE,
                BPMConstants.ACTIVITY_TYPE_DISEASE_MGMT, programID};

        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setPersonId(personId);
        namedParameter.setLuGrp(BPMConstants.BPM_TYPE_ACTIVITY_STATUS);
        namedParameter.setLuVal(BPMConstants.ACTIVITY_STATUS_DELETE);
        namedParameter.setLuGrpNo(BPMConstants.BPM_TYPE_ACTIVITY_TYPE);
        namedParameter.setLuValNo(BPMConstants.ACTIVITY_TYPE_DISEASE_MGMT);
        namedParameter.setBizPgmId(programID);

        lQuery.append(" ORDER BY PERSON_ACTIVITY.actv_stat_dt ");

        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);


        List<MemberActivity> lMemberActivities = namedParameterJdbcTemplate.query(lQuery
                .toString(), namedParameters, new activityMapper());

        //EV58500 - handle pre or post enrollment activities.
        ArrayList<MemberActivity> lMemberActivitiesOutsideEnrollment = (ArrayList<MemberActivity>) getMemberActivitiesOutsideEnrollment(
                personId, programID);

        if (lMemberActivitiesOutsideEnrollment.size() > 0) {
            lMemberActivities.addAll(lMemberActivitiesOutsideEnrollment);
        }

        // Get Disease Management Activities.
        ArrayList<MemberActivity> lMemberDMActivities = (ArrayList<MemberActivity>) getMemberDMActivities(
                personId, programID, pMemberPortal);

        lMemberActivities.addAll(lMemberDMActivities);

        // Get Activity History.
        getMemberActivityHistory(lMemberActivities, personId, programID);

        boolean lHasHAComplete = false;
        // If and HA has been received with a status of COMPLETE, remove the HA with a status of PENDING.
        for (int i = 0; i < lMemberActivities.size(); i++) {
            if (BPMConstants.BPM_ACTIVITY_TYPE_HA.equals(lMemberActivities.get(i).getActivity().getActivityTypeValue())
                    && BPMConstants.ACTIVITY_STATUS_COMPLETE.equalsIgnoreCase(lMemberActivities.get(i).getActivityStatus().getStatusCodeValue())) {
                lHasHAComplete = true;
                break;
            }
        }

        int lNumberOfActivities = lMemberActivities.size();
        for (int i = 0; i < lNumberOfActivities; i++) {
            if (BPMConstants.BPM_ACTIVITY_TYPE_HA.equals(lMemberActivities.get(i).getActivity().getActivityTypeValue())
                    && BPMConstants.ACTIVITY_STATUS_PENDING.equalsIgnoreCase(lMemberActivities.get(i).getActivityStatus().getStatusCodeValue())) {
                if (lHasHAComplete == true) {
                    lMemberActivities.remove(i);
                    lNumberOfActivities--;
                    i--;    // Reset the loop counter. Sometimes there is more than 1 Pending HA.
                    // Once there are no more PENDINGs in the list, the loop counter will be exhausted
                    // and the loop will end.
                }
            }
        }

        for (int i = 0; i < params.length; i++) {
            params[i] = null;
        }

        return lMemberActivities;
    }

    /**
     * Selects a list of Member Activities given the member ID outside of business program effective dates.  Looking for pre or post enrollment activities if they exist.
     *
     * @return ArrayList of MemberActivity objects.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    public Collection<MemberActivity> getMemberActivitiesOutsideEnrollment(Integer personId,
                                                                           Integer programID) {


        StringBuffer lQuery = new StringBuffer();
        Object params[] = null;
        int types[] = null;

        lQuery.append(selectMemberActivitiesOutsideEnrollment);

        params = new Object[]{personId, personId,
                BPMConstants.BPM_TYPE_ACTIVITY_STATUS,
                BPMConstants.ACTIVITY_STATUS_DELETE,
                BPMConstants.BPM_TYPE_ACTIVITY_TYPE,
                BPMConstants.ACTIVITY_TYPE_DISEASE_MGMT, programID};
        types = new int[]{Types.INTEGER, Types.INTEGER, Types.VARCHAR, Types.VARCHAR,
                Types.VARCHAR, Types.VARCHAR, Types.INTEGER};

        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setPersonId(personId);
        namedParameter.setLuGrp(BPMConstants.BPM_TYPE_ACTIVITY_STATUS);
        namedParameter.setLuVal(BPMConstants.ACTIVITY_STATUS_DELETE);
        namedParameter.setLuGrpNo(BPMConstants.BPM_TYPE_ACTIVITY_TYPE);
        namedParameter.setLuValNo(BPMConstants.ACTIVITY_TYPE_DISEASE_MGMT);
        namedParameter.setBizPgmId(programID);

        lQuery.append(" ORDER BY PERSON_ACTIVITY.actv_stat_dt ");

        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);


        List<MemberActivity> lMemberActivitiesOutsideEnrollment = namedParameterJdbcTemplate.query(lQuery
                .toString(), namedParameters, new activityMapper());


        return lMemberActivitiesOutsideEnrollment;
    }


    /**
     * For the web portal use a different SQL that returns the most recent activity when there are
     * multiple registrations for the same activity.
     *
     * @param personId
     * @param programID
     * @return
     * @deprecated
     */
    @Transactional(timeout = 60, rollbackFor = {BPMException.class})
    public Collection<MemberActivity> getMemberActivitiesForPortal(Integer personId, Integer programID) {
        StringBuffer lQuery = new StringBuffer();
        Object params[] = null;
        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setPersonId(personId);
        namedParameter.setLuGrp(BPMConstants.BPM_TYPE_ACTIVITY_TYPE);
        namedParameter.setLuVal(BPMConstants.ACTIVITY_TYPE_DISEASE_MGMT);
        namedParameter.setBizPgmId(programID);

        lQuery.append(selectMemberActivitiesForPortal);

        lQuery.append(" ORDER BY PERSON_ACTIVITY.actv_stat_dt ");
        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        List<MemberActivity> lMemberActivities = namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters, new activityMapper());

        // Get Disease Management Activities.
        ArrayList<MemberActivity> lMemberDMActivities = (ArrayList<MemberActivity>) getMemberDMActivities(
                personId, programID, true);

        lMemberActivities.addAll(lMemberDMActivities);

        // Get Activity History.
        getMemberActivityHistory(lMemberActivities, personId, programID);

        return lMemberActivities;
    }


    /**
     * For each activity, lookup the activity history from the activity
     * event log table.
     */
    @Transactional(timeout = 60, rollbackFor = {BPMException.class})
    public void getMemberActivityHistory(List<MemberActivity> lMemberActivities,
                                         Integer personId, Integer programID) {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectMemberActivityHistory);
        lQuery.append(" ORDER BY log.stat_eff_dt, actv_evnt_log_id ");
        for (int i = 0; i < lMemberActivities.size(); i++) {
            MemberActivity lMemberActivity = (MemberActivity) lMemberActivities.get(i);
            Object params2[] = new Object[]{personId,
                    lMemberActivity.getActivity().getActivityID(), programID};
            NamedParameter namedParameter = new NamedParameter();
            namedParameter.setPersonId(personId);
            namedParameter.setActvId(lMemberActivity.getActivity().getActivityID());
            namedParameter.setBizPgmId(programID);

            final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);


            List<GenericStatusType> lActivityStatusTypes = namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters,
                    new activityStatusTypeMapper());

            List<GenericStatusType> lActivityStatusTypesOutsideEnrollment = getMemberActivityHistoryOutsideEnrollment(lMemberActivity,
                    personId, programID);

            if (lActivityStatusTypesOutsideEnrollment.size() > 0) {
                lActivityStatusTypes.addAll(lActivityStatusTypesOutsideEnrollment);
            }

            GenericStatusType[] lStatusTypeArray = new GenericStatusType[lActivityStatusTypes
                    .size()];

            lActivityStatusTypes.toArray(lStatusTypeArray);

            lMemberActivity.setStatusHistory(lStatusTypeArray);

            for (int j = 0; j < params2.length; j++) {
                params2[j] = null;
            }
        }
    }

    /**
     * EV58500 - For each activity, lookup the activity history from the activity
     * event log table where activity date is outside of program year.
     */
    private List<GenericStatusType> getMemberActivityHistoryOutsideEnrollment(MemberActivity lMemberActivity,
                                                                              Integer personId, Integer programID) {

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectMemberActivityHistoryOutsideEnrollment);
        lQuery.append(" ORDER BY log.stat_eff_dt, actv_evnt_log_id ");
        Object params2[] = new Object[]{personId,
                lMemberActivity.getActivity().getActivityID(), programID};

        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setBizPgmId(programID);
        namedParameter.setPersonId(personId);
        namedParameter.setActvId(lMemberActivity.getActivity().getActivityID());

        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        List<GenericStatusType> lActivityStatusTypesOutsideEnrollment = namedParameterJdbcTemplate
                .query(lQuery.toString(), namedParameters,
                        new activityStatusTypeMapper());


        return lActivityStatusTypesOutsideEnrollment;
    }

    /**
     * Determine if there is the presence of a COMPLETE for multiple activity events for the same activity.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    public boolean isPersonProgramActivityHistoryComplete(Integer activityID,
                                                          Integer personId, Integer programID, String registrationID) {
        boolean isActivityComplete = false;

        StringBuffer lQuery = new StringBuffer();

        lQuery.append(selectPersonProgramActivityHistory);

        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setPersonId(personId);
        namedParameter.setActvId(activityID);
        namedParameter.setBizPgmId(programID);
        namedParameter.setRegistrationId(registrationID);

        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        lQuery.append(" AND log.registration_id  = :registrationId ");
        lQuery.append(" ORDER BY log.stat_eff_dt, actv_evnt_log_id ");

        ArrayList<GenericStatusType> lActivityStatusTypes = (ArrayList<GenericStatusType>) namedParameterJdbcTemplate
                .query(lQuery.toString(), namedParameters,
                        new activityStatusTypeMapper());

        Iterator<GenericStatusType> iter = lActivityStatusTypes.iterator();
        while (iter.hasNext()) {
            GenericStatusType lGenericStatusType = (GenericStatusType) iter.next();
            if (BPMConstants.ACTIVITY_STATUS_COMPLETE.equals(lGenericStatusType.getStatusCodeValue())) {
                isActivityComplete = true;
                break;
            }
        }

        if (isActivityComplete) {
            return isActivityComplete;
        }

        isActivityComplete = isPersonProgramActivityHistoryCompleteOutsideEnrollment(activityID,
                personId, programID, registrationID);


        return isActivityComplete;

    }

    /**
     * EV58500 - Determine if there is the presence of a COMPLETE for multiple activity events for the same activity involving activities taken outside of the program year.
     * Exists for pre-enrollment or post enrollment handling.
     */
    private boolean isPersonProgramActivityHistoryCompleteOutsideEnrollment(Integer activityID,
                                                                            Integer personId, Integer programID, String registrationID) {
        boolean isActivityComplete = false;


        StringBuffer lQuery = new StringBuffer();

        lQuery.append(selectPersonProgramActivityHistoryOutsideEnrollment);

        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setPersonId(personId);
        namedParameter.setActvId(activityID);
        namedParameter.setBizPgmId(programID);
        namedParameter.setRegistrationId(registrationID);

        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        lQuery.append(" AND log.registration_id  = :registrationId ");
        lQuery.append(" ORDER BY log.stat_eff_dt, actv_evnt_log_id ");

        ArrayList<GenericStatusType> lActivityStatusTypes = (ArrayList<GenericStatusType>) namedParameterJdbcTemplate
                .query(lQuery.toString(), namedParameters,
                        new activityStatusTypeMapper());

        Iterator<GenericStatusType> iter = lActivityStatusTypes.iterator();
        while (iter.hasNext()) {
            GenericStatusType lGenericStatusType = (GenericStatusType) iter.next();
            if (BPMConstants.ACTIVITY_STATUS_COMPLETE.equals(lGenericStatusType.getStatusCodeValue())) {
                isActivityComplete = true;
                break;
            }
        }


        return isActivityComplete;

    }

    /*
     * Fetch Disease Management Activities
     */
    @Transactional(timeout = 60, rollbackFor = {BPMException.class})
    public Collection<MemberActivity> getMemberDMActivities(
            Integer personId, Integer programID, boolean pMemberPortal) {

        StringBuffer lDMQuery = new StringBuffer();

        lDMQuery.append(selectMemberDMActivities);

        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setPersonId(personId);
        namedParameter.setLuGrp(BPMConstants.BPM_TYPE_ACTIVITY_STATUS);
        namedParameter.setLuVal(BPMConstants.ACTIVITY_STATUS_DELETE);
        namedParameter.setLuGrpNo(BPMConstants.BPM_TYPE_ACTIVITY_TYPE);
        namedParameter.setLuValNo(BPMConstants.ACTIVITY_TYPE_DISEASE_MGMT);
        namedParameter.setBizPgmId(programID);


        if (pMemberPortal) {
            lDMQuery.append("AND (NOT PERSON_ACTIVITY.actv_stat_cd_id IN (SELECT lu_id FROM luv where lu_grp = ");
            lDMQuery.append("'" + BPMConstants.BPM_TYPE_ACTIVITY_STATUS + "'");
            lDMQuery.append("and lu_val IN ('" + BPMConstants.ACTIVITY_STATUS_INACTIVE + "'");
            lDMQuery.append(" , '" + BPMConstants.ACTIVITY_STATUS_CANCELED + "')");
            lDMQuery.append("))");
        }

        lDMQuery.append("ORDER BY PERSON_ACTIVITY.actv_stat_dt");

        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);


        // Disease Management Activities
        List<MemberActivity> lMemberDMActivities = namedParameterJdbcTemplate.query(
                lDMQuery.toString(), namedParameters, new activityMapper());

        // For each activity, lookup the activity history from the activity
        // event log table.
        for (int i = 0; i < lMemberDMActivities.size(); i++) {
            MemberActivity lMemberActivity = (MemberActivity) lMemberDMActivities
                    .get(i);

            Object params2[] = new Object[]{personId,
                    lMemberActivity.getActivity().getActivityID(), programID};
            int types2[] = new int[]{Types.INTEGER, Types.INTEGER,
                    Types.INTEGER};

            NamedParameter lmemberActivityParam = new NamedParameter();
            lmemberActivityParam.setPersonId(personId);
            lmemberActivityParam.setActvId(lMemberActivity.getActivity().getActivityID());
            lmemberActivityParam.setBizPgmId(programID);

            final SqlParameterSource lmemberActivityParams = new BeanPropertySqlParameterSource(namedParameter);

            List<GenericStatusType> lActivityStatusTypes = namedParameterJdbcTemplate
                    .query(selectMemberDMActivityHistory, lmemberActivityParams,
                            new activityStatusTypeMapper());

            // EV58500 - For each activity, lookup the activity history from the activity
            //           event log table looking for activities taken outside of the program year and flagged for pre-enrollment or post-enrollment.
            List<GenericStatusType> lActivityStatusTypesOutsideEnrollment = namedParameterJdbcTemplate
                    .query(selectMemberDMActivityHistoryOutsideEnrollment, lmemberActivityParams,
                            new activityStatusTypeMapper());

            if (lActivityStatusTypesOutsideEnrollment.size() > 0) {
                lActivityStatusTypes.addAll(lActivityStatusTypesOutsideEnrollment);
            }

            GenericStatusType[] lStatusTypeArray = new GenericStatusType[lActivityStatusTypes
                    .size()];
            lActivityStatusTypes.toArray(lStatusTypeArray);

            lMemberActivity.setStatusHistory(lStatusTypeArray);

        }



        return lMemberDMActivities;
    }


    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {BPMException.class})
    public Collection<EligibleActivity> getEligibleActivities(Integer programID) {
        final ArrayList<EligibleActivity> lEligibleActivities = new ArrayList<EligibleActivity>();

        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setBizPgmId(programID);
        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        namedParameterJdbcTemplate.query(selectEligibleActivities, namedParameters,
                new RowMapper() {
                    @Override
                    public EligibleActivity mapRow(ResultSet rs, int i) throws SQLException {
                        EligibleActivity lEligibleActivity = new EligibleActivity();
                        ActivityDefinition lActivity = new ActivityDefinition();
                        lActivity
                                .setActivityID(rs.getObject("actv_id") != null ? new Integer(
                                        rs.getInt("actv_id"))
                                        : null);
                        lActivity.setName(rs.getString("actv_nm"));
                        lActivity.setDescription(rs.getString("actv_desc"));
                        lActivity.setActivityTypeValue(rs
                                .getString("actv_tp_cd_value"));
                        lActivity.setDuration(rs.getInt("completion_duration"));
                        lActivity.setSourceActivityID(rs
                                .getString("srce_actv_id"));
                        lEligibleActivity.setActivity(lActivity);

                        lEligibleActivity.setAuthorizationCode(rs
                                .getString("auth_cd"));
                        lEligibleActivity
                                .setQualificationWindowStartDate(BPMUtils.formatDateMdyyyy(rs.getDate("qualfctn_start_dt")));
                        lEligibleActivity
                                .setQualificationWindowEndDate(BPMUtils
                                        .formatDateMdyyyy(rs
                                                .getDate("qualfctn_end_dt")));
                        lEligibleActivity
                                .setQualificationWindowEarlyStartDate(BPMUtils
                                        .formatDateMdyyyy(rs
                                                .getDate("qualfctn_early_start_dt")));
                        lEligibleActivity
                                .setQualificationWindowLateEndDate(BPMUtils
                                        .formatDateMdyyyy(rs
                                                .getDate("qualfctn_late_end_dt")));

                        lEligibleActivity.setCompletionDate(BPMUtils
                                .formatDateMdyyyy(rs.getDate("completion_dt")));
                        lEligibleActivity.setEnrollmentEndDate(BPMUtils
                                .formatDateMdyyyy(rs.getDate("enrollment_end_dt")));
                        lEligibleActivity.setEnrollmentWarningDate(BPMUtils
                                .formatDateMdyyyy(rs.getDate("enrollment_warn_dt")));

                        lEligibleActivities.add(lEligibleActivity);
                        return lEligibleActivity;
                    }
                });

        return lEligibleActivities;
    }

    /**
     * Returns a list of business program IDs the given activity is eligible
     * for, in which the member participates.
     *
     * @param pSourceActivityID
     * @param pMemberID
     * @param pAuthCode
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {BPMException.class})
    public Collection<EligibleProgramActivity> getBusinessProgramsForActivity(
            String pSourceActivityID, String pMemberID, String pAuthCode,
            Calendar pActivityDate) {
        final ArrayList<EligibleProgramActivity> lEligibleProgramActivities = new ArrayList<EligibleProgramActivity>();


        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setActivityNum(pSourceActivityID);
        namedParameter.setMemberId(pMemberID);
        namedParameter.setpActivityDate(pActivityDate.getTime());
        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);


        namedParameterJdbcTemplate.query(selectBusinessProgramForActivity, namedParameters,
                new RowMapper() {
                    @Override
                    public EligibleProgramActivity mapRow(ResultSet rs, int i) throws SQLException {
                        EligibleProgramActivity lEligibleProgramActivity = new EligibleProgramActivity();
                        lEligibleProgramActivity.setActivityID(rs
                                .getInt("actv_id"));
                        lEligibleProgramActivity.setActivityName(rs
                                .getString("actv_nm"));
                        lEligibleProgramActivity.setBusinessProgramID(rs
                                .getInt("biz_pgm_id"));
                        lEligibleProgramActivity.setAuthCode(rs
                                .getString("auth_cd"));
                        lEligibleProgramActivity.setExclusionOptionFlag(rs.getString("EXCLUSION_OPTN_FLG"));

                        lEligibleProgramActivity.setBusinessProgramEffectiveDate(BPMUtils.dateToCalendar(rs.getDate("eff_dt")));
                        lEligibleProgramActivity.setBusinessProgramEndDate(BPMUtils.dateToCalendar(rs.getDate("pgm_end_dt")));

                        lEligibleProgramActivity.setProgramActivityQualificationEffectiveDate(BPMUtils.dateToCalendar(rs.getDate("qualfctn_start_dt")));
                        lEligibleProgramActivity.setProgramActivityQualificationEndDate(BPMUtils.dateToCalendar(rs.getDate("qualfctn_end_dt")));

                        lEligibleProgramActivities
                                .add(lEligibleProgramActivity);
                        return lEligibleProgramActivity;
                    }

                });

        //EV58500
        Collection<EligibleProgramActivity> lEligibleProgramActivityOutsideEnrollment = getBusinessProgramsForActivityOutsideEnrollment(
                pSourceActivityID, pMemberID, pAuthCode, pActivityDate);

        if (lEligibleProgramActivityOutsideEnrollment != null && lEligibleProgramActivityOutsideEnrollment.size() > 0) {
            lEligibleProgramActivities.addAll(lEligibleProgramActivityOutsideEnrollment);
        }

        return lEligibleProgramActivities;
    }

    /**
     * Returns a list of business program IDs the given activity is eligible
     * for, in which the member participates.  EV58500 - now must consider
     * incentive overrides.
     *
     * @param pSourceActivityID
     * @param pMemberID
     * @param pAuthCode
     * @return
     */
    @Transactional(timeout = 60, rollbackFor = {BPMException.class})
    public Collection<EligibleProgramActivity> getBusinessProgramsForActivityOutsideEnrollment(
            String pSourceActivityID, String pMemberID, String pAuthCode,
            Calendar pActivityDate) {
        final ArrayList<EligibleProgramActivity> lEligibleProgramActivitiesOutsideEnrollment = new ArrayList<EligibleProgramActivity>();

        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setActivityNum(pSourceActivityID);
        namedParameter.setMemberId(pMemberID);
        namedParameter.setpActivityDate(pActivityDate.getTime());

        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        namedParameterJdbcTemplate.query(selectBusinessProgramForActivityOutsideEnrollment, namedParameters,
                new RowMapper() {

                    @Override
                    public EligibleProgramActivity mapRow(ResultSet rs, int i) throws SQLException {

                        EligibleProgramActivity lEligibleProgramActivity = new EligibleProgramActivity();
                        lEligibleProgramActivity.setActivityID(rs
                                .getInt("actv_id"));
                        lEligibleProgramActivity.setActivityName(rs
                                .getString("actv_nm"));
                        lEligibleProgramActivity.setBusinessProgramID(rs
                                .getInt("biz_pgm_id"));
                        lEligibleProgramActivity.setAuthCode(rs
                                .getString("auth_cd"));
                        lEligibleProgramActivity.setExclusionOptionFlag(rs.getString("EXCLUSION_OPTN_FLG"));

                        lEligibleProgramActivity.setBusinessProgramEffectiveDate(BPMUtils.dateToCalendar(rs.getDate("eff_dt")));
                        lEligibleProgramActivity.setBusinessProgramEndDate(BPMUtils.dateToCalendar(rs.getDate("pgm_end_dt")));

                        lEligibleProgramActivitiesOutsideEnrollment
                                .add(lEligibleProgramActivity);
                        return lEligibleProgramActivity;
                    }


                });


        return lEligibleProgramActivitiesOutsideEnrollment;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {BPMException.class})
    public EligibleProgramActivity getEligibleProgramActivity(
            String pSourceActivityID, String pMemberID, String pAuthCode,
            Calendar pActivityDate, Integer pProgramID)
            throws DataAccessException {
        final ArrayList<EligibleProgramActivity> lEligibleProgramActivities = new ArrayList<EligibleProgramActivity>();
        StringBuffer query = new StringBuffer();
        query.append(selectEligibleProgramActivity);


        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setActivityNum(pSourceActivityID);
        namedParameter.setMemberId(pMemberID);
        namedParameter.setBizPgmId(pProgramID);
        namedParameter.setAuthCode(pAuthCode);
        namedParameter.setpActivityDate(pActivityDate.getTime());
        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        namedParameterJdbcTemplate.query(query.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public EligibleProgramActivity mapRow(ResultSet rs, int i) throws SQLException {
                        EligibleProgramActivity lEligibleProgramActivity = new EligibleProgramActivity();
                        lEligibleProgramActivity.setActivityID(rs
                                .getInt("actv_id"));
                        lEligibleProgramActivity.setActivityName(rs
                                .getString("actv_nm"));
                        lEligibleProgramActivity.setBusinessProgramID(rs
                                .getInt("biz_pgm_id"));
                        lEligibleProgramActivity.setAuthCode(rs
                                .getString("auth_cd"));

                        lEligibleProgramActivities
                                .add(lEligibleProgramActivity);
                        return lEligibleProgramActivity;
                    }

                });

        //EV58500
        EligibleProgramActivity eligibleProgramActivity = null;
        if (lEligibleProgramActivities.size() > 0) {
            eligibleProgramActivity = lEligibleProgramActivities.get(0);
        } else {
            eligibleProgramActivity = getEligibleProgramActivityOutsideEnrollment(pSourceActivityID, pMemberID, pAuthCode, pActivityDate, pProgramID);
        }


        return eligibleProgramActivity;
    }

    @Transactional(timeout = 60, rollbackFor = {BPMException.class})
    public EligibleProgramActivity getEligibleProgramActivityOutsideEnrollment(
            String pSourceActivityID, String pMemberID, String pAuthCode,
            Calendar pActivityDate, Integer pProgramID)
            throws DataAccessException {
        final ArrayList<EligibleProgramActivity> lEligibleProgramActivitiesOutsideEnrollment = new ArrayList<EligibleProgramActivity>();
        StringBuffer query = new StringBuffer();
        query.append(selectEligibleProgramActivityOutsideEnrollment);


        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setActivityNum(pSourceActivityID);
        namedParameter.setMemberId(pMemberID);
        namedParameter.setBizPgmId(pProgramID);
        namedParameter.setAuthCode(pAuthCode);
        namedParameter.setpActivityDate(pActivityDate.getTime());

        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        namedParameterJdbcTemplate.query(query.toString(), namedParameters,
                new RowMapper() {
                    @Override
                    public EligibleProgramActivity mapRow(ResultSet rs, int i) throws SQLException {
                        EligibleProgramActivity lEligibleProgramActivity = new EligibleProgramActivity();
                        lEligibleProgramActivity.setActivityID(rs
                                .getInt("actv_id"));
                        lEligibleProgramActivity.setActivityName(rs
                                .getString("actv_nm"));
                        lEligibleProgramActivity.setBusinessProgramID(rs
                                .getInt("biz_pgm_id"));
                        lEligibleProgramActivity.setAuthCode(rs
                                .getString("auth_cd"));

                        lEligibleProgramActivitiesOutsideEnrollment
                                .add(lEligibleProgramActivity);
                        return lEligibleProgramActivity;
                    }

                });

        EligibleProgramActivity eligibleProgramActivityOutsideEnrollment = null;
        if (lEligibleProgramActivitiesOutsideEnrollment.size() > 0) {
            eligibleProgramActivityOutsideEnrollment = lEligibleProgramActivitiesOutsideEnrollment.get(0);
        }


        return eligibleProgramActivityOutsideEnrollment;
    }

    /**
     * Return an ArrayList of Recommended Activities for the given person.
     *
     * @param pPersonID
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {BPMException.class})
    public Collection<MemberActivity> getRecommendedActivities(Integer pPersonID, Integer pProgramID) {
        // Business Rule: if the member status is HA Completed, and no other
        // activities are
        // Active, show the online courses as recommended.

        final ArrayList<MemberActivity> lRecommendedActivities = new ArrayList<MemberActivity>();


        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setLuGrp(BPMConstants.BPM_TYPE_ACTIVITY_TYPE);
        namedParameter.setLuVal(BPMConstants.ACTIVITY_TYPE_ONLINE_COURSE);
        namedParameter.setLuVal2(BPMConstants.ACTIVITY_TYPE_EMPLOYER_PGM);
        namedParameter.setLuGrp2(BPMConstants.BPM_TYPE_ACTIVITY_STATUS);
        namedParameter.setVal1(BPMConstants.ACTIVITY_STATUS_RECOMMENDED);
        namedParameter.setVal2(BPMConstants.ACTIVITY_STATUS_RECOMMENDED_CAN_NOT_COMPLETE);
        namedParameter.setBizPgmId(pProgramID);
        namedParameter.setPersonId(pPersonID);

        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);


        namedParameterJdbcTemplate.query(selectRecommendedActivities, namedParameters,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        MemberActivity lMemberActivity = new MemberActivity();
                        ActivityDefinition lActivity = new ActivityDefinition();
                        lActivity
                                .setActivityID(rs.getObject("actv_id") != null ? new Integer(
                                        rs.getInt("actv_id"))
                                        : null);
                        lActivity.setActivityTypeDesc(rs
                                .getString("actv_type_desc"));
                        lActivity.setName(rs.getString("actv_nm"));
                        lActivity.setDescription(rs.getString("actv_desc"));
                        lActivity.setCost(rs.getDouble("actv_cost"));
                        lActivity.setDuration(rs.getInt("completion_duration"));
                        lActivity.setSource(rs.getString("host_srce"));
                        lActivity.setWebLink(rs.getString("actv_link"));
                        lActivity.setSourceActivityID(rs
                                .getString("srce_actv_id"));
                        lMemberActivity.setAuthPromoCode(rs.getString("auth_cd"));

                        lMemberActivity.setActivity(lActivity);

                        GenericStatusType lStatusType = new GenericStatusType();

                        lStatusType.setStatusCodeDesc(rs
                                .getString("actv_stat_desc"));
                        lStatusType
                                .setStatusCodeValue(rs.getString("actv_stat_val"));
                        lStatusType.setStatusEffectiveDate((BPMUtils
                                .dateToCalendar(rs.getDate("actv_stat_dt"))));
                        lMemberActivity.setActivityStatus(lStatusType);

                        lRecommendedActivities.add(lMemberActivity);
                    }
                });

        Collection<MemberActivity> lRecommendedActivitiesOutsideEnrollment = getRecommendedActivitiesOutsideEnrollment(pPersonID, pProgramID);

        if (lRecommendedActivitiesOutsideEnrollment != null && lRecommendedActivitiesOutsideEnrollment.size() > 0) {
            lRecommendedActivities.addAll(lRecommendedActivitiesOutsideEnrollment);
        }


        return lRecommendedActivities;
    }

    /**
     * Return an ArrayList of Recommended Activities for the given person.  This method zeros in on pre or post enrollment activities.
     *
     * @param pPersonID
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {BPMException.class})
    public Collection<MemberActivity> getRecommendedActivitiesOutsideEnrollment(Integer pPersonID, Integer pProgramID) {
        // Business Rule: if the member status is HA Completed, and no other
        // activities are
        // Active, show the online courses as recommended.

        final ArrayList<MemberActivity> lRecommendedActivitiesOutsideEnrollment = new ArrayList<MemberActivity>();


        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setLuGrp(BPMConstants.BPM_TYPE_ACTIVITY_TYPE);
        namedParameter.setLuVal(BPMConstants.ACTIVITY_TYPE_ONLINE_COURSE);
        namedParameter.setLuVal2(BPMConstants.ACTIVITY_TYPE_EMPLOYER_PGM);
        namedParameter.setLuGrp2(BPMConstants.BPM_TYPE_ACTIVITY_STATUS);
        namedParameter.setVal1(BPMConstants.ACTIVITY_STATUS_RECOMMENDED);
        namedParameter.setVal2(BPMConstants.ACTIVITY_STATUS_RECOMMENDED_CAN_NOT_COMPLETE);
        namedParameter.setBizPgmId(pProgramID);
        namedParameter.setPersonId(pPersonID);

        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        namedParameterJdbcTemplate.query(selectRecommendedActivitiesOutsideEnrollment, namedParameters,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        MemberActivity lMemberActivity = new MemberActivity();
                        ActivityDefinition lActivity = new ActivityDefinition();
                        lActivity
                                .setActivityID(rs.getObject("actv_id") != null ? new Integer(
                                        rs.getInt("actv_id"))
                                        : null);
                        lActivity.setActivityTypeDesc(rs
                                .getString("actv_type_desc"));
                        lActivity.setName(rs.getString("actv_nm"));
                        lActivity.setDescription(rs.getString("actv_desc"));
                        lActivity.setCost(rs.getDouble("actv_cost"));
                        lActivity.setDuration(rs.getInt("completion_duration"));
                        lActivity.setSource(rs.getString("host_srce"));
                        lActivity.setWebLink(rs.getString("actv_link"));
                        lActivity.setSourceActivityID(rs
                                .getString("srce_actv_id"));
                        lMemberActivity.setAuthPromoCode(rs.getString("auth_cd"));

                        lMemberActivity.setActivity(lActivity);

                        GenericStatusType lStatusType = new GenericStatusType();

                        lStatusType.setStatusCodeDesc(rs
                                .getString("actv_stat_desc"));
                        lStatusType
                                .setStatusCodeValue(rs.getString("actv_stat_val"));
                        lStatusType.setStatusEffectiveDate((BPMUtils
                                .dateToCalendar(rs.getDate("actv_stat_dt"))));
                        lMemberActivity.setActivityStatus(lStatusType);

                        lRecommendedActivitiesOutsideEnrollment.add(lMemberActivity);
                    }
                });


        return lRecommendedActivitiesOutsideEnrollment;
    }

    /**
     * This method fetches and returns activities that were Filtered-Out, meaning they did not
     * count towards qualification.
     * The reason could be mismatching auth-codes, activity-date past the qualification window, etc..
     * Customer Service would like to see these in order to inform the member why a particular activity
     * did not count.
     * <p>
     * EV58500 - Added lookup for pre-enrollment activities filtered out.
     *
     * @param personId
     * @param programID
     * @param pMemberPortal
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {BPMException.class})
    public Collection<MemberActivity>
    getFilteredOutActivities(Integer personId, Integer programID, boolean pCalledFromWebPortal) {
        List<MemberActivity> lFilteredOutActivities = new ArrayList<MemberActivity>();
        StringBuffer lQuery = new StringBuffer();


        // Called from Customer Service
        if (pCalledFromWebPortal == false) {
            lQuery.append(selectFilteredOutActivities);

            NamedParameter namedParameter = new NamedParameter();
            namedParameter.setPersonId(personId);
            namedParameter.setBizPgmId(programID);

            final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

            lFilteredOutActivities = namedParameterJdbcTemplate.query(
                    lQuery.toString(), namedParameters, new activityMapper());


            Collection<MemberActivity> lFilteredOutActivitiesOutsideEnrollment = getFilteredOutActivitiesOutsideEnrollment(personId, programID, pCalledFromWebPortal);

            if (lFilteredOutActivitiesOutsideEnrollment.size() > 0) {
                lFilteredOutActivities.addAll(lFilteredOutActivitiesOutsideEnrollment);
            }

        }

        return lFilteredOutActivities;
    }

    /* EV58500
     * Search for and return filtered activities taken outside of the qualification period.  Majority will be activities taken before qualification
     * period begins otherwise known as pre-enrollment.
     */
    //Produces warnings during compile time to quickly identify typos or API changes

    public Collection<MemberActivity>
    getFilteredOutActivitiesOutsideEnrollment(Integer personId, Integer programID, boolean pCalledFromWebPortal) {
        List<MemberActivity> lFilteredOutActivities = new ArrayList<MemberActivity>();

        StringBuffer lQuery = new StringBuffer();


        // Called from Customer Service
        if (pCalledFromWebPortal == false) {
            lQuery.append(selectFilteredOutActivitiesOutsideEnrollment);

            NamedParameter namedParameter = new NamedParameter();
            namedParameter.setPersonId(personId);
            namedParameter.setBizPgmId(programID);

            final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

            lFilteredOutActivities = namedParameterJdbcTemplate.query(
                    lQuery.toString(), namedParameters, new activityMapper());
        }


        return lFilteredOutActivities;
    }


    /**
     * @see com.healthpartners.service.bpm.dao.ActivityDAO#insertMemberActivity(com.healthpartners.service.bpm.dto.ActivityEvent)
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public int insertMemberActivity(ActivityEvent activityEvent)
            throws DataAccessException {

        Integer businessProgramId = (activityEvent.getMemberActivity() != null) ? activityEvent
                .getMemberActivity().getBusinessProgramID()
                : null;
        String registrationID = (activityEvent.getMemberActivity() != null && activityEvent
                .getMemberActivity().getRegistrationID() != null) ? activityEvent
                .getMemberActivity().getRegistrationID()
                : null;
        String activityStatusCodeValue = (activityEvent.getMemberActivity() != null && activityEvent
                .getMemberActivity().getActivityStatus() != null) ? activityEvent
                .getMemberActivity().getActivityStatus().getStatusCodeValue()
                : null;
        Calendar statusEffectiveDate = (activityEvent.getMemberActivity() != null && activityEvent
                .getMemberActivity().getActivityStatus() != null) ? activityEvent
                .getMemberActivity().getActivityStatus()
                .getStatusEffectiveDate()
                : null;

        String activityOutCome = (activityEvent.getMemberActivity() != null && activityEvent
                .getMemberActivity().getActivityStatus() != null) ? activityEvent
                .getMemberActivity().getActivityStatus().getOutCome()
                : null;
        String authPromoCode = activityEvent.getMemberActivity() != null ? activityEvent
                .getMemberActivity().getAuthPromoCode()
                : null;

        String sourceActivityID = (activityEvent.getMemberActivity() != null && activityEvent
                .getMemberActivity().getActivity() != null) ? activityEvent
                .getMemberActivity().getActivity().getSourceActivityID() : null;

        if (BPMConstants.ACTIVITY_HEALTHY_BENEFITS_HA_ID.equals(sourceActivityID) &&
                (registrationID == null || registrationID.trim().length() < 1)) {
            registrationID = authPromoCode;
        }


        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setMemberId(activityEvent.getMemberID());
        namedParameter.setRegistrationId(registrationID);
        namedParameter.setLuGrp(BPMConstants.BPM_TYPE_ACTIVITY_STATUS);
        namedParameter.setLuVal(activityStatusCodeValue);
        namedParameter.setStatusEffectiveDate(statusEffectiveDate);
        namedParameter.setSourceActivityID(sourceActivityID);
        namedParameter.setInsertUserId(activityEvent.getInsertUserId());
        namedParameter.setAuthPromoCode(authPromoCode);
        namedParameter.setActivityOutCome(activityOutCome);
        namedParameter.setBizPgmId(businessProgramId);

        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        int rowsInserted = namedParameterJdbcTemplate.update(insertMemberActivity, namedParameters);


        return rowsInserted;
    }

    /**
     *
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public int insertMemberActivity(Integer pProgramID, String pMemberID,
                                    MemberActivity pMemberActivity) throws DataAccessException {

        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setMemberId(pMemberID);
        namedParameter.setRegistrationId(pMemberActivity.getRegistrationID());
        namedParameter.setLuGrp(BPMConstants.BPM_TYPE_ACTIVITY_STATUS);
        namedParameter.setLuVal(pMemberActivity.getActivityStatus().getStatusCodeValue());
        namedParameter.setStatusEffectiveDate(pMemberActivity.getActivityStatus().getStatusEffectiveDate());
        namedParameter.setSourceActivityID(pMemberActivity.getActivity().getSourceActivityID());
        namedParameter.setInsertUserId("BPM");
        namedParameter.setAuthPromoCode(pMemberActivity.getAuthPromoCode());
        namedParameter.setActivityOutCome(pMemberActivity.getActivityStatus().getOutCome());
        namedParameter.setBizPgmId(pProgramID);

        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        int rowsInserted = namedParameterJdbcTemplate.update(insertMemberActivity, namedParameters);

        return rowsInserted;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public int updateMemberActivity(ActivityEvent activityEvent)
            throws DataAccessException {
        if (!hasMemberActivityRow(activityEvent)) {
            insertMemberActivity(activityEvent);
            return 1;
        } else {

            Integer businessProgramId = (activityEvent.getMemberActivity() != null) ? activityEvent
                    .getMemberActivity().getBusinessProgramID()
                    : null;
            String registrationID = (activityEvent.getMemberActivity() != null && activityEvent
                    .getMemberActivity().getRegistrationID() != null) ? activityEvent
                    .getMemberActivity().getRegistrationID()
                    : null;
            String activityStatusCodeValue = (activityEvent.getMemberActivity() != null && activityEvent
                    .getMemberActivity().getActivityStatus() != null) ? activityEvent
                    .getMemberActivity().getActivityStatus()
                    .getStatusCodeValue()
                    : null;
            Calendar statusEffectiveDate = (activityEvent.getMemberActivity() != null && activityEvent
                    .getMemberActivity().getActivityStatus() != null) ? activityEvent
                    .getMemberActivity().getActivityStatus()
                    .getStatusEffectiveDate()
                    : null;

            String activityOutCome = (activityEvent.getMemberActivity() != null && activityEvent
                    .getMemberActivity().getActivityStatus() != null) ? activityEvent
                    .getMemberActivity().getActivityStatus().getOutCome()
                    : null;
            String authPromoCode = activityEvent.getMemberActivity() != null ? activityEvent
                    .getMemberActivity().getAuthPromoCode()
                    : null;
            String sourceActivityID = (activityEvent.getMemberActivity() != null && activityEvent
                    .getMemberActivity().getActivity() != null) ? activityEvent
                    .getMemberActivity().getActivity().getSourceActivityID()
                    : null;


            NamedParameter namedParameter = new NamedParameter();
            namedParameter.setMemberId(activityEvent.getMemberID());
            namedParameter.setRegistrationId(registrationID);
            namedParameter.setLuGrp(BPMConstants.BPM_TYPE_ACTIVITY_STATUS);
            namedParameter.setLuVal(activityStatusCodeValue);
            namedParameter.setStatusEffectiveDate(statusEffectiveDate);
            namedParameter.setSourceActivityID(sourceActivityID);
            namedParameter.setModifyUserId("BPM");
            namedParameter.setAuthPromoCode(authPromoCode);
            namedParameter.setActivityOutCome(activityOutCome);
            namedParameter.setBizPgmId(businessProgramId);

            final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);
            return namedParameterJdbcTemplate.update(updateMemberActivity, namedParameters);
        }
    }

    /**
     * @param activityEvent
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public int deleteMemberActivity(ActivityEvent activityEvent)
            throws DataAccessException {

        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setMemberId(activityEvent.getMemberID());
        namedParameter.setSourceActivityID(activityEvent
                .getMemberActivity().getActivity().getSourceActivityID());
        namedParameter.setRegistrationId(activityEvent.getMemberActivity().getRegistrationID());
        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        return namedParameterJdbcTemplate.update(deleteMemberActivity, namedParameters);
    }

    /**
     * private method - internal use
     *
     * @param activityEvent
     * @return boolean
     * @throws DataAccessException
     */
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public boolean hasMemberActivityRow(ActivityEvent activityEvent)
            throws DataAccessException {
        final ArrayList<Boolean> results = new ArrayList<Boolean>();

        String sourceActivityID = (activityEvent.getMemberActivity() != null && activityEvent
                .getMemberActivity().getActivity() != null) ? activityEvent
                .getMemberActivity().getActivity().getSourceActivityID() : null;
        Integer businessProgramID = (activityEvent.getMemberActivity() != null) ? activityEvent
                .getMemberActivity().getBusinessProgramID()
                : null;

        String registrationID = (activityEvent.getMemberActivity() != null && activityEvent
                .getMemberActivity().getRegistrationID() != null) ? activityEvent
                .getMemberActivity().getRegistrationID()
                : null;

        String authPromoCode = activityEvent.getMemberActivity() != null ? activityEvent
                .getMemberActivity().getAuthPromoCode()
                : null;

        if (BPMConstants.ACTIVITY_HEALTHY_BENEFITS_HA_ID.equals(sourceActivityID) &&
                (registrationID == null || registrationID.trim().length() < 1)) {
            registrationID = authPromoCode;
        }

        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setMemberId(activityEvent.getMemberID());
        namedParameter.setSourceActivityID(activityEvent
                .getMemberActivity().getActivity().getSourceActivityID());
        namedParameter.setRegistrationId(activityEvent.getMemberActivity().getRegistrationID());
        namedParameter.setBizPgmId(businessProgramID);
        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        namedParameterJdbcTemplate.query(countMemberActivityRows, namedParameters,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        if (rs.getInt("NUMBER_OF_ACTIVITIES") > 0) {
                            results.add(Boolean.valueOf(true));
                        }
                    }
                });


        return results.size() > 0;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public int deleteMemberActivities(Integer personID, Integer programID)
            throws DataAccessException {

        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setPersonId(personID);
        namedParameter.setBizPgmId(programID);

        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        return namedParameterJdbcTemplate.update(deleteMemberActivities, namedParameters);
    }

    /**
     * Return an ArrayList of Activities.
     *
     * @param N/A
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public Collection<ActivityDefinition> selectActivities() {

        final ArrayList<ActivityDefinition> lActivities = new ArrayList<ActivityDefinition>();

        NamedParameter namedParameter = new NamedParameter();

        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        namedParameterJdbcTemplate.query(selectActivities, namedParameters, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                ActivityDefinition lActivity = new ActivityDefinition();
                lActivity
                        .setActivityID(rs.getObject("actv_id") != null ? new Integer(
                                rs.getInt("actv_id"))
                                : null);
                lActivity.setActivityTypeDesc(rs.getString("lu_desc"));
                lActivity.setActivityTypeValue(rs.getString("lu_val"));
                lActivity.setName(rs.getString("actv_nm"));
                lActivity.setDescription(rs.getString("actv_desc"));
                lActivity.setCost(rs.getDouble("actv_cost"));
                lActivity.setDuration(rs.getInt("completion_duration"));
                lActivity.setSource(rs.getString("host_srce"));
                lActivity.setWebLink(rs.getString("actv_link"));
                lActivity.setSourceActivityID(rs.getString("srce_actv_id"));
                lActivities.add(lActivity);

            }
        });

        return lActivities;
    }

    /**
     * @param pProgramCode
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public Collection<Integer> getNewBusinessPrograms(Integer personID)
            throws DataAccessException {
        final ArrayList<Integer> lProgramIDs = new ArrayList<Integer>();

        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setPersonId(personID);
        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        namedParameterJdbcTemplate.query(selectNewBusinessPrograms, namedParameters,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        Integer lBusinessProgramID = rs.getInt("biz_pgm_id");
                        lProgramIDs.add(lBusinessProgramID);
                    }
                });

        return lProgramIDs;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public Collection<ActivityEvent> getCurrentYearActivitiesForTransfer(
            Integer personID) throws DataAccessException {
        final ArrayList<ActivityEvent> results = new ArrayList<ActivityEvent>();

        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setPersonId(personID);
        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        namedParameterJdbcTemplate.query(selectCurrentYearActivitiesForTransfer, namedParameters,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        ActivityEvent activityEvent = new ActivityEvent();
                        activityEvent.setActivityEventLogID(Long.valueOf(rs
                                .getLong(1)));
                        activityEvent.setProcessingStatusValue(rs.getString(2));

                        activityEvent.setMemberID(rs.getString(3));

                        ActivityDefinition activityDefinition = new ActivityDefinition();
                        MemberActivity memberActivity = new MemberActivity();
                        memberActivity.setActivity(activityDefinition);
                        activityDefinition.setSourceActivityID(rs.getString(4));

                        memberActivity.setRegistrationID(rs.getString(5));
                        activityEvent.setSourceSystemID(rs.getString(6));
                        memberActivity.setAuthPromoCode(rs.getString(7));

                        GenericStatusType personActivityStatus = new GenericStatusType();
                        personActivityStatus
                                .setStatusCodeValue(rs.getString(8));
                        personActivityStatus.setStatusEffectiveDate(rs
                                .getObject(9) != null ? BPMUtils
                                .dateToCalendar(rs.getDate(9)) : null);
                        personActivityStatus.setOutCome(rs.getString(10));

                        memberActivity.setActivityStatus(personActivityStatus);

                        activityEvent.setMemberActivity(memberActivity);

                        results.add(activityEvent);
                    }
                });


        return results;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public Collection<ActivityEvent> getPreviousYearDMActivitiesForTransfer(
            Integer personID) throws DataAccessException {
        final ArrayList<ActivityEvent> results = new ArrayList<ActivityEvent>();

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{personID};
        int types[] = new int[]{Types.INTEGER};

        template.query(selectPreviousYearDMActivitiesForTransfer, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        ActivityEvent activityEvent = new ActivityEvent();

                        activityEvent.setMemberID(rs.getString("hp_mem_id"));

                        ActivityDefinition activityDefinition = new ActivityDefinition();
                        MemberActivity memberActivity = new MemberActivity();
                        memberActivity.setActivity(activityDefinition);
                        activityDefinition.setSourceActivityID(rs
                                .getString("srce_actv_id"));

                        memberActivity.setRegistrationID(rs
                                .getString("registration_id"));
                        memberActivity
                                .setAuthPromoCode(rs.getString("auth_cd"));

                        GenericStatusType personActivityStatus = new GenericStatusType();
                        personActivityStatus
                                .setStatusCodeValue(BPMConstants.ACTIVITY_STATUS_ACTIVE);
                        personActivityStatus.setStatusEffectiveDate(rs
                                .getObject("actv_stat_dt") != null ? BPMUtils
                                .dateToCalendar(rs.getDate("actv_stat_dt"))
                                : null);
                        personActivityStatus.setOutCome(rs
                                .getString("stat_outcm"));

                        memberActivity.setActivityStatus(personActivityStatus);

                        activityEvent.setMemberActivity(memberActivity);

                        results.add(activityEvent);
                    }
                });

        for (int i = 0; i < params.length; i++) {
            params[i] = null;
        }
        types = null;

        return results;
    }

    /**
     * Retrieves the minimum Completion Duration for Online Activities.
     *
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public Integer getMinimumOnlineDuration()
            throws DataAccessException {
        final ArrayList<Integer> results = new ArrayList<Integer>();
        NamedParameter namedParameter = new NamedParameter();
        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        namedParameterJdbcTemplate.query(selectMinimumOnlineDuration, namedParameters,
                        new RowMapper() {
                            @Override
                            public List<Integer> mapRow(ResultSet rs, int i) throws SQLException {
                                Integer lResult = rs.getInt("COMPLETION_DURATION");
                                results.add(lResult);
                                return results;
                            }
                        });


        return results.get(0);
    }


    /**
     * Retrieves the minimum Completion Duration for Disease Management Activities.
     *
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public Integer getMinimumDMDuration()
            throws DataAccessException {
        final ArrayList<Integer> results = new ArrayList<Integer>();

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{};
        int types[] = new int[]{};

        template.query(selectMinimumDMDuration, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        Integer lResult = rs.getInt("COMPLETION_DURATION");
                        results.add(lResult);
                    }
                });

        for (int i = 0; i < params.length; i++) {
            params[i] = null;
        }
        types = null;

        return results.get(0);
    }

    /**
     * Retrieves the minimum Completion Duration for Phone Activities.
     *
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public Integer getMinimumPhoneDuration()
            throws DataAccessException {
        final ArrayList<Integer> results = new ArrayList<Integer>();

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{};
        int types[] = new int[]{};

        template.query(selectMinimumPhoneDuration, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        Integer lResult = rs.getInt("COMPLETION_DURATION");
                        results.add(lResult);
                    }
                });

        for (int i = 0; i < params.length; i++) {
            params[i] = null;
        }
        types = null;

        return results.get(0);
    }


    /**
     * Retrieves if a status of Complete exists for the given activity.
     *
     * @param pMemberID
     * @param pSourceActivityID
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public Collection<MemberActivity>
    getExistingActivity(String pMemberID, String pSourceActivityID, java.sql.Date pActivityDate,
                        String pAuthCode,
                        String pRegistrationID,
                        String pActivityStatus) {
        ArrayList<MemberActivity> lExistingComplete = new ArrayList<MemberActivity>();
        ArrayList<MemberActivity> lExistingCompleteOutsideEnrollment = new ArrayList<MemberActivity>();

        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setMemberId(pMemberID);
        namedParameter.setSourceActivityID(pSourceActivityID);
        namedParameter.setpActivityDate(pActivityDate);
        namedParameter.setAuthCode(pAuthCode);
        namedParameter.setRegistrationId(pRegistrationID);
        namedParameter.setActivityStatus(pActivityStatus);
        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        lExistingComplete = (ArrayList<MemberActivity>)  namedParameterJdbcTemplate.query(selectExistingActivity, namedParameters, new existingActivityMapper());


        lExistingCompleteOutsideEnrollment = (ArrayList<MemberActivity>) getExistingActivityOutsideEnrollment(pMemberID, pSourceActivityID, pActivityDate, pAuthCode, pRegistrationID, pActivityStatus);

        if (lExistingCompleteOutsideEnrollment.size() > 0) {
            lExistingComplete.addAll(lExistingCompleteOutsideEnrollment);
        }


        return lExistingComplete;
    }

    /**
     * EV58500 - Retrieves if a status of Complete exists for the given activity outside of enrollment period (program dates).
     *
     * @param pMemberID
     * @param pSourceActivityID
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public Collection<MemberActivity>
    getExistingActivityOutsideEnrollment(String pMemberID, String pSourceActivityID, java.sql.Date pActivityDate,
                                         String pAuthCode,
                                         String pRegistrationID,
                                         String pActivityStatus) {
        ArrayList<MemberActivity> lExistingCompleteOutsideEnrollment = new ArrayList<MemberActivity>();

        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setMemberId(pMemberID);
        namedParameter.setSourceActivityID(pSourceActivityID);
        namedParameter.setpActivityDate(pActivityDate);
        namedParameter.setAuthCode(pAuthCode);
        namedParameter.setRegistrationId(pRegistrationID);
        namedParameter.setActivityStatus(pActivityStatus);
        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        lExistingCompleteOutsideEnrollment = (ArrayList<MemberActivity>)  namedParameterJdbcTemplate.query(selectExistingActivityOutsideEnrollment
                , namedParameters, new existingActivityMapper());


        return lExistingCompleteOutsideEnrollment;
    }

    /**
     * Is there an existing WAIVE for this activity, and this program-year ?
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public Collection<MemberActivity>
    getExistingWaive(String pMemberID, String pSourceActivityID, java.sql.Date pActivityDate) {
        ArrayList<MemberActivity> lExistingWaive = new ArrayList<MemberActivity>();
        ArrayList<MemberActivity> lExistingWaiveOutsideEnrollment = new ArrayList<MemberActivity>();

        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setMemberId(pMemberID);
        namedParameter.setSourceActivityID(pSourceActivityID);
        namedParameter.setpActivityDate(pActivityDate);
        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        lExistingWaive = (ArrayList<MemberActivity>)  namedParameterJdbcTemplate.query(selectEligibleActivities, namedParameters, new existingWaiveMapper());

        lExistingWaiveOutsideEnrollment = (ArrayList<MemberActivity>) getExistingWaiveOutsideEnrollment(pMemberID, pSourceActivityID, pActivityDate);

        if (lExistingWaiveOutsideEnrollment.size() > 0) {
            lExistingWaive.addAll(lExistingWaiveOutsideEnrollment);
        }


        return lExistingWaive;
    }

    /**
     * EV58500 - Is there an existing WAIVE for this activity, and outside of program-year for handling pre and post enrollment.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public Collection<MemberActivity>
    getExistingWaiveOutsideEnrollment(String pMemberID, String pSourceActivityID, java.sql.Date pActivityDate) {
        ArrayList<MemberActivity> lExistingWaiveOutsideEnrollment = new ArrayList<MemberActivity>();

        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setMemberId(pMemberID);
        namedParameter.setSourceActivityID(pSourceActivityID);
        namedParameter.setpActivityDate(pActivityDate);
        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        lExistingWaiveOutsideEnrollment = (ArrayList<MemberActivity>) namedParameterJdbcTemplate.query(selectExistingWaiveOutsideEnrollment, namedParameters, new existingWaiveMapper());

        return lExistingWaiveOutsideEnrollment;
    }

    /**
     * Insert an eligible activity into the eligible_program_activity table.
     *
     * @param pEligibleActivity
     * @param lUserID
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public void insertEligibleActivity(EligibleProgramActivity pEligibleActivity, String lUserID) {

        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setBusinessPgmEffDate(pEligibleActivity.getBusinessProgramEffectiveDate());
        namedParameter.setBusinessPgmEndDate(pEligibleActivity.getBusinessProgramEndDate());
        namedParameter.setAuthCode(pEligibleActivity.getAuthCode());
        namedParameter.setInsertUserId(lUserID);
        namedParameter.setBizPgmId(pEligibleActivity.getBusinessProgramID());
        namedParameter.setActvId(pEligibleActivity.getActivityID());
        namedParameter.setExclusionOptionFlag(pEligibleActivity.getExclusionOptionFlag());
        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        namedParameterJdbcTemplate.update(insertEligibleActivity, namedParameters);

        return;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public Collection<EligibleProgramActivity> getEligibleProgramActivities(Integer pProgramID) {
        final ArrayList<EligibleProgramActivity> lEligibleProgramActivities = new ArrayList<EligibleProgramActivity>();
        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setBizPgmId(pProgramID);
        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        namedParameterJdbcTemplate.query(selectEligibleActivities, namedParameters,
                new RowMapper() {
                    @Override
                    public EligibleProgramActivity mapRow(ResultSet rs, int i) throws SQLException {
                        EligibleProgramActivity lEligibleProgramActivity = new EligibleProgramActivity();

                        //lEligibleProgramActivity.setActivityGroupName(rs.getString("ACTV_GRP_NM"));
                        lEligibleProgramActivity.setActivityID(rs.getInt("actv_id"));
                        lEligibleProgramActivity.setActivityTypeCodeValue(rs.getString("actv_tp_cd_value"));
                        lEligibleProgramActivity.setIncentiveOverrideCodeID(rs.getInt("incntv_ovrd_tp_cd_id"));
                        lEligibleProgramActivities.add(lEligibleProgramActivity);
                        return lEligibleProgramActivity;
                    }

                });
        return lEligibleProgramActivities;
    }

    /**
     * @param pProgramID
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public Collection<AuthCode> selectExtendedAuthCodes(final Integer pProgramID) {
        final ArrayList<AuthCode> lAuthCodes = new ArrayList<AuthCode>();
        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setBizPgmId(pProgramID);
        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        namedParameterJdbcTemplate.query(selectExtendedAuthCodes, namedParameters,
                new RowMapper() {
                    @Override
                    public AuthCode mapRow(ResultSet rs, int i) throws SQLException {
                        AuthCode lAuthCode = new AuthCode();

                        lAuthCode.setBusinessProgramID(pProgramID);
                        lAuthCode.setAuthCode(rs.getString("auth_cd"));
                        lAuthCode.setAuthCodeTypeCode(rs.getString("lu_val"));
                        lAuthCode.setEffectiveDate(rs.getDate("EFF_DT"));
                        lAuthCode.setEndDate(rs.getDate("END_DT"));

                        lAuthCodes.add(lAuthCode);
                        return lAuthCode;
                    }

                });
        return lAuthCodes;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public Collection<AuthCode> selectEligibleAuthCodes(final Integer pProgramID) {
        final ArrayList<AuthCode> lAuthCodes = new ArrayList<AuthCode>();

        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setBizPgmId(pProgramID);
        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        namedParameterJdbcTemplate.query(selectEligibleAuthCodes, namedParameters,
                new RowMapper() {
                    @Override
                    public AuthCode mapRow(ResultSet rs, int i) throws SQLException {
                        AuthCode lAuthCode = new AuthCode();
                        lAuthCode.setBusinessProgramID(pProgramID);
                        lAuthCode.setAuthCode(rs.getString("auth_cd"));
                        lAuthCode.setAuthCodeTypeCode(rs.getString("lu_val"));
                        lAuthCode.setEffectiveDate(rs.getDate("EFF_DT"));
                        lAuthCode.setEndDate(rs.getDate("END_DT"));
                        lAuthCodes.add(lAuthCode);
                        return lAuthCode;
                    }

                });
        return lAuthCodes;
    }

    /**
     * Return an activity definition record.
     *
     * @param activityId
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public ActivityDefinition getActivity(int activityId) {


        ArrayList<ActivityDefinition> lActivityDefitions = new ArrayList<ActivityDefinition>();

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectActivity);


        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setActivityID(activityId);
        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);


        lActivityDefitions = (ArrayList<ActivityDefinition>) namedParameterJdbcTemplate.query(lQuery
                .toString(), namedParameters, new ActivityDefinitionRowMapper());


        ActivityDefinition dto = null;
        if (lActivityDefitions.size() > 0) {
            dto = (ActivityDefinition) lActivityDefitions.get(0);
        }
        return dto;
    }

    /**
     * Return an person program activity status record.
     *
     * @param memberNo
     * @param sourceActivityId
     * @param effectiveStatusDate
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public PersonProgramActivityStatus getPersonProgramActivityStatus(String memberID, Integer programID, String sourceActivityId, java.sql.Date effectiveStatusDate) {


        ArrayList<PersonProgramActivityStatus> lPersonProgramActivityStatuses = new ArrayList<PersonProgramActivityStatus>();

        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setMemberId(memberID);
        namedParameter.setBizPgmId(programID);
        namedParameter.setSourceActivityID(sourceActivityId);

        Calendar pActivityDate = Calendar.getInstance();
        pActivityDate.setTime(effectiveStatusDate);
        namedParameter.setStatusEffectiveDate(pActivityDate);

        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);


        lPersonProgramActivityStatuses = (ArrayList<PersonProgramActivityStatus>) namedParameterJdbcTemplate.query(selectPersonProgramActivityStatus, namedParameters, new PersonProgramActivityStatusRowMapper());


        PersonProgramActivityStatus dto = null;
        if (lPersonProgramActivityStatuses.size() > 0) {
            dto = (PersonProgramActivityStatus) lPersonProgramActivityStatuses.get(0);
        } else {
            dto = getPersonProgramActivityStatusOutsideEnrollment(memberID, programID, sourceActivityId, effectiveStatusDate);

        }

        return dto;
    }

    /**
     * Return an person program activity status record.
     *
     * @param memberNo
     * @param sourceActivityId
     * @param effectiveStatusDate
     * @return
     */
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public PersonProgramActivityStatus getPersonProgramActivityStatusOutsideEnrollment(String memberID, Integer programID, String sourceActivityId, java.sql.Date effectiveStatusDate) {


        List<PersonProgramActivityStatus> lPersonProgramActivityStatuses = new ArrayList<PersonProgramActivityStatus>();
        Object params[] = new Object[]{memberID, programID, sourceActivityId, effectiveStatusDate};
        JdbcTemplate template = getJdbcTemplate();

        NamedParameter namedParameter = new NamedParameter();
        namedParameter.setMemberId(memberID);
        namedParameter.setBizPgmId(programID);
        namedParameter.setActivityNum(sourceActivityId);
        namedParameter.setStartDate(effectiveStatusDate);

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectPersonProgramActivityStatusOutsideEnrollment);

        int types[] = new int[]{Types.VARCHAR, Types.INTEGER, Types.VARCHAR, Types.DATE};

        final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

        lPersonProgramActivityStatuses = namedParameterJdbcTemplate.query(lQuery
                .toString(), namedParameters, new PersonProgramActivityStatusRowMapper());


        PersonProgramActivityStatus dto = null;
        if (lPersonProgramActivityStatuses.size() > 0) {
            dto = (PersonProgramActivityStatus) lPersonProgramActivityStatuses.get(0);
        }
        return dto;
    }

    /**
     * Return an activity using external activity name.
     *
     * @param N/A
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public Activity getActivityFromExternalActivity(String groupNo, String externalActivityName) throws Exception, DataAccessException {


        final ArrayList<Activity> results = new ArrayList<Activity>();
        Object params[] = new Object[]{groupNo, externalActivityName};
        JdbcTemplate template = getJdbcTemplate();
        int types[] = new int[]{Types.VARCHAR, Types.VARCHAR};
        template.query(selectActivityFromExternalActivity, params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                Activity lActivity = new Activity();
                lActivity
                        .setActivityID(rs.getObject("actv_id") != null ? new Integer(
                                rs.getInt("actv_id"))
                                : null);
                lActivity.setActivityTypeCodeID(rs.getInt("actv_tp_cd_id"));
                lActivity.setSource(rs.getString("host_srce"));
                lActivity.setDuration(rs.getInt("completion_duration"));
                lActivity.setName(rs.getString("actv_nm"));
                lActivity.setDescription(rs.getString("actv_desc"));
                lActivity.setWebLink(rs.getString("actv_link"));
                lActivity.setCost(BPMUtils
                        .convertDoubleToDecimalFormattedString(rs
                                .getDouble("actv_cost")));
                lActivity.setUserId(rs.getString("insert_usr"));
                lActivity.setSourceActivityID(rs.getString("srce_actv_id"));
                lActivity.setEffectiveDate(rs.getDate("actv_eff_dt"));
                lActivity.setEndDate(rs.getDate("actv_end_dt"));
                results.add(lActivity);

            }
        });

        Activity dto = null;
        if (results.size() > 0) {
            dto = (Activity) results.get(0);
        }

        return dto;
    }


    /**
     * @param pPersonDemographicsID
     * @param pProgramID
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    public void setActivitiesToPending(Integer pPersonDemographicsID, Integer pProgramID)
            throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();

        Object params[] = new Object[]{pPersonDemographicsID, pProgramID};

        int types[] = new int[]{Types.INTEGER, Types.INTEGER};

        template.update(setActivitiesToPending, params, types);
        return;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public Collection<Activity> getEmployerAdminsterdActivities()
            throws DataAccessException {

        final ArrayList<Activity> lActivities = new ArrayList<Activity>();
        JdbcTemplate template = getJdbcTemplate();
        template.query(selectEmployerAdminsterdActivities,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        Activity lActivity = new Activity();
                        lActivity
                                .setActivityID(rs.getObject("actv_id") != null ? new Integer(
                                        rs.getInt("actv_id"))
                                        : null);
                        lActivity.setName(rs.getString("actv_nm"));
                        lActivity.setDescription(rs.getString("actv_desc"));
                        lActivity.setDuration(rs.getInt("completion_duration"));
                        lActivity.setActivityTypeValue(rs
                                .getString("actv_tp_cd_value"));
                        lActivity.setSource(rs.getString("host_srce"));
                        lActivity.setSourceActivityID(rs
                                .getString("srce_actv_id"));
                        lActivities.add(lActivity);
                    }
                });

        return lActivities;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class})
    public Collection<ActivityExternalEmployerXref> getExternalEmployerActivityXrefAll()
            throws DataAccessException {

        final ArrayList<ActivityExternalEmployerXref> lActivitiesExternalEmployerXref = new ArrayList<ActivityExternalEmployerXref>();
        JdbcTemplate template = getJdbcTemplate();
        template.query(selectExternalEmployerActivityXref,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        ActivityExternalEmployerXref lActivityExternalEmployerXref = new ActivityExternalEmployerXref();

                        lActivityExternalEmployerXref.setGroupNo(rs.getString("empl_grp_no"));
                        lActivityExternalEmployerXref.setActivityName(rs.getString("ext_actv_nm"));
                        lActivityExternalEmployerXref.setActivityID(rs.getInt("actv_id"));
                        lActivityExternalEmployerXref.setEffectiveDate(rs.getDate("eff_dt"));
                        lActivityExternalEmployerXref.setEndDate(rs.getDate("end_dt"));

                        lActivitiesExternalEmployerXref.add(lActivityExternalEmployerXref);
                    }
                });

        return lActivitiesExternalEmployerXref;
    }


    public String getSelectMemberActivities() {
        return selectMemberActivities;
    }

    public void setSelectMemberActivities(String selectMemberActivities) {
        this.selectMemberActivities = selectMemberActivities;
    }


    public String getSelectMemberActivitiesOutsideEnrollment() {
        return selectMemberActivitiesOutsideEnrollment;
    }

    public void setSelectMemberActivitiesOutsideEnrollment(
            String selectMemberActivitiesOutsideEnrollment) {
        this.selectMemberActivitiesOutsideEnrollment = selectMemberActivitiesOutsideEnrollment;
    }

    public String getSelectEligibleActivities() {
        return selectEligibleActivities;
    }

    public void setSelectEligibleActivities(String selectEligibleActivities) {
        this.selectEligibleActivities = selectEligibleActivities;
    }

    public String getSelectMemberActivityHistory() {
        return selectMemberActivityHistory;
    }

    public void setSelectMemberActivityHistory(
            String selectMemberActivityHistory) {
        this.selectMemberActivityHistory = selectMemberActivityHistory;
    }


    public String getSelectPersonProgramActivityHistory() {
        return selectPersonProgramActivityHistory;
    }

    public void setSelectPersonProgramActivityHistory(
            String selectPersonProgramActivityHistory) {
        this.selectPersonProgramActivityHistory = selectPersonProgramActivityHistory;
    }

    /**
     * Sets the insertMemberActivity SQL statement. Should only be called by
     * Spring.
     *
     * @param String
     */
    public void setInsertMemberActivity(String sql) {
        this.insertMemberActivity = sql;
    }

    /**
     * Sets the updateMemberActivity SQL statement. Should only be called by
     * Spring.
     *
     * @param String
     */
    public void setUpdateMemberActivity(String sql) {
        this.updateMemberActivity = sql;
    }

    /**
     * Sets the countMemberActivityRows SQL statement. Should only be called by
     * Spring.
     *
     * @param String
     */
    public void setCountMemberActivityRows(String sql) {
        this.countMemberActivityRows = sql;
    }

    private static final class activityStatusTypeMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            GenericStatusType lActivityStatus = new GenericStatusType();
            lActivityStatus.setStatusCodeID(rs.getInt("stat_cd_id"));
            lActivityStatus.setStatusCodeDesc(rs.getString("stat_desc"));
            lActivityStatus.setStatusCodeValue(rs.getString("stat_val"));

            lActivityStatus.setStatusEffectiveDate(BPMUtils.dateToCalendar(rs
                    .getDate("stat_eff_dt")));
            lActivityStatus.setOutCome(rs.getString("stat_outcm"));
            return lActivityStatus;
        }
    }

    private static final class activityMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            MemberActivity lMemberActivity = new MemberActivity();
            ActivityDefinition lActivity = new ActivityDefinition();
            lActivity
                    .setActivityID(rs.getObject("actv_id") != null ? new Integer(
                            rs.getInt("actv_id"))
                            : null);
            lMemberActivity.setPersonDemographicsID(rs.getInt("prsn_dmgrphcs_id"));
            lMemberActivity.setActivityTypeCodeID(rs.getInt("actv_tp_cd_id"));
            lActivity.setActivityTypeDesc(rs.getString("actv_type_desc"));
            lActivity.setActivityTypeValue(rs.getString("actv_type_code_val"));
            lActivity.setName(rs.getString("actv_nm"));
            lActivity.setDescription(rs.getString("actv_desc"));
            lActivity.setCost(rs.getDouble("actv_cost"));
            lActivity.setDuration(rs.getInt("completion_duration"));
            lActivity.setSource(rs.getString("host_srce"));
            lActivity.setWebLink(rs.getString("actv_link"));
            lActivity.setSourceActivityID(rs.getString("srce_actv_id"));
            lMemberActivity.setBusinessProgramID(rs.getInt("biz_pgm_id"));
            lMemberActivity.setGroupID(rs.getInt("grp_id"));
            lMemberActivity.setMemberID(rs.getString("hp_mem_id"));
            lMemberActivity.setActivity(lActivity);
            lMemberActivity.setRegistrationID(rs.getString("registration_id"));
            lMemberActivity.setAuthPromoCode(rs.getString("auth_cd"));
            lMemberActivity.setPersonProgramActivityStatusID(rs.getInt("prsn_pgm_actv_sts_id"));
            if (rs.getString("able_to_complete").equalsIgnoreCase("Y")) {
                lMemberActivity.setAbleToComplete(true);
            } else {
                lMemberActivity.setAbleToComplete(false);
            }

            GenericStatusType lStatusType = new GenericStatusType();
            lStatusType.setStatusCodeID((rs.getInt("actv_stat_cd_id")));
            lStatusType.setStatusCodeDesc(rs.getString("active_stat_desc"));
            lStatusType
                    .setStatusCodeValue(rs.getString("active_stat_code_val"));
            lStatusType.setStatusEffectiveDate((BPMUtils.dateToCalendar(rs
                    .getDate("actv_stat_dt"))));
            lStatusType.setOutCome(rs.getString("active_stat_outcome_val"));
            lMemberActivity.setActivityStatus(lStatusType);
            return lMemberActivity;
        }
    }

    private static final class existingActivityMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            MemberActivity lMemberActivity = new MemberActivity();
            ActivityDefinition lActivityDefinition = new ActivityDefinition();
            lActivityDefinition.setSourceActivityID(rs.getString("actv_id"));
            lMemberActivity.setCompletionDate(BPMUtils.dateToCalendar(rs.getDate("stat_eff_dt")));

            GenericStatusType lActivityStatus = new GenericStatusType();
            lActivityStatus.setStatusCodeValue(rs.getString("stat_cd"));

            lMemberActivity.setActivityEventLogID(rs.getInt("actv_evnt_log_id"));
            lMemberActivity.setActivityStatus(lActivityStatus);

            lMemberActivity.setActivity(lActivityDefinition);
            return lMemberActivity;
        }
    }

    private static final class existingWaiveMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            MemberActivity lMemberActivity = new MemberActivity();
            ActivityDefinition lActivityDefinition = new ActivityDefinition();
            lActivityDefinition.setSourceActivityID(rs.getString("actv_id"));
            lMemberActivity.setCompletionDate(BPMUtils.dateToCalendar(rs.getDate("stat_eff_dt")));

            GenericStatusType lActivityStatus = new GenericStatusType();
            lActivityStatus.setStatusCodeValue(rs.getString("stat_cd"));
            lMemberActivity.setActivityStatus(lActivityStatus);

            lMemberActivity.setActivity(lActivityDefinition);
            return lMemberActivity;
        }
    }

    private static final class ActivityDefinitionRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            ActivityDefinition lActivity = new ActivityDefinition();
            lActivity
                    .setActivityID(rs.getObject("actv_id") != null ? new Integer(
                            rs.getInt("actv_id"))
                            : null);
            lActivity.setActivityTypeCodeID(rs.getInt("actv_tp_cd_id"));
            lActivity.setSource(rs.getString("host_srce"));
            lActivity.setDuration(rs.getInt("completion_duration"));
            lActivity.setName(rs.getString("actv_nm"));
            lActivity.setDescription(rs.getString("actv_desc"));
            lActivity.setWebLink(rs.getString("actv_link"));
            lActivity.setCost(rs
                    .getDouble("actv_cost"));
            lActivity.setUserId(rs.getString("insert_usr"));
            lActivity.setSourceActivityID(rs.getString("srce_actv_id"));
            lActivity.setEffectiveDate(rs.getDate("actv_eff_dt"));
            lActivity.setEndDate(rs.getDate("actv_end_dt"));
            return lActivity;

        }
    }

    private static final class PersonProgramActivityStatusRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            PersonProgramActivityStatus lPersonProgramActivityStatus = new PersonProgramActivityStatus();
            lPersonProgramActivityStatus.setActivityID(rs.getInt("prsn_id"));
            lPersonProgramActivityStatus.setActivityStatusCodeID(rs.getInt("actv_stat_cd_id"));
            lPersonProgramActivityStatus.setActivityStatusDate(rs.getDate("actv_stat_dt"));
            lPersonProgramActivityStatus.setActivityID(rs.getInt("actv_id"));
            lPersonProgramActivityStatus.setAuthCode(rs.getString("auth_cd"));
            lPersonProgramActivityStatus.setActivityStatusOutcomeID(rs.getInt("actv_stat_outcm_id"));
            lPersonProgramActivityStatus.setProgramID(rs.getInt("biz_pgm_id"));
            lPersonProgramActivityStatus.setStatusOutcome(rs.getString("stat_outcm"));
            lPersonProgramActivityStatus.setRegistrationID(rs.getString("registration_id"));
            lPersonProgramActivityStatus.setPersonDemographicsID(rs.getInt("prsn_dmgrphcs_id"));
            lPersonProgramActivityStatus.setCollectionID(rs.getInt("collection_id"));
            return lPersonProgramActivityStatus;

        }

    }


    public String getSelectRecommendedActivities() {
        return selectRecommendedActivities;
    }

    public void setSelectRecommendedActivities(
            String selectRecommendedActivities) {
        this.selectRecommendedActivities = selectRecommendedActivities;
    }


    public String getSelectRecommendedActivitiesOutsideEnrollment() {
        return selectRecommendedActivitiesOutsideEnrollment;
    }

    public void setSelectRecommendedActivitiesOutsideEnrollment(
            String selectRecommendedActivitiesOutsideEnrollment) {
        this.selectRecommendedActivitiesOutsideEnrollment = selectRecommendedActivitiesOutsideEnrollment;
    }

    public String getCountMemberActivityRows() {
        return countMemberActivityRows;
    }

    public String getInsertMemberActivity() {
        return insertMemberActivity;
    }

    public String getUpdateMemberActivity() {
        return updateMemberActivity;
    }


    public String getGetActivity() {
        return getActivity;
    }

    public void setGetActivity(String getActivity) {
        this.getActivity = getActivity;
    }

    public String getSelectActivities() {
        return selectActivities;
    }

    public void setSelectActivities(String selectActivities) {
        this.selectActivities = selectActivities;
    }

    public String getSelectActivitiesOrderByHost() {
        return selectActivitiesOrderByHost;
    }

    public void setSelectActivitiesOrderByHost(
            String selectActivitiesOrderByHost) {
        this.selectActivitiesOrderByHost = selectActivitiesOrderByHost;
    }

    public String getSelectBusinessProgramForActivity() {
        return selectBusinessProgramForActivity;
    }

    public void setSelectBusinessProgramForActivity(
            String selectBusinessProgramForActivity) {
        this.selectBusinessProgramForActivity = selectBusinessProgramForActivity;
    }


    public String getSelectBusinessProgramForActivityOutsideEnrollment() {
        return selectBusinessProgramForActivityOutsideEnrollment;
    }

    public void setSelectBusinessProgramForActivityOutsideEnrollment(
            String selectBusinessProgramForActivityOutsideEnrollment) {
        this.selectBusinessProgramForActivityOutsideEnrollment = selectBusinessProgramForActivityOutsideEnrollment;
    }

    public String getDeleteMemberActivities() {
        return deleteMemberActivities;
    }

    public void setDeleteMemberActivities(String deleteMemberActivities) {
        this.deleteMemberActivities = deleteMemberActivities;
    }

    public String getSelectNewBusinessPrograms() {
        return selectNewBusinessPrograms;
    }

    public void setSelectNewBusinessPrograms(String selectNewBusinessPrograms) {
        this.selectNewBusinessPrograms = selectNewBusinessPrograms;
    }

    public String getSelectMemberDMActivities() {
        return selectMemberDMActivities;
    }

    public void setSelectMemberDMActivities(String selectMemberDMActivities) {
        this.selectMemberDMActivities = selectMemberDMActivities;
    }

    public String getSelectMemberDMActivityHistory() {
        return selectMemberDMActivityHistory;
    }

    public void setSelectMemberDMActivityHistory(
            String selectMemberDMActivityHistory) {
        this.selectMemberDMActivityHistory = selectMemberDMActivityHistory;
    }


    public String getSelectMemberActivityHistoryOutsideEnrollment() {
        return selectMemberActivityHistoryOutsideEnrollment;
    }

    public void setSelectMemberActivityHistoryOutsideEnrollment(
            String selectMemberActivityHistoryOutsideEnrollment) {
        this.selectMemberActivityHistoryOutsideEnrollment = selectMemberActivityHistoryOutsideEnrollment;
    }

    public String getSelectPersonProgramActivityHistoryOutsideEnrollment() {
        return selectPersonProgramActivityHistoryOutsideEnrollment;
    }

    public void setSelectPersonProgramActivityHistoryOutsideEnrollment(
            String selectPersonProgramActivityHistoryOutsideEnrollment) {
        this.selectPersonProgramActivityHistoryOutsideEnrollment = selectPersonProgramActivityHistoryOutsideEnrollment;
    }

    public String getSelectMemberDMActivityHistoryOutsideEnrollment() {
        return selectMemberDMActivityHistoryOutsideEnrollment;
    }

    public void setSelectMemberDMActivityHistoryOutsideEnrollment(
            String selectMemberDMActivityHistoryOutsideEnrollment) {
        this.selectMemberDMActivityHistoryOutsideEnrollment = selectMemberDMActivityHistoryOutsideEnrollment;
    }

    public String getSelectExistingWaiveOutsideEnrollment() {
        return selectExistingWaiveOutsideEnrollment;
    }

    public void setSelectExistingWaiveOutsideEnrollment(
            String selectExistingWaiveOutsideEnrollment) {
        this.selectExistingWaiveOutsideEnrollment = selectExistingWaiveOutsideEnrollment;
    }

    public String getSelectCurrentYearActivitiesForTransfer() {
        return selectCurrentYearActivitiesForTransfer;
    }

    public void setSelectCurrentYearActivitiesForTransfer(
            String selectCurrentYearActivitiesForTransfer) {
        this.selectCurrentYearActivitiesForTransfer = selectCurrentYearActivitiesForTransfer;
    }

    public String getSelectPreviousYearDMActivitiesForTransfer() {
        return selectPreviousYearDMActivitiesForTransfer;
    }

    public void setSelectPreviousYearDMActivitiesForTransfer(
            String selectPreviousYearDMActivitiesForTransfer) {
        this.selectPreviousYearDMActivitiesForTransfer = selectPreviousYearDMActivitiesForTransfer;
    }

    public final String getSelectEligibleProgramActivity() {
        return selectEligibleProgramActivity;
    }

    public final void setSelectEligibleProgramActivity(
            String selectEligibleProgramActivity) {
        this.selectEligibleProgramActivity = selectEligibleProgramActivity;
    }


    public String getSelectEligibleProgramActivityOutsideEnrollment() {
        return selectEligibleProgramActivityOutsideEnrollment;
    }

    public void setSelectEligibleProgramActivityOutsideEnrollment(
            String selectEligibleProgramActivityOutsideEnrollment) {
        this.selectEligibleProgramActivityOutsideEnrollment = selectEligibleProgramActivityOutsideEnrollment;
    }

    public final String getSelectFilteredOutActivities() {
        return selectFilteredOutActivities;
    }

    public final void setSelectFilteredOutActivities(
            String selectFilteredOutActivities) {
        this.selectFilteredOutActivities = selectFilteredOutActivities;
    }


    public String getSelectFilteredOutActivitiesOutsideEnrollment() {
        return selectFilteredOutActivitiesOutsideEnrollment;
    }

    public void setSelectFilteredOutActivitiesOutsideEnrollment(
            String selectFilteredOutActivitiesOutsideEnrollment) {
        this.selectFilteredOutActivitiesOutsideEnrollment = selectFilteredOutActivitiesOutsideEnrollment;
    }

    public final String getSelectMinimumDMDuration() {
        return selectMinimumDMDuration;
    }

    public final void setSelectMinimumDMDuration(String selectMinimumDMDuration) {
        this.selectMinimumDMDuration = selectMinimumDMDuration;
    }

    public final String getSelectMinimumOnlineDuration() {
        return selectMinimumOnlineDuration;
    }

    public final void setSelectMinimumOnlineDuration(
            String selectMinimumOnlineDuration) {
        this.selectMinimumOnlineDuration = selectMinimumOnlineDuration;
    }

    public final String getSelectMinimumPhoneDuration() {
        return selectMinimumPhoneDuration;
    }

    public final void setSelectMinimumPhoneDuration(
            String selectMinimumPhoneDuration) {
        this.selectMinimumPhoneDuration = selectMinimumPhoneDuration;
    }


    public final String getSelectExistingActivity() {
        return selectExistingActivity;
    }

    public final void setSelectExistingActivity(String selectExistingActivity) {
        this.selectExistingActivity = selectExistingActivity;
    }


    public String getSelectExistingActivityOutsideEnrollment() {
        return selectExistingActivityOutsideEnrollment;
    }

    public void setSelectExistingActivityOutsideEnrollment(
            String selectExistingActivityOutsideEnrollment) {
        this.selectExistingActivityOutsideEnrollment = selectExistingActivityOutsideEnrollment;
    }

    public final String getDeleteMemberActivity() {
        return deleteMemberActivity;
    }

    public final void setDeleteMemberActivity(String deleteMemberActivity) {
        this.deleteMemberActivity = deleteMemberActivity;
    }

    public final String getSelectMemberActivitiesForPortal() {
        return selectMemberActivitiesForPortal;
    }

    public final void setSelectMemberActivitiesForPortal(
            String selectMemberActivitiesForPortal) {
        this.selectMemberActivitiesForPortal = selectMemberActivitiesForPortal;
    }

    public final String getSelectExistingWaive() {
        return selectExistingWaive;
    }

    public final void setSelectExistingWaive(String selectExistingWaive) {
        this.selectExistingWaive = selectExistingWaive;
    }

    public String getInsertEligibleActivity() {
        return insertEligibleActivity;
    }

    public void setInsertEligibleActivity(String insertEligibleActivity) {
        this.insertEligibleActivity = insertEligibleActivity;
    }

    public final String getSelectExtendedAuthCodes() {
        return selectExtendedAuthCodes;
    }

    public final void setSelectExtendedAuthCodes(String selectExtendedAuthCodes) {
        this.selectExtendedAuthCodes = selectExtendedAuthCodes;
    }

    public String getSetActivitiesToPending() {
        return setActivitiesToPending;
    }

    public void setSetActivitiesToPending(String setActivitiesToPending) {
        this.setActivitiesToPending = setActivitiesToPending;
    }

    public String getSelectEligibleAuthCodes() {
        return selectEligibleAuthCodes;
    }

    public void setSelectEligibleAuthCodes(String selectEligibleAuthCodes) {
        this.selectEligibleAuthCodes = selectEligibleAuthCodes;
    }

    public String getSelectActivity() {
        return selectActivity;
    }

    public void setSelectActivity(String selectActivity) {
        this.selectActivity = selectActivity;
    }

    public String getSelectPersonProgramActivityStatus() {
        return selectPersonProgramActivityStatus;
    }

    public void setSelectPersonProgramActivityStatus(
            String selectPersonProgramActivityStatus) {
        this.selectPersonProgramActivityStatus = selectPersonProgramActivityStatus;
    }

    public String getSelectPersonProgramActivityStatusOutsideEnrollment() {
        return selectPersonProgramActivityStatusOutsideEnrollment;
    }

    public void setSelectPersonProgramActivityStatusOutsideEnrollment(
            String selectPersonProgramActivityStatusOutsideEnrollment) {
        this.selectPersonProgramActivityStatusOutsideEnrollment = selectPersonProgramActivityStatusOutsideEnrollment;
    }

    public String getSelectActivityFromExternalActivity() {
        return selectActivityFromExternalActivity;
    }

    public void setSelectActivityFromExternalActivity(
            String selectActivityFromExternalActivity) {
        this.selectActivityFromExternalActivity = selectActivityFromExternalActivity;
    }

    public String getSelectEmployerAdminsterdActivities() {
        return selectEmployerAdminsterdActivities;
    }

    public void setSelectEmployerAdminsterdActivities(
            String selectEmployerAdminsterdActivities) {
        this.selectEmployerAdminsterdActivities = selectEmployerAdminsterdActivities;
    }

    public String getSelectExternalEmployerActivityXref() {
        return selectExternalEmployerActivityXref;
    }

    public void setSelectExternalEmployerActivityXref(
            String selectExternalEmployerActivityXref) {
        this.selectExternalEmployerActivityXref = selectExternalEmployerActivityXref;
    }

    public String getCountMemberActivityInEmployerActivityXref() {
        return countMemberActivityInEmployerActivityXref;
    }

    public void setCountMemberActivityInEmployerActivityXref(
            String countMemberActivityInEmployerActivityXref) {
        this.countMemberActivityInEmployerActivityXref = countMemberActivityInEmployerActivityXref;
    }


}
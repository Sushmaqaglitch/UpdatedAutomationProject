package com.healthpartners.service.imfs.dao;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * Calls the Stored Procedure createSmallGroupBizPgm.
 * 
 * @author jxbourbour
 *
 */
@Configuration
public class CallCreateSmallGroupBizPgm extends StoredProcedure 
{

    protected final Log logger = LogFactory.getLog(getClass());

    @Autowired
    DataSource bpmDataSource;


    @PostConstruct
    private void initialize() {

        setDataSource(bpmDataSource);
    }

    private static final String STORED_PROC_NAME = "pkg_bpm_smarts.createSmallGroupBizPgm";

    public CallCreateSmallGroupBizPgm(DataSource bpmDataSource)
    {
        super(bpmDataSource, STORED_PROC_NAME);

        /*
          procedure createSmallGroupBizPgm (  inBusinessProgramType IN VARCHAR2
                                                    , inRenewalDate IN DATE
                                                    , inGroupID IN NUMBER
                                                    , inSubgroupID IN NUMBER
                                                    , inAuthCode IN VARCHAR2
                                                    , inPromoCode IN VARCHAR2
                                                    , inTemplateAuthPromoType IN VARCHAR2
                                                    );
                                                    
-------------------------------------------------------------------
-- This procedure creates records for Small Groups in
-- the business_program, eligible_program_activity
-- biz_pgm_incntv_option, biz_pgm_auth_code_extended,
-- and biz_pgm_addtl_info
-- for the given group, site, and renewal date
-- using the data in the tmpl (template) tables.
-------------------------------------------------------------------

         */
        
        // Input Parameter
        
        declareParameter(new SqlParameter("inBusinessProgramType", Types.INTEGER));   
        declareParameter(new SqlParameter("inRenewalDate", Types.DATE));        
        declareParameter(new SqlParameter("inGroupID", Types.INTEGER));
        declareParameter(new SqlParameter("inSubgroupID", Types.INTEGER));
        declareParameter(new SqlParameter("inAuthCode", Types.VARCHAR));
        declareParameter(new SqlParameter("inPromoCode", Types.VARCHAR));
        declareParameter(new SqlParameter("inTemplateAuthPromoType", Types.VARCHAR));
        
        // Output Parameters   
        // None.
        
        compile();
    }

    /**
     * Executes HPD Stored Procedure validate_customer and returns a populated Company object.
     *
     * @return
     */
    public void execute(String pBusinessProgramType
            , java.sql.Date pRenewalDate
            , Integer pGroupID
            , Integer pSubgroupID
            , String pAuthCode
            , String pPromoCode
            , String pTemplateAuthPromoType)    
    {    	    	
        Map<String, Object> lInputParams = new HashMap<String, Object>(8);
              
        // Input
        lInputParams.put("inBusinessProgramType", pBusinessProgramType);
        lInputParams.put("inRenewalDate", pRenewalDate);
        lInputParams.put("inGroupID", pGroupID);
        lInputParams.put("inSubgroupID", pSubgroupID);
        lInputParams.put("inAuthCode", pAuthCode);
        lInputParams.put("inPromoCode", pPromoCode);
        lInputParams.put("inTemplateAuthPromoType", pTemplateAuthPromoType);
        
        Map<String, Object> lOutputParams = execute(lInputParams);
                        
        // Output
        if(lOutputParams.size() > 0) 
        {        	        	        	        	       
        }

        return;
    }

		        
}

/* $Id$ */

package com.healthpartners.service.imfs.rules;

import com.healthpartners.service.imfs.dto.BaseDTO;

/**
 * Adapter for a <code>Rule</code> that can be run by the rules engine.
 * 
 * @author pbhenninger
 */
public class RuleAdapter extends BaseDTO {

	static final long serialVersionUID = 0L;

	private String ruleName;

	private String drl;

	public RuleAdapter() {
		super();
	}

	public RuleAdapter(String ruleName, String drl) {
		super();

		this.ruleName = ruleName;
		this.drl = drl;
	}

	public String getDrl() {
		return drl;
	}

	public void setDrl(String drl) {
		this.drl = drl;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}
}

package com.healthpartners.service.imfs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.*;

import com.fasterxml.jackson.databind.util.Named;
import com.healthpartners.service.imfs.dao.QualificationCheckmarkDAO;
import com.healthpartners.service.imfs.dto.*;
import com.healthpartners.service.imfs.exception.BPMException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.exception.BPMException;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;

@Configuration
public class QualificationCheckmarkDAOJdbc extends JdbcDaoSupport implements QualificationCheckmarkDAO
{	
	private String selectQualificationCheckmarks;	
	private String selectCheckmarkRequirement;
	private String selectCheckmarkDetail;
	private String selectCollectionActivities;
	
	private String selectProgramCheckmarks;	
	private String insertProgramCheckmark;
	private String deleteProgramCheckmarks;
	
	public QualificationCheckmarkDAOJdbc() {
		super();
	}
	//Produces warnings during compile time to quickly identify typos or API changes

	@Autowired
	DataSource bpmDataSource;
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<QualificationCheckmark> getQualificationCheckmarks(int pBusinessProgramID)
	throws BPMException, DataAccessException
	{		

		Object params[] = new Object[] { pBusinessProgramID };
		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setBizPgmId(pBusinessProgramID);
		int types[] = new int[] { Types.INTEGER };

		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);


		List<QualificationCheckmark> lQualificationCheckmarkList = namedParameterJdbcTemplate.query(selectQualificationCheckmarks, namedParameters, new RowMapper()
		{
			@Override
			public QualificationCheckmark mapRow(ResultSet rs, int i) throws SQLException {
				QualificationCheckmark lQualificationCheckmark = new QualificationCheckmark();
				lQualificationCheckmark.setQualificationCheckmarkID(rs.getInt("QUALFCTN_CHKMRK_ID"));
				lQualificationCheckmark.setQualificationCheckmarkName(rs.getString("QUALFCTN_CHKMRK_NM"));
				lQualificationCheckmark.setQualificationCheckmarkInfo(rs.getString("QUALFCTN_CHKMRK_INFO"));
				lQualificationCheckmark.setQualificationCheckmarkDesc(rs.getString("QUALFCTN_CHKMRK_DESC"));
				lQualificationCheckmark.setEffectiveDate(rs.getDate("EFF_DT"));
				lQualificationCheckmark.setEndDate(rs.getDate("END_DT"));

				lQualificationCheckmark.setParticipationGroupID(rs.getInt("INCNTV_PART_GRP_ID"));
				lQualificationCheckmark.setParticipationGroupName(rs.getString("INCNTV_PART_GRP_NM"));
				lQualificationCheckmark.setProgramIncentiveOptionID(rs.getInt("BIZ_PGM_INCNTV_OPTN_ID"));
				lQualificationCheckmark.setIncentedStatusTypeCodeID(rs.getInt("INCNTD_STS_TP_CD_ID"));
				lQualificationCheckmark.setIncentedStatusTypeCode(rs.getString("INCNTD_STS_TP_CD"));

				lQualificationCheckmark.setEffectiveDateString(BPMUtils.formatDateMMddyyyy(lQualificationCheckmark.getEffectiveDate()));
				lQualificationCheckmark.setEndDateString(BPMUtils.formatDateMMddyyyy(lQualificationCheckmark.getEndDate()));

				return lQualificationCheckmark;
			}


		});				
		
		return lQualificationCheckmarkList;
	}
	

	/**
	 * 
	 * @param pQualificationCheckmarkID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<CheckmarkRequirement> getCheckmarkRequirements(Integer pQualificationCheckmarkID)
	throws BPMException, DataAccessException
	{

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { pQualificationCheckmarkID };
		int types[] = new int[] { Types.INTEGER };

		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setQualificationCheckId(pQualificationCheckmarkID);
		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);
		List<CheckmarkRequirement> lCheckmarkRequirements = namedParameterJdbcTemplate.query(selectCheckmarkRequirement, namedParameters, new RowMapper()
		{
			@Override
			public CheckmarkRequirement mapRow(ResultSet rs, int i) throws SQLException {
				CheckmarkRequirement lCheckmarkRequirement = new CheckmarkRequirement();
				lCheckmarkRequirement.setQualificationCheckmarkID(rs.getInt("QUALFCTN_CHKMRK_ID"));
				lCheckmarkRequirement.setRequirementID(rs.getInt("REQD_QUALFCTN_CHKMRK_ID"));
				lCheckmarkRequirement.setQuantity(rs.getInt("REQD_ACTV_QTY"));
				lCheckmarkRequirement.setQualificationStatusCodeID(rs.getInt("QUALFCTN_STAT_CD_ID"));
				lCheckmarkRequirement.setQualificationStatusCode(rs.getString("QUALFCTN_STAT_CD"));
				return lCheckmarkRequirement;
			}

		});
		
		// Now for each Checkmark Requirement, retrieve the Requirement Details.
		for(int i = 0; i < lCheckmarkRequirements.size(); i++)
		{
			ArrayList<CheckmarkDetail> lCheckmarkDetails = (ArrayList<CheckmarkDetail>) 
			    getCheckmarkDetails(pQualificationCheckmarkID, lCheckmarkRequirements.get(i).getRequirementID());
			
			lCheckmarkRequirements.get(i).setCheckmarkDetails(lCheckmarkDetails);
		}
		
		return lCheckmarkRequirements;
	}
	
	/**
	 * 
	 * @param pQualificationCheckmarkID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<CheckmarkDetail> getCheckmarkDetails(Integer pQualificationCheckmarkID, Integer pRequirementID)
	throws BPMException, DataAccessException
	{		

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { pQualificationCheckmarkID, pRequirementID };
		int types[] = new int[] { Types.INTEGER, Types.INTEGER };
		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setQualificationCheckId(pQualificationCheckmarkID);
		namedParameter.setReqQualCheckId(pRequirementID);


		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<CheckmarkDetail> lCheckmarkDetailList = namedParameterJdbcTemplate.query(selectCheckmarkDetail, namedParameters, new RowMapper()
		{
			@Override
			public CheckmarkDetail mapRow(ResultSet rs, int i) throws SQLException {
				CheckmarkDetail lCheckmarkDetail = new CheckmarkDetail();
				lCheckmarkDetail.setQualificationCheckmarkID(rs.getInt("QUALFCTN_CHKMRK_ID"));
				lCheckmarkDetail.setRequirementID(rs.getInt("REQD_QUALFCTN_CHKMRK_ID"));
				lCheckmarkDetail.setActivityID(rs.getInt("ACTV_ID"));
				lCheckmarkDetail.setActivityName(rs.getString("actv_nm"));
				lCheckmarkDetail.setActivityTypeCodeID(rs.getInt("ACTV_TP_CD_ID"));
				lCheckmarkDetail.setActivityTypeCode(rs.getString("actv_tp"));
				lCheckmarkDetail.setQuantity(rs.getInt("REQD_ACTV_QTY"));

				ActivityCollection lActivityCollection = new ActivityCollection();
				lActivityCollection.setCollectionID(rs.getInt("COLLECTION_ID"));
				lActivityCollection.setRequiredQuantity(rs.getInt("REQRD_QTY"));
				lCheckmarkDetail.setActivityCollection(lActivityCollection);
				return lCheckmarkDetail;
			}



		});
		
		for(CheckmarkDetail lCheckmarkDetail : lCheckmarkDetailList)
		{
			lCheckmarkDetail.getActivityCollection().setCollectionActivities(
			   getCollectionActivities(lCheckmarkDetail.getActivityCollection().getCollectionID()));
		}
		
		return lCheckmarkDetailList;
	}
	
	/**
	 * 
	 * @param pCollectionID
	 * @return
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public List<ActivityDefinition> getCollectionActivities(Integer pCollectionID)
	{

		Map<String, Integer> parameters = new HashMap<String, Integer>();
		parameters.put("collectionID", pCollectionID);

		List<ActivityDefinition> lCollectionActivities = namedParameterJdbcTemplate.query(selectCollectionActivities, parameters, new RowMapper()
		{
			public ActivityDefinition mapRow(ResultSet rs, int i) throws SQLException {
				ActivityDefinition lActivityDefinition = new ActivityDefinition();

				lActivityDefinition.setActivityID(rs.getInt("ACTV_ID"));
				lActivityDefinition.setSourceActivityID(rs.getString("srce_actv_id"));
				return lActivityDefinition;
			}

		});

		return lCollectionActivities;
	}
//	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
//	public ArrayList<ActivityDefinition> getCollectionActivities(Integer pCollectionID)
//	{
//		final ArrayList<ActivityDefinition> lCollectionActivities = new ArrayList<ActivityDefinition>();
//
//		JdbcTemplate template = getJdbcTemplate();
//		Object params[] = new Object[] { pCollectionID };
//		int types[] = new int[] { Types.INTEGER };
//
//		template.query(selectCollectionActivities, params, types, new RowCallbackHandler()
//		{
//			public void processRow(ResultSet rs) throws SQLException
//			{
//				ActivityDefinition lActivityDefinition = new ActivityDefinition();
//
//				lActivityDefinition.setActivityID(rs.getInt("ACTV_ID"));
//				lActivityDefinition.setSourceActivityID(rs.getString("srce_actv_id"));
//
//				lCollectionActivities.add(lActivityDefinition);
//			}
//		});
//
//		return lCollectionActivities;
//	}
	
	/**
	 * 
	 * @param pProgramID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public ArrayList<ProgramCheckmark> getProgramCheckmarks(Integer pProgramID)
	throws BPMException, DataAccessException
	{
		final ArrayList<ProgramCheckmark> lProgramCheckmarkList = new ArrayList<ProgramCheckmark>();		
		
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { pProgramID };
		int types[] = new int[] { Types.INTEGER };
		
		template.query(selectProgramCheckmarks, params, types, new RowCallbackHandler()  
		{
			public void processRow(ResultSet rs) throws SQLException 
			{					
				ProgramCheckmark lProgramCheckmark = new ProgramCheckmark();
				lProgramCheckmark.setQualificationCheckmarkID(rs.getInt("QUALFCTN_CHKMRK_ID"));
				lProgramCheckmark.setQualificationCheckmarkName(rs.getString("QUALFCTN_CHKMRK_NM"));
				lProgramCheckmark.setQualificationCheckmarkInfo(rs.getString("QUALFCTN_CHKMRK_INFO"));
				lProgramCheckmark.setQualificationCheckmarkDesc(rs.getString("QUALFCTN_CHKMRK_DESC"));
				lProgramCheckmark.setEffectiveDate(rs.getDate("EFF_DT"));
				lProgramCheckmark.setEndDate(rs.getDate("END_DT"));
				
				lProgramCheckmark.setParticipationGroupID(rs.getInt("INCNTV_PART_GRP_ID"));
				lProgramCheckmark.setParticipationGroupName(rs.getString("INCNTV_PART_GRP_NM"));
				
				lProgramCheckmark.setEffectiveDateString(BPMUtils.formatDateMMddyyyy(lProgramCheckmark.getEffectiveDate()));
				lProgramCheckmark.setEndDateString(BPMUtils.formatDateMMddyyyy(lProgramCheckmark.getEndDate()));
				
				lProgramCheckmarkList.add(lProgramCheckmark);
			}
		});				
		
		return lProgramCheckmarkList;
	}
	
	/**
	 * 
	 * @param pProgramCheckmarks
	 * @param pModifyUserID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int insertProgramCheckmarks(ArrayList<ProgramCheckmark> pProgramCheckmarks
			, String pModifyUserID)
	throws BPMException, DataAccessException
	{
		int rowInserted = 0;
		JdbcTemplate template = getJdbcTemplate();				
		
		for(int i = 0; i < pProgramCheckmarks.size(); i++)
		{
			Object params[] = new Object[] {  
					  pProgramCheckmarks.get(i).getQualificationCheckmarkID()
                    , pProgramCheckmarks.get(i).getBusinessProgramID()
                    , pProgramCheckmarks.get(i).getParticipationGroupID()                    
                    , pProgramCheckmarks.get(i).getEffectiveDate()
                    , pProgramCheckmarks.get(i).getEndDate()
					, pModifyUserID, pModifyUserID};

            int types[] = new int[] {Types.INTEGER, Types.INTEGER
            		, Types.INTEGER
            		, Types.DATE, Types.DATE
					, Types.VARCHAR, Types.VARCHAR};

            rowInserted += template.update(insertProgramCheckmark, params, types);
		}
		
		return rowInserted;
	}
	
	/**
	 * 
	 * @param pProgramCheckmarks
	 * @param pBusinessProgramID
	 * @param pModifyUserID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int updateProgramCheckmarks(ArrayList<ProgramCheckmark> pProgramCheckmarks
			, Integer pBusinessProgramID
			, String pModifyUserID)
	throws BPMException, DataAccessException
	{		
		deleteProgramCheckmarks(pBusinessProgramID);
		
		return insertProgramCheckmarks(pProgramCheckmarks, pModifyUserID);
	}

	/**
	 * 
	 * @param pProgramID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int deleteProgramCheckmarks(Integer pProgramID) 
	throws BPMException, DataAccessException
	{		
		JdbcTemplate template = getJdbcTemplate();
		int rowInserted = 0;
				
		Object params[] = new Object[] {  pProgramID};

        int types[] = new int[] {Types.INTEGER };

        rowInserted = template.update(deleteProgramCheckmarks, params, types);
		
		return rowInserted;
	}
	
	public String getSelectQualificationCheckmarks() {
		return selectQualificationCheckmarks;
	}


	public void setSelectQualificationCheckmarks(String selectQualificationCheckmarks) {
		this.selectQualificationCheckmarks = selectQualificationCheckmarks;
	}

	public String getSelectCheckmarkDetail() {
		return selectCheckmarkDetail;
	}

	public void setSelectCheckmarkDetail(String selectCheckmarkDetail) {
		this.selectCheckmarkDetail = selectCheckmarkDetail;
	}

	public String getSelectCheckmarkRequirement() {
		return selectCheckmarkRequirement;
	}

	public void setSelectCheckmarkRequirement(String selectCheckmarkRequirement) {
		this.selectCheckmarkRequirement = selectCheckmarkRequirement;
	}

	public final String getSelectCollectionActivities() {
		return selectCollectionActivities;
	}

	public final void setSelectCollectionActivities(
			String selectCollectionActivities) {
		this.selectCollectionActivities = selectCollectionActivities;
	}

	public String getSelectProgramCheckmarks() {
		return selectProgramCheckmarks;
	}

	public void setSelectProgramCheckmarks(String selectProgramCheckmarks) {
		this.selectProgramCheckmarks = selectProgramCheckmarks;
	}

	public String getInsertProgramCheckmark() {
		return insertProgramCheckmark;
	}

	public void setInsertProgramCheckmark(String insertProgramCheckmark) {
		this.insertProgramCheckmark = insertProgramCheckmark;
	}

	public String getDeleteProgramCheckmarks() {
		return deleteProgramCheckmarks;
	}

	public void setDeleteProgramCheckmarks(String deleteProgramCheckmarks) {
		this.deleteProgramCheckmarks = deleteProgramCheckmarks;
	}
	
	
}

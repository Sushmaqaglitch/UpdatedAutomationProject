/**
 * 
 */
package com.healthpartners.service.imfs.iface;

import java.util.Calendar;

import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.exception.BPMException;

/**
 * @author mxthoutam
 * 
 */
public interface QualificationTimeService {
	/**
	 * current date
	 * 
	 * @return Calendar
	 * @throws BPMException
	 */
	public Calendar getCurrentDate() throws BPMException;

	/**
	 * target benifit year
	 * 
	 * @return int
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public int getTargetBenefitYear() throws BPMException, DataAccessException;
	
	public int getTargetQualificationYear() throws BPMException, DataAccessException; 
}

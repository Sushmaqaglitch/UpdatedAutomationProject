/* $Id: LookUpValueDAOJdbc.java 227262 2013-02-22 20:50:26Z tjquist $ */

package com.healthpartners.service.imfs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;

import com.healthpartners.service.imfs.dto.EnvCode;
import com.healthpartners.service.imfs.exception.BPMException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;


import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.dto.EnvCode;
import com.healthpartners.service.imfs.exception.BPMException;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;


/**
 * JDBC implementation of the LookUpValueDAO interface.
 * 
 * @author tjquist
 */
@Configuration
public class EnvCodeDAOJdbc extends JdbcDaoSupport implements
		EnvCodeDAO {

	/*
	 * Generic Code SQL statements
	 */

	private String getAllENVCodes;
	
	private String getENVCodeByID;

	private String getENVCodesByDesc;
	
	private String getENVCodeByCode;


	public EnvCodeDAOJdbc() {
		super();
	}

	@Autowired
	DataSource bpmDataSource;


	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}


	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<EnvCode> getAllENVCodes()
			throws DataAccessException {
		final ArrayList<EnvCode> results = new ArrayList<EnvCode>();
		JdbcTemplate template = getJdbcTemplate();
		template.query(getAllENVCodes, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				EnvCode code = new EnvCode();
				code.setEnvCodeID(Integer.valueOf(rs.getInt(1)));
				code.setEnvCode(rs.getString(2));
				code.setEnvCodeValue(rs.getString(3));
				code.setEnvCodeDesc(rs.getString(4));
				results.add(code);
			}
		});
		return results;
	}
	

	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public EnvCode getENVCodeByID(Integer envCodeValID)
			throws DataAccessException {
		final ArrayList<EnvCode> results = new ArrayList<EnvCode>();

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { envCodeValID };
		int types[] = new int[] { Types.INTEGER };
		template.query(getENVCodeByID, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						EnvCode code = new EnvCode();
						code.setEnvCodeID(Integer.valueOf(rs.getInt(1)));
						code.setEnvCode(rs.getString(2));
						code.setEnvCodeValue(rs.getString(3));
						code.setEnvCodeDesc(rs.getString(4));				
						results.add(code);
					}
				});

		EnvCode dto = null;
		if (results.size() > 0) {
			dto = (EnvCode) results.get(0);
		}
		return dto;
	}

	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<EnvCode> getENVCodesByDesc(String envDesc)
			throws DataAccessException {
		final ArrayList<EnvCode> results = new ArrayList<EnvCode>();

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { envDesc };
		int types[] = new int[] { Types.VARCHAR };
		template.query(getENVCodesByDesc, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						EnvCode code = new EnvCode();
						code.setEnvCodeID(Integer.valueOf(rs.getInt(1)));
						code.setEnvCode(rs.getString(2));
						code.setEnvCodeValue(rs.getString(3));
						code.setEnvCodeDesc(rs.getString(4));					
						results.add(code);
					}
				});

		return results;
	}
	

	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public EnvCode getENVCodeByCode(String code)
			throws DataAccessException {
		final ArrayList<EnvCode> results = new ArrayList<EnvCode>();

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { code };
		int types[] = new int[] { Types.VARCHAR };
		template.query(getENVCodeByCode, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						EnvCode code = new EnvCode();
						code.setEnvCodeID(Integer.valueOf(rs.getInt(1)));
						code.setEnvCode(rs.getString(2));
						code.setEnvCodeValue(rs.getString(3));
						code.setEnvCodeDesc(rs.getString(4));				
						results.add(code);
					}
				});

		EnvCode dto = null;
		if (results.size() > 0) {
			dto = (EnvCode) results.get(0);
		}
		return dto;
	}



	public String getGetAllENVCodes() {
		return getAllENVCodes;
	}



	public void setGetAllENVCodes(String getAllENVCodes) {
		this.getAllENVCodes = getAllENVCodes;
	}



	public String getGetENVCodeByID() {
		return getENVCodeByID;
	}



	public void setGetENVCodeByID(String getENVCodeByID) {
		this.getENVCodeByID = getENVCodeByID;
	}



	public String getGetENVCodesByDesc() {
		return getENVCodesByDesc;
	}



	public void setGetENVCodesByDesc(String getENVCodesByDesc) {
		this.getENVCodesByDesc = getENVCodesByDesc;
	}



	public String getGetENVCodeByCode() {
		return getENVCodeByCode;
	}



	public void setGetENVCodeByCode(String getENVCodeByCode) {
		this.getENVCodeByCode = getENVCodeByCode;
	}

	public void setBpmDataSource(DataSource bpmDataSource) {
		this.bpmDataSource = bpmDataSource;
	}
}
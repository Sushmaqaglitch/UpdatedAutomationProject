package com.healthpartners.service.imfs.dto;



public class HeaderEmployerSponsoredActivityDetail
{	

    public HeaderEmployerSponsoredActivityDetail()
    {
    	super();
    }

    private String incentedDate;    
    private String groupNo;
    private String siteNo;
    private String memberNo;
    private String lastName;
    private String firstName;
    private String contractNo;
    private String activityID;
    private String activityName;
    private String contributionAmt;
    private String contributionDate;
    private String productType;
	public String getIncentedDate() {
		return incentedDate;
	}
	public void setIncentedDate(String incentedDate) {
		this.incentedDate = incentedDate;
	}
	public String getGroupNo() {
		return groupNo;
	}
	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}
	public String getSiteNo() {
		return siteNo;
	}
	public void setSiteNo(String siteNo) {
		this.siteNo = siteNo;
	}
	public String getMemberNo() {
		return memberNo;
	}
	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getContractNo() {
		return contractNo;
	}
	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}
	public String getActivityID() {
		return activityID;
	}
	public void setActivityID(String activityID) {
		this.activityID = activityID;
	}
	public String getActivityName() {
		return activityName;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public String getContributionAmt() {
		return contributionAmt;
	}
	public void setContributionAmt(String contributionAmt) {
		this.contributionAmt = contributionAmt;
	}
	public String getContributionDate() {
		return contributionDate;
	}
	public void setContributionDate(String contributionDate) {
		this.contributionDate = contributionDate;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
    
    

	
}

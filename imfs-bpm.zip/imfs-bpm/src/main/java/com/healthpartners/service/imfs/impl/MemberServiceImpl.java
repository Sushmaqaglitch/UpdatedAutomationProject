package com.healthpartners.service.imfs.impl;

import java.text.SimpleDateFormat;
import java.util.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dao.ActivityDAO;
import com.healthpartners.service.imfs.dao.ActivityEventLogDAO;
import com.healthpartners.service.imfs.dao.AdditionalInfoDAO;
import com.healthpartners.service.imfs.dao.BusinessProgramDAO;
import com.healthpartners.service.imfs.dao.ContractDAO;
import com.healthpartners.service.imfs.dao.IncentiveOptionDAO;
import com.healthpartners.service.imfs.dao.LookUpValueDAO;
import com.healthpartners.service.imfs.dao.ParticipationGroupDAO;
import com.healthpartners.service.imfs.dao.PersonDAO;
import com.healthpartners.service.imfs.dao.ProcessingStatusLogDAO;
import com.healthpartners.service.imfs.dao.QualificationOverrideDAO;
import com.healthpartners.service.imfs.dao.TaskEventLogDAO;
import com.healthpartners.service.imfs.dto.Activity;
import com.healthpartners.service.imfs.dto.ActivityEvent;
import com.healthpartners.service.imfs.dto.ActivityExternalEmployerXref;
import com.healthpartners.service.imfs.dto.ActivityFulfillmentTrackingReportHist;
import com.healthpartners.service.imfs.dto.AdditionalInformation;
import com.healthpartners.service.imfs.dto.AuthCode;
import com.healthpartners.service.imfs.dto.BPMBusinessProgram;
import com.healthpartners.service.imfs.dto.BPMRequiredParticipantResponse;
import com.healthpartners.service.imfs.dto.BusinessProgramTO;
import com.healthpartners.service.imfs.dto.CDHPFulfillmentTrackingReportHist;
import com.healthpartners.service.imfs.dto.Contract;
import com.healthpartners.service.imfs.dto.ContractProgramIncentiveTO;
import com.healthpartners.service.imfs.dto.ContractProgramStatusTO;
import com.healthpartners.service.imfs.dto.EligibleActivity;
import com.healthpartners.service.imfs.dto.EligibleProgramActivity;
import com.healthpartners.service.imfs.dto.EmployerActivityContributionsFileData;
import com.healthpartners.service.imfs.dto.EmployerGroup;
import com.healthpartners.service.imfs.dto.EmployerSponsoredActivity;
import com.healthpartners.service.imfs.dto.IncentiveStatusActivityDetail;
import com.healthpartners.service.imfs.dto.LookUpValueCode;
import com.healthpartners.service.imfs.dto.Member;
import com.healthpartners.service.imfs.dto.MemberActivity;
import com.healthpartners.service.imfs.dto.MemberContractProgramTO;
import com.healthpartners.service.imfs.dto.MemberProgramIncentiveTO;
import com.healthpartners.service.imfs.dto.MemberProgramStatus;
import com.healthpartners.service.imfs.dto.MemberProgramUpdateTO;
import com.healthpartners.service.imfs.dto.MemberTO;
import com.healthpartners.service.imfs.dto.MemberUpdate;
import com.healthpartners.service.imfs.dto.ParticipationGroup;
import com.healthpartners.service.imfs.dto.ParticipationGroupDetail;
import com.healthpartners.service.imfs.dto.ParticipationGroupRequirement;
import com.healthpartners.service.imfs.dto.Person;
import com.healthpartners.service.imfs.dto.PersonActivityAchievedContribution;
import com.healthpartners.service.imfs.dto.PersonActivityAchievedReward;
import com.healthpartners.service.imfs.dto.PersonActivityIncentToFulfillReconcile;
import com.healthpartners.service.imfs.dto.PersonContractHist;
import com.healthpartners.service.imfs.dto.PersonContractRecycle;
import com.healthpartners.service.imfs.dto.PersonProgramActivityIncentiveStatus;
import com.healthpartners.service.imfs.dto.PersonProgramHealthPlan;
import com.healthpartners.service.imfs.dto.PersonRelationship;
import com.healthpartners.service.imfs.dto.ProgramIncentiveOption;
import com.healthpartners.service.imfs.dto.QualificationOverride;
import com.healthpartners.service.imfs.dto.RequiredParticipant;
import com.healthpartners.service.imfs.dto.SubgroupHistory;
import com.healthpartners.service.imfs.dto.WebServiceRequest;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.iface.DemoSiteService;
import com.healthpartners.service.imfs.iface.MemberService;
import com.healthpartners.service.imfs.iface.QualificationTimeService;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
@Component
@Service
public class MemberServiceImpl implements MemberService {
	@Autowired
	private ActivityDAO activityDAO;
	@Autowired
	private BusinessProgramDAO businessProgramDAO;
	@Autowired
	private AdditionalInfoDAO additionalInfoDAO;
	@Autowired
	private PersonDAO personDAO;
	@Autowired
	private ContractDAO contractDAO;
	@Autowired
	private TaskEventLogDAO taskEventLogDAO;
	@Autowired
	private QualificationTimeService qualificationTimeService;

	@Autowired
	private ProcessingStatusLogDAO processingStatusLogDAO;
	@Autowired
	private QualificationOverrideDAO qualificationOverrideDAO;
	@Autowired
	private IncentiveOptionDAO incentiveOptionDAO;
	@Autowired
	private ActivityEventLogDAO activityEventLogDAO;
	@Autowired
	private ParticipationGroupDAO participationGroupDAO;
	@Autowired
	private LookUpValueDAO lookUpValueDAO;
	@Autowired
	private DemoSiteService demoSiteService;

	
	private HashMap<String, Integer> lookUpValuesRecycleStatusHM = new HashMap<String, Integer>();
	private HashMap<String, Integer> lookUpValuesContractStatusHM = new HashMap<String, Integer>();
	private HashMap<String, Integer> lookUpValuesMemberStatusHM = new HashMap<String, Integer>();


	protected final Log logger = LogFactory.getLog(getClass());

	public MemberServiceImpl() {
		super();
		
	}

	/**
	 * @param pPersonID
	 * 
	 * @return list of Business Programs a Member participates in.
	 * 
	 */

	public Collection<BusinessProgramTO> getBusinessPrograms(Integer pPersonID)
			throws BPMException, DataAccessException {

		Collection<BusinessProgramTO> programs = new ArrayList<BusinessProgramTO>();

		// Sending a null for program-year will retrieve all years. 
		ArrayList<BusinessProgramTO> lBusinessProgramTOs = (ArrayList<BusinessProgramTO>) businessProgramDAO
					.getBusinessProgramTO(pPersonID, null);

		programs.addAll(lBusinessProgramTOs);

		if (programs != null && programs.size() > 0) {
			Iterator<BusinessProgramTO> itr = programs.iterator();
			while (itr.hasNext()) {
				BusinessProgramTO businessProgram = itr.next();
				Collection<EligibleActivity> lEligibleActivities = activityDAO
						.getEligibleActivities(businessProgram.getProgramID());
				EligibleActivity[] lEligibleActivityArray = new EligibleActivity[lEligibleActivities
						.size()];
				lEligibleActivities.toArray(lEligibleActivityArray);
				businessProgram.getBusinessProgram().setEligibleActivities(
						lEligibleActivityArray);
			}
		}

		return programs;
	}
	
	public Collection<BPMBusinessProgram> getParticipatingBusinessPrograms(Integer pPersonID)
	throws BPMException, DataAccessException 
	{
		Collection<BPMBusinessProgram> programs = new ArrayList<BPMBusinessProgram>();
				
        // The boolean is to limit the number of previous years member status is calculated.
	    ArrayList<BPMBusinessProgram> lBusinessPrograms = (ArrayList<BPMBusinessProgram>) businessProgramDAO
					.getBPMBusinessPrograms(pPersonID, null, true);
		
	    programs.addAll(lBusinessPrograms);

        return programs;
    }
	
	public Collection<BPMBusinessProgram> getParticipatingBusinessProgramsWTermedContract(Integer pPersonID)
			throws BPMException, DataAccessException 
	{
		Collection<BPMBusinessProgram> programs = new ArrayList<BPMBusinessProgram>();
				
        // The boolean is to limit the number of previous years member status is calculated.
	    ArrayList<BPMBusinessProgram> lBusinessPrograms = (ArrayList<BPMBusinessProgram>) businessProgramDAO
					.getBPMBusinessProgramsWTermedContract(pPersonID, null, true);
		
	    programs.addAll(lBusinessPrograms);

        return programs;
    }

	/**
	 * @param pMemberID
	 * 
	 * @return list of Business Programs a Member participates in.
	 * 
	 */

	public Collection<BusinessProgramTO> getBusinessPrograms(String pMemberID)
			throws BPMException, DataAccessException {

		Integer personID = personDAO.getPersonID(pMemberID);
		
		// If a person ID was not found for the given member ID, return an empty list.
		if(personID == null || personID.intValue() <= 0)
		{
			return new ArrayList<BusinessProgramTO>();
		}

		return getBusinessPrograms(personID);
	}

	public Integer getPersonID(String hpMemberID) throws BPMException,
			DataAccessException {

		return personDAO.getPersonID(hpMemberID);
	}

	/**
	 * Called by the web service, this method returns a collection of
	 * MemberProgramStatus objects. Each MemberProgramStatus object in the
	 * collection represents a target benefit year, and contains the Program for
	 * that year, and all the Members (policy holder and relatives) for that
	 * program for that year. Each Member object also has a list of that
	 * Member's Activities.
	 * 
	 * 2008 Healthy Benefits web service - Deprecated on 5/5/2015
	 * 
	 * @deprecated
	 * @param pWebServiceRequest
	 * @return Collection<MemberProgramStatus>
	 */
	public Collection<MemberProgramStatus> getMemberProgramStatus(
			WebServiceRequest pWebServiceRequest) {
		ArrayList<MemberProgramStatus> lMemberProgramStatuses = new ArrayList<MemberProgramStatus>();

		Integer personID = personDAO.getPersonID(pWebServiceRequest
				.getMemberID());
		
		boolean lCalledFromWebPortal = true;

		if(personID == null || personID.intValue() <= 0) {
			return new ArrayList<MemberProgramStatus>();
		}

		if (pWebServiceRequest.getGroupNumber() == null) {
			pWebServiceRequest.setGroupNumber(String.valueOf(0));
		}

		// The target benefit year is "ALL".
		if (pWebServiceRequest.getTargetQualificationYear().equalsIgnoreCase(
				BPMConstants.ALL_BENEFIT_YEARS)) 
		{
			lCalledFromWebPortal = false;
			// Called for ALL years. Get member status for this person for all participation years.						
			ArrayList<MemberProgramStatus> lMemberProgramStatusArrayList = getMemberProgramStatus(personID, lCalledFromWebPortal); 												
			
			lMemberProgramStatuses.addAll(lMemberProgramStatusArrayList);
			
		} else {
			// The target benefit year is provided.
			// Get the programs and populate the members for that program for
			// that year.
			String lTargetQualificationYear = null;
			BPMRequiredParticipantResponse lResponse = isRequiredParticipant(pWebServiceRequest);
			
			if(lResponse.getRequiredParticipants().size() > 0)
			{	
				for(int k = 0; k < lResponse.getRequiredParticipants().size(); k++)
				{
			        lTargetQualificationYear = lResponse.getRequiredParticipants().get(k).getQualificationYear();

					if(lTargetQualificationYear != null)
					{
					lMemberProgramStatuses.addAll(getMemberProgramStatus(personID,
							pWebServiceRequest.getProgramCode(), Integer
									.valueOf(lTargetQualificationYear),
							pWebServiceRequest.getGroupNumber(), pWebServiceRequest
									.getMemberID(), lCalledFromWebPortal, 
									lResponse.getRequiredParticipants().get(k).getProgramID()));
					}
				}
			}
		}

		return lMemberProgramStatuses;
	}

	/**
	 * Utility method called for one target benefit year. It retrieves all the
	 * programs for the member for the given year.
	 * 
	 * @deprecated
	 * @param pPersonID
	 * @param pProgramCode
	 * @param pTargetQualificationYear
	 * @param pGroupNumber
	 * @param pMemberID
	 * @return
	 */
	private ArrayList<MemberProgramStatus> getMemberProgramStatus(
			Integer pPersonID, String pProgramCode,
			Integer pTargetQualificationYear, String pGroupNumber,
			String pMemberID, boolean pCalledFromWebPortal, Integer pProgramID) {
		ArrayList<MemberProgramStatus> lMemberProgramStatuses = new ArrayList<MemberProgramStatus>();

		ArrayList<BusinessProgramTO> lBusinessProgramTOs = (ArrayList<BusinessProgramTO>) businessProgramDAO
				.getBusinessProgramTO(pPersonID, pProgramCode,
						pTargetQualificationYear, String.valueOf(pGroupNumber), pProgramID);						
						
		// For each program, get the members.
		for (int j = 0; j < lBusinessProgramTOs.size(); j++) {
			BusinessProgramTO lBusinessProgramTO = (BusinessProgramTO) lBusinessProgramTOs
					.get(j);						
						
			ArrayList<Integer> lProgramIDs = (ArrayList<Integer>)
			businessProgramDAO.getHAAvailable(new Integer(lBusinessProgramTO.getProgramID()),
					String.valueOf(pTargetQualificationYear), Calendar.getInstance());
			
			lBusinessProgramTO.getBusinessProgram().setProgramAvailable(false);
						
			for (int k = 0; k < lProgramIDs.size(); k++) 
			{
				Integer lProgramID = (Integer) lProgramIDs.get(k);		
				if (lProgramID != null && lProgramID.intValue() == lBusinessProgramTO.getProgramID()) 
				{
					lBusinessProgramTO.getBusinessProgram().setProgramAvailable(true);
					break;
				}				
			}
			
			lBusinessProgramTO.getBusinessProgram().setEligibleActivities(
					getEligibleActivityArray(lBusinessProgramTO.getProgramID()));
							
		    lBusinessProgramTO.getBusinessProgram().setProgramIncentiveOptions(
		    		getProgramIncentiveOptionArray(lBusinessProgramTO.getProgramID()));

		    lBusinessProgramTO.getBusinessProgram().setProgramAdditionalInformation(
		    		getProgramAdditionalInfoArray(lBusinessProgramTO.getProgramID()));

			MemberProgramStatus lMemberProgramStatus = new MemberProgramStatus();
			Collection<Member> lMembers = getMembers(pPersonID,
					lBusinessProgramTO, pCalledFromWebPortal);

			if (lMembers != null && lMembers.size() > 0) {
				Member[] lMemberArray = new Member[lMembers.size()];
				lMembers.toArray(lMemberArray);

				lMemberProgramStatus.setMembers(lMemberArray);
				lMemberProgramStatus.setBusinessProgram(lBusinessProgramTO
						.getBusinessProgram());
				lMemberProgramStatuses.add(lMemberProgramStatus);
			}
		}

		return lMemberProgramStatuses;
	}
	
	/**
	 * 
	 * 2008 Healthy Benefits web service - Deprecated on 5/5/2015
	 * 
	 * @deprecated
	 * Get Member Program Status for All business programs this person participates in.
	 * @param pPersonID
	 * @return
	 */
	private ArrayList<MemberProgramStatus> getMemberProgramStatus(Integer pPersonID, boolean pCalledFromWebPortal)
	{
		ArrayList<MemberProgramStatus> lMemberProgramStatuses = new ArrayList<MemberProgramStatus>();				

		ArrayList<BusinessProgramTO> lBusinessProgramTOs = (ArrayList<BusinessProgramTO>) 
		    businessProgramDAO.getAllBusinessPrograms(pPersonID, pCalledFromWebPortal);				
				
		for (int j = 0; j < lBusinessProgramTOs.size(); j++) 
		{
			BusinessProgramTO lBusinessProgramTO = (BusinessProgramTO) lBusinessProgramTOs.get(j);
			
			lBusinessProgramTO.getBusinessProgram().setEligibleActivities(
					getEligibleActivityArray(lBusinessProgramTO.getProgramID()));
			
			lBusinessProgramTO.getBusinessProgram().setProgramIncentiveOptions(
		    		getProgramIncentiveOptionArray(lBusinessProgramTO.getProgramID()));
			
			lBusinessProgramTO.getBusinessProgram().setProgramAdditionalInformation(
		    		getProgramAdditionalInfoArray(lBusinessProgramTO.getProgramID()));
			
			MemberProgramStatus lMemberProgramStatus = new MemberProgramStatus();
			Collection<Member> lMembers = getMembers(pPersonID,
					lBusinessProgramTO, pCalledFromWebPortal);

			if (lMembers != null && lMembers.size() > 0) {
				Member[] lMemberArray = new Member[lMembers.size()];
				lMembers.toArray(lMemberArray);

				lMemberProgramStatus.setMembers(lMemberArray);
				lMemberProgramStatus.setBusinessProgram(lBusinessProgramTO
						.getBusinessProgram());
				lMemberProgramStatuses.add(lMemberProgramStatus);
			}
		}
		
		return lMemberProgramStatuses;
	}
			
	/**
	 * 
	 * @param pProgramID
	 * @return
	 */
	private EligibleActivity[] getEligibleActivityArray(Integer pProgramID)
	{
		ArrayList<EligibleActivity> lEligibleActivities = (ArrayList<EligibleActivity>) 
		    getEligibleActivities(pProgramID);

		EligibleActivity[] lEligibleActivityArray = new EligibleActivity[lEligibleActivities
				.size()];
		lEligibleActivities.toArray(lEligibleActivityArray);
		
		return lEligibleActivityArray;
	}

	/**
	 * 
	 * @param pProgramID
	 * @return
	 */
	private ProgramIncentiveOption[] getProgramIncentiveOptionArray(Integer pProgramID)
	{
	    ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = 
		    (ArrayList<ProgramIncentiveOption>)getProgramIncentiveOptions(pProgramID);

        ProgramIncentiveOption[] lProgramIncentiveOptionArray = new ProgramIncentiveOption[lProgramIncentiveOptions.size()];
        lProgramIncentiveOptions.toArray(lProgramIncentiveOptionArray);
    
        return lProgramIncentiveOptionArray;
	}
	
	/**
	 * 
	 * @param pProgramID
	 * @return
	 */
	private AdditionalInformation[] getProgramAdditionalInfoArray(Integer pProgramID)
	{
	    ArrayList<AdditionalInformation> lAdditionalInfos = 
		    (ArrayList<AdditionalInformation>)getProgramAdditionalInfos(pProgramID);

        AdditionalInformation[] lProgramAdittionalInfoArray = new AdditionalInformation[lAdditionalInfos.size()];
        lAdditionalInfos.toArray(lProgramAdittionalInfoArray);
        
        return lProgramAdittionalInfoArray;
	}
	/**
	 * 
	 */
	public Collection<Member> getMembers(String pMemberID,
			BusinessProgramTO pBusinessProgramTO) {
		Integer personID = personDAO.getPersonID(pMemberID);
		if(personID == null || personID.intValue() <= 0)
		{
			return new ArrayList<Member>();
		}
		return getMembers(personID, pBusinessProgramTO, true);
	}

	/**
	 * Get a collection of members for a given Business Program (by program ID)
	 * and a given Target Benefit Year. Each Member has a collection of Member
	 * Activities.
	 */
	public Collection<Member> getMembers(Integer pPersonID,
			BusinessProgramTO pBusinessProgramTO, boolean pCalledFromWebPortal) {
		ArrayList<Member> lMembers = new ArrayList<Member>();

		Member lMember = null;
		ArrayList<MemberActivity> lMemberActivities = null;		

		ArrayList<PersonRelationship> lRelations = (ArrayList<PersonRelationship>) personDAO
				.getPersonRelationship(pPersonID, pBusinessProgramTO.getProgramID());		
		
		// For each person related to the main policy-holder, find the member
		// information,
		// find the activities, and add the member to the member-array.
		for (int i = 0; i < lRelations.size(); i++) {

			PersonRelationship lPersonRelationship = (PersonRelationship) lRelations
					.get(i);
			int lPersonID = lPersonRelationship.getRelatedPersonId();

			if (isMemberOrFamilyRequiredForProgram(lPersonRelationship,
					pBusinessProgramTO)) {
				lMember = personDAO.getMemberStatus(lPersonID,
						pBusinessProgramTO.getProgramID(), pCalledFromWebPortal);

				Contract lContract = null;

				lContract = personDAO.getMemberContractStatus(lPersonID,
						pBusinessProgramTO.getProgramID(), lPersonRelationship
								.getRelationshipCode(), lPersonRelationship
								.getContractNumber(), pCalledFromWebPortal);

				if (lMember != null && lContract != null) {
					lMember.setMemberContract(lContract);

					lMemberActivities = (ArrayList<MemberActivity>) activityDAO
							.getMemberActivities(lPersonID, pBusinessProgramTO
									.getProgramID(), pCalledFromWebPortal);

					// Retrieve the recommended activities for the member.
					// If there are any append them to the list of member
					// activities.					
					// TODO Remove this.
					/*
					ArrayList<MemberActivity> lRecommendedActivities = getRecommendedActivities(pPersonID, pBusinessProgramTO
							, lMemberActivities, lMember);
					if (lRecommendedActivities != null && lRecommendedActivities.size() > 0) 
					{														
							lMemberActivities.addAll(lRecommendedActivities);
					}
                    */
					
					ArrayList<MemberActivity> lFilteredOutActivities = (ArrayList<MemberActivity>) getFilteredOutActivities(
							lPersonID, pBusinessProgramTO.getProgramID(), pCalledFromWebPortal);
					
					lMemberActivities.addAll(lFilteredOutActivities);

					ArrayList<EligibleActivity> lEligibleActivities = (ArrayList<EligibleActivity>) getEligibleActivities(pBusinessProgramTO
							.getProgramID());

					EligibleActivity[] lEligibleActivityArray = new EligibleActivity[lEligibleActivities
							.size()];
					lEligibleActivities.toArray(lEligibleActivityArray);
					lMember.setEligibleActivities(lEligibleActivityArray);

					MemberActivity[] lMemberActivityArray = new MemberActivity[lMemberActivities
							.size()];
					lMemberActivities.toArray(lMemberActivityArray);
					lMember.setMemberActivities(lMemberActivityArray);

					lMember
							.setRelationshipToContractHolder(((PersonRelationship) lRelations
									.get(i)).getRelationshipType());

					lMembers.add(lMember);
				}
			}
		}

		return lMembers;
	}
	
	public String getMemberNoUsingMODS(String lExternalPersonID) throws Exception, DataAccessException {
		String memberNo = personDAO.getMemberNoUsingMODS(lExternalPersonID);
		
		return memberNo;
	}
	
	/**
	 * Determine whether or not to retrieve a list of Recommended Activities based on the
	 * Health Assessment having been taken, Hold, Exempt, or Qualified status.
	 * 
	 * 2008 Healthy Benefits - Deprecated on 5/5/2015
	 * 
	 * @deprecated
	 * @param pPersonID
	 * @param pBusinessProgramTO
	 * @param pMemberActivities
	 * @param pMember
	 * @return
	 */
	protected ArrayList<MemberActivity> getRecommendedActivities(Integer pPersonID, BusinessProgramTO pBusinessProgramTO
			, ArrayList<MemberActivity> pMemberActivities, Member pMember)
	{
		ArrayList<MemberActivity> lRecommendedActivities = null;
		
		boolean lHasTakenHA = false;
		boolean lOtherActivities = false;
		boolean lGetRecommendedActivities = false;
		
		boolean lTooLateForDM = tooLateForDiseaseManagement(pBusinessProgramTO);		
		boolean lTooLateForPhone = tooLateForPhone(pBusinessProgramTO);
		
		for(int j = 0; j < pMemberActivities.size(); j++)
		{
			MemberActivity lMemberActivity = (MemberActivity)pMemberActivities.get(j);
			if(BPMConstants.ACTIVITY_HEALTHY_BENEFITS_HA_ID.equals(lMemberActivity.getActivity().getSourceActivityID()))
			{
				lHasTakenHA = true;
				break;
			}
		}
		
		if (lHasTakenHA == true) 
		{
			// If the Health Assessment has been taken but the member is on Hold,
			// Do not retrieve Recommended Activities.
			if (BPMConstants.MEMBER_STATUS_HOLD_FOR_CONTACT.equalsIgnoreCase(pMember.getMemberStatus()
							.getStatus().getStatusCodeValue())
				|| BPMConstants.MEMBER_STATUS_EXEMPT_HOLD.equalsIgnoreCase(pMember.getMemberStatus()
						.getStatus().getStatusCodeValue()))
			{
				// If it's too late to take a Phone course
				// display the Recommended Online Activities.				
				if(lTooLateForPhone)
				{
				    lGetRecommendedActivities = true;
				}
				else
				{
					// Not too late for Phone courses.
					// Set the member status to HOLD_FOR_PHONE to signal the web to display the 
					// Phone courses.
					//pMember.getMemberStatus().getStatus().setStatusCodeValue(BPMConstants.MEMBER_STATUS_HOLD_FOR_PHONE);
					//pMember.getMemberStatus().getStatus().setStatusCodeDesc(BPMConstants.MEMBER_STATUS_HOLD_FOR_PHONE);
					lGetRecommendedActivities = false;
				}				
			}			
			else
			{
				lGetRecommendedActivities = true;
				// Are there any other Active non-DM activities ? If yes, do not get Recommended.				  
				for(int j = 0; j < pMemberActivities.size(); j++)
				{					
					MemberActivity lMemberActivity = (MemberActivity)pMemberActivities.get(j);
					
					// If there is at least one non-Disease-Management activity, do not get Recommended. 
					if(BPMConstants.ACTIVITY_STATUS_ACTIVE.equals(lMemberActivity.getActivityStatus().getStatusCodeValue())
				    && !BPMConstants.ACTIVITY_TYPE_DISEASE_MGMT.equalsIgnoreCase(lMemberActivity.getActivity().getActivityTypeValue()))
					{
						lGetRecommendedActivities = false;
						lOtherActivities = true;
						break;
					}
					// If there is at least one Complete Activity (and is not Health Assessment) do not get Recommended.
					if(BPMConstants.ACTIVITY_STATUS_COMPLETE.equals(lMemberActivity.getActivityStatus().getStatusCodeValue())
					&& !BPMConstants.ACTIVITY_HEALTHY_BENEFITS_HA_ID.equals(lMemberActivity.getActivity().getSourceActivityID())
					)
					{
						lGetRecommendedActivities = false;
						lOtherActivities = true;
						break;
					}
				}
			}
		} 
		
		// Once the member has Qualified no need for Recommended Activities.
		if (BPMConstants.MEMBER_STATUS_QUALIFIED.equalsIgnoreCase(pMember.getMemberStatus()
						.getStatus().getStatusCodeValue()) 
			|| BPMConstants.MEMBER_STATUS_EXEMPT_QUALIFIED.equalsIgnoreCase(pMember.getMemberStatus()
					.getStatus().getStatusCodeValue()))
		{
			lGetRecommendedActivities = false;
		}
		
		if (BPMConstants.MEMBER_STATUS_EXEMPT.equalsIgnoreCase(pMember.getMemberStatus().getStatus().getStatusCodeValue())
			|| BPMConstants.MEMBER_STATUS_EXEMPT_HA_COMPLETED.equalsIgnoreCase(pMember.getMemberStatus().getStatus().getStatusCodeValue())) 
		{
			// For exempts, only show recommended activities if only
			// HA has been taken.
			// Once other activities are taken, no recommended
			// activities.
			if (lHasTakenHA == true && lOtherActivities == false) 
			{
			    lGetRecommendedActivities = true;
			}
		}
		
		if(lGetRecommendedActivities == true)
		{
			lRecommendedActivities = (ArrayList<MemberActivity>)  
			    getRecommendedActivities(pPersonID, pBusinessProgramTO.getProgramID());
		}
		
		return lRecommendedActivities;
	}
	
	/**
	 * If the current date + minimum duration for a DM activity would be past the Qual End date,
	 * but current date + minimum for an online activity is still within the Qual window, it's too late for
	 * a DM. But not too late for an online course.
	 * 	 
	 * @param pBusinessProgramTO
	 * @return
	 */	
	public boolean tooLateForDiseaseManagement(BusinessProgramTO pBusinessProgramTO)
	{
		boolean lTooLateForDiseaseManagement = false;
					
		Integer lMinimumDMDuration = activityDAO.getMinimumDMDuration();
				
		Calendar lCurrentDatePlusDM = Calendar.getInstance();
		
		try
		{			
			lCurrentDatePlusDM = qualificationTimeService.getCurrentDate();
		}
		catch(Exception e)
		{
			logger.error(e);
		}
			
		lCurrentDatePlusDM.add(Calendar.DAY_OF_MONTH, lMinimumDMDuration);
		
		// Set the times to 0, so that only the dates are compared.
		BPMUtils.setTimeToZero(pBusinessProgramTO.getBusinessProgram().getQualificationWindowEndDate());
		BPMUtils.setTimeToZero(lCurrentDatePlusDM);
				
		// If the current date + minimum duration for a DM activity would be past the Qual End date,
		// but current date + minimum for an online activity is still within the Qual window, it's too late for
		// a DM. But not too late for an online course.
		if((lCurrentDatePlusDM.after(pBusinessProgramTO.getBusinessProgram().getQualificationWindowEndDate())
				|| lCurrentDatePlusDM.compareTo(pBusinessProgramTO.getBusinessProgram().getQualificationWindowEndDate()) == 0)
		  )
		{
			lTooLateForDiseaseManagement = true;
		}				
		
		return lTooLateForDiseaseManagement;
	}
	
	/**
	 * If the current date + minimum duration for a Phone Course would be past the Qual End date,
	 * it's too late for a Phone Course. 
	 * 	 
	 * @param pBusinessProgramTO
	 * @return
	 */	
	public boolean tooLateForPhone(BusinessProgramTO pBusinessProgramTO)
	{
		boolean lTooLateForPhone = false;
		
		Integer lMinimumPhoneDuration = activityDAO.getMinimumPhoneDuration();
				
		Calendar lCurrentDatePlusPhone = Calendar.getInstance();
		
		try
		{			
			lCurrentDatePlusPhone = qualificationTimeService.getCurrentDate();
		}
		catch(Exception e)
		{
			logger.error(e);
		}
			
		lCurrentDatePlusPhone.add(Calendar.DAY_OF_MONTH, lMinimumPhoneDuration);
		
        // Set the times to 0, so that only the dates are compared.
		BPMUtils.setTimeToZero(lCurrentDatePlusPhone);
		BPMUtils.setTimeToZero(pBusinessProgramTO.getBusinessProgram().getQualificationWindowEndDate());			
		
		// If the current date + minimum duration for a Phone activity would be past the Qual End date,
		// but current date + minimum for an online activity is still within the Qual window, it's too late for
		// a Phone. But not too late for an online course.
		if((lCurrentDatePlusPhone.after(pBusinessProgramTO.getBusinessProgram().getQualificationWindowEndDate())
		 || lCurrentDatePlusPhone.compareTo(pBusinessProgramTO.getBusinessProgram().getQualificationWindowEndDate()) == 0)
		  )
		{
			lTooLateForPhone = true;
		}
		
		return lTooLateForPhone;
	}

	/**
	 * Compares the relationship type of the Person to the relationship
	 * requirement of the Business Program.
	 * 
	 * @param pPersonRelationship
	 * @param pBusinessProgramTO
	 * @return
	 */
	protected boolean isMemberOrFamilyRequiredForProgram(
			PersonRelationship pPersonRelationship,
			BusinessProgramTO pBusinessProgramTO) {
		boolean lIsMemberRequiredForProgram = false;

		logger.debug("Person ID = "
				+ pPersonRelationship.getRelatedPersonId()
				+ ", Fam Part Req = "
				+ pBusinessProgramTO.getBusinessProgram()
						.getFamilyParticipationValue() + ", Rel Type = "
				+ pPersonRelationship.getRelationshipType());

		if (pBusinessProgramTO.getBusinessProgram().getContractNumber()
				.intValue() != pPersonRelationship.getContractNumber()
				.intValue()) {
			logger.debug("Biz Contract Number = "
					+ pBusinessProgramTO.getBusinessProgram()
							.getContractNumber() + ", Rel Contract Number = "
					+ pPersonRelationship.getContractNumber());
			return false;
		}
			
		if (BPMConstants.BPM_PARTICIP_REQ_ALL_18_PLUS.equalsIgnoreCase(pBusinessProgramTO.getBusinessProgram()
						.getFamilyParticipationValue())
           || BPMConstants.BPM_PARTICIP_REQ_PH_18_OPTIONAL.equalsIgnoreCase(pBusinessProgramTO.getBusinessProgram().getFamilyParticipationValue())						
						)
		{			
			return true;
		}

		if (BPMConstants.RELATIONSHIP_TYPE_SELF
				.equalsIgnoreCase(pPersonRelationship.getRelationshipType())) {
			if (BPMConstants.BPM_PARTICIP_REQ_PH_ONLY.equalsIgnoreCase(pBusinessProgramTO.getBusinessProgram().getFamilyParticipationValue())
					|| BPMConstants.BPM_PARTICIP_REQ_PH_AND_SPOUSE_OR_DOM.equalsIgnoreCase(pBusinessProgramTO.getBusinessProgram().getFamilyParticipationValue())
					|| BPMConstants.BPM_PARTICIP_REQ_PH_AND_SPOUSE.equalsIgnoreCase(pBusinessProgramTO.getBusinessProgram().getFamilyParticipationValue())
					|| BPMConstants.BPM_PARTICIP_REQ_PH_SPOUSE_OPTIONAL.equalsIgnoreCase(pBusinessProgramTO.getBusinessProgram().getFamilyParticipationValue())
					|| BPMConstants.BPM_PARTICIP_REQ_PH_18_OPTIONAL.equalsIgnoreCase(pBusinessProgramTO.getBusinessProgram().getFamilyParticipationValue())
					|| BPMConstants.BPM_PARTICIP_REQ_PH_SPOUSE_DOM_OPTIONAL.equalsIgnoreCase(pBusinessProgramTO.getBusinessProgram().getFamilyParticipationValue())
					|| BPMConstants.BPM_PARTICIP_REQ_PH_AND_SPOUSE_18_OPT.equalsIgnoreCase(pBusinessProgramTO.getBusinessProgram().getFamilyParticipationValue())
					|| BPMConstants.BPM_PARTICIP_REQ_PH_AND_SPOUSE_DOM_18_OPT.equalsIgnoreCase(pBusinessProgramTO.getBusinessProgram().getFamilyParticipationValue()))
			{
				lIsMemberRequiredForProgram = true;
			}
		}

		if (BPMConstants.RELATIONSHIP_TYPE_SPOUSE
				.equalsIgnoreCase(pPersonRelationship.getRelationshipType())) {
			if (BPMConstants.BPM_PARTICIP_REQ_PH_AND_SPOUSE_OR_DOM.equalsIgnoreCase(pBusinessProgramTO.getBusinessProgram().getFamilyParticipationValue())
					|| BPMConstants.BPM_PARTICIP_REQ_PH_AND_SPOUSE.equalsIgnoreCase(pBusinessProgramTO.getBusinessProgram().getFamilyParticipationValue())
					|| BPMConstants.BPM_PARTICIP_REQ_PH_SPOUSE_OPTIONAL.equalsIgnoreCase(pBusinessProgramTO.getBusinessProgram().getFamilyParticipationValue())
					|| BPMConstants.BPM_PARTICIP_REQ_PH_SPOUSE_DOM_OPTIONAL.equalsIgnoreCase(pBusinessProgramTO.getBusinessProgram().getFamilyParticipationValue())
					|| BPMConstants.BPM_PARTICIP_REQ_PH_AND_SPOUSE_18_OPT.equalsIgnoreCase(pBusinessProgramTO.getBusinessProgram().getFamilyParticipationValue())
					|| BPMConstants.BPM_PARTICIP_REQ_PH_AND_SPOUSE_DOM_18_OPT.equalsIgnoreCase(pBusinessProgramTO.getBusinessProgram().getFamilyParticipationValue())
					) {
				lIsMemberRequiredForProgram = true;
			}
		}

		if (BPMConstants.RELATIONSHIP_TYPE_DOMESTIC_PARTNER.equalsIgnoreCase(pPersonRelationship.getRelationshipType())) {
			if (BPMConstants.BPM_PARTICIP_REQ_PH_AND_SPOUSE_OR_DOM.equalsIgnoreCase(pBusinessProgramTO.getBusinessProgram().getFamilyParticipationValue())
					|| BPMConstants.BPM_PARTICIP_REQ_PH_SPOUSE_DOM_OPTIONAL.equalsIgnoreCase(pBusinessProgramTO.getBusinessProgram().getFamilyParticipationValue())	
					|| BPMConstants.BPM_PARTICIP_REQ_PH_AND_SPOUSE_DOM_18_OPT.equalsIgnoreCase(pBusinessProgramTO.getBusinessProgram().getFamilyParticipationValue())
					) {
				lIsMemberRequiredForProgram = true;
			}
		}

		return lIsMemberRequiredForProgram;
	}

	/**
	 * Called by the web service to determine if the given member is part of
	 * Healthy Benefits. If the target benefit year is provided, the service
	 * will determine if member is participating that year. If target benefit
	 * year is ALL, the service will determine if member is or has participated
	 * in any year.
	 * 
	 * @param pWebServiceRequest
	 */
	public BPMRequiredParticipantResponse isRequiredParticipant(WebServiceRequest pWebServiceRequest) 
	{
		Calendar lCurrentDate = Calendar.getInstance();
		BPMRequiredParticipantResponse lBPMRequiredParticpantResponse = new BPMRequiredParticipantResponse();
		ArrayList<RequiredParticipant> lRequiredParticipantsResponse = new ArrayList<RequiredParticipant>();
		lBPMRequiredParticpantResponse.setRequiredParticipants(lRequiredParticipantsResponse);
		
		try
		{
			if(BPMConstants.BPM_SOURCE_SYSTEM_DEMO.equals(pWebServiceRequest.getSourceSystemID()))
			{
				// If called from the Deme Site use the DemoSiteService.
				return demoSiteService.isRequiredParticipant(pWebServiceRequest);
			}
			
			// Get the current date from the qualification time service. This will allow setting the
			// date to future dates when testing.
			lCurrentDate = qualificationTimeService.getCurrentDate();
		
		    // Get a list of all the participants. The DAO returns the member and relatives.
		    ArrayList<RequiredParticipant> lRequiredParticipants = (ArrayList<RequiredParticipant>) personDAO
				.getParticipant(pWebServiceRequest.getMemberID(), pWebServiceRequest.getTargetQualificationYear(), lCurrentDate);
							
			// If the member ID matches the member ID that was passed in, add it to the 
	        // RequiredParticipantResponse. 
			if (lRequiredParticipants != null && lRequiredParticipants.size() > 0) 
			{
				for(int i = 0; i < lRequiredParticipants.size(); i++)
				{				
					if(lRequiredParticipants.get(i).getMemberID().equals(pWebServiceRequest.getMemberID()))
					{
						lRequiredParticipants.get(i).setParticipant(true);				    
						lRequiredParticipants.get(i).setQualificationYear(String.valueOf(lRequiredParticipants.get(i).getCurrentBusinessProgramEffectiveDate().get(Calendar.YEAR)));
						
						// Is HA Available for this member ID
						// Get all the Business Programs for this member.
						ArrayList<BusinessProgramTO> lBusinessProgramTOs = (ArrayList<BusinessProgramTO>)  
					        getBusinessPrograms(pWebServiceRequest.getMemberID());
						
						for(int j = 0; j < lBusinessProgramTOs.size(); j++)
						{
							BusinessProgramTO lBusinessProgramTO = (BusinessProgramTO)lBusinessProgramTOs.get(j);
											
							ArrayList<Integer> lProgramIDs = (ArrayList<Integer>) businessProgramDAO
										.getHAAvailable(
												lBusinessProgramTO.getProgramID(),
												pWebServiceRequest.getTargetQualificationYear(),
												qualificationTimeService.getCurrentDate());
							
							if (lProgramIDs.size() > 0 && lProgramIDs.get(0) != null) 
							{
								Integer lProgramID = (Integer) lProgramIDs.get(0);
								
								if (lProgramID != null && lProgramID.intValue() > 0 
										&& lProgramID.intValue() == lRequiredParticipants.get(i).getProgramID().intValue()) 
								{
									lRequiredParticipants.get(i).setHaAvailable(true);
								}
								else
								{
									lRequiredParticipants.get(i).setHaAvailable(false);							
								}
							}
						}
						
						// Add the RequiredParticipant object to the Response ArrayList.
					    lRequiredParticipantsResponse.add(lRequiredParticipants.get(i));
					}				
				}
			}
		}
		catch(Exception e)
		{
			logger.error(e);
		}
		
		return lBPMRequiredParticpantResponse;
	}

	public boolean isRequiredParticipant(String memberID,
			int targetQualificationYear, Calendar pCurrentDate) {
		ArrayList<Member> lMembers = (ArrayList<Member>) personDAO
				.getParticipatingMember(memberID, String
						.valueOf(targetQualificationYear), pCurrentDate);

		if (lMembers != null && lMembers.size() > 0) {
			return true;
		} else {
			return false;
		}
	}
	/*
	* This method addresses an issue where member experiences a package change at the beginning or middle of a program year.  See EV109752.
	*/ 
	
	public boolean isRequiredParticipantRetroactive(String memberID,
			int targetQualificationYear, Calendar activityStatusDate) {
		ArrayList<Member> lMembers = (ArrayList<Member>) personDAO
				.getParticipatingMemberRetroactive(memberID, String
						.valueOf(targetQualificationYear), activityStatusDate);

		if (lMembers != null && lMembers.size() > 0) {
			return true;
		} else {
			return false;
		}
	}
	
	
	/**
	 * Called by the web service. Indicates whether the Healthy Benefits HA is
	 * currently (as of date of service call) available for this member. This
	 * will be True if todays date is on or after the start date of the HA
	 * Completion Window and on or before the end date of the Qualification
	 * Window.
	 * 
	 */
	public BPMRequiredParticipantResponse isHAAvailable(WebServiceRequest pWebServiceRequest) 
	{
		BPMRequiredParticipantResponse lBPMRequiredParticipantResponse = isRequiredParticipant(pWebServiceRequest);
		//lBPMRequiredParticipantResponse.setHaAvailable(false);
		
		try 
		{
			ArrayList<BusinessProgramTO> lBusinessProgramTOs = (ArrayList<BusinessProgramTO>)  
			    getBusinessPrograms(pWebServiceRequest.getMemberID());
			
			for(int i = 0; i < lBusinessProgramTOs.size(); i++)
			{
				BusinessProgramTO lBusinessProgramTO = (BusinessProgramTO)lBusinessProgramTOs.get(i);
								
				ArrayList<Integer> lProgramIDs = (ArrayList<Integer>) businessProgramDAO
							.getHAAvailable(
									lBusinessProgramTO.getProgramID(),
									pWebServiceRequest.getTargetQualificationYear(),
									qualificationTimeService.getCurrentDate());
	
				if (lProgramIDs.size() > 0 && lProgramIDs.get(0) != null) 
				{
					Integer lProgramID = (Integer) lProgramIDs.get(0);
					
					for(int j = 0; j < lBPMRequiredParticipantResponse.getRequiredParticipants().size(); j++)
					{
						if (lProgramID != null && lProgramID.intValue() > 0 
								&& lProgramID.intValue() == lBPMRequiredParticipantResponse.getRequiredParticipants().get(j).getProgramID().intValue()) 
						{
							lBPMRequiredParticipantResponse.getRequiredParticipants().get(j).setHaAvailable(true);
						}
						else
						{
							lBPMRequiredParticipantResponse.getRequiredParticipants().get(j).setHaAvailable(false);							
						}
					}
				}				
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e);
		}
		return lBPMRequiredParticipantResponse;
	}

	protected Collection<MemberActivity> getRecommendedActivities(
			Integer pPersonID, Integer pProgramID) {
		return activityDAO.getRecommendedActivities(pPersonID, pProgramID);
	}

	protected Collection<EligibleActivity> getEligibleActivities(
			Integer pProgramID) {
		return activityDAO.getEligibleActivities(pProgramID);
	}
	
	protected Collection<MemberActivity> getFilteredOutActivities(Integer pPersonID,
			Integer pProgramID, boolean pCalledFromWebPortal) {
		return activityDAO.getFilteredOutActivities(pPersonID, pProgramID, pCalledFromWebPortal);
	}

	public Collection<MemberTO> getMembersForStatusCalculation(String memberID, BPMBusinessProgram pBusinessProgram)
			throws BPMException, DataAccessException {

		Integer personID = personDAO.getPersonID(memberID);
		if(personID == null || personID.intValue() <= 0)
		{
			return new ArrayList<MemberTO>();
		}
		
		return getMembersForStatusCalculation(personID, pBusinessProgram);
	}


	/**
	 * fetches member details of relatives inscluding self(self,dom,spouse)
	 */
	public Collection<MemberTO> getMembersForStatusCalculation(Integer personID, BPMBusinessProgram pBusinessProgram)
			throws BPMException, DataAccessException {

		Collection<MemberTO> meberTOs = new ArrayList<MemberTO>();

		// to add distinct person ids
		TreeSet<Integer> personIDs = new TreeSet<Integer>();

		// add this person
		personIDs.add(personID);
		
		

		// fetch related members
		Collection<PersonRelationship> lRelations = null;
		
		// EV 27989 - If the Family Participation includes spouse, or domestic partner, get the relations
		// to this person ID. Otherwise skip this step to improve performance.
		// BPM-45 - Need relationship for all business program calculation in order to identify
		//          dual coverage scenerios.  PH only make up less than 1 percent of all active business
		//          programs.
//		if(!BPMConstants.BPM_PARTICIP_REQ_PH_ONLY.equals(pBusinessProgram.getFamilyParticipationValue()))
//		{
			lRelations = personDAO.getPersonRelationship(personID, pBusinessProgram.getProgramID());
//		}

		//BPM 45 - block of code removed to allow lRelations to be used for passing
		//         in person id and relationship to getMemberDetails.  Discovered
		//         that relationship is needed as part of the member contract lookup
		//         when dual coverage is present.
//		if(lRelations != null)
//		{
//			// add distinct personIds
//			Iterator<PersonRelationship> itrRel = lRelations.iterator();
//			while (itrRel.hasNext()) {
//				PersonRelationship personRelationship = itrRel.next();
//				Integer lPersonID = personRelationship.getRelatedPersonId();
//				personIDs.add(lPersonID);
//			}
//		}
			

//		// get person details
//		Iterator<Integer> itr = personIDs.iterator();
//		while (itr.hasNext()) {
//			Integer lPersonID = itr.next();
//			MemberTO memberTO = getMemberDetails(lPersonID, pBusinessProgram);
//			meberTOs.add(memberTO);
//		}

		// get person details

		Iterator<PersonRelationship> itrRel = lRelations.iterator();

		Integer phPersonId = 0;
		while (itrRel.hasNext()) {
			PersonRelationship personRelationship = itrRel.next();
			if (personRelationship.getRelationshipCode().equals(BPMConstants.RELSHP_SELF)) {
				phPersonId = personRelationship.getId();
				break;
			}
		}

		itrRel = lRelations.iterator();

		while (itrRel.hasNext()) {
			PersonRelationship personRelationship = itrRel.next();
			MemberTO memberTO = getMemberDetails(personRelationship, pBusinessProgram);
			memberTO.setPHpersonID(phPersonId);
			meberTOs.add(memberTO);
		}

		return meberTOs;
	}
	


	public MemberTO getMemberDetails(PersonRelationship personRelationship, BPMBusinessProgram pBusinessProgram) throws BPMException,
			DataAccessException {

		MemberTO memberTO = new MemberTO();

		Integer personID = personRelationship.getRelatedPersonId();

		Integer relationshipCode = personRelationship.getRelationshipCode();


		memberTO.setPersonID(personID);



		//Note: personID is mislabeled.  It stores personDemographicsID.
		//Renaming here only to be used in the lookup of personID needed for
		//the lookup of person demographics (Person) data.
		Integer personDemographicsID = personID;
		Integer personIDTemp = personDAO.getPersonIDFromPersonDemographicsID(personDemographicsID);
		Person lPerson = personDAO.getPersonByPersonId(personIDTemp);

		memberTO.setDateOfBirth(BPMUtils.convertFromUtilDateToSQLDate(lPerson.getDateOfBirth()));

		// For Status calculation do not exclude inactives.
		boolean lExcludeInactives = false;

		// set collection of MemberContractProgramTO
		Collection<MemberContractProgramTO> memberContractProgramTOs = new ArrayList<MemberContractProgramTO>();
		
		// Retrieve members, their contracts, and program years.
		// Sending a null for program-year will retrieve all years.		
		
		Collection<MemberContractProgramTO> lMemberContractProgramTOs = null;
		
		memberTO.setProgramID(pBusinessProgram.getProgramID());
		
		//EV46192 - Retrieve member contract program status for persons with termed contracts only
		//if evaluate termed contract flag is set.
		if (pBusinessProgram.isEvaluateTermedContract()) {
						
			// Retrieve member, business programs from same year, and their termed contracts.
			// Sending a null for program year will retrieve all business program 
			// participant was enrolled in.				
			lMemberContractProgramTOs = contractDAO
						.getMemberContractProgramStatusTermed(personID, relationshipCode, pBusinessProgram.getEffectiveDate().get(Calendar.YEAR));
			if (lMemberContractProgramTOs.size() > 0) {
				memberTO.setMemberTermedContractPrograms(lMemberContractProgramTOs);
			}						
			
		} else {
			lMemberContractProgramTOs = contractDAO
					.getMemberContractProgramStatus(personID, relationshipCode, pBusinessProgram.getEffectiveDate().get(Calendar.YEAR));
		}								
		
		memberContractProgramTOs.addAll(lMemberContractProgramTOs);

		// activities, tasks per program
		Iterator<MemberContractProgramTO> itr = memberContractProgramTOs
				.iterator();
		while (itr.hasNext()) {

			MemberContractProgramTO memberContractProgramTO = itr.next();

			Integer businessProgramID = memberContractProgramTO
					.getBusinessProgramID();						

			// activities
			Collection<MemberActivity> memberActivities = activityDAO
					.getMemberActivities(personID, businessProgramID, lExcludeInactives);
			memberContractProgramTO.setMemberActivities(memberActivities);

			// tasks - 03-24-2015 - Removing unnecessary call to the DB.
			/*
			Collection<TaskEvent> memberTasks = taskEventLogDAO.getTaskEvents(
					personID, businessProgramID);
			memberContractProgramTO.setMemberTasks(memberTasks);
			*/									
		}

		memberTO.setMemberContractPrograms(memberContractProgramTOs);
				
		// EV 58085
		// Get all the member exemptions 
		//{
			memberTO.getMemberExemptions().addAll(qualificationOverrideDAO.getAllQualificationOverrides(personID));
		//}
		// EV 58085
				
		ArrayList<BusinessProgramTO> lBusinessProgramTOsSiteTransfer = (ArrayList<BusinessProgramTO>) businessProgramDAO
				.getBusinessProgramTOFromMemberTermedSite(personID,
						pBusinessProgram.getEffectiveDate().get(Calendar.YEAR), pBusinessProgram.getGroupNumber());
		
		Iterator<BusinessProgramTO> iter = lBusinessProgramTOsSiteTransfer.iterator();
		
		List<PersonProgramActivityIncentiveStatus> lPersonProgramActivityIncentiveStatuses = new ArrayList<PersonProgramActivityIncentiveStatus>();
		while (iter.hasNext()) {
			BusinessProgramTO lBusinessProgramTO = iter.next();
			PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus = personDAO.getPersonPgmActivityIncentives(lBusinessProgramTO.getProgramID(), personID);
			if (lPersonProgramActivityIncentiveStatus != null) {
				lPersonProgramActivityIncentiveStatuses.add(lPersonProgramActivityIncentiveStatus);
			}
		}
		
		memberTO.setActivityBasedIncentivesForTermedSite(lPersonProgramActivityIncentiveStatuses);

		//EV90008 - gather member based activities belonging to termed 
		lPersonProgramActivityIncentiveStatuses = new ArrayList<PersonProgramActivityIncentiveStatus>();
		iter = lBusinessProgramTOsSiteTransfer.iterator();
		while (iter.hasNext()) {
			BusinessProgramTO lBusinessProgramTO = iter.next();
			//EV101972
			if (String.valueOf(lBusinessProgramTO.getProgramID()) != null && lBusinessProgramTO.getProgramID() == pBusinessProgram.getProgramID()) {
			} else {
				lPersonProgramActivityIncentiveStatuses = this.getMemberPgmActivityIncentiveStatusesNDetail(lBusinessProgramTO.getProgramID(), personID);
				break;
			}
		}
		
		memberTO.setMemberBasedIncentivesForTermedSite(lPersonProgramActivityIncentiveStatuses);
		
		//EV90008 - gather contract based activities belonging to termed 
		lPersonProgramActivityIncentiveStatuses = new ArrayList<PersonProgramActivityIncentiveStatus>();
		iter = lBusinessProgramTOsSiteTransfer.iterator();
		while (iter.hasNext()) {
			BusinessProgramTO lBusinessProgramTO = iter.next();
			Collection<MemberUpdate> lMemberUpdates = contractDAO.getBPMMemberContracts(personID);
			for (MemberUpdate lMemberUpdate : lMemberUpdates) {
				if (lMemberUpdate.getBusinessProgramID().equals(lBusinessProgramTO.getProgramID())) {
					Integer contractNo = lMemberUpdate.getContractNumber();
					lPersonProgramActivityIncentiveStatuses = this.getContractPgmActivityIncentiveStatusNDetail(lBusinessProgramTO.getProgramID(), contractNo, null, null);
					break;
				}
			}
			if (lPersonProgramActivityIncentiveStatuses != null && lPersonProgramActivityIncentiveStatuses.size() > 0) {
				break;
			}
		}
		
		memberTO.setContractBasedIncentivesForTermedSite(lPersonProgramActivityIncentiveStatuses);
		
		if (memberTO.getMemberTermedContractPrograms() == null || memberTO.getMemberTermedContractPrograms().size() == 0) {
			//retrieve member with termed contracts if they exist within the same year.
			Collection<MemberContractProgramTO> 
			lMemberTermedContractProgramTOs = contractDAO.getMemberContractProgramStatusTermed(personID, relationshipCode, pBusinessProgram.getQualificationWindowStartDate().get(Calendar.YEAR));
			for (MemberContractProgramTO lMemberContractProgramTO : lMemberTermedContractProgramTOs) {
				Collection<MemberActivity> memberActivities = activityDAO
						.getMemberActivities(personID, pBusinessProgram.getProgramID(), lExcludeInactives);
				lMemberContractProgramTO.setMemberActivities(memberActivities);
				
			}
			memberTO.setMemberTermedContractPrograms(lMemberTermedContractProgramTOs);
		}
		
		return memberTO;
	}

	/**
	 * Method used for membership update (ETL)
	 * site transfers, program participation changes etc
	 * @return TreeSet<Integer> updated personIDs
	 */	
	public TreeSet<Integer> updateMembershipData(Integer lPersonID)
			throws BPMException, DataAccessException {

		ArrayList<MemberUpdate> insertMemberPrograms = new ArrayList<MemberUpdate>();
		ArrayList<MemberUpdate> updateMemberPrograms = new ArrayList<MemberUpdate>();
		ArrayList<MemberUpdate> deleteMemberPrograms = new ArrayList<MemberUpdate>();
		ArrayList<MemberUpdate> lMemberUpdateList = new ArrayList<MemberUpdate>();
		ArrayList<MemberUpdate> lParticipatingMembers = new ArrayList<MemberUpdate>();

		// holds unique person ids to return and re calculation
		TreeSet<Integer> personIDsForReCalculation = new TreeSet<Integer>();
		try 
		{			
			// 1. Find the member's existing programs and contracts in BPM, if any.
			ArrayList<MemberUpdate> lMemberUpdateListYear = (ArrayList<MemberUpdate>) contractDAO
					.getBPMMemberContracts(lPersonID);
			lMemberUpdateList.addAll(lMemberUpdateListYear);
			
			// 2. get updated participating info.
			ArrayList<MemberUpdate> lParticipatingMembersYear = (ArrayList<MemberUpdate>) personDAO
					.getParticipatingUpdatedMember(lPersonID);
			lParticipatingMembers.addAll(lParticipatingMembersYear);					
									
            // Check for any deletes			
			//logger.info("@MembershipUpdate-Checking Deletes for personID="
			//		+ lPersonID);
			for (int m = 0; m < lMemberUpdateList.size(); m++) {
				MemberUpdate lMemberUpdate = (MemberUpdate) lMemberUpdateList
						.get(m);
				boolean lFound = false;
				for (int n = 0; n < lParticipatingMembers.size(); n++) {
					MemberUpdate lParticipatingMemberUpdate = (MemberUpdate) lParticipatingMembers
							.get(n);
					if (lParticipatingMemberUpdate.getBusinessProgramID().intValue() == 
						             lMemberUpdate.getBusinessProgramID().intValue() &&
						lParticipatingMemberUpdate.getContractNumber().intValue() ==
							         lMemberUpdate.getContractNumber().intValue() &&
					    lParticipatingMemberUpdate.getRelationshipID().intValue() == 
					    		lMemberUpdate.getRelationshipID().intValue() &&
					    lParticipatingMemberUpdate.getProgramIncentiveOptionID().intValue() == 
					             lMemberUpdate.getProgramIncentiveOptionID().intValue())
					{
						lFound = true;
						break;
					}
				}

				if (!lFound) 
				{
					//logger.info("@MembershipUpdate-found Delete - programID=" + lMemberUpdate.getBusinessProgramID());
					deleteMemberPrograms.add(lMemberUpdate);
				}
			}
						            	

			// Check for updates and inserts
			//logger.info("@MembershipUpdate-Checking Updates/Inserts for personID=" + lPersonID);
			
			for (int j = 0; j < lParticipatingMembers.size(); j++) {
				MemberUpdate lParticipatingMemberUpdate = (MemberUpdate) lParticipatingMembers
						.get(j);
				boolean lFound = false;								
				
				// check from existing programs
				for (int k = 0; k < lMemberUpdateList.size(); k++) {															
					MemberUpdate lMemberUpdate = (MemberUpdate) lMemberUpdateList
							.get(k);					
					if (lParticipatingMemberUpdate.getBusinessProgramID().intValue() == 
								lMemberUpdate.getBusinessProgramID().intValue() &&
						lParticipatingMemberUpdate.getContractNumber().intValue() ==
						         lMemberUpdate.getContractNumber().intValue()  &&
						lParticipatingMemberUpdate.getRelationshipID().intValue() == 
						    	 lMemberUpdate.getRelationshipID().intValue()  &&
					    lParticipatingMemberUpdate.getProgramIncentiveOptionID().intValue() == 
					             lMemberUpdate.getProgramIncentiveOptionID().intValue()						    	 
					   )
					{						
						// mark for update person - program
						lFound = true;
						break;
					}
				}								
								
				
				if (lFound) {
					// update member program
					//logger.info("--- MembershipUpdate-found Update - programID="
					//		+ lParticipatingMemberUpdate.getPersonID() + ", " + lParticipatingMemberUpdate.getBusinessProgramID() + ", Rel=" + lParticipatingMemberUpdate.getRelationshipID());
					updateMemberPrograms.add(lParticipatingMemberUpdate);
				} else {
					// insert new program
					//logger.info("--- MembershipUpdate-found Insert - programID="
					//		+ lParticipatingMemberUpdate.getPersonID() + ", " +  lParticipatingMemberUpdate.getBusinessProgramID() + ", Rel=" + lParticipatingMemberUpdate.getRelationshipID());
					insertMemberPrograms.add(lParticipatingMemberUpdate);
				}
			}
			
            // Deletes
			
			for (int t = 0; t < deleteMemberPrograms.size(); t++) {
				MemberUpdate lDeleteMemberUpdate = (MemberUpdate) deleteMemberPrograms
						.get(t);
				// Keep Termed Member: DO NOT delete member program
				// Just update the participation-end-date
				endMemberParticipation(lDeleteMemberUpdate);
				logger
						.info("@MembershipUpdate-Ending Participation - person id= "
								+ lDeleteMemberUpdate.getPersonID()
								+ ", contract="
								+ lDeleteMemberUpdate.getContractNumber()
								+ ", program ID="
								+ lDeleteMemberUpdate.getBusinessProgramID());
				Collection<MemberUpdate> updates = contractDAO
						.getBPMMembersForProgramContract(lDeleteMemberUpdate
								.getContractNumber(), lDeleteMemberUpdate
								.getBusinessProgramID());
				Iterator<MemberUpdate> itr = updates.iterator();
				while (itr.hasNext()) {
					MemberUpdate updateMem = itr.next();
					personIDsForReCalculation.add(updateMem.getPersonID());
				}
			}
			
			
			// 1. inserts
			
			for (int p = 0; p < insertMemberPrograms.size(); p++) {
				boolean isInsertNew = true;
				MemberUpdate lInsertMemberUpdate = (MemberUpdate) insertMemberPrograms
						.get(p);
				// insert new program
				logger
						.info("@MembershipUpdate-Insert member program - member ID="
								+ lInsertMemberUpdate.getMemberID()
								+ ", personID="
								+ lPersonID
								+ ", program ID="
								+ lInsertMemberUpdate.getBusinessProgramID()
								+ ", contract ID ="
								+ lInsertMemberUpdate.getContractNumber());				
				
				updateMemberProgramDetails(lInsertMemberUpdate, isInsertNew);

				personIDsForReCalculation
						.add(lInsertMemberUpdate.getPersonID());
			}

			// 2. Updates			
			for (int r = 0; r < updateMemberPrograms.size(); r++) {
				boolean isInsertNew = false;
				MemberUpdate lUpdateMemberUpdate = (MemberUpdate) updateMemberPrograms
						.get(r);
				// update member program
				logger
						.info("@MembershipUpdate-Update member program - member ID="
								+ lUpdateMemberUpdate.getMemberID()
								+ ", personID="
								+ lPersonID
								+ ", program ID="
								+ lUpdateMemberUpdate.getBusinessProgramID()
								+ ", contract ID ="
								+ lUpdateMemberUpdate.getContractNumber());
				updateMemberProgramDetails(lUpdateMemberUpdate, isInsertNew);

				personIDsForReCalculation
						.add(lUpdateMemberUpdate.getPersonID());
			}			
			
		} catch (DataAccessException dae) {
			logger
					.error("An unexpected error has occured: "
							+ dae.getMessage(), dae);
			throw dae;
		} catch (Exception e) {
			logger.error("@@Exception in updateMembershipData(personID) ="
					+ e.getMessage());
			throw new BPMException(e);
		}
		finally
		{
			insertMemberPrograms.clear();
			updateMemberPrograms.clear();
			deleteMemberPrograms.clear();
			lMemberUpdateList.clear();
			lParticipatingMembers.clear();						
		}

		return personIDsForReCalculation;
	}
	
	
	/**
	 * Insert/update member status, contract status, transfer activities, exemptions
	 * @param lParticipatingMemberUpdate
	 * @param isInsertNew
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	private void updateMemberProgramDetails(
			MemberUpdate lParticipatingMemberUpdate, boolean isInsertNew)
			throws BPMException, DataAccessException {

		try 
		{
			// If the prod_tp_cd or codes, contain an M, this is a member.
			// If there is no M in this person's prod_tp_cd, this is a non-member.
			
			List<PersonProgramHealthPlan> lPersonProgramHealthPlans =
			    personDAO.getPersonHealthPlanCode(lParticipatingMemberUpdate.getPersonID()
			         , lParticipatingMemberUpdate.getBusinessProgramID()
			         , lParticipatingMemberUpdate.getContractNumber());
						
			Integer lQualificationCheckmarkID = 0;
			String lPersonHealthPlanCode = null;
			for(PersonProgramHealthPlan lPersonProgramHealthPlan : lPersonProgramHealthPlans)
			{				
			    if(BPMConstants.BPM_MEMBER_WITH_MEDICAL_PLAN.equals(lPersonProgramHealthPlan.getHealthPlanCode()))
			    {
			    	lPersonHealthPlanCode = BPMConstants.BPM_MEMBER_WITH_MEDICAL_PLAN;
			        break;
			    }
			}						
			
			if(lPersonHealthPlanCode == null || lPersonHealthPlanCode.length() < 1)
			{
				lPersonHealthPlanCode = BPMConstants.BPM_NON_MEMBER_WITHOUT_PLAN;
			}						
								
			// Participation end date is set to 1/1/9999 if the contract is still valid.
			personDAO.setContractParticipationEndDate(lParticipatingMemberUpdate.getPersonID(), lParticipatingMemberUpdate.getBusinessProgramID(), 
					lParticipatingMemberUpdate.getContractNumber(), BPMConstants.BPM_USER_SYSTEM);
			
			// Get the program-incentive-options for this programID.
			ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>) 
				    incentiveOptionDAO.getIncentiveOptions(lParticipatingMemberUpdate.getBusinessProgramID());
			
			boolean lParticipatesInThisIncentive = false;
															
			if (isInsertNew) 
			{	
				for(ProgramIncentiveOption lProgramIncentiveOption : lProgramIncentiveOptions)
				{					
					if(!personDAO.hasMemberProgramStatusRow(lParticipatingMemberUpdate.getPersonID(), lParticipatingMemberUpdate.getBusinessProgramID(), lParticipatingMemberUpdate.getRelationshipID(),
							lProgramIncentiveOption.getProgramIncentiveOptionID()))
					{												
						lProgramIncentiveOption.setParticipationGroup(participationGroupDAO.getParticipationGroup(lProgramIncentiveOption.getParticipationGroupID()));
						
						if(lProgramIncentiveOption.getParticipationGroup() != null)
						{
							lProgramIncentiveOption.getParticipationGroup().setParticipationGroupRequirements(
								    participationGroupDAO.getParticipationGroupRequirements(lProgramIncentiveOption.getParticipationGroupID()));
						}											
						
						// Determine member's participation in this incentive option.										
						lParticipatesInThisIncentive = determineParticipation(lProgramIncentiveOption.getParticipationGroup(), lParticipatingMemberUpdate.getRelationshipID(), lParticipatingMemberUpdate.getDateOfBirth());
												
						if(lParticipatesInThisIncentive == true)
						{
							// Insert into or update person_program_status
							try {
								personDAO.insertMemberProgramStatus(lParticipatingMemberUpdate.getPersonID()
										, lParticipatingMemberUpdate.getBusinessProgramID(),
										BPMConstants.MEMBER_STATUS_ELIGIBLE,
										lPersonHealthPlanCode
										, lParticipatingMemberUpdate.getRelationshipID()
										, "BPM_NIGHTLY"
										, null
										, lProgramIncentiveOption.getProgramIncentiveOptionID());
							} catch (DuplicateKeyException duplicateException) {
								logger.info("Duplicate key detected when trying to insert to person program status table.  Ignore.");
							} finally {
								logger.info("Continue processing after insertMemberProgramStatus.");
							}
							
							/*
							 * ---- EV 84878
							 * Insert a default Not-Achieved contract or member incentive for this program incentive option
							 * depending on what the type is.
							 */
							if(BPMConstants.BPM_INCENTED_STATUS_TYPE_CONTRACT_BASED.equals((lProgramIncentiveOption.getIncentedStatusTypeCode())))
							{
								ContractProgramIncentiveTO lContractProgramIncentiveTO = createContractProgramIncentive(lProgramIncentiveOption
										, lParticipatingMemberUpdate.getBusinessProgramID()
										, lParticipatingMemberUpdate.getContractNumber()
										, BPMConstants.PROGRAM_INCENTIVE_OPTION_ACTIVATION_NOT_ACTIVE);
							    incentiveOptionDAO.updateContractProgramIncentive(lContractProgramIncentiveTO);
							}
							
							if(BPMConstants.BPM_INCENTED_STATUS_TYPE_MEMBER_BASED.equals((lProgramIncentiveOption.getIncentedStatusTypeCode())))
							{							  
								MemberProgramIncentiveTO lMemberProgramIncentiveTO = createMemberIncentive(lProgramIncentiveOption
										, lParticipatingMemberUpdate.getPersonID()
										, lParticipatingMemberUpdate.getBusinessProgramID()
										, lParticipatingMemberUpdate.getContractNumber()
										, BPMConstants.PROGRAM_INCENTIVE_OPTION_ACTIVATION_NOT_ACTIVE);
							    incentiveOptionDAO.updateMemberProgramIncentive(lMemberProgramIncentiveTO);
							}
							
							// ---- EV 84878
						}						
					}					
					
					// EV 83578 - Only if the program-incentive-option is contract-based.
					// ------------------------------------------------------------------
					String lContractStatus = null;
					
					if(BPMConstants.BPM_INCENTED_STATUS_TYPE_CONTRACT_BASED.equals((lProgramIncentiveOption.getIncentedStatusTypeCode())))
					{		
						lContractStatus = BPMConstants.CONTRACT_STATUS_ELIGIBLE;
					}
					else
					{
						lContractStatus = BPMConstants.CONTRACT_STATUS_NONE;
					}
					
					boolean lContractProgramExists = 
							contractDAO.hasMemberContractStatusRow(lParticipatingMemberUpdate.getContractNumber(), lProgramIncentiveOption.getProgramIncentiveOptionID(), lParticipatingMemberUpdate.getBusinessProgramID());
					if(lContractProgramExists == false)
					{					
					// Insert into or update contract_program_status
						contractDAO.insertMemberContractStatus(lParticipatingMemberUpdate.getProgramIncentiveOptionID()
								, lParticipatingMemberUpdate.getBusinessProgramID()
								, lParticipatingMemberUpdate.getContractNumber()
								, lContractStatus, "BPM_NIGHTLY");
					}
					// EV 83578
				}												
				
				
				//Check for new Journeywell program type and if a site transfer has taken place.  If not, no activities are to be transferred
				//to the new group.  Update: As part of story BPM-6, include all program types for site transfer consideration.  DM activities no longer
				//used since 2011.
				BPMBusinessProgram  businessProgramDetail = businessProgramDAO.getBusinessProgramDetail(lParticipatingMemberUpdate.getBusinessProgramID());
//				if(BPMConstants.PROGRAM_TYPE_CODE_NEW_JOURNEYWELL.equals(businessProgramDetail.getProgramTypeCodeID())
//						|| BPMConstants.PROGRAM_TYPE_CODE_JOURNEYWELL_4.equals(businessProgramDetail.getProgramTypeCodeID())
//						|| BPMConstants.PROGRAM_TYPE_CODE_OCTAVIUS.equals(businessProgramDetail.getProgramTypeCodeID())
//						)
//				{
				boolean siteTransfer = isSiteTransfer(lParticipatingMemberUpdate.getPersonID(), lParticipatingMemberUpdate.getContractNumber(), businessProgramDetail);

				if (siteTransfer) {
					 // update member Activities
					updateMemberTransferActvitiesForNewJourneywell(lParticipatingMemberUpdate, businessProgramDetail);
				}
					/*
					 * 
					copyPrevYearsActiveDMActivities(lParticipatingMemberUpdate.getBusinessProgramID(), lParticipatingMemberUpdate.getPersonID());
					*/
					
				// update manual exemptions
				updateMemberTransferGroupManualExemptions(lParticipatingMemberUpdate);
			
//				} else {
//					//perform member activity transfer for non new Journeywell program types.
//	                // update member Activities
//				    updateMemberTransferActvities(lParticipatingMemberUpdate);
//	                // update manual exemptions
//					updateMemberTransferGroupManualExemptions(lParticipatingMemberUpdate);
//				}
			}
			else  // If not isInsertNew - (update existing record)
			{
			    personDAO.updatePersonHealthPlanCode(lParticipatingMemberUpdate.getPersonID()
			    		, lParticipatingMemberUpdate.getBusinessProgramID()
			    		, lParticipatingMemberUpdate.getProgramIncentiveOptionID()
			    		, lParticipatingMemberUpdate.getRelationshipID()
			    		, lPersonHealthPlanCode);
			    
			    if(hasContractEnded(lParticipatingMemberUpdate.getPersonID(), lParticipatingMemberUpdate.getBusinessProgramID(), lParticipatingMemberUpdate.getContractNumber())
			    		|| hasSubgroupEnded(lParticipatingMemberUpdate.getPersonID(), lParticipatingMemberUpdate.getBusinessProgramID(), lParticipatingMemberUpdate.getContractNumber())
			    		|| hasPackageEnded(lParticipatingMemberUpdate.getPersonID(), lParticipatingMemberUpdate.getBusinessProgramID(), lParticipatingMemberUpdate.getContractNumber()))
			    {			   
			        endMemberParticipation(lParticipatingMemberUpdate);
			    }
			    else
			    {
			    	// Otherwise update participation end date to 1/1/9999.
			    	personDAO.updateParticipationEndDate(lParticipatingMemberUpdate.getPersonID()
			    			, lParticipatingMemberUpdate.getBusinessProgramID()
			    			, BPMUtils.formatDateMMddyyyy(BPMConstants.BPM_FUTURE_DATE)
			    			, lParticipatingMemberUpdate.getRelationshipID()
			    			, BPMConstants.BPM_USER_SYSTEM);
			    }
			}

		} catch (DataAccessException dae) {
			logger.error("An unexpected error has occured: " + dae.getMessage(), dae);
			logger.error("Person DemogID = " + lParticipatingMemberUpdate.getPersonID() + ", Contract = " +
					lParticipatingMemberUpdate.getContractNumber() + ", Biz = " + lParticipatingMemberUpdate.getBusinessProgramID());
			throw dae;
		} catch (Exception e) {
			logger.error("Person DemogID = " + lParticipatingMemberUpdate.getPersonID() + ", Contract = " +
					lParticipatingMemberUpdate.getContractNumber() + ", Biz = " + lParticipatingMemberUpdate.getBusinessProgramID());
			throw new BPMException(e);
		}
	}

	/**
	 * deletes member fronm a program
	 * @param lMemberUpdate
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	private void deleteMemberProgramDetails(MemberUpdate lMemberUpdate)
			throws BPMException, DataAccessException {

		try {
			// delete from person_program_status
			personDAO.deleteMemberProgramStatus(lMemberUpdate.getPersonID(),
					lMemberUpdate.getBusinessProgramID());

			// delete from contract_program_status
			contractDAO.deleteMemberContractStatusByPersonID(lMemberUpdate
					.getPersonID(), lMemberUpdate.getContractNumber(),
					lMemberUpdate.getBusinessProgramID());
			// delete from person_program-activities
			activityDAO.deleteMemberActivities(lMemberUpdate.getPersonID(),
					lMemberUpdate.getBusinessProgramID());
			// delete existing program exemptions
			qualificationOverrideDAO.deleteAutomaticMemberExemptions(
					lMemberUpdate.getPersonID(), lMemberUpdate
							.getBusinessProgramID(), lMemberUpdate.getContractNumber());

		} catch (DataAccessException dae) {
			logger
					.error("An unexpected error has occured: "
							+ dae.getMessage(), dae);
			throw dae;
		} catch (Exception e) {
			throw new BPMException(e);
		}
	}
	
	/*
	 * EV 93292
	 * Tollgate rules that force contract status and member status to error recycle:
	 * When status'es go from,
	 * 1.  Qualified to Eligible
	 * 2.  Did Not Qualify to Eligible
	 * 3.  Qualified to Did Not Qualify
	 * 4.  Eligible after Qualification period
	 * HCEREWARD-252 - commented out because it was never used.
	 */
//	public void updateMemberContractRecyclePerTollgateRules(Collection<MemberProgramUpdateTO> generatedMemberProgramStatuses, Collection<MemberProgramUpdateTO> generatedMemberContractStatuses) throws BPMException {
//		if (generatedMemberProgramStatuses != null) {
//			for (MemberProgramUpdateTO generatedMemberProgramStatus : generatedMemberProgramStatuses) {
//				Integer pPersonDemographicsID = generatedMemberProgramStatus.getPersonID();
//				Integer pContractNumber = generatedMemberProgramStatus.getContractNumber();
//				Integer pProgramId = generatedMemberProgramStatus.getProgramID();
//				Integer pProgramIncentiveOptionID = generatedMemberProgramStatus.getProgramIncentiveOptionID();
//				PersonContractHist personContractHist = personDAO.getPersonContractHistForPersonContractMax(pPersonDemographicsID, pContractNumber, pProgramId, pProgramIncentiveOptionID);
//				if (personContractHist != null) {
//					String currentStatusValue = generatedMemberProgramStatus.getStatusCodeValue();
//					String previousStatusValue = personContractHist.getMemberStatus();
//					String tollgateRuleDesc = evaluateAgainstTollgateRules(currentStatusValue, previousStatusValue);
//					PersonContractRecycle personProgramRecycle = personDAO.getPersonContractRecycleForPersonContract(pContractNumber, pPersonDemographicsID, pProgramId, pProgramIncentiveOptionID);
//					if (tollgateRuleDesc != null) {
//						if (personProgramRecycle == null) {
//							personProgramRecycle = buildPersonContractRecycle(generatedMemberProgramStatus, personContractHist, tollgateRuleDesc, false);
//							personDAO.updatePersonContractRecycleStatusPerTollgateRules(personProgramRecycle);
//						}
//					} else {
//						if (personProgramRecycle != null && personProgramRecycle.getRecycleStatus().equals(BPMConstants.PERSON_CONTRACT_RECYCLE_STATUS_ACTION_NEEDED)) {
//							Integer luvID = lookUpValuesRecycleStatusHM.get(BPMConstants.PERSON_CONTRACT_RECYCLE_STATUS_ACTION_TAKEN);
//							personProgramRecycle.setRecycleStatusId(luvID);
//							personProgramRecycle.setReasonDesc(BPMConstants.PERSON_CONTRACT_HIST_ACTION_TAKEN_REASON);
//							personDAO.updatePersonContractRecycleStatusPerTollgateRules(personProgramRecycle);
//						}
//					}
//				}
//			}
//		}
//
//		if (generatedMemberContractStatuses != null) {
//			for (MemberProgramUpdateTO generatedMemberContractStatus : generatedMemberContractStatuses) {
//				Integer pPersonDemographicsID = generatedMemberContractStatus.getPersonID();
//				Integer pContractNumber = generatedMemberContractStatus.getContractNumber();
//				Integer pProgramId = generatedMemberContractStatus.getProgramID();
//				Integer pProgramIncentiveOptionID = generatedMemberContractStatus.getProgramIncentiveOptionID();
//				PersonContractHist personContractHist = personDAO.getPersonContractHistForPersonContractMax(pPersonDemographicsID, pContractNumber, pProgramId, pProgramIncentiveOptionID);
//				if (personContractHist != null) {
//					String currentStatusValue = generatedMemberContractStatus.getStatusCodeValue();
//					String previousStatusValue = personContractHist.getContractStatus();
//					String tollgateRuleDesc = evaluateAgainstTollgateRules(currentStatusValue, previousStatusValue);
//					if (tollgateRuleDesc != null) {
//						PersonContractRecycle personProgramRecycle = personDAO.getPersonContractRecycleForPersonContract(pContractNumber, pPersonDemographicsID, pProgramId, pProgramIncentiveOptionID);
//						if (personProgramRecycle == null) {
//							personProgramRecycle = buildPersonContractRecycle(generatedMemberContractStatus, personContractHist, tollgateRuleDesc, true);
//							personDAO.updatePersonContractRecycleStatusPerTollgateRules(personProgramRecycle);
//						}
//					} else {
//						PersonContractRecycle personProgramRecycle = personDAO.getPersonContractRecycleForPersonContract(pContractNumber, pPersonDemographicsID, pProgramId, pProgramIncentiveOptionID);
//						if (personProgramRecycle != null && personProgramRecycle.getRecycleStatus().equals(BPMConstants.PERSON_CONTRACT_RECYCLE_STATUS_ACTION_NEEDED)) {
//							Integer luvID = lookUpValuesRecycleStatusHM.get(BPMConstants.PERSON_CONTRACT_RECYCLE_STATUS_ACTION_TAKEN);
//							personProgramRecycle.setRecycleStatusId(luvID);
//							personProgramRecycle.setReasonDesc(BPMConstants.PERSON_CONTRACT_HIST_ACTION_TAKEN_REASON);
//							personDAO.updatePersonContractRecycleStatusPerTollgateRules(personProgramRecycle);
//						}
//					}
//				}
//			}
//		}
//
//	}
	/*
	   HCEREWARD-252 - Commented out.  No longer needed. Was never used.
	 */

//	private String evaluateAgainstTollgateRules(String currentStatusValue, String previousStatusValue) {
//		String tollgateRuleDesc = null;
//
//		if (isStatusChangeFromQualifiedToEligible(currentStatusValue, previousStatusValue)) {
//			tollgateRuleDesc = BPMConstants.PERSON_CONTRACT_HIST_RECYCLE_TOLLGATE_RULE_5;
//		if (isStatusChangeFromDidNotQualifyToEligible(currentStatusValue, previousStatusValue)) {
//					tollgateRuleDesc = BPMConstants.PERSON_CONTRACT_HIST_RECYCLE_TOLLGATE_RULE_6;
//		} else if (isStatusChangeFromQualifyToDidNotQualify(currentStatusValue, previousStatusValue)) {
//					tollgateRuleDesc = BPMConstants.PERSON_CONTRACT_HIST_RECYCLE_TOLLGATE_RULE_7;
//		}
//
//		return tollgateRuleDesc;
//	}
		
	/*
	 * Determine if status changed from Qualified to Eligible.
	 */
	private boolean isStatusChangeFromQualifiedToEligible(String currentStatusValue, String previousStatusValue) {
		
		boolean isEligible = false;
		
		
	   if (currentStatusValue!= null && !currentStatusValue.equals(previousStatusValue)) {	
		   if (currentStatusValue.equals(BPMConstants.MEMBER_STATUS_ELIGIBLE) && 
				   previousStatusValue.equals(BPMConstants.MEMBER_STATUS_QUALIFIED)) {
			   isEligible = true;
			}
	   }
	    
		return isEligible;
	}
	
	/*
	 * Determine if status changed from Did Not Qualify to Eligible.
	 */
	private boolean isStatusChangeFromDidNotQualifyToEligible(String currentStatusValue, String previousStatusValue) {
		
		boolean isEligible = false;
		
		
	   if (currentStatusValue != null && !currentStatusValue.equals(previousStatusValue)) {	
		   if (currentStatusValue.equals(BPMConstants.MEMBER_STATUS_ELIGIBLE) && 
				   previousStatusValue.equals(BPMConstants.MEMBER_STATUS_DID_NOT_QUALIFY)) {
			   isEligible = true;
			}
	   }
	    
		return isEligible;
	}
	
	/*
	 * Determine if status changed from Did Not Qualify to Eligible.
	 */
	private boolean isStatusChangeFromQualifyToDidNotQualify(String currentStatusValue, String previousStatusValue) {
		
		boolean isDidNotQualify = false;
		
		
	   if (currentStatusValue != null && !currentStatusValue.equals(previousStatusValue)) {	
		   if (currentStatusValue.equals(BPMConstants.MEMBER_STATUS_DID_NOT_QUALIFY) && 
				   previousStatusValue.equals(BPMConstants.MEMBER_STATUS_QUALIFIED)) {
			   isDidNotQualify = true;
			}
	   }
	    
		return isDidNotQualify;
	}	
	
	
	
	private void endMemberParticipation(MemberUpdate lMemberUpdate)
	throws BPMException, DataAccessException 
	{
	    try 
	    {
		    // Update participation end date.
		    personDAO.endMemberParticipation(lMemberUpdate.getPersonID(),
				lMemberUpdate.getBusinessProgramID(), BPMConstants.BPM_USER_SYSTEM);

		    // Update contract participation end date if the contract has ended.
		    personDAO.setContractParticipationEndDate(lMemberUpdate.getPersonID(), lMemberUpdate.getBusinessProgramID(), 
		    		lMemberUpdate.getContractNumber(), BPMConstants.BPM_USER_SYSTEM);
		    
		    // delete existing program exemptions
		    qualificationOverrideDAO.deleteAutomaticMemberExemptions(
				lMemberUpdate.getPersonID(), lMemberUpdate
						.getBusinessProgramID(), lMemberUpdate.getContractNumber());

	    } catch (DataAccessException dae) {
		    logger.error("An unexpected error has occured: "
						+ dae.getMessage(), dae);
		    throw dae;
	    } catch (Exception e) {
		    throw new BPMException(e);
        }
    }
	
	
	/**
	 * Copy current year activities and previous year DM activities to a member program
	 * @param pParticipatingMemberUpdate
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	protected void updateMemberTransferActvities(
			MemberUpdate pParticipatingMemberUpdate) throws BPMException,
			DataAccessException {

		Integer lNewBusinessProgramID = pParticipatingMemberUpdate
				.getBusinessProgramID();		
		Integer pPersonID = pParticipatingMemberUpdate.getPersonID();

		
		copyPrevYearsActiveDMActivities(lNewBusinessProgramID, pPersonID);

		// copy current year activities
		Collection<ActivityEvent> lCurrentActivities = activityDAO
				.getCurrentYearActivitiesForTransfer(pPersonID);

		Iterator<ActivityEvent> itr = lCurrentActivities.iterator();
		while (itr.hasNext()) {
			ActivityEvent activityEvent = itr.next();
			updatePersonProgramActivityStatus(activityEvent,
					lNewBusinessProgramID);
		}


		/*
		 * commented old code ArrayList<Integer> lNewBusinessProgramIDs =
		 * (ArrayList<Integer>) activityDAO
		 * .getNewBusinessPrograms(pParticipatingMemberUpdate .getPersonID());
		 * 
		 * ArrayList<MemberActivity> lMemberActivities = (ArrayList<MemberActivity>)
		 * activityDAO
		 * .getMemberActivities(pParticipatingMemberUpdate.getPersonID(),
		 * pParticipatingMemberUpdate.getBusinessProgramID());
		 * 
		 * for (int i = 0; i < lNewBusinessProgramIDs.size(); i++) { Integer
		 * lNewProgramID = (Integer) lNewBusinessProgramIDs.get(i);
		 * 
		 * for (int j = 0; j < lMemberActivities.size(); j++) { MemberActivity
		 * lMemberActivity = (MemberActivity) lMemberActivities .get(j); //
		 * Taken activities count for the new group too, except for // Health
		 * Assessment // which is program specific. if
		 * (!lMemberActivity.getActivity().getName().equalsIgnoreCase(
		 * BPMConstants.ACTIVITY_HEALTHY_BENEFITS_HA)) {
		 * activityDAO.insertMemberActivity(lNewProgramID,
		 * pParticipatingMemberUpdate.getMemberID(), lMemberActivity); } } }
		 */

	}


	/**
	 * 
	 * @param pParticipatingMemberUpdate
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	protected void updateMemberTransferActvitiesForNewJourneywell(
			MemberUpdate pParticipatingMemberUpdate, BPMBusinessProgram businessProgramDetail) throws BPMException,
			DataAccessException {

		Integer lNewBusinessProgramID = pParticipatingMemberUpdate
				.getBusinessProgramID();		
		Integer pPersonID = pParticipatingMemberUpdate.getPersonID();
				
		// copy current year activities
		Collection<ActivityEvent> lCurrentActivities = activityDAO
				.getCurrentYearActivitiesForTransfer(pPersonID);				

		Iterator<ActivityEvent> itr = lCurrentActivities.iterator();
		while (itr.hasNext()) {
			ActivityEvent activityEvent = itr.next();
			updatePersonProgramActivityStatusForNewJourneywell(activityEvent,
					lNewBusinessProgramID);
		    
		}
	}

	/**
	 * processes ActivityEvent wrt member program
	 * @param activityEvent
	 * @param pPprogramID
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	private void updatePersonProgramActivityStatus(ActivityEvent activityEvent,
			Integer pPprogramID) throws BPMException, DataAccessException {
		try {
			// get all eligible programs from memberId, source activity id, auth
			// code.
			EligibleProgramActivity lEligibleProgramActivity = activityDAO
					.getEligibleProgramActivity(activityEvent
							.getMemberActivity().getActivity()
							.getSourceActivityID(),
							activityEvent.getMemberID(), activityEvent
									.getMemberActivity().getAuthPromoCode(),
							activityEvent.getMemberActivity()
									.getActivityStatus()
									.getStatusEffectiveDate(), pPprogramID);

			// update activity status for program
			if (lEligibleProgramActivity != null) {				
				// Count Health Assessment as a member activity for the
				// business program only if
				// a correct auth code was sent to us.
				if (BPMConstants.ACTIVITY_HEALTHY_BENEFITS_HA
						.equals(lEligibleProgramActivity.getActivityName())
						&& activityEvent.getMemberActivity().getAuthPromoCode() != null) 
				{
					boolean lAuthCodeMatch = false;
					if (activityEvent.getMemberActivity().getAuthPromoCode().equals(
											lEligibleProgramActivity.getAuthCode()))
					{
						lAuthCodeMatch = true;
					}
					
					if(lAuthCodeMatch == false)
					{
						// Check the extended auth codes table
						ArrayList<AuthCode> lExtendedAuthCodes = (ArrayList<AuthCode>)
							    activityDAO.selectExtendedAuthCodes(lEligibleProgramActivity.getBusinessProgramID());
						for(AuthCode lAuthCode : lExtendedAuthCodes)
						{
							if(lAuthCode.equals(activityEvent.getMemberActivity().getAuthPromoCode()))
							{
								lAuthCodeMatch = true;
								break;
							}
						}
					}
					
					if(lAuthCodeMatch)
					{
						activityEvent.getMemberActivity().setBusinessProgramID(
								pPprogramID);
						activityDAO.updateMemberActivity(activityEvent);
					}
				} else {
					// All other activities count for business
					// program.
					// TODO Star Tribune on-line seminar.
					activityEvent.getMemberActivity().setBusinessProgramID(
							pPprogramID);
					activityDAO.updateMemberActivity(activityEvent);
				}
			}
		} catch (DataAccessException dae) {
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		} catch (Exception e) {
			logger.error("BPMException: " + e.getMessage(), e);
			throw new BPMException(e);
		}
	}
	
	/**
	 * processes ActivityEvent wrt member program for new Journeywell.  Activity events are transferred when it's been predetermined that
	 * a site transfer has taken place.  If member transferred to a new group, activities will not follow.
	 * @param activityEvent
	 * @param pPprogramID
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	private void updatePersonProgramActivityStatusForNewJourneywell(ActivityEvent activityEvent,
			Integer pPprogramID) throws BPMException, DataAccessException {
		try {
			// get all eligible programs from memberId, source activity id, auth
			// code.
			EligibleProgramActivity lEligibleProgramActivity = activityDAO
					.getEligibleProgramActivity(activityEvent
							.getMemberActivity().getActivity()
							.getSourceActivityID(),
							activityEvent.getMemberID(), activityEvent
									.getMemberActivity().getAuthPromoCode(),
							activityEvent.getMemberActivity()
									.getActivityStatus()
									.getStatusEffectiveDate(), pPprogramID);

			// update activity status for program
			if (lEligibleProgramActivity != null) {				
				// Count Health Assessment as a member activity for the
				// business program only if
				// a correct auth code was sent to us.
				
				//determine if site transfer
				
				
				if (BPMConstants.ACTIVITY_HEALTHY_BENEFITS_HA
						.equals(lEligibleProgramActivity.getActivityName())) {
					//Auth promo code does not have to match the eligible HA activity promo code for the business program being transferred to.
					//allow HA Auth Code to transfer. As a result, member will not have to retake HA.
					activityEvent.getMemberActivity().setBusinessProgramID(
							pPprogramID);
					activityDAO.updateMemberActivity(activityEvent);
					
				} else {
					// All other activities count for business
					// program.
					// TODO Star Tribune on-line seminar.
					activityEvent.getMemberActivity().setBusinessProgramID(
							pPprogramID);
					activityDAO.updateMemberActivity(activityEvent);
				}
			}
		} catch (DataAccessException dae) {
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		} catch (Exception e) {
			logger.error("BPMException: " + e.getMessage(), e);
			throw new BPMException(e);
		}
	}

	/**
	 * Transfers group's member manual exemptions
	 * @param pParticipatingMemberUpdate
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	protected void updateMemberTransferGroupManualExemptions(
			MemberUpdate pParticipatingMemberUpdate) throws BPMException,
			DataAccessException {

		Integer lNewBusinessProgramID = pParticipatingMemberUpdate
				.getBusinessProgramID();
		Integer pPersonID = pParticipatingMemberUpdate.getPersonID();
		Integer lContractNo = pParticipatingMemberUpdate.getContractNumber();
		Integer lProgramIncentiveOptionID = pParticipatingMemberUpdate.getProgramIncentiveOptionID();

		// fetch group transfer manual exemptions
		Collection<QualificationOverride> transferExemptions = qualificationOverrideDAO
				.getGroupTransferManualExemptions(pPersonID,
						lNewBusinessProgramID, lContractNo, lProgramIncentiveOptionID);

		// copy to new member program
		Iterator<QualificationOverride> exemIterator = transferExemptions
				.iterator();
		while (exemIterator.hasNext()) {
			QualificationOverride exemption = exemIterator.next();
			exemption.setProgramID(lNewBusinessProgramID);
			exemption.setPersonID(pPersonID);
			exemption.setContractNo(lContractNo);
			qualificationOverrideDAO.insertQualificationOverride(exemption);
		}
	}
	
	/* Copy all the previous years Active Disease Management activities to
	* the new biz program.
	*/
	private void copyPrevYearsActiveDMActivities(Integer lNewBusinessProgramID, Integer pPersonID)  throws BPMException, DataAccessException {
	
		
		Collection<ActivityEvent> lPreviousDMActivities = activityDAO
				.getPreviousYearDMActivitiesForTransfer(pPersonID);				
	
		Iterator<ActivityEvent> lDMIterator = lPreviousDMActivities.iterator();
		while (lDMIterator.hasNext()) {
			ActivityEvent lDMActivityEvent = lDMIterator.next();
			updatePersonProgramActivityStatus(lDMActivityEvent,
					lNewBusinessProgramID);
		}
	}

	/*
	 * For new Journeywell programs, check to see if a site transfer has taken place.
	 */

	private boolean isSiteTransfer(Integer pPersonDemographicsID, Integer pContractNo, BPMBusinessProgram pBPMBusinessProgram)
	{
		boolean siteTransfer = false;
		Date systemDate = Calendar.getInstance().getTime();

		Date openDate = null;

		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
		try {
			openDate = format.parse("1/1/9999");
		} catch (Exception e) {
			logger.error("exception on date parsing.");
		}

		ArrayList<SubgroupHistory> lSubgroupHistories = (ArrayList<SubgroupHistory>)
				contractDAO.getSubgroupHistory(pPersonDemographicsID, pContractNo);

		if (lSubgroupHistories!= null)
		{
			// Find the first subgroup whose group is the same as the passed in business program.
			//Story BPM-413 - Address transfer of activities from previous program years by making
			//sure activity transfers are coming from sites within the current business program year.
			for (SubgroupHistory lSubgroupHistory : lSubgroupHistories)
			{
				//before a site transfer can be considered, perform boundary checks to ensure
				//biz programs being evaluated are active across the same group.
				if (lSubgroupHistory.getGroupID().intValue() == pBPMBusinessProgram.getGroupID() &&
						//biz program boundary check against subgroup effective date
						(lSubgroupHistory.getEffectiveDate().before(pBPMBusinessProgram.getEffectiveDate().getTime()) || lSubgroupHistory.getEffectiveDate().equals(pBPMBusinessProgram.getEffectiveDate().getTime())) &&
						(lSubgroupHistory.getEffectiveDate().before(pBPMBusinessProgram.getEndDate().getTime()) || lSubgroupHistory.getEffectiveDate().equals(pBPMBusinessProgram.getEndDate().getTime())) &&
						//biz program boundary check against subgroup end date
						(lSubgroupHistory.getEndDate().equals(openDate) ||
								lSubgroupHistory.getEndDate().before(pBPMBusinessProgram.getEndDate().getTime()) ||
								lSubgroupHistory.getEndDate().equals(pBPMBusinessProgram.getEndDate().getTime())) &&
						//biz program must be current by evaluating with
						//another date boundary check using current date
						(systemDate.equals(pBPMBusinessProgram.getEffectiveDate().getTime()) ||
								systemDate.after(pBPMBusinessProgram.getEffectiveDate().getTime())) &&
						(systemDate.equals(pBPMBusinessProgram.getEndDate().getTime()) ||
								systemDate.before(pBPMBusinessProgram.getEndDate().getTime())))
				{
					siteTransfer = true;
				}
			}
		}

		return siteTransfer;
	}

	public int updateMemberContractStatus(
			MemberProgramUpdateTO memberProgramUpdate) throws BPMException,
			DataAccessException {
		return contractDAO.updateMemberContractStatus(memberProgramUpdate);
	}

	public int[] updateMemberContractStatus(
			Collection<MemberProgramUpdateTO> memberProgramUpdates)
			throws BPMException, DataAccessException {

		return contractDAO.updateMemberContractStatus(memberProgramUpdates);
	}

	public int updateMemberProgramStatus(
			MemberProgramUpdateTO memberProgramUpdate) throws BPMException,
			DataAccessException {
		int ctr = 0;
		//tjq determineParticipation
//		boolean lParticipatesInThisIncentive = false;
//		// Get the program-incentive-options for this programID.
//		ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>)
//				incentiveOptionDAO.getIncentiveOptions(memberProgramUpdate.getProgramID());
//
//		for (ProgramIncentiveOption lProgramIncentiveOption : lProgramIncentiveOptions) {
//			lParticipatesInThisIncentive = determineParticipation(lProgramIncentiveOption.getParticipationGroup(), memberProgramUpdate.getRelationshipCodeID(), );
//		}
//
//		if(lParticipatesInThisIncentive == true) {
//			ctr = personDAO.updateMemberProgramStatus(memberProgramUpdate);
//		}
		ctr = personDAO.updateMemberProgramStatus(memberProgramUpdate);
		return ctr;
	}

	public int[] updateMemberProgramStatus(
			Collection<MemberProgramUpdateTO> memberProgramUpdates)
			throws BPMException, DataAccessException 
	{
		int[] numberOfRowsUpdated =
		    personDAO.updateMemberProgramStatus(memberProgramUpdates);

		return numberOfRowsUpdated;
	}
	
	public void createPersonContractProgramHistory(
			Collection<MemberProgramUpdateTO> memberProgramUpdates, Collection<MemberProgramUpdateTO> memberProgramContractUpdates, Collection<MemberTO> members)
			throws BPMException, DataAccessException 
	{
		
		
		
		Collection<MemberProgramUpdateTO> lMemberProgramUpdateTOsMerged = null;
		
		memberProgramContractUpdates = syncMemberContractStatusWithContractProgramStatusTable(memberProgramContractUpdates);
		
		if (memberProgramUpdates != null && memberProgramUpdates.size() > 0 || memberProgramContractUpdates != null && memberProgramContractUpdates.size() > 0) {
			
			lMemberProgramUpdateTOsMerged = determineMergingOfMemberContractStatuses(memberProgramUpdates, memberProgramContractUpdates, members);
		}
		
		if (lMemberProgramUpdateTOsMerged != null) {
			for (MemberProgramUpdateTO lMemberProgramUpdateTOMerged : lMemberProgramUpdateTOsMerged) {
				if (isNoChangeInPersonProgramStatus(lMemberProgramUpdateTOMerged)) {
					//no need to capture a change in status to the person contract history table.
				} else {
						PersonContractHist lPersonContractHist = buildPersonContractProgramHist(lMemberProgramUpdateTOMerged, members);
						personDAO.insertPersonContractHist(lPersonContractHist);	
				}
			}
		}
	}
	/*
	 * This method ensures that the contract statuses within the member contract status array is current
	 * with the contract program status table.  When a contract becomes qualified not all members of the 
	 * contract reflect the qualified status.
	 */
	private Collection<MemberProgramUpdateTO> syncMemberContractStatusWithContractProgramStatusTable(Collection<MemberProgramUpdateTO> memberProgramContractUpdates) {
		
		HashMap<String, String> contractProgramStatusHM = new HashMap<String, String>();
		
		for (MemberProgramUpdateTO memberProgramContractUpdate : memberProgramContractUpdates) {
			String contractStatus = null;
			ContractProgramStatusTO lContractProgramStatus = null;
			Integer programID = memberProgramContractUpdate.getProgramID();
			Integer programIncentiveOptionID = memberProgramContractUpdate.getProgramIncentiveOptionID();
			Integer contractNo = memberProgramContractUpdate.getContractNumber();
			String key = concatenateDigits(programIncentiveOptionID, contractNo);
			if (contractProgramStatusHM.containsKey(key)) {
				contractStatus = contractProgramStatusHM.get(key);
			} else {
				lContractProgramStatus = contractDAO.getContractStatus(programID, programIncentiveOptionID, contractNo);
				if (lContractProgramStatus != null) {
					contractStatus = lContractProgramStatus.getContractStatus();
					contractProgramStatusHM.put(key, contractStatus);
				}
			}
				
			if (contractStatus != null) {
				//if not equal contract statuses
				if (!contractStatus.equals(memberProgramContractUpdate.getStatusCodeValue())) {
					memberProgramContractUpdate.setStatusCodeValue(contractStatus);
				}
			} 
		}
		
		return memberProgramContractUpdates;
	}
	/*
	 * First determine if there are statuses to combine.  If records exist in a collection for one or the other, set the appropriate flags.
	 * If records exist in both collections then merge based on which collection is greater.
	 */
	private Collection<MemberProgramUpdateTO> determineMergingOfMemberContractStatuses(Collection<MemberProgramUpdateTO> memberProgramUpdates, 
														Collection<MemberProgramUpdateTO> memberProgramContractUpdates, Collection<MemberTO> members) {
		Collection<MemberProgramUpdateTO> lMemberProgramUpdateTOCombined = null;
		
		//return member program statues when member contract statuses don't exist since there is nothing to combine;
		if (memberProgramUpdates != null && memberProgramUpdates.size() > 0 && (memberProgramContractUpdates == null || memberProgramContractUpdates.size() == 0)) {
			for (MemberProgramUpdateTO lMemberProgramUpdateTO : memberProgramUpdates) {
				//get current contract status
				Integer	contractNumber = getPersonContractNumber(lMemberProgramUpdateTO.getProgramID(), lMemberProgramUpdateTO.getPersonID(), members);
				Integer personID = personDAO.getPersonIDFromPersonDemographicsID(lMemberProgramUpdateTO.getPersonID());
				MemberProgramUpdateTO lMemberProgramUpdateTOContract = contractDAO.getMemberContractStatus(contractNumber, personID, lMemberProgramUpdateTO.getProgramID());
				if (lMemberProgramUpdateTOContract != null) {
					lMemberProgramUpdateTO.setStatusCodeValue2(lMemberProgramUpdateTOContract.getStatusCodeValue());
					lMemberProgramUpdateTO.setIssueDate2(lMemberProgramUpdateTOContract.getIssueDate());
				} else {
					lMemberProgramUpdateTO.setStatusCodeValue2(BPMConstants.CONTRACT_STATUS_ELIGIBLE);
					lMemberProgramUpdateTO.setIssueDate2(Calendar.getInstance());
				}
				lMemberProgramUpdateTO.setContractStatusWithMemberStatus(true);											
			}
			return memberProgramUpdates;
		}
		
		//return member program contract statuses when member program statuses don't exist since there is nothing to combine;
		if (memberProgramContractUpdates != null && memberProgramContractUpdates.size() > 0 && (memberProgramUpdates == null || memberProgramUpdates.size() == 0)) 
		{
			ArrayList<MemberProgramUpdateTO> lMemberProgramsWithActivationStatus = new ArrayList<MemberProgramUpdateTO>();
			
			for (MemberProgramUpdateTO lMemberProgramContractUpdateTO : memberProgramContractUpdates) {
				//get current member status
				Member lMember = personDAO.getMemberStatus(lMemberProgramContractUpdateTO.getPersonID().intValue(), lMemberProgramContractUpdateTO.getProgramID().intValue(), false);
				if (lMember != null) {
					lMemberProgramContractUpdateTO.setStatusCodeValue2(lMember.getMemberStatus().getStatus().getStatusCodeValue());
					lMemberProgramContractUpdateTO.setIssueDate2(lMember.getMemberStatus().getStatus().getStatusEffectiveDate()); 
				}
				lMemberProgramContractUpdateTO.setMemberStatusWithContractStatus(true);
				
				if(lMemberProgramContractUpdateTO.getActivationStatusCode() != null)
				{
					lMemberProgramsWithActivationStatus.add(lMemberProgramContractUpdateTO);
				}				
			}
			return lMemberProgramsWithActivationStatus;
		}
		
		//Merge member contract statuses with member statuses for those that match on biz program id, person id, and biz program incentive option id.
		//If collections are equal, indicates there will be a one to one match.  In other words, a status change occurred to both member and contract statuses.
			
		if (memberProgramUpdates.size() >= memberProgramContractUpdates.size()) {
			
			lMemberProgramUpdateTOCombined = combineMemberProgramMemberStatusesWithContractStatuses(memberProgramContractUpdates ,memberProgramUpdates);
		} else 
			//Merge member statuses with contract statuses for those that match on biz program id, person id, and biz program incentive option id.
			if (memberProgramContractUpdates.size() > memberProgramUpdates.size()) {
				lMemberProgramUpdateTOCombined = combineMemberProgramContractStatusesWithMemberStatuses(memberProgramUpdates, memberProgramContractUpdates);
		} 
		
		
		
		
		return lMemberProgramUpdateTOCombined;
	}
	
	/*
	 * Combine member program member statuses with member contract statuses if a match occurs.   
	 */
	private Collection<MemberProgramUpdateTO> combineMemberProgramMemberStatusesWithContractStatuses(Collection<MemberProgramUpdateTO>  memberProgramContractsUpdate, Collection<MemberProgramUpdateTO> memberProgramUpdates) {
		HashMap<String, MemberProgramUpdateTO> memberProgramContractUpdatesHM = new HashMap<String, MemberProgramUpdateTO>();
		for (MemberProgramUpdateTO memberProgramContractUpdate : memberProgramContractsUpdate) {
			for (MemberProgramUpdateTO memberProgramUpdate : memberProgramUpdates) {
				if (memberProgramUpdate.getProgramID().equals(memberProgramContractUpdate.getProgramID()) &&
						memberProgramUpdate.getPersonID().equals(memberProgramContractUpdate.getPersonID()) &&
							memberProgramUpdate.getProgramIncentiveOptionID().equals(memberProgramContractUpdate.getProgramIncentiveOptionID())) {
					memberProgramContractUpdate.setStatusCodeValue2(memberProgramUpdate.getStatusCodeValue());
					memberProgramContractUpdate.setIssueDate2(memberProgramUpdate.getIssueDate());
					memberProgramContractUpdate.setMemberStatusWithContractStatus(true);
					break;
				}
			}
			if (memberProgramContractUpdate.getStatusCodeValue2() == null) {
				
				//get current member status
				Member lMember = personDAO.getMemberStatus(memberProgramContractUpdate.getPersonID().intValue(), memberProgramContractUpdate.getProgramID().intValue(), false);
				if (lMember != null) {
					memberProgramContractUpdate.setStatusCodeValue2(lMember.getMemberStatus().getStatus().getStatusCodeValue());
					memberProgramContractUpdate.setIssueDate2(lMember.getMemberStatus().getStatus().getStatusEffectiveDate());
				}
				memberProgramContractUpdate.setMemberStatusWithContractStatus(true);
			}									
			
			String key = concatenateDigits(memberProgramContractUpdate.getProgramIncentiveOptionID(), memberProgramContractUpdate.getPersonID());
			//HashMap eliminates the possiblility of duplicate person program contract history records being introduced.
			if (memberProgramContractUpdatesHM.containsKey(key)) {
				//replace value object with latest.
				memberProgramContractUpdatesHM.replace(key, memberProgramContractUpdate);
			} else {
				memberProgramContractUpdatesHM.put(key, memberProgramContractUpdate);
			}
		}
		
		return memberProgramContractUpdatesHM.values();
	}
	
	/*
	  * Combine member program member contract statuses with member statuses if a match occurs.  
	 */
	private Collection<MemberProgramUpdateTO> combineMemberProgramContractStatusesWithMemberStatuses(Collection<MemberProgramUpdateTO> memberProgramUpdates, Collection<MemberProgramUpdateTO> memberProgramContractUpdates) {
		HashMap<String, MemberProgramUpdateTO> memberProgramUpdatesHM = new HashMap<String, MemberProgramUpdateTO>();
		for (MemberProgramUpdateTO memberProgramUpdate : memberProgramUpdates) {
			for (MemberProgramUpdateTO memberProgramContractUpdate : memberProgramContractUpdates) {
				if (memberProgramUpdate.getProgramID().equals(memberProgramContractUpdate.getProgramID()) &&
						memberProgramUpdate.getPersonID().equals(memberProgramContractUpdate.getPersonID()) &&
							memberProgramUpdate.getProgramIncentiveOptionID().equals(memberProgramContractUpdate.getProgramIncentiveOptionID())) {
					memberProgramUpdate.setStatusCodeValue2(memberProgramContractUpdate.getStatusCodeValue());
					memberProgramUpdate.setIssueDate2(memberProgramContractUpdate.getIssueDate());
					memberProgramUpdate.setContractStatusWithMemberStatus(true);
					break;
				} 
			}
			if (memberProgramUpdate.getStatusCodeValue2() == null) {
				//get current contract status
				Integer personID = personDAO.getPersonIDFromPersonDemographicsID(memberProgramUpdate.getPersonID());
				MemberProgramUpdateTO lMemberProgramContractUpdateTO = contractDAO.getMemberContractStatus(memberProgramUpdate.getContractNumber(), personID, memberProgramUpdate.getProgramID());
				if (lMemberProgramContractUpdateTO != null) {
					memberProgramUpdate.setStatusCodeValue2(lMemberProgramContractUpdateTO.getStatusCodeValue());
					memberProgramUpdate.setIssueDate2(lMemberProgramContractUpdateTO.getIssueDate());
				}
				memberProgramUpdate.setContractStatusWithMemberStatus(true); 
			}						
			
			String key = concatenateDigits(memberProgramUpdate.getProgramIncentiveOptionID(), memberProgramUpdate.getPersonID());
			//HashMap eliminates the possiblility of duplicate person program contract history records being introduced.
			if (memberProgramUpdatesHM.containsKey(key)) {
				memberProgramUpdatesHM.replace(key, memberProgramUpdate);
			} else {
				memberProgramUpdatesHM.put(key, memberProgramUpdate);
			}
		}
		
		return memberProgramUpdatesHM.values();
	}
	
	private static String concatenateDigits(Integer value1, Integer value2) {
	   StringBuilder sb = new StringBuilder();
	   
	   sb.append(value1);
	   sb.append(value2);
	  
	   return sb.toString();
	}

	public Person getPersonByMemberId(String memberID) throws BPMException,
			DataAccessException {

		return personDAO.getPersonByMemberId(memberID);
	}

	public Collection<Integer> getPersonsEligibleBeyondQualificationPeriod()
			throws BPMException, DataAccessException {
		return personDAO.getPersonsEligibleBeyondQualificationPeriod();
	}
	
	public Collection<ActivityFulfillmentTrackingReportHist> getActivityFulfillmentTrackingReportHist(String fulfillmentRoutingType, java.sql.Date transactionDate)
			throws DataAccessException {
		return personDAO.getActivityFulfillmentTrackingReportHist(fulfillmentRoutingType, transactionDate);
	}

	public int[] insertPersonProcessingStatus(Collection<Integer> personIds,
			Integer processId, String processingStatusValue, String userId)
			throws BPMException, DataAccessException {
		return processingStatusLogDAO.insertPersonProcessingStatusLog(
				personIds, processId, processingStatusValue, userId);
	}

	public Long insertPersonProcessingStatus(Integer personId,
			Integer processId, String processingStatusValue, String userId)
			throws BPMException, DataAccessException {
		return processingStatusLogDAO.insertPersonProcessingStatusLog(personId,
				processId, processingStatusValue, userId);
	}
	
	
	public int insertCDHPFulfillments(Collection<PersonActivityAchievedContribution> cdhpParticipantCompletions) 
			throws BPMException, DataAccessException {
		
		Iterator<PersonActivityAchievedContribution> iter =  (Iterator<PersonActivityAchievedContribution>) cdhpParticipantCompletions.iterator();
		int insertCt = 0;
		while (iter.hasNext()) {
			PersonActivityAchievedContribution hraParticipantCompletion = (PersonActivityAchievedContribution) iter.next();
			personDAO.insertCDHPCompletion(hraParticipantCompletion);
			insertCt ++;
		}
		
		return insertCt;
	}
	
	public int insertCDHPFulfillmentHistory(Collection<PersonActivityAchievedContribution> hraParticipantCompletions) 
	throws BPMException, DataAccessException {

		Iterator<PersonActivityAchievedContribution> iter =  (Iterator<PersonActivityAchievedContribution>) hraParticipantCompletions.iterator();
		int insertCt = 0;
		while (iter.hasNext()) {
			PersonActivityAchievedContribution hraParticipantCompletion = (PersonActivityAchievedContribution) iter.next();
			personDAO.insertCDHPCompletionHistory(hraParticipantCompletion);
			insertCt ++;
		}

		return insertCt;
	}
	
	public int insertRewardFulfillmentHistory(Collection<PersonActivityAchievedReward> participantRewards) 
			throws BPMException, DataAccessException {

		Iterator<PersonActivityAchievedReward> iter =  (Iterator<PersonActivityAchievedReward>) participantRewards.iterator();
		int insertCt = 0;
		while (iter.hasNext()) {
			PersonActivityAchievedReward participantCompletion = (PersonActivityAchievedReward) iter.next();
			participantCompletion.setSystemID(BPMConstants.BPM_USER_SYSTEM);
			personDAO.insertRewardFulfillHistory(participantCompletion);
			insertCt ++;
		}

		return insertCt;
	}
	
	/**
	 * Insert person program stage records that will go to the Cache projection table into the person contract history table.
	 * @param pPersonContractHist
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public void insertPersonContractHist(
			Collection<PersonContractHist> pPersonContractHist) throws BPMException,
			DataAccessException {

		Iterator<PersonContractHist> iter = pPersonContractHist
				.iterator();
		PersonContractHist personContractHist = null;
		while (iter.hasNext()) {
			personContractHist = iter.next();
			personDAO.insertPersonContractHist(personContractHist);
		}
	}
	
	/**
	 * Insert to activity fulfillment report tracking history.  This table will then be used to drive records to the Cache membership premium billing for
	 * reporting achieved activities.
	 * @param pMemberActivities
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	public int insertPersonActivityFulfillmentHistory(
			Collection<MemberActivity> pMemberActivities) throws BPMException,
			DataAccessException {
		int insertCount = 0;
		for (MemberActivity pMemberActivity : pMemberActivities) {
			if (personDAO.isPersonActivityFulfillmentHistoryNotExist(pMemberActivity)) {
				personDAO.insertPersonActivityFulfillmentHistory(pMemberActivity);
				insertCount++;
			}
		}
		
		return insertCount;
	}

	public int updatePersonProcessingStatusLog(Integer personId,
			Integer processId, String processingStatusValue, String userId)
			throws BPMException, DataAccessException {
		return processingStatusLogDAO.updatePersonProcessingStatusLog(personId,
				processId, processingStatusValue, userId);
	}

	public int[] updatePersonProcessingStatus(Collection<Integer> personIds,
			Integer processId, String processingStatusValue, String userId)
			throws BPMException, DataAccessException {
		return processingStatusLogDAO.updatePersonProcessingStatus(personIds,
				processId, processingStatusValue, userId);
	}

	public Collection<Integer> getPendingPersonsTobeProcessed(int batchSize,
			int pProcessID) throws BPMException, DataAccessException {

		return processingStatusLogDAO.getPendingPersonsTobeProcessed(batchSize,
				pProcessID);
	}

	public int getNumberOfPendingPersonsTobeProcessed(int pProcessID)
			throws BPMException, DataAccessException {
		return processingStatusLogDAO
				.getNumberOfPendingPersonsTobeProcessed(pProcessID);
	}
	
	public Collection<PersonContractHist> getPersonContractHistoryReconciled(java.sql.Date pCutoffDateToReconcile)
			throws DataAccessException {
		return personDAO
					.getPersonContractHistoryReconciled(pCutoffDateToReconcile);
	}
	/*
	 * (non-Javadoc)
	 * @see com.healthpartners.service.bpm.iface.MemberService#getAllPersonActivityIncentToFulfillReconciled(java.lang.String, java.lang.String)
	 * Method used for reconciling activity events that have a predefined sourceSystemCode to isolate where activity was sourced from.
	 * Origninally created for activities that came in from Optum clearing house.  Employers using Optum are WellsFargo and Target.
	 */
	public Collection<PersonActivityIncentToFulfillReconcile> getAllPersonActivityIncentToFulfillReconciled(String sourceSystemCode, String productSubType)
			throws DataAccessException {
		
		Collection<PersonActivityIncentToFulfillReconcile> lPersonActivityIncentToFulfillReconcile = personDAO.getPersonActivityIncentToFulfillReconciled(sourceSystemCode, productSubType);
		
		Collection<PersonActivityIncentToFulfillReconcile> lMemberActivityIncentToFulfillReconcile = personDAO.getMemberActivityIncentToFulfillReconciled(sourceSystemCode, productSubType);
		
		lPersonActivityIncentToFulfillReconcile.addAll(lMemberActivityIncentToFulfillReconcile);
		
		return lPersonActivityIncentToFulfillReconcile;
	}
	/*
	 * Reconcile activity against CDHP Fulfillment table.
	 */
	public Collection<PersonProgramActivityIncentiveStatus> getCDHPPersonActivityIncentToFulfillReconciled(Collection<PersonProgramActivityIncentiveStatus> personProgramActivityIncentiveStatusForHraHsaAL) 
			throws DataAccessException {
		ArrayList<PersonProgramActivityIncentiveStatus> personProgramActivityIncentiveStatusForHraHsaDifferences = new ArrayList<PersonProgramActivityIncentiveStatus>();
		
		for (PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus : personProgramActivityIncentiveStatusForHraHsaAL) {
			
			boolean isCDHPFulfillmentReconciled = personDAO.isCDHPPersonActivityIncentToFulfillReconcile(lPersonProgramActivityIncentiveStatus);
			//if activity does not reconcile to fulfillment table
			if (!isCDHPFulfillmentReconciled) {
				personProgramActivityIncentiveStatusForHraHsaDifferences.add(lPersonProgramActivityIncentiveStatus);
			} 
		}
		
		return personProgramActivityIncentiveStatusForHraHsaDifferences;
		
	}
	/*
	 * Reconcile activity against Reward Fulfillment table.
	 */
	public Collection<PersonProgramActivityIncentiveStatus> getRewardPersonActivityIncentToFulfillReconciled(Collection<PersonProgramActivityIncentiveStatus> personProgramActivityIncentiveStatusForRewardAL) 
			throws DataAccessException {
		ArrayList<PersonProgramActivityIncentiveStatus> personProgramActivityIncentiveStatusForRewardDifferences = new ArrayList<PersonProgramActivityIncentiveStatus>();
		
		for (PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus : personProgramActivityIncentiveStatusForRewardAL) {
			
			boolean isRewardFulfillmentReconciled = personDAO.isRewardPersonActivityIncentToFulfillReconcile(lPersonProgramActivityIncentiveStatus);
			//if activity does not reconcile to fulfillment table
			if (!isRewardFulfillmentReconciled) {
				personProgramActivityIncentiveStatusForRewardDifferences.add(lPersonProgramActivityIncentiveStatus);
			}
		}
		
		return personProgramActivityIncentiveStatusForRewardDifferences;
		
	}
	
	
	
	/**
	 * Determine if the end date of the contract has arrived.
	 * 
	 * @param pPersonDemographicsID
	 * @param pProgramID
	 * @param pContractNo
	 * @return
	 */
	public boolean hasContractEnded(Integer pPersonDemographicsID, Integer pProgramID, Integer pContractNo)
	{
		List<java.sql.Date> lContractEndDates =
		    personDAO.selectContractEndDates(pPersonDemographicsID, pProgramID, pContractNo);
		
		if(lContractEndDates.size() > 0)
		{
			java.sql.Date lContractEndDate = lContractEndDates.get(0);
			Calendar lEndDateCalendar = BPMUtils.dateToCalendar(lContractEndDate);			
			Calendar lToday = Calendar.getInstance();
						
			if(lEndDateCalendar.after(lToday))
			{
				return false;
			}			
		}
		
		return true;
	}
	
	/**
	 * Determine if the subgroup (site) end date has arrived.
	 * 
	 * @param pPersonDemographicsID
	 * @param pProgramID
	 * @param pContractNo
	 * @return
	 */
	public boolean hasSubgroupEnded(Integer pPersonDemographicsID, Integer pProgramID, Integer pContractNo)
	{
		List<java.sql.Date> lSubgroupEndDates =
		    personDAO.selectSubgroupEndDates(pPersonDemographicsID, pProgramID, pContractNo);
		
		if(lSubgroupEndDates.size() > 0)
		{
			java.sql.Date lSubgroupEndDate = lSubgroupEndDates.get(0);
			Calendar lEndDateCalendar = BPMUtils.dateToCalendar(lSubgroupEndDate);			
			Calendar lToday = Calendar.getInstance();
						
			if(lEndDateCalendar.after(lToday))
			{
				return false;
			}			
		}
		
		return true;
	}
	
	/**
	 * Determine if the package end date has arrived.
	 * 
	 * @param pPersonDemographicsID
	 * @param pProgramID
	 * @param pContractNo
	 * @return
	 */
	public boolean hasPackageEnded(Integer pPersonDemographicsID, Integer pProgramID, Integer pContractNo)
	{
		List<java.sql.Date> lPackageEndDates =
		    personDAO.selectPackageEndDates(pPersonDemographicsID, pProgramID, pContractNo);
		
		if(lPackageEndDates.size() > 0)
		{
			java.sql.Date lPackageEndDate = lPackageEndDates.get(0);
			Calendar lEndDateCalendar = BPMUtils.dateToCalendar(lPackageEndDate);			
			Calendar lToday = Calendar.getInstance();
						
			if(lEndDateCalendar.after(lToday))
			{
				return false;
			}			
		}
		
		return true;
	}
	
	public Collection<String> getMemberIDFromPersonDetails(String firstName,
			String middleInitial, String lastName, String gender,
			java.sql.Date dateOfBirth) throws DataAccessException, BPMException {

		return personDAO.getMemberIDFromPersonDetails(firstName, middleInitial,
				lastName, gender, dateOfBirth);
	}
	
	public Collection<Integer> insertEmployerAdministeredActivities(
			EmployerActivityContributionsFileData lEmployerActivityContributionsFileData)
			throws DataAccessException, BPMException {
		Collection<Integer> retValues = new ArrayList<Integer>();
		String userID = lEmployerActivityContributionsFileData.getInsertUserId();
		
		Collection<EmployerSponsoredActivity> lEmployerSponsoredActivities = lEmployerActivityContributionsFileData.getValidMemberActivities();
		
		for (EmployerSponsoredActivity lEmployerSponsoredActivity : lEmployerSponsoredActivities) {
			int retValue = activityEventLogDAO
							.insertEmployerAdministeredActivity(lEmployerSponsoredActivity, userID);
			retValues.add(retValue);
			
		}
			
		return retValues;
		
	}
	
	
	public String getGroupName(String groupNo) throws BPMException,
			DataAccessException {
		Collection<EmployerGroup> lEmployerGroup = businessProgramDAO.getGroups(groupNo);
		String groupName = null;
		if(lEmployerGroup.size() > 0){
			groupName = lEmployerGroup.iterator().next().getGroupName();
		}
		return groupName;
	}
	
	public boolean validateParticipatingMember(String memberID) {
		
		boolean isParticipating = personDAO.validateParticipatingMember(memberID);
		
		return isParticipating;
	}
	
	/**
	 * Determine participation of the relationship of the member on the contract, in this incentive.
	 *
	 * @param pParticipationGroup
	 * @return
	 */
	private boolean determineParticipation(ParticipationGroup pParticipationGroup, Integer relationshipID, java.sql.Date dateOfBirth)
	{
		//Start HCEREWARD-262 - 18 plus determination
		if (BPMConstants.BPM_18_PLUS_CD.equals(pParticipationGroup.getParticipationGroupName())) {
			for (ParticipationGroupRequirement lParticipationGroupRequirement : pParticipationGroup.getParticipationGroupRequirements()) {
				for (ParticipationGroupDetail lParticipationGroupDetail : lParticipationGroupRequirement.getParticipationGroupDetails()) {
					if (BPMConstants.BPM_DOB_CD.equals(lParticipationGroupDetail.getParticipationGroupDetailCode())) {
						if (BPMUtils.is18Plus(dateOfBirth)) {
							return true;
						}
					} else {
						return false;
					}
				}
			}
			//End HCEREWARD-262 - 18 plus determination
		} else {
			for (ParticipationGroupRequirement lParticipationGroupRequirement : pParticipationGroup.getParticipationGroupRequirements()) {
				for (ParticipationGroupDetail lParticipationGroupDetail : lParticipationGroupRequirement.getParticipationGroupDetails()) {
					if (BPMConstants.BPM_RELATIONSHIP_CD.equals(lParticipationGroupDetail.getParticipationGroupDetailCode())) {
						if (lParticipationGroupDetail.getSourceCode().equals(String.valueOf(relationshipID))) {
							return true;
						}
					} else {
						return true;
					}
				}
			}
		}

		return false;
	}
	
	/**
	 * Get all related activity incentives by contract to member being processed
	 *   
	 * @param programID
	 * @param contractNo
	 * @param personDemographicsID
	 * @return
	 */
	public ArrayList<MemberProgramIncentiveTO> getRelatedMemberProgramIncentives(Integer programID, Integer contractNo, Integer personDemographicsID)
	{
		//EV103931
		ArrayList<MemberProgramIncentiveTO> removeRelatedMemberProgramIncentives = new ArrayList<MemberProgramIncentiveTO>();
		ArrayList<MemberProgramIncentiveTO> existingRelatedMemberProgramIncentives = new ArrayList<MemberProgramIncentiveTO>();
		
		existingRelatedMemberProgramIncentives.addAll(
					incentiveOptionDAO.getMemberProgramIncentive(programID,			
							 null, contractNo, null));
		
		//find and set aside Related Member Program Incentive objects to be removed
		for (MemberProgramIncentiveTO lMemberProgramIncentiveTO : existingRelatedMemberProgramIncentives) {
			if (personDemographicsID.equals(lMemberProgramIncentiveTO.getPersonDemographicsID())) {
				removeRelatedMemberProgramIncentives.add(lMemberProgramIncentiveTO);
			}
		}
		
		//remove from existingRelatedMemberProgramIncentives
		for (MemberProgramIncentiveTO removeRelatedMemberProgramIncentive : removeRelatedMemberProgramIncentives) {
			existingRelatedMemberProgramIncentives.remove(removeRelatedMemberProgramIncentive);
		}
		
		return existingRelatedMemberProgramIncentives;
	}
	
	/**
	 * 
	 * @param programID
	 * @param personDemographicsID
	 * @param incentiveOptionID
	 * @param activityID
	 * @return
	 */
	public PersonProgramActivityIncentiveStatus getMemberPgmActivityIncentiveStatusNDetail (Integer programID, Integer personDemographicsID, Integer incentiveOptionID, Integer activityID) throws DataAccessException {
			List<IncentiveStatusActivityDetail> lIncentiveStatusActivityDetails = null;
			
			PersonProgramActivityIncentiveStatus lMemberProgramActivityIncentiveStatus = personDAO.getMemberPgmActivityIncentiveStatus(programID, personDemographicsID, incentiveOptionID, activityID);
			
			if (lMemberProgramActivityIncentiveStatus != null) {
				Integer programMemberIncentiveStatusID = lMemberProgramActivityIncentiveStatus.getProgramMemberIncentiveStatusID();
				lIncentiveStatusActivityDetails = incentiveOptionDAO.getIncentiveStatusActivityDetails(null, null, programMemberIncentiveStatusID);
				lMemberProgramActivityIncentiveStatus.setIncentiveStatusActivityDetails(lIncentiveStatusActivityDetails);
			}
			
			return lMemberProgramActivityIncentiveStatus;
	}
	
	/**
	 * 
	 * @param programID
	 * @param personDemographicsID
	 * HashMap exists to eliminate duplicates.  Only completed activities are returned.
	 * @return
	 */
	private ArrayList<PersonProgramActivityIncentiveStatus> getMemberPgmActivityIncentiveStatusesNDetail (Integer programID, Integer personDemographicsID) throws DataAccessException {
			List<IncentiveStatusActivityDetail> lIncentiveStatusActivityDetails = null;
			HashMap<Integer, PersonProgramActivityIncentiveStatus> memberPgmActivityStatusHM = new HashMap<Integer, PersonProgramActivityIncentiveStatus>();
			Collection<PersonProgramActivityIncentiveStatus> lMemberProgramActivityIncentiveStatuses = (Collection<PersonProgramActivityIncentiveStatus>) personDAO.getMemberPgmActivityIncentiveStatuses(programID, personDemographicsID, BPMConstants.ACTIVITY_STATUS_COMPLETE, BPMConstants.ACTIVITY_STATUS_INCENTIVE_ACHIEVED);
			
			for (PersonProgramActivityIncentiveStatus lMemberProgramActivityIncentiveStatus : lMemberProgramActivityIncentiveStatuses) {
				Integer programMemberIncentiveStatusID = lMemberProgramActivityIncentiveStatus.getProgramMemberIncentiveStatusID();
				lIncentiveStatusActivityDetails = incentiveOptionDAO.getIncentiveStatusActivityDetails(null, null, programMemberIncentiveStatusID);
				lMemberProgramActivityIncentiveStatus.setIncentiveStatusActivityDetails(lIncentiveStatusActivityDetails);
				if (!memberPgmActivityStatusHM.containsKey(lMemberProgramActivityIncentiveStatus.getPersonProgramActivityStatusID())) {
					memberPgmActivityStatusHM.put(lMemberProgramActivityIncentiveStatus.getPersonProgramActivityStatusID(), lMemberProgramActivityIncentiveStatus);
				//BPM Story 214 -- addressing site transfer issue.  Need to capture the incentive detail that is present if two program member incentive status records
				//	               exist.
				} else if (lIncentiveStatusActivityDetails.size() > 0) {
							if (memberPgmActivityStatusHM.get(lMemberProgramActivityIncentiveStatus.getPersonProgramActivityStatusID()).getIncentiveStatusActivityDetails().isEmpty()) {
								memberPgmActivityStatusHM.replace(lMemberProgramActivityIncentiveStatus.getPersonProgramActivityStatusID(), lMemberProgramActivityIncentiveStatus);
							}
				}
			}
			
			ArrayList<PersonProgramActivityIncentiveStatus> lMemberProgramActivityIncentiveStatusesAL = new ArrayList<PersonProgramActivityIncentiveStatus>();
			lMemberProgramActivityIncentiveStatuses = (Collection<PersonProgramActivityIncentiveStatus>) memberPgmActivityStatusHM.values();
			for (PersonProgramActivityIncentiveStatus lMemberProgramActivityIncentiveStatus : lMemberProgramActivityIncentiveStatuses) {
				lMemberProgramActivityIncentiveStatusesAL.add(lMemberProgramActivityIncentiveStatus);
			}
			
			return lMemberProgramActivityIncentiveStatusesAL;
	}
	
	/**
	 * 
	 * @param programID
	 * @param incentiveOptionID
	 * @param activityID
	 * @return
	 */
	private List<PersonProgramActivityIncentiveStatus> getContractPgmActivityIncentiveStatusNDetail (Integer programID, Integer contractNo, Integer incentiveOptionID, Integer activityID) throws DataAccessException {
			List<IncentiveStatusActivityDetail> lIncentiveStatusActivityDetails = null;
			
			List<PersonProgramActivityIncentiveStatus> lContractProgramActivityIncentiveStatusAL = personDAO.getContractPgmActivityIncentiveStatus(programID, contractNo, incentiveOptionID, activityID);
			
			if (lContractProgramActivityIncentiveStatusAL != null) {
				for (PersonProgramActivityIncentiveStatus lContractProgramActivityIncentiveStatus : lContractProgramActivityIncentiveStatusAL) {
					Integer programMemberIncentiveStatusID = lContractProgramActivityIncentiveStatus.getProgramMemberIncentiveStatusID();
					lIncentiveStatusActivityDetails = incentiveOptionDAO.getIncentiveStatusActivityDetails(null, null, programMemberIncentiveStatusID);
					if (lIncentiveStatusActivityDetails != null) {
						lContractProgramActivityIncentiveStatus.setIncentiveStatusActivityDetails(lIncentiveStatusActivityDetails);
					}
				}
			}
			
			return lContractProgramActivityIncentiveStatusAL;
	}
	
	/**
	 * Create a default Not-Achieved contract-incentive.
	 * 
	 * @param pProgramIncentiveOption
	 * @param pBusinessProgramID
	 * @param pContractNo
	 * @param pActivationStatusCode
	 * @return
	 */
	private ContractProgramIncentiveTO createContractProgramIncentive(ProgramIncentiveOption pProgramIncentiveOption
			, Integer pBusinessProgramID
			, Integer pContractNo
			, String pActivationStatusCode)
	{
		ContractProgramIncentiveTO lContractProgramIncentiveTO = new ContractProgramIncentiveTO();
		
		lContractProgramIncentiveTO.setBusinessProgramID(pBusinessProgramID);
		lContractProgramIncentiveTO.setIncentiveOptionID(pProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID());
		lContractProgramIncentiveTO.setProgramIncentiveOptionID(pProgramIncentiveOption.getProgramIncentiveOptionID());
		lContractProgramIncentiveTO.setContractIncentiveStatusCode(BPMConstants.ACTIVITY_STATUS_INCENTIVE_NOT_ACHIEVED);
		lContractProgramIncentiveTO.setContractNo(pContractNo);
		lContractProgramIncentiveTO.setActivationStatusCode(pActivationStatusCode);
		
		return lContractProgramIncentiveTO;		
	}
	
	/**
	 * Create a default Not-Achieved member-incentive.
	 * 
	 * @param pProgramIncentiveOption
	 * @param pPersonDemographicsID
	 * @param pBusinessProgramID
	 * @param pContractNo
	 * @param pActivationStatusCode
	 * @return
	 */
	private MemberProgramIncentiveTO createMemberIncentive(ProgramIncentiveOption pProgramIncentiveOption
			, Integer pPersonDemographicsID
			, Integer pBusinessProgramID
			, Integer pContractNo
			, String pActivationStatusCode)
	{
		MemberProgramIncentiveTO lMemberProgramIncentiveTO = new MemberProgramIncentiveTO();
		
		lMemberProgramIncentiveTO.setPersonDemographicsID(pPersonDemographicsID);
		lMemberProgramIncentiveTO.setBusinessProgramID(pBusinessProgramID);
		lMemberProgramIncentiveTO.setContractNo(pContractNo);
		lMemberProgramIncentiveTO.setProgramIncentiveOptionID(pProgramIncentiveOption.getProgramIncentiveOptionID());
		lMemberProgramIncentiveTO.setIncentiveOptionID(pProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID());
		lMemberProgramIncentiveTO.setMemberIncentiveStatusCode(BPMConstants.ACTIVITY_STATUS_INCENTIVE_NOT_ACHIEVED);
		lMemberProgramIncentiveTO.setActivationStatusCode(pActivationStatusCode);
		
		return lMemberProgramIncentiveTO;
	}
	
	private PersonContractHist buildPersonContractProgramHist(MemberProgramUpdateTO lMemberProgramUpdateTO, Collection<MemberTO> members) {
		
		PersonContractHist lPersonContractHist = new PersonContractHist();
			
		//perform lookup on business program
		BPMBusinessProgram lBPMBusinessProgram = businessProgramDAO.getBusinessProgramDetail(lMemberProgramUpdateTO.getProgramID());
		//perform lookup on person demographic
		Integer personID = personDAO.getPersonIDFromPersonDemographicsID(lMemberProgramUpdateTO.getPersonID());
		Person lPerson = personDAO.getPersonByPersonId(personID);
		
		if (lMemberProgramUpdateTO.getContractNumber() != null) {
			lPersonContractHist.setContractNumber(lMemberProgramUpdateTO.getContractNumber());
		} else {
			Integer contractNumber = getPersonContractNumber(lMemberProgramUpdateTO.getProgramID(), lMemberProgramUpdateTO.getPersonID(), members);
			lPersonContractHist.setContractNumber(contractNumber);
		}
		
		if (lMemberProgramUpdateTO.isContractStatusWithMemberStatus()) {
			lPersonContractHist.setMemberStatus(lMemberProgramUpdateTO.getStatusCodeValue());
			if (lMemberProgramUpdateTO.getIssueDate() != null) {
					lPersonContractHist.setMemberStatusDate(BPMUtils.calendarToSqlDate(lMemberProgramUpdateTO.getIssueDate()));
			}
			
			lPersonContractHist.setContractStatus(lMemberProgramUpdateTO.getStatusCodeValue2());
			if (lMemberProgramUpdateTO.getIssueDate2() != null) {
				lPersonContractHist.setContractStatusDate(BPMUtils.calendarToSqlDate(lMemberProgramUpdateTO.getIssueDate2()));
			}
		}
		
		if (lMemberProgramUpdateTO.isMemberStatusWithContractStatus()) {
			
			lPersonContractHist.setContractStatus(lMemberProgramUpdateTO.getStatusCodeValue());
			if (lMemberProgramUpdateTO.getIssueDate() != null) {
				lPersonContractHist.setContractStatusDate(BPMUtils.calendarToSqlDate(lMemberProgramUpdateTO.getIssueDate()));
			}
			
			lPersonContractHist.setMemberStatus(lMemberProgramUpdateTO.getStatusCodeValue2());
			if (lMemberProgramUpdateTO.getIssueDate() != null) {
				lPersonContractHist.setMemberStatusDate(BPMUtils.calendarToSqlDate(lMemberProgramUpdateTO.getIssueDate2()));
			}
		}

		lPersonContractHist.setMemberNumber(lPerson.getMemberId());
		lPersonContractHist.setFirstName(lPerson.getFirstName());
		lPersonContractHist.setLastName(lPerson.getLastName());
		lPersonContractHist.setProgramID(lMemberProgramUpdateTO.getProgramID());
		lPersonContractHist.setGroupID(Integer.valueOf(lBPMBusinessProgram.getGroupID()));
		lPersonContractHist.setPersonNumber(personID);
		lPersonContractHist.setPersonDemographicsID(lPerson.getId());
		lPersonContractHist.setProgramTypeCode(lBPMBusinessProgram.getProgramTypeCodeID());
		lPersonContractHist.setQualificationStartDate(BPMUtils.calendarToSqlDate(lBPMBusinessProgram.getQualificationWindowStartDate()));
		lPersonContractHist.setQualificationEndDate(BPMUtils.calendarToSqlDate(lBPMBusinessProgram.getQualificationWindowEndDate()));
		lPersonContractHist.setProgramStartDate(BPMUtils.calendarToSqlDate(lBPMBusinessProgram.getEffectiveDate()));
		lPersonContractHist.setProgramEndDate(BPMUtils.calendarToSqlDate(lBPMBusinessProgram.getEndDate()));
		lPersonContractHist.setSiteID(lBPMBusinessProgram.getSubgroupID());
		lPersonContractHist.setBusinessProgramIncentiveOptionID(lMemberProgramUpdateTO.getProgramIncentiveOptionID());
				
		lPersonContractHist.setActivationStatusCode(lMemberProgramUpdateTO.getActivationStatusCode());	    	
		
		return lPersonContractHist;
	}
	
private PersonContractRecycle buildPersonContractRecycle(MemberProgramUpdateTO generatedMemberProgramStatus, PersonContractHist personContractHist, String tollgateReason, boolean isContract) {
		
		PersonContractRecycle lPersonContractRecycle = new PersonContractRecycle();
		lPersonContractRecycle.setProgramId(generatedMemberProgramStatus.getProgramID());
		lPersonContractRecycle.setPersonNumber(personContractHist.getPersonNumber());
		lPersonContractRecycle.setPersonDemographicsID(generatedMemberProgramStatus.getPersonID());
		lPersonContractRecycle.setContractNumber(generatedMemberProgramStatus.getContractNumber());
		
		Integer luvID = lookUpValuesRecycleStatusHM.get(BPMConstants.PERSON_CONTRACT_RECYCLE_STATUS_ACTION_NEEDED);
		lPersonContractRecycle.setRecycleStatusId(luvID);
		lPersonContractRecycle.setRecycleStatus(BPMConstants.PERSON_CONTRACT_RECYCLE_STATUS_ACTION_NEEDED);
		
		if (isContract) {
			luvID = lookUpValuesContractStatusHM.get(generatedMemberProgramStatus.getStatusCodeValue());
			if (luvID != null) {
				lPersonContractRecycle.setContractStatusCurrentId(luvID);
				lPersonContractRecycle.setContractStatusCurrent(generatedMemberProgramStatus.getStatusCodeValue());
			}
			luvID = lookUpValuesMemberStatusHM.get(personContractHist.getContractStatus());
			if (luvID != null) {
				lPersonContractRecycle.setContractStatusPrevId(luvID);
				lPersonContractRecycle.setContractStatusPrev(personContractHist.getContractStatus());
			}
		} else {
			luvID = lookUpValuesContractStatusHM.get(generatedMemberProgramStatus.getStatusCodeValue());
			if (luvID != null) {
				lPersonContractRecycle.setMemberStatusCurrentId(luvID);
				lPersonContractRecycle.setMemberStatusCurrent(generatedMemberProgramStatus.getStatusCodeValue());
			}
			luvID = lookUpValuesMemberStatusHM.get(personContractHist.getMemberStatus());
			if (luvID != null) {
				lPersonContractRecycle.setMemberStatusPrevId(luvID);
				lPersonContractRecycle.setMemberStatusPrev(personContractHist.getMemberStatus());
			}
		}
		
		lPersonContractRecycle.setProgramIncentiveOptionID(personContractHist.getBusinessProgramIncentiveOptionID());
		lPersonContractRecycle.setApproverUserId(BPMConstants.BPM_USER_SYSTEM);
		lPersonContractRecycle.setReasonDesc(tollgateReason);
		
		return lPersonContractRecycle;
	}
	
	
	
	private boolean isNoChangeInPersonProgramStatus(MemberProgramUpdateTO lMemberProgramUpdateTO) {
		boolean noChangeInStatus = false;
		
		//read for person contract program history records that match for comparison.
		Integer programID = lMemberProgramUpdateTO.getProgramID();
		Integer programIncentiveOptionID = lMemberProgramUpdateTO.getProgramIncentiveOptionID();
		Integer personDemographicsID = lMemberProgramUpdateTO.getPersonID();
		PersonContractHist lPersonContractHist = personDAO.getPersonContractHist(programID, personDemographicsID, programIncentiveOptionID);
		
		if (lPersonContractHist == null) {
			return noChangeInStatus;
		}
		
		
		if (lMemberProgramUpdateTO.isContractStatusWithMemberStatus()) {
			//Compare member statuses
			if (lPersonContractHist.getMemberStatus() != null && lPersonContractHist.getMemberStatus().equals(lMemberProgramUpdateTO.getStatusCodeValue())) {
				//Compare contract statuses
				if (lPersonContractHist.getContractStatus() != null && lPersonContractHist.getContractStatus().equals(lMemberProgramUpdateTO.getStatusCodeValue2())) {
					noChangeInStatus = true;
				}
			}
		}
		

		if (lMemberProgramUpdateTO.isMemberStatusWithContractStatus()) {
			//Compare contract statuses
			if (lPersonContractHist.getContractStatus() != null && lPersonContractHist.getContractStatus().equals(lMemberProgramUpdateTO.getStatusCodeValue())) {
				//Compare member statuses
				if (lPersonContractHist.getMemberStatus() != null && lPersonContractHist.getMemberStatus().equals(lMemberProgramUpdateTO.getStatusCodeValue2())) {
					noChangeInStatus = true;
				}
			}
			
		}
		
		
	
		return noChangeInStatus;
	}
	

	private Integer getPersonContractNumber(Integer programID, Integer personID, Collection<MemberTO> members) {
		Integer contractNumber = null;
		
		for (MemberTO member : members) {
			if (member.getProgramID().equals(programID)) {
				if (member.getPersonID().intValue() == personID.intValue()) {
					MemberContractProgramTO lMemberContractProgramTO  = member.getMemberContractProgramTO(programID);
					contractNumber = lMemberContractProgramTO.getMemberContract().getContract().getContractNumber();
					break;
				}
			}
		}
		
		return contractNumber;
	}
	/*
	 * Create hashmap table for managing IO when retrieving lookup values.
	 */
	private void createLookUpValueHashMaps() {
		
		Collection<LookUpValueCode> lookUpValueCodes = lookUpValueDAO.getLUVCodesByGroup(BPMConstants.BPM_RECYCLE_STATUS);
		for (LookUpValueCode lookUpValueCode : lookUpValueCodes) {
			lookUpValuesRecycleStatusHM.put(lookUpValueCode.getLuvVal(), lookUpValueCode.getLuvId());
		}
		
		lookUpValueCodes = lookUpValueDAO.getLUVCodesByGroup(BPMConstants.BPM_TYPE_MEMBER_STATUS);
		for (LookUpValueCode lookUpValueCode : lookUpValueCodes) {
			lookUpValuesMemberStatusHM.put(lookUpValueCode.getLuvVal(), lookUpValueCode.getLuvId());
		}
		
		lookUpValueCodes = lookUpValueDAO.getLUVCodesByGroup(BPMConstants.BPM_TYPE_CONTRACT_STATUS);
		for (LookUpValueCode lookUpValueCode : lookUpValueCodes) {
			lookUpValuesContractStatusHM.put(lookUpValueCode.getLuvVal(), lookUpValueCode.getLuvId());
		}
		
	}
	
	public Collection<CDHPFulfillmentTrackingReportHist> getCDHPFulfillmentTrackingReportHist(String productType, Integer programID, Integer personDemographicsID, Integer activityID)
			throws DataAccessException {
		return personDAO.getCDHPFulfillmentTrackingReportHist(productType, programID, personDemographicsID, activityID);
	}
	
	public Collection<ProgramIncentiveOption> getProgramIncentiveOptions(Integer programID)
	{
		return getIncentiveOptionDAO().getIncentiveOptions(programID);
	}
	
	public Collection<AdditionalInformation> getProgramAdditionalInfos(Integer programID)
	{
		return getAdditionalInfoDAO().getAdditionalInfo(programID);
	}
	
	public Collection<PersonRelationship> getPersonRelationships(Integer pPersonDemographicsID)
	{
        return personDAO.getPersonRelationship(pPersonDemographicsID);
	}
	
	public Activity getActivityFromExternalActivity(String groupNo, String externalActivityName) throws Exception, DataAccessException {

		return activityDAO.getActivityFromExternalActivity(groupNo, externalActivityName);
	}
	
	public Collection<Activity> getEmployerAdminsterdActivities()
			throws DataAccessException, BPMException {

		return activityDAO.getEmployerAdminsterdActivities();
	}
	
	public Collection<ActivityExternalEmployerXref> getExternalEmployerActivityXrefAll()
			throws DataAccessException, BPMException {

		return activityDAO.getExternalEmployerActivityXrefAll();
	}

	public ActivityDAO getActivityDAO() {
		return activityDAO;
	}

	public void setActivityDAO(ActivityDAO activityDAO) {
		this.activityDAO = activityDAO;
	}

	public BusinessProgramDAO getBusinessProgramDAO() {
		return businessProgramDAO;
	}

	public void setBusinessProgramDAO(BusinessProgramDAO businessProgramDAO) {
		this.businessProgramDAO = businessProgramDAO;
	}

	public PersonDAO getPersonDAO() {
		return personDAO;
	}

	public void setPersonDAO(PersonDAO personDAO) {
		this.personDAO = personDAO;
	}

	/**
	 * Gets the contractDAO instance variable (injected by Spring).
	 * 
	 * @return ContractDAO
	 */
	public ContractDAO getContractDAO() {
		return contractDAO;
	}

	/**
	 * Set the contractDAO instance variable (injected by Spring).
	 * 
	 * @param contractDAO
	 *            an instance of ContractDAO
	 */
	public void setContractDAO(ContractDAO contractDAO) {
		this.contractDAO = contractDAO;
	}

	public QualificationTimeService getQualificationTimeService() {
		return qualificationTimeService;
	}

	public void setQualificationTimeService(
			QualificationTimeService qualificationTimeService) {
		this.qualificationTimeService = qualificationTimeService;
	}

	/**
	 * @return the taskEventLogDAO
	 */
	public TaskEventLogDAO getTaskEventLogDAO() {
		return taskEventLogDAO;
	}

	/**
	 * @param taskEventLogDAO
	 *            the taskEventLogDAO to set
	 */
	public void setTaskEventLogDAO(TaskEventLogDAO taskEventLogDAO) {
		this.taskEventLogDAO = taskEventLogDAO;
	}

	
	public ProcessingStatusLogDAO getProcessingStatusLogDAO() {
		return processingStatusLogDAO;
	}

	public void setProcessingStatusLogDAO(
			ProcessingStatusLogDAO processingStatusLogDAO) {
		this.processingStatusLogDAO = processingStatusLogDAO;
	}

	public QualificationOverrideDAO getQualificationOverrideDAO() {
		return qualificationOverrideDAO;
	}

	public void setQualificationOverrideDAO(
			QualificationOverrideDAO qualificationOverrideDAO) {
		this.qualificationOverrideDAO = qualificationOverrideDAO;
	}



	public final IncentiveOptionDAO getIncentiveOptionDAO() {
		return incentiveOptionDAO;
	}

	public final void setIncentiveOptionDAO(IncentiveOptionDAO incentiveOptionDAO) {
		this.incentiveOptionDAO = incentiveOptionDAO;
	}

	public AdditionalInfoDAO getAdditionalInfoDAO() {
		return additionalInfoDAO;
	}

	public void setAdditionalInfoDAO(AdditionalInfoDAO additionalInfoDAO) {
		this.additionalInfoDAO = additionalInfoDAO;
	}
	
	

	public ActivityEventLogDAO getActivityEventLogDAO() {
		return activityEventLogDAO;
	}

	public void setActivityEventLogDAO(ActivityEventLogDAO activityEventLogDAO) {
		this.activityEventLogDAO = activityEventLogDAO;
	}

	public DemoSiteService getDemoSiteService() {
		return demoSiteService;
	}

	public void setDemoSiteService(DemoSiteService demoSiteService) {
		this.demoSiteService = demoSiteService;
	}

	public ParticipationGroupDAO getParticipationGroupDAO() {
		return participationGroupDAO;
	}

	public void setParticipationGroupDAO(ParticipationGroupDAO participationGroupDAO) {
		this.participationGroupDAO = participationGroupDAO;
	}
							
	public LookUpValueDAO getLookUpValueDAO() {
		return lookUpValueDAO;
	}

	public void setLookUpValueDAO(LookUpValueDAO lookUpValueDAO) {
		this.lookUpValueDAO = lookUpValueDAO;
		
		createLookUpValueHashMaps();
	}
	
	
	
}
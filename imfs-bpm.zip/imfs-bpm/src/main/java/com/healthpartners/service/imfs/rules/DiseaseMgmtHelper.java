package com.healthpartners.service.imfs.rules;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;


import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.GenericStatusType;
import com.healthpartners.service.imfs.dto.MemberActivity;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;



/**
 * 
 * Helper class to calculate Disease Managemnt activity status based on
 * contiguous 150 days active and 21 days grace period between inactive days
 * 
 * Algorithm: 200.Create Active inactive pairs by ACTV_ID ordered by Start Date
 * 300. Iterate over the collection to determine all contiguouse periods of
 * Active participation 400. Find the the maximum number of 'active days' 500.
 * Determin DM Activity completion status 600. Determine DM Activity active
 * status (if today falls in any of the periods found in Step2, then member is
 * active in DM)
 * 
 * @author mxthoutam
 * 
 */
public class DiseaseMgmtHelper {


	protected final Log logger = LogFactory.getLog(getClass());

	SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");

	/**
	 * Determine weather atleast 1 DM activity completed??
	 * @param memberActivities
	 * @param program
	 * @param currentDateTime
	 * @return
	 */
	public boolean isDiseaseManagementProgramActivityCompleted(
			Collection<MemberActivity> memberActivities,
			BusinessProgramAdapter program, Calendar currentDateTime) {
		boolean result = false;

		if (memberActivities != null && memberActivities.size() > 0) {
			logger.info("Current DateTime="
					+ dateFormat.format(currentDateTime.getTime()));

			// 1.determine if atleast 1 DM activity with completed status
			result = isDMActivityStatusCompleted(memberActivities, program);			
			
			// 2.if NOT complted
			if (!result) {
				//calculate from DM activity History
				result = calculateDMActivityForCompleteStatus(memberActivities,
						program, currentDateTime);
			} // if NOT result
		}

		logger.info("@isDiseaseManagementProgramActivityCompleted=" + result);

		return result;
	}

	/**
	 * Determine weather atleast 1 DM activity started??
	 * @param memberActivities
	 * @param program
	 * @param currentDateTime
	 * @return
	 */
	public boolean isDiseaseManagementProgramActivityStarted(
			Collection<MemberActivity> memberActivities,
			BusinessProgramAdapter program, Calendar currentDateTime) {
		boolean result = false;

		if (memberActivities != null && memberActivities.size() > 0) {

			logger.info("Current DateTime="
					+ dateFormat.format(currentDateTime.getTime()));

			// 1.determine if atleast 1 DM activity with completed status
			result = isDMActivityStatusCompleted(memberActivities, program);			

			// 2.if NOT complted
			if (!result) {
				//calculate from DM activity History
				result = calculateDMActivityForActiveStatus(memberActivities,
						program, currentDateTime);
			} // if NOT result

		}
		logger.info("@isDiseaseManagementProgramActivityStarted=" + result);
		return result;
	}

	/**
	 * Determine weather atleast 1 DM activity completed from the DM activity history
	 *  
	 * Algorithm: 200.Create Active inactive pairs by ACTV_ID ordered by Start Date
	 * 300. Iterate over the collection to determine all contiguouse periods of
	 * Active participation 400. Find the the maximum number of 'active days' 500.
	 * Determin DM Activity completion status 600. Determine DM Activity active
	 * status (if today falls in any of the periods found in Step2, then member is
	 * active in DM)
	 * 
	 * @param memberActivities
	 * @param program
	 * @return
	 */
	private boolean calculateDMActivityForCompleteStatus(
			Collection<MemberActivity> memberActivities,
			BusinessProgramAdapter program, Calendar currentDateTime) {
		boolean result;
		// 100.create activity level map from all activity histories
		TreeMap<Integer, List<DMActivityStatus>> dMActivityStatusMap = generateDMActivityLevelMap(memberActivities);

		// 200 create activity pairs - sorted by activity ID and start date
		List<DMActivityPair> dMActivityPairs = generateDMActivityPairs(
				dMActivityStatusMap, program, currentDateTime);

		// 300.create active PERIODS
		List<DMActivePeriod> dMActivePeriods = generateDMContiguousActivePeriods(dMActivityPairs);

		// 400 calculate based on active days
		result = isDMActivityCompleteFromActivePeriods(dMActivePeriods);
		return result;
	}

	/**
	 * Determine weather atleast 1 DM activity active/completed from the DM activity history
	 *  
	 * Algorithm: 200.Create Active inactive pairs by ACTV_ID ordered by Start Date
	 * 300. Iterate over the collection to determine all contiguouse periods of
	 * Active participation 400. Find the the maximum number of 'active days' 500.
	 * Determin DM Activity completion status 600. Determine DM Activity active
	 * status (if today falls in any of the periods found in Step2, then member is
	 * active in DM)
	 *  
	 * @param memberActivities
	 * @param program
	 * @param currentDateTime
	 * @return
	 */
	private boolean calculateDMActivityForActiveStatus(
			Collection<MemberActivity> memberActivities,
			BusinessProgramAdapter program, Calendar currentDateTime) {
		boolean result;
		// 100.create activity level map from all activity histories
		TreeMap<Integer, List<DMActivityStatus>> dMActivityStatusMap = generateDMActivityLevelMap(memberActivities);
		
		// 200 create activity pairs - sorted by activity ID and start date
		List<DMActivityPair> dMActivityPairs = generateDMActivityPairs(
				dMActivityStatusMap, program, currentDateTime);				

		// EV 38641
		// If this activity is canceled remove it from the activity-pair list so it is not
		// counted for member status of Active.
		removeStatusFromPair(dMActivityStatusMap
				, dMActivityPairs, BPMConstants.ACTIVITY_STATUS_CANCELED);

		// 300.create active PERIODS
		List<DMActivePeriod> dMActivePeriods = generateDMContiguousActivePeriods(dMActivityPairs);

		// 400 calculate based on active days
		result = isDMActivityActiveFromActivePeriods(dMActivePeriods, program,
				currentDateTime);
		return result;
	}

	/**
	 * determines if any DM activity active period is greater than 150 days
	 * @param dMActivePeriods
	 * @return
	 */
	private boolean isDMActivityCompleteFromActivePeriods(
			List<DMActivePeriod> dMActivePeriods) {
		boolean result = false;
		Iterator<DMActivePeriod> itr = dMActivePeriods.iterator();
		while (itr.hasNext()) {
			DMActivePeriod activePeriod = itr.next();
			if (activePeriod.getActiveDays() >= BPMConstants.DISEASE_MGMT_ACTIVITY_COMPLETED_TIME_OUT_DAYS) {
				result = true;
				logger.info("DM Activity Completed - from "
								+ activePeriod.getPeriodName()
								+ ", activeDays="
								+ activePeriod.getActiveDays()
								+ " >= "
								+ BPMConstants.DISEASE_MGMT_ACTIVITY_COMPLETED_TIME_OUT_DAYS);
			}
		}
		return result;
	}

	/**
	 * determines if any DM activity active period is greater than 0 days
	 * @param dMActivePeriods
	 * @return
	 */
	private boolean isDMActivityActiveFromActivePeriods(
			List<DMActivePeriod> dMActivePeriods,
			BusinessProgramAdapter program, Calendar currentDateTime) {
		boolean result = false;
		Iterator<DMActivePeriod> itr = dMActivePeriods.iterator();
		while (itr.hasNext()) {
			DMActivePeriod activePeriod = itr.next();
			if(activePeriod.getActiveDays() > 0){
				//is active in DM program at least once
				result = true;
				break;
			}
		}
		return result;
	}

	/**
	 * determine if atleast 1 DM activity with completed status
	 * @param memberActivities
	 * @return
	 */
	private boolean isDMActivityStatusCompleted(
			Collection<MemberActivity> memberActivities, BusinessProgramAdapter program) {

		boolean result = false;

		Iterator<MemberActivity> itr = memberActivities.iterator();
		while (itr.hasNext()) 
		{
			MemberActivity lMemberActivity = (MemberActivity)itr.next();
			
			BPMUtils.setTimeToZero(lMemberActivity.getActivityStatus().getStatusEffectiveDate());
			BPMUtils.setTimeToZero(program.getBusinessProgram().getQualificationWindowStartDate());
			BPMUtils.setTimeToZero(program.getBusinessProgram().getQualificationWindowEndDate());
			
			// Waived by the Administrator counts as Complete. After the Qual Start Date, 
			// and before or on Qual End Date.
			if((BPMConstants.ACTIVITY_STATUS_COMPLETE.equalsIgnoreCase(lMemberActivity.getActivityStatus().getStatusCodeValue())
					|| BPMConstants.ACTIVITY_STATUS_WAIVE.equalsIgnoreCase(lMemberActivity.getActivityStatus().getStatusCodeValue())
					|| BPMConstants.ACTIVITY_STATUS_EXEMPT.equalsIgnoreCase(lMemberActivity.getActivityStatus().getStatusCodeValue()))
			  && lMemberActivity.getActivityStatus().getStatusEffectiveDate().after(program.getBusinessProgram().getQualificationWindowStartDate())
              && (lMemberActivity.getActivityStatus().getStatusEffectiveDate().before(program.getBusinessProgram().getQualificationWindowEndDate())
            	  || lMemberActivity.getActivityStatus().getStatusEffectiveDate().compareTo(program.getBusinessProgram().getQualificationWindowEndDate()) == 0
            	 )	  
              )
			{
                //atleast 1 activity completed
				result = true;
			}							
		}
		return result;
	}

	/**
	 * generates DM activity map by activityid and activityhistory. activity history sortedby date ascending
	 * @param memberActivities
	 */
	private TreeMap<Integer, List<DMActivityStatus>> generateDMActivityLevelMap(
			Collection<MemberActivity> memberActivities) {
		TreeMap<Integer, List<DMActivityStatus>> dMActivityStatusMap = new TreeMap<Integer, List<DMActivityStatus>>();

		Iterator<MemberActivity> itrAct = memberActivities.iterator();
		//iterate each DM activity
		while (itrAct.hasNext()) {
			//prepare and add this DM activity history
			List<DMActivityStatus> dmActivityStatusList = new ArrayList<DMActivityStatus>();
			MemberActivity activity = itrAct.next();
			Integer activityID = activity.getActivity().getActivityID();
			GenericStatusType[] statusHistory = activity.getStatusHistory();
			if (statusHistory != null && statusHistory.length > 0) {
				for (int i = 0; i < statusHistory.length; i++) {
					DMActivityStatus dmActivityStatus = new DMActivityStatus();
					dmActivityStatus.setActivityID(activityID);
					dmActivityStatus.setStatusCodeValue(statusHistory[i]
							.getStatusCodeValue());
					dmActivityStatus.setStatusDate(statusHistory[i]
							.getStatusEffectiveDate());
					//add activity history
					dmActivityStatusList.add(dmActivityStatus);
				}
			}
			//sort by status date
			Collections.sort(dmActivityStatusList); 
			//put DM activity
			dMActivityStatusMap.put(activityID, dmActivityStatusList);
		}

		return dMActivityStatusMap;
	}

	/**
	 * create activity pairs - sorted by activity ID and start date
	 * @param dMActivityStatusMap
	 * @param program
	 * @param currentDateTime
	 * @return
	 */
	private List<DMActivityPair> generateDMActivityPairs(
			TreeMap<Integer, List<DMActivityStatus>> dMActivityStatusMap,
			BusinessProgramAdapter program, Calendar currentDateTime) {
		List<DMActivityPair> dMActivityPairs = new ArrayList<DMActivityPair>();

		Set<Integer> keys = dMActivityStatusMap.keySet();
		Iterator<Integer> itr = keys.iterator();
		while (itr.hasNext()) {
			List<DMActivityStatus> dMActivityStatusList = dMActivityStatusMap
					.get(itr.next());
			List<DMActivityPair> dMActivityPairList = generateActivityPairsBySigleActivity(
					dMActivityStatusList, program, currentDateTime);
			dMActivityPairs.addAll(dMActivityPairList);
		}

		// sorted by activity ID and start date
		Collections.sort(dMActivityPairs);

		// Just to debug
		Iterator<DMActivityPair> itrd = dMActivityPairs.iterator();
		int i = 0;
		while (itrd.hasNext()) {
			i++;
			DMActivityPair dMActivityPair = itrd.next();
			logger.info("ActivityPair "
					+ i
					+ ":startDate="
					+ dateFormat
							.format(dMActivityPair.getStartDate().getTime())
					+ ", endDate="
					+ dateFormat.format(dMActivityPair.getEndDate().getTime()));
		}

		return dMActivityPairs;
	}

	/**
	 * create activity pair for single activity -(activity start and end dates)
	 * @param dMActivityStatusList
	 * @param program
	 * @param currentDateTime
	 * @return
	 */
	private List<DMActivityPair> generateActivityPairsBySigleActivity(
			List<DMActivityStatus> dMActivityStatusList,
			BusinessProgramAdapter program, Calendar currentDateTime) {
		List<DMActivityPair> dMActivityPairs = new ArrayList<DMActivityPair>();
		Integer activityID = null;

		boolean activityStarted = false;
		boolean activityInactive = false;		
		Calendar startDate = null;
		Calendar endDate = null;

		Iterator<DMActivityStatus> itr = dMActivityStatusList.iterator();
		while (itr.hasNext()) {			
			DMActivityStatus dMActivityStatus = itr.next();
			activityID = dMActivityStatus.getActivityID();
			String activityStatus = dMActivityStatus.getStatusCodeValue();
			if (BPMConstants.ACTIVITY_STATUS_ACTIVE.equals(activityStatus)) {
				// Active
				if (!activityStarted) {
					startDate = dMActivityStatus.getStatusDate();
					activityStarted = true;
				}
			} 
			else if (BPMConstants.ACTIVITY_STATUS_INACTIVE.equals(activityStatus)
					|| BPMConstants.ACTIVITY_STATUS_CANCELED.equals(activityStatus)) 
			{
				// Inactive
				// EV 38641 - If the activity is canceled, still take it through the 150 day calculation. 
				if (!activityInactive) {
					endDate = dMActivityStatus.getStatusDate();
					activityInactive = true;
				}

			} 
			else if (BPMConstants.ACTIVITY_STATUS_DELETE.equals(activityStatus)) 
			{
				// delete ie don't consider previous history
				activityStarted = false;
				activityInactive = false;
				startDate = null;
				endDate = null;
				
				int lActivityPairsSize = dMActivityPairs.size();

				// If this activity is cancelled or deleted remove it from the activity-pair list.
                for(int j = 0; j < lActivityPairsSize; j++)
                {
                	DMActivityPair lDMActivityPair = (DMActivityPair)dMActivityPairs.get(j);
                	if(lDMActivityPair.getActivityID().intValue() == activityID.intValue())
                	{
                		dMActivityPairs.remove(j);
                		lActivityPairsSize--;
                	}
                }
			}			

			// create one pair - if any inactives
			if (activityInactive) {
				DMActivityPair dMActivityPair = new DMActivityPair();
				dMActivityPair.setActivityID(activityID);
				if (!activityStarted) {
					// 06/13/2008
					// Once here, the activity is Inactive AND not started.
					// So this is the first time we hear about this activity and
					// it is Inactive.
					startDate = dMActivityStatus.getStatusDate();
				}
				// getmax of qual st date, startDate
				dMActivityPair.setStartDate(BPMUtils.getMaximumDate(startDate,
						program.getBusinessProgram()
								.getQualificationWindowStartDate()));
				// get min of qual end date, endDate
				dMActivityPair.setEndDate(BPMUtils.getMinimumDate(endDate,
						program.getBusinessProgram()
								.getQualificationWindowEndDate()));
				// ADD one pair
				dMActivityPairs.add(dMActivityPair);	
                // make room for another pair
				activityStarted = false;
				activityInactive = false;
			}
		} // while iterate
		
        //	create one pair - if only one ACTIVE, and NO inactives
		if (activityStarted && !activityInactive) {
			DMActivityPair dMActivityPair = new DMActivityPair();
			dMActivityPair.setActivityID(activityID);
			//getmax of qual st date, startDate
			dMActivityPair.setStartDate(BPMUtils.getMaximumDate(startDate,
					program.getBusinessProgram()
							.getQualificationWindowStartDate()));								

			// No inactives
			// get min of (qual end date, today)
			dMActivityPair.setEndDate(BPMUtils.getMinimumDate(currentDateTime,
					program.getBusinessProgram()
							.getQualificationWindowEndDate()));
			// ADD one pair
			dMActivityPairs.add(dMActivityPair);						
		}

		return dMActivityPairs;
	}

	/**
	 * prepare contiguous active days from the activity pairs of start and end dates
	 * @param dMActivityPairs
	 * @return
	 */
	private List<DMActivePeriod> generateDMContiguousActivePeriods(
			List<DMActivityPair> dMActivityPairs) {
		List<DMActivePeriod> dMActivePeriods = new ArrayList<DMActivePeriod>();

		Iterator<DMActivityPair> itr = dMActivityPairs.iterator();
		DMActivityPair activityPair1 = null;
		DMActivityPair activityPair2 = null;
		int countPass = 0;
		DMActivePeriod activePeriod = null;
		int periodNumber = 0;
		do {
			if (countPass == 0 && itr.hasNext()) {
				// first pass
				activityPair1 = itr.next();
				activePeriod = new DMActivePeriod();
				activePeriod.setStartDate(activityPair1.getStartDate());
				activePeriod.setEndDate(activityPair1.getEndDate());
			} else if (itr.hasNext()) {
				// second pass onwards
				activityPair2 = itr.next();
				int gapDays = BPMUtils.getDaysBetweenDates(activityPair2
								.getStartDate(),
						activePeriod.getEndDate());

				logger.info("DMContiguousActivePeriod for activityID="
								+ activityPair2.getActivityID() + ", gapDays"
								+ gapDays);
				if (gapDays > BPMConstants.DISEASE_MGMT_ACTIVITY_INACTIVE_GRACE_DAYS) {
					// add old period
					periodNumber++;
					activePeriod.setPeriodName("PERIOD" + periodNumber);
					activePeriod.setGapDays(gapDays);
					dMActivePeriods.add(activePeriod);
					// new period
					activePeriod = new DMActivePeriod();
					activePeriod.setGapDays(gapDays);
					activePeriod.setStartDate(activityPair2.getStartDate());
					activePeriod.setEndDate(activityPair2.getEndDate());
				} else {
					// contiguous
					// activityPair1.activityID
					activePeriod.setGapDays(gapDays);
					activePeriod.setEndDate(BPMUtils.getMaximumDate(
							activePeriod.getEndDate(), activityPair2
									.getEndDate()));
					activePeriod.setStartDate(BPMUtils.getMinimumDate(
							activePeriod.getStartDate(), activityPair2
									.getStartDate()));
				}
			}
			countPass++;
		} while (itr.hasNext());

		// add the latest remaining
		if (activePeriod != null) {
			periodNumber++;
			activePeriod.setPeriodName("PERIOD" + periodNumber);
			dMActivePeriods.add(activePeriod);
		}

		// Just to debug
		Iterator<DMActivePeriod> itrd = dMActivePeriods.iterator();
		while (itrd.hasNext()) {
			DMActivePeriod dMActivePeriod = itrd.next();
			logger.info("DMContiguousActivePeriod- "
					+ dMActivePeriod.getPeriodName()
					+ "- startDate="
					+ dateFormat
							.format(dMActivePeriod.getStartDate().getTime())
					+ ", endDate="
					+ dateFormat.format(dMActivePeriod.getEndDate().getTime())
					+ ", Total Active Days=" + dMActivePeriod.getActiveDays());
		}

		return dMActivePeriods;
	}
	
	/**
	 * Removes a specified status (CANCEL, DELETE, etc..) from the list of activity-status pairs.
	 * Used to remove a status so it is not counted for member status.
	 * 
	 * @param dMActivityStatusMap
	 * @param dMActivityPairs
	 * @param pActivityStatus
	 */
	protected void removeStatusFromPair(TreeMap<Integer, List<DMActivityStatus>> dMActivityStatusMap
			, List<DMActivityPair> dMActivityPairs, String pActivityStatus)
	{
		int lActivityPairsSize = dMActivityPairs.size();
		
		for(int j = 0; j < lActivityPairsSize; j++)
        {
        	DMActivityPair lDMActivityPair = (DMActivityPair)dMActivityPairs.get(j);
        	List<DMActivityStatus> dMActivityStatusList = dMActivityStatusMap.get(lDMActivityPair.getActivityID());
        	
        	Iterator<DMActivityStatus> itr = dMActivityStatusList.iterator();
    		while (itr.hasNext()) 
    		{			
    			DMActivityStatus dMActivityStatus = itr.next();
	        	if(pActivityStatus.equals(dMActivityStatus.getStatusCodeValue()))
	        	{
	        		dMActivityPairs.remove(j);
	        		lActivityPairsSize--;
	        	}
    		}
        }
	}

	// private utility methods
	private boolean isActivityCompleted(MemberActivity activity) {
		boolean result = false;
		if (BPMConstants.ACTIVITY_STATUS_COMPLETE.equals(activity
				.getActivityStatus().getStatusCodeValue())) {
			result = true;
		}
		return result;
	}

	// inner classes
	/**
	 * Inner Class holds activityID, stats, statusDate, sortable by statusDate
	 */
	private class DMActivityStatus implements Comparable<DMActivityStatus> {

		private Integer activityID;

		private String statusCodeValue;

		private Calendar statusDate;

		public Integer getActivityID() {
			return activityID;
		}

		public void setActivityID(Integer activityID) {
			this.activityID = activityID;
		}

		public String getStatusCodeValue() {
			return statusCodeValue;
		}

		public void setStatusCodeValue(String statusCodeValue) {
			this.statusCodeValue = statusCodeValue;
		}

		public Calendar getStatusDate() {
			return statusDate;
		}

		public void setStatusDate(Calendar statusDate) {
			this.statusDate = statusDate;
		}

		public int compareTo(DMActivityStatus o) {
            // Set the times to 0, so that only the dates are compared.
			BPMUtils.setTimeToZero(getStatusDate());
			BPMUtils.setTimeToZero(o.getStatusDate());
			
			return getStatusDate().compareTo(o.getStatusDate());
		}
	}

	/**
	 * Inner Class holds activityPair info( activityID, startDate, endDate), sortable by startDate 
	 * @author mxthoutam
	 *
	 */
	private class DMActivityPair implements Comparable<DMActivityPair> {

		private Integer activityID;

		private Calendar startDate;

		private Calendar endDate;

		public Integer getActivityID() {
			return activityID;
		}

		public void setActivityID(Integer activityID) {
			this.activityID = activityID;
		}

		public Calendar getEndDate() {
			return endDate;
		}

		public void setEndDate(Calendar endDate) {
			this.endDate = endDate;
		}

		public Calendar getStartDate() {
			return startDate;
		}

		public void setStartDate(Calendar startDate) {
			this.startDate = startDate;
		}

		public int compareTo(DMActivityPair o) {
			
            // Set the times to 0, so that only the dates are compared.
			BPMUtils.setTimeToZero(getStartDate());
			BPMUtils.setTimeToZero(o.getStartDate());					
			
			// sort by  status date
			return getStartDate().compareTo(o.getStartDate());

		}
	}

	/**
	 * Inner Class holds active period info( gapDays, activeDays, activeDays,  endDate) 
	 * @author mxthoutam
	 *
	 */
	private class DMActivePeriod {

		private int gapDays = 0;

		private int activeDays = 0;

		private String periodName;

		private Calendar startDate;

		private Calendar endDate;

		public int getActiveDays() {
			this.activeDays = BPMUtils.getDaysBetweenDates(endDate, startDate);
			return activeDays;
		}

		public void setActiveDays(int activeDays) {
			this.activeDays = activeDays;
		}

		public int getGapDays() {
			return gapDays;
		}

		public void setGapDays(int gapDays) {
			this.gapDays = gapDays;
		}

		public String getPeriodName() {
			return periodName;
		}

		public void setPeriodName(String periodName) {
			this.periodName = periodName;
		}

		public Calendar getEndDate() {
			return endDate;
		}

		public void setEndDate(Calendar endDate) {
			this.endDate = endDate;
		}

		public Calendar getStartDate() {
			return startDate;
		}

		public void setStartDate(Calendar startDate) {
			this.startDate = startDate;
		}

	}
}

package com.healthpartners.service.imfs.dao;


import com.healthpartners.service.imfs.dto.ReconLogStage;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Types;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.healthpartners.service.imfs.exception.BPMException;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;

// Referenced classes of package com.healthpartners.service.bpm.dao:
//            ReconLogStageDAO
@Configuration
public class ReconLogStageDAOJdbc extends JdbcDaoSupport
    implements ReconLogStageDAO
{
	private String selectReconLogStage;
    private String insertReconLogStageRecord;
    
    public ReconLogStageDAOJdbc()
    {
    }

	@Qualifier("cacheDataSource")
	@Autowired
	DataSource cacheDataSource;


	@PostConstruct
	private void initialize() {

		setDataSource(cacheDataSource);
	}

    //Produces warnings during compile time to quickly identify typos or API changes

	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
    public ReconLogStage getReconLogStage(Integer auditLogId)
    
        throws DataAccessException
    {
    	final ArrayList<ReconLogStage> lReconLogsStage = new ArrayList<ReconLogStage>();
		StringBuffer query = new StringBuffer();
		query.append(selectReconLogStage);
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { auditLogId };
		int types[] = new int[] { Types.INTEGER};

		template.query(query.toString(), params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						ReconLogStage lReconLogStage = new ReconLogStage();
						lReconLogStage.setAuditLogId(rs
								.getInt("AuditLogId"));
						lReconLogStage.setAppId(rs
								.getString("AppId"));
						lReconLogStage.setAppEventId(rs
								.getString("AppEventId"));
						lReconLogStage.setAppEventResultId(rs
								.getString("AppEventResultId"));
						lReconLogStage.setParam1Id(rs
								.getString("Param1Id"));
						lReconLogStage.setParam2Id(rs
								.getString("Param2Id"));
						lReconLogStage.setParam3Id(rs
								.getString("Param3Id"));
						lReconLogStage.setParam4Id(rs
								.getString("Param4Id"));
						
						lReconLogsStage
								.add(lReconLogStage);
					}
				});

		ReconLogStage reconLogStage = null;
		if (lReconLogsStage.size() > 0) {
			reconLogStage = lReconLogsStage.get(0);
		}

		return reconLogStage;
    }
    //Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "CacheDataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
    public int insertReconLogStage(ReconLogStage reconLogStage)
	throws DataAccessException {


	    	Integer auditLogId = null;
	        Date runDate = null;
	        Time runTime = null;
	        String appId = null;
	        String appEventId = null;
	        String appEventResultId = null;
	        String param1Id = null;
	        String param2Id = null;
	        String param3Id = null;
	        String param4Id = null;
	        
	        auditLogId = reconLogStage.getAuditLogId() == null ? null : reconLogStage.getAuditLogId();
	        appId = reconLogStage.getAppId() == null ? null : reconLogStage.getAppId();
	        appEventId = reconLogStage.getAppEventId() == null ? null : reconLogStage.getAppEventId();
	        appEventResultId = reconLogStage.getAppEventResultId() == null ? null : reconLogStage.getAppEventResultId();
	        param1Id = reconLogStage.getParam1Id() == null ? null : reconLogStage.getParam1Id();
	        param2Id = reconLogStage.getParam2Id() == null ? null : reconLogStage.getParam2Id();
	        param3Id = reconLogStage.getParam3Id() == null ? null : reconLogStage.getParam3Id();
	        param4Id = reconLogStage.getParam4Id() == null ? null : reconLogStage.getParam4Id();
	        runDate = new Date((new java.util.Date()).getTime());
	        long time = runDate.getTime();
	        runTime = new Time(time);

			
			
			// Persist.
			JdbcTemplate template = getJdbcTemplate();
			Object params[] = new Object[] {  appEventId, appEventResultId, appId, auditLogId,  param1Id, param2Id, param3Id, param4Id, runDate, runTime};
			int types[] = new int[] { Types.VARCHAR, Types.VARCHAR,
					Types.VARCHAR, Types.INTEGER, 
					Types.VARCHAR, Types.VARCHAR, 
					Types.VARCHAR, Types.VARCHAR,
					Types.DATE, Types.TIME};
					
			
			int rowInserted = template.update(insertReconLogStageRecord, params, types);
				
	
		return rowInserted;
    }
    
    
    public String getSelectReconLogStage()
    {
        return selectReconLogStage;
    }

    public void setSelectReconLogStage(String selectReconLogStage)
    {
        this.selectReconLogStage = selectReconLogStage;
    }

    public String getInsertReconLogStageRecord()
    {
        return insertReconLogStageRecord;
    }

    public void setInsertReconLogStageRecord(String insertReconLogStageRecord)
    {
        this.insertReconLogStageRecord = insertReconLogStageRecord;
    }

    
}
package com.healthpartners.service.imfs.dao;

import java.util.Collection;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.healthpartners.service.imfs.dto.IncentivePackageRuleGroup;
import com.healthpartners.service.imfs.dto.IncentivePackageRuleRequirement;
import com.healthpartners.service.imfs.exception.BPMException;

public interface IncentivePackageRuleDAO 
{
	public Collection<IncentivePackageRuleGroup> getIncentivePackageRuleGroups()
			throws BPMException, DataAccessException;
	
	public IncentivePackageRuleGroup getIncentivePackageRuleGroup(Integer pIncentivePackageRuleGroupID) 
			throws BPMException, DataAccessException;
		 
	public int insertIncentivePackageRuleGroup(IncentivePackageRuleGroup pIncentivePackageRuleGroup, String pModifyUserID) 
			throws BPMException, DataAccessException;

	public int deleteIncentivePackageRuleGroup(Integer pIncentivePackageRuleGroupID) 
			throws BPMException, DataAccessException;

	public int updateIncentivePackageRuleGroup(IncentivePackageRuleGroup pIncentivePackageRuleGroup, String pModifyUserID) 
			throws BPMException, DataAccessException;

	public List<IncentivePackageRuleRequirement> getIncentivePackageRuleRequirements(Integer pIncentivePackageRuleGroupID)
			throws BPMException, DataAccessException;
}



package com.healthpartners.service.imfs.writecsv;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.StringTokenizer;

import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.EmployerFulfillmentMemberActivity;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.EmployerFulfillmentMemberActivity;
 
public class GenerateEmplTrackingCsv
{

	protected final Log logger = LogFactory.getLog(getClass());
 
   public int generateCsvFile(Collection<EmployerFulfillmentMemberActivity> memberActivityCompletions, String pFilePath)
   {
	  
	   Calendar calDate = Calendar.getInstance();

       String calDateStr = BPMUtils.formatDateMMddyyyy(calDate);
       StringTokenizer strDate = new StringTokenizer(calDateStr, "/");
       String month = strDate.nextToken();
       String day = strDate.nextToken();
       String year = strDate.nextToken();
       
       String topLevelDir = "output_bpm/";
       File topLevelDirFile = new File(topLevelDir);
       if((topLevelDirFile.mkdirs())) {
           logger.info("Created directory: " + topLevelDirFile.getPath());
       }
	   String filePathWithFileName =  pFilePath + month + day + year + ".csv";
	   logger.info("GenerateEmplTrackingCSV: File path is " + filePathWithFileName);
	    int recsWritten = 0;
		try
		    
		{
			FileWriter writer = new FileWriter(filePathWithFileName);
			Iterator<EmployerFulfillmentMemberActivity> iter = (Iterator<EmployerFulfillmentMemberActivity>)memberActivityCompletions.iterator();
			writer = buildHeader(writer);
			while (iter.hasNext()) {
					EmployerFulfillmentMemberActivity employerFulfillmentMemberActivity = (EmployerFulfillmentMemberActivity)iter.next();
					writer = buildDetail(writer, employerFulfillmentMemberActivity);				    
				    recsWritten++;
			}
			 writer.flush();
			 writer.close();
		} catch(IOException e)
		{
		     e.printStackTrace();
		} 
		
		return recsWritten;
    }
   
 private FileWriter buildHeader(FileWriter fileWriterHeader) throws IOException {
	   
	   fileWriterHeader.append("ACTIVITY_CODE");
	   fileWriterHeader.append(',');
	   fileWriterHeader.append("EMPLOYEE_ID");
	   fileWriterHeader.append(',');
	   fileWriterHeader.append("ACTIVITY_COMPLETED_DATE");
	   fileWriterHeader.append('\n');
	   
	   return fileWriterHeader;
   }
 
 private FileWriter buildDetail(FileWriter fileWriterDetail, EmployerFulfillmentMemberActivity employerFulfillmentMemberActivity) throws IOException {
	   
	 fileWriterDetail.append(employerFulfillmentMemberActivity.getActivityCode());
	 fileWriterDetail.append(',');
	 fileWriterDetail.append(employerFulfillmentMemberActivity.getEmployeeID());
	 fileWriterDetail.append(',');
	 java.sql.Date activityCompletionDate  = employerFulfillmentMemberActivity.getActivityCompletionDate();
	 String formatDate = BPMUtils.formatDateMMddyyyy(activityCompletionDate);
	 fileWriterDetail.append(formatDate);
	 fileWriterDetail.append('\n');
	   
	 return fileWriterDetail;
   }
 
  
}
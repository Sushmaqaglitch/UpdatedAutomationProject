/**
 * 
 */
package com.healthpartners.service.imfs.dao;

import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.dto.BusinessProgramTO;
import com.healthpartners.service.imfs.rules.RuleAdapter;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.transaction.annotation.Transactional;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;
import java.io.InputStream;


/**
 * @author tjquist
 * 
 */
@Configuration
public class RuleGroupDAOJdbc extends JdbcDaoSupport implements RuleGroupDAO {

	//Spread sheetes containind JRules Decision tables
	public static final String XLS_FILE_CONTRACT_STATUS_RULES = "ruleResources/contractStatusRules.xls";

	public static final String XLS_FILE_MEMBER_STATUS_RULES = "ruleResources/memberStatusRules.xls";

	public static final String XLS_FILE_MEMBER_EXEMPTION_RULES = "ruleResources/memberExemptionRules.xls";


	protected final Log logger = LogFactory.getLog(getClass());

	/**
	 * Default Constructor
	 */
	public RuleGroupDAOJdbc() {
		super();
	}

	@Autowired
	DataSource bpmDataSource;


	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}

	/*
	 * @see com.healthpartners.service.bpm.dao.RuleGroupDAO#getContractStatusRules(com.healthpartners.service.bpm.dto.BusinessProgramTO)
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public RuleAdapter getContractStatusRules(BusinessProgramTO businessProgram)
			throws BPMException, DataAccessException {

		String rulesCsvText = getSpreadSheetFileContent(XLS_FILE_CONTRACT_STATUS_RULES);

		return new RuleAdapter(BPMConstants.RULESET_NAME_CONTRACT_STATUS,
				rulesCsvText);
	}

	/*
	 * @see com.healthpartners.service.bpm.dao.RuleGroupDAO#getExemptionRules(com.healthpartners.service.bpm.dto.BusinessProgramTO)
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public RuleAdapter getMemberExemptionRules(BusinessProgramTO businessProgram)
			throws BPMException, DataAccessException {

		String rulesCsvText = getSpreadSheetFileContent(XLS_FILE_MEMBER_EXEMPTION_RULES);

		return new RuleAdapter(BPMConstants.RULESET_NAME_MEMBER_EXEMPTION,
				rulesCsvText);
	}


	/*
	 * @see com.healthpartners.service.bpm.dao.RuleGroupDAO#getMemberStatusRules(com.healthpartners.service.bpm.dto.BusinessProgramTO)
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public RuleAdapter getMemberStatusRules(BusinessProgramTO businessProgram)
			throws BPMException, DataAccessException {

		String rulesCsvText = getSpreadSheetFileContent(XLS_FILE_MEMBER_STATUS_RULES);

		return new RuleAdapter(BPMConstants.RULESET_NAME_MEMBER_STATUS,
				rulesCsvText);
	}


	private String getSpreadSheetFileContent(String fileWrtClassPath) throws BPMException {
		InputStream inputStream = null;
		String content = null;
		try {
			inputStream = this.getClass().getClassLoader().getResourceAsStream(fileWrtClassPath);
			//SpreadsheetCompiler compiler = new SpreadsheetCompiler();
			//content = compiler.compile(inputStream, InputType.XLS);
			//logger.info("File content of "+ fileWrtClassPath +" =" + content);
		} catch (Exception e) {
			logger.info("BPMException occured=" + e.getMessage());
			throw new BPMException(e);
		}
		return content;
	}
	
/*	private String getCsvFileContent(String fileWrtClassPath) throws BPMException {
		InputStream inputStream = null;
		String content = null;
		try {
			inputStream = this.getClass().getClassLoader().getResourceAsStream(fileWrtClassPath);
			SpreadsheetCompiler compiler = new SpreadsheetCompiler();
			content = compiler.compile(inputStream, InputType.CSV);
			//logger.info("File content of "+ fileWrtClassPath +" =" + content);
		} catch (Exception e) {
			logger.error("BPMException occured=" + e.getMessage());
			throw new BPMException(e);
		}
		return content;
	}*/
	
/*	*//**
	 * reads the file content
	 * 
	 * @param fileWrtClassPath
	 * @return
	 * @throws BPMException
	 *//*
	private String getFileContent(String fileWrtClassPath) throws BPMException {
		InputStream inputStream = null;
		String content = null;
		try {
			inputStream = this.getClass().getClassLoader().getResourceAsStream(fileWrtClassPath);
			//int x = inputStream.available();
			//byte b[] = new byte[x];
			//inputStream.read(b);
			//content = new String(b);
			SpreadsheetCompiler compiler = new SpreadsheetCompiler();
			content = compiler.compile(inputStream, InputType.XLS);
			//content = compiler.compile(inputStream, InputType.CSV);
			//logger.info("File content of "+ fileWrtClassPath +" =" + content);
		} catch (Exception e) {
			logger.error("BPMException occured=" + e.getMessage());
			throw new BPMException(e);
		}

		return content;
	}*/
}

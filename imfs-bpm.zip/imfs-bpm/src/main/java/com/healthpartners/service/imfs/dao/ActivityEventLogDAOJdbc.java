package com.healthpartners.service.imfs.dao;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.*;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.exception.BPMException;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;


/**
 * @author tjquist
 * 
 */
@Configuration
public class ActivityEventLogDAOJdbc extends JdbcDaoSupport implements
		ActivityEventLogDAO {


	protected final Log logger = LogFactory.getLog(getClass());
	

	/*
	 * SQL statements
	 */
	private String insertActivityEventLog;
	
	private String insertEmployerAdministeredActivity;

	private String updateActivityLogProcessingStatus;

	private String deleteActivityEventLog;

	private String getActivityEventLog;

	private String selectPendingActivityEvents;
	
	private String selectNumberOfPendingActivities;
	
	private String selectNumberOfFilteredActivities;
	
	private String selectCompleteActivityEventsSentInAtSameTimeAsActiveOrCancel;
	
	private String updateActivityLogByAdvancingTimestamp;
	
    private String selectMemberActivityEventLog;
    
    private String selectActivityEventLogs;
    
    private String selectActivityEventLogsByGroup;
    
    private String updateQualifyingFilteredOutActivityEventsToPending;
    
    private String insertMemberActivityBasedOnPreconditionByGroup;
	

	/*
	 * SQL sequences
	 */
	@Autowired
	private DataFieldMaxValueIncrementer activityEventLogIdIncrementer;

	/**
	 * 
	 */
	public ActivityEventLogDAOJdbc() {
		super();
	}

	@Autowired
	DataSource bpmDataSource;


	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}

	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public Long insertActivityEventLog(ActivityEvent activityEvent)
			throws DataAccessException {
		
		boolean lActivityEventExists = false;
		Long lExistingActivityEventLogID = (long)0;
		// Check if this activity-registration-status-date already exists
		ArrayList<ActivityEvent> lExistingActivities = (ArrayList<ActivityEvent>) 
		    getMemberActivityEventLogActivity(activityEvent.getMemberID()
				, activityEvent.getMemberActivity().getActivity().getSourceActivityID()
				, activityEvent.getMemberActivity().getRegistrationID());
		
		
		for(ActivityEvent lExistingActivity : lExistingActivities)
		{			
			if(activityEvent.getMemberActivity().getActivityStatus().getStatusCodeValue().equalsIgnoreCase(
			lExistingActivity.getMemberActivity().getActivityStatus().getStatusCodeValue()))
			{
				lActivityEventExists = true;
				lExistingActivityEventLogID = lExistingActivity.getActivityEventLogID();
				break;
			}			
		}
		
		if(lActivityEventExists == true)
		{
			return lExistingActivityEventLogID;
		}
		
		// Retrieve the next sequence number for the ActivityEventLog.
		Long activityEventLogId = new Long(activityEventLogIdIncrementer
				.nextLongValue());

		// Persist the ActivityEventLog.
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {
				activityEventLogId,
				activityEvent.getProcessingStatusValue(),
				activityEvent.getMemberID(),
				(activityEvent.getMemberActivity() != null && activityEvent
						.getMemberActivity().getActivity() != null) ? activityEvent
						.getMemberActivity().getActivity()
						.getSourceActivityID()
						: null,
				activityEvent.getMemberActivity() != null ? activityEvent
						.getMemberActivity().getRegistrationID() : null,
				activityEvent.getSourceSystemID(),
				activityEvent.getMemberActivity() != null ? activityEvent
						.getMemberActivity().getAuthPromoCode() : null,
				(activityEvent.getMemberActivity() != null && activityEvent
						.getMemberActivity().getActivityStatus() != null) ? activityEvent
						.getMemberActivity().getActivityStatus()
						.getStatusCodeValue()
						: null,
				(activityEvent.getMemberActivity() != null && activityEvent
						.getMemberActivity().getActivityStatus() != null) ? activityEvent
						.getMemberActivity().getActivityStatus()
						.getStatusEffectiveDate()
						: null,
				(activityEvent.getMemberActivity() != null && activityEvent
						.getMemberActivity().getActivityStatus() != null) ? activityEvent
						.getMemberActivity().getActivityStatus().getOutCome()
						: null, activityEvent.getInsertUserId() };
		int types[] = new int[] { Types.BIGINT, Types.VARCHAR, Types.VARCHAR,
				Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
				Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR };
		template.update(insertActivityEventLog, params, types);

		return activityEventLogId;
	}
	
	
	/**
	 * 
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public int insertEmployerAdministeredActivity(EmployerSponsoredActivity lEmployerSponsoredActivity, String userID)
	throws DataAccessException
	{
		JdbcTemplate template = getJdbcTemplate();

		Long activityEventLogId = new Long(activityEventLogIdIncrementer
				.nextLongValue());
		
		
		
		Calendar lToday = Calendar.getInstance();
		
		if(lEmployerSponsoredActivity.getRegistrationID() == null || lEmployerSponsoredActivity.getRegistrationID().length() <=0)
		{
			lEmployerSponsoredActivity.setRegistrationID(lEmployerSponsoredActivity.getMemberID()
			    + "-" + BPMUtils.formatDateMMddyyyyNoDel(lToday));
		}
		
		
		Object params[] = new Object[] 
		        {				
				activityEventLogId,
				BPMConstants.PROCESSING_STATUS_PENDING, //processing status value
				lEmployerSponsoredActivity.getMemberID(),
				lEmployerSponsoredActivity.getSourceActivityID(),
				lEmployerSponsoredActivity.getRegistrationID(),
				lEmployerSponsoredActivity.getSourceSystemID(), 
				BPMConstants.ACTIVITY_STATUS_COMPLETE,
				BPMUtils.convertStringToSqlDate(lEmployerSponsoredActivity.getActivityDate(), BPMConstants.HP_BPM_COMMON_DATE_FORMAT),
				userID,
				lEmployerSponsoredActivity.getReasonDesc(),
				lEmployerSponsoredActivity.getAuthCode(),
				lEmployerSponsoredActivity.getAmountEarned(),
				lEmployerSponsoredActivity.getDependentID(),
				userID				
				};

		int types[] = new int[] {Types.BIGINT,
				Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, 				
				Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR,   
				Types.VARCHAR,  Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };

		int retValue = template.update(insertEmployerAdministeredActivity, params, types);
		
		return retValue;
	}

	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public int updateActivityLogProcessingStatus(ActivityEvent activityEvent)
			throws DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {
				activityEvent.getProcessingStatusValue(),
				activityEvent.getReasonDescription(),
				activityEvent.getModifyUserId(),
				activityEvent.getActivityEventLogID()};
		int types[] = new int[] { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT };
		return template
				.update(updateActivityLogProcessingStatus, params, types);
	}

	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public int deleteActivityEventLog(Long activityEventLogID)
			throws DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { activityEventLogID };
		int types[] = new int[] { Types.BIGINT };
		return template.update(deleteActivityEventLog, params, types);
	}

	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public ActivityEvent getActivityEventLog(Long activityEventLogID)
			throws DataAccessException {
		final ArrayList<ActivityEvent> results = new ArrayList<ActivityEvent>();
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { activityEventLogID };
		int types[] = new int[] { Types.BIGINT };
		template.query(getActivityEventLog, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						ActivityEvent activityEvent = new ActivityEvent();
						activityEvent.setActivityEventLogID(Long.valueOf(rs.getLong("ACTV_EVNT_LOG_ID")));
						activityEvent.setProcessingStatusValue(rs.getString("PRCSNG_STAT_VAL"));
						activityEvent.setMemberID(rs.getString("HP_MEM_ID"));
						activityEvent.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
						activityEvent.setExternalPersonID(rs.getString("EXT_PRSN_ID"));
						
						
						ActivityDefinition activityDefinition = new ActivityDefinition();
						MemberActivity memberActivity = new MemberActivity();
						memberActivity.setActivity(activityDefinition);
						activityDefinition.setActivityID(rs.getInt("actv_id"));
						activityDefinition.setSourceActivityID(rs.getString("srce_actv_id"));

						memberActivity.setRegistrationID(rs.getString("REGISTRATION_ID"));
						activityEvent.setSourceSystemID(rs.getString("SRCE_SYSTM_ID"));
						memberActivity.setAuthPromoCode(rs.getString("AUTH_CD"));
						memberActivity.setContributionAmt(rs.getInt("CONTRIB_AMT"));

						GenericStatusType personActivityStatus = new GenericStatusType();
						personActivityStatus
								.setStatusCodeValue(rs.getString("STAT_CD"));
						personActivityStatus.setStatusEffectiveDate(BPMUtils.dateToCalendar(rs.getDate("STAT_EFF_DT")));												
						
						personActivityStatus.setOutCome(rs.getString("STAT_OUTCM"));
						
						activityDefinition.setActivityTypeValue(rs.getString("ACTV_TP_CD"));

						memberActivity.setActivityStatus(personActivityStatus);

						activityEvent.setMemberActivity(memberActivity);

						results.add(activityEvent);
					}
				});

		ActivityEvent dto = null;
		if (results.size() > 0) {
			dto = (ActivityEvent) results.get(0);
		}
		return dto;
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public Collection<Long> getPendingActivityEventLogIDs(int batchSize)
			throws DataAccessException {
		final ArrayList<Long> results = new ArrayList<Long>();
		JdbcTemplate template = getJdbcTemplate();
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectPendingActivityEvents);

		if (batchSize > 0) {
			lQuery.append(" AND ROWNUM <= " + batchSize + " ");
		}

		template.query(lQuery.toString(), new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				results.add(Long.valueOf(rs.getLong(1)));
			}
		});

		return results;
	}
	
	/*
	 * Check for COMPLETE activity events sent in at same time as ACTIVE or CANCEL activities and
	 * update insert timestamp by advancing by a minute. 
	 * 
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public  int processCompleteActivityEventsSentInAtSameTimeAsActiveOrCancel() throws DataAccessException {
		final ArrayList<Integer> results = new ArrayList<Integer>();
		JdbcTemplate template = getJdbcTemplate();
		template.query(selectCompleteActivityEventsSentInAtSameTimeAsActiveOrCancel,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						results.add(rs.getInt("actv_evnt_log_id"));
					}
				});

		Integer activityEventLogId = 0;
		if (results.size() > 0) {
			Iterator<Integer> activityEventLogIds = (Iterator<Integer>)results.iterator();
			while (activityEventLogIds.hasNext()) {
				activityEventLogId = activityEventLogIds.next();
				logger.info("@@processCompleteActivityEventsSentInAtSameTimeAsActiveOrCancel: update activityEventLogId =" + activityEventLogId);
				updateActivityLogByAdvancingTimestamp(activityEventLogId);
			}
		}
		int numberOfActivityEventTSUpdates = results.size();
		return numberOfActivityEventTSUpdates;

	}

	
	/**
	 * Advance timestamp by a minute on Complete Activity Events where an Active or Cancel was sent in at the same time.  
	 * A Complete Activity Event has to be the last transaction sent in after a Active or Cancel.
	 */
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	private int updateActivityLogByAdvancingTimestamp(Integer activityEventLogId)
			throws DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {
				activityEventLogId };
		int types[] = new int[] { Types.INTEGER };
		return template
				.update(updateActivityLogByAdvancingTimestamp, params, types);
	}


	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public int getNumberOfPendingActivityEvents() throws DataAccessException {
		final ArrayList<Integer> results = new ArrayList<Integer>();
		JdbcTemplate template = getJdbcTemplate();
		template.query(selectNumberOfPendingActivities,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						results.add(new Integer(rs.getInt(1)));
					}
				});

		int numberOfPendingActivities = 0;
		if (results.size() > 0) {
			numberOfPendingActivities = results.get(0).intValue();
		}

		return numberOfPendingActivities;

	}
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public int getNumberOfFilteredActivityEvents(String reasonCode, int daySpan) throws DataAccessException {
		final ArrayList<Integer> results = new ArrayList<Integer>();
		JdbcTemplate template = getJdbcTemplate();
		
		//calc date looking back x days.
		java.util.Calendar cal = java.util.Calendar.getInstance();
		cal.add(Calendar.DATE, daySpan);
		java.util.Date convDate = cal.getTime();
		java.sql.Date sqlDate = new java.sql.Date(convDate.getTime());
	    
		
		Object params[] = new Object[] {reasonCode, sqlDate };
		
		int types[] = new int[] {Types.CHAR, Types.DATE };
		
		template.query(selectNumberOfFilteredActivities, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						results.add(new Integer(rs.getInt(1)));
					}
				});

		int numberOfFilteredActivities = 0;
		if (results.size() > 0) {
			numberOfFilteredActivities = results.get(0).intValue();
		}

		return numberOfFilteredActivities;

	}
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public int updateQualifyingFilteredOutActivityEventsToPending(String reasonCode, int daySpan) throws DataAccessException {
		final ArrayList<Integer> results = new ArrayList<Integer>();
		JdbcTemplate template = getJdbcTemplate();
		
		//calc date looking back x days.
		java.util.Calendar cal = java.util.Calendar.getInstance();
		cal.add(Calendar.DATE, daySpan);
		java.util.Date convDate = cal.getTime();
		java.sql.Date sqlDate = new java.sql.Date(convDate.getTime());
	    
		
		Object params[] = new Object[] {reasonCode, sqlDate };
		
		int types[] = new int[] {Types.CHAR, Types.DATE };
		
		
		return template
					.update(updateQualifyingFilteredOutActivityEventsToPending, params, types);
	}
	
	/**
	 * Return all the activity event log entries for the given member ID, source activity ID, and registration ID.
	 * (i.e. all the other events for the same member activity)
	 *  
	 * @param pMemberID
	 * @param pSourceActivityID
	 * @return
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public Collection<ActivityEvent> 
	getMemberActivityEventLogActivity(String pMemberID, String pSourceActivityID, Date pActivityDate)
	{
		Object params[] = new Object[] { pMemberID, pSourceActivityID, pActivityDate };
		int types[] = new int[] { Types.VARCHAR, Types.VARCHAR, Types.DATE };
		JdbcTemplate template = getJdbcTemplate();
		StringBuffer lQuery = new StringBuffer();
		
		lQuery.append(selectMemberActivityEventLog);
		lQuery.append(" AND actv_id = ?");
		lQuery.append(" AND stat_eff_dt = ?");

		final ArrayList<ActivityEvent> lActivityEvents = new ArrayList<ActivityEvent>();
		
		template.query(lQuery.toString(), params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException 
					{
						ActivityEvent lActivityEvent = new ActivityEvent();						
						MemberActivity lMemberActivity = new MemberActivity();
						GenericStatusType lActivityStatus = new GenericStatusType();
						lMemberActivity.setActivityStatus(lActivityStatus);
						if (rs.getString("CONTRIB_AMT") !=null && !rs.getString("CONTRIB_AMT").isEmpty()) {
							lMemberActivity.setContributionAmt(Integer.valueOf(rs.getString("CONTRIB_AMT")));
						} 
						lActivityEvent.setMemberActivity(lMemberActivity);
						ActivityDefinition lActivityDefinition = new ActivityDefinition();						
						lMemberActivity.setActivity(lActivityDefinition);
						
						lActivityEvent.setActivityEventLogID(rs.getLong("ACTV_EVNT_LOG_ID"));
						lActivityDefinition.setSourceActivityID(rs.getString("actv_id"));						
						lMemberActivity.setAuthPromoCode(rs.getString("auth_cd"));
						Calendar lCompletionDate = Calendar.getInstance();
						lCompletionDate.setTime(rs.getDate("stat_eff_dt"));
						lMemberActivity.setCompletionDate(lCompletionDate);						
						lMemberActivity.setRegistrationID(rs.getString("registration_id"));
						
						lActivityStatus.setStatusCodeValue(rs.getString("stat_cd"));
						
						lActivityEvent.setProcessingStatusValue(rs.getString("PRCSNG_STAT_VAL"));
						

						lActivityEvents.add(lActivityEvent);
					}
				});
		
		return lActivityEvents;
	}
	
	/**
	 * Return all the activity event log entries for the given member ID, source activity ID, and registration ID.
	 * (i.e. all the other events for the same member activity)
	 *  
	 * @param pMemberID
	 * @param pSourceActivityID
	 * @param pRegistrationID
	 * @return
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public Collection<ActivityEvent> 
	getMemberActivityEventLogActivity(String pMemberID, String pSourceActivityID, String pRegistrationID)
	{
		Object params[] = new Object[] { pMemberID, pSourceActivityID, pRegistrationID };
		int types[] = new int[] { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };
		JdbcTemplate template = getJdbcTemplate();
		StringBuffer lQuery = new StringBuffer();
		
		lQuery.append(selectMemberActivityEventLog);
		lQuery.append(" AND actv_id = ?");
		lQuery.append(" AND registration_id = ?");

		final ArrayList<ActivityEvent> lActivityEvents = new ArrayList<ActivityEvent>();
		
		template.query(lQuery.toString(), params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException 
					{
						ActivityEvent lActivityEvent = new ActivityEvent();						
						MemberActivity lMemberActivity = new MemberActivity();
						GenericStatusType lActivityStatus = new GenericStatusType();
						lMemberActivity.setActivityStatus(lActivityStatus);
						 
						lActivityEvent.setMemberActivity(lMemberActivity);
						ActivityDefinition lActivityDefinition = new ActivityDefinition();						
						lMemberActivity.setActivity(lActivityDefinition);
						
						lActivityEvent.setActivityEventLogID(rs.getLong("ACTV_EVNT_LOG_ID"));
						lActivityEvent.setProcessingStatusValue(rs.getString("PRCSNG_STAT_VAL"));
						lActivityEvent.setMemberID(rs.getString("hp_mem_id"));
						lActivityDefinition.setSourceActivityID(rs.getString("actv_id"));
						lMemberActivity.setRegistrationID(rs.getString("registration_id"));						
						lMemberActivity.setAuthPromoCode(rs.getString("auth_cd"));
						lActivityStatus.setStatusCodeValue(rs.getString("stat_cd"));
						Calendar lCompletionDate = Calendar.getInstance();
						lCompletionDate.setTime(rs.getDate("stat_eff_dt"));
						lMemberActivity.setCompletionDate(lCompletionDate);
						lMemberActivity.getActivityStatus().setOutCome(rs.getString("STAT_OUTCM"));
						
						if (rs.getString("CONTRIB_AMT") !=null && !rs.getString("CONTRIB_AMT").isEmpty()) {
							lMemberActivity.setContributionAmt(Integer.valueOf(rs.getString("CONTRIB_AMT")));
						}
						
						lActivityEvents.add(lActivityEvent);
					}
				});
		
		return lActivityEvents;
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public Collection<ActivityEvent> getActivityEventLogsByProcessingStatus(String processingStatus, java.sql.Date lActivityEventCutoffDate, boolean twoDaysNolderFlag, String sourceSystemID) 
				throws DataAccessException {
		
		ArrayList<Integer> lTypes = new ArrayList<Integer>();	
		ArrayList<Object> lParameters = new ArrayList<Object>();
		
		lParameters.add(processingStatus);
	    lTypes.add(new Integer(Types.VARCHAR));
	    lParameters.add(lActivityEventCutoffDate);
	    lTypes.add(new Integer(Types.DATE));
		
		
		JdbcTemplate template = getJdbcTemplate();
		StringBuffer lQuery = new StringBuffer();
		
		lQuery.append(selectActivityEventLogs);
		lQuery.append(" WHERE prcsng_stat_val = ?");
		lQuery.append(" AND trunc(insert_ts) >= ?");
		
		if (twoDaysNolderFlag) {
			//select 2 days and older
			lQuery.append("AND trunc(insert_ts) <= trunc(sysdate) - 2");
		}
		
		if (sourceSystemID != null && sourceSystemID.length() > 0) {
			lParameters.add(sourceSystemID);
		    lTypes.add(new Integer(Types.VARCHAR));
			lQuery.append("AND srce_systm_id = ?");
		}
		
		 // Convert the parameter and types ArrayLists to arrays of primitive types. 
	    Object params[] = new Object[lParameters.size()];
	    lParameters.toArray(params);

	    int types[] = new int[lTypes.size()];
	    for(int j = 0; j < lTypes.size(); j++)
	    {
	    	types[j] = ((Integer)lTypes.get(j)).intValue();
	    }

		final ArrayList<ActivityEvent> lActivityEvents = new ArrayList<ActivityEvent>();
		
		template.query(lQuery.toString(), params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException 
					{
						ActivityEvent lActivityEvent = new ActivityEvent();						
						MemberActivity lMemberActivity = new MemberActivity();
						GenericStatusType lActivityStatus = new GenericStatusType();
						lMemberActivity.setActivityStatus(lActivityStatus);
						if (rs.getString("CONTRIB_AMT") !=null && !rs.getString("CONTRIB_AMT").isEmpty()) {
							lMemberActivity.setContributionAmt(Integer.valueOf(rs.getString("CONTRIB_AMT")));
						} 
						lActivityEvent.setMemberActivity(lMemberActivity);
						ActivityDefinition lActivityDefinition = new ActivityDefinition();						
						lMemberActivity.setActivity(lActivityDefinition);
						
						lActivityEvent.setActivityEventLogID(rs.getLong("ACTV_EVNT_LOG_ID"));
						lActivityDefinition.setSourceActivityID(rs.getString("actv_id"));						
						lMemberActivity.setAuthPromoCode(rs.getString("auth_cd"));
						Calendar lCompletionDate = Calendar.getInstance();
						lCompletionDate.setTime(rs.getDate("stat_eff_dt"));
						lMemberActivity.setCompletionDate(lCompletionDate);						
						lMemberActivity.setRegistrationID(rs.getString("registration_id"));
						
						lActivityStatus.setStatusCodeValue(rs.getString("stat_cd"));
						
						lActivityEvent.setProcessingStatusValue(rs.getString("PRCSNG_STAT_VAL"));
						

						lActivityEvents.add(lActivityEvent);
					}
				});
		
		return lActivityEvents;
		
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public Collection<ActivityEvent> getActivityEventLogsByGroup(String groupNo, String siteNo, String memberNo, java.sql.Date lActivityEventCutoffDate, String sourceSystemID) 
			throws DataAccessException {
	
	ArrayList<Integer> lTypes = new ArrayList<Integer>();	
	ArrayList<Object> lParameters = new ArrayList<Object>();
	
	lParameters.add(groupNo);
    lTypes.add(new Integer(Types.VARCHAR));
    lParameters.add(lActivityEventCutoffDate);
    lTypes.add(new Integer(Types.DATE));
	
	
	JdbcTemplate template = getJdbcTemplate();
	StringBuffer lQuery = new StringBuffer();
	
	lQuery.append(selectActivityEventLogsByGroup);
	
	if (sourceSystemID != null && sourceSystemID.length() > 0) {
		lParameters.add(sourceSystemID);
	    lTypes.add(new Integer(Types.VARCHAR));
		lQuery.append("AND srce_systm_id = ?");
	}
	
	if (siteNo != null && siteNo.length() > 0) {
		lParameters.add(siteNo);
	    lTypes.add(new Integer(Types.VARCHAR));
		lQuery.append("AND egs.empl_grp_site_id_no = ?");
	}
	
	if (memberNo != null && memberNo.length() > 0) {
		lParameters.add(memberNo);
	    lTypes.add(new Integer(Types.VARCHAR));
		lQuery.append("AND pd.hp_mem_id = ?");
	}
	
	lQuery.append("order by  t.HP_MEM_ID, t.actv_id");
	
	 // Convert the parameter and types ArrayLists to arrays of primitive types. 
    Object params[] = new Object[lParameters.size()];
    lParameters.toArray(params);

    int types[] = new int[lTypes.size()];
    for(int j = 0; j < lTypes.size(); j++)
    {
    	types[j] = ((Integer)lTypes.get(j)).intValue();
    }

	final ArrayList<ActivityEvent> lActivityEvents = new ArrayList<ActivityEvent>();
	
	template.query(lQuery.toString(), params, types,
			new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException 
				{
					ActivityEvent lActivityEvent = new ActivityEvent();						
					MemberActivity lMemberActivity = new MemberActivity();
					GenericStatusType lActivityStatus = new GenericStatusType();
					lMemberActivity.setActivityStatus(lActivityStatus);
					if (rs.getString("CONTRIB_AMT") !=null && !rs.getString("CONTRIB_AMT").isEmpty()) {
						lMemberActivity.setContributionAmt(Integer.valueOf(rs.getString("CONTRIB_AMT")));
					} 
					
					ActivityDefinition lActivityDefinition = new ActivityDefinition();						
					lMemberActivity.setActivity(lActivityDefinition);
					
					lActivityDefinition.setSourceActivityID(rs.getString("srce_actv_id"));	
					lActivityDefinition.setActivityID(rs.getInt("actv_id"));
					lActivityDefinition.setActivityTypeCodeID(rs.getInt("actv_tp_cd_id"));
					lActivityDefinition.setName(rs.getString("actv_nm"));
					lActivityDefinition.setSourceActivityID(rs.getString("srce_actv_id"));
					lMemberActivity.setAuthPromoCode(rs.getString("auth_cd"));
					Calendar lCompletionDate = Calendar.getInstance();
					lCompletionDate.setTime(rs.getDate("stat_eff_dt"));
					lMemberActivity.setCompletionDate(lCompletionDate);						
					lMemberActivity.setRegistrationID(rs.getString("registration_id"));
					
					lActivityStatus.setStatusCodeValue(rs.getString("stat_cd"));
					
					lActivityEvent.setProcessingStatusValue(rs.getString("PRCSNG_STAT_VAL"));
					
					lMemberActivity.setGroupNo(rs.getString("EMPL_GRP_NO"));
					lMemberActivity.setSiteNo(rs.getString("EMPL_GRP_SITE_ID_NO"));
					lMemberActivity.setGroupName(rs.getString("EMPL_GRP_NM"));
					lMemberActivity.setSiteName(rs.getString("Empl_Grp_Site_Nm"));
					lMemberActivity.setReasonDesc(rs.getString("RSN_DESC"));
					lMemberActivity.setMemberID(rs.getString("HP_MEM_ID"));
					lMemberActivity.setSourceSystemID(rs.getString("SRCE_SYSTM_ID"));
					lMemberActivity.setBusinessProgramID(rs.getInt("biz_pgm_id"));
					lMemberActivity.setPersonID(rs.getInt("prsn_id"));
					lMemberActivity.setPersonDemographicsID(rs.getInt("prsn_dmgrphcs_id"));
					lActivityEvent.setPersonDemographicsID(lMemberActivity.getPersonDemographicsID());
					lActivityEvent.setPurchaserSubtypeName(rs.getString("purch_sub_tp_nm"));
					
					
					lActivityEvent.setMemberActivity(lMemberActivity);
					

					lActivityEvents.add(lActivityEvent);
				}
			});
	
	return lActivityEvents;
	
}
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public int insertMemberActivityBasedOnPreconditionByGroup(String groupNo, String siteNo, Integer programIncentiveOptionID, String sourceActivityID)
			throws DataAccessException {
	
		final ArrayList<String> results = new ArrayList<String>();
		Object params[] = new Object[] { sourceActivityID, groupNo,  siteNo, programIncentiveOptionID, groupNo,  siteNo, sourceActivityID};
		JdbcTemplate template = getJdbcTemplate();
		int types[] = new int[] { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };
		
		int recordsInsertedCt = template.update(insertMemberActivityBasedOnPreconditionByGroup, params, types);
	
		
		return recordsInsertedCt;
	}

	/**
	 * Sets the insertActivityEventLog SQL statement. Should only be called by
	 * Spring.
	 *
	 */
	public void setInsertActivityEventLog(String sql) {
		this.insertActivityEventLog = sql;
	}
	
	

	public void setInsertEmployerAdministeredActivity(
			String insertEmployerAdministeredActivity) {
		this.insertEmployerAdministeredActivity = insertEmployerAdministeredActivity;
	}

	/**
	 * Sets the updateActivityLogProcessingStatus SQL statement. Should only be
	 * called by Spring.
	 *
	 */
	public void setUpdateActivityLogProcessingStatus(String sql) {
		this.updateActivityLogProcessingStatus = sql;
	}

	/**
	 * Sets the deleteActivityEventLog SQL statement. Should only be called by
	 * Spring.
	 *
	 */
	public void setDeleteActivityEventLog(String sql) {
		this.deleteActivityEventLog = sql;
	}

	/**
	 * Sets the getActivityEventLog SQL statement. Should only be called by
	 * Spring.
	 *
	 */
	public void setGetActivityEventLog(String sql) {
		this.getActivityEventLog = sql;
	}

	/**
	 * Sets the Incrementer. Should only be called by Spring.
	 *
	 */
	public void setActivityEventLogIdIncrementer(
			DataFieldMaxValueIncrementer incrementer) {
		this.activityEventLogIdIncrementer = incrementer;
	}

	public String getSelectPendingActivityEvents() {
		return selectPendingActivityEvents;
	}

	public void setSelectPendingActivityEvents(String sql) {
		this.selectPendingActivityEvents = sql;
	}

	public String getSelectNumberOfPendingActivities() {
		return selectNumberOfPendingActivities;
	}

	public void setSelectNumberOfPendingActivities(
			String selectNumberOfPendingActivities) {
		this.selectNumberOfPendingActivities = selectNumberOfPendingActivities;
	}

	public String getSelectNumberOfFilteredActivities() {
		return selectNumberOfFilteredActivities;
	}

	public void setSelectNumberOfFilteredActivities(
			String selectNumberOfFilteredActivities) {
		this.selectNumberOfFilteredActivities = selectNumberOfFilteredActivities;
	}

	public final String getSelectCompleteActivityEventsSentInAtSameTimeAsActiveOrCancel() {
		return selectCompleteActivityEventsSentInAtSameTimeAsActiveOrCancel;
	}

	public final void setSelectCompleteActivityEventsSentInAtSameTimeAsActiveOrCancel(
			String selectCompleteActivityEventsSentInAtSameTimeAsActiveOrCancel) {
		this.selectCompleteActivityEventsSentInAtSameTimeAsActiveOrCancel = selectCompleteActivityEventsSentInAtSameTimeAsActiveOrCancel;
	}

	public final String getUpdateActivityLogByAdvancingTimestamp() {
		return updateActivityLogByAdvancingTimestamp;
	}

	public final void setUpdateActivityLogByAdvancingTimestamp(
			String updateActivityLogByAdvancingTimestamp) {
		this.updateActivityLogByAdvancingTimestamp = updateActivityLogByAdvancingTimestamp;
	}

	public final String getUpdateActivityLogProcessingStatus() {
		return updateActivityLogProcessingStatus;
	}

	public void setSelectActivityEventLogs(String selectActivityEventLogs) {
		this.selectActivityEventLogs = selectActivityEventLogs;
	}

	public String getSelectMemberActivityEventLog() {
		return selectMemberActivityEventLog;
	}

	public void setSelectMemberActivityEventLog(String selectMemberActivityEventLog) {
		this.selectMemberActivityEventLog = selectMemberActivityEventLog;
	}

	public void setSelectActivityEventLogsByGroup(
			String selectActivityEventLogsByGroup) {
		this.selectActivityEventLogsByGroup = selectActivityEventLogsByGroup;
	}


	public void setUpdateQualifyingFilteredOutActivityEventsToPending(
			String updateQualifyingFilteredOutActivityEventsToPending) {
		this.updateQualifyingFilteredOutActivityEventsToPending = updateQualifyingFilteredOutActivityEventsToPending;
	}

	public void setInsertMemberActivityBasedOnPreconditionByGroup(String insertMemberActivityBasedOnPreconditionByGroup) {
		this.insertMemberActivityBasedOnPreconditionByGroup = insertMemberActivityBasedOnPreconditionByGroup;
	}

	
	

	
}

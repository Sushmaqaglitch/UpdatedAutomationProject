package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.util.Calendar;

public class MemberStatus implements Serializable
{
	static final long serialVersionUID = 0L;
	
	public MemberStatus()
	{
		super();
	}

	private Calendar benefitYearStartDate;
    private String benefitLevel;
    private GenericStatusType status;
    
    public String getBenefitLevel() {
		return benefitLevel;
	}

	public void setBenefitLevel(String benefitLevel) {
		this.benefitLevel = benefitLevel;
	}

	public Calendar getBenefitYearStartDate() {
		return benefitYearStartDate;
	}

	public void setBenefitYearStartDate(Calendar benefitYearStartDate) {
		this.benefitYearStartDate = benefitYearStartDate;
	}

	public GenericStatusType getStatus() {
		return status;
	}

	public void setStatus(GenericStatusType status) {
		this.status = status;
	}		
}

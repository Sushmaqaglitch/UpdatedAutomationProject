package com.healthpartners.service.imfs.dto;

import java.util.Calendar;

public class Contract 
{
	private Integer contractNumber;
	
	private Calendar contractEffectiveDate;
	private Calendar contractEndDate;
	private GenericStatusType contractStatus;
	private Integer policyHolderNumber;
	
	public Contract()
	{
		super();
	}	

	public Integer getContractNumber() {
		return contractNumber;
	}

	public void setContractNumber(Integer contractNumber) {
		this.contractNumber = contractNumber;
	}
	
	public GenericStatusType getContractStatus() {
		return contractStatus;
	}

	public void setContractStatus(GenericStatusType contractStatus) {
		this.contractStatus = contractStatus;
	}

	public Calendar getContractEffectiveDate() {
		return contractEffectiveDate;
	}

	public void setContractEffectiveDate(Calendar contractEffectiveDate) {
		this.contractEffectiveDate = contractEffectiveDate;
	}

	public Calendar getContractEndDate() {
		return contractEndDate;
	}

	public void setContractEndDate(Calendar contractEndDate) {
		this.contractEndDate = contractEndDate;
	}

	public Integer getPolicyHolderNumber() {
		return policyHolderNumber;
	}

	public void setPolicyHolderNumber(Integer policyHolderNumber) {
		this.policyHolderNumber = policyHolderNumber;
	}			
}

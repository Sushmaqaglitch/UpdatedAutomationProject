/**
 * 
 */
package com.healthpartners.service.imfs.dto;

import java.util.Calendar;

/**
 * Used for member exemptions
 * @author tjquist
 * 
 */
public class QualificationOverride extends BaseAuditableDTO {

	static final long serialVersionUID = 0L;

	private Integer personID;

	private Integer programID;
	
	private Integer programIncentiveOptionID;

	//	BPM_TYPE_OVERRIDE - luv grp
	private String overrideType; 

	// BPMConstants.OVERRIDE_CODE_EXEMPTION,BPMConstants.OVERRIDE_CODE_MANUAL_EXEMPTION,
	private String overrideCode;

	private String reasonCode;

	private Calendar issueDate;

	private Long id; // database id
	
	private Integer contractNo;

	/**
	 * 
	 */
	public QualificationOverride() {
		super();
	}

	/**
	 * @param personID
	 * @param programID
	 * @param overrideType
	 * @param overrideCode
	 * @param reasonCode
	 */
	public QualificationOverride(Integer personID, Integer programID,
			String overrideType, String overrideCode, String reasonCode) {
		super();
		this.personID = personID;
		this.programID = programID;
		this.overrideType = overrideType;
		this.overrideCode = overrideCode;
		this.reasonCode = reasonCode;
		this.issueDate = Calendar.getInstance();
	}

	/**
	 * @param personID
	 * @param programID
	 * @param overrideType
	 * @param overrideCode
	 * @param reasonCode
	 * @param issueDate
	 */
	public QualificationOverride(Integer personID, Integer programID,
			String overrideType, String overrideCode, String reasonCode,
			Calendar issueDate) {
		super();
		this.personID = personID;
		this.programID = programID;
		this.overrideType = overrideType;
		this.overrideCode = overrideCode;
		this.reasonCode = reasonCode;
		this.issueDate = issueDate;
	}


	/**
	 * @return the overrideType
	 */
	public String getOverrideType() {
		return overrideType;
	}

	/**
	 * @param overrideType
	 *            the overrideType to set
	 */
	public void setOverrideType(String overrideType) {
		this.overrideType = overrideType;
	}

	/**
	 * @return the personID
	 */
	public Integer getPersonID() {
		return personID;
	}

	/**
	 * @param personID
	 *            the personID to set
	 */
	public void setPersonID(Integer personID) {
		this.personID = personID;
	}

	/**
	 * @return the programID
	 */
	public Integer getProgramID() {
		return programID;
	}

	/**
	 * @param programID
	 *            the programID to set
	 */
	public void setProgramID(Integer programID) {
		this.programID = programID;
	}

	/**
	 * @return the reasonCode
	 */
	public String getReasonCode() {
		return reasonCode;
	}

	/**
	 * @param reasonCode
	 *            the reasonCode to set
	 */
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	/**
	 * @return the overrideCode
	 */
	public String getOverrideCode() {
		return overrideCode;
	}

	/**
	 * @param overrideCode
	 *            the overrideCode to set
	 */
	public void setOverrideCode(String overrideCode) {
		this.overrideCode = overrideCode;
	}

	/**
	 * @return the issueDate
	 */
	public Calendar getIssueDate() {
		return issueDate;
	}

	/**
	 * @param issueDate
	 *            the issueDate to set
	 */
	public void setIssueDate(Calendar issueDate) {
		this.issueDate = issueDate;
	}


	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	public Integer getContractNo() {
		return contractNo;
	}

	public void setContractNo(Integer contractNo) {
		this.contractNo = contractNo;
	}

	public Integer getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}

	public void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}
	
	
}

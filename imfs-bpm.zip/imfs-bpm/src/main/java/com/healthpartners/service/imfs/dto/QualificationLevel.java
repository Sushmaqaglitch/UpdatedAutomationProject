package com.healthpartners.service.imfs.dto;

public class QualificationLevel extends BaseDTO
{
	static final long serialVersionUID = 0L;
	private Integer ID;
	private String qualificationLevelCode;
	private String name;
	private String description;
	private Integer minScore;
    
    public QualificationLevel()
    {
    	super();
    }

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getID() {
		return ID;
	}

	public void setId(Integer id) {
		this.ID = id;
	}

	public Integer getMinScore() {
		return minScore;
	}

	public void setMinScore(Integer minScore) {
		this.minScore = minScore;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getQualificationLevelCode() {
		return qualificationLevelCode;
	}

	public void setQualificationLevelCode(String qualificationLevelCode) {
		this.qualificationLevelCode = qualificationLevelCode;
	}
    
}

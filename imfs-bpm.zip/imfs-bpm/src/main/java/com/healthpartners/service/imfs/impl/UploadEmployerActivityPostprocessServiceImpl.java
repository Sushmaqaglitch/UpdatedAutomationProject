package com.healthpartners.service.imfs.impl;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMEmailUtility;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dao.BusinessProgramDAO;
import com.healthpartners.service.imfs.dao.ControlGroupIOFileDirSetupDAO;
import com.healthpartners.service.imfs.dao.EmployerRecycleDAO;
import com.healthpartners.service.imfs.dao.PersonDAO;
import com.healthpartners.service.imfs.dto.ActivityDefinition;
import com.healthpartners.service.imfs.dto.ActivityEvent;
import com.healthpartners.service.imfs.dto.ActivityExternalEmployerXref;
import com.healthpartners.service.imfs.dto.BPMBusinessProgram;
import com.healthpartners.service.imfs.dto.ControlGroupIOFileDirSetup;
import com.healthpartners.service.imfs.dto.EmployerActivityContributionsFileData;
import com.healthpartners.service.imfs.dto.EmployerSponsoredActivity;
import com.healthpartners.service.imfs.dto.EmployerSponsoredActivityTrailer;
import com.healthpartners.service.imfs.dto.EmployerSponsoredFile;
import com.healthpartners.service.imfs.dto.GroupActivityProgressTracker;
import com.healthpartners.service.imfs.dto.LookUpValueCode;
import com.healthpartners.service.imfs.dto.MemberActivity;
import com.healthpartners.service.imfs.dto.PersonPackage;
import com.healthpartners.service.imfs.dto.PersonProgramActivityIncentiveStatus;
import com.healthpartners.service.imfs.dto.RejectedPerson;
import com.healthpartners.service.imfs.exception.BPMBusinessValidationException;
import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.helper.UploadEmployerActivityDataFileHelper;
import com.healthpartners.service.imfs.iface.ActivityEventService;
import com.healthpartners.service.imfs.iface.BusinessProgramService;
import com.healthpartners.service.imfs.iface.GroupActivityProgressTrackerService;
import com.healthpartners.service.imfs.iface.LookUpValueService;
import com.healthpartners.service.imfs.iface.MemberService;
import com.healthpartners.service.imfs.iface.UploadEmployerActivityPostprocessService;
import com.healthpartners.service.imfs.outbound.OutboundFileProcessing;
import com.healthpartners.service.imfs.rules.StatusCalculationCommand;
@Component
@Service
public class UploadEmployerActivityPostprocessServiceImpl implements UploadEmployerActivityPostprocessService {
	

	protected final Log logger = LogFactory.getLog(getClass());
	@Autowired
	private MemberService memberService;
	@Autowired
	private BusinessProgramService businessProgramService;
	@Autowired
	private LookUpValueService lookUpValueService;
	@Autowired
	private GroupActivityProgressTrackerService groupActivityProgressTrackerService;
	@Autowired
	private ActivityEventService activityEventService;

	@Autowired
	private PersonDAO personDAO;
	@Autowired
	private EmployerRecycleDAO employerRecycleDAO;
	@Autowired
	private BusinessProgramDAO businessProgramDAO;
	@Autowired
	private BPMEmailUtility bpmEmailUtility;

	@Autowired
	private ControlGroupIOFileDirSetupDAO controlGroupIOFileDirSetupDAO;

	private GroupActivityProgressTracker groupActivityProgressTracker;
	
	private String hostName;
	private String userID;
	
	private ArrayList<PersonProgramActivityIncentiveStatus> personProgramActivityIncentiveStatusAL = null;
	private ArrayList<RejectedPerson> errorRecycleAL = null;
	private ArrayList<EmployerSponsoredActivity> employerSponsoredActivityPendingAL = null;
	private ArrayList<EmployerSponsoredActivity> employerSponsoredActivityInProcessAL = null;
	private ArrayList<EmployerSponsoredActivity> employerSponsoredActivityFilteredOutAL = null;
	private ArrayList<EmployerSponsoredActivity> employerSponsoredActivityMissingInActivityEventLogAL = null;
	private ArrayList<EmployerSponsoredActivity> employerSponsoredActivityMissingInActivityIncentedNRecycleAL = null;
	private ArrayList<EmployerSponsoredActivity> employerSponsoredActivityUnresolvedMemberIDAL = null;
	
/*
 * Batch job to produce reconciliation employer sponsored summary report within the e-mail notification and
 * create a Detail File from the Person Program Activity Incentive Status table if reconciled successfully back to 
 * the file sent from Vendor.
 * 
*/
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class,
			BPMBusinessValidationException.class, BPMException.class })
public void processUploadEmployerActivityPostprocessCommand(StatusCalculationCommand statusCalculationCommand) throws BPMException {
		
			logger.info("@Start - Processing Upload Employer Activity Postprocess Command. ");
			
			instantiateActivityALs();
			
			statusCalculationCommand.setCurrentCommandText("Upload Employer Activity Postprocess");
			
			
			setHostName(statusCalculationCommand.getHostName());
			setUserID(statusCalculationCommand.getUserID());
			
			logger.info("@@@Host name is " + hostName);
			logger.info("@@@User ID is " + userID);
				
			LookUpValueCode uploadEmployerGroupLuv = null;
			//read from a group control table to get fileLocation by group.  Also, get group number.
			try {
				uploadEmployerGroupLuv = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.CNTRL_GRP_RT_TYPE, BPMConstants.UPL_EMPLOYER_SPONSORED);
			} catch (Exception e) {
				logger.error("Exception thrown after luv lookup: " + e.getMessage());
				throw new BPMException(e);
			}
			
			Integer routingTypeID = uploadEmployerGroupLuv.getLuvId();
			Collection<ControlGroupIOFileDirSetup> lControlGroupIOFileDirSetups = controlGroupIOFileDirSetupDAO.getControlGroupsIOFileDirSetup(routingTypeID);
			
			
			UploadEmployerActivityDataFileHelper lUploadEmployerActivityDataFileHelper = new UploadEmployerActivityDataFileHelper();
			
			for (ControlGroupIOFileDirSetup lControlGroupIOFileDirSetup : lControlGroupIOFileDirSetups) {
				try {	
					boolean errorsExist = false;
					lUploadEmployerActivityDataFileHelper.setWellsFargo(false);
					lUploadEmployerActivityDataFileHelper.setTarget(false);
					lUploadEmployerActivityDataFileHelper.setDaikin(false);
					
					String groupNo = lControlGroupIOFileDirSetup.getGroupNo();
					String fileLocationPreprocess = lControlGroupIOFileDirSetup.getInputFileLocPreprocess();
					String fileLocationProcessed = lControlGroupIOFileDirSetup.getInputFileLocProcessed();
					
					if (groupNo.equals(BPMConstants.BPM_TARGET)) {
						lUploadEmployerActivityDataFileHelper.setTarget(true);
					} else if (groupNo.equals(BPMConstants.BPM_DAIKIN)) {
							lUploadEmployerActivityDataFileHelper.setDaikin(true);
					} else if (groupNo.equals(BPMConstants.BPM_WELLSFARGO)) {
							lUploadEmployerActivityDataFileHelper.setWellsFargo(true);
					} 
					
					Collection<ActivityExternalEmployerXref> lActivitiesExternalEmployerXref = memberService.getExternalEmployerActivityXrefAll();
					
					lUploadEmployerActivityDataFileHelper.setActivitiesExternalEmployerXref(lActivitiesExternalEmployerXref);
					lUploadEmployerActivityDataFileHelper.setMemberService(memberService);
					lUploadEmployerActivityDataFileHelper.setBusinessProgramService(businessProgramService);
					
					//1) Read in one or more employer sponsored files.
					logger.info("processUploadEmployerActivityPostprocessCommand - Reading from file location: " + fileLocationPreprocess);
					Collection<EmployerSponsoredFile> lEmployerSponsoredFiles = lUploadEmployerActivityDataFileHelper.getEmployerSponsoredFiles(fileLocationPreprocess);
					
					for (EmployerSponsoredFile lEmployerSponsoredFile : lEmployerSponsoredFiles) {
						String groupFileSourceName = lEmployerSponsoredFile.getGroupFileSourceName();
						Collection<EmployerSponsoredActivity> lEmployerSponsoredActivities = lEmployerSponsoredFile.getEmployerSponsoredActivities();
						
						if (lEmployerSponsoredActivities != null && lEmployerSponsoredActivities.isEmpty()) {
							//EV83985
							//prepareAndSendSummaryEmail(null, lControlGroupIOFileDirSetup, BPMConstants.RESULT_SUCCESS, groupFileSourceName, null, null);
							//moveFilesFromPreprocessToProcessed(fileLocationPreprocess, fileLocationProcessed, groupNo);
						} else {
						
							//2) validate to ensure integrity of the file before producing the summary report.
							EmployerActivityContributionsFileData lEmployerActivityContributionsFileData  
											= lUploadEmployerActivityDataFileHelper.validateNFormatEmployerActivityContributions(lEmployerSponsoredActivities, groupNo);
							
							if (lEmployerActivityContributionsFileData.isRejectWholeFile()) {
								sendFailedSummaryEmail(lEmployerActivityContributionsFileData, lControlGroupIOFileDirSetup, groupFileSourceName);
							} else if (lEmployerActivityContributionsFileData.getEmployerSponsoredActivityTrailer().getRecordCount().equals("0")) {
										//EV83985
										//prepareAndSendSummaryEmail(null, lControlGroupIOFileDirSetup, BPMConstants.RESULT_SUCCESS, groupFileSourceName, null, null);
										//moveFilesFromPreprocessToProcessed(fileLocationPreprocess, fileLocationProcessed, groupNo);
							
							} else {
								//3) If first time through, check group activity progression tracker record for what status it is in.
								//if (firstTimeThru) {
								//   firstTimeThru = false;	
								validateStatusOfFile(lEmployerActivityContributionsFileData, lControlGroupIOFileDirSetup, groupFileSourceName);
							    //}
								
								Collection<EmployerSponsoredActivity> validEmployerSponsoredMemberActivities = lEmployerActivityContributionsFileData.getValidMemberActivities();
								Collection<EmployerSponsoredActivity> errorRecycleEmployerSponsoredMemberActivities = lEmployerActivityContributionsFileData.getErrorRecycleMemberActivities();
								
							
								
								if (isPassReconciliationSteps(validEmployerSponsoredMemberActivities, errorRecycleEmployerSponsoredMemberActivities)) {
								
								
									//4) reconciliation successful. produce detail file from program activity Incentive status table and
									//   summary by contract detail file.
									
									LookUpValueCode lLookupValueCode = null;
									try {
										lLookupValueCode = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.UPL_EMPL_TRACK_STAT_GROUP, BPMConstants.UPL_EMPL_PREPROCESS_STATUS);
									} catch (Exception e) {
										logger.error("Attempt made to read for the preprocess status record but failed when trying to build out a GroupActivityProgressTracker record");
										throw e;
									}
									
									
									//5) write activity detail and contract summary records to csv file within weblogic file system directory.
									Integer contractRecordCount = generatCSVEmployerSponsoredContributionReports(lControlGroupIOFileDirSetup);
									
										
									//6) if free of errors, set employer activity progression tracker table to POSTPROCESS and record and contribution totals to indicated the groups employer sponsored file 
									//   was successfull processed.
									String resultStatus = BPMConstants.RESULT_FAILURE;
									if (isFileFreeOfIssues()) { 
										updateGroupActivityProgressionTrackerToPostProcessStatus(lEmployerActivityContributionsFileData);
										
										resultStatus = BPMConstants.RESULT_SUCCESS;
									} else {
										errorsExist = true;
										updateGroupActivityProgressionTrackerWithBusPgmID(lEmployerActivityContributionsFileData);
									}
									prepareAndSendSummaryEmail(lEmployerActivityContributionsFileData, lControlGroupIOFileDirSetup, resultStatus, groupFileSourceName, contractRecordCount, null);
									
									
								} else {
									prepareAndSendSummaryEmail(lEmployerActivityContributionsFileData, lControlGroupIOFileDirSetup, BPMConstants.RESULT_FAILURE, groupFileSourceName, null, null);
								}
							}
							
							clearActivityALs();
						}
					} 
					
					//if no errors exist.
					if (!errorsExist) {
						moveFilesFromPreprocessToProcessed(fileLocationPreprocess, fileLocationProcessed, groupNo);
					}
					
				} catch (Exception e) {
					System.out.println("Exception is " + e.toString());
					throw new BPMException(e);
				} 
			}
			
			
			
	}
	/*
	 * Validate file is not in a PREPROCESS or POSTPROCESS status.  Status needs to be INPROCESS in order for the batch process to continue.
	 */
	private void validateStatusOfFile(EmployerActivityContributionsFileData lEmployerActivityContributionsFileData, ControlGroupIOFileDirSetup lControlGroupIOFileDirSetup, String groupFileSourceName) throws Exception, BPMException {
		
		try {
			if (lEmployerActivityContributionsFileData.getValidMemberActivities().size() > 0) {
				
				GroupActivityProgressTracker lGroupActivityProgressTracker = buildGroupActivityProgressTracker(lEmployerActivityContributionsFileData);	
				setGroupActivityProgressTracker(lGroupActivityProgressTracker);
				//Check to see if file was already processed.
				if (isFileInPreProcessState()) {
					String errorReason = "ERROR:  File is set to PREPROCESS status.  Needs to be in a INPROCESS status for this batch job to continue.";
					logger.error(errorReason);
					//setting flag to object is pass by reference.
					lEmployerActivityContributionsFileData.setRejectWholeFile(true);
					lEmployerActivityContributionsFileData.setRejectWholeFileReason(errorReason);
					sendFailedSummaryEmail(lEmployerActivityContributionsFileData, lControlGroupIOFileDirSetup, groupFileSourceName);
					throw new BPMException(errorReason);
				} 
				
				if (isFilePostProcessedState()) {
					String errorReason = "ERROR:  File is set to POSTPROCESS status.  Needs to be in a INPROCESS status for this batch job to continue.  It should not be considered for reprocessing!!!";
					logger.error(errorReason);
					//setting flag to object is pass by reference.
					lEmployerActivityContributionsFileData.setRejectWholeFile(true);
					lEmployerActivityContributionsFileData.setRejectWholeFileReason(errorReason);
					sendFailedSummaryEmail(lEmployerActivityContributionsFileData, lControlGroupIOFileDirSetup, groupFileSourceName);
					throw new BPMException(errorReason);
				}
				
				if (isNoFileBeenProcessed()) {
					String errorReason = "ERROR:  File was not run through Employer Sponsored Activtiy Preprocess batch job.  Needs to be in a INPROCESS status for this batch job to continue.";
					logger.error(errorReason);
					//setting flag to object is pass by reference.
					lEmployerActivityContributionsFileData.setRejectWholeFile(true);
					lEmployerActivityContributionsFileData.setRejectWholeFileReason(errorReason);
					sendFailedSummaryEmail(lEmployerActivityContributionsFileData, lControlGroupIOFileDirSetup, groupFileSourceName);
					throw new BPMException(errorReason);
				}
			}
		} catch (Exception e) {
			logger.error("validateStatusOfFile: ERROR: " + e.getMessage());
			throw e;
		}
	}
	
	private boolean isFileFreeOfIssues() {
		boolean freeOfIssues = false;
		if (getEmployerSponsoredActivityFilteredOutAL().isEmpty() &&
				getEmployerSponsoredActivityInProcessAL().isEmpty() &&
					getEmployerSponsoredActivityMissingInActivityEventLogAL().isEmpty() &&
						getEmployerSponsoredActivityMissingInActivityIncentedNRecycleAL().isEmpty() &&
							getEmployerSponsoredActivityPendingAL().isEmpty() &&
							getEmployerSponsoredActivityUnresolvedMemberIDAL().isEmpty()) {
			
			freeOfIssues = true;
		}
		
		return freeOfIssues;
			
	}
	
	/* Begin reconciliation process of Optum csv file against activity event log and person program activity incentive status table.
	*	1) Read from activity event log to validate all records sent from Vendor were accounted for in the batch employer sponsored preprocess load step
	*  and to produce pending and filtered out summary totals if they exists.  If anytime a record is not found, produce a "failure 
	*  to reconcile" e-mail notification.  
	*  2) If activity event is in a PENDING status, produce a "some activities remain in a pending state" and fail the
	*  batch process.  
	*  3) Read from person program activity incentive status table for producing record and contribution amount processing totals. 
	*     Produce "failure to reconcile" e-mail notification if no record exists.
	*/
	private boolean isPassReconciliationSteps(Collection<EmployerSponsoredActivity> validEmployerSponsoredMemberActivities, Collection<EmployerSponsoredActivity> errorRecycleEmployerSponsoredMemberActivities) throws BPMException {
		boolean allStepsPassed = false;
			 
		if (validEmployerSponsoredMemberActivities.size() > 0 ) {
			for (EmployerSponsoredActivity lEmployerSponsoredActivity : validEmployerSponsoredMemberActivities) {
				if (isActivityEventLogReconcileCorrectly(lEmployerSponsoredActivity)) {
					if (isPersonProgramActivityIncentiveStatusReconcileCorrectly(lEmployerSponsoredActivity)) {
						allStepsPassed = true;
					}
					//EV84334
					//if activity not found in activity incented table, try Member Incented table.
					if (!allStepsPassed && isMemberProgramActivityIncentiveStatusReconcileCorrectly(lEmployerSponsoredActivity)) {
						allStepsPassed = true;
					}
				}
			}	
		}
		
		boolean reconciledSuccessfullyToErrorRecycle = true;
		if (errorRecycleEmployerSponsoredMemberActivities != null && errorRecycleEmployerSponsoredMemberActivities.size() > 0) {
			reconciledSuccessfullyToErrorRecycle = reconcileToErrorRecycle(errorRecycleEmployerSponsoredMemberActivities);
		}
		
			
		return allStepsPassed && reconciledSuccessfullyToErrorRecycle;
	}
	/*
	 * Methods purpose is to determine if all employer sponsored activities were entered into the activity event log and processed.
	 */
	private boolean isActivityEventLogReconcileCorrectly(EmployerSponsoredActivity lEmployerSponsoredActivity) throws BPMException {
		
		boolean reconciledSuccessfully = false;
		boolean pendingActivity = false;
		boolean inprocessActivity = false;
		boolean missingActivity =false;
		
		java.sql.Date pActivityDate = null;
		Integer pAmountEarned = new Integer(0);
		
		String errorReason = null;
		
		String pMemberID = lEmployerSponsoredActivity.getMemberID();
		String pSourceActivityID = lEmployerSponsoredActivity.getSourceActivityID();
		if (lEmployerSponsoredActivity.getActivityDate() != null) {
			pActivityDate = BPMUtils.convertStringToSqlDate(lEmployerSponsoredActivity.getActivityDate(), BPMConstants.HP_BPM_COMMON_DATE_FORMAT);
			
		}
		
		if (lEmployerSponsoredActivity.getAmountEarned() !=null) {
			pAmountEarned = Integer.valueOf(lEmployerSponsoredActivity.getAmountEarned());
		} 
		
		Calendar lToday = Calendar.getInstance();
		String pRegistrationID = lEmployerSponsoredActivity.getMemberID()
			    + "-" + BPMUtils.formatDateMMddyyyyNoDel(lToday);
		lEmployerSponsoredActivity.setRegistrationID(pRegistrationID);
		
		Collection<ActivityEvent> lActivityEvents =
							activityEventService.getMemberActivityEventLogActivity(pMemberID, pSourceActivityID, pActivityDate);
	
		if (lActivityEvents != null && lActivityEvents.size() > 0) {
			for (ActivityEvent lActivityEvent : lActivityEvents) {
				if (pAmountEarned.equals(lActivityEvent.getMemberActivity().getContributionAmt()))  {
					if (lActivityEvent.getProcessingStatusValue().equals(BPMConstants.PROCESSING_STATUS_COMPLETED)) {
						//activity reconciled successfully.
					} else if (lActivityEvent.getProcessingStatusValue().equals(BPMConstants.PROCESSING_STATUS_PENDING)) {
						pendingActivity = true;
						errorReason = "ERROR: Employer sponsored activity in a PENDING status. Take action to reprocess.";
						lEmployerSponsoredActivity.setErrorReason(errorReason);
						logger.error("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
						logger.error("getMemberActivityEventLogActivity - " + errorReason);
						logger.error("Activity Event Log ID is " + lActivityEvent.getActivityEventLogID());
						logger.error("Member ID is " + pMemberID);
						logger.error("Source Activity ID is " + pSourceActivityID);
						logger.error("Registration ID is " + pRegistrationID);
						employerSponsoredActivityPendingAL.add(lEmployerSponsoredActivity);
					} else if (lActivityEvent.getProcessingStatusValue().equals(BPMConstants.PROCESSING_STATUS_INPROCESS)) {
						inprocessActivity = true;
						errorReason = "ERROR: Employer sponsored activity in an INPROCESS status. Take action to reprocess.";
						lEmployerSponsoredActivity.setErrorReason(errorReason);
						logger.error("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
						logger.error("getMemberActivityEventLogActivity - " + errorReason);
						logger.error("Activity Event Log ID is " + lActivityEvent.getActivityEventLogID());
						logger.error("Member ID is " + pMemberID);
						logger.error("Source Activity ID is " + pSourceActivityID);
						logger.error("Registration ID is " + pRegistrationID);
						employerSponsoredActivityInProcessAL.add(lEmployerSponsoredActivity);
					} else if (lActivityEvent.getProcessingStatusValue().equals(BPMConstants.PROCESSING_STATUS_FILTERD_OUT)) {
						pendingActivity = true;
						errorReason = "WARNING: Employer sponsored activity in a FILTERED OUT status.  Possible Member Eligibility not active at time of contribution";
						lEmployerSponsoredActivity.setErrorReason(errorReason);
						logger.error("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
						logger.error("getMemberActivityEventLogActivity - " + errorReason);
						logger.error("Activity Event Log ID is " + lActivityEvent.getActivityEventLogID());
						logger.error("Member ID is " + pMemberID);
						logger.error("Source Activity ID is " + pSourceActivityID);
						logger.error("Registration ID is " + pRegistrationID);
						employerSponsoredActivityFilteredOutAL.add(lEmployerSponsoredActivity);
					}
				} else {
					missingActivity = true;
					errorReason = "ERROR: Employer sponsored activity missing from activity event log table. Take action to reprocess.";
					lEmployerSponsoredActivity.setErrorReason(errorReason);
					logger.error("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
					logger.error("getMemberActivityEventLogActivity - " + errorReason);
					logger.error("Activity Event Log ID is " + lActivityEvent.getActivityEventLogID());
					logger.error("Member ID is " + pMemberID);
					logger.error("Source Activity ID is " + pSourceActivityID);
					logger.error("Registration ID is " + pRegistrationID);
					employerSponsoredActivityMissingInActivityEventLogAL.add(lEmployerSponsoredActivity);
				}
				
			}
		} else {
			missingActivity = true;
			errorReason = "ERROR: Employer sponsored activity missing from activity event log table. Take action to reprocess.";
			lEmployerSponsoredActivity.setErrorReason(errorReason);
			logger.error("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
			logger.error("getMemberActivityEventLogActivity - " + errorReason);
			logger.error("Member ID is " + pMemberID);
			logger.error("Source Activity ID is " + pSourceActivityID);
			logger.error("Registration ID is " + pRegistrationID);
			employerSponsoredActivityMissingInActivityEventLogAL.add(lEmployerSponsoredActivity);
		}
	
	
		if (pendingActivity && missingActivity) {
			errorReason = "ERROR: Both pending activities and no activity exist in the activity event log for the employer sponsored file being processed.  See audit log trail prior to this message for details.";
		} else if (pendingActivity) {
					errorReason = "ERROR: Pending activity exists in the activity event log for the employer sponsored file that needs to be reprocessed to COMPLETED.  See audit log trail prior to this message for details.";
		} else if (missingActivity) {
					errorReason = "ERROR: No activity exists in the activity event log for the corresponding employer sponsored activity taken.  See audit log trail prior to this message for details.";
		}
		
		if (errorReason != null) {
			logger.error(errorReason);
		}
		
		if (pendingActivity || missingActivity || inprocessActivity) {
			//reconciliation unsuccessful
		} else {
			reconciledSuccessfully = true;
		}
			
		return reconciledSuccessfully;
	}
	
	private boolean isPersonProgramActivityIncentiveStatusReconcileCorrectly(EmployerSponsoredActivity lEmployerSponsoredActivity) throws BPMException{
		
		boolean reconciledSuccessfully = false;
		
		Integer personDemographicsID = getPersonDemographicsID(lEmployerSponsoredActivity);
		if (personDemographicsID == null) {
			return reconciledSuccessfully;
		}
		
		
		ActivityEvent activityEvent = new ActivityEvent();
		MemberActivity memberActivity = new MemberActivity();
		ActivityDefinition activityDef = new ActivityDefinition();
		
		activityEvent.setPersonDemographicsID(personDemographicsID);
		activityDef.setActivityID(lEmployerSponsoredActivity.getActivityID());
		memberActivity.setActivity(activityDef);
		memberActivity.setContributionAmt(Integer.valueOf(lEmployerSponsoredActivity.getAmountEarned()));
		Date activityDate = BPMUtils.convertStringToSqlDate(lEmployerSponsoredActivity.getActivityDate(), BPMConstants.HP_BPM_COMMON_DATE_FORMAT);
		memberActivity.setCompletionDate(BPMUtils.dateToCalendar(activityDate));
		memberActivity.setRegistrationID(lEmployerSponsoredActivity.getRegistrationID());
		activityEvent.setMemberActivity(memberActivity);
		
		Integer programID = activityEvent.getMemberActivity().getBusinessProgramID();
		Integer activityID = activityEvent.getMemberActivity().getActivity().getActivityID();
		Date activityStatusDate = BPMUtils.calendarToSqlDate(activityEvent.getMemberActivity().getCompletionDate());
		Integer contributionAmt = activityEvent.getMemberActivity().getContributionAmt();
		PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus = personDAO.getPersonPgmActivityIncentiveStatusEnhanced(programID, personDemographicsID, activityID, activityStatusDate, contributionAmt);
		
		if (lPersonProgramActivityIncentiveStatus != null) {
			Collection<PersonPackage> lPersonPackages = 
					personDAO.getPersonPackages(lPersonProgramActivityIncentiveStatus.getPersonDemographicsID(), lPersonProgramActivityIncentiveStatus.getProgramID());
			if (lPersonPackages != null && lPersonPackages.size() > 0) {
				//Should only be one record returned.
				PersonPackage lPersonPackage = lPersonPackages.iterator().next();
				lPersonProgramActivityIncentiveStatus.setContractNo(String.valueOf(lPersonPackage.getContractNo()));
				lPersonProgramActivityIncentiveStatus.setProductType(lPersonPackage.getPackageSubTypeName());
				
			}else {
				lPersonProgramActivityIncentiveStatus.setContractNo("0");
				lPersonProgramActivityIncentiveStatus.setProductType("Not Available");
			}
			
			
			personProgramActivityIncentiveStatusAL.add(lPersonProgramActivityIncentiveStatus);
			reconciledSuccessfully = true;
		} else {
			//is activity accounted for in employer recycle table
			reconciledSuccessfully = isPersonProgramActivityReconcileToErrorRecycle(lEmployerSponsoredActivity);
		}
		
		return reconciledSuccessfully;
	}

	/* EV84334
	 * Reconcile to the member activity incented table.
	 */
	private boolean isMemberProgramActivityIncentiveStatusReconcileCorrectly(EmployerSponsoredActivity lEmployerSponsoredActivity) throws BPMException {
		
		boolean reconciledSuccessfully = false;
		
		Integer personDemographicsID = getPersonDemographicsID(lEmployerSponsoredActivity);
		if (personDemographicsID == null) {
			return reconciledSuccessfully;
		}
		
		
		ActivityEvent activityEvent = new ActivityEvent();
		MemberActivity memberActivity = new MemberActivity();
		ActivityDefinition activityDef = new ActivityDefinition();
		
		activityEvent.setPersonDemographicsID(personDemographicsID);
		activityDef.setActivityID(lEmployerSponsoredActivity.getActivityID());
		memberActivity.setActivity(activityDef);
		memberActivity.setContributionAmt(Integer.valueOf(lEmployerSponsoredActivity.getAmountEarned()));
		Date activityDate = BPMUtils.convertStringToSqlDate(lEmployerSponsoredActivity.getActivityDate(), BPMConstants.HP_BPM_COMMON_DATE_FORMAT);
		memberActivity.setCompletionDate(BPMUtils.dateToCalendar(activityDate));
		memberActivity.setRegistrationID(lEmployerSponsoredActivity.getRegistrationID());
		activityEvent.setMemberActivity(memberActivity);
		
		
		Integer programID = activityEvent.getMemberActivity().getBusinessProgramID();
		Integer activityID = activityEvent.getMemberActivity().getActivity().getActivityID();
		Date activityStatusDate = BPMUtils.calendarToSqlDate(activityEvent.getMemberActivity().getCompletionDate());
		Integer contributionAmt = activityEvent.getMemberActivity().getContributionAmt();
		PersonProgramActivityIncentiveStatus lMemberProgramActivityIncentiveStatus = personDAO.getMemberPgmActivityIncentiveStatusEnhanced(programID, personDemographicsID, activityID, activityStatusDate, contributionAmt);
		
		if (lMemberProgramActivityIncentiveStatus != null) {
			Collection<PersonPackage> lPersonPackages = 
					personDAO.getPersonPackages(lMemberProgramActivityIncentiveStatus.getPersonDemographicsID(), lMemberProgramActivityIncentiveStatus.getProgramID());
			if (lPersonPackages != null && lPersonPackages.size() > 0) {
				//Should only be one record returned.
				PersonPackage lPersonPackage = lPersonPackages.iterator().next();
				lMemberProgramActivityIncentiveStatus.setContractNo(String.valueOf(lPersonPackage.getContractNo()));
				lMemberProgramActivityIncentiveStatus.setProductType(lPersonPackage.getPackageSubTypeName());
				
			}else {
				lMemberProgramActivityIncentiveStatus.setContractNo("0");
				lMemberProgramActivityIncentiveStatus.setProductType("Not Available");
			}
			
			
			personProgramActivityIncentiveStatusAL.add(lMemberProgramActivityIncentiveStatus);
			reconciledSuccessfully = true;
		} else {
			//is activity accounted for in employer recycle table
			reconciledSuccessfully = isPersonProgramActivityReconcileToErrorRecycle(lEmployerSponsoredActivity);
		}
		
		return reconciledSuccessfully;
	}
	
	
	private boolean reconcileToErrorRecycle(Collection<EmployerSponsoredActivity> errorRecycleEmployerSponsoredMemberActivities) throws BPMException {
		boolean reconciledSuccessfully = false;
		for (EmployerSponsoredActivity errorRecycleEmployerSponsoredMemberActivity : errorRecycleEmployerSponsoredMemberActivities) {
			reconciledSuccessfully = isPersonProgramActivityReconcileToErrorRecycle(errorRecycleEmployerSponsoredMemberActivity);
		}
		
		return reconciledSuccessfully;
	}
	
	
	private boolean isPersonProgramActivityReconcileToErrorRecycle(EmployerSponsoredActivity lEmployerSponsoredActivity) throws BPMException{
		
		boolean reconciledSuccessfully = false;
	
		Date activityDate = BPMUtils.convertStringToSqlDate(lEmployerSponsoredActivity.getActivityDate(), BPMConstants.HP_BPM_COMMON_DATE_FORMAT);
		
		Date dateOfBirth = BPMUtils.convertStringToSqlDate(lEmployerSponsoredActivity.getDateOfBirth(), BPMConstants.HP_BPM_COMMON_DATE_FORMAT);
		
		
		Collection<RejectedPerson> lRejectedPersons = 
					businessProgramService.getEmployerRecycle(lEmployerSponsoredActivity.getActivityID(), lEmployerSponsoredActivity.getFirstName(), lEmployerSponsoredActivity.getLastName(), dateOfBirth, activityDate, null, null, null, Integer.valueOf(lEmployerSponsoredActivity.getAmountEarned()));
	
		if (lRejectedPersons == null || lRejectedPersons.isEmpty()) {
			String errorReason = "ERROR: Employer sponsored activity did not reach activity incented table and was not found in the recycle table.  Possible missing package in package baseline table, incentive did not meet family and participant capping rules or member is not eligible (missing from person baseline).  Work with developer to investigate.";
			logger.error("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
			logger.error("isPersonProgramActivityIncentiveStatusReconcileCorrectly: " + errorReason);
			logger.error("It does not exist in either the activity event for person program activity incentive status tables.");
			logger.error("Person ID is " + lEmployerSponsoredActivity.getPersonID());
			lEmployerSponsoredActivity.setErrorReason(errorReason);
			employerSponsoredActivityMissingInActivityIncentedNRecycleAL.add(lEmployerSponsoredActivity);
		} else {
			reconciledSuccessfully = true;
			RejectedPerson lRejectedPerson = lRejectedPersons.iterator().next();
			errorRecycleAL.add(lRejectedPerson);
		}
		
		return reconciledSuccessfully;
	}
	
	private Integer getPersonDemographicsID(EmployerSponsoredActivity lEmployerSponsoredActivity) {
		Integer personDemographicsID = null;
		String memberID =  lEmployerSponsoredActivity.getMemberID();
		
		
		if (memberID != null) {
			personDemographicsID = personDAO.getPersonID(memberID);
		} else {
			String fatalErrorReason = "ERROR: Member ID is missing for looking up person demographics ID.  Look to see if member is in the error recycle table.";
			logger.error("isPersonProgramActivityIncentiveStatusReconcileCorrectly:  " + fatalErrorReason);
			lEmployerSponsoredActivity.setErrorReason(fatalErrorReason);
			getEmployerSponsoredActivityUnresolvedMemberIDAL().add(lEmployerSponsoredActivity);
		}
		
		return personDemographicsID;
	}
	
	/**
	 * @param employerActivities
	 * @return
	 * @throws DataAccessException
	 * @throws BPMException
	 */
	private String sendFailedSummaryEmail(
			EmployerActivityContributionsFileData employerActivities, ControlGroupIOFileDirSetup lControlGroupIOFileDirSetup, String groupFileSourceName) throws BPMException {
		
		String resultPage = BPMConstants.RESULT_FAILURE;
//		ActionMessages messages = new ActionMessages();

		try {

//			if (employerActivities == null) {
//
//				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage(
//						"messages.info", "No Employer Sponsored File to process for group ." + lControlGroupIOFileDirSetup.getGroupNo() + " - " + lControlGroupIOFileDirSetup.getGroupName()));
//				//EV83985
//				//prepareAndSendSummaryEmail(employerActivities, lControlGroupIOFileDirSetup, resultPage, groupFileSourceName, null, null);
//			} else if (employerActivities.isRejectWholeFile()) {
//
//					messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage(
//							"messages.info", "Rejecting whole file."));
//			}
//
//			// add number of invalid/incomplete employer activities written to employer activity recycle table
//			int employerRecycleRecsWrittenCt = 0;
//
//			if (employerActivities.getErrorRecycleMemberActivities() != null) {
//				employerRecycleRecsWrittenCt = employerActivities.getErrorRecycleMemberActivities().size();
//			}
//
//			messages.add(ActionMnessages.GLOBAL_MESSAGE,
//					new ActionMessage("messages.info",
//							"Invalid and incomplete person activities written '" + employerRecycleRecsWrittenCt +
//							"' to the Employer Recycle table for further review'"));
//			messages.add(ActionMessages.GLOBAL_MESSAGE,
//					new ActionMessage("messages.info",
//							"Go to Person Employer Activity Recycle (Review) to reconcile"));
									
			
			// prepare summary email and send
			prepareAndSendSummaryEmail(employerActivities, lControlGroupIOFileDirSetup, resultPage, groupFileSourceName, null, null);
		
		

		} catch (Exception e) {
			System.out.println("Error: Called sendFailedSummaryEmail error. Exception is " + e);
			throw new BPMException(e);
		}

		return resultPage;
	}
	
	/*
	 * update to the group activity progression tracking table with a status of POSTPROCESS indicating reporting was generated successfully and batch
	 * process made it through all it's progression status's PREPROCESS, INPROCESS, and POSTPROCESS.
	 */
	private void updateGroupActivityProgressionTrackerToPostProcessStatus(EmployerActivityContributionsFileData lEmployerActivityContributionsFileData) throws Exception {
		
		try {
			
			if (personProgramActivityIncentiveStatusAL.size() > 0) {
				//Taking first occurence of person program activity incentive for program id since the rest of the
				//collection will be tied to the same program id.
				Integer programID = personProgramActivityIncentiveStatusAL.iterator().next().getProgramID();
				groupActivityProgressTracker.setProgramID(programID);
			}
			groupActivityProgressTracker.setTrackingStatusCode(BPMConstants.UPL_EMPL_POSTPROCESS_STATUS);
			groupActivityProgressTracker.setPostprocessCount(lEmployerActivityContributionsFileData.getValidMemberActivityCount());
			groupActivityProgressTracker.setPostprocessAmount(lEmployerActivityContributionsFileData.getValidTotalAmounts());
			groupActivityProgressTrackerService.updateGroupActivityProgressionTracker(groupActivityProgressTracker, BPMConstants.BPM_USER_SYSTEM);
				
			
		} catch (Exception e) {
			throw e;
		}
	}
	
	/*
	 * update to the group activity progression tracking table with the business program id associated to the optum file being processed.
	 * Capturing business program id back to the tracking record is vital for the incented to fulfillment reconciliation batch process.
	 */
	private void updateGroupActivityProgressionTrackerWithBusPgmID(EmployerActivityContributionsFileData lEmployerActivityContributionsFileData) throws Exception {
		
		try {
			
			if (personProgramActivityIncentiveStatusAL.size() > 0) {
				//Taking first occurence of person program activity incentive for program id since the rest of the
				//collection will be tied to the same program id.
				Integer programID = personProgramActivityIncentiveStatusAL.iterator().next().getProgramID();
				groupActivityProgressTracker.setProgramID(programID);
				groupActivityProgressTracker.setTrackingStatusCode(BPMConstants.UPL_EMPL_INPROCESS_STATUS);
				groupActivityProgressTrackerService.updateGroupActivityProgressionTracker(groupActivityProgressTracker, BPMConstants.BPM_USER_SYSTEM);
			}
			
		} catch (Exception e) {
			throw e;
		}
	}
	
	
	private boolean isFilePostProcessedState() {
		boolean isFileAlreadyProcessed = false;
		
		
		try {
			isFileAlreadyProcessed = groupActivityProgressTrackerService.isFileAlreadyProcessed(groupActivityProgressTracker);
		} catch (Exception e) {
			logger.error("Error encountered after groupActivityProgressTrackerService.isFileAlreadyProcessed call");
			logger.error("Message is " + e);
			return isFileAlreadyProcessed;
		}
		
		return isFileAlreadyProcessed;
		
	}
	
	private boolean isFileInPreProcessState() {
		boolean isFilePreProcess = false;
		
		
		try {
			isFilePreProcess = groupActivityProgressTrackerService.isFilePreProcess(groupActivityProgressTracker);
		} catch (Exception e) {
			logger.error("Error encountered after groupActivityProgressTrackerService.isFilePreProcess call");
			logger.error("Message is " + e);
			return isFilePreProcess;
		}
		
		return isFilePreProcess;
		
	}
	
	
	
	private boolean isNoFileBeenProcessed() {
		boolean isNoFileBeenProcessed = false;
		
		
		try {
			isNoFileBeenProcessed = groupActivityProgressTrackerService.isNoFileBeenProcessed(groupActivityProgressTracker);
		} catch (Exception e) {
			logger.error("Error encountered after groupActivityProgressTrackerService.isNoFileBeenProcessed call");
			logger.error("Message is " + e);
			return isNoFileBeenProcessed;
		}
		
		return isNoFileBeenProcessed;
		
	}
	
	private GroupActivityProgressTracker buildGroupActivityProgressTracker(EmployerActivityContributionsFileData lEmployerActivityContributionsFileData)  throws Exception {
		
		GroupActivityProgressTracker lGroupActivityProgressTracker = new GroupActivityProgressTracker();
		
		EmployerSponsoredActivityTrailer employerSponsoredActivityTrailer = lEmployerActivityContributionsFileData.getEmployerSponsoredActivityTrailer();
		
		java.sql.Date batchDate = BPMUtils.formatDateMMddyyyy(employerSponsoredActivityTrailer.getDateSent());
		lGroupActivityProgressTracker.setGroupNo(lEmployerActivityContributionsFileData.getGroupNo());
		lGroupActivityProgressTracker.setGroupName(lEmployerActivityContributionsFileData.getGroupName());
		lGroupActivityProgressTracker.setBatchDate(batchDate);
		lGroupActivityProgressTracker.setInputFileName(employerSponsoredActivityTrailer.getGroupFileSourceName());
		lGroupActivityProgressTracker.setPreprocessAmount(employerSponsoredActivityTrailer.getTotalAmount());
		lGroupActivityProgressTracker.setPreprocessCount(Integer.valueOf(employerSponsoredActivityTrailer.getRecordCount()));	
		
		return lGroupActivityProgressTracker;
		
	}
	
	/*
     * Generate Employer Sponsored reports from automated upload and write to file system directory.
     */
	private int	generatCSVEmployerSponsoredContributionReports(ControlGroupIOFileDirSetup lControlGroupIOFileDirSetup) throws BPMException {
		   int contractRecsWritten = 0;
		   
		   try {
			   
			  
			   OutboundFileProcessing lOutboundFileProcessing = new OutboundFileProcessing();
			   
			   lOutboundFileProcessing.generateEmployerSponsoredActivityFile(personProgramActivityIncentiveStatusAL, lControlGroupIOFileDirSetup);
				
			   contractRecsWritten = lOutboundFileProcessing.generateEmployerSponsoredContractSummaryFile(personProgramActivityIncentiveStatusAL, lControlGroupIOFileDirSetup);
			   
			   logger.info("sendCDHPContributionFile lOutboundFileProcessing.generateEmployerSponsoredContractSummaryFile count is " + contractRecsWritten);
			   
			   
			   
		   } catch (Exception e) {
				String failureReason = BPMUtils.getStakTraceAsString(e);
				logger.error(failureReason, e);
				throw new BPMException(failureReason, e);
		   } 
		   
		   
		   
		   return contractRecsWritten;
	
	}
	
	
	
	
	
	/**
	 * prepare and send summary email
	 * 
	 * @param employerActivities
	 */
	private void prepareAndSendSummaryEmail(
			EmployerActivityContributionsFileData employerActivities, ControlGroupIOFileDirSetup lControlGroupIOFileDirSetup, String resultPage, String groupFileSourceName, Integer contractRecordCount, String errorMessage) {
		String emailServerHost = null;
		String emailFromAddress = null;
		String dbEnvirnment = "";
		List<String> emailToAddress = new ArrayList<String>();
		StringBuffer emailContent = new StringBuffer();
		StringBuffer emailSubject = new StringBuffer();
		java.util.Date startDate = new java.util.Date();
		LookUpValueCode toAddress = null;
		try {

			Collection<LookUpValueCode> serverHost = lookUpValueService
					.getLUVCodesByGroup(BPMConstants.BPM_EMAIL_HOST_SRVR);
			Collection<LookUpValueCode> fromAddress = lookUpValueService
					.getLUVCodesByGroup(BPMConstants.BPM_EMAIL_FROM_ADDR);
			if (lControlGroupIOFileDirSetup.getGroupNo().equals(BPMConstants.BPM_WELLSFARGO)) {
				toAddress = lookUpValueService
						.getLUVCodeByGroupNValue(BPMConstants.EMPL_SPONSORED_TO_ADDR, BPMConstants.EMPL_SPONSORED_TO_WELLSFARGO);
			} else if (lControlGroupIOFileDirSetup.getGroupNo().equals(BPMConstants.BPM_TARGET)) {
				toAddress = lookUpValueService
						.getLUVCodeByGroupNValue(BPMConstants.EMPL_SPONSORED_TO_ADDR, BPMConstants.EMPL_SPONSORED_TO_TARGET);
			} else if (lControlGroupIOFileDirSetup.getGroupNo().equals(BPMConstants.BPM_DAIKIN)) {
				toAddress = lookUpValueService
						.getLUVCodeByGroupNValue(BPMConstants.EMPL_SPONSORED_TO_ADDR, BPMConstants.EMPL_SPONSORED_TO_DAIKIN);
			} 
			Collection<LookUpValueCode> dbEnvirnments = lookUpValueService
					.getLUVCodesByGroup(BPMConstants.BPM_DB_ENV);

			// email server host
			Iterator<LookUpValueCode> itrHost = serverHost.iterator();
			if (itrHost.hasNext()) {
				LookUpValueCode lvalue = itrHost.next();
				emailServerHost = lvalue.getLuvDesc();
			}

			// from address
			Iterator<LookUpValueCode> itrTo = fromAddress.iterator();
			if (itrTo.hasNext()) {
				LookUpValueCode lvalue = itrTo.next();
				emailFromAddress = lvalue.getLuvDesc();
			}

		
			// to address
			emailToAddress.add(toAddress.getLuvDesc());

			Iterator<LookUpValueCode> itrEnv = dbEnvirnments.iterator();
			while (itrEnv.hasNext()) {
				LookUpValueCode lvalue = itrEnv.next();
				dbEnvirnment = lvalue.getLuvDesc();
				break;
			}
			
			emailSubject
			.append("BPM Batch - PostProcess " + lControlGroupIOFileDirSetup.getGroupName() + " Upload Employer Sponsored Activities (ESP) Update - " + resultPage);
			
			emailContent.append("<table>");
			
			// prepare summary email body
			
			 
			emailContent.append("<table>");
			emailContent.append("<tr><td>Time Start:</td><td> "
					+ BPMUtils.getFormattedDateTime(startDate)
					+ "</td></tr>");
			emailContent.append("<tr><td>Purpose: To ensure all Employer Sponsored Activities incented.</td></tr>");
			emailContent.append("<tr><td>Database Environment:</td>");
			emailContent.append("<td>" + dbEnvirnment + "</td></tr>");
			if (groupFileSourceName != null) {
				emailContent.append("<tr><td>CSV Input File:</td>");
				emailContent.append("<td>" + groupFileSourceName + "</td></tr>");
			} else {
				emailContent.append("<tr><td>CSV Input File:</td>");
				emailContent.append("<td>" + "Not Available" + "</td></tr>");
			}
			emailContent.append("<tr><td>Application Server:</td>");
			emailContent.append("<td>" + hostName + "</td></tr>");
			emailContent.append("<tr><td>Group Description:</td><td colspan=2> "
					+ lControlGroupIOFileDirSetup.getGroupNo() + " - " + lControlGroupIOFileDirSetup.getGroupName() + "</td></tr>");
		
			emailContent.append("<tr><td>Initiated User:</td><td> "
					+ userID + "</td></tr>");
			emailContent.append("</table>");
			emailContent.append("<table>");
			
			if (employerActivities == null) {
				emailContent
				.append("<tr><td></td><td></tr>");
				emailContent
				.append("<tr><td></td><td></tr>");
				emailContent
				.append("<tr><td>ATTENTION: No Employer Sponsored Activity File to process today!"
						+ "</td></tr>");
				emailContent
				.append("<tr><td></td><td></tr>");
				emailContent
				.append("<tr><td></td><td></tr>");
			} else if (employerActivities.isRejectWholeFile()) {
				emailContent
					.append("<tr><td></td><td></tr>");
				emailContent
					.append("<tr><td></td><td></tr>");
				
				if (employerActivities.getRejectWholeFileReason() != null) {
					emailContent
						.append("<tr><td>" 
							+ employerActivities.getRejectWholeFileReason()
							+ "</td></tr>");
				} else {
						emailContent
						.append("<tr><td>ATTENTION: Whole file has been rejected. " 
							+ "</td></tr>");
						emailContent
						.append("<tr><td>File should not contain errors if already processed through the PREPROCESS phase of the automated upload ESP series of batch processes.  Investigate why this is happening.</td><td> "
								+ "</tr>");
						emailContent.append("</table>");
						emailContent.append("<table>");
						emailContent
							.append("<tr><td></td><td></tr>");
						emailContent
							.append("<tr><td></td><td></tr>");
							appendSummaryTotals(emailContent, employerActivities, null);
						
						appendDetailSummary(emailContent, employerActivities);
				}
			} else {
						
				appendSummaryTotals(emailContent, employerActivities, contractRecordCount);
				
				appendDetailSummary(emailContent, employerActivities);
				
			}
			
			
			
			emailContent.append("</table>");
			emailContent.append("<table>");
			
			
			if (errorMessage != null) {
					emailContent
					.append("<tr><td>***Attention!!! Error detected! Error follows: "
							+ errorMessage +"</td></tr>");
			}
			
			emailContent.append("</table>");
			emailContent.append("<table>");
			
			emailContent
			.append("<tr><td>*************************************************************************************************************************************************************************** </td><td>");
				
			
			emailContent.append("</table>");
			
			ArrayList<String> emailAttachmentLocations = determineEmailAttachments(lControlGroupIOFileDirSetup);
			
			bpmEmailUtility.sendEmail(emailServerHost, emailFromAddress,
					emailToAddress, emailSubject.toString(), emailContent.toString(),
					bpmEmailUtility.EMAIL_CONTENT_TYPE_HTML, emailAttachmentLocations);
		
		} catch (Exception e) {
			logger.error(
					"Error occurred sending Employer Sponsored activities update status email: "
							+ e.getMessage(), e);
			logger.error("  emailToAddress=" + emailToAddress);
			logger.error("  emailFromAddress=" + emailFromAddress);
			logger.error("  emailSubject=" + emailSubject.toString());
			logger.error("  emailContent=" + emailContent.toString());
		}
	}
	
	private void appendSummaryTotals(StringBuffer emailContent, EmployerActivityContributionsFileData employerActivities, Integer contractRecordCount) {
		
		
		if (personProgramActivityIncentiveStatusAL != null) {
			HashMap<Integer, BPMBusinessProgram> lBPMBusinessProgramMap = new HashMap<Integer, BPMBusinessProgram>();
			
			for (PersonProgramActivityIncentiveStatus lPersonProgramActivityIncentiveStatus : personProgramActivityIncentiveStatusAL) {
				BPMBusinessProgram  businessProgramDetail = businessProgramDAO.getBusinessProgramDetail(lPersonProgramActivityIncentiveStatus.getProgramID());
				if (businessProgramDetail != null) {
					if (!lBPMBusinessProgramMap.containsKey(businessProgramDetail.getProgramID())) {
						lBPMBusinessProgramMap.put(businessProgramDetail.getProgramID(), businessProgramDetail);
					}
				}
			}
			
			emailContent.append("<table>");
			emailContent
			.append("<tr><td>-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td><td></tr>");
			emailContent
				.append("<tr><td>Participant ESP activities are registered to the following Business program(s):</td></tr>");	
			emailContent.append("</table>");
			emailContent.append("<table>");
			if (!lBPMBusinessProgramMap.isEmpty()) {
				Collection<BPMBusinessProgram> lBPMBusinessPrograms = lBPMBusinessProgramMap.values();
				
				for (BPMBusinessProgram lBPMBusinessProgram : lBPMBusinessPrograms) {
						
					emailContent
						.append("<tr><td>Group Name: </td><td colspan=2>" + lBPMBusinessProgram.getGroupName() + "</td></tr>");
					emailContent
						.append("<tr><td>Site Name: </td><td>" + lBPMBusinessProgram.getSiteName() + "</td></tr>");
					emailContent
						.append("<tr><td>Effective Dates: </td><td>" + BPMUtils.formatDateMMddyyyy(lBPMBusinessProgram.getEffectiveDate()) + " | " + BPMUtils.formatDateMMddyyyy(lBPMBusinessProgram.getEndDate()) + "</td><td></tr>");
					emailContent
						.append("<tr><td colspan=2>-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td><td></tr>");		
				}
				
				emailContent
				.append("<tr><td></td><td></tr>");
			} else {
				emailContent
				.append("<tr><td>Business Program Not Available</td></tr>");	
			}
			
		}
		
		emailContent.append("</table>");
		emailContent.append("<table>");
		
		emailContent
		.append("<tr><td>Total Records From Input File:</td><td> "
				+ employerActivities
						.getTotalNumberOfMemberActivityLines()
				+ "</td></tr>");
		emailContent
		.append("<tr><td colspan=2>-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td><td></tr>");		
		if (employerActivities
				.getValidMemberActivities() != null) {
			emailContent
					.append("<tr><td>Total Valid Records From Activity Event Table:</td><td> "
							+ employerActivities
										.getValidMemberActivities().size()
							+ "</td></tr>");
		} else {
			emailContent
			.append("<tr><td>Total Valid Records From Activity Event Table:</td><td> "
					+ "0"
					+ "</td></tr>");
		}
		if (personProgramActivityIncentiveStatusAL != null) {
			emailContent
					.append("<tr><td>Total Activity Records Incented Successfully:</td><td> "
							+ personProgramActivityIncentiveStatusAL.size()
							+ "</td></tr>");
		} else {
			emailContent
			.append("<tr><td>Total Activity Records Incented Successfully:</td><td> "
					+ "0"
					+ "</td></tr>");
		}
		
		if (contractRecordCount != null) {
			emailContent
					.append("<tr><td>Total Contract Records To Be Sent to Surround:</td><td> "
							+ contractRecordCount
							+ "</td></tr>");
		} else {
			emailContent
			.append("<tr><td>Total Contract Records To Be Sent to Surround:</td><td> "
					+ "0"
					+ "</td></tr>");
		}
		
		if (errorRecycleAL != null) {
			emailContent
			.append("<tr><td>A) Total Records In Error Recycle:</td><td> "
					+ errorRecycleAL.size()
					+ "</td></tr>");
		} else {
			emailContent
			.append("<tr><td>A) Total Records In Error Recycle:</td><td> "
					+ "0"
					+ "</td></tr>");
		}
		
		if (employerSponsoredActivityPendingAL != null) {
			emailContent
			.append("<tr><td>B) Total Records Pending:</td><td> "
					+ employerSponsoredActivityPendingAL.size()
					+ "</td></tr>");
		} else {
			emailContent
			.append("<tr><td>B) Total Records Pending:</td><td> "
					+ "0"
					+ "</td></tr>");
		}
		
		if (employerSponsoredActivityInProcessAL != null) {
			emailContent
			.append("<tr><td>C) Total Records InProcess:</td><td> "
					+ employerSponsoredActivityInProcessAL.size()
					+ "</td></tr>");
		} else {
			emailContent
			.append("<tr><td>C) Total Records InProcess:</td><td> "
					+ "0"
					+ "</td></tr>");
		}
		
		if (employerSponsoredActivityFilteredOutAL != null) {
			emailContent
					.append("<tr><td>D) Total Records Filtered Out: </td><td>"
							+ employerSponsoredActivityFilteredOutAL.size()
							+ "</td></tr>");
		} else {
			emailContent
			.append("<tr><td>D) Total Records Filtered Out: </td><td>"
					+ "0"
					+ "</td></tr>");
		}
		
		if (employerSponsoredActivityMissingInActivityEventLogAL != null) {
			emailContent
			.append("<tr><td>E) Total Records Missing From Activity Event Log: </td><td>"
					+ employerSponsoredActivityMissingInActivityEventLogAL.size()
					+ "</td></tr>");
		} else {
			emailContent
			.append("<tr><td>E) Total Records Missing From Activity Event Log: </td><td>"
					+ "0"
					+ "</td></tr>");
		}
		
		if (employerSponsoredActivityMissingInActivityIncentedNRecycleAL != null) {
			emailContent
			.append("<tr><td>F) Total Records Missing From Activity Incented Table and Recycle Table: </td><td>"
					+ employerSponsoredActivityMissingInActivityIncentedNRecycleAL.size()
					+ "</td></tr>");
		} else {
			emailContent
			.append("<tr><td>F) Total Records Missing From Activity Incented Table and Recycle Table: </td><td>"
					+ "0"
					+ "</td></tr>");
		}
		
		if (employerSponsoredActivityUnresolvedMemberIDAL != null) {
			emailContent
			.append("<tr><td>G) Total Records Flagged For Unresolved Member No: </td><td>"
					+ employerSponsoredActivityUnresolvedMemberIDAL.size()
					+ "</td></tr>");
		} else {
			emailContent
			.append("<tr><td>G) Total Records Flagged For Unresolved Member No:</td><td>"
					+ "0"
					+ "</td></tr>");
		}
		
		
		
		emailContent
		.append("<tr><td> </td></tr>");
		emailContent
		.append("<tr><td> </td></tr>");		
		
		if (employerActivities.getValidMemberActivities() != null) {
			emailContent
			.append("<tr><td>Total Valid Contributions From Activity Event Table: </td><td>$" 
					+ totalEmployerSponsoredActivityAmounts(employerActivities.getValidMemberActivities())
					+ "</td></tr>");
		} else {
			emailContent
			.append("<tr><td>Total Valid Contributions From Activity Event Table:  </td><td>$"
					+ "0"
					+ "</td></tr>");
		}
		
		if (personProgramActivityIncentiveStatusAL != null) {
			emailContent
			.append("<tr><td>Total Activity Contributions Incented Successfully: </td><td>$"
					+ totalPersonProgramActivityIncentiveStatusAmounts(personProgramActivityIncentiveStatusAL)
					+ "</td></tr>");
		} else {
			emailContent
			.append("<tr><td>Total Activity Contributions Incented Successfully: </td><td>$"
					+ "0"
					+ "</td></tr>");
		}
		
		if (errorRecycleAL != null) {
			emailContent
			.append("<tr><td>A) Total Contributions In Error Recycle: </td><td>$"
					+ totalErrorRecycleAmounts(errorRecycleAL)
					+ "</td></tr>");
		} else {
			emailContent
			.append("<tr><td>A) Total Contributions To Error Recycle: </td><td>$"
					+ "0"
					+ "</td></tr>");
		}
		
		if (employerSponsoredActivityPendingAL != null) {
			emailContent
			.append("<tr><td>B) Total Contributions Pending: </td><td>$"
					+ totalEmployerSponsoredActivityAmounts(employerSponsoredActivityPendingAL)
					+ "</td></tr>");
		} else {
			emailContent
			.append("<tr><td>B) Total Contributions Pending: </td><td>$"
					+ "0"
					+ "</td></tr>");
		}
		
		if (employerSponsoredActivityInProcessAL != null) {
			emailContent
			.append("<tr><td>C) Total Contributions InProcess: </td><td>$"
					+ totalEmployerSponsoredActivityAmounts(employerSponsoredActivityInProcessAL)
					+ "</td></tr>");
		} else {
			emailContent
			.append("<tr><td>C) Total Contributions InProcess: </td><td>$"
					+ "0"
					+ "</td></tr>");
		}
		
		if (employerSponsoredActivityFilteredOutAL != null) {
			emailContent
			.append("<tr><td>D) Total Contributions Filtered Out: </td><td>$" 
					+ totalEmployerSponsoredActivityAmounts(employerSponsoredActivityFilteredOutAL)
					+ "</td></tr>");
		} else {
			emailContent
			.append("<tr><td>D) Total Contributions Filtered Out: </td><td>$"
					+ "0"
					+ "</td></tr>");
		}
		
		if (employerSponsoredActivityMissingInActivityEventLogAL != null) {
			emailContent
			.append("<tr><td>E) Total Contributions Missing From Activity Event Log: </td><td>$"
					+ totalEmployerSponsoredActivityAmounts(employerSponsoredActivityMissingInActivityEventLogAL)
					+ "</td></tr>");
		} else {
			emailContent
			.append("<tr><td>E) Total Contributions Missing From Activity Event Log: </td><td>$"
					+ "0"
					+ "</td></tr>");
		}
		
		if (employerSponsoredActivityMissingInActivityIncentedNRecycleAL != null) {
			emailContent
			.append("<tr><td>F) Total Contributions Missing From Activity Incented Table and Recycle Table: </td><td>$"
					+ totalEmployerSponsoredActivityAmounts(employerSponsoredActivityMissingInActivityIncentedNRecycleAL)
					+ "</td></tr>");
		} else {
			emailContent
			.append("<tr><td>F) Total Contributions Missing From Activity Incented Table and Recycle Table: </td><td>$"
					+ "0"
					+ "</td></tr>");
		}
		
		if (employerSponsoredActivityUnresolvedMemberIDAL != null) {
			emailContent
			.append("<tr><td>G) Total Contributions Due To Unresolved Member No: </td><td>$"
					+ totalEmployerSponsoredActivityAmounts(employerSponsoredActivityUnresolvedMemberIDAL)
					+ "</td></tr>");
		} else {
			emailContent
			.append("<tr><td>G) Total Contributions Due To Unresolved Member No: </td><td>$"
					+ "0"
					+ "</td></tr>");
		}
		
		
		
		emailContent.append("</table>");
		emailContent.append("<table>");
		emailContent
		.append("<tr><td>***************************************************************************</td></tr>");
		emailContent
		.append("<tr><td>***Action to take based on the results of this report:</td></tr>");
		emailContent
		.append("<tr><td>***1) If Total Records match Total Records Processed Succesfully, NO ACTION IS NECESSARY.  INDICATES REPORT HAS BALANCED AND STATUS OF FILE IS IN A POSTPROCESS STATE.</td></tr>");
		emailContent
		.append("<tr><td>***2) If Total Records DO NOT MATCH Total Records Processed Succesfully, USE THE BREAKDOWN OF THE RECORD SUMMARY COUNTS TO DETERMINE WHY.  FILE REMAINS IN A INPROCESS STATE.</td></tr>");
		emailContent
		.append("<tr><td>***   A) For records in Error Recycle, go to BPM Admin Tool and link Person Employer Activity Recycle. </td></tr>");
		emailContent
		.append("<tr><td>***   B) For records pending, run the Pending Activities job kicked off through the BPM Admin Tool. </td></tr>");
		emailContent
		.append("<tr><td>***   C) For records INPROCESS, repend these activities and then run the Pending Activities job kicked off through the BPM Admin Tool. </td></tr>");
		emailContent
		.append("<tr><td>***   D) For records filtered out, go to Member Status screen and look for the reason why activity was filtered out. </td></tr>");
		emailContent
		.append("<tr><td>***   E) For records Missing From Activity Event Log, work with developer to determine why. </td></tr>");
		emailContent
		.append("<tr><td>***   F) For records Missing From Activity Incented Table and Recycle Table, work with developer to determine why. </td></tr>");
		emailContent
		.append("<tr><td>***   G) For records flagged with fatal errors, work with developer to determine why. </td></tr>");
		emailContent
		.append("<tr><td>***   Note: If all records have been accounted for but will not balance through this batch process, </td></tr>");
		emailContent
		.append("<tr><td>***         declare the file has balanced by setting the status to POSTPROCESS on the Person Employer Activity Upload Search screen within the BPM Admin Tool.  </td></tr>");
		emailContent
		.append("<tr><td>***         Notify the developer that the files status is being set manually.  The developer will then need to physically move the file from the systems preprocess folder to the processed folder. </td></tr>");
		emailContent.append("</table>");
	}
	
	private void appendDetailSummary(StringBuffer emailContent, EmployerActivityContributionsFileData employerActivities) throws BPMException {
		
		//EV90233 - Control producing activity detail report from LUV table.
		LookUpValueCode uploadEmployerGroupLuv = null;
		try {
			uploadEmployerGroupLuv = lookUpValueService.getLUVCodeByGroupNValue(BPMConstants.CNTRL_OPTUM_DETAIL_RPT, BPMConstants.CNTRL_OPTUM_VALID_ACTIVITY_ENABLED);
		} catch (Exception e) {
			logger.error("Exception thrown after luv lookup in  appendDetailSummary method: " + e.getMessage());
			throw new BPMException(e);
		}
		
		String activityEnabled = uploadEmployerGroupLuv.getLuvDesc();
		
		int lineCtr;
		
		// valid activities processed
		if (activityEnabled.equals("Y")) {
			emailContent.append("<br><br><table>");
			emailContent
					.append("<tr><td>***************************************************************************</td></tr>");
			if (employerActivities.isRejectWholeFile()) {
				emailContent
						.append("<tr><td>Valid Member Activity(s) (No records were written to Activity Event Log due to fatal errors detected)</td></tr>");
				emailContent
						.append("<tr><td>***************************************************************************</td></tr>");
			} else {
				emailContent
						.append("<tr><td>Valid Member Activity(s) Added to Activity Event Log</td></tr>");
				emailContent
						.append("<tr><td>***************************************************************************</td></tr>");
			}
			emailContent.append("</table>");
			emailContent.append("<table>");
		
		
			if (employerActivities
					.getValidMemberActivities().size() > 0) {
				
				emailContent.append("<tr><td> Line</td><td>MemberID</td><td>Person ID</td><td>First Name</td><td>MI</td><td>Last Name</td><td>DOB</td><td>Gender</td><td>PersonID</td><td>Activity Name</td><td>Activity Date</td><td>Amt</td></tr>");
						
				Iterator<EmployerSponsoredActivity> itrValAct = employerActivities
						.getValidMemberActivities().iterator();
				int lineNbr = 1;
				while (itrValAct.hasNext()) {
					EmployerSponsoredActivity empActivity = itrValAct.next();
					emailContent
					.append("<tr><td colspan=13>---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
					emailContent.append("<tr><td> "
							+ lineNbr + "</td><td>"
							+ empActivity.getMemberID() + "</td><td>"
							+ empActivity.getPersonID() + "</td><td>"
							+ empActivity.getFirstName() + "</td><td>" 
							+ empActivity.getMiddleName() + "</td><td>" 
							+ empActivity.getLastName() + "</td><td>" 
							+ empActivity.getDateOfBirth() + "</td><td>" 
							+ empActivity.getGender() + "</td><td>" 
							+ empActivity.getPersonID() + "</td><td>" 
							+ empActivity.getActivityName() + "</td><td>"
							+ empActivity.getActivityDate() + "</td><td>$" 
							+ empActivity.getAmountEarned() + 	
							"</td></tr>");
					lineNbr++;
				}
			}
			emailContent.append("</table>");
		}
		
		emailContent.append("<table>");
		emailContent
		.append("<tr><td> </td></tr>");
		emailContent
		.append("<tr><td> </td></tr>");	
		
		if (errorRecycleAL !=null && errorRecycleAL.size() > 0) {
			emailContent.append("<table>");
			emailContent
			.append("<tr><td>***********************************************************</td></tr>");
			emailContent
			.append("<tr><td>LIST OF PARTICIPANTS IN ERROR RECYCLE: </td><td>"
					+ "</td></tr>");
			emailContent
			.append("<tr><td>***********************************************************</td></tr>");
			emailContent.append("</table>");
			emailContent.append("<table>");
			emailContent.append("<tr><td> Line</td><td>Last Name</td><td>First Name</td><td>Activity Name</td><td>Activity Date</td><td>Amount</td><td>Error reason</td></tr>");
			lineCtr = 1;
			for (RejectedPerson lRejectedPerson : errorRecycleAL) {
				emailContent
				.append("<tr><td colspan=6>--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
				emailContent
				.append("<tr><td>" + lineCtr 
						+ "</td><td>"
						+ lRejectedPerson.getLastName()
						+ "</td><td>"
						+ lRejectedPerson.getFirstName()
						+ "</td><td>"  
						+ lRejectedPerson.getActivityName()
						+ "</td><td>"
						+ lRejectedPerson.getActivityDate()
						+ "</td><td>"
						+ lRejectedPerson.getContributionAmount()
						+ "</td><td>"
						+ "Member activity is in Error Recycle due to no match against BPM eligibility."
						+ "</td></tr>");
				lineCtr++;
			}
		
			emailContent.append("</table>");
		}
		
		emailContent.append("<table>");
		emailContent
		.append("<tr><td> </td></tr>");
		emailContent
		.append("<tr><td> </td></tr>");	
		
		String listDescription = "";
		if (employerSponsoredActivityUnresolvedMemberIDAL !=null && employerSponsoredActivityUnresolvedMemberIDAL.size() > 0) {
			listDescription = "LIST OF PARTICIPANTS WITH UNRESOLVED MEMBER NUMBERS: ";
			employerSponsoredErrorDetailSummary(emailContent, employerSponsoredActivityUnresolvedMemberIDAL, listDescription);
			
		}
		
		if (employerSponsoredActivityMissingInActivityIncentedNRecycleAL !=null && employerSponsoredActivityMissingInActivityIncentedNRecycleAL.size() > 0) {
			listDescription = "LIST OF PARTICIPANTS WITH ACTIVITIES THAT DID NOT REACH THE INCENTED TABLE OR ERROR RECYCLE: ";
			employerSponsoredErrorDetailSummary(emailContent, employerSponsoredActivityMissingInActivityIncentedNRecycleAL, listDescription);
		}
	
		
		if (employerSponsoredActivityPendingAL !=null && employerSponsoredActivityPendingAL.size() > 0) {
			listDescription = "LIST OF PARTICIPANTS WITH ACTIVITIES STILL IN A PENDING STATUS: ";
			employerSponsoredErrorDetailSummary(emailContent, employerSponsoredActivityPendingAL, listDescription);
		}
		
		if (employerSponsoredActivityInProcessAL !=null && employerSponsoredActivityInProcessAL.size() > 0) {
			listDescription = "LIST OF PARTICIPANTS WITH ACTIVITIES THAT ARE PENDING OR INPROCESS: ";
			employerSponsoredErrorDetailSummary(emailContent, employerSponsoredActivityPendingAL, listDescription);
		}
		
		if (employerSponsoredActivityFilteredOutAL !=null && employerSponsoredActivityFilteredOutAL.size() > 0) {
			listDescription = "LIST OF PARTICIPANTS WITH ACTIVITIES FILTERED OUT: ";
			employerSponsoredErrorDetailSummary(emailContent, employerSponsoredActivityFilteredOutAL, listDescription);
		}
		
		emailContent.append("</table>");
		
	}
	
	private void employerSponsoredErrorDetailSummary(StringBuffer emailContent, ArrayList<EmployerSponsoredActivity> lEmployerSponsoredActivityAL, String listDescription) {
			emailContent
			.append("<tr><td>*******************************************************************************************************************************************</td></tr>");
			emailContent
			.append("<tr><td>" + listDescription + "</td><td></td></tr>");
					
			emailContent
			.append("<tr><td>*******************************************************************************************************************************************</td></tr>");
			emailContent.append("</table>");
			emailContent.append("<table>");
			emailContent.append("<tr><td> Line</td><td>Member No</td><td>Person ID</td><td>Activity Name</td><td>Activity Date</td><td>Amount</td><td>Error reason</td></tr>");
			int lineCtr = 1;
			for (EmployerSponsoredActivity lEmployerSponsoredActivity : lEmployerSponsoredActivityAL) {
				emailContent
				.append("<tr><td colspan=6>--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>");
				emailContent
				.append("<tr><td>" + lineCtr 
						+ "</td><td>"
						+ lEmployerSponsoredActivity.getMemberID()
						+ "</td><td>"
						+ lEmployerSponsoredActivity.getPersonID()
						+ "</td><td>"  
						+ lEmployerSponsoredActivity.getActivityName()
						+ "</td><td>"
						+ lEmployerSponsoredActivity.getActivityDate()
						+ "</td><td>"
						+ lEmployerSponsoredActivity.getAmountEarned()
						+ "</td><td>"
						+ lEmployerSponsoredActivity.getErrorReason()
						+ "</td></tr>");
				lineCtr++;
			}
		
			emailContent.append("</table>");
	
	}
		
	
	private ArrayList<String> determineEmailAttachments(ControlGroupIOFileDirSetup lControlGroupIOFileDirSetup) {
		ArrayList<String> emailAttachmentLocations = new ArrayList<String>();
		
		if (lControlGroupIOFileDirSetup.getGeneratedContractPathNFileName() != null) {
			String emailAttachmentLocationContract = lControlGroupIOFileDirSetup.getGeneratedContractPathNFileName().trim();
			emailAttachmentLocations.add(emailAttachmentLocationContract);
		}
		
		if (lControlGroupIOFileDirSetup.getGeneratedDetailPathNFileName() != null) {
			String emailAttachmentLocationDetail = lControlGroupIOFileDirSetup.getGeneratedDetailPathNFileName().trim();
			emailAttachmentLocations.add(emailAttachmentLocationDetail);
		}
		
		
		return emailAttachmentLocations;
		
	}
	
	private void moveFilesFromPreprocessToProcessed(String fileLocationPreprocess, String fileLocationProcessed, String groupNo) throws BPMException {
		
		logger.info("Move file for group " + groupNo + " from " + fileLocationPreprocess + " to " + fileLocationProcessed);
		BPMUtils.moveFiles(fileLocationPreprocess, fileLocationProcessed);
			
	}
	
	private Integer totalEmployerSponsoredActivityAmounts(Collection<EmployerSponsoredActivity> employerSponsoredActivities) {
		Integer totalAmount = 0;
		
		for (EmployerSponsoredActivity employerSponsoredActivity : employerSponsoredActivities) {
			totalAmount= totalAmount + Integer.valueOf(employerSponsoredActivity.getAmountEarned());
		}
		
		return totalAmount;
	}
	
	private Integer totalPersonProgramActivityIncentiveStatusAmounts(Collection<PersonProgramActivityIncentiveStatus> personProgramActivityIncentiveStatuses) {
		Integer totalAmount = 0;
		
		for (PersonProgramActivityIncentiveStatus personProgramActivityIncentiveStatus : personProgramActivityIncentiveStatuses) {
			totalAmount= totalAmount + personProgramActivityIncentiveStatus.getContributionAmt();
		}
		
		return totalAmount;
	}
	
	private Integer totalErrorRecycleAmounts(Collection<RejectedPerson> errorRecycleAmounts) {
		Integer totalAmount = 0;
		
		for (RejectedPerson errorRecycleAmount : errorRecycleAmounts) {
			totalAmount= totalAmount + errorRecycleAmount.getContributionAmount();
		}
		
		return totalAmount;
	}
	
	private void instantiateActivityALs() {
		    setPersonProgramActivityIncentiveStatusAL(new ArrayList<PersonProgramActivityIncentiveStatus>());
			setEmployerSponsoredActivityPendingAL(new ArrayList<EmployerSponsoredActivity>());
			setEmployerSponsoredActivityInProcessAL(new ArrayList<EmployerSponsoredActivity>());
			setEmployerSponsoredActivityFilteredOutAL(new ArrayList<EmployerSponsoredActivity>());
			setEmployerSponsoredActivityMissingInActivityEventLogAL(new ArrayList<EmployerSponsoredActivity>());
			setEmployerSponsoredActivityMissingInActivityIncentedNRecycleAL(new ArrayList<EmployerSponsoredActivity>());
			setEmployerSponsoredActivityUnresolvedMemberIDAL(new ArrayList<EmployerSponsoredActivity>());
			setErrorRecycleAL(new ArrayList<RejectedPerson>());
		
	}
	private void clearActivityALs() {
		
		if (personProgramActivityIncentiveStatusAL != null) {
			personProgramActivityIncentiveStatusAL.clear();
		}
		if (employerSponsoredActivityPendingAL != null) {
			employerSponsoredActivityPendingAL.clear();
		}
		if (employerSponsoredActivityInProcessAL != null) {
			employerSponsoredActivityInProcessAL.clear();
		}
		if (employerSponsoredActivityFilteredOutAL != null) {
			employerSponsoredActivityFilteredOutAL.clear();
		}
		if (employerSponsoredActivityMissingInActivityEventLogAL != null) {
			employerSponsoredActivityMissingInActivityEventLogAL.clear();
			
		}if (employerSponsoredActivityMissingInActivityIncentedNRecycleAL != null) {
			employerSponsoredActivityMissingInActivityIncentedNRecycleAL.clear();
		}
		if (employerSponsoredActivityUnresolvedMemberIDAL != null) {
			employerSponsoredActivityUnresolvedMemberIDAL.clear();
		}
	}
	
	
	
	public void setLookUpValueService(LookUpValueService lookUpValueService) {
		this.lookUpValueService = lookUpValueService;
	}


	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}
	
	

	public void setBusinessProgramService(
			BusinessProgramService businessProgramService) {
		this.businessProgramService = businessProgramService;
	}
	public void setGroupActivityProgressTrackerService(
			GroupActivityProgressTrackerService groupActivityProgressTrackerService) {
		this.groupActivityProgressTrackerService = groupActivityProgressTrackerService;
	}

	
	
	public void setActivityEventService(ActivityEventService activityEventService) {
		this.activityEventService = activityEventService;
	}
	
	public void setPersonDAO(PersonDAO personDAO) {
		this.personDAO = personDAO;
	}
	
	
	
	public void setEmployerRecycleDAO(EmployerRecycleDAO employerRecycleDAO) {
		this.employerRecycleDAO = employerRecycleDAO;
	}
	
	
	
	public void setControlGroupIOFileDirSetupDAO(
			ControlGroupIOFileDirSetupDAO controlGroupIOFileDirSetupDAO) {
		this.controlGroupIOFileDirSetupDAO = controlGroupIOFileDirSetupDAO;
	}
	
	
	
	public void setBusinessProgramDAO(BusinessProgramDAO businessProgramDAO) {
		this.businessProgramDAO = businessProgramDAO;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public void setBpmEmailUtility(BPMEmailUtility bpmEmailUtility) {
		this.bpmEmailUtility = bpmEmailUtility;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public void setGroupActivityProgressTracker(
			GroupActivityProgressTracker groupActivityProgressTracker) {
		this.groupActivityProgressTracker = groupActivityProgressTracker;
	}
	public ArrayList<PersonProgramActivityIncentiveStatus> getPersonProgramActivityIncentiveStatusAL() {
		return personProgramActivityIncentiveStatusAL;
	}
	public void setPersonProgramActivityIncentiveStatusAL(
			ArrayList<PersonProgramActivityIncentiveStatus> personProgramActivityIncentiveStatusAL) {
		this.personProgramActivityIncentiveStatusAL = personProgramActivityIncentiveStatusAL;
	}
	
	public ArrayList<RejectedPerson> getErrorRecycleAL() {
		return errorRecycleAL;
	}
	public void setErrorRecycleAL(ArrayList<RejectedPerson> errorRecycleAL) {
		this.errorRecycleAL = errorRecycleAL;
	}
	public ArrayList<EmployerSponsoredActivity> getEmployerSponsoredActivityPendingAL() {
		return employerSponsoredActivityPendingAL;
	}
	public void setEmployerSponsoredActivityPendingAL(
			ArrayList<EmployerSponsoredActivity> employerSponsoredActivityPendingAL) {
		this.employerSponsoredActivityPendingAL = employerSponsoredActivityPendingAL;
	}
	
	public ArrayList<EmployerSponsoredActivity> getEmployerSponsoredActivityInProcessAL() {
		return employerSponsoredActivityInProcessAL;
	}
	public void setEmployerSponsoredActivityInProcessAL(
			ArrayList<EmployerSponsoredActivity> employerSponsoredActivityInProcessAL) {
		this.employerSponsoredActivityInProcessAL = employerSponsoredActivityInProcessAL;
	}
	
	public ArrayList<EmployerSponsoredActivity> getEmployerSponsoredActivityMissingInActivityEventLogAL() {
		return employerSponsoredActivityMissingInActivityEventLogAL;
	}
	public void setEmployerSponsoredActivityMissingInActivityEventLogAL(
			ArrayList<EmployerSponsoredActivity> employerSponsoredActivityMissingInActivityEventLogAL) {
		this.employerSponsoredActivityMissingInActivityEventLogAL = employerSponsoredActivityMissingInActivityEventLogAL;
	}
	public ArrayList<EmployerSponsoredActivity> getEmployerSponsoredActivityFilteredOutAL() {
		return employerSponsoredActivityFilteredOutAL;
	}
	public void setEmployerSponsoredActivityFilteredOutAL(
			ArrayList<EmployerSponsoredActivity> employerSponsoredActivityFilteredOutAL) {
		this.employerSponsoredActivityFilteredOutAL = employerSponsoredActivityFilteredOutAL;
	}
	
	public ArrayList<EmployerSponsoredActivity> getEmployerSponsoredActivityMissingInActivityIncentedNRecycleAL() {
		return employerSponsoredActivityMissingInActivityIncentedNRecycleAL;
	}
	public void setEmployerSponsoredActivityMissingInActivityIncentedNRecycleAL(
			ArrayList<EmployerSponsoredActivity> employerSponsoredActivityMissingInActivityIncentedNRecycleAL) {
		this.employerSponsoredActivityMissingInActivityIncentedNRecycleAL = employerSponsoredActivityMissingInActivityIncentedNRecycleAL;
	}
	public ArrayList<EmployerSponsoredActivity> getEmployerSponsoredActivityUnresolvedMemberIDAL() {
		return employerSponsoredActivityUnresolvedMemberIDAL;
	}
	public void setEmployerSponsoredActivityUnresolvedMemberIDAL(
			ArrayList<EmployerSponsoredActivity> employerSponsoredActivityUnresolvedMemberIDAL) {
		this.employerSponsoredActivityUnresolvedMemberIDAL = employerSponsoredActivityUnresolvedMemberIDAL;
	}
	
	
	
	
	
}

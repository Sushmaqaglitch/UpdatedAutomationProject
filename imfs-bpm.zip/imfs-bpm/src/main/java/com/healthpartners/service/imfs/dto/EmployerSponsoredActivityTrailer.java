
package com.healthpartners.service.imfs.dto;

/**
 * Represents trailer record from the optum file.
 * @author tjquist
 *
 */
public class EmployerSponsoredActivityTrailer {

	private String groupFileSourceName;
	
	private String columnLabel;
	
	private String recordCount;
	
	private String dateSent;
	
	private Integer totalAmount;
	
	
	
	public EmployerSponsoredActivityTrailer() {
		super();
	}



	public String getGroupFileSourceName() {
		return groupFileSourceName;
	}



	public void setGroupFileSourceName(String groupFileSourceName) {
		this.groupFileSourceName = groupFileSourceName;
	}


	

	public String getColumnLabel() {
		return columnLabel;
	}



	public void setColumnLabel(String columnLabel) {
		this.columnLabel = columnLabel;
	}



	public String getRecordCount() {
		return recordCount;
	}



	public void setRecordCount(String recordCount) {
		this.recordCount = recordCount;
	}



	public String getDateSent() {
		return dateSent;
	}



	public void setDateSent(String dateSent) {
		this.dateSent = dateSent;
	}



	public Integer getTotalAmount() {
		return totalAmount;
	}



	public void setTotalAmount(Integer totalAmount) {
		this.totalAmount = totalAmount;
	}

	


}

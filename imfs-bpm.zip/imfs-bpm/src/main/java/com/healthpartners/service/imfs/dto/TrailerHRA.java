package com.healthpartners.service.imfs.dto;


public class TrailerHRA
{	
	static final long serialVersionUID = 0L;

    public TrailerHRA()
    {
    	super();
    }

    private String recordType;    
    private String totalRecords;

	public String getRecordType() {
		return recordType;
	}
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}
	public String getTotalRecords() {
		return totalRecords;
	}
	public void setTotalRecords(String totalRecords) {
		this.totalRecords = totalRecords;
	}
	
    
}

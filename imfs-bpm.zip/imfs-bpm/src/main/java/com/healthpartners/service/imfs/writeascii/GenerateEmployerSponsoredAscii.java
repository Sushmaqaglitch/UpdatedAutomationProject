

package com.healthpartners.service.imfs.writeascii;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Calendar;
import java.util.Collection;
import java.util.StringTokenizer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.DetailEmployerSponsoredActivity;
import com.healthpartners.service.imfs.dto.DetailEmployerSponsoredContractSummary;
import com.healthpartners.service.imfs.dto.TrailerEmployerSponsoredActivity;
import com.healthpartners.service.imfs.dto.TrailerEmployerSponsoredContractSummary;
 
public class GenerateEmployerSponsoredAscii
{

	protected final Log logger = LogFactory.getLog(getClass());
   
   private FileWriter writer = null;
   
   private int recsWrittenActivity = 0;
   
   private int recsWrittenContractSummary = 0;
 
   public void GenerateCDHPHSATrackingAscii() {
	   
   }
   
   public int generateActivityAsciiFile(Collection<DetailEmployerSponsoredActivity> lDetailEmployerSponsoredActivitys, TrailerEmployerSponsoredActivity lTrailerEmployerSponsoredActivity) throws Exception {
	   
	   
	    EmployerSponsoredReportFileFormats lEmployerSponsoredReportFileFormats = new EmployerSponsoredReportFileFormats();
	    lEmployerSponsoredReportFileFormats.setDetailEmployerSponsoredActivitys(lDetailEmployerSponsoredActivitys);
	    lEmployerSponsoredReportFileFormats.setTrailerEmployerSponsoredActivity(lTrailerEmployerSponsoredActivity);
	    
	    if (writer != null) {
	    	logger.info("GenerateEmployerSponsoredAscii.generateActivityAsciiFile: FileWriter instantiated indicating directory permissions are working.");
	    	lEmployerSponsoredReportFileFormats.setFileWriter(writer);
	    } else {
	    	String errorMessage = "GenerateEmployerSponsoredAscii.generateActivityAsciiFile: FileWriter is null indicating directory permissions are not working.";
	    	logger.error(errorMessage);
	    	throw new Exception(errorMessage);
	    }
	    
	  
	   
	    lEmployerSponsoredReportFileFormats.processFileEmployerSponsoredActivityDetail();
	    setRecsWrittenActivity(lEmployerSponsoredReportFileFormats.getRecsWrittenActivity());
	   
		
	   	return recsWrittenActivity;
		
	}
   
   public int generateContractSummaryAsciiFile(Collection<DetailEmployerSponsoredContractSummary> lDetailEmployerSponsoredContractSummarys, TrailerEmployerSponsoredContractSummary lTrailerEmployerSponsoredContractSummary) throws Exception {
	   
	   
	    EmployerSponsoredReportFileFormats lEmployerSponsoredReportFileFormats = new EmployerSponsoredReportFileFormats();
	    lEmployerSponsoredReportFileFormats.setDetailEmployerSponsoredContractSummarys(lDetailEmployerSponsoredContractSummarys);
	    lEmployerSponsoredReportFileFormats.setTrailerEmployerSponsoredContractSummary(lTrailerEmployerSponsoredContractSummary);
	    
	    if (writer != null) {
	    	logger.info("GenerateEmployerSponsoredAscii.generateContractSummaryAsciiFile: FileWriter instantiated indicating directory permissions are working.");
	    	lEmployerSponsoredReportFileFormats.setFileWriter(writer);
	    } else {
	    	String errorMessage = "GenerateEmployerSponsoredAscii.generateContractSummaryAsciiFile: FileWriter is null indicating directory permissions are not working.";
	    	logger.error(errorMessage);
	    	throw new Exception(errorMessage);
	    }
	    
	  
	   
	    lEmployerSponsoredReportFileFormats.processFileEmployerSponsoredContractSummary();
	    setRecsWrittenContractSummary(lEmployerSponsoredReportFileFormats.getRecsWrittenContractSummary());
	   
		
	   	return recsWrittenContractSummary;
		
	}
   
   
 public String openFileWriter(String processedOutputFilePath, String fileName) {
	
	 Calendar calDate = Calendar.getInstance();

     String calDateStr = BPMUtils.formatDateMMddyyyy(calDate);
     StringTokenizer strDate = new StringTokenizer(calDateStr, "/");
     String month = strDate.nextToken();
     String day = strDate.nextToken();
     String year = strDate.nextToken();
     
     File topLevelDirProcessedFile = new File(processedOutputFilePath);
     if((topLevelDirProcessedFile.mkdirs())) {
         logger.info("Created processed directory: " + topLevelDirProcessedFile.getPath());
     }
     
     //String outputFileName =  outputFilePathNFileNameForFTP + year + month + day + calDate.get(Calendar.HOUR_OF_DAY) + calDate.get(Calendar.MINUTE) + calDate.get(Calendar.SECOND) + ".csv";
     String outputFileName =  processedOutputFilePath + fileName + year + month + day + calDate.get(Calendar.HOUR_OF_DAY) + calDate.get(Calendar.MINUTE) + calDate.get(Calendar.SECOND) + ".csv";
     logger.info("GenerateEmployerSponsoredFileAscii: Output File name is " + outputFileName);
     
     try{
    	 writer = new FileWriter(outputFileName); 
    	 
	 } catch(IOException e)
		{
		     e.printStackTrace();
		} 
    
     return outputFileName;
 	}

	public void closeFileWriter() {
		try {
		 writer.flush();
		 writer.close();
		} catch(IOException e)
		{
		     e.printStackTrace();
		} 
	}


	public void setRecsWrittenActivity(int recsWrittenActivity) {
		this.recsWrittenActivity = recsWrittenActivity;
	}

	public void setRecsWrittenContractSummary(int recsWrittenContractSummary) {
		this.recsWrittenContractSummary = recsWrittenContractSummary;
	}
	
	
	  
  
}
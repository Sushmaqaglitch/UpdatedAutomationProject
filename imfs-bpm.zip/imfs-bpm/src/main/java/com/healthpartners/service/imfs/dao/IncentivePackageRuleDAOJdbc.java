package com.healthpartners.service.imfs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.healthpartners.service.imfs.dto.IncentivePackageRuleDetail;
import com.healthpartners.service.imfs.dto.IncentivePackageRuleGroup;
import com.healthpartners.service.imfs.dto.IncentivePackageRuleRequirement;
import com.healthpartners.service.imfs.dto.NamedParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;

import com.healthpartners.service.imfs.dto.IncentivePackageRuleDetail;
import com.healthpartners.service.imfs.dto.IncentivePackageRuleGroup;
import com.healthpartners.service.imfs.dto.IncentivePackageRuleRequirement;
import com.healthpartners.service.imfs.exception.BPMException;
import org.springframework.transaction.annotation.Transactional;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;

/**
 * 
 * @author jxbourbour
 * 
 */
@Configuration
public class IncentivePackageRuleDAOJdbc extends JdbcDaoSupport implements IncentivePackageRuleDAO 
{
	private String selectIncentivePackageRuleGroups;
	private String insertIncentivePackageRuleGroup;
	private String deleteIncentivePackageRuleGroup;
	private String updateIncentivePackageRuleGroup;

	@Autowired
	private DataFieldMaxValueIncrementer incentivePackageRuleGroupIDIncrementer;
	
	private String selectIncentivePackageRuleRequirement;
	private String selectIncentivePackageRuleDetail;
	private String insertIncentivePackageRuleRequirement;
	private String insertIncentivePackageRuleDetail;
	private String deleteIncentivePackageRuleRequirements;
	private String deleteIncentivePackageRuleDetails;
	private String updateIncentivePackageRuleDetail;

	public IncentivePackageRuleDAOJdbc() {
		super();
	}

	@Autowired
	DataSource bpmDataSource;


	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}

	/**
	 * Retrieve a list of all the participation group definitions.
	 */
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<IncentivePackageRuleGroup> getIncentivePackageRuleGroups() throws BPMException, DataAccessException
	{
		final ArrayList<IncentivePackageRuleGroup> lIncentivePackageRuleGroupList = new ArrayList<IncentivePackageRuleGroup>();

		NamedParameter namedParameter = new NamedParameter();

		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);
		namedParameterJdbcTemplate.query(selectIncentivePackageRuleGroups, namedParameters, new RowMapper() {
			@Override
			public IncentivePackageRuleGroup mapRow(ResultSet rs, int i) throws SQLException {
				IncentivePackageRuleGroup lIncentivePackageRuleGroup = new IncentivePackageRuleGroup();

				lIncentivePackageRuleGroup.setIncentivePackageRuleGroupID(rs.getInt("incntv_optn_pkg_rule_grp_id"));
				lIncentivePackageRuleGroup.setIncentivePackageRuleGroupName(rs.getString("incntv_optn_pkg_rule_grp_nm"));
				lIncentivePackageRuleGroup.setIncentivePackageRuleGroupInfo(rs.getString("incntv_optn_pkg_rule_grp_info"));
				lIncentivePackageRuleGroup.setIncentivePackageRuleGroupDesc(rs.getString("incntv_optn_pkg_rule_grp_desc"));
				lIncentivePackageRuleGroup.setEffectiveDate(rs.getDate("EFF_DT"));
				lIncentivePackageRuleGroup.setEndDate(rs.getDate("END_DT"));
				lIncentivePackageRuleGroup.setUsed("Y".equals(rs.getString("used_flg")));
				return lIncentivePackageRuleGroup;
			}

		});

		return lIncentivePackageRuleGroupList;
	}

	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public IncentivePackageRuleGroup getIncentivePackageRuleGroup(Integer pIncentivePackageRuleGroupID) throws BPMException, DataAccessException 
	{

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { pIncentivePackageRuleGroupID };
		int types[] = new int[] { Types.INTEGER };
		
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectIncentivePackageRuleGroups);
		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setIncentiveReqGroupId(pIncentivePackageRuleGroupID);
		lQuery.append(" WHERE incntv_optn_pkg_rule_grp_id = :incentiveReqGroupId ");

		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);

		List<IncentivePackageRuleGroup> lIncentivePackageRuleGroupList = namedParameterJdbcTemplate.query(lQuery.toString(), namedParameters, new RowMapper() {
			@Override
			public IncentivePackageRuleGroup mapRow(ResultSet rs, int i) throws SQLException {
				IncentivePackageRuleGroup lIncentivePackageRuleGroup = new IncentivePackageRuleGroup();

				lIncentivePackageRuleGroup.setIncentivePackageRuleGroupID(rs.getInt("incntv_optn_pkg_rule_grp_id"));
				lIncentivePackageRuleGroup.setIncentivePackageRuleGroupName(rs.getString("incntv_optn_pkg_rule_grp_nm"));
				lIncentivePackageRuleGroup.setIncentivePackageRuleGroupInfo(rs.getString("incntv_optn_pkg_rule_grp_info"));
				lIncentivePackageRuleGroup.setIncentivePackageRuleGroupDesc(rs.getString("incntv_optn_pkg_rule_grp_desc"));
				lIncentivePackageRuleGroup.setEffectiveDate(rs.getDate("EFF_DT"));
				lIncentivePackageRuleGroup.setEndDate(rs.getDate("END_DT"));
				lIncentivePackageRuleGroup.setUsed("Y".equals(rs.getString("used_flg")));
				return lIncentivePackageRuleGroup;
			}

		});

		return lIncentivePackageRuleGroupList.get(0);
	}

	/**
	 * Insert into the incntv_participation_grp table.
	 * 
	 * @param pIncentivePackageRuleGroup
	 * @param pModifyUserID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int insertIncentivePackageRuleGroup(IncentivePackageRuleGroup pIncentivePackageRuleGroup, String pModifyUserID)
	throws BPMException, DataAccessException 
	{
		JdbcTemplate template = getJdbcTemplate();
		int rowInserted = 0;

		Long lIncentivePackageRuleGroupID = new Long(incentivePackageRuleGroupIDIncrementer.nextLongValue());

		Object params[] = new Object[] { lIncentivePackageRuleGroupID
				, pIncentivePackageRuleGroup.getIncentivePackageRuleGroupName()
				, pIncentivePackageRuleGroup.getIncentivePackageRuleGroupInfo()
				, pIncentivePackageRuleGroup.getIncentivePackageRuleGroupDesc()
				, pIncentivePackageRuleGroup.getEffectiveDate()
				, pIncentivePackageRuleGroup.getEndDate()
				, pModifyUserID, pModifyUserID };

		int types[] = new int[] { Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.DATE, Types.DATE,
				Types.VARCHAR, Types.VARCHAR };

		rowInserted = template.update(insertIncentivePackageRuleGroup, params, types);

		pIncentivePackageRuleGroup.setIncentivePackageRuleGroupID(new Integer(lIncentivePackageRuleGroupID.intValue()));
		insertIncentivePackageRuleRequirements(pIncentivePackageRuleGroup, pModifyUserID);

		return rowInserted;
	}

	/**
	 * Delete from incntv_participation_grp table
	 * 
	 * @param lIncentivePackageRuleGroupID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int deleteIncentivePackageRuleGroup(Integer lIncentivePackageRuleGroupID) throws BPMException, DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		int rowInserted = 0;

		Object params[] = new Object[] { lIncentivePackageRuleGroupID
				//, lIncentivePackageRuleGroupID   // TODO add when incentive option package rule is added to biz pgm incentive option. 
				};

		int types[] = new int[] { Types.INTEGER
				//, Types.INTEGER 
				};

		deleteIncentivePackageRuleRequirements(lIncentivePackageRuleGroupID);
		rowInserted = template.update(deleteIncentivePackageRuleGroup, params, types);
		return rowInserted;
	}

	/**
	 * Update the incntv_participation_grp table
	 * 
	 * @param pIncentivePackageRuleGroup
	 * @param pModifyUserID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int updateIncentivePackageRuleGroup(IncentivePackageRuleGroup pIncentivePackageRuleGroup, String pModifyUserID)
			throws BPMException, DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		int rowInserted = 0;

		if (!pIncentivePackageRuleGroup.isPersistent()) {
			rowInserted = this.insertIncentivePackageRuleGroup(pIncentivePackageRuleGroup, pModifyUserID);
		} else {
			Object params[] = new Object[] { pIncentivePackageRuleGroup.getIncentivePackageRuleGroupName(),
					pIncentivePackageRuleGroup.getIncentivePackageRuleGroupInfo(), pIncentivePackageRuleGroup.getIncentivePackageRuleGroupDesc(),
					pIncentivePackageRuleGroup.getEffectiveDate(), pIncentivePackageRuleGroup.getEndDate(), pModifyUserID,
					pIncentivePackageRuleGroup.getIncentivePackageRuleGroupID() };

			int types[] = new int[] { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.DATE, Types.DATE,
					Types.VARCHAR, Types.INTEGER };

			rowInserted = template.update(updateIncentivePackageRuleGroup, params, types);
		}

		deleteIncentivePackageRuleRequirements(pIncentivePackageRuleGroup.getIncentivePackageRuleGroupID());
		insertIncentivePackageRuleRequirements(pIncentivePackageRuleGroup, pModifyUserID);
		
		return rowInserted;
	}

	/**
	 * 
	 * @param lIncentivePackageRuleGroupID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public ArrayList<IncentivePackageRuleRequirement> getIncentivePackageRuleRequirements(Integer lIncentivePackageRuleGroupID)
	throws BPMException, DataAccessException 
	{
		final ArrayList<IncentivePackageRuleRequirement> lIncentivePackageRuleRequirements = new ArrayList<IncentivePackageRuleRequirement>();

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { lIncentivePackageRuleGroupID };
		int types[] = new int[] { Types.INTEGER };

		template.query(selectIncentivePackageRuleRequirement, params, types, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				IncentivePackageRuleRequirement lIncentivePackageRuleRequirement = new IncentivePackageRuleRequirement();
				
				lIncentivePackageRuleRequirement.setIncentivePackageRuleRequirementID(rs.getInt("incntv_optn_pkg_rule_req_id"));
				lIncentivePackageRuleRequirement.setIncentivePackageRuleGroupID(rs.getInt("incntv_optn_pkg_rule_grp_id"));
				
				lIncentivePackageRuleRequirements.add(lIncentivePackageRuleRequirement);
			}
		});

		// Now for each IncentivePackageRuleGroupRequirement, retrieve the Details.
		for (IncentivePackageRuleRequirement requirement : lIncentivePackageRuleRequirements) {
			ArrayList<IncentivePackageRuleDetail> lIncentivePackageRuleDetails = getIncentivePackageRuleDetails(requirement);
			requirement.setIncentivePackageRuleDetails(lIncentivePackageRuleDetails);
		}

		return lIncentivePackageRuleRequirements;
	}

	/**
	 *
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public ArrayList<IncentivePackageRuleDetail> getIncentivePackageRuleDetails(IncentivePackageRuleRequirement requirement)
			throws BPMException, DataAccessException {
		final ArrayList<IncentivePackageRuleDetail> lIncentivePackageRuleDetails = new ArrayList<IncentivePackageRuleDetail>();

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { requirement.getIncentivePackageRuleGroupID(),
				requirement.getIncentivePackageRuleRequirementID() };
		int types[] = new int[] { Types.INTEGER, Types.INTEGER };

		template.query(selectIncentivePackageRuleDetail, params, types, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				IncentivePackageRuleDetail lIncentivePackageRuleDetail = new IncentivePackageRuleDetail();
				
				lIncentivePackageRuleDetail.setIncentivePackageRuleDetailID(rs.getInt("incntv_optn_pkg_rule_dtl_id"));
				lIncentivePackageRuleDetail.setIncentivePackageRuleRequirementID(rs.getInt("incntv_optn_pkg_rule_req_id"));
				lIncentivePackageRuleDetail.setIncentivePackageRuleGroupID(rs.getInt("incntv_optn_pkg_rule_grp_id"));								
				lIncentivePackageRuleDetail.setIncentivePackageRuleCodeID(rs.getInt("incntv_optn_pkg_rule_cd_id"));
				lIncentivePackageRuleDetail.setIncentivePackageRuleCodeValue(rs.getString("incntv_optn_pkg_rule_cd"));
				lIncentivePackageRuleDetail.setSourceCode(rs.getString("srce_cd"));				
				lIncentivePackageRuleDetail.setLogicOperatorCodeID(rs.getInt("logic_optr_cd_id"));
				lIncentivePackageRuleDetail.setLogicOperatorCodeValue(rs.getString("logic_optr_cd"));
				
				

				lIncentivePackageRuleDetails.add(lIncentivePackageRuleDetail);
			}
		});

		return lIncentivePackageRuleDetails;
	}

	/**
	 * 
	 * @param pIncentivePackageRuleGroup
	 * @param pModifyUserID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	private int insertIncentivePackageRuleRequirements(IncentivePackageRuleGroup pIncentivePackageRuleGroup, String pModifyUserID)
	throws BPMException, DataAccessException 
	{
		int rowInserted = 0;
		List<IncentivePackageRuleRequirement> participationGroupRequirements = 
				pIncentivePackageRuleGroup.getIncentivePackageRuleRequirements();				
		
		for (int i = 0; i < participationGroupRequirements.size(); i++) 
		{
			IncentivePackageRuleRequirement requirement = participationGroupRequirements.get(i);
			requirement.setIncentivePackageRuleGroupID(pIncentivePackageRuleGroup.getIncentivePackageRuleGroupID());
			requirement.setIncentivePackageRuleRequirementID(i);
			rowInserted += insertIncentivePackageRuleRequirement(requirement, pModifyUserID);
			List<IncentivePackageRuleDetail> participationGroupDetails = requirement.getIncentivePackageRuleDetails();
			
			for (int j = 0; j < participationGroupDetails.size(); j++) 
			{
				IncentivePackageRuleDetail detail = participationGroupDetails.get(j);
				detail.setIncentivePackageRuleGroupID(pIncentivePackageRuleGroup.getIncentivePackageRuleGroupID());
				detail.setIncentivePackageRuleRequirementID(i);
				detail.setIncentivePackageRuleDetailID(j);
				insertIncentivePackageRuleDetail(detail, pModifyUserID);
			}
		}

		return rowInserted;
	}

	private int insertIncentivePackageRuleRequirement(IncentivePackageRuleRequirement requirement, String pModifyUserID)
			throws BPMException, DataAccessException {
		int rowInserted = 0;
		JdbcTemplate template = getJdbcTemplate();

		Object params[] = new Object[] { requirement.getIncentivePackageRuleGroupID(), requirement.getIncentivePackageRuleRequirementID(),
				pModifyUserID, pModifyUserID };

		int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.VARCHAR, Types.VARCHAR };

		rowInserted = template.update(insertIncentivePackageRuleRequirement, params, types);

		return rowInserted;
	}

	/**
	 *
	 * @param pModifyUserID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int insertIncentivePackageRuleDetail(IncentivePackageRuleDetail detail, String pModifyUserID)
			throws BPMException, DataAccessException {
		int rowInserted = 0;
		JdbcTemplate template = getJdbcTemplate();

		Object params[] = new Object[] { detail.getIncentivePackageRuleDetailID(), detail.getIncentivePackageRuleRequirementID(),
				detail.getIncentivePackageRuleGroupID(), detail.getIncentivePackageRuleCodeID(), detail.getSourceCode(), detail.getLogicOperatorCodeID(),
				pModifyUserID, pModifyUserID };

		int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.VARCHAR, Types.INTEGER,  
				Types.VARCHAR, Types.VARCHAR };

		rowInserted = template.update(insertIncentivePackageRuleDetail, params, types);

		return rowInserted;
	}

	/**
	 *
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */

	private int deleteIncentivePackageRuleRequirements(Integer pIncentivePackageRuleGroupD) throws BPMException,
	DataAccessException 
	{
		JdbcTemplate template = getJdbcTemplate();
		int rowInserted = 0;

		Object params[] = new Object[] { pIncentivePackageRuleGroupD };

		int types[] = new int[] { Types.INTEGER };

		// be sure to delete related details first
		deleteIncentivePackageRuleGroupDetails(pIncentivePackageRuleGroupD);
		rowInserted = template.update(deleteIncentivePackageRuleRequirements, params, types);

		return rowInserted;
	}

	private int deleteIncentivePackageRuleGroupDetails(Integer pIncentivePackageRuleGroupD) 
	throws BPMException, DataAccessException 
	{
		JdbcTemplate template = getJdbcTemplate();
		int rowInserted = 0;

		Object params[] = new Object[] { pIncentivePackageRuleGroupD };

		int types[] = new int[] { Types.INTEGER };

		rowInserted = template.update(deleteIncentivePackageRuleDetails, params, types);

		return rowInserted;
	}

	public String getSelectIncentivePackageRuleGroups() {
		return selectIncentivePackageRuleGroups;
	}

	public void setSelectIncentivePackageRuleGroups(
			String selectIncentivePackageRuleGroups) {
		this.selectIncentivePackageRuleGroups = selectIncentivePackageRuleGroups;
	}

	public String getInsertIncentivePackageRuleGroup() {
		return insertIncentivePackageRuleGroup;
	}

	public void setInsertIncentivePackageRuleGroup(
			String insertIncentivePackageRuleGroup) {
		this.insertIncentivePackageRuleGroup = insertIncentivePackageRuleGroup;
	}

	public String getDeleteIncentivePackageRuleGroup() {
		return deleteIncentivePackageRuleGroup;
	}

	public void setDeleteIncentivePackageRuleGroup(
			String deleteIncentivePackageRuleGroup) {
		this.deleteIncentivePackageRuleGroup = deleteIncentivePackageRuleGroup;
	}

	public String getUpdateIncentivePackageRuleGroup() {
		return updateIncentivePackageRuleGroup;
	}

	public void setUpdateIncentivePackageRuleGroup(
			String updateIncentivePackageRuleGroup) {
		this.updateIncentivePackageRuleGroup = updateIncentivePackageRuleGroup;
	}


	public String getSelectIncentivePackageRuleRequirement() {
		return selectIncentivePackageRuleRequirement;
	}

	public void setSelectIncentivePackageRuleRequirement(
			String selectIncentivePackageRuleRequirement) {
		this.selectIncentivePackageRuleRequirement = selectIncentivePackageRuleRequirement;
	}

	public String getSelectIncentivePackageRuleDetail() {
		return selectIncentivePackageRuleDetail;
	}

	public void setSelectIncentivePackageRuleDetail(
			String selectIncentivePackageRuleDetail) {
		this.selectIncentivePackageRuleDetail = selectIncentivePackageRuleDetail;
	}

	public String getInsertIncentivePackageRuleRequirement() {
		return insertIncentivePackageRuleRequirement;
	}

	public void setInsertIncentivePackageRuleRequirement(
			String insertIncentivePackageRuleRequirement) {
		this.insertIncentivePackageRuleRequirement = insertIncentivePackageRuleRequirement;
	}

	public String getInsertIncentivePackageRuleDetail() {
		return insertIncentivePackageRuleDetail;
	}

	public void setInsertIncentivePackageRuleDetail(
			String insertIncentivePackageRuleDetail) {
		this.insertIncentivePackageRuleDetail = insertIncentivePackageRuleDetail;
	}

	public String getDeleteIncentivePackageRuleRequirements() {
		return deleteIncentivePackageRuleRequirements;
	}

	public void setDeleteIncentivePackageRuleRequirements(
			String deleteIncentivePackageRuleRequirements) {
		this.deleteIncentivePackageRuleRequirements = deleteIncentivePackageRuleRequirements;
	}

	public String getDeleteIncentivePackageRuleDetails() {
		return deleteIncentivePackageRuleDetails;
	}

	public void setDeleteIncentivePackageRuleDetails(
			String deleteIncentivePackageRuleDetails) {
		this.deleteIncentivePackageRuleDetails = deleteIncentivePackageRuleDetails;
	}

	public String getUpdateIncentivePackageRuleDetail() {
		return updateIncentivePackageRuleDetail;
	}

	public void setUpdateIncentivePackageRuleDetail(
			String updateIncentivePackageRuleDetail) {
		this.updateIncentivePackageRuleDetail = updateIncentivePackageRuleDetail;
	}

	
	
	
	
}

package com.healthpartners.service.imfs.dto;


public class TrailerHSA
{	
	static final long serialVersionUID = 0L;

    public TrailerHSA()
    {
    	super();
    }

    private String recordType;    
    private String totalRecords;

	public String getRecordType() {
		return recordType;
	}
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}
	public String getTotalRecords() {
		return totalRecords;
	}
	public void setTotalRecords(String totalRecords) {
		this.totalRecords = totalRecords;
	}
	
    
}

package com.healthpartners.service.imfs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;

import com.healthpartners.service.imfs.dto.RewardControlProgramProcessTracker;
import com.healthpartners.service.imfs.exception.BPMException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.dto.RewardControlProgram;
import com.healthpartners.service.imfs.dto.RewardControlProgramProcessTracker;
import com.healthpartners.service.imfs.exception.BPMException;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;


/**
 * 
 * @author tjquist
 *
 */
@Configuration
public class RewardControlProgramDAOJdbc extends JdbcDaoSupport implements RewardControlProgramDAO 
{
	private String selectRewardControlPrograms;
	private String insertRewardControlProgramProcessTracker;
	private String selectRewardControlProgramProcessTracker;

	@Autowired
	DataSource bpmDataSource;


	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}
	
	/**
	 * 
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<RewardControlProgram> getRewardControlPrograms(String quoteID)
	{
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {quoteID };
		int types[] = new int[] {Types.VARCHAR};
		final ArrayList<RewardControlProgram> lRewardControlPrograms = new ArrayList<RewardControlProgram>();
		
		template.query(selectRewardControlPrograms, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						RewardControlProgram lRewardControlProgram = new RewardControlProgram();
						
						lRewardControlProgram.setControlProgramID(rs.getInt("REWARD_CNTRL_PGM_ID"));
						lRewardControlProgram.setProgramID(rs.getInt("BIZ_PGM_ID"));
						lRewardControlProgram.setRunFrequency(rs.getString("RUN_FREQ_TP"));
						lRewardControlProgram.setQuoteNo(rs.getString("QUOTE_NO"));
						lRewardControlProgram.setGroupNo(rs.getString("empl_grp_no"));
						lRewardControlProgram.setSiteNo(rs.getString("empl_grp_site_id_no"));
						lRewardControlProgram.setGroupName(rs.getString("empl_grp_nm"));
						lRewardControlProgram.setSiteName(rs.getString("empl_grp_site_nm"));
						lRewardControlProgram.setIncentiveOptionID(rs.getInt("incntv_optn_id"));
						lRewardControlProgram.setProgramIncentiveOptionEffectiveDate(rs.getDate("incntv_optn_eff_dt"));
						lRewardControlProgram.setProgramIncentiveOptionEndDate(rs.getDate("incntv_optn_end_dt"));
						
						lRewardControlPrograms.add(lRewardControlProgram);
					}
		});
		
		return lRewardControlPrograms;
	}
	
	/**
	 * 
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public RewardControlProgramProcessTracker getRewardControlProgramProcessTracker(Integer controlProgramID)
	{
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {controlProgramID, controlProgramID };
		int types[] = new int[] {Types.INTEGER, Types.INTEGER };
		final ArrayList<RewardControlProgramProcessTracker> lRewardControlProgramProcessTrackers = new ArrayList<RewardControlProgramProcessTracker>();
		
		template.query(selectRewardControlProgramProcessTracker, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						RewardControlProgramProcessTracker lRewardControlProgramProcessTracker = new RewardControlProgramProcessTracker();
						
						lRewardControlProgramProcessTracker.setControlProgramID(rs.getInt("reward_cntrl_pgm_id"));
						lRewardControlProgramProcessTracker.setDateLastProcessed(rs.getDate("dt_last_processed"));
						lRewardControlProgramProcessTracker.setProcessStatus(rs.getString("process_status"));
						lRewardControlProgramProcessTracker.setProcessStatusID(rs.getInt("prcs_status_tp_id"));
						lRewardControlProgramProcessTracker.setRecordsSent(rs.getInt("records_sent"));
						
						lRewardControlProgramProcessTrackers.add(lRewardControlProgramProcessTracker);
					}
		});
		
		RewardControlProgramProcessTracker dto = null;
		if (lRewardControlProgramProcessTrackers.size() > 0) {
			dto = (RewardControlProgramProcessTracker) lRewardControlProgramProcessTrackers.get(0);
		}
		return dto;
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public int insertRewardControlProgramProcessTracker(Integer controlProgramID, String processStatus, Integer recordsSent)
	throws DataAccessException {
		
	
		JdbcTemplate template = getJdbcTemplate();
		
	
		Object params[] = new Object[] { controlProgramID, processStatus, recordsSent };
		int types[] = new int[] { Types.INTEGER, Types.VARCHAR, Types.INTEGER};
	
		int rowInserted = template.update(insertRewardControlProgramProcessTracker, params,
				types);
	
		
		return rowInserted;
	}

	public void setSelectRewardControlPrograms(String selectRewardControlPrograms) {
		this.selectRewardControlPrograms = selectRewardControlPrograms;
	}

	public void setSelectRewardControlProgramProcessTracker(
			String selectRewardControlProgramProcessTracker) {
		this.selectRewardControlProgramProcessTracker = selectRewardControlProgramProcessTracker;
	}

	public String getInsertRewardControlProgramProcessTracker() {
		return insertRewardControlProgramProcessTracker;
	}

	public void setInsertRewardControlProgramProcessTracker(
			String insertRewardControlProgramProcessTracker) {
		this.insertRewardControlProgramProcessTracker = insertRewardControlProgramProcessTracker;
	}

	public String getSelectRewardControlPrograms() {
		return selectRewardControlPrograms;
	}

	public String getSelectRewardControlProgramProcessTracker() {
		return selectRewardControlProgramProcessTracker;
	}

	
	
}

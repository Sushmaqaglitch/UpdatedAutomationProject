package com.healthpartners.service.imfs.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author jxbourbour
 * 
 */
public class ParticipationGroupRequirement implements Serializable {
	static final long serialVersionUID = 0L;

	private Integer participationGroupID;
	private Integer participationGroupRequirementID;

	private List<ParticipationGroupDetail> participationGroupDetails = new ArrayList<ParticipationGroupDetail>();

	public ParticipationGroupRequirement() {
		super();
	}

	public final Integer getParticipationGroupID() {
		return participationGroupID;
	}

	public final void setParticipationGroupID(Integer participationGroupID) {
		this.participationGroupID = participationGroupID;
	}

	public final Integer getParticipationGroupRequirementID() {
		return participationGroupRequirementID;
	}

	public final void setParticipationGroupRequirementID(Integer participationGroupRequirementID) {
		this.participationGroupRequirementID = participationGroupRequirementID;
	}

	public final List<ParticipationGroupDetail> getParticipationGroupDetails() {
		return participationGroupDetails;
	}

	public final void setParticipationGroupDetails(List<ParticipationGroupDetail> participationGroupDetails) {
		this.participationGroupDetails = participationGroupDetails;
	}

	public ParticipationGroupDetail getParticipationGroupDetail(int index) {
		return getParticipationGroupDetails().get(index);
	}

	public boolean isPersistent() {
		return participationGroupRequirementID != null && participationGroupRequirementID > 0;
	}
}

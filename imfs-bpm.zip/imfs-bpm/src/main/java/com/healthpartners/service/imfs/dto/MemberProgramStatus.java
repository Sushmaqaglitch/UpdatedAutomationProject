package com.healthpartners.service.imfs.dto;

import java.io.Serializable;

/**
 * This is the structure returned in the getMemberStatus web service response.
 * 
 * @author jxbourbour
 *
 */
public class MemberProgramStatus implements Serializable
{	
	static final long serialVersionUID = 0L;
	
    private BusinessProgram businessProgram;
    private Member[] members;
    
    public MemberProgramStatus()
    {
    	super();
    }	

	public BusinessProgram getBusinessProgram() {
		return businessProgram;
	}

	public void setBusinessProgram(BusinessProgram businessProgram) {
		this.businessProgram = businessProgram;
	}	

	public void setMembers(Member[] members) {
		this.members = members;
	}

	public Member[] getMembers() {
		return members;
	}	
}

package com.healthpartners.service.imfs.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;

import com.healthpartners.service.imfs.dto.*;
import org.springframework.dao.DataAccessException;


public interface ActivityDAO {
	public Collection<MemberActivity> getMemberActivities(Integer personId,
			Integer programID, boolean pExcludeInactives);
	
	public Collection<EligibleActivity> getEligibleActivities(Integer programID);
	
	public boolean isPersonProgramActivityHistoryComplete(Integer activityID,
			Integer personId, Integer programID, String registrationID);


	public Collection<MemberActivity> getRecommendedActivities(Integer pPersonID, Integer pProgramID);

	/**
	 * inserts Member Activity - DB table PERSON_PROGRAM_ACTIVITY_STATUS
	 * 
	 * @param activityEvent
	 * @return int rows inserted
	 * @throws DataAccessException
	 */
	public int insertMemberActivity(ActivityEvent activityEvent)
			throws DataAccessException;

	public int insertMemberActivity(Integer pProgramID, String pMemberID,
			MemberActivity pMemberActivity) throws DataAccessException;

	/**
	 * updates Member Activity - DB table PERSON_PROGRAM_ACTIVITY_STATUS
	 * 
	 * @param activityEvent
	 * @return number rows updated
	 * @throws DataAccessException
	 */
	public int updateMemberActivity(ActivityEvent activityEvent)
			throws DataAccessException;

	public Collection<EligibleProgramActivity> getBusinessProgramsForActivity(
			String pSourceActivityID, String pMemberID, String pAuthCode,
			Calendar pActivityDate);

	public int deleteMemberActivities(Integer personID, Integer programID)
			throws DataAccessException;

	public Collection<Integer> getNewBusinessPrograms(Integer pPersonID)
			throws DataAccessException;

	public EligibleProgramActivity getEligibleProgramActivity(
			String pSourceActivityID, String pMemberID, String pAuthCode,
			Calendar pActivityDate, Integer pProgramID)
			throws DataAccessException;

	public Collection<ActivityEvent> getCurrentYearActivitiesForTransfer(
			Integer personID) throws DataAccessException;
	
	public Collection<ActivityEvent> getPreviousYearDMActivitiesForTransfer(
			Integer personID) throws DataAccessException;
	
	public Collection<MemberActivity> 
	getFilteredOutActivities(Integer personId, Integer programID, boolean pCalledFromWebPortal);

	public Integer getMinimumOnlineDuration()
	throws DataAccessException;
	
	public Integer getMinimumDMDuration()
	throws DataAccessException;
	
	public Integer getMinimumPhoneDuration()
	throws DataAccessException;
	
	public Collection<MemberActivity> 
	getExistingActivity(String pMemberID, String pSourceActivityID, java.sql.Date pActivityDate, 
			String pAuthCode, String pRegistrationID, String pActivityStatus)
	throws DataAccessException;	
	
	public int deleteMemberActivity(ActivityEvent activityEvent)
	throws DataAccessException;
	
	public Collection<MemberActivity> 
	getExistingWaive(String pMemberID, String pSourceActivityID, java.sql.Date pActivityDate);
	
	public Collection<ActivityDefinition> selectActivities()
	throws DataAccessException;
	
	public void insertEligibleActivity(EligibleProgramActivity pEligibleActivity, String lUserID)
	throws DataAccessException;
	
	public Collection<EligibleProgramActivity> getEligibleProgramActivities(Integer pProgramID)
	throws DataAccessException;
	
	public Collection<AuthCode> selectExtendedAuthCodes(final Integer pProgramID)
	throws DataAccessException;
	
	public Collection<AuthCode> selectEligibleAuthCodes(final Integer pProgramID)
	throws DataAccessException;
	
	public void setActivitiesToPending(Integer pPersonDemographicsID, Integer pProgramID)
	throws DataAccessException;
	
	public ActivityDefinition getActivity(int activityId);
	
	public PersonProgramActivityStatus getPersonProgramActivityStatus(String memberID, Integer programID, String sourceActivityId, java.sql.Date effectiveStatusDate);
	
	public Activity getActivityFromExternalActivity(String groupNo, String externalActivityName) throws Exception, DataAccessException;
	
	public Collection<Activity> getEmployerAdminsterdActivities()
			throws DataAccessException;
	
	public Collection<ActivityExternalEmployerXref> getExternalEmployerActivityXrefAll()
			throws DataAccessException;
	
	public Collection<MemberActivity> getMemberActivitiesOutsideEnrollment(Integer personId,
			Integer programID);
	
	public Collection<MemberActivity> getRecommendedActivitiesOutsideEnrollment(Integer pPersonID, Integer pProgramID);

	public Collection<MemberActivity> 
		getFilteredOutActivitiesOutsideEnrollment(Integer personId, Integer programID, boolean pCalledFromWebPortal);

				
	public Collection<MemberActivity> 
		getExistingActivityOutsideEnrollment(String pMemberID, String pSourceActivityID, java.sql.Date pActivityDate, 
				String pAuthCode,
				String pRegistrationID, 
				String pActivityStatus);
				
	public Collection<MemberActivity> 
		getExistingWaiveOutsideEnrollment(String pMemberID, String pSourceActivityID, java.sql.Date pActivityDate);
	
}

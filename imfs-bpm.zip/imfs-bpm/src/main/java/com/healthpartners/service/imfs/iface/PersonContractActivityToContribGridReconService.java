/**
 * 
 */
package com.healthpartners.service.imfs.iface;


import com.healthpartners.service.imfs.exception.BPMException;
import com.healthpartners.service.imfs.rules.StatusCalculationCommand;


/**
 * Provides a common interface for reconciliation of person contract activity to contribut grid table.
 * 
 * @author tjquist
 */
public interface PersonContractActivityToContribGridReconService 
{
	
	public void processPersonContractActivityToContribGridReconCommand(StatusCalculationCommand statusCalculationCommand) throws BPMException;
	
	
}

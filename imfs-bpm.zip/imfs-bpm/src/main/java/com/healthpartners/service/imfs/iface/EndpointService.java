/**
 * 
 */
package com.healthpartners.service.imfs.iface;

import java.util.ArrayList;


/**
 * Provides a common interface to starting embedded batch services.
 * 
 * @author tjquist
 */
public interface EndpointService
{

	public String startBatchProcess(String userID, String processName, Integer daySpan, String sourceSystemID, String groupNo, String hostServer) throws Exception;

}

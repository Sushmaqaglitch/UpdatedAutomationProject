package com.healthpartners.service.imfs.dto;

import java.sql.Date;
import java.util.Collection;

/**
 * @author tjquist
 * 
 */
public class ContractProgramStatusTO extends BaseDTO {

	static final long serialVersionUID = 0L;

	private Integer programID;
	private Integer programIncentiveOptionID;
	private Integer contractNo;
	private Date qualificationStartDate;
	private String contractStatus;
	private Date contractStatusDate;
	private Date participationEndDate;
	
	

	/**
	 * 
	 */
	public ContractProgramStatusTO() {
		super();
	}



	public Integer getProgramID() {
		return programID;
	}



	public void setProgramID(Integer programID) {
		this.programID = programID;
	}



	public Integer getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}



	public void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}

	

	public Integer getContractNo() {
		return contractNo;
	}



	public void setContractNo(Integer contractNo) {
		this.contractNo = contractNo;
	}



	public Date getQualificationStartDate() {
		return qualificationStartDate;
	}



	public void setQualificationStartDate(Date qualificationStartDate) {
		this.qualificationStartDate = qualificationStartDate;
	}



	public String getContractStatus() {
		return contractStatus;
	}



	public void setContractStatus(String contractStatus) {
		this.contractStatus = contractStatus;
	}



	public Date getContractStatusDate() {
		return contractStatusDate;
	}



	public void setContractStatusDate(Date contractStatusDate) {
		this.contractStatusDate = contractStatusDate;
	}



	public Date getParticipationEndDate() {
		return participationEndDate;
	}



	public void setParticipationEndDate(Date participationEndDate) {
		this.participationEndDate = participationEndDate;
	}

	
	
}

/* $Id: ContributionGridDAOJdbc.java 207938 2013-06-07 17:49:24Z tjquist $ */

package com.healthpartners.service.imfs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.healthpartners.service.imfs.dto.ContributionGridBenefitContractTypeRelationship;
import com.healthpartners.service.imfs.dto.NamedParameter;
import com.healthpartners.service.imfs.dto.ProgramContributionGrid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.exception.BPMException;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;


@Configuration
public class ContributionGridDAOJdbc extends JdbcDaoSupport implements
		ContributionGridDAO {
	
	private String selectProgramContributionGrids;
	private String selectContributionGridBenefitContractTypeRelationships;


	public ContributionGridDAOJdbc() {
		super();
	}

	@Autowired
	DataSource bpmDataSource;

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}

	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { BPMException.class})
	public List<ProgramContributionGrid> getProgramContributionGrids(Integer programIncentiveOptionID)
			throws DataAccessException {

		Object params[] = new Object[] {programIncentiveOptionID};
		int types[] = new int[] {Types.INTEGER};
		NamedParameter namedParameter = new NamedParameter();
		namedParameter.setIncentiveId(programIncentiveOptionID);

		final SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(namedParameter);
		List<ProgramContributionGrid> results = namedParameterJdbcTemplate.query(selectProgramContributionGrids, namedParameters,
				new RowMapper() {
					Integer rowIDCtr = 1;

					@Override
					public ProgramContributionGrid mapRow(ResultSet rs, int i) throws SQLException {
						ProgramContributionGrid lProgramContributionGrid = new ProgramContributionGrid();

						lProgramContributionGrid.setContributionGridID(rs.getInt("contrib_grid_id"));
						lProgramContributionGrid.setProgramIncentiveOptionID(rs.getInt("biz_pgm_incntv_optn_id"));
						lProgramContributionGrid.setBenefitContractTypeID(rs.getInt("ben_contr_tp_lu_id"));
						lProgramContributionGrid.setBenefitContractTypeVal(rs.getString("ben_con_typ_val"));
						lProgramContributionGrid.setBenefitContractTypeDesc(rs.getString("ben_con_typ_desc"));
						lProgramContributionGrid.setRelationshipCodeID(rs.getInt("rel_cd"));
						lProgramContributionGrid.setRelationshipCode(rs.getString("rel_desc"));
						lProgramContributionGrid.setContributionAmount(rs.getInt("contrib_amt"));
						lProgramContributionGrid.setRowID(rowIDCtr++);

						return lProgramContributionGrid;
					}

				});

		

		return results;
	}
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(transactionManager = "DataSourceTransactionManager", timeout = 60, rollbackFor = { DataAccessException.class})
	public Collection<ContributionGridBenefitContractTypeRelationship> getContributionGridBenefitContractTypeRelationships(Integer benefitContractTypeID)
			throws DataAccessException {
		final ArrayList<ContributionGridBenefitContractTypeRelationship> lContributionGridBenefitContractTypeRelationships = new ArrayList<ContributionGridBenefitContractTypeRelationship>();
	

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {benefitContractTypeID};
		int types[] = new int[] {Types.INTEGER};
		template.query(selectContributionGridBenefitContractTypeRelationships, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						ContributionGridBenefitContractTypeRelationship lContributionGridBenefitContractTypeRelationship = new ContributionGridBenefitContractTypeRelationship();
						

						lContributionGridBenefitContractTypeRelationship.setUid(rs.getInt("ben_con_type_rel_id"));
						lContributionGridBenefitContractTypeRelationship.setBenefitContractTypeID(rs.getInt("ben_con_type_id"));
						lContributionGridBenefitContractTypeRelationship.setRelationshipCode(rs.getInt("rlshp_cd"));
						lContributionGridBenefitContractTypeRelationship.setRelationshipDesc(rs.getString("rlshp_txt"));
						lContributionGridBenefitContractTypeRelationship.setEffectiveDate(rs.getDate("eff_dt"));
						lContributionGridBenefitContractTypeRelationship.setEndDate(rs.getDate("end_dt"));
						
						
						lContributionGridBenefitContractTypeRelationships.add(lContributionGridBenefitContractTypeRelationship);
					}
				});
		
		

		return lContributionGridBenefitContractTypeRelationships;
	}


	public void setSelectProgramContributionGrids(
			String selectProgramContributionGrids) {
		this.selectProgramContributionGrids = selectProgramContributionGrids;
	}


	public void setSelectContributionGridBenefitContractTypeRelationships(
			String selectContributionGridBenefitContractTypeRelationships) {
		this.selectContributionGridBenefitContractTypeRelationships = selectContributionGridBenefitContractTypeRelationships;
	}
	
	
	
	

}

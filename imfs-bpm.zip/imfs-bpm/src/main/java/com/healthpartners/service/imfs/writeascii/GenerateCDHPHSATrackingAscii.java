

package com.healthpartners.service.imfs.writeascii;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Calendar;
import java.util.Collection;
import java.util.StringTokenizer;

import com.healthpartners.service.imfs.dto.DetailHSA;
import com.healthpartners.service.imfs.dto.HeaderHSA;
import com.healthpartners.service.imfs.dto.TrailerHSA;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.healthpartners.service.imfs.common.BPMConstants;
import com.healthpartners.service.imfs.common.BPMUtils;
import com.healthpartners.service.imfs.dto.DetailHSA;
import com.healthpartners.service.imfs.dto.HeaderHSA;
import com.healthpartners.service.imfs.dto.TrailerHSA;
 
public class GenerateCDHPHSATrackingAscii
{

	protected final Log logger = LogFactory.getLog(getClass());
   
   private FileWriter writer = null;
   
   private int recsWritten = 0;
 
   public void GenerateCDHPHSATrackingAscii() {
	   
   }
   
   public int generateAsciiFile(HeaderHSA lHeaderHSA, Collection<DetailHSA> lDetailHSAs, TrailerHSA lTrailerHSA, String fileLayoutType) throws Exception {
	   
	   
	    CDHPHSAFileFormats lHSAFileFormats = new CDHPHSAFileFormats();
	    lHSAFileFormats.setHeaderHSA(lHeaderHSA);
	    lHSAFileFormats.setDetailHSAs(lDetailHSAs);
	    lHSAFileFormats.setTrailerHSA(lTrailerHSA);
	    
	    if (writer != null) {
	    	logger.info("GenerateCDHPHSATrackingAscii.generateAsciiFile: FileWriter instantiated indicating directory permissions are working.");
	    	lHSAFileFormats.setFileWriter(writer);
	    } else {
	    	String errorMessage = "GenerateCDHPHSATrackingAscii.generateAsciiFile: FileWriter is null indicating directory permissions are not working.";
	    	logger.error(errorMessage);
	    	throw new Exception(errorMessage);
	    }
	    
	  
	   	if (fileLayoutType.equals(BPMConstants.CDHP_HSA_FILE_LAYOUT_TP_A)) {
	   		lHSAFileFormats.processFileFormatA();
	   		setRecsWritten(lHSAFileFormats.getRecsWritten());
	   	} else {
	   		throw new Exception("File layout does not match file format registered to control group.  File format is " + fileLayoutType);
	   	}
		
	   	return recsWritten;
		
	}
   
 public void openFileWriter(String preprocessOutputFilePath, String processedOutputFilePath, String outputFilePathNFileName) {
	
	 Calendar calDate = Calendar.getInstance();

     String calDateStr = BPMUtils.formatDateMMddyyyy(calDate);
     StringTokenizer strDate = new StringTokenizer(calDateStr, "/");
     String month = strDate.nextToken();
     String day = strDate.nextToken();
     String year = strDate.nextToken();
     
     File topLevelDirPreProcessFile = new File(preprocessOutputFilePath);
     if((topLevelDirPreProcessFile.mkdirs())) {
         logger.info("Created preprocess directory: " + topLevelDirPreProcessFile.getPath());
     }
     
     File topLevelDirProcessedFile = new File(processedOutputFilePath);
     if((topLevelDirProcessedFile.mkdirs())) {
         logger.info("Created processed directory: " + topLevelDirProcessedFile.getPath());
     }
     
     String outputFileName =  outputFilePathNFileName + year + month + day + calDate.get(Calendar.HOUR_OF_DAY) + calDate.get(Calendar.MINUTE) + calDate.get(Calendar.SECOND) + ".csv";
     logger.info("GenerateHSAFileAscii: Output File name is " + outputFileName);
     
     try{
    	 writer = new FileWriter(outputFileName); 
    	 
	 } catch(IOException e)
		{
		     e.printStackTrace();
		} 
     
 	}

	public void closeFileWriter() {
		try {
		 writer.flush();
		 writer.close();
		} catch(IOException e)
		{
		     e.printStackTrace();
		} 
	}

	public int getRecsWritten() {
		return recsWritten;
	}

	public void setRecsWritten(int recsWritten) {
		this.recsWritten = recsWritten;
	}
	  
  
}
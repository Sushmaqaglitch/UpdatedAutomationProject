package com.healthpartners.service.imfs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;

import com.healthpartners.service.imfs.dto.GroupBaseline;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthpartners.service.imfs.dto.GroupBaseline;
import com.healthpartners.service.imfs.exception.BPMException;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;

/**
 * 
 * @author jxbourbour
 *
 */
@Configuration
public class GroupBaselineDAOJdbc extends JdbcDaoSupport implements GroupBaselineDAO
{
	private String selectFromGroupBaseline;
	private String purgeGroupBaselineHistByDate;
	private String selectGroupBaselineHistCount;

	@Autowired
	DataSource bpmDataSource;


	@PostConstruct
	private void initialize() {

		setDataSource(bpmDataSource);
	}
	
	/**
	 * Retrieve rows from the bpm_empl_grp_baseline table, that are not already in the 
	 * business program table.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Collection<GroupBaseline> selectFromGroupBaseline(Integer batchCount)
	throws DataAccessException
	{
		final ArrayList<GroupBaseline> lGroupBaselines = new ArrayList<GroupBaseline>();

		JdbcTemplate template = getJdbcTemplate();				
		Object params[] = new Object[] {batchCount };	
		int types[] = new int[] {Types.INTEGER };

		template.query(selectFromGroupBaseline, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						GroupBaseline lGroupBaseline = new GroupBaseline();
			
						lGroupBaseline.setGroupID(rs.getInt("grp_id"));
						lGroupBaseline.setSubGroupID(rs.getInt("subgrp_id"));
						lGroupBaseline.setEffectiveDate(rs.getDate("eff_dt"));
						lGroupBaseline.setProgramTypeCode(rs.getString("business_pgm_tp_cd"));
						lGroupBaselines.add(lGroupBaseline);					
				}
		});
		return lGroupBaselines;
	}

	/**
	 * Date used comes from LUV table
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Integer purgeGroupBaselineHistByDate(java.sql.Date purgeDate)
			throws DataAccessException {


		// Persist the audit log entry.
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {
				purgeDate // comes from LUV table
		};
		int types[] = new int[] {
				Types.TIMESTAMP};
		int deleteCount = template.update(purgeGroupBaselineHistByDate, params, types);

		return deleteCount;
	}


	//Produces warnings during compile time to quickly identify typos or API changes
	@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
	public Integer getGroupBaselineHistCount() throws DataAccessException {
		final ArrayList<Integer> results = new ArrayList<Integer>();
		JdbcTemplate template = getJdbcTemplate();
		template.query(selectGroupBaselineHistCount,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						results.add(new Integer(rs.getInt(1)));
					}
				});

		Integer numberOfEmplGroupBaselineHistRecords = 0;
		if (results.size() > 0) {
			numberOfEmplGroupBaselineHistRecords = results.get(0).intValue();
		}

		return numberOfEmplGroupBaselineHistRecords;

	}

	public String getSelectFromGroupBaseline() {
		return selectFromGroupBaseline;
	}

	public void setSelectFromGroupBaseline(String selectFromGroupBaseline) {
		this.selectFromGroupBaseline = selectFromGroupBaseline;
	}

	public String getPurgeGroupBaselineHistByDate() {
		return purgeGroupBaselineHistByDate;
	}

	public void setPurgeGroupBaselineHistByDate(String purgeGroupBaselineHistByDate) {
		this.purgeGroupBaselineHistByDate = purgeGroupBaselineHistByDate;
	}

	public String getSelectGroupBaselineHistCount() {
		return selectGroupBaselineHistCount;
	}

	public void setSelectGroupBaselineHistCount(String selectGroupBaselineHistCount) {
		this.selectGroupBaselineHistCount = selectGroupBaselineHistCount;
	}
}

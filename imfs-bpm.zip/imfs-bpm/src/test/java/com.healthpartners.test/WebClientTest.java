package com.healthpartners.test;

import com.healthpartners.service.imfs.iface.EndpointService;
import com.healthpartners.service.imfs.impl.EndpointServiceImpl;


public class WebClientTest {

    public static final String TASK_EVENT = "TASK_EVENT";

    public static final String PENDING_ACTIVITY_EVENTS = "PENDING_ACTIVITY_EVENTS";

    public static final String FILTERED_ACTIVITY_EVENTS = "FILTERED_ACTIVITY_EVENTS";

    public static final String PENDING_TASK_EVENTS = "PENDING_TASK_EVENTS";

    public static final String ETL_MEMBERSHIP_UPDATE = "ETL_MEMBERSHIP_UPDATE";
    public static final String TOPIC_ETL_MEMBERSHIP_UPDATE = "TOPIC_ETL_MEMBERSHIP_UPDATE";
    public static final String ETL_MEMBERSHIP_UPDATE_ONLY = "ETL_MEMBERSHIP_ONLY";

    public static final String MEMBER_ELAPSED_TIME = "MEMBER_ELAPSED_TIME";

    public static final String PURGE_AUDIT_LOG_TABLE = "PURGE_AUDITLOG_TABLE";

    public static final String PURGE_PROCESSLG_TABLE = "PURGE_PROCSTATLOG_TABLE";

    public static final String PURGE_GROUPBASELINEHIST_TABLE = "PURGE_GROUPBASELINEHIST_TABLE";


    public static final String ARCHIVE_PERSONCONTRACTHIST_TABLE = "ARCHIVE_PERSONCONTRACTHIST_TABLE";

    public static final String MEMBERCONTRACTRECYCLE_ACTIONNEEDED_RPT = "MEMBERCONTRACTRECYCLE_ACTIONNEEDED_RPT";


    public static final String PARAM_BATCH_SIZE = "PARAM_BATCH_SIZE";

    public static final String ONE_PERSON = "ONE_PERSON";

    public static final String MEMBERS_RECALCULATION = "MEMBERS_RECALCULATION";

    public static final String MEMBERSHIP_FEED = "MEMBERSHIP_FEED";

    public static final String MEMBERSHIP_PREMIUM_BILLING_FEED = "MEMBERSHIP_PREMIUM_BILLING_FEED";

    public static final String AUTO_PROGRAM_SETUP = "AUTO_PROGRAM_SETUP";
    public static final String AUTO_PROGRAM_NEW_SETUP = "AUTO_PROGRAM_NEW_SMARTSTEPS";

    public static final String EMPLOYER_GROUP_SITE_SETUP = "EMPLOYER_GROUP_SITE_SETUP";
    public static final String EMPLOYER_BASELINE_SETUP = "EMPLOYER_BASELINE_SETUP";
    public static final String POPULATE_MISSING_PEOPLE = "POPULATE_MISSING_PEOPLE";
    public static final String POPULATE_MISSING_ACTIVITIES = "POPULATE_MISSING_ACTIVITIES";
    public static final String RECALC_DUALCOVERED_PARTICIPANTS = "RECALC_DUALCOVERED_PARTICIPANTS";
    public static final String DELETE_TERMED_PARTICIPANTS = "DELETE_TERMED_PARTICIPANTS";
    public static final String DELETE_TERMED_PARTICIPANTS_BY_GRP = "DELETE_TERMED_BY_GRP";


    public static final String CONTRACT_RECONCILIATION = "CONTRACT_RECONCILIATION";


    public static final String EMPLOYER_FULFILLMENT_REPORTING = "EMPLOYER_FULFILLMENT";
    public static final String EMPLOYER_FULFILLMENT_REPORTING_RESEND = "EMPLOYER_FULFILLMENT_RESEND";

    public static final String CDHP_HRA_FULFILLMENT_REPORTING = "CDHP_HRA_FULFILLMENT";
    public static final String CDHP_HSA_FULFILLMENT_REPORTING = "CDHP_HSA_FULFILLMENT";

    public static final String REWARD_FULFILLMENT_SEND = "REWARD_FULFILLMENT";

    public static final String UPLOAD_EMPLOYER_ACTIVITY_PREPROCESS = "UPLOAD_EMPLOYER_ACTIVITY_PREPROCESS";
    public static final String UPLOAD_EMPLOYER_ACTIVITY_POSTPROCESS = "UPLOAD_EMPLOYER_ACTIVITY_POSTPROCESS";
    public static final String OPTUM_INCENTED_TO_FULFILL_RECON = "OPTUM_INCENTED_TO_FULFILL_RECON";


    public static final String REWARD_INTELISPEND_REPORTING = "INTELISPEND_REPORTS";

    public static final String POPULATE_PACKAGE_BASELINE = "POPULATE_PACKAGE_BASELINE";
    public static final String FILTERED_OUT_ACTIVITY_REPORT = "FILTERED_OUT_ACTIVITY_REPORT";

    public static final String AUTO_POPULATE_AUDIT_REPORT = "AUTO_POPULATE_AUDIT_REPORT";

    public static final String RESET_ACTIVITY_EVENT_TO_PENDING = "RESET_ACTIVITY_EVENT_TO_PENDING";

    public static final String REPROCESS_INCENTED_ACTIVITY_W_UNRESOLVED = "REPROCESS_INCENTED_ACTIVITY_W_UNRESOLVED";

    public static final String ACTIVITY_TO_CONTRIBGRID_RECON = "ACTIVITY_TO_CONTRIBGRID_RECON";

    public static final String EMPLOYER_ACTIVITY_END_TO_END_RECON = "EMPLOYER_ACTIVITY_END_TO_END_RECON";

    public static final String CORRECT_PURCHASER_SUBTYPE = "CORRECT_PURCHASER_SUBTYPE";

    public static final String ACTIVITY_CREATION_BASED_ON_PRECONDITION = "ACTIVITY_CREATION_BASED_ON_PRECONDITION";
    public static final String REWARD_FULFILLMENT = "REWARD_FULFILLMENT";

    //@Test
    public void startBatchProcessTest()
    {
        EndpointService endpointService = new EndpointServiceImpl();

        //String hostServer = "https://admin-imfs-bpm.apps.dev2-int.ocp.healthpartners.com/";

       //String hostServer = "https://admin-imfs-bpm.apps.uat3-int.ocp.healthpartners.com/";



        String hostServer = "http://localhost:8081";

        String userID = "tjquist";
    //    String processName = PENDING_ACTIVITY_EVENTS;
        String processName = FILTERED_ACTIVITY_EVENTS;

 //         String processName = TASK_EVENT;
//        String processName = PENDING_TASK_EVENTS;
//        String processName = TOPIC_ETL_MEMBERSHIP_UPDATE;
//          String processName = ETL_MEMBERSHIP_UPDATE;
    //    String processName = ETL_MEMBERSHIP_UPDATE_ONLY;
//          String processName = MEMBER_ELAPSED_TIME;
//        String processName = PURGE_AUDIT_LOG_TABLE;
//          String processName = PURGE_PROCESSLG_TABLE;
 //       String processName = PURGE_GROUPBASELINEHIST_TABLE;  -- no response.
 //Don't run long running process       String processName = ARCHIVE_PERSONCONTRACTHIST_TABLE;
 //No results       String processName = MEMBERCONTRACTRECYCLE_ACTIONNEEDED_RPT;
 //No results       String processName = MEMBERS_RECALCULATION;
 //       String processName = MEMBERSHIP_FEED;
    //This process failed!    String processName = RECALC_DUALCOVERED_PARTICIPANTS;
    //    String processName = PURGE_AUDIT_LOG_TABLE;
    //    String processName = ACTIVITY_TO_CONTRIBGRID_RECON;
        //--Do not run String processName = AUTO_POPULATE_AUDIT_REPORT;  -- System cannot find path.
        //String processName = DELETE_TERMED_PARTICIPANTS; --FileNotFoundException: .\BPM-Audit\EndedGroups\EndedGroups-20210503.csv
        //String processName = EMPLOYER_BASELINE_SETUP;
        //String processName = EMPLOYER_GROUP_SITE_SETUP;
        //String processName = POPULATE_MISSING_PEOPLE;
        //String processName = POPULATE_PACKAGE_BASELINE;
        //String processName = REWARD_INTELISPEND_REPORTING; Retired service which now runs as a microservice.


        String sourceSystemID = "";
        String groupNo = "";
        Integer daySpan = -365;

        String messageResponse = null;

        System.out.print("Batch process started for processName " + processName);
        try {
            messageResponse = endpointService.startBatchProcess(userID, processName, daySpan, sourceSystemID, groupNo, hostServer);
        } catch (Exception e) {
            System.out.print("Exception caught calling endpointService.startBatchProcess: " + e.getMessage());
        }
        System.out.print("Batch process finished for processName " + processName);

        System.out.print("Message response is " + messageResponse);
    }

}
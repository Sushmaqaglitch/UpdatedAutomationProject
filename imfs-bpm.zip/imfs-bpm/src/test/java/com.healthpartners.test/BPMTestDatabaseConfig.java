package com.healthpartners.test;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

public class BPMTestDatabaseConfig {

    @Bean(name = "bpmDataSource")
    public DataSource dataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("oracle.jdbc.driver.OracleDriver");
        dataSource.setUrl("jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=oradevrac.healthpartners.com)(PORT=1551))(CONNECT_DATA=(SERVICE_NAME=bpmtst.healthpartners.com)))");
        dataSource.setUsername("bpm");
        dataSource.setPassword("ch3moTh3rapy");

        return dataSource;
    }

}

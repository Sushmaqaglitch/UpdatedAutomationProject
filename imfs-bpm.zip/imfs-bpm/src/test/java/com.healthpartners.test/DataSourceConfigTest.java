package com.healthpartners.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import javax.sql.DataSource;

@Configuration

@EnableTransactionManagement
public class DataSourceConfigTest {

    public static void main(String[] args) {
        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(BPMTestDatabaseConfig.class);
        DataSource dataSource = (DataSource) context.getBean("bpmTestDataSource");

    }

}
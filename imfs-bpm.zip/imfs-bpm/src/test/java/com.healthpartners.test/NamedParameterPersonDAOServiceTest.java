//package com.healthpartners.test;
//
//import com.healthpartners.service.imfs.common.BPMConstants;
//import com.healthpartners.service.imfs.dao.ActivityDAOJdbc;
//import com.healthpartners.service.imfs.dto.*;
//import org.junit.Test;
//import static org.junit.jupiter.api.Assertions.*;
//
//
//import org.junit.runner.RunWith;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.SpringBootConfiguration;
//import org.springframework.boot.context.properties.EnableConfigurationProperties;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.web.servlet.ServletComponentScan;
//import org.springframework.context.ApplicationContext;
//
//import org.springframework.context.annotation.AnnotationConfigApplicationContext;
//import org.springframework.context.annotation.ComponentScan;
//import org.springframework.context.annotation.Import;
//import org.springframework.context.annotation.ImportResource;
//import org.springframework.context.support.ClassPathXmlApplicationContext;
//
//import org.springframework.dao.DataAccessException;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringRunner;
//import org.springframework.web.bind.annotation.PostMapping;
//
//import jakarta.annotation.PostConstruct;
//import java.util.Calendar;
//import java.util.Collection;
//import com.healthpartners.service.imfs.dto.ActivityDefinition;
//
//
//@RunWith(SpringRunner.class)
//@ComponentScan(basePackages = "com.healthpartners.service.imfs")
////@ServletComponentScan(basePackages = "com.healthpartners.service.imfs")
//@ImportResource("classpath:beans.xml")
////@ImportResource("classpath:applicationtest.propeties")
////@ContextConfiguration(classes = {ActivityDAOJdbc.class})
//@ContextConfiguration
////@EnableConfigurationProperties
//@SpringBootConfiguration
//@SpringBootTest
//public class NamedParameterPersonDAOServiceTest {
//
//    //not working. pull from context.a
//   // @Autowired
//   // public ActivityDAOJdbc activityDAOJdbc;
//
//    //@Test
//   // @PostConstruct
//    public void getActivityDAOJdbcTesting() {
//
//        ApplicationContext ctx = SpringApplication.run(NamedParameterPersonDAOServiceTest.class);
//        System.out.println("Application context initialized!!!");
//
//        ActivityDAOJdbc activityDAOJdbc = ctx.getBean("activityDAO", ActivityDAOJdbc.class);
//
//        Integer personId = 1700155;
//        Integer programId = 357633;
//        Integer activityId = 37;
//        String registrationId = "2084397";
//        //Tested BPM-466
//        //Collection memberActivities = activityDAOJdbc.getMemberActivities(personId, programId, false);
//        //Tested BPM-467 Collection<MemberActivity> memberActivities = activityDAOJdbc.getMemberActivitiesForPortal(personId, programId);
//        //BPM-469
//        //Collection<MemberActivity> memberActivities = activityDAOJdbc.getMemberActivities(personId, programId, false);
//        //BPM-470
//        //activityDAOJdbc.isPersonProgramActivityHistoryComplete(activityId, personId, programId, registrationId);
//        //BPM-471
//        //activityDAOJdbc.getMemberDMActivities(personId, programId, true);
//        //BPM-472
//        //activityDAOJdbc.getEligibleActivities(programId);
//        //BPM-473
//        String pMemberID = "30950988";
//        String pAuthCode = "350222-2";
//        Calendar pActivityDate = Calendar.getInstance();
//        pActivityDate.set(2022, 06, 01);
//        String pSourceActivityID = "2170";
////        Collection<EligibleProgramActivity> eligibleProgramActivities = activityDAOJdbc.getBusinessProgramsForActivity(
////                pSourceActivityID, pMemberID, pAuthCode,
////                pActivityDate);
//        //BPM474
////        Collection<EligibleProgramActivity> eligibleProgramActivities = activityDAOJdbc.getBusinessProgramsForActivityOutsideEnrollment(
////                pSourceActivityID, pMemberID, pAuthCode,
////                pActivityDate);
//        //BPM-475
//        //EligibleProgramActivity eligibleProgramActivity = activityDAOJdbc.getEligibleProgramActivity(pSourceActivityID, pMemberID, pAuthCode, pActivityDate, programId);
//        //BPM-476
//        //EligibleProgramActivity eligibleProgramActivity =  activityDAOJdbc.getEligibleProgramActivityOutsideEnrollment(pSourceActivityID, pMemberID, pAuthCode, pActivityDate, programId);
//        //BPM-477 and 478
//        //Collection<MemberActivity> memberActivities = activityDAOJdbc.getRecommendedActivities(personId, programId);
//        //BPM-479
//        //Collection<MemberActivity> memberActivities = activityDAOJdbc.getFilteredOutActivities(personId, programId, false);
//        //BPM-480
//       // Collection<MemberActivity> memberActivities = activityDAOJdbc.getFilteredOutActivitiesOutsideEnrollment(personId, programId, false);
//        //BPM-481
//
////        MemberActivity memberActivity = new MemberActivity();
////        memberActivity.setRegistrationID("123456789");
////        memberActivity.setAuthPromoCode("319022");
////        memberActivity.setSourceSystemID("0001");
////        memberActivity.setBusinessProgramID(357332);
////
////        ActivityDefinition activityDefinition = new ActivityDefinition();
////        activityDefinition.setSourceActivityID("0001");
////        memberActivity.setActivity(activityDefinition);
////        Calendar activityDate = Calendar.getInstance();
////        activityDate.set(2022, 06, 01);
////        GenericStatusType genericStatusType = new GenericStatusType();
////        genericStatusType.setStatusEffectiveDate(activityDate);
////        memberActivity.setActivityStatus(genericStatusType);
////        memberActivity.getActivityStatus().setStatusEffectiveDate(activityDate);
////        memberActivity.getActivityStatus().setStatusCodeValue("ACTIVE");
////
////        ActivityEvent activityEvent = new ActivityEvent();
////        activityEvent.setReasonDescription("Testing");
////        activityEvent.setMemberActivity(memberActivity);
////        activityEvent.setPersonDemographicsID(1726435);
////        activityEvent.setMemberID("50070804");
////        activityEvent.setInsertUserId("tjquist");
////
////
////
////
////        try {
//////            int count = activityDAOJdbc.insertMemberActivity(activityEvent);
////            Integer programID = 357332;
////            String memberID = "50070804";
////            int count = activityDAOJdbc.insertMemberActivity(programID, memberID,
////                    memberActivity);
////        } catch (Exception e) {
////            System.out.println("Exception thrown: " + e.getMessage());
////        }
//       // assertNotNull(count);
//
////        MemberActivity memberActivity = new MemberActivity();
////        memberActivity.setRegistrationID("123456789");
////        memberActivity.setAuthPromoCode("319022");
////        memberActivity.setSourceSystemID("0001");
////        memberActivity.setBusinessProgramID(357332);
////
////        ActivityDefinition activityDefinition = new ActivityDefinition();
////        activityDefinition.setSourceActivityID("0001");
////        memberActivity.setActivity(activityDefinition);
////        Calendar activityDate = Calendar.getInstance();
////        activityDate.set(2022, 06, 01);
////        GenericStatusType genericStatusType = new GenericStatusType();
////        genericStatusType.setStatusEffectiveDate(activityDate);
////        memberActivity.setActivityStatus(genericStatusType);
////        memberActivity.getActivityStatus().setStatusEffectiveDate(activityDate);
////        memberActivity.getActivityStatus().setStatusCodeValue("ACTIVE");
////
//
////        ActivityDefinition activityDefinition = new ActivityDefinition();
////        activityDefinition.setSourceActivityID("0001");
////
////        MemberActivity memberActivity = new MemberActivity();
////        memberActivity.setActivity(activityDefinition);
////        memberActivity.setRegistrationID("2077069");
////        memberActivity.setAuthPromoCode("319022");
////        memberActivity.setSourceSystemID("0001");
////        memberActivity.setBusinessProgramID(357332);
////
////        ActivityEvent activityEvent = new ActivityEvent();
////        activityEvent.setReasonDescription("Testing");
////        activityEvent.setMemberActivity(memberActivity);
////        activityEvent.setPersonDemographicsID(1726435);
////        activityEvent.setMemberID("10754437");
////        activityEvent.setModifyUserId("tjquist");
////
////      BPM-482
////        int count = activityDAOJdbc.updateMemberActivity(activityEvent);
//        //BPM-483
//       // int count = activityDAOJdbc.deleteMemberActivity(activityEvent);
//        //BPM-484
////        boolean isMemberActivityRow = activityDAOJdbc.hasMemberActivityRow(activityEvent);
//
////        if (isMemberActivityRow) {
////            System.out.println("Member activity row exists.");
////        }
//        //BPM-485
//        //int count = activityDAOJdbc.deleteMemberActivities(personId, programId);
//        //BPM-486
//        //Collection<ActivityDefinition> activityDefinitions = activityDAOJdbc.selectActivities();
//
//
//    //    Collection<ActivityEvent> activityEvents = activityDAOJdbc.getCurrentYearActivitiesForTransfer(personId);
//
//
//    //    System.out.println("End testing....");
//    }
//}
